<div class="container-fluid py-4">
    <div class="d-flex justify-content-between mb-4">
        <h2>Control de Inventario</h2>
        <div>
            <a href="?propiedad=CSDI" class="btn <?= $prop=='CSDI'?'btn-primary':'btn-outline-primary' ?>">CSDI</a>
            <a href="?propiedad=TNG" class="btn <?= $prop=='TNG'?'btn-success':'btn-outline-success' ?>">TNG</a>
        </div>
    </div>

    <!-- Búsqueda rápida -->
    <input type="text" id="busqueda-inventario" class="form-control mb-3" placeholder="🔍 Buscar en la tabla...">

    <div class="card shadow-sm">
        <table class="table table-hover" id="tabla-inventario">
            <thead class="table-dark">
                <tr>
                    <th><a href="?propiedad=<?=$prop?>&sort=modelo&dir=<?= $dir=='ASC'?'DESC':'ASC' ?>" class="text-white text-decoration-none">Modelo / Marca</a></th>
                    <th><a href="?propiedad=<?=$prop?>&sort=serie&dir=<?= $dir=='ASC'?'DESC':'ASC' ?>" class="text-white text-decoration-none">Nro Serie</a></th>
                    <th>Ubicación</th>
                    <th><a href="?propiedad=<?=$prop?>&sort=estado&dir=<?= $dir=='ASC'?'DESC':'ASC' ?>" class="text-white text-decoration-none">Estado</a></th>
                    <th>Ficha</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($equipos as $e): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($e['nombre_modelo']) ?></strong><br><small><?= htmlspecialchars($e['marca']) ?></small></td>
                    <td><?= htmlspecialchars($e['serie']) ?></td>
                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($e['cliente_nombre'] ?? 'STOCK') ?></span></td>
                    <td><span class="badge bg-info"><?= htmlspecialchars($e['estado']) ?></span></td>
                    <td><button class="btn btn-sm btn-outline-primary" onclick="ui.modal('/admin/equipo?id=<?= $e['id'] ?>', 'Ficha')">✏️</button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Búsqueda instantánea
document.getElementById('busqueda-inventario').addEventListener('keyup', function() {
    let term = this.value.toLowerCase();
    document.querySelectorAll('#tabla-inventario tbody tr').forEach(tr => {
        tr.style.display = tr.innerText.toLowerCase().includes(term) ? '' : 'none';
    });
});
</script>