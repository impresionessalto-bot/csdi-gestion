<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Services\PortalClienteService;
use App\Services\Timeline\TimelineService;
use App\Services\Statistics\StatisticsService;
use App\Services\Alert\AlertService;
use App\Services\Document\DocumentService;
use App\Services\IaService;
use Throwable;


final class PortalClienteDashboard extends BaseDashboard
{


    public function __construct(

        private readonly PortalClienteService $portalService,

        private readonly TimelineService $timeline,

        private readonly StatisticsService $statistics,

        private readonly AlertService $alerts,

        private readonly DocumentService $documents,

        private readonly ?IaService $ia = null

    ) {

    }







    /**
     * =====================================================
     * DASHBOARD PORTAL CLIENTE
     * =====================================================
     */
    public function obtener(
        int $id = 0
    ): array
    {


        try {


            if($id <= 0){


                return $this->build([

                    'alertas'=>[

                        [

                            'tipo'=>'warning',

                            'mensaje'=>'Cliente inválido'

                        ]

                    ]

                ]);

            }








            $cliente =
                $this->portalService
                ->cliente(
                    $id
                );








            if(!$cliente){


                return $this->build([

                    'alertas'=>[

                        [

                            'tipo'=>'danger',

                            'mensaje'=>'Cliente no encontrado'

                        ]

                    ]

                ]);


            }










            return $this->build([






                'general'=>[


                    'cliente'=>$cliente,


                    'empresa'=>[],


                    'contactos'=>[],


                    'usuarios'=>[],


                    'sucursales'=>[],


                ],







                'tecnico'=>[


                    'equipos'=>[],


                    'contadores'=>[],


                    'ultimos_servicios'=>[],


                    'mantenimientos'=>[],


                    'equipos_fuera_servicio'=>[],


                ],







                'comercial'=>[


                    'contratos'=>[],


                    'promociones'=>[],


                    'equipos_en_venta'=>[],


                    'insumos'=>[],


                    'ofertas_personalizadas'=>[],


                    'programa_referidos'=>[],


                ],







                'financiero'=>[


                    'facturas'=>[],


                    'recibos'=>[],


                    'cuenta_corriente'=>[],


                    'saldo'=>[],


                    'vencimientos'=>[],


                ],







                'kpis'=>[


                    'equipos_activos'=>0,


                    'servicios_abiertos'=>0,


                    'facturas_pendientes'=>0,


                    'contadores_pendientes'=>0,


                    'proximo_mantenimiento'=>0,


                ],







                'estadisticas'=>

                    $this->safeCall(

                        fn() =>

                        $this->statistics
                        ->portalCliente(
                            $id
                        )

                    ),







                'timeline'=>

                    $this->safeCall(

                        fn() =>

                        $this->timeline
                        ->cliente(
                            $id
                        )

                    ),







                'alertas'=>

                    $this->safeCall(

                        fn() =>

                        $this->alerts
                        ->cliente(
                            $id
                        )

                    ),







                'documentos'=>

                    $this->safeCall(

                        fn() =>

                        $this->documents
                        ->cliente(
                            $id
                        )

                    ),







                'imagenes'=>[


                    'logo'=>null,


                    'equipos'=>[],


                    'servicios'=>[],


                ],







                'widgets'=>[


                    'equipos'=>[],


                    'facturacion'=>[],


                    'contadores'=>[],


                    'promociones'=>[],


                    'referidos'=>[],


                    'servicios'=>[],


                    'encuestas'=>[],


                    'notificaciones'=>[],


                ],







                'acciones'=>[


                    'nuevo_reclamo',


                    'registrar_contador_manual',


                    'subir_foto_contador',


                    'subir_pdf_contador',


                    'descargar_factura',


                    'pagar_online',


                    'comprar_insumos',


                    'comprar_equipo',


                    'solicitar_cotizacion',


                    'solicitar_mudanza',


                    'solicitar_instalacion',


                    'referir_cliente',


                    'chat_soporte',


                ],







                'ia'=>[


                    'resumen'=>null,


                    'asistente'=>[],


                    'diagnosticos'=>[],


                    'recomendaciones'=>[],


                    'faq'=>[],


                ]







            ]);



        }
        catch(Throwable $e)
        {


            return $this->build([


                'alertas'=>[


                    [

                        'tipo'=>'danger',

                        'mensaje'=>
                            'Error cargando portal cliente: '
                            .
                            $e->getMessage()

                    ]

                ]


            ]);



        }



    }









    /**
     * Ejecuta servicios protegidos
     */
    private function safeCall(
        callable $callback
    ):array
    {


        try {


            $resultado =
                $callback();



            return is_array($resultado)
                ?
                $resultado
                :
                [];



        }
        catch(Throwable)
        {

            return [];

        }


    }



}