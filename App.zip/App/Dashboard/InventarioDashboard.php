<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Modules\Inventario\Services\Service as InventarioService;
use App\Services\Timeline\TimelineService;
use App\Services\Statistics\StatisticsService;
use App\Services\Alert\AlertService;
use App\Services\Document\DocumentService;
use App\Services\IaService;
use Throwable;


final class InventarioDashboard extends BaseDashboard
{

    public function __construct(
        private readonly InventarioService $inventarioService,
        private readonly TimelineService $timeline,
        private readonly StatisticsService $statistics,
        private readonly AlertService $alerts,
        private readonly DocumentService $documents,
        private readonly IaService $ia
    ) {
    }





    public function obtener(
        int $id = 0
    ): array
    {


        if($id <= 0){

            return $this->build([]);

        }



        try {


            $producto =
                $this->inventarioService->find($id);



            if(!$producto){

                return $this->build([]);

            }




            return $this->build([



                'general'=>[

                    'producto'=>$producto,

                    'categoria'=>[],

                    'marca'=>[],

                    'modelo'=>[],

                    'ubicacion'=>[],

                    'proveedor'=>[]

                ],




                'tecnico'=>[

                    'compatibilidades'=>[],

                    'equipos_instalados'=>[],

                    'vida_util'=>[],

                    'instalaciones'=>[],

                    'consumos'=>[]

                ],




                'comercial'=>[

                    'compras'=>[],

                    'ventas'=>[],

                    'clientes'=>[],

                    'cotizaciones'=>[]

                ],




                'financiero'=>[

                    'precio_compra'=>
                        $producto['precio_compra'] ?? 0,


                    'precio_venta'=>
                        $producto['precio_venta'] ?? 0,


                    'stock_valorizado'=>0,


                    'rentabilidad'=>[],


                    'movimientos'=>[]

                ],





                'kpis'=>[

                    'stock_actual'=>0,

                    'stock_minimo'=>0,

                    'stock_reservado'=>0,

                    'stock_disponible'=>0,

                    'rotacion'=>0,

                    'dias_stock'=>0,

                    'consumo_mensual'=>0,

                    'valor_stock'=>0

                ],





                'estadisticas'=>
                    method_exists(
                        $this->statistics,
                        'inventario'
                    )
                    ?
                    $this->statistics->inventario($id)
                    :
                    [],





                'timeline'=>
                    $this->timeline->inventario($id),





                'alertas'=>
                    $this->alerts->inventario($id),





                'documentos'=>
                    $this->documents->inventario($id),





                'imagenes'=>[

                    'principal'=>
                        $producto['foto'] ?? null,


                    'galeria'=>[]

                ],





                'widgets'=>[

                    'stock'=>[],

                    'rotacion'=>[],

                    'consumo'=>[],

                    'compatibilidad'=>[],

                    'compras'=>[],

                    'ventas'=>[]

                ],





                'acciones'=>[

                    'entrada_stock',

                    'salida_stock',

                    'ajuste_stock',

                    'traslado',

                    'comprar',

                    'vender',

                    'imprimir_etiqueta_qr',

                    'subir_documento',

                    'subir_foto'

                ],





                'ia'=>[

                    'resumen'=>null,

                    'prediccion_stock'=>[],

                    'recomendacion_compra'=>[],

                    'consumo_estimado'=>[],

                    'riesgos'=>[]

                ]



            ]);



        }
        catch(Throwable)
        {

            return $this->build([]);

        }



    }


}