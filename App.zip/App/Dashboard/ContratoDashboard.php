<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Modules\Contratos\Services\Service as ContratoService;
use App\Modules\Clientes\Services\Service as ClienteService;
use App\Modules\Equipos\Services\Service as EquipoService;
use App\Services\Timeline\TimelineService;
use App\Services\Statistics\StatisticsService;
use App\Services\Alert\AlertService;
use App\Services\Document\DocumentService;
use App\Services\IaService;
use Throwable;


final class ContratoDashboard extends BaseDashboard
{

    public function __construct(

        private readonly ContratoService $contratoService,

        private readonly ClienteService $clienteService,

        private readonly EquipoService $equipoService,

        private readonly TimelineService $timeline,

        private readonly StatisticsService $statistics,

        private readonly AlertService $alerts,

        private readonly DocumentService $documents,

        private readonly ?IaService $ia = null

    ) {

    }





    public function obtener(
        int $id = 0
    ): array
    {


        if($id <= 0)
        {

            return $this->build([

                'alertas'=>[

                    [
                        'tipo'=>'warning',
                        'mensaje'=>'Contrato no especificado'
                    ]

                ]

            ]);

        }






        try
        {


            $contrato =
                $this->safeValue(

                    fn() =>

                    $this->contratoService->find($id)

                );





            if(!is_array($contrato) || empty($contrato))
            {

                return $this->build([

                    'alertas'=>[

                        [
                            'tipo'=>'danger',
                            'mensaje'=>'Contrato no encontrado'
                        ]

                    ]

                ]);

            }






            $cliente = null;

            $equipos = [];







            $clienteId =
                (int)(
                    $contrato['cliente_id']
                    ??
                    0
                );






            if($clienteId > 0)
            {


                $cliente =

                    $this->safeValue(

                        fn() =>

                        $this->clienteService
                        ->find($clienteId)

                    );





                $equipos =

                    $this->safeArray(

                        fn() =>

                        $this->equipoService
                        ->porCliente($clienteId)

                    );


            }









            return $this->build([



                'general'=>[


                    'contrato'=>$contrato,

                    'cliente'=>$cliente,

                    'equipos'=>$equipos,

                    'estado'=>
                        $contrato['estado']
                        ??
                        null

                ],







                'tecnico'=>[

                    'equipos'=>[],

                    'contadores'=>[],

                    'mantenimientos'=>[],

                    'servicios'=>[],

                    'preventivos'=>[],

                    'correctivos'=>[]

                ],







                'comercial'=>[

                    'vigencia'=>[],

                    'renovaciones'=>[],

                    'anexos'=>[],

                    'adendas'=>[],

                    'historial'=>[]

                ],







                'financiero'=>[

                    'abono'=>[],

                    'facturacion'=>[],

                    'pagos'=>[],

                    'saldo'=>[],

                    'copias_excedentes'=>[]

                ],







                'kpis'=>[

                    'meses_vigencia'=>0,

                    'copias_mes'=>0,

                    'copias_excedentes'=>0,

                    'facturacion_total'=>0,

                    'rentabilidad'=>0,

                    'cumplimiento'=>0

                ],







                'estadisticas'=>

                    $this->safeArray(

                        fn() =>

                        $this->statistics
                        ->contrato($id)

                    ),






                'timeline'=>

                    $this->safeArray(

                        fn() =>

                        $this->timeline
                        ->contrato($id)

                    ),






                'alertas'=>

                    $this->safeArray(

                        fn() =>

                        $this->alerts
                        ->contrato($id)

                    ),






                'documentos'=>

                    $this->safeArray(

                        fn() =>

                        $this->documents
                        ->contrato($id)

                    ),







                'imagenes'=>[

                    'contrato_firmado'=>null,

                    'anexos'=>[]

                ],







                'widgets'=>[

                    'vigencia'=>[],

                    'copias'=>[],

                    'facturacion'=>[],

                    'rentabilidad'=>[],

                    'equipos'=>[],

                    'renovacion'=>[]

                ],







                'acciones'=>[

                    'renovar_contrato',

                    'agregar_equipo',

                    'quitar_equipo',

                    'registrar_contador',

                    'emitir_factura',

                    'crear_servicio',

                    'subir_documento',

                    'imprimir_contrato'

                ],







                'ia'=>[

                    'resumen'=>null,

                    'riesgos'=>[],

                    'predicciones'=>[],

                    'recomendaciones'=>[],

                    'renovacion'=>[]

                ]



            ]);



        }
        catch(Throwable)
        {


            return $this->build([

                'alertas'=>[

                    [

                        'tipo'=>'danger',

                        'mensaje'=>'Error cargando dashboard contrato'

                    ]

                ]

            ]);


        }


    }









    private function safeArray(
        callable $callback
    ):array
    {

        try
        {

            $data = $callback();

            return is_array($data)
                ?
                $data
                :
                [];

        }
        catch(Throwable)
        {

            return [];

        }

    }







    private function safeValue(
        callable $callback
    ):mixed
    {

        try
        {

            return $callback();

        }
        catch(Throwable)
        {

            return null;

        }

    }


}