<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Modules\Equipos\Services\Service as EquipoService;
use App\Modules\Clientes\Services\Service as ClienteService;
use App\Services\Timeline\TimelineService;
use App\Services\Statistics\StatisticsService;
use App\Services\Alert\AlertService;
use App\Services\Document\DocumentService;
use App\Services\IaService;
use Throwable;


final class EquipoDashboard extends BaseDashboard
{


    public function __construct(

        private readonly EquipoService $equipoService,

        private readonly ClienteService $clienteService,

        private readonly TimelineService $timeline,

        private readonly StatisticsService $statistics,

        private readonly AlertService $alerts,

        private readonly DocumentService $documents,

        private readonly ?IaService $ia = null

    ){
    }








    public function obtener(
        int $id = 0
    ): array
    {


        if($id <= 0)
        {

            return $this->build([

                'general'=>[

                    'error'=>'Equipo no especificado'

                ],

                'kpis'=>$this->kpis(),

                'widgets'=>$this->widgets()

            ]);

        }








        $equipo =
            $this->safe(
                fn() =>
                    $this->equipoService->find($id)
            );







        if(!is_array($equipo))
        {

            return $this->build([

                'general'=>[

                    'error'=>'Equipo no encontrado'

                ],

                'kpis'=>$this->kpis(),

                'widgets'=>$this->widgets()

            ]);

        }








        return $this->build([



            /*
            |--------------------------------------------------------------------------
            | INFORMACIÓN GENERAL
            |--------------------------------------------------------------------------
            */

            'general'=>[


                'equipo'=>$equipo,


                'cliente'=>
                    $this->cliente(
                        $equipo['cliente_id'] ?? null
                    ),


                'modelo'=>
                    $equipo['modelo_oficial']
                    ??
                    null,


                'marca'=>
                    $equipo['marca']
                    ??
                    null,


                'estado'=>
                    $equipo['estado']
                    ??
                    'Activo',


                'propiedad'=>
                    $equipo['propiedad']
                    ??
                    'CSDI'


            ],







            /*
            |--------------------------------------------------------------------------
            | INFORMACIÓN TÉCNICA
            |--------------------------------------------------------------------------
            */

            'tecnico'=>[


                'contadores'=>[],


                'servicios'=>[],


                'mantenimientos'=>[],


                'componentes'=>[],


                'consumibles'=>[],


                'firmware'=>null,


                'telemetria'=>[]


            ],







            /*
            |--------------------------------------------------------------------------
            | COMERCIAL
            |--------------------------------------------------------------------------
            */

            'comercial'=>[


                'contratos'=>[],


                'ventas'=>[],


                'alquileres'=>[],


                'cotizaciones'=>[]


            ],







            /*
            |--------------------------------------------------------------------------
            | FINANCIERO
            |--------------------------------------------------------------------------
            */

            'financiero'=>[


                'valor_activo'=>
                    $equipo['valor_activo']
                    ??
                    0,


                'facturacion'=>[],


                'costos'=>[],


                'rentabilidad'=>[],


                'roi'=>0


            ],







            /*
            |--------------------------------------------------------------------------
            | KPIS
            |--------------------------------------------------------------------------
            */

            'kpis'=>$this->kpis($id),







            /*
            |--------------------------------------------------------------------------
            | ESTADISTICAS
            |--------------------------------------------------------------------------
            */

            'estadisticas'=>

                $this->safeArray(

                    fn() =>
                    $this->statistics->equipo($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | TIMELINE
            |--------------------------------------------------------------------------
            */

            'timeline'=>

                $this->safeArray(

                    fn() =>
                    $this->timeline->equipo($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | ALERTAS
            |--------------------------------------------------------------------------
            */

            'alertas'=>

                $this->safeArray(

                    fn() =>
                    $this->alerts->equipo($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | DOCUMENTOS
            |--------------------------------------------------------------------------
            */

            'documentos'=>

                $this->safeArray(

                    fn() =>
                    $this->documents->equipo($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | IMÁGENES
            |--------------------------------------------------------------------------
            */

            'imagenes'=>[


                'principal'=>
                    $equipo['foto']
                    ??
                    null,


                'galeria'=>[]


            ],







            /*
            |--------------------------------------------------------------------------
            | WIDGETS
            |--------------------------------------------------------------------------
            */

            'widgets'=>$this->widgets(),







            /*
            |--------------------------------------------------------------------------
            | ACCIONES
            |--------------------------------------------------------------------------
            */

            'acciones'=>[


                'registrar_contador',


                'crear_servicio',


                'registrar_mantenimiento',


                'cambiar_cliente',


                'trasladar',


                'subir_documento',


                'subir_foto'


            ],







            /*
            |--------------------------------------------------------------------------
            | IA
            |--------------------------------------------------------------------------
            */

            'ia'=>[


                'resumen'=>null,


                'riesgos'=>[],


                'predicciones'=>[],


                'recomendaciones'=>[]


            ]



        ]);


    }









    private function kpis(
        int $id = 0
    ):array
    {


        try {


            $data =
                $this->equipoService
                ->obtenerEstadisticas();



            return [


                'total'=>
                    $data['total'] ?? 0,


                'activos'=>
                    $data['activos'] ?? 0,


                'tng'=>
                    $data['tng'] ?? 0,


                'taller'=>
                    $data['taller'] ?? 0,


                'health_score'=>0,


                'mtbf'=>0,


                'mttr'=>0,


                'copias_totales'=>0,


                'disponibilidad'=>0


            ];


        }
        catch(Throwable)
        {


            return [

                'total'=>0,

                'activos'=>0,

                'tng'=>0,

                'taller'=>0

            ];


        }


    }









    private function widgets():array
    {

        return [


            'health'=>[],


            'contador'=>[],


            'consumo'=>[],


            'fallas'=>[],


            'rentabilidad'=>[],


            'mantenimientos'=>[],


            'ubicacion'=>[],


            'vida_util'=>[]


        ];


    }









    private function cliente(
        mixed $id
    ):?array
    {


        if(!$id)
        {
            return null;
        }



        return $this->safe(

            fn() =>
                $this->clienteService
                ->find((int)$id)

        );


    }









    private function safe(
        callable $callback
    ):mixed
    {

        try {

            return $callback();

        }
        catch(Throwable)
        {

            return null;

        }


    }









    private function safeArray(
        callable $callback
    ):array
    {


        try {


            $result =
                $callback();



            return is_array($result)
                ?
                $result
                :
                [];

        }
        catch(Throwable)
        {

            return [];

        }


    }


}