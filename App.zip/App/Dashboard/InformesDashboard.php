<?php

declare(strict_types=1);

namespace App\Dashboard;

use PDO;
use Throwable;


final class InformesDashboard extends BaseDashboard
{


    public function __construct(
        private readonly PDO $db
    ){
    }





    public function obtener(
        int $id = 0
    ):array
    {

        return $this->build([


            'general'=>[

                'titulo'=>'Informes TNG'

            ],



            'kpis'=>$this->cards(),



            'estadisticas'=>[

                'informes'=>
                    $this->totalInformes(),

                'pendientes'=>
                    $this->pendientes()

            ],



            'widgets'=>[

                'informes'=>[]

            ]



        ]);

    }





    public function cards():array
    {

        return [

            'informes_tng'=>
                $this->totalInformes(),


            'pendientes_tng'=>
                $this->pendientes(),

        ];

    }





    private function totalInformes():int
    {

        try {


            return (int)$this->db

                ->query("

                    SELECT COUNT(*)

                    FROM historial_informes

                    WHERE propiedad='TNG'

                ")

                ->fetchColumn();


        }
        catch(Throwable)
        {

            return 0;

        }


    }





    private function pendientes():int
    {

        try {


            return (int)$this->db

                ->query("

                    SELECT COUNT(*)

                    FROM equipos

                    WHERE propiedad='TNG'

                    AND activo=1

                ")

                ->fetchColumn();



        }
        catch(Throwable)
        {

            return 0;

        }


    }


}