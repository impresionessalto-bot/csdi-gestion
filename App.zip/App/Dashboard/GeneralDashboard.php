<?php

declare(strict_types=1);

namespace App\Dashboard;


use App\Dashboard\Builders\DashboardBuilder;
use Throwable;



final class GeneralDashboard extends BaseDashboard
{


    public function __construct(
        private readonly DashboardBuilder $builder
    )
    {

    }







    /**
     * Dashboard general ERP
     */
    public function obtener(
        int $id = 0
    ):array
    {


        try {


            return $this->build(

                $this->builder->general($id)

            );


        }
        catch(Throwable $e)
        {


            return $this->build([


                'error'=>true,


                'mensaje'=>
                    $e->getMessage(),


                'dashboard'=>'general'


            ]);


        }


    }





}