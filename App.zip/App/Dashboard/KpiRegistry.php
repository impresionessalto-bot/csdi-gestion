<?php

declare(strict_types=1);

namespace App\Dashboard;


use App\Services\Statistics\StatisticsService;




final class KpiRegistry
{


    private array $kpis=[];





    public function __construct(
        private readonly StatisticsService $statistics
    )
    {

        $this->registerDefaults();

    }









    private function registerDefaults():void
    {


        $this->register(

            'clientes',

            [

                'titulo'=>'Clientes',

                'valor'=>fn() =>
                    $this->statistics
                    ->clientes(),

                'icono'=>
                    'fa-solid fa-users',

                'color'=>
                    'primary',

                'ruta'=>
                    '/clientes'


            ]

        );







        $this->register(

            'equipos',

            [

                'titulo'=>'Equipos',

                'valor'=>fn() =>
                    $this->statistics
                    ->equipos(),

                'icono'=>
                    'fa-solid fa-print',

                'color'=>
                    'info',

                'ruta'=>
                    '/equipos'


            ]

        );







        $this->register(

            'servicios',

            [

                'titulo'=>'Servicios',

                'valor'=>fn() =>
                    $this->statistics
                    ->servicios(),

                'icono'=>
                    'fa-solid fa-screwdriver-wrench',

                'color'=>
                    'warning',

                'ruta'=>
                    '/servicios'


            ]

        );







        $this->register(

            'contadores',

            [

                'titulo'=>'Contadores',

                'valor'=>fn() =>
                    $this->statistics
                    ->contadores(),

                'icono'=>
                    'fa-solid fa-calculator',

                'color'=>
                    'success',

                'ruta'=>
                    '/contadores'


            ]

        );







        $this->register(

            'ventas',

            [

                'titulo'=>'Ventas',

                'valor'=>fn() =>
                    $this->statistics
                    ->ventas(),

                'icono'=>
                    'fa-solid fa-cart-shopping',

                'color'=>
                    'danger',

                'ruta'=>
                    '/ventas'


            ]

        );


    }









    public function register(
        string $name,
        array $data
    ):void
    {

        $this->kpis[$name]=$data;


    }









    public function all():array
    {

        return $this->kpis;


    }









    public function get(
        string $name
    ):array
    {

        return $this->kpis[$name] ?? [];


    }









    public function has(
        string $name
    ):bool
    {

        return isset(
            $this->kpis[$name]
        );


    }









    public function remove(
        string $name
    ):void
    {

        unset(
            $this->kpis[$name]
        );


    }









    public function clear():void
    {

        $this->kpis=[];


    }


}