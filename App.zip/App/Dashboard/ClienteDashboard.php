<?php

declare(strict_types=1);

namespace App\Dashboard;


use App\Services\ClienteService;
use App\Services\EquipoService;
use App\Services\Timeline\TimelineService;
use App\Services\Statistics\StatisticsService;
use App\Services\Alert\AlertService;
use App\Services\Document\DocumentService;
use App\Services\IaService;
use Throwable;



final class ClienteDashboard extends BaseDashboard
{


    public function __construct(

        private readonly ClienteService $clienteService,

        private readonly EquipoService $equipoService,

        private readonly TimelineService $timeline,

        private readonly StatisticsService $statistics,

        private readonly AlertService $alerts,

        private readonly DocumentService $documents,

        private readonly ?IaService $ia = null

    ) {

    }







    /**
     * =====================================================
     * DASHBOARD CLIENTE
     * =====================================================
     */
    public function obtener(
        int $id = 0
    ): array
    {


        /*
        |--------------------------------------------------------------------------
        | Validación
        |--------------------------------------------------------------------------
        */


        if($id <= 0)
        {

            return $this->build([

                'alertas'=>[

                    [

                        'tipo'=>'danger',

                        'mensaje'=>'Cliente inválido'

                    ]

                ]

            ]);

        }






        try {


            /*
            |--------------------------------------------------------------------------
            | Cliente
            |--------------------------------------------------------------------------
            */


            $cliente =
                $this->clienteService
                ->find($id);





            if(!$cliente)
            {

                return $this->build([

                    'alertas'=>[

                        [

                            'tipo'=>'warning',

                            'mensaje'=>'Cliente no encontrado'

                        ]

                    ]

                ]);

            }






            /*
            |--------------------------------------------------------------------------
            | Equipos asociados
            |--------------------------------------------------------------------------
            */


            $equipos =
                $this->equipoService
                ->porCliente($id);







            /*
            |--------------------------------------------------------------------------
            | Construcción Dashboard
            |--------------------------------------------------------------------------
            */


            return $this->build([



                /*
                |--------------------------------------------------------------------------
                | GENERAL
                |--------------------------------------------------------------------------
                */


                'general'=>[


                    'cliente'=>$cliente,


                    'equipos'=>$equipos,



                    'contactos'=>
                        $this->safe(
                            fn() =>
                            $this->clienteService
                            ->contactos($id)
                        ),




                    'localidad'=>
                        $this->safe(
                            fn() =>
                            $this->clienteService
                            ->localidad($id)
                        )



                ],






                /*
                |--------------------------------------------------------------------------
                | TECNICO
                |--------------------------------------------------------------------------
                */


                'tecnico'=>[


                    'servicios'=>[],


                    'contadores'=>[],


                    'preventivos'=>[],


                    'correctivos'=>[]


                ],







                /*
                |--------------------------------------------------------------------------
                | COMERCIAL
                |--------------------------------------------------------------------------
                */


                'comercial'=>[


                    'contratos'=>[],


                    'ventas'=>[],


                    'cotizaciones'=>[],


                    'insumos'=>[]


                ],







                /*
                |--------------------------------------------------------------------------
                | FINANCIERO
                |--------------------------------------------------------------------------
                */


                'financiero'=>[


                    'facturas'=>[],


                    'cuenta_corriente'=>[],


                    'pagos'=>[],


                    'deuda'=>[]


                ],







                /*
                |--------------------------------------------------------------------------
                | KPIs
                |--------------------------------------------------------------------------
                */


                'kpis'=>[


                    'equipos'=>
                        count($equipos),



                    'servicios'=>0,


                    'facturacion'=>0,


                    'copias'=>0,


                    'rentabilidad'=>0


                ],







                /*
                |--------------------------------------------------------------------------
                | ESTADISTICAS
                |--------------------------------------------------------------------------
                */


                'estadisticas'=>

                    $this->safe(

                        fn() =>
                        $this->statistics
                        ->cliente($id)

                    ),







                /*
                |--------------------------------------------------------------------------
                | TIMELINE
                |--------------------------------------------------------------------------
                */


                'timeline'=>

                    $this->safe(

                        fn() =>
                        $this->timeline
                        ->cliente($id)

                    ),







                /*
                |--------------------------------------------------------------------------
                | ALERTAS
                |--------------------------------------------------------------------------
                */


                'alertas'=>

                    $this->safe(

                        fn() =>
                        $this->alerts
                        ->cliente($id)

                    ),







                /*
                |--------------------------------------------------------------------------
                | DOCUMENTOS
                |--------------------------------------------------------------------------
                */


                'documentos'=>

                    $this->safe(

                        fn() =>
                        $this->documents
                        ->cliente($id)

                    ),







                /*
                |--------------------------------------------------------------------------
                | IMAGENES
                |--------------------------------------------------------------------------
                */


                'imagenes'=>[],








                /*
                |--------------------------------------------------------------------------
                | WIDGETS
                |--------------------------------------------------------------------------
                */


                'widgets'=>[


                    'salud_cliente'=>[],


                    'facturacion_mensual'=>[],


                    'equipos_estado'=>[],


                    'ranking_consumo'=>[]


                ],







                /*
                |--------------------------------------------------------------------------
                | ACCIONES RAPIDAS
                |--------------------------------------------------------------------------
                */


                'acciones'=>[


                    'nuevo_servicio',


                    'nuevo_contrato',


                    'registrar_contador',


                    'subir_documento',


                    'enviar_whatsapp',


                    'enviar_mail'


                ],







                /*
                |--------------------------------------------------------------------------
                | IA
                |--------------------------------------------------------------------------
                */


                'ia'=>[


                    'resumen'=>null,


                    'riesgos'=>[],


                    'recomendaciones'=>[],


                    'predicciones'=>[]


                ]



            ]);



        }
        catch(Throwable $e)
        {


            return $this->build([

                'alertas'=>[

                    [

                        'tipo'=>'danger',

                        'mensaje'=>
                            'Error cargando Dashboard Cliente'

                    ]

                ]

            ]);

        }


    }








    /**
     * =====================================================
     * EJECUCIÓN SEGURA DE SERVICIOS
     * =====================================================
     */
    private function safe(
        callable $callback
    ):array
    {


        try {


            $resultado =
                $callback();



            return is_array($resultado)
                ?
                $resultado
                :
                [];



        }
        catch(Throwable)
        {

            return [];

        }


    }



}