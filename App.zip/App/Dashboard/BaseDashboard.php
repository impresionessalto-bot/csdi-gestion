<?php

declare(strict_types=1);

namespace App\Dashboard;


/**
 * =========================================================
 * ERP CSDI PRO
 *
 * CONTRATO BASE DASHBOARDS
 *
 * =========================================================
 */

interface DashboardInterface
{

    /**
     * Genera información del Dashboard
     */
    public function obtener(
        int $id = 0
    ): array;

}







/**
 * =========================================================
 * DASHBOARD BASE
 *
 * Todos los dashboards heredan esta estructura.
 *
 * =========================================================
 */

abstract class BaseDashboard implements DashboardInterface
{


    /**
     * Estructura estándar ERP
     */
    protected function estructuraBase(): array
    {

        return [


            'general'=>[],


            'tecnico'=>[],


            'comercial'=>[],


            'financiero'=>[],


            'kpis'=>[],


            'estadisticas'=>[],


            'timeline'=>[],


            'alertas'=>[],


            'documentos'=>[],


            'imagenes'=>[],


            'widgets'=>[],


            'acciones'=>[],


            'ia'=>[]


        ];

    }








    /**
     * Une estructura + datos específicos
     */
    protected function build(
        array $datos
    ): array
    {


        return array_replace_recursive(

            $this->estructuraBase(),

            $datos

        );


    }








    /**
     * Obligatorio para todos los dashboards
     */
    abstract public function obtener(
        int $id = 0
    ): array;



}