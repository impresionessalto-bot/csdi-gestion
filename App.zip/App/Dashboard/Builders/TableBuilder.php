<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class TableBuilder
{


    private array $columns=[];

    private array $rows=[];





    public function columns(
        array $columns
    ):self
    {

        $this->columns=$columns;


        return $this;

    }







    public function rows(
        array $rows
    ):self
    {

        $this->rows=$rows;


        return $this;

    }







    public function build():array
    {

        return [


            'columns'=>$this->columns,


            'rows'=>$this->rows


        ];

    }



}