<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class WidgetBuilder
{

    /**
     * Widgets registrados
     *
     * @var array<int,array>
     */
    private array $widgets = [];





    /**
     * Agregar widget
     */
    public function add(
        string $name,
        array $data = []
    ): self
    {

        $this->widgets[] = [

            'name' => $name,

            'data' => $data

        ];


        return $this;

    }







    /**
     * Widget con título
     */
    public function card(
        string $name,
        string $title,
        array $data = []
    ): self
    {


        return $this->add(
            $name,
            [

                'title'=>$title,

                ...$data

            ]
        );


    }







    /**
     * Cantidad de widgets
     */
    public function count():int
    {

        return count(
            $this->widgets
        );

    }







    /**
     * Verificar existencia
     */
    public function has(
        string $name
    ):bool
    {


        foreach($this->widgets as $widget)
        {

            if(
                ($widget['name'] ?? null)
                ===
                $name
            ){

                return true;

            }

        }


        return false;

    }







    /**
     * Obtener todos
     */
    public function all():array
    {

        return $this->widgets;

    }







    /**
     * Limpiar
     */
    public function clear():self
    {

        $this->widgets=[];


        return $this;

    }



}