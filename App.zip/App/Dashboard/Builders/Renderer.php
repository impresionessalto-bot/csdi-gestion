<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;

use Throwable;


/**
 * =========================================================
 * ERP CSDI PRO
 *
 * Dashboard Renderer V2
 *
 * Ubicación:
 * App/Dashboard/Builder/Renderer.php
 *
 * Responsabilidad:
 *
 * - Normalizar datos del Dashboard
 * - Preparar estructura para vistas Bootstrap 5
 * - Controlar widgets dinámicos
 * - Controlar KPIs
 * - Controlar gráficos
 * - Controlar tablas
 *
 * NO contiene:
 *
 * - SQL
 * - PDO
 * - Servicios
 * - Reglas de negocio
 *
 * =========================================================
 */

final class Renderer
{


    /**
     * Render dashboard completo
     */
    public function render(
        array $dashboard
    ): array
    {


        return [


            'header' =>

                $this->header(
                    $dashboard
                ),



            'kpis' =>

                $this->kpis(
                    $dashboard['kpis']
                    ??
                    []
                ),




            'widgets' =>

                $this->widgets(
                    $dashboard['widgets']
                    ??
                    []
                ),




            'charts' =>

                $this->charts(
                    $dashboard['charts']
                    ??
                    []
                ),




            'tables' =>

                $this->tables(
                    $dashboard['tables']
                    ??
                    []
                ),




            'alerts' =>

                $this->alerts(
                    $dashboard['alertas']
                    ??
                    []
                ),




            'meta' => [

                'rendered'=>true,

                'version'=>'2.0'

            ]


        ];

    }









    /**
     * Header dashboard
     */
    private function header(
        array $data
    ):array
    {


        return [


            'titulo'=>

                $data['titulo']
                ??
                'Dashboard ERP',



            'descripcion'=>

                $data['descripcion']
                ??
                '',



            'icono'=>

                $data['icono']
                ??
                'fa-solid fa-chart-line'



        ];

    }









    /**
     * Procesar KPIs
     */
    private function kpis(
        mixed $items
    ):array
    {


        if(!is_array($items))
        {
            return [];
        }



        $resultado=[];



        foreach($items as $item)
        {


            try {


                if(!is_array($item))
                {
                    continue;
                }



                $resultado[]=[


                    'nombre'=>

                        $item['nombre']
                        ??
                        null,



                    'titulo'=>

                        $item['titulo']
                        ??
                        'KPI',



                    'valor'=>

                        $item['valor']
                        ??
                        0,



                    'icono'=>

                        $item['icono']
                        ??
                        'fa-solid fa-chart-simple',



                    'color'=>

                        $item['color']
                        ??
                        'primary',



                    'ruta'=>

                        $item['ruta']
                        ??
                        null


                ];



            }
            catch(Throwable)
            {

                continue;

            }


        }



        return $resultado;


    }









    /**
     * Procesar widgets dinámicos
     */
    private function widgets(
        mixed $items
    ):array
    {


        if(!is_array($items))
        {
            return [];
        }



        $resultado=[];



        foreach($items as $widget)
        {


            if(!is_array($widget))
            {
                continue;
            }




            $resultado[]=[



                'nombre'=>

                    $widget['nombre']
                    ??
                    null,



                'tipo'=>

                    $widget['tipo']
                    ??
                    'card',



                'titulo'=>

                    $widget['titulo']
                    ??
                    '',



                'icono'=>

                    $widget['icono']
                    ??
                    null,



                'contenido'=>

                    $widget['contenido']
                    ??
                    [],



                'acciones'=>

                    $widget['acciones']
                    ??
                    []



            ];


        }



        return $resultado;


    }









    /**
     * Procesar gráficos
     */
    private function charts(
        mixed $items
    ):array
    {


        if(!is_array($items))
        {
            return [];
        }



        $resultado=[];



        foreach($items as $chart)
        {


            if(!is_array($chart))
            {
                continue;
            }



            $resultado[]=[



                'nombre'=>

                    $chart['nombre']
                    ??
                    null,



                'titulo'=>

                    $chart['titulo']
                    ??
                    'Gráfico',



                'tipo'=>

                    $chart['tipo']
                    ??
                    'bar',



                'datos'=>

                    $chart['datos']
                    ??
                    []



            ];


        }



        return $resultado;


    }









    /**
     * Procesar tablas
     */
    private function tables(
        mixed $items
    ):array
    {


        if(!is_array($items))
        {
            return [];
        }



        $resultado=[];



        foreach($items as $table)
        {


            if(!is_array($table))
            {
                continue;
            }



            $resultado[]=[


                'titulo'=>

                    $table['titulo']
                    ??
                    '',



                'columnas'=>

                    $table['columnas']
                    ??
                    [],



                'filas'=>

                    $table['filas']
                    ??
                    []


            ];


        }



        return $resultado;


    }









    /**
     * Procesar alertas
     */
    private function alerts(
        mixed $items
    ):array
    {


        if(!is_array($items))
        {
            return [];
        }



        $resultado=[];



        foreach($items as $alert)
        {


            if(!is_array($alert))
            {
                continue;
            }



            $resultado[]=[


                'tipo'=>

                    $alert['tipo']
                    ??
                    'info',



                'mensaje'=>

                    $alert['mensaje']
                    ??
                    ''



            ];

        }



        return $resultado;


    }



}