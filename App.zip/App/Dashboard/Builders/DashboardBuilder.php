<?php

declare(strict_types=1);

namespace App\Dashboard\Builders;

use App\Services\Statistics\StatisticsService;
use RuntimeException;
use Throwable;


/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| DASHBOARD BUILDER V6
|--------------------------------------------------------------------------
|
| Constructor general Dashboard ERP
|
| Genera:
| - KPIs
| - Estadísticas
| - Alertas
| - Documentos
| - Widgets
|
|--------------------------------------------------------------------------
*/


final class DashboardBuilder
{


    public function __construct(
        private readonly StatisticsService $statistics
    ) {
    }





    /**
     * Dashboard general ERP
     */
    public function general(
        int $id = 0
    ): array
    {

        try {


            return [

                'kpis' =>
                    $this->kpis(),


                'estadisticas' =>
                    $this->estadisticas(),


                'alertas' =>
                    $this->alertas(),


                'documentos' =>
                    $this->documentos(),


                'widgets' =>
                    $this->widgets(),


                'generado' =>
                    date('Y-m-d H:i:s')

            ];


        }
        catch(Throwable $e)
        {

            throw new RuntimeException(

                'Error generando Dashboard general: '
                .
                $e->getMessage(),

                0,

                $e

            );

        }

    }









    /*
    |--------------------------------------------------------------------------
    | KPIS PRINCIPALES
    |--------------------------------------------------------------------------
    */


    private function kpis(): array
    {

        return [

            [
                'titulo'=>'Clientes',
                'valor'=>$this->safeStatistic('clientes'),
                'icono'=>'fa-users'
            ],


            [
                'titulo'=>'Equipos',
                'valor'=>$this->safeStatistic('equipos'),
                'icono'=>'fa-print'
            ],


            [
                'titulo'=>'Servicios',
                'valor'=>$this->safeStatistic('servicios'),
                'icono'=>'fa-screwdriver-wrench'
            ],


            [
                'titulo'=>'Ventas',
                'valor'=>$this->safeStatistic('ventas'),
                'icono'=>'fa-cart-shopping'
            ],


            [
                'titulo'=>'Contadores pendientes',
                'valor'=>$this->safeStatistic(
                    'contadores_pendientes'
                ),
                'icono'=>'fa-calculator'
            ]

        ];

    }









    /*
    |--------------------------------------------------------------------------
    | ESTADISTICAS
    |--------------------------------------------------------------------------
    */


    private function estadisticas(): array
    {

        try {


            if(
                !method_exists(
                    $this->statistics,
                    'dashboard'
                )
            ){

                return [];

            }



            return $this->statistics->dashboard();


        }
        catch(Throwable)
        {

            return [];

        }


    }









    /*
    |--------------------------------------------------------------------------
    | ALERTAS ERP
    |--------------------------------------------------------------------------
    */


    private function alertas(): array
    {

        return [

            [

                'tipo'=>'info',

                'titulo'=>'Sistema',

                'mensaje'=>
                    'Dashboard actualizado correctamente'

            ]

        ];

    }









    /*
    |--------------------------------------------------------------------------
    | DOCUMENTOS
    |--------------------------------------------------------------------------
    */


    private function documentos(): array
    {

        return [

            'pendientes'=>[


                /*
                Ejemplo futuro:

                [
                    'tipo'=>'Servicio',
                    'titulo'=>'Orden técnica pendiente',
                    'estado'=>'Pendiente'
                ]

                */


            ],



            'recientes'=>[


                /*
                Ejemplo futuro:

                [
                    'tipo'=>'Informe',
                    'titulo'=>'Informe técnico',
                    'fecha'=>'2026-07-29'
                ]

                */


            ]

        ];

    }









    /*
    |--------------------------------------------------------------------------
    | WIDGETS
    |--------------------------------------------------------------------------
    */


    private function widgets(): array
    {

        return [

            [

                'nombre'=>'contadores',

                'titulo'=>'Últimos Contadores'

            ],



            [

                'nombre'=>'servicios',

                'titulo'=>'Servicios Técnicos'

            ],



            [

                'nombre'=>'ventas',

                'titulo'=>'Ventas'

            ]

        ];

    }









    /*
    |--------------------------------------------------------------------------
    | SAFE STATISTIC
    |--------------------------------------------------------------------------
    */


    private function safeStatistic(
        string $method
    ): int|float
    {

        try {


            if(
                !method_exists(
                    $this->statistics,
                    $method
                )
            ){

                return 0;

            }



            return $this->statistics->{$method}();


        }
        catch(Throwable)
        {

            return 0;

        }

    }



}