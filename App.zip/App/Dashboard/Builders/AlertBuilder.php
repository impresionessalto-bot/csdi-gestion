<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class AlertBuilder
{


    private array $alerts=[];




    public function add(
        string $type,
        string $message
    ):self
    {


        $this->alerts[]=[


            'type'=>$type,


            'message'=>$message


        ];


        return $this;

    }






    public function all():array
    {

        return $this->alerts;

    }



}<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class AlertBuilder
{


    private array $alerts=[];




    public function add(
        string $type,
        string $message
    ):self
    {


        $this->alerts[]=[


            'type'=>$type,


            'message'=>$message


        ];


        return $this;

    }






    public function all():array
    {

        return $this->alerts;

    }



}