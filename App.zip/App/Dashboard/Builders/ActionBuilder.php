<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class ActionBuilder
{


    private array $actions=[];




    public function add(
        string $title,
        string $url,
        string $icon='fa-link'
    ):self
    {


        $this->actions[]=[


            'title'=>$title,


            'url'=>$url,


            'icon'=>$icon


        ];



        return $this;

    }







    public function all():array
    {

        return $this->actions;

    }



}