<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class ChartBuilder
{


    private array $charts=[];




    public function add(
        string $type,
        string $title,
        array $data
    ):self
    {


        $this->charts[]=[


            'type'=>$type,


            'title'=>$title,


            'data'=>$data


        ];



        return $this;

    }






    public function all():array
    {

        return $this->charts;

    }



}