<?php

declare(strict_types=1);

namespace App\Dashboard\Builder;


final class CardBuilder
{


    private array $cards=[];




    public function add(
        string $title,
        mixed $value,
        string $icon='fa-chart-line',
        string $color='primary',
        ?string $route=null
    ):self
    {


        $this->cards[]=[


            'title'=>$title,


            'value'=>$value,


            'icon'=>$icon,


            'color'=>$color,


            'route'=>$route


        ];



        return $this;

    }







    public function all():array
    {

        return $this->cards;

    }



}