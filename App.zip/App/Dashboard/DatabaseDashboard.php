<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Modules\Database\Services\Service as DatabaseService;
use Throwable;


final class DatabaseDashboard extends BaseDashboard
{


    public function __construct(

        private readonly DatabaseService $database

    ) {

    }







    /**
     * =====================================================
     * DASHBOARD DATABASE
     * =====================================================
     */
    public function obtener(
        int $id = 0
    ): array
    {


        try {


            $tablas = [];



            try {


                $tablas =
                    $this->database
                    ->listarTablas();



                if(!is_array($tablas)){


                    $tablas=[];


                }



            }
            catch(Throwable)
            {

                $tablas=[];

            }







            return $this->build([






                'general'=>[


                    'titulo'=>'Base de Datos',


                    'id'=>$id,


                ],







                'tecnico'=>[],


                'comercial'=>[],


                'financiero'=>[],







                'kpis'=>[


                    'tablas'=>
                        count($tablas),


                ],







                'estadisticas'=>[


                    'tablas'=>$tablas,


                ],







                'timeline'=>[],


                'alertas'=>[],


                'documentos'=>[],


                'imagenes'=>[],







                'widgets'=>[


                    'tablas'=>$tablas,


                    'motor'=>'mysql',


                ],







                'acciones'=>[


                    [


                        'titulo'=>'Explorar tablas',


                        'url'=>'/admin/database',


                        'icono'=>
                            'fa-solid fa-database'


                    ],


                    [


                        'titulo'=>'Optimizar base',


                        'url'=>'/admin/database/optimize',


                        'icono'=>
                            'fa-solid fa-gauge-high'


                    ]


                ],







                'ia'=>[


                    'resumen'=>null,


                    'analisis'=>[],


                    'recomendaciones'=>[],


                ]







            ]);




        }
        catch(Throwable $e)
        {


            return $this->build([



                'alertas'=>[


                    [


                        'tipo'=>'danger',


                        'mensaje'=>

                            'Error cargando dashboard database: '
                            .
                            $e->getMessage()



                    ]


                ]



            ]);



        }



    }




}