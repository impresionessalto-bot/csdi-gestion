<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Modules\Tecnicos\Services\Service as TecnicoService;
use App\Services\Timeline\TimelineService;
use App\Services\Statistics\StatisticsService;
use App\Services\Alert\AlertService;
use App\Services\Document\DocumentService;
use App\Services\IaService;
use Throwable;


final class TecnicoDashboard extends BaseDashboard
{


    public function __construct(

        private readonly TecnicoService $tecnicoService,

        private readonly TimelineService $timeline,

        private readonly StatisticsService $statistics,

        private readonly AlertService $alerts,

        private readonly DocumentService $documents,

        private readonly IaService $ia

    ){

    }









    public function obtener(
        int $id = 0
    ):array
    {


        if($id <= 0)
        {

            return $this->build([

                'general'=>[

                    'error'=>'Técnico no especificado'

                ]

            ]);

        }






        try {

            $tecnico =
                $this->tecnicoService->find($id);


        }
        catch(Throwable)
        {

            $tecnico=null;

        }






        if(!$tecnico)
        {

            return $this->build([

                'general'=>[

                    'error'=>'Técnico no encontrado'

                ]

            ]);

        }








        return $this->build([




            /*
            |--------------------------------------------------------------------------
            | GENERAL
            |--------------------------------------------------------------------------
            */


            'general'=>[


                'tecnico'=>$tecnico,


                'agenda'=>[],


                'zona'=>[],


                'vehiculo'=>[],


                'estado'=>
                    $tecnico['estado'] ?? null,


            ],






            /*
            |--------------------------------------------------------------------------
            | INFORMACIÓN TÉCNICA
            |--------------------------------------------------------------------------
            */


            'tecnico'=>[


                'servicios_asignados'=>[],


                'servicios_finalizados'=>[],


                'equipos_atendidos'=>[],


                'preventivos'=>[],


                'correctivos'=>[],


                'repuestos_utilizados'=>[],


                'herramientas'=>[],


            ],







            /*
            |--------------------------------------------------------------------------
            | COMERCIAL
            |--------------------------------------------------------------------------
            */


            'comercial'=>[


                'clientes'=>[],


                'zonas'=>[],


                'visitas'=>[],


            ],







            /*
            |--------------------------------------------------------------------------
            | FINANCIERO
            |--------------------------------------------------------------------------
            */


            'financiero'=>[


                'horas_trabajadas'=>0,


                'viaticos'=>[],


                'combustible'=>[],


                'costos'=>[],


            ],







            /*
            |--------------------------------------------------------------------------
            | KPIs
            |--------------------------------------------------------------------------
            */


            'kpis'=>[


                'servicios_mes'=>0,


                'tiempo_promedio'=>0,


                'eficiencia'=>0,


                'primera_visita_ok'=>0,


                'reincidencias'=>0,


                'satisfaccion'=>0,


            ],







            /*
            |--------------------------------------------------------------------------
            | ESTADÍSTICAS
            |--------------------------------------------------------------------------
            */


            'estadisticas'=>

                $this->safeCall(

                    fn() =>
                        $this->statistics->tecnico($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | TIMELINE
            |--------------------------------------------------------------------------
            */


            'timeline'=>

                $this->safeCall(

                    fn() =>
                        $this->timeline->tecnico($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | ALERTAS
            |--------------------------------------------------------------------------
            */


            'alertas'=>

                $this->safeCall(

                    fn() =>
                        $this->alerts->tecnico($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | DOCUMENTOS
            |--------------------------------------------------------------------------
            */


            'documentos'=>

                $this->safeCall(

                    fn() =>
                        $this->documents->tecnico($id)

                ),







            /*
            |--------------------------------------------------------------------------
            | IMÁGENES
            |--------------------------------------------------------------------------
            */


            'imagenes'=>[


                'perfil'=>
                    $tecnico['foto'] ?? null,


                'trabajos'=>[],


            ],







            /*
            |--------------------------------------------------------------------------
            | WIDGETS
            |--------------------------------------------------------------------------
            */


            'widgets'=>[


                'agenda'=>[],


                'mapa'=>[],


                'productividad'=>[],


                'servicios'=>[],


                'horas'=>[],


            ],







            /*
            |--------------------------------------------------------------------------
            | ACCIONES
            |--------------------------------------------------------------------------
            */


            'acciones'=>[


                'nuevo_servicio',


                'ver_agenda',


                'registrar_visita',


                'subir_foto',


                'subir_documento',


                'registrar_gasto',


                'registrar_km',


            ],







            /*
            |--------------------------------------------------------------------------
            | IA
            |--------------------------------------------------------------------------
            */


            'ia'=>[


                'resumen'=>null,


                'productividad'=>[],


                'recomendaciones'=>[],


                'capacitacion'=>[],


            ]




        ]);

    }








    private function safeCall(
        callable $callback
    ):array
    {


        try {


            $data =
                $callback();


            return is_array($data)
                ? $data
                : [];


        }
        catch(Throwable)
        {

            return [];

        }


    }




}