<?php

declare(strict_types=1);

namespace App\Dashboard;


/**
 * =========================================================
 * ERP CSDI PRO
 *
 * CONTRATO DE DASHBOARD
 *
 * =========================================================
 */

interface DashboardInterface
{

    /**
     * Construye el dashboard
     */
    public function obtener(
        int $id
    ): array;

}