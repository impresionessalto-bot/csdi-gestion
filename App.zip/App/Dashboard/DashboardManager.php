<?php

declare(strict_types=1);

namespace App\Dashboard;

use App\Core\Container;
use RuntimeException;
use Throwable;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * DASHBOARD MANAGER V3
 *
 * Administrador central de dashboards ERP
 * =========================================================
 */

final class DashboardManager
{
    /**
     * @var array<string,string>
     */
    private array $dashboards = [];

    /**
     * @var array<string,DashboardInterface>
     */
    private array $instances = [];

    public function __construct(
        private readonly Container $container
    ) {
        $this->registerDefaults();
    }

    /**
     * Dashboards oficiales ERP
     */
    private function registerDefaults(): void
    {
        $defaults = [
            /*
            |--------------------------------------------------------------------------
            | PRINCIPALES
            |--------------------------------------------------------------------------
            */
            'general' => GeneralDashboard::class,
            'cliente' => ClienteDashboard::class,
            'equipo' => EquipoDashboard::class,
            'tecnico' => TecnicoDashboard::class,

            /*
            |--------------------------------------------------------------------------
            | NEGOCIO
            |--------------------------------------------------------------------------
            */
            'contrato' => ContratoDashboard::class,
            'inventario' => InventarioDashboard::class,

            /*
            |--------------------------------------------------------------------------
            | PORTALES
            |--------------------------------------------------------------------------
            */
            'portal_cliente' => PortalClienteDashboard::class,

            /*
            |--------------------------------------------------------------------------
            | ADMIN
            |--------------------------------------------------------------------------
            */
            'database' => DatabaseDashboard::class,
            'informes' => InformesDashboard::class,
        ];

        foreach ($defaults as $nombre => $class) {
            try {
                if (class_exists($class)) {
                    $this->register($nombre, $class);
                }
            } catch (Throwable $e) {
                throw new RuntimeException(
                    "Error registrando Dashboard {$nombre}: " . $e->getMessage()
                );
            }
        }
    }

    /**
     * Registrar dashboard
     */
    public function register(
        string $nombre,
        string $class
    ): void {
        if (!class_exists($class)) {
            throw new RuntimeException(
                "Dashboard inexistente: {$class}"
            );
        }

        if (!is_subclass_of($class, BaseDashboard::class)) {
            throw new RuntimeException(
                "Dashboard inválido: {$class}"
            );
        }

        $this->dashboards[$nombre] = $class;
    }

    /**
     * Obtener datos dashboard
     */
    public function obtener(
        string $nombre,
        int $id = 0
    ): array {
        return $this
            ->instancia($nombre)
            ->obtener($id);
    }

    /**
     * Crear instancia
     */
    public function instancia(
        string $nombre
    ): DashboardInterface {
        if (!$this->existe($nombre)) {
            throw new RuntimeException(
                "Dashboard no registrado: {$nombre}"
            );
        }

        if (isset($this->instances[$nombre])) {
            return $this->instances[$nombre];
        }

        try {
            $class = $this->dashboards[$nombre];

            $dashboard = $this->container->make($class);

            if (!$dashboard instanceof DashboardInterface) {
                throw new RuntimeException(
                    "No implementa DashboardInterface: " . $class
                );
            }

            $this->instances[$nombre] = $dashboard;

            return $dashboard;
        } catch (Throwable $e) {
            throw new RuntimeException(
                "Error cargando Dashboard {$nombre}: " . $e->getMessage()
            );
        }
    }

    /**
     * Existe dashboard
     */
    public function existe(
        string $nombre
    ): bool {
        return isset(
            $this->dashboards[$nombre]
        );
    }

    /**
     * Lista dashboards
     */
    public function disponibles(): array
    {
        return array_keys(
            $this->dashboards
        );
    }

    /**
     * Eliminar dashboard
     */
    public function remove(
        string $nombre
    ): void {
        unset(
            $this->dashboards[$nombre],
            $this->instances[$nombre]
        );
    }

    /**
     * Reiniciar manager
     */
    public function reset(): void
    {
        $this->dashboards = [];
        $this->instances = [];
        $this->registerDefaults();
    }

    /**
     * Debug ERP
     */
    public function debug(): array
    {
        return [
            'dashboards' => $this->dashboards,
            'instancias' => array_keys(
                $this->instances
            )
        ];
    }
}