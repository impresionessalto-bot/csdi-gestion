<?php

declare(strict_types=1);

namespace App\Core;

final class Middleware
{
    public static function handle(array $middlewares): void
    {
        /**
         * =========================================================
         * SESSION SAFE START
         * =========================================================
         */
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        foreach ($middlewares as $middleware) {

            switch ($middleware) {

                /**
                 * =====================================================
                 * AUTH
                 * =====================================================
                 */
                case 'auth':

                    if (empty($_SESSION['usuario_id'])) {
                        self::redirectToLogin();
                    }

                break;

                /**
                 * =====================================================
                 * ADMIN
                 * =====================================================
                 */
                case 'admin':

                    if (empty($_SESSION['usuario_id'])) {
                        self::redirectToLogin();
                    }

                    $role = $_SESSION['usuario_rol'] ?? null;

                    if ($role !== 'admin') {
                        http_response_code(403);
                        exit('Acceso denegado');
                    }

                break;

                /**
                 * =====================================================
                 * API (RESERVADO)
                 * =====================================================
                 */
                case 'api':
                    // futuro: JWT / token validation
                break;

                /**
                 * =====================================================
                 * CSRF (RESERVADO)
                 * =====================================================
                 */
                case 'csrf':
                    // futuro: validación central CSRF
                break;
            }
        }
    }

    /**
     * =========================================================
     * REDIRECT CENTRALIZADO
     * =========================================================
     */
    private static function redirectToLogin(): void
    {
        if (!headers_sent()) {
            header('Location: /login');
        }
        exit;
    }
}