<?php

namespace App\Core;

final class UIEngine
{
    public static array $state = [
        'view' => null,
        'header' => false,
        'footer' => false,
        'assets' => [
            'bootstrap' => false,
            'icons' => false,
            'css' => false,
        ],
        'errors' => []
    ];

    public static function init(string $view): void
    {
        self::$state['view'] = $view;
    }

    public static function mark(string $key): void
    {
        self::$state[$key] = true;
    }

    public static function asset(string $key): void
    {
        self::$state['assets'][$key] = true;
    }

    public static function error(string $msg): void
    {
        self::$state['errors'][] = $msg;
    }

    public static function renderDebug(): void
    {
        if (!isset($_GET['ui_debug'])) return;

        echo "<div style='position:fixed;bottom:0;right:0;background:#0b1220;color:#00ff88;
        padding:12px;font-size:12px;z-index:999999;font-family:monospace;max-width:320px'>";

        echo "<b>UI ENGINE CSDI PRO</b><br><br>";

        foreach (self::$state as $k => $v) {

            if (is_array($v)) {
                echo "<u>$k</u><br>";
                foreach ($v as $k2 => $v2) {
                    $icon = $v2 ? "✔" : "❌";
                    echo "$icon $k2<br>";
                }
                continue;
            }

            $icon = $v ? "✔" : "❌";
            echo "$icon $k<br>";
        }

        if (!empty(self::$state['errors'])) {
            echo "<hr>ERRORS:<br>";
            foreach (self::$state['errors'] as $e) {
                echo "❌ $e<br>";
            }
        }

        echo "</div>";
    }
}