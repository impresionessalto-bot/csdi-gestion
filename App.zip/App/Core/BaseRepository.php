<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOStatement;
use RuntimeException;


abstract class BaseRepository
{


    protected PDO $db;


    protected string $table;


    protected string $primaryKey='id';





    public function __construct(PDO $db)
    {

        $this->db=$db;


        if(empty($this->table)){

            throw new RuntimeException(
                static::class.' no definió $table'
            );

        }

    }





    protected function query(
        string $sql,
        array $params=[]
    ): PDOStatement
    {

        $stmt =
            $this->db->prepare($sql);


        $stmt->execute(
            $params
        );


        return $stmt;

    }





    public function getAll(): array
    {

        return $this->query(
            "
            SELECT *
            FROM {$this->table}
            WHERE deleted_at IS NULL
            ORDER BY {$this->primaryKey} DESC
            "
        )
        ->fetchAll(PDO::FETCH_ASSOC);

    }





    public function find(
        int $id
    ): ?array
    {

        $row =
            $this->query(
                "
                SELECT *
                FROM {$this->table}
                WHERE {$this->primaryKey}=?
                AND deleted_at IS NULL
                LIMIT 1
                ",
                [
                    $id
                ]
            )
            ->fetch(PDO::FETCH_ASSOC);


        return $row ?: null;

    }





    public function create(
        array $data
    ): int
    {

        $fields =
            array_keys($data);


        $sql="
        INSERT INTO {$this->table}
        (".implode(',',$fields).")
        VALUES
        (".implode(
            ',',
            array_fill(
                0,
                count($fields),
                '?'
            )
        ).")
        ";


        $this->query(
            $sql,
            array_values($data)
        );


        return (int)
            $this->db->lastInsertId();

    }





    public function update(
        int $id,
        array $data
    ): bool
    {

        $sets=[];


        foreach(
            array_keys($data)
            as $field
        ){

            $sets[] =
                "{$field}=?";

        }


        $sql="
        UPDATE {$this->table}
        SET ".implode(',',$sets)."
        WHERE {$this->primaryKey}=?
        ";


        $params =
            array_values($data);


        $params[]=$id;


        return $this->query(
            $sql,
            $params
        )
        ->rowCount()>0;

    }





    public function delete(
        int $id
    ): bool
    {

        return $this->query(
            "
            UPDATE {$this->table}
            SET deleted_at=NOW()
            WHERE {$this->primaryKey}=?
            ",
            [
                $id
            ]
        )
        ->rowCount()>0;

    }





    public function count(): int
    {

        return (int)$this->query(
            "
            SELECT COUNT(*)
            FROM {$this->table}
            WHERE deleted_at IS NULL
            "
        )
        ->fetchColumn();

    }





    public function exists(
        int $id
    ): bool
    {

        return $this->find($id)!==null;

    }





    public function where(
        array $conditions
    ): array
    {

        $sql="
        SELECT *
        FROM {$this->table}
        WHERE deleted_at IS NULL
        ";


        $params=[];


        foreach($conditions as $field=>$value){

            $sql.=" AND {$field}=?";

            $params[]=$value;

        }


        return $this->query(
            $sql,
            $params
        )
        ->fetchAll(PDO::FETCH_ASSOC);

    }





    public function paginate(
        int $page,
        int $limit
    ): array
    {

        $offset =
            ($page-1)*$limit;


        return $this->query(
            "
            SELECT *
            FROM {$this->table}
            WHERE deleted_at IS NULL
            LIMIT {$limit}
            OFFSET {$offset}
            "
        )
        ->fetchAll(PDO::FETCH_ASSOC);

    }





    protected function lastInsertId(): int
    {

        return (int)
            $this->db->lastInsertId();

    }


}