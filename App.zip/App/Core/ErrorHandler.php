<?php

declare(strict_types=1);

namespace App\Core;

use Throwable;

/**
 * ERP ErrorHandler centralizado
 * Compatible PHP 8.3
 */
final class ErrorHandler
{
    private static bool $debug = true;
    private static string $logFile = BASE_PATH . '/storage/logs/erp.log';

    /**
     * Inicializa manejadores globales
     */
    public static function register(bool $debug = true): void
    {
        self::$debug = $debug;

        set_error_handler([self::class, 'handleError']);
        set_exception_handler([self::class, 'handleException']);
        register_shutdown_function([self::class, 'handleShutdown']);
    }

    /**
     * Manejo de errores PHP clásicos
     */
    public static function handleError(
        int $severity,
        string $message,
        string $file,
        int $line
    ): bool {
        if (!(error_reporting() & $severity)) {
            return false;
        }

        $error = "[ERROR] $message in $file:$line";

        self::log($error);

        if (self::$debug) {
            self::renderHtmlError($error);
        }

        return true;
    }

    /**
     * Manejo de excepciones
     */
    public static function handleException(Throwable $e): void
    {
        $error = "[EXCEPTION] " . $e->getMessage()
            . " in " . $e->getFile()
            . ":" . $e->getLine()
            . "\n" . $e->getTraceAsString();

        self::log($error);

        if (self::$debug) {
            self::renderHtmlError($error);
        } else {
            self::renderGenericError();
        }

        exit;
    }

    /**
     * Captura errores fatales (shutdown)
     */
    public static function handleShutdown(): void
    {
        $error = error_get_last();

        if ($error !== null) {

            $message = "[FATAL] {$error['message']} in {$error['file']}:{$error['line']}";

            self::log($message);

            if (self::$debug) {
                self::renderHtmlError($message);
            }
        }
    }

    /**
     * Log a archivo
     */
    private static function log(string $message): void
    {
        $date = date('Y-m-d H:i:s');

        $dir = dirname(self::$logFile);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        file_put_contents(
            self::$logFile,
            "[$date] $message\n",
            FILE_APPEND
        );
    }

    /**
     * Render error en modo desarrollo
     */
    private static function renderHtmlError(string $message): void
    {
        http_response_code(500);

        echo "<div style='
            background:#111;
            color:#ff4d4d;
            padding:20px;
            font-family:monospace;
        '>";

        echo "<h2>❌ ERP ERROR</h2>";
        echo "<pre>" . htmlspecialchars($message) . "</pre>";

        echo "</div>";
    }

    /**
     * Error genérico en producción
     */
    private static function renderGenericError(): void
    {
        http_response_code(500);

        echo "<h1>❌ Error interno del sistema</h1>";
    }
}