<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;


/**
 * =========================================================
 * ERP CSDI PRO
 *
 * MODULE MANAGER V10
 *
 * Administrador central de módulos ERP
 *
 * =========================================================
 */

final class ModuleManager
{


    /**
     * @var array<string,Module>
     */
    private array $modules = [];



    private bool $loaded = false;






    public function __construct()
    {

        $this->load();

    }






    /**
     * Cargar módulos
     */
    private function load():void
    {

        if($this->loaded){

            return;

        }


        ModuleLoader::load();


        $this->modules =
            ModuleLoader::modules();


        $this->loaded=true;

    }






    /**
     * Todos los módulos
     */
    public function all():array
    {

        return $this->modules;

    }






    /**
     * Cantidad
     */
    public function count():int
    {

        return count(
            $this->modules
        );

    }






    /**
     * Nombres
     */
    public function names():array
    {

        return array_keys(
            $this->modules
        );

    }






    /**
     * Existe módulo
     */
    public function has(
        string $name
    ):bool
    {

        return isset(
            $this->modules[$name]
        );

    }






    /**
     * Obtener módulo
     */
    public function get(
        string $name
    ):?Module
    {

        return $this->modules[$name] ?? null;

    }






    /**
     * Información módulo
     */
    public function info(
        string $name
    ):array
    {

        $module =
            $this->get($name);



        if(!$module){


            throw new RuntimeException(

                "Módulo '{$name}' inexistente"

            );

        }



        return $module->info();

    }






    /**
     * Módulos activos
     */
    public function enabled():array
    {

        return array_filter(

            $this->modules,

            fn(Module $module)=>
                $module->enabled()

        );

    }






    /**
     * Menú ERP
     */
    public function menu():array
    {

        return ModuleLoader::menu();

    }






    /**
     * Permisos globales
     */
    public function permissions():array
    {

        return ModuleLoader::permissions();

    }






    /**
     * Buscar módulos por permiso
     */
    public function findByPermission(
        string $permission
    ):array
    {

        $result=[];


        foreach($this->modules as $module){


            if(
                in_array(

                    $permission,

                    $module->permissions(),

                    true

                )
            ){

                $result[]=$module;

            }


        }


        return $result;

    }






    /**
     * Dependencias
     */
    public function dependencies(
        string $module
    ):array
    {

        $instance =
            $this->get($module);



        if(!$instance){

            throw new RuntimeException(

                "Módulo '{$module}' inexistente"

            );

        }



        return $instance->dependencies();

    }






    /**
     * Verificar dependencias
     */
    public function checkDependencies(
        string $module
    ):bool
    {

        foreach(
            $this->dependencies($module)
            as $dependency
        ){


            if(!$this->has($dependency)){


                throw new RuntimeException(

                    "El módulo {$module} requiere {$dependency}"

                );

            }


        }


        return true;

    }






    /**
     * Ejecutar método del módulo
     */
    public function call(
        string $module,
        string $method,
        mixed ...$args
    ):mixed
    {

        $instance =
            $this->get($module);



        if(!$instance){

            throw new RuntimeException(

                "Módulo '{$module}' inexistente"

            );

        }



        if(!method_exists($instance,$method)){


            throw new RuntimeException(

                "Método {$method} no existe en {$module}"

            );

        }



        return $instance->{$method}(...$args);

    }






    /**
     * Recargar módulos
     */
    public function reload():void
    {

        ModuleLoader::reset();


        $this->loaded=false;


        $this->load();


    }






    /**
     * Limpiar
     */
    public function reset():void
    {

        $this->modules=[];


        $this->loaded=false;


        ModuleLoader::reset();

    }






}