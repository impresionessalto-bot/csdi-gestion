$dispatcher->listen(
    \App\Events\CounterUpdatedEvent::class,
    new \App\Listeners\CounterAuditListener($repo)
);

$dispatcher->listen(
    \App\Events\CounterUpdatedEvent::class,
    new \App\Listeners\CounterVersionListener($repo)
);