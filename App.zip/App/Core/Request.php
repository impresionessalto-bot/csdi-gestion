<?php

declare(strict_types=1);

namespace App\Core;

final class Request
{
    private array $get;
    private array $post;
    private array $headers;
    private array $body;

    public function __construct()
    {
        $this->get     = $_GET ?? [];
        $this->post    = $_POST ?? [];
        $this->headers = $this->loadHeaders();
        $this->body    = $this->loadJsonBody();
    }

    /* =========================================================
       METHOD
    ========================================================= */

    public function method(): string
    {
        return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    }

    public function isGet(): bool
    {
        return $this->method() === 'GET';
    }

    public function isPost(): bool
    {
        return $this->method() === 'POST';
    }

    public function isAjax(): bool
    {
        return (
            ($this->headers['X-Requested-With'] ?? '') === 'XMLHttpRequest'
        );
    }

    /* =========================================================
       INPUT (UNIFIED ACCESS)
    ========================================================= */

    public function input(string $key, mixed $default = null): mixed
    {
        return $this->post[$key]
            ?? $this->get[$key]
            ?? $this->body[$key]
            ?? $default;
    }

    public function all(): array
    {
        return array_merge(
            $this->get,
            $this->post,
            $this->body
        );
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->get[$key] ?? $default;
    }

    public function post(string $key, mixed $default = null): mixed
    {
        return $this->post[$key] ?? $default;
    }

    public function body(string $key = null): mixed
    {
        if ($key === null) {
            return $this->body;
        }

        return $this->body[$key] ?? null;
    }

    /* =========================================================
       JSON BODY (API)
    ========================================================= */

    private function loadJsonBody(): array
    {
        $raw = file_get_contents('php://input');

        if (!$raw) {
            return [];
        }

        $decoded = json_decode($raw, true);

        return is_array($decoded)
            ? $decoded
            : [];
    }

    /* =========================================================
       HEADERS
    ========================================================= */

    private function loadHeaders(): array
    {
        $headers = [];

        foreach ($_SERVER as $key => $value) {

            if (str_starts_with($key, 'HTTP_')) {

                $name = str_replace(
                    ' ',
                    '-',
                    ucwords(
                        strtolower(
                            str_replace('_', ' ', substr($key, 5))
                        )
                    )
                );

                $headers[$name] = $value;
            }
        }

        return $headers;
    }

    public function header(string $key, mixed $default = null): mixed
    {
        return $this->headers[$key] ?? $default;
    }

    /* =========================================================
       CSRF
    ========================================================= */

    public function csrf(): ?string
    {
        return $this->input('csrf')
            ?? $this->input('csrf_token');
    }

    /* =========================================================
       HELPERS
    ========================================================= */

    public function int(string $key, int $default = 0): int
    {
        return (int)($this->input($key, $default));
    }

    public function string(string $key, string $default = ''): string
    {
        return (string)($this->input($key, $default));
    }

    public function bool(string $key, bool $default = false): bool
    {
        return filter_var(
            $this->input($key, $default),
            FILTER_VALIDATE_BOOLEAN
        );
    }

    public function has(string $key): bool
    {
        return $this->input($key, null) !== null;
    }

    public function only(array $keys): array
    {
        $data = [];

        foreach ($keys as $key) {
            $data[$key] = $this->input($key);
        }

        return $data;
    }

    /* =========================================================
       DEBUG
    ========================================================= */

    public function dump(): array
    {
        return [
            'method' => $this->method(),
            'get' => $this->get,
            'post' => $this->post,
            'body' => $this->body,
            'headers' => $this->headers,
        ];
    }
}