<?php
namespace App\Core;

final class ExportHelper
{
    public static function toCsv(array $data, string $filename): void
    {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="'.$filename.'.csv"');
        $output = fopen('php://output', 'w');
        fputcsv($output, array_keys($data[0])); // Cabeceras
        foreach ($data as $row) fputcsv($output, $row);
        fclose($output);
        exit;
    }
}