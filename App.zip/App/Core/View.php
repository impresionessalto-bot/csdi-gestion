<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;


final class View
{


    private static string $basePath =
        BASE_PATH . '/App/Views/';



    private static array $aliases = [

        'equipment.' => 'equipos.',
        'equipment'  => 'equipos',

        'client.'    => 'clientes.',
        'client'     => 'clientes',

        'clients.'   => 'clientes.',
        'clients'    => 'clientes',

    ];






    public static function render(
        string $view,
        array $data = [],
        ?string $layout = 'layouts/app',
        ?string $module = null
    ):void
    {


        $view =
            self::normalize($view);




        $file =
            self::resolve(
                $view,
                $module
            );





        if(!$file)
        {

            self::error(
                $view,
                $module
            );

            return;

        }






        $data =
            array_merge(

                [

                    'titulo'=>'CSDI ERP',

                    'user'=>
                        $_SESSION['user']
                        ??
                        null,

                ],

                $data

            );







        extract(
            $data,
            EXTR_SKIP
        );







        ob_start();


        require $file;


        $content =
            ob_get_clean();








        /*
        |--------------------------------------------------------------------------
        | SIN LAYOUT
        |--------------------------------------------------------------------------
        */


        if($layout===null)
        {

            echo $content;

            return;

        }







        $layoutFile =
            self::resolveLayout(
                $layout
            );








        if(!$layoutFile)
        {

            throw new RuntimeException(
                'Layout no encontrado: '.$layout
            );

        }






        require $layoutFile;



    }









    private static function resolve(
        string $view,
        ?string $module=null
    ):?string
    {



        $path =
            str_replace(
                '.',
                '/',
                $view
            );








        /*
        |--------------------------------------------------------------------------
        | 1) VISTAS CENTRALES
        |--------------------------------------------------------------------------
        */


        $central =

            self::$basePath
            .
            $path
            .
            '.php';



        if(is_file($central))
        {

            return $central;

        }









        /*
        |--------------------------------------------------------------------------
        | 2) MODULO EXPLICITO
        |
        | Equipos/index
        |--------------------------------------------------------------------------
        */


        $parts =
            explode(
                '/',
                $path
            );



        if(count($parts)>=2)
        {


            $modulo =
                ucfirst(
                    $parts[0]
                );


            $vista =
                $parts[1];



            $moduleFile =

                BASE_PATH
                .
                "/App/Modules/{$modulo}/Views/{$vista}.php";



            if(is_file($moduleFile))
            {

                return $moduleFile;

            }


        }








        /*
        |--------------------------------------------------------------------------
        | 3) MODULO AUTOMATICO
        |
        | index
        |
        | Busca:
        |
        | App/Modules/Equipos/Views/index.php
        |--------------------------------------------------------------------------
        */


        if($module)
        {


            $moduleFile =

                BASE_PATH
                .
                "/App/Modules/{$module}/Views/{$path}.php";



            if(is_file($moduleFile))
            {

                return $moduleFile;

            }


        }








        return null;


    }









    private static function resolveLayout(
        string $layout
    ):?string
    {


        $layout =
            str_replace(
                '.',
                '/',
                trim($layout)
            );



        $file =

            self::$basePath
            .
            $layout
            .
            '.php';



        return is_file($file)
            ?
            $file
            :
            null;


    }









    private static function normalize(
        string $view
    ):string
    {


        $view =
            trim($view);




        $view =
            str_replace(

                [

                    '..',

                    '\\',

                    '//'

                ],

                '',

                $view

            );








        foreach(
            self::$aliases as $from=>$to
        )
        {


            if(
                str_starts_with(
                    $view,
                    $from
                )
            )
            {


                $view =
                    $to
                    .
                    substr(
                        $view,
                        strlen($from)
                    );


                break;

            }


        }






        return $view;


    }









    public static function exists(
        string $view,
        ?string $module=null
    ):bool
    {


        return
            self::resolve(
                self::normalize($view),
                $module
            )
            !==null;


    }









    private static function error(
        string $view,
        ?string $module=null
    ):void
    {


        http_response_code(500);



        echo "

        <div style='padding:25px;font-family:Arial'>

            <h2 style='color:#b30000'>
                ERP VIEW ERROR
            </h2>


            <p>
                <b>Vista:</b>
                "
                .
                htmlspecialchars($view)
                .
                "
            </p>



            <p>
                <b>Módulo:</b>
                "
                .
                htmlspecialchars(
                    $module ?? 'N/A'
                )
                .
                "
            </p>


        </div>

        ";



        error_log(
            '[ERP VIEW ERROR] '
            .
            $view
            .
            ' module='
            .
            ($module ?? 'null')
        );


    }



}