<?php

declare(strict_types=1);

namespace App\Core;

/**
 * =========================================================
 * CSDI ERP PRO
 * ASSET MANAGER V3
 * =========================================================
 */
final class AssetManager
{
    /**
     * @var array<string,bool>
     */
    private array $styles = [];

    /**
     * @var array<string,bool>
     */
    private array $scripts = [];

    public function addCss(string $file): self
    {
        $file = $this->normalize($file);

        if ($file === '') {
            return $this;
        }

        $this->styles[$file] = true;

        return $this;
    }

    public function addJs(string $file): self
    {
        $file = $this->normalize($file);

        if ($file === '') {
            return $this;
        }

        $this->scripts[$file] = true;

        return $this;
    }

    public function addCssMany(array $files): self
    {
        foreach ($files as $file) {
            if (is_string($file)) {
                $this->addCss($file);
            }
        }

        return $this;
    }

    public function addJsMany(array $files): self
    {
        foreach ($files as $file) {
            if (is_string($file)) {
                $this->addJs($file);
            }
        }

        return $this;
    }

    public function addModule(string $module): self
    {
        $module = strtolower(trim($module));

        if ($module === '') {
            return $this;
        }

        $css = "assets/css/{$module}.css";
        $js  = "assets/js/{$module}.js";

        if ($this->exists($css)) {
            $this->addCss($css);
        }

        if ($this->exists($js)) {
            $this->addJs($js);
        }

        return $this;
    }

    public function addModuleDirectory(string $module): self
    {
        $module = strtolower(trim($module));

        if ($module === '') {
            return $this;
        }

        $cssDir = BASE_PATH . '/assets/css/' . $module;

        if (is_dir($cssDir)) {

            $files = glob($cssDir . '/*.css');

            if (is_array($files)) {

                sort($files);

                foreach ($files as $file) {

                    if (!is_file($file)) {
                        continue;
                    }

                    $relative = $this->relativePath($file);

                    if ($relative !== null) {
                        $this->addCss($relative);
                    }
                }
            }
        }

        $jsDir = BASE_PATH . '/assets/js/' . $module;

        if (is_dir($jsDir)) {

            $files = glob($jsDir . '/*.js');

            if (is_array($files)) {

                sort($files);

                foreach ($files as $file) {

                    if (!is_file($file)) {
                        continue;
                    }

                    $relative = $this->relativePath($file);

                    if ($relative !== null) {
                        $this->addJs($relative);
                    }
                }
            }
        }

        return $this;
    }

    /**
     * @return string[]
     */
    public function css(): array
    {
        return array_keys($this->styles);
    }

    /**
     * @return string[]
     */
    public function js(): array
    {
        return array_keys($this->scripts);
    }

    public function hasCss(string $file): bool
    {
        return isset(
            $this->styles[
                $this->normalize($file)
            ]
        );
    }

    public function hasJs(string $file): bool
    {
        return isset(
            $this->scripts[
                $this->normalize($file)
            ]
        );
    }

    public function renderCss(): string
    {
        $html = '';

        foreach ($this->css() as $file) {

            $url = '/' . ltrim(
                $this->normalize($file),
                '/'
            );

            $html .= '<link rel="stylesheet" href="'
                . htmlspecialchars(
                    $url,
                    ENT_QUOTES,
                    'UTF-8'
                )
                . '">' . PHP_EOL;
        }

        return $html;
    }

    public function renderJs(): string
    {
        $html = '';

        foreach ($this->js() as $file) {

            $url = '/' . ltrim(
                $this->normalize($file),
                '/'
            );

            $html .= '<script src="'
                . htmlspecialchars(
                    $url,
                    ENT_QUOTES,
                    'UTF-8'
                )
                . '"></script>' . PHP_EOL;
        }

        return $html;
    }

    public function clear(): void
    {
        $this->styles = [];
        $this->scripts = [];
    }

    public function clearCss(): void
    {
        $this->styles = [];
    }

    public function clearJs(): void
    {
        $this->scripts = [];
    }

    private function normalize(string $file): string
    {
        $file = str_replace(
            '\\',
            '/',
            trim($file)
        );

        $file = ltrim($file, '/');

        $file = preg_replace(
            '#\.\.+/#',
            '',
            $file
        ) ?? '';

        return trim($file, '/');
    }

    private function exists(string $file): bool
    {
        if (
            !defined('BASE_PATH')
            || BASE_PATH === ''
        ) {
            return false;
        }

        return is_file(
            BASE_PATH
            . '/'
            . ltrim($file, '/')
        );
    }

    private function relativePath(
        string $absolutePath
    ): ?string {

        if (
            !defined('BASE_PATH')
            || BASE_PATH === ''
        ) {
            return null;
        }

        $base = rtrim(
            str_replace(
                '\\',
                '/',
                BASE_PATH
            ),
            '/'
        );

        $absolute = str_replace(
            '\\',
            '/',
            $absolutePath
        );

        if (
            !str_starts_with(
                $absolute,
                $base . '/'
            )
        ) {
            return null;
        }

        return ltrim(
            substr(
                $absolute,
                strlen($base)
            ),
            '/'
        );
    }
}