<?php

declare(strict_types=1);

namespace App\Core;

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| AUTOLOAD V9 BLINDADO (Ferozo & Linux Production Certified)
|--------------------------------------------------------------------------
|
| PSR simple ERP MVC con soporte estricto de minúsculas,
| resolución de enlaces físicos reales y prevención de doble declaración.
|
|--------------------------------------------------------------------------
*/

if (!defined('BASE_PATH')) {
    define(
        'BASE_PATH',
        dirname(__DIR__, 2)
    );
}

final class Autoload
{
    private static bool $registered = false;
    private static array $loaded = [];
    private static array $cache = [];

    public static function register(): void
    {
        if (self::$registered) {
            return;
        }

        self::$registered = true;

        spl_autoload_register(
            static function (string $class): void {
                self::load($class);
            }
        );
    }

    private static function load(string $class): void
    {
        if (!str_starts_with($class, 'App\\')) {
            return;
        }

        // MEJORA 1: Normalizamos el nombre de la clase a minúsculas
        // PHP no discrimina mayúsculas en la declaración de clases; prevenimos el doble registro en memoria.
        $classLower = strtolower($class);

        if (isset(self::$loaded[$classLower])) {
            return;
        }

        if (isset(self::$cache[$classLower])) {
            // MEJORA 2: Resolvemos el path real físico antes del require_once
            $realPath = realpath(self::$cache[$classLower]);
            if ($realPath !== false) {
                require_once $realPath;
                self::$loaded[$classLower] = true;
                return;
            }
        }

        $relative = substr($class, 4);

        $file = BASE_PATH . '/App/' . str_replace('\\', '/', $relative) . '.php';

        if (is_file($file)) {
            $realPath = realpath($file);
            if ($realPath !== false) {
                require_once $realPath;

                if (self::exists($class)) {
                    self::$cache[$classLower] = $realPath;
                    self::$loaded[$classLower] = true;
                    return;
                }
            }
        }

        $file = self::search($relative);

        if ($file) {
            $realPath = realpath($file);
            if ($realPath !== false) {
                require_once $realPath;

                if (self::exists($class)) {
                    self::$cache[$classLower] = $realPath;
                    self::$loaded[$classLower] = true;
                    return;
                }
            }
        }
    }

    private static function search(string $relative): ?string
    {
        $parts = explode('\\', $relative);
        $path = BASE_PATH . '/App';

        foreach ($parts as $part) {
            if (!is_dir($path)) {
                break;
            }

            $found = null;

            foreach (scandir($path) as $item) {
                if (strtolower($item) === strtolower($part)) {
                    $found = $item;
                    break;
                }
            }

            if (!$found) {
                return null;
            }

            $path .= '/' . $found;
        }

        if (is_file($path . '.php')) {
            return $path . '.php';
        }

        if (is_file($path)) {
            return $path;
        }

        return null;
    }

    private static function exists(string $class): bool
    {
        return class_exists($class, false)
            || interface_exists($class, false)
            || trait_exists($class, false);
    }

    public static function reset(): void
    {
        self::$loaded = [];
        self::$cache = [];
    }
}

/*
|--------------------------------------------------------------------------
| REGISTER
|--------------------------------------------------------------------------
*/
Autoload::register();