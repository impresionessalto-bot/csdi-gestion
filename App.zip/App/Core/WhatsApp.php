<?php namespace App\Core;

class WhatsApp {
    public static function enviar($numero, $mensaje, $db) {
        // 1. Obtener configuración de DB (Centralizado y Blindado)
        $res = $db->query("SELECT clave, valor FROM configuracion_sistema WHERE clave IN ('whatsapp_api_url', 'whatsapp_token')");
        $cfg = array_column($res->fetch_all(\MYSQLI_ASSOC), 'valor', 'clave');
        
        if (empty($cfg['whatsapp_api_url']) || empty($cfg['whatsapp_token'])) return false;

        // 2. Limpiar número (Formato internacional)
        $to = preg_replace('/[^0-9]/', '', $numero);
        // Si no empieza con 549, podrías añadirle el prefijo si es necesario
        
        $params = [
            'token'  => $cfg['whatsapp_token'],
            'to'     => $to, 
            'body'   => $mensaje,
            'priority' => 10
        ];

        $ch = curl_init($cfg['whatsapp_api_url']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}