<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;


final class Response
{


    /*
    |--------------------------------------------------------------------------
    | JSON
    |--------------------------------------------------------------------------
    */


    public static function json(
        array $data,
        int $status = 200
    ): never {


        if(!headers_sent()){

            http_response_code($status);

            header(
                'Content-Type: application/json; charset=utf-8'
            );

        }



        echo json_encode(

            $data,

            JSON_UNESCAPED_UNICODE
            |
            JSON_UNESCAPED_SLASHES
            |
            JSON_THROW_ON_ERROR

        );


        exit;

    }







    public static function success(
        mixed $data = [],
        string $message = 'OK',
        int $status = 200
    ): never {


        self::json([

            'success'=>true,

            'message'=>$message,

            'data'=>$data

        ],$status);


    }







    public static function error(
        string $message,
        int $status = 400,
        array $errors = []
    ): never {


        self::json([

            'success'=>false,

            'message'=>$message,

            'errors'=>$errors

        ],$status);


    }







    public static function validation(
        array $errors
    ): never {


        self::error(

            'Errores de validación',

            422,

            $errors

        );

    }









    /*
    |--------------------------------------------------------------------------
    | HTTP SHORTCUTS
    |--------------------------------------------------------------------------
    */


    public static function created(
        mixed $data=[],
        string $message='Registro creado'
    ):never
    {

        self::success(
            $data,
            $message,
            201
        );

    }





    public static function unauthorized(
        string $message='No autorizado'
    ):never
    {

        self::error(
            $message,
            401
        );

    }





    public static function forbidden(
        string $message='Acceso denegado'
    ):never
    {

        self::error(
            $message,
            403
        );

    }





    public static function notFound(
        string $message='No encontrado'
    ):never
    {

        self::error(
            $message,
            404
        );

    }







    /*
    |--------------------------------------------------------------------------
    | EXCEPTIONS
    |--------------------------------------------------------------------------
    */


    public static function exception(
        Throwable $e,
        bool $debug=false
    ):never
    {


        self::json([


            'success'=>false,


            'message'=>

                $debug

                ?

                $e->getMessage()

                :

                'Error interno del servidor',



            'file'=>

                $debug

                ?

                $e->getFile()

                :

                null,



            'line'=>

                $debug

                ?

                $e->getLine()

                :

                null


        ],500);


    }









    /*
    |--------------------------------------------------------------------------
    | REDIRECT
    |--------------------------------------------------------------------------
    */


    public static function redirect(
        string $url,
        int $status=302
    ):never
    {


        if(!headers_sent()){


            http_response_code($status);


            header(
                'Location: '.$url
            );


        }


        exit;


    }







    public static function back():never
    {

        self::redirect(

            $_SERVER['HTTP_REFERER']
            ??
            '/'

        );

    }







    /*
    |--------------------------------------------------------------------------
    | HTML / TEXT
    |--------------------------------------------------------------------------
    */


    public static function html(
        string $html,
        int $status=200
    ):never
    {


        if(!headers_sent()){


            http_response_code($status);


            header(
                'Content-Type:text/html;charset=utf-8'
            );


        }


        echo $html;

        exit;


    }







    public static function text(
        string $text,
        int $status=200
    ):never
    {


        if(!headers_sent()){


            http_response_code($status);


            header(
                'Content-Type:text/plain;charset=utf-8'
            );


        }


        echo $text;

        exit;


    }









    /*
    |--------------------------------------------------------------------------
    | FILES
    |--------------------------------------------------------------------------
    */


    public static function download(
        string $file,
        ?string $name=null
    ):never
    {


        if(!is_file($file)){

            self::notFound(
                'Archivo inexistente'
            );

        }



        $name ??=
            basename($file);



        $name =
            basename($name);



        header(
            'Content-Type: application/octet-stream'
        );


        header(
            'Content-Disposition: attachment; filename="'.$name.'"'
        );


        header(
            'Content-Length: '.filesize($file)
        );



        readfile($file);


        exit;


    }







    public static function file(
        string $file,
        string $mime='application/pdf'
    ):never
    {


        if(!is_file($file)){

            self::notFound(
                'Archivo inexistente'
            );

        }



        header(
            'Content-Type: '.$mime
        );


        header(
            'Content-Length: '.filesize($file)
        );


        readfile($file);


        exit;


    }









    /*
    |--------------------------------------------------------------------------
    | AJAX
    |--------------------------------------------------------------------------
    */


    public static function ajax():bool
    {


        return

            (
                $_SERVER['HTTP_X_REQUESTED_WITH']
                ??
                ''
            )
            ===
            'XMLHttpRequest'

            ||

            str_contains(

                $_SERVER['HTTP_ACCEPT']
                ??
                '',

                'application/json'

            );


    }





}