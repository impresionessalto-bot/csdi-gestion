<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;
use Throwable;

/**
 * ============================================================================
 * CSDI PRO
 * MODULE LOADER
 * ============================================================================
 *
 * Responsabilidades:
 *
 * - Descubrir módulos dentro de App/Modules.
 * - Registrar módulos habilitados.
 * - Validar que implementen App\Core\Module.
 * - Detectar módulos duplicados.
 * - Verificar dependencias.
 * - Ordenar módulos por prioridad.
 * - Ejecutar boot() de cada módulo.
 * - Cargar routes.php de cada módulo.
 * - Exponer módulos, menú y permisos.
 *
 * Características:
 *
 * - Compatible con módulos existentes.
 * - No requiere modificar los módulos actuales.
 * - Un módulo sin routes.php NO rompe el ERP.
 * - Un routes.php inválido sí genera error controlado.
 * - Evita cargar módulos y rutas más de una vez.
 * - reset() permite reinicializar correctamente el loader.
 *
 * ============================================================================
 */
final class ModuleLoader
{
    /*
    |--------------------------------------------------------------------------
    | ESTADO DEL LOADER
    |--------------------------------------------------------------------------
    */

    /**
     * Indica si los módulos ya fueron cargados.
     */
    private static bool $loaded = false;

    /**
     * Indica si las rutas ya fueron cargadas.
     */
    private static bool $routesLoaded = false;

    /**
     * Módulos registrados.
     *
     * @var array<string, Module>
     */
    private static array $modules = [];


    /*
    |--------------------------------------------------------------------------
    | LOAD
    |--------------------------------------------------------------------------
    */

    /**
     * Descubre, registra, valida, ordena e inicializa los módulos.
     */
    public static function load(): void
    {
        /*
         * --------------------------------------------------------------
         * Evitar doble carga
         * --------------------------------------------------------------
         */
        if (self::$loaded) {
            return;
        }

        /*
         * --------------------------------------------------------------
         * Marcar como iniciado
         * --------------------------------------------------------------
         */
        self::$loaded = true;

        /*
         * --------------------------------------------------------------
         * Directorio de módulos
         * --------------------------------------------------------------
         */
        $baseModulesPath =
            BASE_PATH
            . '/App/Modules';

        if (!is_dir($baseModulesPath)) {

            /*
             * No hay módulos.
             */
            return;
        }

        /*
         * --------------------------------------------------------------
         * Descubrir directorios
         * --------------------------------------------------------------
         */
        $directories = glob(
            $baseModulesPath . '/*',
            GLOB_ONLYDIR
        );

        if (!$directories) {
            return;
        }

        /*
         * --------------------------------------------------------------
         * Registrar módulos
         * --------------------------------------------------------------
         */
        foreach ($directories as $directory) {

            try {

                self::register(
                    $directory
                );

            } catch (Throwable $e) {

                /*
                 * Si un módulo está mal construido,
                 * el error debe indicar claramente cuál es.
                 */
                throw new RuntimeException(
                    'Error cargando módulo '
                    . basename($directory)
                    . ': '
                    . $e->getMessage(),
                    (int) $e->getCode(),
                    $e
                );
            }
        }

        /*
         * --------------------------------------------------------------
         * Validar dependencias
         * --------------------------------------------------------------
         */
        self::checkDependencies();

        /*
         * --------------------------------------------------------------
         * Ordenar por prioridad
         * --------------------------------------------------------------
         */
        self::sort();

        /*
         * --------------------------------------------------------------
         * Inicializar módulos
         * --------------------------------------------------------------
         */
        foreach (self::$modules as $module) {

            try {

                $module->boot();

            } catch (Throwable $e) {

                throw new RuntimeException(
                    'Error inicializando módulo '
                    . $module->name()
                    . ': '
                    . $e->getMessage(),
                    (int) $e->getCode(),
                    $e
                );
            }
        }

        /*
         * --------------------------------------------------------------
         * Cargar rutas
         * --------------------------------------------------------------
         */
        self::routes();
    }


    /*
    |--------------------------------------------------------------------------
    | REGISTER
    |--------------------------------------------------------------------------
    */

    /**
     * Registra un módulo individual.
     */
    private static function register(
        string $directory
    ): void {

        /*
         * --------------------------------------------------------------
         * Validar directorio
         * --------------------------------------------------------------
         */
        if (!is_dir($directory)) {
            return;
        }

        /*
         * --------------------------------------------------------------
         * Module.php
         * --------------------------------------------------------------
         */
        $file =
            $directory
            . '/Module.php';

        /*
         * --------------------------------------------------------------
         * Módulo sin definición
         * --------------------------------------------------------------
         *
         * Esto permite que App/Modules contenga carpetas auxiliares
         * que no sean módulos reales.
         *
         */
        if (!is_file($file)) {
            return;
        }

        /*
         * --------------------------------------------------------------
         * Cargar definición
         * --------------------------------------------------------------
         */
        require_once $file;

        /*
         * --------------------------------------------------------------
         * Nombre de carpeta
         * --------------------------------------------------------------
         */
        $folder =
            basename($directory);

        /*
         * --------------------------------------------------------------
         * Clases compatibles
         * --------------------------------------------------------------
         *
         * Soporta:
         *
         * App\Modules\Modulo\Module
         *
         * y también:
         *
         * App\Modules\Modulo\ModuloModule
         *
         */
        $possible = [
            "App\\Modules\\{$folder}\\Module",
            "App\\Modules\\{$folder}\\{$folder}Module",
        ];

        $class = null;

        /*
         * --------------------------------------------------------------
         * Buscar clase
         * --------------------------------------------------------------
         */
        foreach ($possible as $candidate) {

            if (class_exists($candidate)) {

                $class = $candidate;

                break;
            }
        }

        /*
         * --------------------------------------------------------------
         * No existe clase
         * --------------------------------------------------------------
         */
        if ($class === null) {

            throw new RuntimeException(
                "No existe módulo {$folder}"
            );
        }

        /*
         * --------------------------------------------------------------
         * Instanciar
         * --------------------------------------------------------------
         */
        try {

            $module =
                new $class();

        } catch (Throwable $e) {

            throw new RuntimeException(
                "No se pudo instanciar el módulo {$folder}: "
                . $e->getMessage(),
                (int) $e->getCode(),
                $e
            );
        }

        /*
         * --------------------------------------------------------------
         * Validar contrato
         * --------------------------------------------------------------
         */
        if (!$module instanceof Module) {

            throw new RuntimeException(
                "{$class} no implementa App\\Core\\Module"
            );
        }

        /*
         * --------------------------------------------------------------
         * Módulo deshabilitado
         * --------------------------------------------------------------
         */
        if (!$module->enabled()) {
            return;
        }

        /*
         * --------------------------------------------------------------
         * Obtener nombre
         * --------------------------------------------------------------
         */
        $name =
            trim(
                (string) $module->name()
            );

        if ($name === '') {

            throw new RuntimeException(
                "El módulo {$folder} no tiene nombre válido"
            );
        }

        /*
         * --------------------------------------------------------------
         * Detectar duplicados
         * --------------------------------------------------------------
         */
        if (isset(self::$modules[$name])) {

            throw new RuntimeException(
                "Módulo duplicado {$name}"
            );
        }

        /*
         * --------------------------------------------------------------
         * Registrar
         * --------------------------------------------------------------
         */
        self::$modules[$name] =
            $module;
    }


    /*
    |--------------------------------------------------------------------------
    | ROUTES
    |--------------------------------------------------------------------------
    */

    /**
     * Carga routes.php de los módulos.
     *
     * Un módulo sin routes.php no rompe el ERP.
     */
    private static function routes(): void
    {
        /*
         * --------------------------------------------------------------
         * Evitar doble carga
         * --------------------------------------------------------------
         */
        if (self::$routesLoaded) {
            return;
        }

        /*
         * --------------------------------------------------------------
         * Recorrer módulos
         * --------------------------------------------------------------
         */
        foreach (self::$modules as $module) {

            try {

                /*
                 * ------------------------------------------------------
                 * Obtener archivo de rutas
                 * ------------------------------------------------------
                 */
                $file =
                    $module->routes();

                /*
                 * ------------------------------------------------------
                 * Módulo sin rutas
                 * ------------------------------------------------------
                 */
                if (
                    $file === null
                    || trim((string) $file) === ''
                ) {
                    continue;
                }

                $file =
                    (string) $file;

                /*
                 * ------------------------------------------------------
                 * Validar que sea archivo
                 * ------------------------------------------------------
                 *
                 * IMPORTANTE:
                 *
                 * Si Database declara:
                 *
                 * __DIR__ . '/routes.php'
                 *
                 * pero el archivo todavía no existe,
                 * NO detenemos todo el ERP.
                 *
                 * Se registra en el log y continuamos.
                 * ------------------------------------------------------
                 */
                if (!is_file($file)) {

                    error_log(
                        '[ModuleLoader] routes.php no encontrado para módulo '
                        . $module->name()
                        . ': '
                        . $file
                    );

                    continue;
                }

                /*
                 * ------------------------------------------------------
                 * Validar extensión
                 * ------------------------------------------------------
                 */
                $extension =
                    strtolower(
                        (string) pathinfo(
                            $file,
                            PATHINFO_EXTENSION
                        )
                    );

                if ($extension !== 'php') {

                    error_log(
                        '[ModuleLoader] Archivo de rutas inválido para módulo '
                        . $module->name()
                        . ': '
                        . $file
                    );

                    continue;
                }

                /*
                 * ------------------------------------------------------
                 * Cargar rutas
                 * ------------------------------------------------------
                 */
                require_once $file;

            } catch (Throwable $e) {

                /*
                 * ------------------------------------------------------
                 * Error real dentro de routes.php
                 * ------------------------------------------------------
                 *
                 * Si el archivo existe pero contiene un error,
                 * NO lo ocultamos.
                 *
                 * Esto permite detectar:
                 *
                 * - errores de sintaxis
                 * - clases inexistentes
                 * - métodos inexistentes
                 * - errores del Router
                 * - errores de configuración
                 *
                 * ------------------------------------------------------
                 */
                throw new RuntimeException(
                    'Error cargando rutas del módulo '
                    . $module->name()
                    . ': '
                    . $e->getMessage(),
                    (int) $e->getCode(),
                    $e
                );
            }
        }

        /*
         * --------------------------------------------------------------
         * Marcar rutas como cargadas
         * --------------------------------------------------------------
         */
        self::$routesLoaded = true;
    }


    /*
    |--------------------------------------------------------------------------
    | SORT
    |--------------------------------------------------------------------------
    */

    /**
     * Ordena módulos por prioridad.
     */
    private static function sort(): void
    {
        uasort(
            self::$modules,
            static function (
                Module $a,
                Module $b
            ): int {

                return
                    $a->priority()
                    <=>
                    $b->priority();
            }
        );
    }


    /*
    |--------------------------------------------------------------------------
    | DEPENDENCIES
    |--------------------------------------------------------------------------
    */

    /**
     * Verifica las dependencias declaradas por los módulos.
     */
    private static function checkDependencies(): void
    {
        foreach (self::$modules as $module) {

            $dependencies =
                $module->dependencies();

            if (!is_array($dependencies)) {
                continue;
            }

            foreach ($dependencies as $dependency) {

                $dependency =
                    trim(
                        (string) $dependency
                    );

                if ($dependency === '') {
                    continue;
                }

                if (
                    !isset(
                        self::$modules[$dependency]
                    )
                ) {

                    throw new RuntimeException(
                        "Falta {$dependency} requerido por "
                        . $module->name()
                    );
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | MODULES
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve todos los módulos cargados.
     *
     * @return array<string, Module>
     */
    public static function modules(): array
    {
        return self::$modules;
    }


    /*
    |--------------------------------------------------------------------------
    | MENU
    |--------------------------------------------------------------------------
    */

    /**
     * Construye el menú global de módulos.
    *
     * @return array<int,array<string,mixed>>
     */
    public static function menu(): array
    {
        $menu = [];

        foreach (self::$modules as $module) {

            try {

                $items =
                    $module->menu();

            } catch (Throwable $e) {

                error_log(
                    '[ModuleLoader] Error obteniendo menú del módulo '
                    . $module->name()
                    . ': '
                    . $e->getMessage()
                );

                continue;
            }

            if (!is_array($items)) {
                continue;
            }

            foreach ($items as $item) {

                if (!is_array($item)) {
                    continue;
                }

                $menu[] =
                    $item;
            }
        }

        /*
         * --------------------------------------------------------------
         * Ordenar menú
         * --------------------------------------------------------------
         */
        usort(
            $menu,
            static function (
                array $a,
                array $b
            ): int {

                return
                    ((int) ($a['order'] ?? 100))
                    <=>
                    ((int) ($b['order'] ?? 100));
            }
        );

        return $menu;
    }


    /*
    |--------------------------------------------------------------------------
    | PERMISSIONS
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve todos los permisos registrados por los módulos.
     *
     * @return array<int,string>
     */
    public static function permissions(): array
    {
        $result = [];

        foreach (self::$modules as $module) {

            try {

                $permissions =
                    $module->permissions();

            } catch (Throwable $e) {

                error_log(
                    '[ModuleLoader] Error obteniendo permisos del módulo '
                    . $module->name()
                    . ': '
                    . $e->getMessage()
                );

                continue;
            }

            if (!is_array($permissions)) {
                continue;
            }

            $result =
                array_merge(
                    $result,
                    $permissions
                );
        }

        /*
         * --------------------------------------------------------------
         * Normalizar
         * --------------------------------------------------------------
         */
        $result =
            array_map(
                static function (mixed $permission): string {
                    return trim(
                        (string) $permission
                    );
                },
                $result
            );

        /*
         * --------------------------------------------------------------
         * Eliminar vacíos y duplicados
         * --------------------------------------------------------------
         */
        $result =
            array_filter(
                $result,
                static function (string $permission): bool {
                    return $permission !== '';
                }
            );

        return array_values(
            array_unique(
                $result
            )
        );
    }


    /*
    |--------------------------------------------------------------------------
    | RESET
    |--------------------------------------------------------------------------
    */

    /**
     * Reinicia completamente el ModuleLoader.
     *
     * Útil para:
     *
     * - tests
     * - reinicialización del Kernel
     * - procesos especiales
     * - entornos donde se vuelve a cargar el bootstrap
     */
    public static function reset(): void
    {
        self::$loaded = false;

        self::$routesLoaded = false;

        self::$modules = [];
    }
}