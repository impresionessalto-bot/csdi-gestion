<?php

declare(strict_types=1);

namespace App\Core;

final class ErpModuleGenerator
{
    private string $basePath;

    public function __construct(string $basePath)
    {
        $this->basePath = rtrim($basePath, '/');
    }

    public function generate(string $moduleName, string $tableName, array $fields): void
    {
        $class = ucfirst($moduleName);

        $this->createRepository($class, $tableName, $fields);
        $this->createService($class);
        $this->createController($class);

        echo "✔ Módulo {$class} generado correctamente\n";
    }

    private function createRepository(string $class, string $table, array $fields): void
    {
        $fieldsInsert = implode(', ', array_keys($fields));
        $placeholders = implode(', ', array_fill(0, count($fields), '?'));

        $updateFields = implode(",\n                ", array_map(
            fn($f) => "$f = ?",
            array_keys($fields)
        ));

        $code = <<<PHP
<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class {$class}Repository
{
    public function __construct(private PDO \$pdo) {}

    public function all(): array
    {
        return \$this->pdo->query("SELECT * FROM {$table} ORDER BY id DESC")
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int \$id): ?array
    {
        \$stmt = \$this->pdo->prepare("SELECT * FROM {$table} WHERE id = ?");
        \$stmt->execute([\$id]);

        return \$stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function insert(array \$data): int
    {
        \$stmt = \$this->pdo->prepare("
            INSERT INTO {$table} ({$fieldsInsert})
            VALUES ({$placeholders})
        ");

        \$stmt->execute([
            {$this->buildArrayFields($fields)}
        ]);

        return (int)\$this->pdo->lastInsertId();
    }

    public function update(int \$id, array \$data): bool
    {
        \$stmt = \$this->pdo->prepare("
            UPDATE {$table}
            SET {$updateFields}
            WHERE id = ?
        ");

        return \$stmt->execute([
            {$this->buildArrayFields($fields, true)},
            \$id
        ]);
    }

    public function delete(int \$id): bool
    {
        \$stmt = \$this->pdo->prepare("DELETE FROM {$table} WHERE id = ?");
        return \$stmt->execute([\$id]);
    }
}
PHP;

        $this->write("App/Repositories/{$class}Repository.php", $code);
    }

    private function createService(string $class): void
    {
        $code = <<<PHP
<?php

declare(strict_types=1);

namespace App\Services;

use App\Repositories\\{$class}Repository;

final class {$class}Service
{
    public function __construct(private {$class}Repository \$repo) {}

    public function list(): array
    {
        return \$this->repo->all();
    }

    public function get(int \$id): ?array
    {
        return \$this->repo->find(\$id);
    }

    public function create(array \$data): int
    {
        return \$this->repo->insert(\$data);
    }

    public function update(int \$id, array \$data): bool
    {
        return \$this->repo->update(\$id, \$data);
    }

    public function delete(int \$id): bool
    {
        return \$this->repo->delete(\$id);
    }
}
PHP;

        $this->write("App/Services/{$class}Service.php", $code);
    }

    private function createController(string $class): void
    {
        $code = <<<PHP
<?php

declare(strict_types=1);

namespace App\Controllers;

use PDO;
use App\Repositories\\{$class}Repository;
use App\Services\\{$class}Service;

final class {$class}Controller
{
    private {$class}Service \$service;

    public function __construct(PDO \$pdo)
    {
        \$repo = new {$class}Repository(\$pdo);
        \$this->service = new {$class}Service(\$repo);
    }

    public function index(): void
    {
        \$items = \$this->service->list();
        require BASE_PATH . '/App/Views/{$class}/index.php';
    }

    public function show(int \$id): void
    {
        \$item = \$this->service->get(\$id);
        require BASE_PATH . '/App/Views/{$class}/show.php';
    }

    public function store(): void
    {
        \$id = \$this->service->create(\$_POST);
        header("Location: /{$class}/show?id=" . \$id);
        exit;
    }

    public function update(int \$id): void
    {
        \$this->service->update(\$id, \$_POST);
        header("Location: /{$class}/show?id=" . \$id);
        exit;
    }

    public function delete(int \$id): void
    {
        \$this->service->delete(\$id);
        header("Location: /{$class}");
        exit;
    }
}
PHP;

        $this->write("App/Controllers/{$class}Controller.php", $code);
    }

    private function buildArrayFields(array $fields, bool $skipLast = false): string
    {
        $keys = array_keys($fields);

        if ($skipLast) {
            array_push($keys, 'id');
        }

        return implode(",\n            ", array_map(
            fn($k) => "\$data['$k'] ?? null",
            $keys
        ));
    }

    private function write(string $path, string $content): void
    {
        $full = $this->basePath . '/' . $path;
        $dir = dirname($full);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        file_put_contents($full, $content);
    }
}