<?php
declare(strict_types=1);

namespace App\Core;

/**
 * ============================================================
 * ERP CSDI
 * ------------------------------------------------------------
 * Session
 * ------------------------------------------------------------
 * Manejo centralizado de sesiones.
 *
 * Nunca utilizar directamente $_SESSION
 *
 * Session::get()
 * Session::put()
 * Session::flash()
 * Session::has()
 * Session::forget()
 * Session::destroy()
 * ============================================================
 */

final class Session
{
    /**
     * Inicia la sesión si aún no está iniciada.
     */
    public static function start(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {

            session_start([
                'cookie_httponly' => true,
                'cookie_samesite' => 'Lax',
                'use_strict_mode' => true
            ]);

        }
    }

    /**
     * Obtiene un valor.
     */
    public static function get(string $key, mixed $default = null): mixed
    {
        self::start();

        return $_SESSION[$key] ?? $default;
    }

    /**
     * Guarda un valor.
     */
    public static function put(string $key, mixed $value): void
    {
        self::start();

        $_SESSION[$key] = $value;
    }

    /**
     * Alias de put().
     */
    public static function set(string $key, mixed $value): void
    {
        self::put($key, $value);
    }

    /**
     * Verifica existencia.
     */
    public static function has(string $key): bool
    {
        self::start();

        return array_key_exists($key, $_SESSION);
    }

    /**
     * Elimina una variable.
     */
    public static function forget(string $key): void
    {
        self::start();

        unset($_SESSION[$key]);
    }

    /**
     * Limpia toda la sesión.
     */
    public static function clear(): void
    {
        self::start();

        $_SESSION = [];
    }

    /**
     * Destruye completamente la sesión.
     */
    public static function destroy(): void
    {
        self::start();

        $_SESSION = [];

        if (ini_get('session.use_cookies')) {

            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
    }

    /**
     * Flash message.
     * Disponible una sola vez.
     */
    public static function flash(string $key, mixed $value): void
    {
        self::start();

        $_SESSION['_flash'][$key] = $value;
    }

    /**
     * Obtiene una flash y la elimina.
     */
    public static function getFlash(string $key, mixed $default = null): mixed
    {
        self::start();

        if (!isset($_SESSION['_flash'][$key])) {
            return $default;
        }

        $value = $_SESSION['_flash'][$key];

        unset($_SESSION['_flash'][$key]);

        return $value;
    }

    /**
     * Verifica flash.
     */
    public static function hasFlash(string $key): bool
    {
        self::start();

        return isset($_SESSION['_flash'][$key]);
    }

    /**
     * Login rápido.
     */
    public static function login(array $user): void
    {
        self::start();

        session_regenerate_id(true);

        $_SESSION['user'] = $user;

        $_SESSION['logged'] = true;

        $_SESSION['login_at'] = date('Y-m-d H:i:s');
    }

    /**
     * Logout.
     */
    public static function logout(): void
    {
        self::destroy();
    }

    /**
     * Usuario actual.
     */
    public static function user(): ?array
    {
        self::start();

        return $_SESSION['user'] ?? null;
    }

    /**
     * Usuario autenticado.
     */
    public static function check(): bool
    {
        self::start();

        return !empty($_SESSION['logged']);
    }

    /**
     * ID del usuario.
     */
    public static function userId(): ?int
    {
        $user = self::user();

        return isset($user['id'])
            ? (int)$user['id']
            : null;
    }

    /**
     * Nombre del usuario.
     */
    public static function userName(): ?string
    {
        $user = self::user();

        return $user['nombre'] ?? null;
    }

    /**
     * Rol del usuario.
     */
    public static function role(): ?string
    {
        $user = self::user();

        return $user['rol'] ?? null;
    }

    /**
     * Verifica rol.
     */
    public static function is(string $role): bool
    {
        return self::role() === $role;
    }

    /**
     * Devuelve toda la sesión.
     */
    public static function all(): array
    {
        self::start();

        return $_SESSION;
    }

    /**
     * Regenera el ID.
     */
    public static function regenerate(): void
    {
        self::start();

        session_regenerate_id(true);
    }
}