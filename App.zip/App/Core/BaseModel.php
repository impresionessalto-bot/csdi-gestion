<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

abstract class BaseModel
{
    protected PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    protected function query(string $sql, array $params = [])
    {
        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt;
    }

    protected function one(string $sql, array $params = []): array|null
    {
        return $this->query($sql, $params)
            ->fetch(PDO::FETCH_ASSOC);
    }

    protected function all(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    protected function execute(string $sql, array $params = []): bool
    {
        return $this->query($sql, $params) !== false;
    }
}