<?php
declare(strict_types=1);

namespace App\Core;

final class Jwt
{
    private static string $secret = 'CSDI_SUPER_SECRET_KEY_CHANGE_ME';

    public static function generate(array $payload): string
    {
        $header = base64_encode(json_encode([
            'alg' => 'HS256',
            'typ' => 'JWT'
        ]));

        $payload['exp'] = time() + 3600 * 8; // 8 horas

        $payloadEncoded = base64_encode(json_encode($payload));

        $signature = hash_hmac(
            'sha256',
            $header . "." . $payloadEncoded,
            self::$secret,
            true
        );

        $signatureEncoded = base64_encode($signature);

        return $header . "." . $payloadEncoded . "." . $signatureEncoded;
    }

    public static function validate(string $token): ?array
    {
        $parts = explode('.', $token);

        if (count($parts) !== 3) {
            return null;
        }

        [$header, $payload, $signature] = $parts;

        $validSignature = base64_encode(
            hash_hmac('sha256', $header . "." . $payload, self::$secret, true)
        );

        if (!hash_equals($validSignature, $signature)) {
            return null;
        }

        $data = json_decode(base64_decode($payload), true);

        if ($data['exp'] < time()) {
            return null;
        }

        return $data;
    }
}