<?php
declare(strict_types=1);

namespace App\Modules\Clientes;

use App\Core\Module as CoreModule;

final class Module extends CoreModule
{
    public function name(): string
    {
        return 'Clientes';
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function menu(): array
    {
        return [
            'titulo' => 'Clientes'
        ];
    }

    public function icon(): string
    {
        return 'fa-solid fa-users';
    }

    public function url(): string
    {
        return '/clientes';
    }

    public function order(): int
    {
        return 10;
    }

    public function permissions(): array
    {
        return [

            'clientes.ver',

            'clientes.crear',

            'clientes.editar',

            'clientes.eliminar'

        ];
    }

    public function dependencies(): array
    {
        return [];
    }
}