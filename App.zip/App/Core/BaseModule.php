<?php
declare(strict_types=1);

namespace App\Core;

abstract class BaseModule
{
    /**
     * Nombre del módulo
     */
    protected string $name = '';

    /**
     * Icono FontAwesome
     */
    protected string $icon = 'fa-solid fa-cube';

    /**
     * Ruta principal
     */
    protected string $route = '/';

    /**
     * Orden del menú
     */
    protected int $order = 100;

    /**
     * Visible en menú
     */
    protected bool $visible = true;

    /**
     * Activo
     */
    protected bool $enabled = true;

    /**
     * Permisos requeridos
     */
    protected array $permissions = [];

    /* =========================================================
     * INFORMACIÓN
     * ========================================================= */

    public function name(): string
    {
        return $this->name;
    }

    public function icon(): string
    {
        return $this->icon;
    }

    public function route(): string
    {
        return $this->route;
    }

    public function order(): int
    {
        return $this->order;
    }

    public function visible(): bool
    {
        return $this->visible;
    }

    public function enabled(): bool
    {
        return $this->enabled;
    }

    public function permissions(): array
    {
        return $this->permissions;
    }

    /* =========================================================
     * PATHS
     * ========================================================= */

    public function path(): string
    {
        $reflection = new \ReflectionClass($this);

        return dirname($reflection->getFileName());
    }

    public function configPath(): string
    {
        return $this->path() . '/Config';
    }

    public function controllerPath(): string
    {
        return $this->path() . '/Controllers';
    }

    public function servicePath(): string
    {
        return $this->path() . '/Services';
    }

    public function repositoryPath(): string
    {
        return $this->path() . '/Repositories';
    }

    public function dtoPath(): string
    {
        return $this->path() . '/DTOs';
    }

    public function viewPath(): string
    {
        return $this->path() . '/Views';
    }

    public function assetPath(): string
    {
        return $this->path() . '/Assets';
    }

    /* =========================================================
     * AUTOLOAD
     * ========================================================= */

    public function routesFile(): ?string
    {
        $file = $this->configPath() . '/routes.php';

        return file_exists($file)
            ? $file
            : null;
    }

    public function permissionsFile(): ?string
    {
        $file = $this->configPath() . '/permissions.php';

        return file_exists($file)
            ? $file
            : null;
    }

    public function menu(): array
    {
        return [

            'name' => $this->name(),

            'icon' => $this->icon(),

            'route' => $this->route(),

            'order' => $this->order(),

            'visible' => $this->visible()

        ];
    }

    /**
     * Hook de inicio del módulo.
     */
    public function boot(): void
    {
    }
}