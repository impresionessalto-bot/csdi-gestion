<?php

declare(strict_types=1);

namespace App\Core;

use Closure;
use RuntimeException;


/**
 * =========================================================
 * ERP CSDI PRO
 *
 * ROUTER V10 BLINDADO
 *
 * Router MVC central
 *
 * Soporta:
 *
 * GET
 * POST
 * PUT
 * PATCH
 * DELETE
 *
 * Middleware
 * Groups
 * Controllers
 * Parámetros dinámicos
 *
 * =========================================================
 */
final class Router
{


    private static array $routes=[

        'GET'=>[],
        'POST'=>[],
        'PUT'=>[],
        'PATCH'=>[],
        'DELETE'=>[]

    ];



    private static array $group=[

        'prefix'=>'',

        'middleware'=>[]

    ];



    private static ?Closure $notFound=null;





    public static function get(
        string $uri,
        string|array|Closure $action,
        array $middleware=[]
    ):void
    {

        self::add(
            'GET',
            $uri,
            $action,
            $middleware
        );

    }





    public static function post(
        string $uri,
        string|array|Closure $action,
        array $middleware=[]
    ):void
    {

        self::add(
            'POST',
            $uri,
            $action,
            $middleware
        );

    }





    public static function put(
        string $uri,
        string|array|Closure $action,
        array $middleware=[]
    ):void
    {

        self::add(
            'PUT',
            $uri,
            $action,
            $middleware
        );

    }





    public static function patch(
        string $uri,
        string|array|Closure $action,
        array $middleware=[]
    ):void
    {

        self::add(
            'PATCH',
            $uri,
            $action,
            $middleware
        );

    }





    public static function delete(
        string $uri,
        string|array|Closure $action,
        array $middleware=[]
    ):void
    {

        self::add(
            'DELETE',
            $uri,
            $action,
            $middleware
        );

    }





    private static function add(
        string $method,
        string $uri,
        string|array|Closure $action,
        array $middleware
    ):void
    {


        $uri =
            self::normalize(

                self::$group['prefix']
                .
                $uri

            );




        self::$routes[$method][]=[


            'uri'=>$uri,


            'regex'=>self::compile($uri),


            'action'=>$action,


            'middleware'=>

                array_merge(

                    self::$group['middleware'],

                    $middleware

                )


        ];


    }





    public static function group(
        string $prefix,
        array|Closure $middleware,
        ?Closure $callback=null
    ):void
    {


        if($middleware instanceof Closure){


            $callback=$middleware;

            $middleware=[];


        }





        if(!$callback){


            throw new RuntimeException(

                'Grupo sin callback'

            );


        }





        $old=self::$group;



        self::$group['prefix']=

            self::normalize(

                self::$group['prefix']
                .
                $prefix

            );




        self::$group['middleware']=

            array_merge(

                self::$group['middleware'],

                $middleware

            );





        try{


            $callback();


        }
        finally{


            self::$group=$old;


        }



    }





    public static function dispatch():void
    {


        $method =
            strtoupper(

                $_SERVER['REQUEST_METHOD']
                ??
                'GET'

            );





        $uri =
            parse_url(

                $_SERVER['REQUEST_URI']
                ??
                '/',

                PHP_URL_PATH

            );




        $uri =
            self::normalize(
                $uri ?: '/'
            );






        foreach(
            self::$routes[$method] ?? []
            as $route
        ){



            if(
                !preg_match(
                    $route['regex'],
                    $uri,
                    $matches
                )
            ){

                continue;

            }




            array_shift($matches);




            MiddlewareKernel::run(
                $route['middleware']
            );





            self::execute(

                $route['action'],

                $matches

            );



            return;


        }





        self::notFound();


    }





    private static function execute(
        string|array|Closure $action,
        array $params
    ):void
    {


        if($action instanceof Closure){


            $action(...$params);


            return;


        }





        if(is_array($action)){


            $class=$action[0];

            $method=$action[1];


        }
        else{


            if(!str_contains($action,'@')){


                throw new RuntimeException(

                    "Ruta inválida {$action}"

                );


            }


            [
                $class,
                $method
            ] =
            explode(
                '@',
                $action,
                2
            );


        }





        $class =
            self::resolveController(
                $class
            );





        if(!class_exists($class)){


            throw new RuntimeException(

                "Controller no existe {$class}"

            );


        }





        $controller =

            Container::getInstance()
                ->make($class);





        if(!method_exists($controller,$method)){


            throw new RuntimeException(

                "Método {$method} inexistente"

            );


        }





        $params =
            array_map(

                static function($value){


                    return ctype_digit((string)$value)

                        ? (int)$value

                        : $value;


                },

                $params

            );






        $controller->{$method}(
            ...$params
        );


    }





    private static function resolveController(
        string $class
    ):string
    {


        if(str_starts_with($class,'App\\')){


            return $class;


        }





        /*
         *
         * Módulos:
         *
         * Counter\Controllers\Controller
         *
         */

        if(str_contains($class,'\\')){


            return
                'App\\Modules\\'
                .$class;


        }





        return
            'App\\Controllers\\'
            .$class;



    }





    private static function compile(
        string $uri
    ):string
    {


        $regex =
            preg_replace(

                '#\{[a-zA-Z0-9_]+\}#',

                '([^/]+)',

                $uri

            );



        return '#^'.$regex.'$#';



    }





    private static function normalize(
        string $uri
    ):string
    {


        $uri =
            '/'.trim($uri,'/');



        return $uri==='//'
            ? '/'
            : $uri;


    }





    public static function setNotFound(
        Closure $callback
    ):void
    {

        self::$notFound=$callback;

    }





    private static function notFound():void
    {


        http_response_code(404);



        if(self::$notFound){


            (self::$notFound)();


            return;


        }



        throw new RuntimeException(

            'Ruta no encontrada'

        );


    }





    public static function routes():array
    {

        return self::$routes;

    }





    public static function reset():void
    {

        self::$routes=[

            'GET'=>[],
            'POST'=>[],
            'PUT'=>[],
            'PATCH'=>[],
            'DELETE'=>[]

        ];



        self::$group=[

            'prefix'=>'',

            'middleware'=>[]

        ];



        self::$notFound=null;


    }



}