<?php

declare(strict_types=1);

namespace App\Core;

/**
 * =========================================================
 * CSDI ERP PRO
 * MENU MANAGER V3
 * =========================================================
 *
 * Genera automáticamente el menú lateral del ERP
 * leyendo todos los módulos registrados.
 *
 * Compatible con:
 * - title / titulo
 * - icon
 * - url
 * - group
 * - order
 * - permission
 * - permissions
 * - roles
 * - children
 * - visible
 *
 * =========================================================
 */

final class MenuManager
{
    /**
     * @var array<int,array<string,mixed>>
     */
    private array $menus = [];

    /**
     * Registrar uno o varios menús.
     */
    public function register(array $items): void
    {
        /*
        |--------------------------------------------------------------------------
        | Si viene un único item
        |--------------------------------------------------------------------------
        */

        if (
            isset($items['title']) ||
            isset($items['titulo'])
        ) {
            $items = [$items];
        }

        foreach ($items as $item) {

            if (!is_array($item)) {
                continue;
            }

            $this->menus[] = $this->normalize($item);
        }
    }

    /**
     * Normaliza el formato de un item.
     */
    private function normalize(array $item): array
    {
        return [

            'title' =>
                $item['title']
                ??
                $item['titulo']
                ??
                'Sin nombre',

            'icon' =>
                $item['icon']
                ??
                'fa-solid fa-cube',

            'url' =>
                $item['url']
                ??
                '#',

            'group' =>
                $item['group']
                ??
                'General',

            'order' =>
                (int)($item['order'] ?? 100),

            'permission' =>
                $item['permission']
                ??
                null,

            'permissions' =>
                $item['permissions']
                ??
                [],

            'roles' =>
                $item['roles']
                ??
                [],

            'children' =>
                $item['children']
                ??
                [],

            'visible' =>
                (bool)($item['visible'] ?? true),

        ];
    }

    /**
     * Leer todos los módulos.
     */
    public function loadModules(): void
    {
        foreach (ModuleLoader::modules() as $module) {

            if (!$module instanceof Module) {
                continue;
            }

            $menu = $module->menu();

            if (!is_array($menu)) {
                continue;
            }

            $this->register($menu);
        }
    }

    /**
     * Devuelve todos los menús.
     */
    public function all(): array
    {
        if (empty($this->menus)) {
            $this->loadModules();
        }

        return $this->menus;
    }

    /**
     * Agrupa por categoría.
     */
    public function grouped(): array
    {
        $groups = [];

        foreach ($this->all() as $item) {

            if (($item['visible'] ?? true) === false) {
                continue;
            }

            $group = $item['group'] ?? 'General';

            $groups[$group][] = $item;
        }

        foreach ($groups as &$items) {

            usort(
                $items,
                static fn(array $a, array $b): int =>
                    ($a['order'] ?? 100)
                    <=>
                    ($b['order'] ?? 100)
            );
        }

        unset($items);

        ksort($groups);

        return $groups;
    }

    /**
     * Verifica si el usuario puede ver un menú.
     */
    public function can(array $item): bool
    {
        $user = $_SESSION['user'] ?? null;

        if ($user === null) {
            return false;
        }

        $rol = strtolower((string)($user['rol'] ?? ''));

        /*
        |--------------------------------------------------------------------------
        | Administrador ve todo
        |--------------------------------------------------------------------------
        */

        if ($rol === 'admin') {
            return true;
        }

        /*
        |--------------------------------------------------------------------------
        | Restricción por roles
        |--------------------------------------------------------------------------
        */

        if (!empty($item['roles'])) {

            return in_array(
                $rol,
                array_map('strtolower', $item['roles']),
                true
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Temporal:
        | cuando exista PermissionManager se validará aquí.
        |--------------------------------------------------------------------------
        */

        return true;
    }

    /**
     * Devuelve únicamente los menús visibles.
     */
    public function visible(): array
    {
        $result = [];

        foreach ($this->grouped() as $group => $items) {

            foreach ($items as $item) {

                if (!$this->can($item)) {
                    continue;
                }

                $result[$group][] = $item;
            }
        }

        return $result;
    }

    /**
     * Buscar menú por URL.
     */
    public function findByUrl(string $url): ?array
    {
        foreach ($this->all() as $item) {

            if (($item['url'] ?? '') === $url) {
                return $item;
            }
        }

        return null;
    }

    /**
     * Cantidad de opciones cargadas.
     */
    public function count(): int
    {
        return count($this->all());
    }

    /**
     * Limpiar caché.
     */
    public function reset(): void
    {
        $this->menus = [];
    }
}