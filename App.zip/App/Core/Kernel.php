<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;
use Throwable;


/**
 * =========================================================
 * CSDI ERP PRO
 *
 * KERNEL V5 BLINDADO
 *
 * Bootstrap principal ERP
 *
 * =========================================================
 */

final class Kernel
{


    private bool $booted=false;


    private bool $debug=true;





    public function __construct(
        bool $debug=true
    )
    {

        $this->debug=$debug;

    }






    public function boot():void
    {


        if($this->booted){

            return;

        }





        try{


            $this->registerErrors();



            $this->loadHelpers();



            $this->bootSession();



            $this->bootDatabase();



            $this->bootServices();



            /*
             |--------------------------------------------------
             | MODULOS
             |--------------------------------------------------
             */

            ModuleLoader::load();




            /*
             |--------------------------------------------------
             | RUTAS
             |--------------------------------------------------
             */

            $this->loadRoutes();




            $this->booted=true;



        }
        catch(Throwable $e){


            if(class_exists(ErrorHandler::class)){


                ErrorHandler::handleException(
                    $e
                );


            }
            else{


                throw $e;


            }



        }



    }







    public function run():void
    {


        $this->boot();



        Router::dispatch();


    }








    private function registerErrors():void
    {


        if(class_exists(ErrorHandler::class)){


            ErrorHandler::register(
                $this->debug
            );


        }


    }









    private function loadHelpers():void
    {


        $files=[


            BASE_PATH.'/App/Support/helpers.php',


            BASE_PATH.'/App/Support/view_helper.php'


        ];




        foreach($files as $file){


            if(is_file($file)){


                require_once $file;


            }


        }




        if(!function_exists('h')){


            throw new RuntimeException(

                'No existe helper h()'

            );


        }



    }









    private function bootSession():void
    {


        if(
            session_status()
            !==
            PHP_SESSION_ACTIVE
        ){



            session_name(
                'CSDIERP'
            );



            session_set_cookie_params([


                'lifetime'=>0,


                'path'=>'/',


                'secure'=>
                    !empty($_SERVER['HTTPS'])
                    &&
                    $_SERVER['HTTPS']!=='off',


                'httponly'=>true,


                'samesite'=>'Lax'


            ]);



            session_start();


        }



    }









    private function bootDatabase():void
    {


        $file=
            BASE_PATH.'/config/database.php';




        if(!is_file($file)){


            throw new RuntimeException(

                'Falta config/database.php'

            );


        }





        $config=
            require $file;





        if(!is_array($config)){


            throw new RuntimeException(

                'Database config inválida'

            );


        }






        $database=
            new Database(
                $config
            );






        Container::getInstance()
            ->boot(

                $database->getConnection()

            );



    }









    private function bootServices():void
    {


        if(class_exists(ServiceProviderLoader::class)){


            ServiceProviderLoader::load();


        }




        $container=
            Container::getInstance();





        $services=[


            \App\Services\AI\IaService::class,


        ];





        foreach($services as $service){



            if(class_exists($service)){


                $container->singleton(

                    $service,

                    $service

                );


            }


        }



    }









    private function loadRoutes():void
    {


        $routes=[


            BASE_PATH.'/routes/web.php',


        ];





        foreach($routes as $file){


            if(is_file($file)){


                require_once $file;


            }


        }



    }









    public function isBooted():bool
    {

        return $this->booted;

    }









    public function reset():void
    {


        $this->booted=false;


        Router::reset();


        ModuleLoader::reset();


        Container::getInstance()
            ->reset();


    }



}