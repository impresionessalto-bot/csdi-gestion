<?php

declare(strict_types=1);

namespace App\Core;


/**
 * =========================================================
 * ERP CSDI PRO
 *
 * MODULE CORE V5
 *
 * Contrato único de módulos ERP
 *
 * Compatible con:
 * - ModuleLoader
 * - ModuleManager
 * - Config/routes.php
 * - Menú dinámico
 * - Permisos
 * - Widgets Dashboard
 *
 * =========================================================
 */

abstract class Module
{


    /*
    |--------------------------------------------------------------------------
    | INFORMACION BASICA
    |--------------------------------------------------------------------------
    */


    public function name():string
    {
        return static::class;
    }



    public function description():string
    {
        return '';
    }



    public function version():string
    {
        return '1.0.0';
    }



    public function slug():string
    {

        $parts = explode(
            '\\',
            static::class
        );


        return strtolower(

            str_replace(
                'Module',
                '',
                $parts[2] ?? 'module'
            )

        );

    }





    public function info():array
    {

        return [

            'name'=>
                $this->name(),

            'slug'=>
                $this->slug(),

            'description'=>
                $this->description(),

            'version'=>
                $this->version(),

            'enabled'=>
                $this->enabled(),

            'priority'=>
                $this->priority(),

            'permissions'=>
                $this->permissions(),

            'dependencies'=>
                $this->dependencies(),

        ];

    }






    /*
    |--------------------------------------------------------------------------
    | RUTAS
    |--------------------------------------------------------------------------
    */


    /**
     * Devuelve archivo Config/routes.php
     */
    public function routes():string
    {
        return '';
    }



    /**
     * Alias compatible con BaseModule
     */
    public function routesFile():?string
    {

        $file =
            $this->configPath()
            .
            '/routes.php';


        return file_exists($file)
            ? $file
            : null;

    }



    public function permissionsFile():?string
    {

        $file =
            $this->configPath()
            .
            '/permissions.php';


        return file_exists($file)
            ? $file
            : null;

    }





    /*
    |--------------------------------------------------------------------------
    | MENU
    |--------------------------------------------------------------------------
    */


    public function icon():string
    {
        return 'fa-solid fa-cube';
    }



    public function url():string
    {
        return '#';
    }



    public function group():string
    {
        return 'General';
    }



    public function order():int
    {
        return 100;
    }



    public function menu():array
    {

        return [

            [

                'title'=>
                    $this->name(),


                'icon'=>
                    $this->icon(),


                'url'=>
                    $this->url(),


                'group'=>
                    $this->group(),


                'order'=>
                    $this->order(),


                'permission'=>
                    $this->permissions()[0]
                    ??
                    null,


                'visible'=>
                    $this->enabled(),


                'children'=>[]

            ]

        ];

    }





    /*
    |--------------------------------------------------------------------------
    | PERMISOS
    |--------------------------------------------------------------------------
    */


    public function permissions():array
    {
        return [];
    }





    /*
    |--------------------------------------------------------------------------
    | DEPENDENCIAS
    |--------------------------------------------------------------------------
    */


    public function dependencies():array
    {
        return [];
    }





    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */


    public function widgets():array
    {
        return [];
    }



    public function kpis():array
    {
        return [];
    }





    /*
    |--------------------------------------------------------------------------
    | PRIORIDAD Y ESTADO
    |--------------------------------------------------------------------------
    */


    public function priority():int
    {
        return 100;
    }



    public function enabled():bool
    {
        return true;
    }





    /*
    |--------------------------------------------------------------------------
    | BOOT
    |--------------------------------------------------------------------------
    */


    public function boot():void
    {

    }





    /*
    |--------------------------------------------------------------------------
    | SISTEMA DE ARCHIVOS DEL MODULO
    |--------------------------------------------------------------------------
    */


    /**
     * Ruta física del módulo
     */
    public function path():string
    {

        $reflection =
            new \ReflectionClass($this);


        return dirname(
            $reflection->getFileName()
        );

    }





    public function configPath():string
    {
        return $this->path()
            .
            '/Config';
    }




    public function controllerPath():string
    {
        return $this->path()
            .
            '/Controllers';
    }




    public function servicePath():string
    {
        return $this->path()
            .
            '/Services';
    }




    public function repositoryPath():string
    {
        return $this->path()
            .
            '/Repositories';
    }




    public function dtoPath():string
    {
        return $this->path()
            .
            '/DTOs';
    }




    public function viewPath():string
    {
        return $this->path()
            .
            '/Views';
    }




    public function assetPath():string
    {
        return $this->path()
            .
            '/Assets';
    }





    /*
    |--------------------------------------------------------------------------
    | CONFIGURACION
    |--------------------------------------------------------------------------
    */


    public function config():array
    {

        return [

            'name'=>
                $this->name(),

            'slug'=>
                $this->slug(),

            'version'=>
                $this->version(),

            'enabled'=>
                $this->enabled(),

        ];

    }


}