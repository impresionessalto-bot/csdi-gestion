<?php

namespace App\Core\Contracts;


interface DashboardModule
{

    public function count():int;

    public function dashboard():array;

}