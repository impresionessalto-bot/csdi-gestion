<?php namespace App\Core;

class AIService {
    private $apiKey = "TU_OPENAI_API_KEY";

    public function preguntarAgente($rol, $tarea, $contexto) {
        $url = 'https://api.openai.com/v1/chat/completions';
        
        $data = [
            'model' => 'gpt-4o', // El más potente para redacción PRO
            'messages' => [
                ['role' => 'system', 'content' => $rol], // Ej: "Sos un experto en Marketing Tech"
                ['role' => 'user', 'content' => $tarea . "\nContexto: " . $contexto]
            ],
            'temperature' => 0.7 // Creatividad balanceada
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey
        ]);

        $response = curl_exec($ch);
        $result = json_decode($response, true);
        return $result['choices'][0]['message']['content'] ?? 'Error de conexión';
    }
}