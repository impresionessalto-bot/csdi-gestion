<?php

namespace App\Core\Traits;

use PDO;

trait SoftDeletes
{
    protected PDO $db;

    /**
     * BORRADO LÓGICO
     */
    public function softDelete(string $table, int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE {$table}
            SET deleted_at = NOW()
            WHERE id = :id
        ");

        return $stmt->execute(['id' => $id]);
    }

    /**
     * RESTAURAR REGISTRO
     */
    public function restore(string $table, int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE {$table}
            SET deleted_at = NULL
            WHERE id = :id
        ");

        return $stmt->execute(['id' => $id]);
    }

    /**
     * LISTADO ACTIVO (SOLO VIVOS)
     */
    public function findAllActive(string $table): array
    {
        return $this->db->query("
            SELECT *
            FROM {$table}
            WHERE deleted_at IS NULL
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * FIND BY ID SOLO ACTIVO
     */
    public function findActiveById(string $table, int $id): array|false
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM {$table}
            WHERE id = :id
            AND deleted_at IS NULL
        ");

        $stmt->execute(['id' => $id]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}