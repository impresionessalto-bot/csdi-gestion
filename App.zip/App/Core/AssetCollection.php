<?php
declare(strict_types=1);

namespace App\Core;

final class AssetCollection
{
    /**
     * @var array<string,array<string,mixed>>
     */
    private array $items = [];

    /**
     * Agrega un asset.
     */
    public function add(
        string $file,
        int $priority = 100,
        array $attributes = []
    ): void {

        $this->items[$file] = [

            'file'       => $file,
            'priority'   => $priority,
            'attributes' => $attributes,

        ];

    }

    /**
     * Elimina un asset.
     */
    public function remove(string $file): void
    {
        unset($this->items[$file]);
    }

    /**
     * Vacía la colección.
     */
    public function clear(): void
    {
        $this->items = [];
    }

    /**
     * ¿Existe?
     */
    public function has(string $file): bool
    {
        return isset($this->items[$file]);
    }

    /**
     * Cantidad.
     */
    public function count(): int
    {
        return count($this->items);
    }

    /**
     * Devuelve ordenados por prioridad.
     *
     * @return array<int,array<string,mixed>>
     */
    public function all(): array
    {
        $items = array_values($this->items);

        usort(
            $items,
            fn(array $a, array $b)
                => $a['priority'] <=> $b['priority']
        );

        return $items;
    }
}