<?php
declare(strict_types=1);

namespace App\Core;


/**
 * =========================================================
 * ERP CSDI PRO
 * SERVICE PROVIDER BASE
 * =========================================================
 *
 * Los Service Providers registran servicios
 * globales del sistema.
 *
 * Ejemplo:
 *
 * App\Providers\AppServiceProvider
 *
 * registra:
 *
 * PdfService
 * IaService
 * MailService
 * StorageService
 *
 * =========================================================
 */

abstract class ServiceProvider
{


    protected Container $container;




    public function __construct(
        Container $container
    )
    {

        $this->container = $container;

    }





    /**
     * Registro de servicios
     *
     * Cada Provider debe implementar
     */
    abstract public function register():void;



}