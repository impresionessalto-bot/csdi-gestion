<?php

declare(strict_types=1);

namespace App\Core;

use Closure;
use PDO;
use ReflectionClass;
use ReflectionNamedType;
use ReflectionParameter;
use RuntimeException;


final class Container
{

    private static ?self $instance = null;


    private ?PDO $db = null;


    private array $instances = [];


    private array $bindings = [];


    private array $singletons = [];


    private array $factories = [];


    private array $aliases = [];


    private array $building = [];



    private function __construct()
    {

    }




    public static function getInstance():self
    {

        if(!self::$instance){

            self::$instance = new self();

            self::$instance
                ->instances[self::class]
                =
                self::$instance;
        }


        return self::$instance;

    }





    public function boot(PDO $pdo):void
    {

        $this->db = $pdo;

        $this->registerDefaults();

    }





    public function db():PDO
    {

        if(!$this->db){

            throw new RuntimeException(
                'Base de datos no inicializada'
            );

        }


        return $this->db;

    }





    private function registerDefaults():void
    {


        $core = [

            Request::class,

            Response::class,

            ModuleManager::class,

            AssetManager::class,

        ];



        foreach($core as $class){


            $this->singleton(
                $class,
                $class
            );


        }





        $services=[


            \App\Dashboard\DashboardManager::class,


            \App\Dashboard\KpiRegistry::class,


            \App\Services\Permissions\PermissionService::class,


            \App\Services\Audit\AuditService::class,


            \App\Services\AI\IaService::class,


            \App\Services\Search\SearchService::class,


            \App\Services\ClientesService::class,


            \App\Services\EquiposService::class,


            \App\Services\ConfigService::class,


            \App\Services\RulesService::class,


            \App\Services\ReportService::class,


        ];




        foreach($services as $service){


            if(class_exists($service)){


                $this->singleton(
                    $service,
                    $service
                );


            }

        }


    }






    public function bind(
        string $abstract,
        string $concrete
    ):void
    {

        $this->bindings[$abstract]=$concrete;

    }






    public function singleton(
        string $abstract,
        string $concrete
    ):void
    {

        $this->singletons[$abstract]=$concrete;

    }







    public function factory(
        string $abstract,
        Closure $factory
    ):void
    {

        $this->factories[$abstract]=$factory;

    }







    public function alias(
        string $alias,
        string $abstract
    ):void
    {

        $this->aliases[$alias]=$abstract;

    }







    public function make(
        string $abstract
    ):mixed
    {


        if($abstract===self::class){

            return $this;

        }




        $abstract =
            $this->aliases[$abstract]
            ??
            $abstract;




        if(isset($this->instances[$abstract])){

            return $this->instances[$abstract];

        }




        if(isset($this->factories[$abstract])){

            return ($this->factories[$abstract])($this);

        }




        $concrete =
            $this->bindings[$abstract]
            ??
            $this->singletons[$abstract]
            ??
            $abstract;





        $object =
            $this->build($concrete);





        if(isset($this->singletons[$abstract])){

            $this->instances[$abstract]=$object;

        }



        return $object;

    }








    private function build(
        string $class
    ):object
    {


        if(!class_exists($class)){


            throw new RuntimeException(
                "Clase no encontrada: {$class}"
            );

        }



        if(isset($this->building[$class])){


            throw new RuntimeException(
                "Dependencia circular: {$class}"
            );

        }




        $this->building[$class]=true;




        try{


            $reflection =
                new ReflectionClass($class);



            $constructor =
                $reflection->getConstructor();




            if(!$constructor){

                return new $class();

            }




            $arguments=[];



            foreach($constructor->getParameters() as $parameter){


                $arguments[] =
                    $this->resolve($parameter);


            }




            return $reflection->newInstanceArgs(
                $arguments
            );


        }
        finally{


            unset($this->building[$class]);


        }


    }







    private function resolve(
        ReflectionParameter $parameter
    ):mixed
    {


        $type =
            $parameter->getType();




        if(
            $type instanceof ReflectionNamedType
            &&
            !$type->isBuiltin()
        )
        {


            $name =
                $type->getName();




            if($name===PDO::class){

                return $this->db();

            }



            return $this->make($name);

        }





        if($parameter->isDefaultValueAvailable()){

            return $parameter->getDefaultValue();

        }




        if($parameter->allowsNull()){

            return null;

        }



        throw new RuntimeException(
            "No se puede resolver: ".$parameter->getName()
        );


    }






    public function has(string $id):bool
    {

        return isset($this->instances[$id])
            ||
            isset($this->bindings[$id])
            ||
            isset($this->singletons[$id])
            ||
            class_exists($id);

    }






    public function reset():void
    {

        self::$instance=null;

        $this->db=null;

        $this->instances=[];

        $this->bindings=[];

        $this->singletons=[];

        $this->factories=[];

        $this->aliases=[];

        $this->building=[];

    }


}