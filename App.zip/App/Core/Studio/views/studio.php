<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ERP Studio</title>
    <style>
        body {
            font-family: Arial;
            background: #0f172a;
            color: white;
            padding: 30px;
        }

        .card {
            background: #1e293b;
            padding: 20px;
            border-radius: 10px;
            width: 500px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
        }

        button {
            padding: 10px;
            width: 100%;
            background: #22c55e;
            border: 0;
            color: white;
            cursor: pointer;
        }

        small {
            color: #94a3b8;
        }
    </style>
</head>
<body>

<h1>⚙ ERP Studio Visual</h1>

<div class="card">

<form method="POST">

    <label>Nombre del módulo</label>
    <input name="name" placeholder="cliente" required>

    <label>Tabla</label>
    <input name="table" placeholder="clientes" required>

    <label>Campos</label>
    <input name="fields" placeholder="nombre:string, telefono:string, email:string">

    <small>Formato: campo:tipo, campo:tipo</small>

    <br><br>

    <button type="submit">🚀 Generar módulo</button>

</form>

</div>

</body>
</html>