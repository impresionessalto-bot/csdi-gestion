<?php

namespace App\Core\Studio;

use App\Core\Studio\StudioService;

final class StudioController
{
    private StudioService $service;

    public function __construct()
    {
        $this->service = new StudioService();
    }

    public function handle(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->service->generate($_POST);
            return;
        }

        $this->view();
    }

    private function view(): void
    {
        echo file_get_contents(__DIR__ . '/views/studio.php');
    }
}