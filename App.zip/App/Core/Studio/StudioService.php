<?php

namespace App\Core\Studio;

use App\Core\Cli\Support\FileWriter;
use App\Core\Cli\Support\SchemaParser;

final class StudioService
{
    public function generate(array $data): void
    {
        $name  = $data['name'];
        $table = $data['table'];

        $fieldsRaw = explode(',', $data['fields']);
        $fields = SchemaParser::parse(array_map('trim', $fieldsRaw));

        FileWriter::makeModule($name, $table, $fields);
        FileWriter::makeViews($name, $fields);
        FileWriter::registerModule($name);

        echo "<h3>✔ Módulo '{$name}' generado correctamente</h3>";
        echo "<a href='/erp-studio.php'>Volver</a>";
    }
}