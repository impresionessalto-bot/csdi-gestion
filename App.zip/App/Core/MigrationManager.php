<?php
declare(strict_types=1);

namespace App\Core;

final class MigrationManager
{
    private \PDO $db;
    private string $migrationsPath;

    public function __construct(\PDO $db, string $migrationsPath)
    {
        $this->db = $db;
        $this->migrationsPath = rtrim($migrationsPath, '/');
        
        $this->ensureMigrationsTable();
    }

    private function ensureMigrationsTable(): void
    {
        $sql = "CREATE TABLE IF NOT EXISTS migrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            migration VARCHAR(255) NOT NULL UNIQUE,
            executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

        $this->db->exec($sql);
    }

    public function migrate(): array
    {
        $executed = [];
        $files = glob($this->migrationsPath . '/*.php');

        if ($files === false) {
            return $executed;
        }

        sort($files);

        $stmt = $this->db->query("SELECT migration FROM migrations");
        $applied = $stmt->fetchAll(\PDO::FETCH_COLUMN);

        foreach ($files as $file) {
            $migrationName = basename($file, '.php');

            if (!in_array($migrationName, $applied, true)) {
                $migrationInstance = require $file;

                if (is_object($migrationInstance) && method_exists($migrationInstance, 'up')) {
                    $migrationInstance->up($this->db);
                } elseif (function_exists('up')) {
                    up($this->db);
                }

                $stmt = $this->db->prepare("INSERT INTO migrations (migration) VALUES (:migration)");
                $stmt->execute(['migration' => $migrationName]);

                $executed[] = $migrationName;
            }
        }

        return $executed;
    }
}