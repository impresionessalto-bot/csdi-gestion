<?php

declare(strict_types=1);

namespace App\Core;

final class Validator
{
    private array $data;
    private array $rules;
    private array $errors = [];

    private function __construct(array $data, array $rules)
    {
        $this->data  = $data;
        $this->rules = $rules;
    }

    public static function make(array $data, array $rules): self
    {
        $validator = new self($data, $rules);
        $validator->validate();

        return $validator;
    }

    private function validate(): void
    {
        foreach ($this->rules as $field => $ruleString) {

            $value = $this->data[$field] ?? null;

            $rules = explode('|', $ruleString);

            foreach ($rules as $rule) {

                $parameter = null;

                if (str_contains($rule, ':')) {
                    [$rule, $parameter] = explode(':', $rule, 2);
                }

                switch ($rule) {

                    case 'required':

                        if (
                            $value === null ||
                            trim((string)$value) === ''
                        ) {

                            $this->addError(
                                $field,
                                'El campo es obligatorio.'
                            );
                        }

                        break;

                    case 'numeric':

                        if (
                            $value !== null &&
                            !is_numeric($value)
                        ) {

                            $this->addError(
                                $field,
                                'Debe ser numérico.'
                            );
                        }

                        break;

                    case 'integer':

                        if (
                            $value !== null &&
                            filter_var(
                                $value,
                                FILTER_VALIDATE_INT
                            ) === false
                        ) {

                            $this->addError(
                                $field,
                                'Debe ser un número entero.'
                            );
                        }

                        break;

                    case 'email':

                        if (
                            $value &&
                            !filter_var(
                                $value,
                                FILTER_VALIDATE_EMAIL
                            )
                        ) {

                            $this->addError(
                                $field,
                                'Email inválido.'
                            );
                        }

                        break;

                    case 'min':

                        if (
                            $value !== null &&
                            is_numeric($value) &&
                            $value < (float)$parameter
                        ) {

                            $this->addError(
                                $field,
                                "Debe ser mayor o igual a {$parameter}."
                            );
                        }

                        if (
                            is_string($value) &&
                            mb_strlen($value) < (int)$parameter
                        ) {

                            $this->addError(
                                $field,
                                "Debe tener al menos {$parameter} caracteres."
                            );
                        }

                        break;

                    case 'max':

                        if (
                            is_numeric($value) &&
                            $value > (float)$parameter
                        ) {

                            $this->addError(
                                $field,
                                "Debe ser menor o igual a {$parameter}."
                            );
                        }

                        if (
                            is_string($value) &&
                            mb_strlen($value) > (int)$parameter
                        ) {

                            $this->addError(
                                $field,
                                "No puede superar {$parameter} caracteres."
                            );
                        }

                        break;

                    case 'boolean':

                        if (
                            $value !== null &&
                            filter_var(
                                $value,
                                FILTER_VALIDATE_BOOLEAN,
                                FILTER_NULL_ON_FAILURE
                            ) === null
                        ) {

                            $this->addError(
                                $field,
                                'Debe ser verdadero o falso.'
                            );
                        }

                        break;

                    case 'date':

                        if (
                            $value &&
                            strtotime((string)$value) === false
                        ) {

                            $this->addError(
                                $field,
                                'Fecha inválida.'
                            );
                        }

                        break;

                    case 'in':

                        $values = explode(',', (string)$parameter);

                        if (
                            $value !== null &&
                            !in_array(
                                $value,
                                $values,
                                true
                            )
                        ) {

                            $this->addError(
                                $field,
                                'Valor no permitido.'
                            );
                        }

                        break;

                    case 'regex':

                        if (
                            $value &&
                            !preg_match(
                                (string)$parameter,
                                (string)$value
                            )
                        ) {

                            $this->addError(
                                $field,
                                'Formato inválido.'
                            );
                        }

                        break;
                }
            }
        }
    }

    private function addError(
        string $field,
        string $message
    ): void {

        $this->errors[$field][] = $message;
    }

    public function fails(): bool
    {
        return !empty($this->errors);
    }

    public function passes(): bool
    {
        return empty($this->errors);
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function first(string $field): ?string
    {
        return $this->errors[$field][0] ?? null;
    }
}