<?php

declare(strict_types=1);

namespace App\Core;

final class WebSocket
{
    public static function broadcast(array $data): void
    {
        // Bridge futuro Redis / Node / Socket.io
    }

    public static function lock(
        int $equipoId,
        int $userId
    ): void {

        // lock row future
    }

    public static function unlock(
        int $equipoId
    ): void {

        // unlock row future
    }
}