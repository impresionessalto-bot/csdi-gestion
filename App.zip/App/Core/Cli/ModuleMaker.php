<?php

declare(strict_types=1);

namespace App\Core\Cli;

final class ModuleMaker
{
    public function __construct(
        private array $argv
    ) {}

    public function run(): void
    {
        $name  = $this->argv[2] ?? null;
        $table = $this->argv[3] ?? null;

        if (!$name || !$table) {
            echo "❌ Uso: make:module nombre tabla fields\n";
            return;
        }

        $fieldsRaw = array_slice($this->argv, 4);
        $fields = $this->parseFields($fieldsRaw);

        $this->makeRepository($name, $table, $fields);
        $this->makeService($name);
        $this->makeController($name);

        echo "✔ Módulo {$name} creado correctamente\n";
    }

    private function parseFields(array $fieldsRaw): array
    {
        $fields = [];

        foreach ($fieldsRaw as $field) {
            [$name, $type] = explode(':', $field);
            $fields[$name] = $type;
        }

        return $fields;
    }

    private function makeRepository(string $name, string $table, array $fields): void
    {
        $class = ucfirst($name);

        $fieldsInsert = implode(', ', array_keys($fields));
        $placeholders = implode(', ', array_fill(0, count($fields), '?'));

        $setUpdate = implode(",\n            ", array_map(
            fn($f) => "$f = ?",
            array_keys($fields)
        ));

        $code = <<<PHP
<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class {$class}Repository
{
    public function __construct(private PDO \$pdo) {}

    public function all(): array
    {
        return \$this->pdo->query("SELECT * FROM {$table} ORDER BY id DESC")
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function find(int \$id): ?array
    {
        \$stmt = \$this->pdo->prepare("SELECT * FROM {$table} WHERE id = ?");
        \$stmt->execute([\$id]);

        return \$stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function insert(array \$data): int
    {
        \$stmt = \$this->pdo->prepare("
            INSERT INTO {$table} ({$fieldsInsert})
            VALUES ({$placeholders})
        ");

        \$stmt->execute([
            {$this->mapFields($fields)}
        ]);

        return (int)\$this->pdo->lastInsertId();
    }

    public function update(int \$id, array \$data): bool
    {
        \$stmt = \$this->pdo->prepare("
            UPDATE {$table}
            SET {$setUpdate}
            WHERE id = ?
        ");

        return \$stmt->execute([
            {$this->mapFields($fields)},
            \$id
        ]);
    }

    public function delete(int \$id): bool
    {
        \$stmt = \$this->pdo->prepare("DELETE FROM {$table} WHERE id = ?");
        return \$stmt->execute([\$id]);
    }
}
PHP;

        $this->write("App/Repositories/{$class}Repository.php", $code);
    }

    private function makeService(string $name): void
    {
        $class = ucfirst($name);

        $code = <<<PHP
<?php

declare(strict_types=1);

namespace App\Services;

use App\Repositories\\{$class}Repository;

final class {$class}Service
{
    public function __construct(private {$class}Repository \$repo) {}

    public function list(): array
    {
        return \$this->repo->all();
    }

    public function get(int \$id): ?array
    {
        return \$this->repo->find(\$id);
    }

    public function create(array \$data): int
    {
        return \$this->repo->insert(\$data);
    }

    public function update(int \$id, array \$data): bool
    {
        return \$this->repo->update(\$id, \$data);
    }

    public function delete(int \$id): bool
    {
        return \$this->repo->delete(\$id);
    }
}
PHP;

        $this->write("App/Services/{$class}Service.php", $code);
    }

    private function makeController(string $name): void
    {
        $class = ucfirst($name);

        $code = <<<PHP
<?php

declare(strict_types=1);

namespace App\Controllers;

use PDO;
use App\Repositories\\{$class}Repository;
use App\Services\\{$class}Service;

final class {$class}Controller
{
    private {$class}Service \$service;

    public function __construct(PDO \$pdo)
    {
        \$repo = new {$class}Repository(\$pdo);
        \$this->service = new {$class}Service(\$repo);
    }

    public function index(): void
    {
        \$items = \$this->service->list();
        require BASE_PATH . '/App/Views/{$name}/index.php';
    }

    public function show(int \$id): void
    {
        \$item = \$this->service->get(\$id);
        require BASE_PATH . '/App/Views/{$name}/show.php';
    }

    public function store(): void
    {
        \$id = \$this->service->create(\$_POST);
        header("Location: /{$name}/show?id=" . \$id);
        exit;
    }

    public function update(int \$id): void
    {
        \$this->service->update(\$id, \$_POST);
        header("Location: /{$name}/show?id=" . \$id);
        exit;
    }

    public function delete(int \$id): void
    {
        \$this->service->delete(\$id);
        header("Location: /{$name}");
        exit;
    }
}
PHP;

        $this->write("App/Controllers/{$class}Controller.php", $code);
    }

    private function mapFields(array $fields): string
    {
        return implode(",\n            ", array_map(
            fn($k) => "\$data['$k'] ?? null",
            array_keys($fields)
        ));
    }

    private function write(string $path, string $content): void
    {
        $full = __DIR__ . '/../../../../' . $path;
        $dir = dirname($full);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        file_put_contents($full, $content);
    }
}