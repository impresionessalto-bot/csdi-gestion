<?php

declare(strict_types=1);

namespace App\Core\Cli;

use App\Core\Cli\Commands\MakeModule;
use App\Core\Cli\Commands\MakeMigration;
use App\Core\Cli\Commands\MakeApi;

final class Kernel
{
    public function __construct(private array $argv) {}

    public function handle(): void
    {
        $cmd = $this->argv[1] ?? null;

        match ($cmd) {
            'make:module'   => (new MakeModule($this->argv))->run(),
            'make:migration'=> (new MakeMigration($this->argv))->run(),
            'make:api'      => (new MakeApi($this->argv))->run(),
            'make:crud'     => (new MakeModule($this->argv, true))->run(),
            default         => $this->help()
        };
    }

    private function help(): void
    {
        echo "
ERP CLI V2

Commands:
  make:module
  make:migration
  make:api
  make:crud

Example:
  php erp.php make:crud cliente clientes nombre:string telefono:string
";
    }
}