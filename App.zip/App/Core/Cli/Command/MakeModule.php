<?php

declare(strict_types=1);

namespace App\Core\Cli\Commands;

use App\Core\Cli\Support\FileWriter;
use App\Core\Cli\Support\SchemaParser;

final class MakeModule
{
    public function __construct(
        private array $argv,
        private bool $fullCrud = false
    ) {}

    public function run(): void
    {
        $name  = $this->argv[2] ?? null;
        $table = $this->argv[3] ?? null;

        $fieldsRaw = array_slice($this->argv, 4);
        $fields = SchemaParser::parse($fieldsRaw);

        FileWriter::makeModule($name, $table, $fields);

        if ($this->fullCrud) {
            FileWriter::makeViews($name, $fields);
            FileWriter::registerModule($name);
        }

        echo "✔ Módulo V2 creado: {$name}\n";
    }
}