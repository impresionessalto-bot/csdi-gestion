<?php

declare(strict_types=1);

namespace App\Core\Cli\Commands;

use App\Core\Cli\Support\FileWriter;

final class MakeMigration
{
    public function __construct(private array $argv) {}

    public function run(): void
    {
        $name = $this->argv[2] ?? null;
        $table = $this->argv[3] ?? null;

        $fields = array_slice($this->argv, 4);

        $sql = FileWriter::generateSQL($table, $fields);

        $file = date('Y_m_d_His') . "_create_{$table}.sql";

        file_put_contents(__DIR__ . "/../../../../database/migrations/{$file}", $sql);

        echo "✔ Migración creada: {$file}\n";
    }
}