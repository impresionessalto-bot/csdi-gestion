<?php
final class View
{
    public static function render(string $view, array $data = []): void
    {
        extract($data);

        $contentView = $view;

        require BASE_PATH . '/App/Views/layouts/app.php';
    }
}
/** @var array $equipos */
$equipos = $equipos ?? [];
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">Equipos</h3>

        <a href="/equipos/create" class="btn btn-primary">
            + Nuevo Equipo
        </a>
    </div>

    <!-- FILTRO SIMPLE -->
    <form method="GET" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <input type="text" name="buscar" class="form-control"
                       placeholder="Buscar por serial, cliente o ubicación">
            </div>

            <div class="col-md-2">
                <button class="btn btn-secondary w-100">Buscar</button>
            </div>
        </div>
    </form>

    <!-- TABLA -->
    <div class="card">
        <div class="card-body p-0">

            <table class="table table-striped table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Modelo</th>
                        <th>Serial</th>
                        <th>Ubicación</th>
                        <th>Contador</th>
                        <th>Estado</th>
                        <th width="160">Acciones</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (empty($equipos)): ?>
                    <tr>
                        <td colspan="8" class="text-center p-4">
                            No hay equipos cargados
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($equipos as $eq): ?>
                        <tr>
                            <td><?= (int)$eq['id'] ?></td>
                            <td><?= htmlspecialchars($eq['cliente_nombre'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($eq['modelo_nombre'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($eq['serial'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($eq['ubicacion'] ?? '-') ?></td>
                            <td><?= (int)($eq['contador_base'] ?? 0) ?></td>
                            <td>
                                <span class="badge bg-<?= ($eq['estado'] ?? '') === 'Activo' ? 'success' : 'secondary' ?>">
                                    <?= htmlspecialchars($eq['estado'] ?? 'Sin estado') ?>
                                </span>
                            </td>
                            <td>
                                <a href="/equipos/<?= $eq['id'] ?>/edit" class="btn btn-sm btn-warning">
                                    Editar
                                </a>

                                <a href="/equipos/<?= $eq['id'] ?>/delete"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('¿Eliminar equipo?')">
                                    Borrar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>

            </table>

        </div>
    </div>

</div>