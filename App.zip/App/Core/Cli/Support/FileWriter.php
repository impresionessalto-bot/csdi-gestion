<?php

declare(strict_types=1);

namespace App\Core\Cli\Support;

final class FileWriter
{
    public static function makeModule($name, $table, $fields): void
    {
        $class = ucfirst($name);

        $repo = self::repo($class, $table, $fields);
        $service = self::service($class);
        $controller = self::controller($class);

        self::write("App/Repositories/{$class}Repository.php", $repo);
        self::write("App/Services/{$class}Service.php", $service);
        self::write("App/Controllers/{$class}Controller.php", $controller);
    }

    public static function makeViews($name, $fields): void
    {
        self::write("App/Views/{$name}/index.php", "<h1>{$name}</h1>");
    }

    public static function registerModule($name): void
    {
        $file = __DIR__ . '/../../../../App/Core/modules.php';

        file_put_contents($file, "\n'{$name}',", FILE_APPEND);
    }

    public static function generateSQL($table, $fields): string
    {
        $cols = [];

        foreach ($fields as $f) {
            [$name, $type] = explode(':', $f);

            $sqlType = match ($type) {
                'int' => 'INT',
                'string' => 'VARCHAR(255)',
                default => 'TEXT'
            };

            $cols[] = "{$name} {$sqlType}";
        }

        return "CREATE TABLE {$table} (
id INT AUTO_INCREMENT PRIMARY KEY,
" . implode(",\n", $cols) . "
);";
    }

    private static function repo($class, $table, $fields): string
    {
        return "<?php
namespace App\Repositories;

use PDO;

final class {$class}Repository {
    public function __construct(private PDO \$pdo) {}

    public function all(){ return \$this->pdo->query('SELECT * FROM {$table}')->fetchAll(); }
}";
    }

    private static function service($class): string
    {
        return "<?php
namespace App\Services;

final class {$class}Service {
    public function __construct(private \$repo) {}
    public function list(){ return \$this->repo->all(); }
}";
    }

    private static function controller($class): string
    {
        return "<?php
namespace App\Controllers;

final class {$class}Controller {}";
    }

    private static function write($path, $content): void
    {
        $full = __DIR__ . '/../../../../' . $path;
        if (!is_dir(dirname($full))) mkdir(dirname($full), 0777, true);
        file_put_contents($full, $content);
    }
}