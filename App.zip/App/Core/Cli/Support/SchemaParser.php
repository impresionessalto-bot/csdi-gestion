<?php

declare(strict_types=1);

namespace App\Core\Cli\Support;

final class SchemaParser
{
    public static function parse(array $fields): array
    {
        $result = [];

        foreach ($fields as $field) {
            [$name, $type] = explode(':', $field);
            $result[$name] = $type;
        }

        return $result;
    }
}