<?php namespace App\Core;

/**
 * SERVICIO DE INTEGRACIÓN INTEGRAL DUX SOFTWARE
 * UBICACIÓN: /App/Core/DuxService.php
 * CARACTERÍSTICAS: Soporte GET/POST, Gestión de Errores IIS, Consultas de Catálogo.
 */
class DuxService {
    
    private $url_base = "https://erp.duxsoftware.com.ar/WSERP/rest/services";
    private $token;

    public function __construct() {
        global $conn;
        // Obtenemos el token desde la configuración global
        $res = $conn->query("SELECT valor FROM configuracion_sistema WHERE clave = 'dux_api_token' LIMIT 1");
        $this->token = $res->fetch_assoc()['valor'] ?? '';
    }

    /**
     * MOTOR DE PETICIONES (Maneja la comunicación cURL)
     */
    private function call(string $endpoint, string $method = 'GET', array $data = null) {
        if (empty($this->token)) {
            return ['success' => false, 'message' => "Token de API no configurado."];
        }

        $url = $this->url_base . $endpoint;
        $ch = curl_init($url);
        
        $headers = [
            'Content-Type: application/json',
            'api-token: ' . $this->token
        ];

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Fix para servidores Windows/IIS

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            return ['success' => false, 'message' => "Error de conexión: " . $err];
        }

        $decoded = json_decode($response, true);

        if ($http_code >= 200 && $http_code < 300) {
            return ['success' => true, 'data' => $decoded];
        }

        return [
            'success' => false, 
            'message' => "Error Dux ($http_code): " . ($decoded['message'] ?? 'Respuesta inválida'),
            'detail' => $decoded
        ];
    }

    // ============================================================
    // MÉTODOS DE ACCIÓN (POST)
    // ============================================================

    /**
     * Crea un nuevo pedido de venta
     */
    public function crearPedido(array $data_pedido) {
        return $this->call('/pedido/nuevopedido', 'POST', $data_pedido);
    }

    // ============================================================
    // MÉTODOS DE CONSULTA (GET)
    // ============================================================

    /**
     * Obtiene la lista de artículos/servicios de Dux
     * Útil para buscar los IDs de "Excedente B&N" o "Tóner"
     */
    public function obtenerArticulos() {
        return $this->call('/articulo/listado', 'GET');
    }

    /**
     * Obtiene los clientes creados en Dux
     */
    public function obtenerClientes() {
        return $this->call('/cliente/listado', 'GET');
    }

    /**
     * Consulta el estado de un pedido específico
     */
    public function consultarPedido(int $id_pedido) {
        return $this->call("/pedido/consultar?id=$id_pedido", 'GET');
    }
}