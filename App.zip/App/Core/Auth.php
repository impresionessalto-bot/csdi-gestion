<?php

declare(strict_types=1);

namespace App\Core;


final class Auth
{


    private static function start(): void
    {

        if(
            session_status() === PHP_SESSION_NONE
        ){

            session_start();

        }

    }





    public static function user(): array
    {

        self::start();

        return $_SESSION['user'] ?? [];

    }







    public static function check(): bool
    {

        self::start();

        return !empty(
            $_SESSION['user']['id']
        );

    }







    public static function id(): ?int
    {

        self::start();


        return isset(
            $_SESSION['user']['id']
        )
        ?
        (int)$_SESSION['user']['id']
        :
        null;

    }








    public static function role(): ?string
    {

        self::start();


        return

            $_SESSION['user']['role']
            ??
            $_SESSION['user']['rol']
            ??
            null;

    }









    public static function isAdmin(): bool
    {

        return self::role()==='admin';

    }








    public static function login(
        array $user
    ): void
    {


        self::start();


        session_regenerate_id(true);



        $id =
            $user['id']
            ??
            0;



        $rol =
            $user['rol']
            ??
            $user['role']
            ??
            'usuario';



        $nombre =
            $user['nombre']
            ??
            $user['name']
            ??
            'Usuario';




        $_SESSION['user']=[


            'id'=>
                (int)$id,


            'role'=>
                $rol,


            'rol'=>
                $rol,


            'nombre'=>
                $nombre,


            'usuario'=>
                $user['usuario']
                ??
                $nombre,


            'es_superadmin'=>

                (int)(
                    $user['es_superadmin']
                    ??
                    0
                )


        ];

    }









    public static function logout(): void
    {

        self::start();


        $_SESSION=[];



        if(
            ini_get('session.use_cookies')
        ){

            $params =
                session_get_cookie_params();


            setcookie(

                session_name(),

                '',

                time()-42000,

                $params['path'],

                $params['domain'],

                $params['secure'],

                $params['httponly']

            );

        }


        session_destroy();

    }





}