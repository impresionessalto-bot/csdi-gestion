<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use Throwable;
use RuntimeException;
use App\Core\AssetManager;

/**
 * =========================================================
 *
 * ERP CSDI PRO
 *
 * BASE CONTROLLER V11 BLINDADO
 *
 * Controlador padre ERP
 *
 * Soporta:
 *
 * - Views globales
 * - Views módulos
 * - Layouts
 * - PDO
 * - Request
 * - Response
 * - Auth
 * - CSRF
 * - JSON Responses
 * - Exception Handling
 *
 * =========================================================
 */
abstract class BaseController
{
    protected PDO $db;

    protected Request $request;

    protected Response $response;
	
    // CORRECCIÓN SINTÁCTICA: Hacemos la propiedad nullable por defecto para evitar crashes de inicialización bajo PHP 8.3
    protected ?AssetManager $assets = null;

    public function __construct(
        ?Request $request = null,
        ?Response $response = null
    ) {
        $container = Container::getInstance();

        $this->db = $container->db();

        $this->request = $request
            ??
            $container->make(
                Request::class
            );

        $this->response = $response
            ??
            $container->make(
                Response::class
            );

        $this->assets = $container->make(
            AssetManager::class
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VIEW GLOBAL
    |--------------------------------------------------------------------------
    */
    protected function view(
        string $view,
        array $data = [],
        ?string $layout = 'app'
    ): void {
        $view = str_replace('.', '/', $view);

        $file = BASE_PATH . '/App/Views/' . $view . '.php';

        /*
         * Si no existe en App/Views,
         * buscar automáticamente en todos los módulos.
         */
        if (!is_file($file)) {
            foreach (glob(BASE_PATH . '/App/Modules/*/Views', GLOB_ONLYDIR) as $viewsPath) {
                $candidate = $viewsPath . '/' . $view . '.php';

                if (is_file($candidate)) {
                    $file = $candidate;
                    break;
                }
            }
        }

        if (!is_file($file)) {
            throw new RuntimeException(
                "Vista no encontrada: {$view}"
            );
        }

        extract($data, EXTR_SKIP);

        ob_start();

        require $file;

        $content = ob_get_clean();

        if ($layout) {
            $layoutFile =
                BASE_PATH .
                '/App/Views/layouts/' .
                $layout .
                '.php';

            if (is_file($layoutFile)) {
                require $layoutFile;
                return;
            }
        }

        echo $content;
    }

    /*
    |--------------------------------------------------------------------------
    | VIEW MODULO
    |--------------------------------------------------------------------------
    */
    protected function moduleView(
        string $module,
        string $view,
        array $data=[],
        string $layout='app'
    ): void {
        $file =
            BASE_PATH
            .
            '/App/Modules/'
            .
            $module
            .
            '/Views/'
            .
            $view
            .
            '.php';

        if (!is_file($file)) {
            throw new RuntimeException(
                "Vista módulo no encontrada: {$module}/{$view}"
            );
        }

        extract($data, EXTR_SKIP);

        ob_start();

        require $file;

        $content = ob_get_clean();

        if ($layout) {
            $layoutFile =
                BASE_PATH
                .
                '/App/Views/layouts/'
                .
                $layout
                .
                '.php';

            if (is_file($layoutFile)) {
                require $layoutFile;
                return;
            }
        }

        echo $content;
    }

    /*
    |--------------------------------------------------------------------------
    | REDIRECT
    |--------------------------------------------------------------------------
    */
    protected function redirect(
        string $url
    ): never {
        Response::redirect($url);
    }

    /*
    |--------------------------------------------------------------------------
    | JSON
    |--------------------------------------------------------------------------
    */
    protected function json(
        array $data,
        int $status=200
    ): never {
        Response::json(
            $data,
            $status
        );
    }
	
    /*
    |--------------------------------------------------------------------------
    | RESPONSE HELPERS
    |--------------------------------------------------------------------------
    */
    protected function success(
        mixed $data=[],
        string $message='OK'
    ): never {
        Response::success(
            $data,
            $message
        );
    }

    protected function ok(
        mixed $data=[],
        string $message='OK'
    ): never {
        $this->success(
            $data,
            $message
        );
    }

    protected function fail(
        string|Throwable $message,
        int $status=500,
        array $errors=[]
    ): never {
        if ($message instanceof Throwable) {
            $text = $message->getMessage();

            if (
                defined('APP_DEBUG')
                &&
                APP_DEBUG
            ) {
                $errors = [
                    'exception' => get_class($message),
                    'file'      => $message->getFile(),
                    'line'      => $message->getLine()
                ];
            }
        } else {
            $text = $message;
        }

        Response::error(
            $text,
            $status,
            $errors
        );
    }

    protected function created(
        mixed $data=[],
        string $message='Registro creado'
    ): never {
        Response::created(
            $data,
            $message
        );
    }

    protected function validation(
        array $errors
    ): never {
        Response::validation(
            $errors
        );
    }

    protected function unauthorized(
        string $message='No autorizado'
    ): never {
        Response::unauthorized(
            $message
        );
    }

    protected function forbidden(
        string $message='Acceso denegado'
    ): never {
        Response::forbidden(
            $message
        );
    }

    protected function notFound(
        string $message='Registro no encontrado'
    ): never {
        Response::notFound(
            $message
        );
    }

    /*
    |--------------------------------------------------------------------------
    | AUTH
    |--------------------------------------------------------------------------
    */
    protected function user(): array
    {
        return Auth::user();
    }

    protected function userId(): ?int
    {
        return Auth::id();
    }

    protected function role(): ?string
    {
        return Auth::role();
    }

    protected function requireAuth(): void
    {
        if (!Auth::check()) {
            $this->redirect(
                '/login'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */
    protected function csrf(): string
    {
        if (
            session_status()
            !==
            PHP_SESSION_ACTIVE
        ) {
            session_start();
        }

        if (
            empty($_SESSION['_csrf'])
        ) {
            $_SESSION['_csrf']
                =
                bin2hex(
                    random_bytes(32)
                );
        }

        return $_SESSION['_csrf'];
    }

    protected function validateCsrf(): bool
    {
        if (
            session_status()
            !==
            PHP_SESSION_ACTIVE
        ) {
            session_start();
        }

        $token = $this->request->csrf();

        if (
            !$token
            ||
            empty($_SESSION['_csrf'])
        ) {
            return false;
        }

        return hash_equals(
            $_SESSION['_csrf'],
            (string)$token
        );
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS
    |--------------------------------------------------------------------------
    */
    protected function asset(
        string $path
    ): string {
        return '/assets/'
            .
            ltrim(
                $path,
                '/'
            );
    }

    protected function baseUrl(): string
    {
        return rtrim(
            dirname(
                $_SERVER['SCRIPT_NAME']
                ??
                ''
            ),
            '/'
        );
    }

    protected function e(
        mixed $value
    ): string {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | EXCEPTION HANDLER
    |--------------------------------------------------------------------------
    */
    protected function exception(
        Throwable $e
    ): void {
        if (
            defined('APP_DEBUG')
            &&
            APP_DEBUG
        ) {
            throw $e;
        }

        Response::error(
            'Error interno del servidor',
            500
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ASSET MANAGER
    |--------------------------------------------------------------------------
    */
    protected function addCss(
        string $file
    ): void {
        $this->getAssetManager()
            ->addCss($file);
    }

    protected function addJs(
        string $file
    ): void {
        $this->getAssetManager()
            ->addJs($file);
    }

    protected function assets(): AssetManager
    {
        return $this->getAssetManager();
    }

    private function getAssetManager(): AssetManager
    {
        if ($this->assets === null) {
            $this->assets =
                Container::getInstance()
                    ->make(
                        AssetManager::class
                    );
        }

        return $this->assets;
    }
}