<?php

declare(strict_types=1);

namespace App\Core;

/**
 * =========================================================
 * BASE ADMIN CONTROLLER
 * =========================================================
 *
 * Todos los controladores administrativos deben heredar de aquí.
 * La autenticación se realiza automáticamente.
 * La validación de administrador ya está implementada
 * en BaseController.
 */

abstract class BaseAdminController extends BaseController
{
    /**
     * Layout por defecto para el panel administrativo.
     */
    protected string $layout = 'layouts.admin';

    public function __construct()
    {
        parent::__construct();

        // Todo controlador administrativo requiere usuario autenticado.
        $this->requireAuth();
    }

    /* =========================================================
       RENDER
    ========================================================= */

    protected function render(string $view, array $data = []): void
    {
        // Validación centralizada en BaseController
        $this->requireAdmin();

        $this->view($view, $data);
    }

    /* =========================================================
       FLASH MESSAGES
    ========================================================= */

    protected function flash(string $type, string $message): void
    {
        $_SESSION['flash'] = [
            'type'    => $type,
            'message' => $message,
        ];
    }

    protected function getFlash(): ?array
    {
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);

        return $flash;
    }
}