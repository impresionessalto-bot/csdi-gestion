<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use RuntimeException;
use Throwable;


final class Database
{


    private PDO $connection;





    /*
    |--------------------------------------------------------------------------
    | CONSTRUCTOR
    |--------------------------------------------------------------------------
    */


    public function __construct(
        array $config
    )
    {


        $this->connect(
            $config
        );


    }









    private function connect(
        array $config
    ):void
    {


        $required = [

            'host',
            'dbname',
            'user',
            'pass'

        ];





        foreach($required as $key){


            if(!array_key_exists($key,$config)){


                throw new RuntimeException(

                    "Configuración DB faltante: {$key}"

                );


            }


        }








        $host =
            $config['host'];



        $port =
            $config['port']
            ??
            3306;



        $dbname =
            $config['dbname'];



        $charset =
            $config['charset']
            ??
            'utf8mb4';






        $dsn =
            sprintf(

                "mysql:host=%s;port=%s;dbname=%s;charset=%s",

                $host,

                $port,

                $dbname,

                $charset

            );








        try {


            $this->connection =
                new PDO(

                    $dsn,

                    $config['user'],

                    $config['pass'],

                    [


                        PDO::ATTR_ERRMODE =>
                            PDO::ERRMODE_EXCEPTION,


                        PDO::ATTR_DEFAULT_FETCH_MODE =>
                            PDO::FETCH_ASSOC,


                        PDO::ATTR_EMULATE_PREPARES =>
                            false,


                        PDO::ATTR_STRINGIFY_FETCHES =>
                            false,


                        PDO::ATTR_PERSISTENT =>
                            false


                    ]

                );




        }
        catch(PDOException $e){



            /*
            |--------------------------------------------------
            | No mostrar datos sensibles
            |--------------------------------------------------
            */


            throw new RuntimeException(

                'No se pudo conectar a la base de datos.',

                500,

                $e

            );



        }


    }









    /*
    |--------------------------------------------------------------------------
    | CONNECTION
    |--------------------------------------------------------------------------
    */


    public function getConnection():PDO
    {

        return $this->connection;

    }









    /*
    |--------------------------------------------------------------------------
    | TEST
    |--------------------------------------------------------------------------
    */


    public function connected():bool
    {


        try {


            return $this->connection->query(
                'SELECT 1'
            ) !== false;



        }
        catch(Throwable){


            return false;


        }


    }









    /*
    |--------------------------------------------------------------------------
    | TRANSACTIONS
    |--------------------------------------------------------------------------
    */


    public function begin():void
    {

        $this->connection->beginTransaction();

    }





    public function commit():void
    {

        $this->connection->commit();

    }





    public function rollback():void
    {

        if(
            $this->connection->inTransaction()
        ){

            $this->connection->rollBack();

        }

    }







    /*
    |--------------------------------------------------------------------------
    | CLOSE
    |--------------------------------------------------------------------------
    */


    public function close():void
    {

        unset(
            $this->connection
        );

    }


}