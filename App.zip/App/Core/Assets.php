<?php

declare(strict_types=1);

namespace App\Core;

final class Assets
{
    private static string $baseUrl = '';

    public static function init(): void
    {
        $scriptName = $_SERVER['SCRIPT_NAME'] ?? '/';

        // elimina index.php SI existe
        $base = str_replace('index.php', '', $scriptName);

        // normaliza slashes
        $base = rtrim(str_replace('\\', '/', $base), '/');

        self::$baseUrl = $base === '' ? '' : $base;
    }

    public static function url(string $path): string
    {
        $path = ltrim($path, '/');

        $fullPath = BASE_PATH . '/' . $path;

        // cache busting seguro
        if (is_file($fullPath)) {
            $version = filemtime($fullPath);
        } else {
            $version = time();
        }

        return self::$baseUrl . '/' . $path . '?v=' . $version;
    }

    /**
     * Debug helper ERP
     */
    public static function debug(): array
    {
        return [
            'baseUrl' => self::$baseUrl,
            'script'  => $_SERVER['SCRIPT_NAME'] ?? null,
        ];
    }
}