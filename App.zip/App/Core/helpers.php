<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| GLOBAL HELPERS UNIFICADOS (Ferozo Certified)
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| SANEAMIENTO HTML ESCAPE
|--------------------------------------------------------------------------
*/
if (!function_exists('html')) {
    function html(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Alias de compatibilidad legacy para h()
if (!function_exists('h')) {
    function h(mixed $value): string
    {
        return html($value);
    }
}

/*
|--------------------------------------------------------------------------
| BASE URL & RUTAS
|--------------------------------------------------------------------------
*/
if (!function_exists('base_url')) {
    function base_url(string $path = ''): string
    {
        $base = defined('BASE_URL')
            ? rtrim((string) BASE_URL, '/')
            : '';

        $path = trim($path, '/');

        if ($path === '') {
            return $base !== '' ? $base : '/';
        }

        if ($base === '') {
            return '/' . $path;
        }

        return $base . '/' . $path;
    }
}

if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        return base_url($path);
    }
}

if (!function_exists('route')) {
    function route(string $path = ''): string
    {
        return base_url($path);
    }
}

/*
|--------------------------------------------------------------------------
| NUEVO: ASSETS ENRUTADOR (Requerido por layouts/app.php)
|--------------------------------------------------------------------------
*/
if (!function_exists('asset')) {
    /**
     * Define la ruta URL pública de descarga de recursos estáticos (CSS/JS) en el navegador.
     */
    function asset(string $path): string
    {
        return '/assets/' . ltrim($path, '/');
    }
}

/*
|--------------------------------------------------------------------------
| NUEVO: RENDERIZADOR DE COMPONENTES DE VISTA (Requerido por StandardCard)
|--------------------------------------------------------------------------
*/
if (!function_exists('view')) {
    /**
     * Helper global para compilar y renderizar vistas y componentes en CSDI PRO.
     */
    function view(string $viewPath, array $data = []): string
    {
        // 1. Resolvemos la ruta física relativa a la raíz de tu proyecto
        $viewFile = BASE_PATH . '/' . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $viewPath) . '.php';

        // 2. Si no se encuentra en la raíz, buscamos dentro de la carpeta estándar de vistas
        if (!file_exists($viewFile)) {
            $viewFile = BASE_PATH . '/App/Views/' . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $viewPath) . '.php';
        }

        if (!file_exists($viewFile)) {
            return "<!-- Error de CSDI UI Framework: No se pudo cargar la vista en [{$viewFile}] -->";
        }

        // Extracción de variables de forma segura
        extract($data, EXTR_SKIP);

        // Capturamos el buffer en memoria para retornar la cadena de texto HTML limpia
        ob_start();
        try {
            require $viewFile;
        } catch (\Throwable $e) {
            ob_end_clean();
            return "<!-- Error al renderizar la plantilla: " . htmlspecialchars($e->getMessage()) . " -->";
        }

        return ob_get_clean();
    }
}