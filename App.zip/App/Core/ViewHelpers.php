<?php

declare(strict_types=1);

namespace App\Core;

/**
 * ============================================================================
 * CSDI ERP PRO
 * VIEW HELPERS
 * ============================================================================
 *
 * Helpers generales para presentación de datos en vistas.
 *
 * IMPORTANTE:
 * - No contienen lógica de negocio.
 * - No realizan consultas SQL.
 * - No dependen de PDO.
 * - Su única responsabilidad es presentar datos de forma segura.
 * ============================================================================
 */

/**
 * Escapa cualquier valor para HTML.
 */
if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}


/**
 * Devuelve un texto seguro o un fallback.
 */
if (!function_exists('counterValue')) {
    function counterValue(
        mixed $value,
        string $fallback = '-'
    ): string {
        $value = trim((string)($value ?? ''));

        return $value !== ''
            ? $value
            : $fallback;
    }
}


/**
 * Formatea números del ERP.
 */
if (!function_exists('counterNumber')) {
    function counterNumber(
        mixed $value,
        int $decimals = 0
    ): string {
        return number_format(
            (float)($value ?? 0),
            $decimals,
            ',',
            '.'
        );
    }
}


/**
 * Formatea dinero.
 */
if (!function_exists('counterMoney')) {
    function counterMoney(
        mixed $value,
        string $symbol = '$'
    ): string {
        if ($value === null || $value === '') {
            return '-';
        }

        return $symbol . number_format(
            (float)$value,
            2,
            ',',
            '.'
        );
    }
}


/**
 * Campo estándar de Ficha 360°.
 */
if (!function_exists('counterField')) {
    function counterField(
        string $label,
        mixed $value,
        string $columnClass = 'col-md-4',
        string $fallback = '-'
    ): void {
        ?>

        <div class="<?= e($columnClass) ?>">

            <div class="counter-360-field">

                <span class="label">
                    <?= e($label) ?>
                </span>

                <div class="value">
                    <?= e(counterValue($value, $fallback)) ?>
                </div>

            </div>

        </div>

        <?php
    }
}


/**
 * Campo estándar de texto largo.
 */
if (!function_exists('counterTextareaField')) {
    function counterTextareaField(
        string $label,
        mixed $value,
        string $columnClass = 'col-md-12',
        string $fallback = '-'
    ): void {
        ?>

        <div class="<?= e($columnClass) ?>">

            <div class="counter-360-field">

                <span class="label">
                    <?= e($label) ?>
                </span>

                <div class="value">

                    <?= nl2br(
                        e(
                            counterValue(
                                $value,
                                $fallback
                            )
                        )
                    ) ?>

                </div>

            </div>

        </div>

        <?php
    }
}


/**
 * Botón de acción estándar.
 *
 * disabled = true mantiene el botón visualmente deshabilitado.
 */
if (!function_exists('counterActionButton')) {
    function counterActionButton(
        string $text,
        string $icon,
        string $class = 'btn btn-outline-primary btn-sm',
        ?string $href = null,
        bool $disabled = false
    ): void {
        if ($href !== null && !$disabled) {
            ?>

            <a
                href="<?= e($href) ?>"
                class="<?= e($class) ?>"
            >
                <i class="bi <?= e($icon) ?> me-1"></i>
                <?= e($text) ?>
            </a>

            <?php

            return;
        }

        ?>

        <button
            type="button"
            class="<?= e($class) ?>"
            <?= $disabled ? 'disabled' : '' ?>
        >
            <i class="bi <?= e($icon) ?> me-1"></i>
            <?= e($text) ?>
        </button>

        <?php
    }
}


/**
 * Badge de estado.
 */
if (!function_exists('counterBadge')) {
    function counterBadge(
        mixed $value,
        string $class = 'secondary'
    ): void {
        ?>

        <span class="badge bg-<?= e($class) ?>">

            <?= e(
                counterValue(
                    $value,
                    'SIN ESTADO'
                )
            ) ?>

        </span>

        <?php
    }
}


/**
 * Tarjeta KPI.
 */
if (!function_exists('counterKpi')) {
    function counterKpi(
        string $label,
        mixed $value,
        string $sub = '',
        bool $number = false,
        string $columnClass = 'col-6 col-xl-3'
    ): void {
        ?>

        <div class="<?= e($columnClass) ?>">

            <div class="counter-360-kpi">

                <div class="label">
                    <?= e($label) ?>
                </div>

                <div class="value">

                    <?php if ($number): ?>

                        <?= e(counterNumber($value)) ?>

                    <?php else: ?>

                        <?= e(counterValue($value)) ?>

                    <?php endif; ?>

                </div>

                <?php if ($sub !== ''): ?>

                    <div class="sub">
                        <?= e($sub) ?>
                    </div>

                <?php endif; ?>

            </div>

        </div>

        <?php
    }
}


/**
 * Tarjeta contador.
 */
if (!function_exists('counterCounterCard')) {
    function counterCounterCard(
        string $label,
        mixed $actual,
        mixed $anterior,
        mixed $consumo,
        bool $enabled = true
    ): void {
        ?>

        <div class="col-md-6">

            <div class="counter-360-counter">

                <div class="counter-label">
                    <?= e($label) ?>
                </div>

                <?php if ($enabled): ?>

                    <div class="counter-value">
                        <?= e(counterNumber($actual)) ?>
                    </div>

                    <div class="text-muted">

                        Anterior:
                        <?= e(counterNumber($anterior)) ?>

                    </div>

                    <hr>

                    <strong>

                        Consumo:
                        <?= e(counterNumber($consumo)) ?>

                    </strong>

                <?php else: ?>

                    <div class="counter-value text-muted">
                        N/A
                    </div>

                    <div class="text-muted">
                        Equipo monocromático
                    </div>

                <?php endif; ?>

            </div>

        </div>

        <?php
    }
}


/**
 * Tarjeta de tarifa.
 */
if (!function_exists('counterTarifaCard')) {
    function counterTarifaCard(
        string $label,
        mixed $value
    ): void {
        ?>

        <div class="col-md-4">

            <div class="counter-360-counter">

                <div class="counter-label">
                    <?= e($label) ?>
                </div>

                <div class="counter-value">

                    <?php if ($value !== null && $value !== ''): ?>

                        <?= e(counterMoney($value)) ?>

                    <?php else: ?>

                        <span class="text-muted">
                            -
                        </span>

                    <?php endif; ?>

                </div>

            </div>

        </div>

        <?php
    }
}