<?php
namespace App\Core;

final class ListHelper
{
    /**
     * Devuelve los parámetros de ordenamiento validados y seguros.
     * @param array $allowedColumns Columnas permitidas para ordenar.
     */
    public static function getSortParams(array $allowedColumns, string $defaultSort = 'id'): array
    {
        $sort = $_GET['sort'] ?? $defaultSort;
        $dir  = strtoupper($_GET['dir'] ?? 'DESC');
        
        // Blindaje: Solo permitimos columnas de nuestra lista blanca
        $sort = in_array($sort, $allowedColumns) ? $sort : $defaultSort;
        $dir  = ($dir === 'ASC') ? 'ASC' : 'DESC';
        
        return ['sort' => $sort, 'dir' => $dir, 'nextDir' => ($dir === 'ASC' ? 'DESC' : 'ASC')];
    }
}