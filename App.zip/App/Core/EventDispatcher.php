<?php

declare(strict_types=1);

namespace App\Events;

final class EventDispatcher
{
    /**
     * Lista de listeners por evento
     * [
     *   EventClass => [listener1, listener2]
     * ]
     */
    private array $listeners = [];

    /* =========================================================
       REGISTRAR LISTENER
    ========================================================= */

    public function listen(string $eventClass, callable $listener): void
    {
        $this->listeners[$eventClass][] = $listener;
    }

    /* =========================================================
       DISPATCH EVENTO
    ========================================================= */

    public function dispatch(object $event): void
    {
        $eventClass = get_class($event);

        if (!isset($this->listeners[$eventClass])) {
            return;
        }

        foreach ($this->listeners[$eventClass] as $listener) {

            try {
                $listener($event);
            } catch (\Throwable $e) {
                // 🔥 IMPORTANTE:
                // No romper el flujo del sistema por un listener fallido
                error_log(
                    '[EVENT ERROR] ' .
                    $eventClass .
                    ' -> ' .
                    $e->getMessage()
                );
            }
        }
    }

    /* =========================================================
       HELPERS
    ========================================================= */

    public function hasListeners(string $eventClass): bool
    {
        return !empty($this->listeners[$eventClass]);
    }

    public function getListeners(string $eventClass): array
    {
        return $this->listeners[$eventClass] ?? [];
    }
}