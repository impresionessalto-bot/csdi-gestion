<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

final class Audit
{
    public static function log(
        PDO $db,
        int $userId,
        int $clienteId,
        int $equipoId,
        string $field,
        mixed $old,
        mixed $new
    ): void {

        $stmt = $db->prepare("
            INSERT INTO audit_logs
            (
                user_id,
                cliente_id,
                equipo_id,
                campo,
                valor_anterior,
                valor_nuevo,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");

        $stmt->execute([
            $userId,
            $clienteId,
            $equipoId,
            $field,
            (string)$old,
            (string)$new
        ]);
    }
}