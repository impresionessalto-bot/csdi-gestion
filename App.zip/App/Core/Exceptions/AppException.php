<?php
declare(strict_types=1);

namespace App\Exceptions;

use Exception;
use Throwable;

class AppException extends Exception
{
    public function __construct(
        string $message = "Error interno de la aplicación",
        int $code = 0,
        ?Throwable $previous = null
    ) {
        parent::__construct($message, $code, $previous);
    }

    public function toArray(): array
    {
        return [
            'error' => true,
            'message' => $this->getMessage(),
            'code' => $this->getCode()
        ];
    }
}