<?php
declare(strict_types=1);

namespace App\Exceptions;

use Throwable;

class RepositoryException extends AppException
{
    public function __construct(
        string $message = "Error en la capa de datos",
        int $code = 500,
        ?Throwable $previous = null
    ) {
        parent::__construct(
            $message,
            $code,
            $previous
        );
    }
}