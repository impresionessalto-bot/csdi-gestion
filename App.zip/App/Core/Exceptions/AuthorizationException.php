<?php
declare(strict_types=1);

namespace App\Exceptions;

use Throwable;

class AuthorizationException extends AppException
{
    public function __construct(
        string $message = "No tiene permisos para realizar esta acción",
        int $code = 403,
        ?Throwable $previous = null
    ) {
        parent::__construct(
            $message,
            $code,
            $previous
        );
    }
}