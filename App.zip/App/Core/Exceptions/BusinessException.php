<?php
declare(strict_types=1);

namespace App\Exceptions;

use Throwable;

class BusinessException extends AppException
{
    public function __construct(
        string $message = "No se puede completar la operación",
        int $code = 409,
        ?Throwable $previous = null
    ) {
        parent::__construct(
            $message,
            $code,
            $previous
        );
    }
}