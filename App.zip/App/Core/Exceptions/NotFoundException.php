<?php
declare(strict_types=1);

namespace App\Exceptions;

use Throwable;

class NotFoundException extends AppException
{
    public function __construct(
        string $message = "Registro no encontrado",
        int $code = 404,
        ?Throwable $previous = null
    ) {
        parent::__construct(
            $message,
            $code,
            $previous
        );
    }
}