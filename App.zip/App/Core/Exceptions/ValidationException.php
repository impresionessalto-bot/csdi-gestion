<?php
declare(strict_types=1);

namespace App\Exceptions;

use Throwable;

class ValidationException extends AppException
{
    private array $errors;

    public function __construct(
        array $errors = [],
        string $message = "Error de validación",
        int $code = 422,
        ?Throwable $previous = null
    ) {
        $this->errors = $errors;

        parent::__construct(
            $message,
            $code,
            $previous
        );
    }


    public function errors(): array
    {
        return $this->errors;
    }


    public function toArray(): array
    {
        return [
            'error' => true,
            'message' => $this->getMessage(),
            'errors' => $this->errors,
            'code' => $this->getCode()
        ];
    }
}