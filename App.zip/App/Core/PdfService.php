<?php
namespace App\Core;

// Requerir FPDF (ajusta la ruta según donde subas el archivo fpdf.php)
require_once ROOT_PATH . 'App/Core/Libs/fpdf/fpdf.php';

class PdfService extends \FPDF {
    
    /**
     * Genera un PDF a partir de un array de rutas de imágenes
     */
    public static function imagesToPdf(array $imagePaths, string $destPath): void {
        $pdf = new \FPDF();
        
        foreach ($imagePaths as $img) {
            if (!file_exists($img)) continue;
            
            $pdf->AddPage();
            // Obtener dimensiones para ajustar la imagen a la página A4
            list($width, $height) = getimagesize($img);
            $ratio = $width / $height;
            
            if ($ratio > 1) { // Horizontal
                $pdf->Image($img, 10, 10, 190);
            } else { // Vertical
                $pdf->Image($img, 10, 10, 0, 270);
            }
        }
        
        $pdf->Output('F', $destPath);
    }
}