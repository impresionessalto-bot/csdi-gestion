<?php
declare(strict_types=1);

namespace App\Core;


final class Permission
{


    /**
     * Verifica permiso del usuario actual
     */
    public static function can(
        string $permission
    ): bool
    {


        $user =
            $_SESSION['user'] ?? [];



        /*
        |--------------------------------------------------------------------------
        | ADMIN GLOBAL
        |--------------------------------------------------------------------------
        */

        if(
            ($user['rol'] ?? '') === 'admin'
        ){

            return true;

        }





        /*
        |--------------------------------------------------------------------------
        | PERMISOS SESSION
        |--------------------------------------------------------------------------
        */


        $permissions =
            $user['permissions'] ?? [];



        if(
            !is_array($permissions)
        ){

            return false;

        }



        return in_array(
            $permission,
            $permissions,
            true
        );


    }







    /**
     * Requiere permiso
     */
    public static function check(
        string $permission
    ): void
    {


        if(
            !self::can($permission)
        ){


            http_response_code(403);


            exit(
                '❌ No tiene permisos para realizar esta acción'
            );


        }


    }









    /**
     * Lista permisos usuario
     */
    public static function all(): array
    {

        return
            $_SESSION['user']['permissions']
            ??
            [];

    }








    /**
     * Asignar permisos en sesión
     */
    public static function set(
        array $permissions
    ): void
    {


        $_SESSION['user']['permissions'] =
            array_values(
                array_unique(
                    $permissions
                )
            );


    }








    /**
     * Agregar permiso
     */
    public static function add(
        string $permission
    ): void
    {


        $permissions =
            self::all();



        $permissions[] =
            $permission;



        self::set(
            $permissions
        );


    }







    /**
     * Quitar permiso
     */
    public static function remove(
        string $permission
    ): void
    {


        $permissions =
            self::all();



        $permissions =
            array_filter(

                $permissions,

                fn($item)=>
                    $item !== $permission

            );



        self::set(
            $permissions
        );


    }








    /**
     * Verifica varios permisos
     */
    public static function any(
        array $permissions
    ): bool
    {

        foreach($permissions as $permission){

            if(self::can($permission)){

                return true;

            }

        }


        return false;

    }








    /**
     * Verifica todos
     */
    public static function allRequired(
        array $permissions
    ): bool
    {


        foreach($permissions as $permission){

            if(!self::can($permission)){

                return false;

            }

        }


        return true;

    }


}