<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;
use Throwable;


abstract class BaseService
{


    /*
    |--------------------------------------------------------------------------
    | VALIDAR ID
    |--------------------------------------------------------------------------
    */


    protected function validateId(
        int $id,
        string $entity = 'registro'
    ): void
    {

        if($id <= 0){

            throw new RuntimeException(
                ucfirst($entity).' inválido.'
            );

        }

    }





    /*
    |--------------------------------------------------------------------------
    | LIMPIAR TEXTO
    |--------------------------------------------------------------------------
    */


    protected function clean(
        ?string $value
    ): ?string
    {

        return $value === null
            ? null
            : trim($value);

    }





    /*
    |--------------------------------------------------------------------------
    | PAGINACION
    |--------------------------------------------------------------------------
    */


    protected function pagination(
        int $page = 1,
        int $limit = 20
    ): array
    {

        $page =
            max(
                1,
                $page
            );


        $limit =
            max(
                1,
                $limit
            );


        return [

            'page'=>$page,

            'limit'=>$limit,

            'offset'=>
                ($page-1)*$limit

        ];

    }





    /*
    |--------------------------------------------------------------------------
    | RESPUESTAS
    |--------------------------------------------------------------------------
    */


    protected function success(
        mixed $data=null,
        string $message=''
    ): array
    {

        return [

            'success'=>true,

            'message'=>$message,

            'data'=>$data,

            'errors'=>[]

        ];

    }




    protected function error(
        string $message,
        array $errors=[]
    ): array
    {

        return [

            'success'=>false,

            'message'=>$message,

            'data'=>null,

            'errors'=>$errors

        ];

    }





    /*
    |--------------------------------------------------------------------------
    | USUARIO ACTUAL
    |--------------------------------------------------------------------------
    */


    protected function userId(): ?int
    {

        return isset($_SESSION['user']['id'])
            ? (int)$_SESSION['user']['id']
            : null;

    }





    /*
    |--------------------------------------------------------------------------
    | EMPRESA ACTUAL
    |--------------------------------------------------------------------------
    */


    protected function empresaId(): int
    {

        return (int)(
            $_SESSION['empresa_id']
            ?? 1
        );

    }





    /*
    |--------------------------------------------------------------------------
    | TRANSACCIONES
    |--------------------------------------------------------------------------
    */


    protected function transaction(
        callable $callback
    ): mixed
    {

        $db =
            Container::getInstance()
            ->db();


        try{

            $db->beginTransaction();


            $result =
                $callback();


            $db->commit();


            return $result;


        }catch(Throwable $e){


            if($db->inTransaction()){

                $db->rollBack();

            }


            throw $e;

        }

    }





    /*
    |--------------------------------------------------------------------------
    | AUDITORIA
    |--------------------------------------------------------------------------
    */


    protected function audit(
        string $action,
        array $data=[]
    ): void
    {

        /*
         * Preparado para AuditService
         */

    }





    /*
    |--------------------------------------------------------------------------
    | PERMISOS
    |--------------------------------------------------------------------------
    */


    protected function can(
        string $permission
    ): bool
    {

        return true;

    }





    /*
    |--------------------------------------------------------------------------
    | SOFT DELETE
    |--------------------------------------------------------------------------
    */


    protected function softDelete(
        string $table,
        int $id
    ): bool
    {

        $db =
            Container::getInstance()
            ->db();


        $stmt =
            $db->prepare(
                "
                UPDATE {$table}
                SET deleted_at = NOW()
                WHERE id = ?
                "
            );


        $stmt->execute([
            $id
        ]);


        return $stmt->rowCount()>0;

    }


}