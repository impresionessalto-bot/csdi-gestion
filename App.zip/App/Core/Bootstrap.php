<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use App\Repositories\CounterRepository;
use App\Services\CounterService;
use App\Events\EventDispatcher;
use App\Listeners\CounterAuditListener;
use App\Listeners\CounterVersionListener;

final class Bootstrap
{
    private static ?self $instance = null;

    private PDO $db;
    private EventDispatcher $dispatcher;

    public CounterService $counterService;

    public function __construct(PDO $db)
    {
        $this->db = $db;

        $this->initDispatcher();
        $this->initRepositories();
        $this->initServices();
        $this->initListeners();
    }

    /* =========================================================
       SINGLETON (opcional pero útil en ERP chico/medio)
    ========================================================= */

    public static function init(PDO $db): self
    {
        if (!self::$instance) {
            self::$instance = new self($db);
        }

        return self::$instance;
    }

    public static function getInstance(): self
    {
        return self::$instance;
    }

    /* =========================================================
       EVENT DISPATCHER
    ========================================================= */

    private function initDispatcher(): void
    {
        $this->dispatcher = new EventDispatcher();
    }

    public function dispatcher(): EventDispatcher
    {
        return $this->dispatcher;
    }

    /* =========================================================
       REPOSITORIES
    ========================================================= */

    private CounterRepository $counterRepo;

    private function initRepositories(): void
    {
        $this->counterRepo = new CounterRepository(
            $this->db
        );
    }

    public function counterRepo(): CounterRepository
    {
        return $this->counterRepo;
    }

    /* =========================================================
       SERVICES
    ========================================================= */

    private function initServices(): void
    {
        $this->counterService = new CounterService(
            $this->counterRepo,
            $this->dispatcher
        );
    }

    public function counterService(): CounterService
    {
        return $this->counterService;
    }

    /* =========================================================
       LISTENERS (EVENTOS GLOBALES)
    ========================================================= */

    private function initListeners(): void
    {
        // Auditoría de cambios
        $this->dispatcher->listen(
            \App\Events\CounterUpdatedEvent::class,
            new CounterAuditListener($this->counterRepo)
        );

        // Versionado de equipos
        $this->dispatcher->listen(
            \App\Events\CounterUpdatedEvent::class,
            new CounterVersionListener($this->counterRepo)
        );
    }
}