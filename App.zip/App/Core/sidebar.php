<?php

declare(strict_types=1);

namespace App\Core;

final class Sidebar
{
    public static function render(): void
    {
        $role = strtolower($_SESSION['usuario_rol'] ?? 'user');

        $map = [
            'admin' => 'sidebar_admin.php',
            'tech'  => 'sidebar_tech.php',
            'user'  => 'sidebar_user.php',
        ];

        $file = $map[$role] ?? 'sidebar_user.php';

        $path = BASE_PATH . '/App/Views/components/' . $file;

        // fallback blindado
        if (!file_exists($path)) {
            $path = BASE_PATH . '/App/Views/components/sidebar_base.php';
        }

        require $path;
    }
}