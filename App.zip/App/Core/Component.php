<?php

declare(strict_types=1);

namespace App\Core;

/**
 * CSDI ERP UI Framework v1.0
 *
 * Base Component Class
 */
abstract class Component
{
    /**
     * Datos del componente
     */
    protected array $data = [];

    /**
     * Vista asociada
     */
    protected string $view = '';

    /**
     * Asignar datos (Interfaz Fluida)
     */
    public function with(array $data): static 
    {
        $this->data = $data;
        return $this;
    }

    /**
     * Definir vista
     */
    protected function setView(string $view): void 
    {
        $this->view = $view;
    }

    /**
     * Render común unificado
     */
    public function render(): string
    {
        // CORRECCIÓN HISTÓRICA CLAVE: Anteponemos la barra invertida '\' antes de view
        // Esto obliga a PHP a llamar al helper global view() unificado de tu helpers.php
        return \view(
            $this->view,
            array_merge(
                $this->data,
                [
                    'component' => $this
                ]
            )
        );
    }
}