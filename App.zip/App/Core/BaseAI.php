<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;
use Throwable;


/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| BASE AI V2
|--------------------------------------------------------------------------
|
| Clase base para módulos de inteligencia artificial del ERP.
|
| Usos:
|
| - StockAI
| - FinanzasAI
| - TngAI
| - DocumentosAI
| - TecnicoAI
|
|--------------------------------------------------------------------------
*/


abstract class BaseAI
{


    /*
    |--------------------------------------------------------------------------
    | CONFIGURACIÓN
    |--------------------------------------------------------------------------
    */


    protected string $model = 'ERP-AI';


    protected string $provider = 'internal';



    /*
    |--------------------------------------------------------------------------
    | DATOS
    |--------------------------------------------------------------------------
    */


    protected array $data = [];



    /*
    |--------------------------------------------------------------------------
    | CONTEXTO ERP
    |--------------------------------------------------------------------------
    |
    | Ej:
    |
    | empresa_id
    | usuario_id
    | modulo
    |
    */


    protected array $context = [];



    /*
    |--------------------------------------------------------------------------
    | MEMORIA
    |--------------------------------------------------------------------------
    */


    protected array $memory = [];



    /*
    |--------------------------------------------------------------------------
    | RESULTADOS
    |--------------------------------------------------------------------------
    */


    protected array $result = [];



    protected array $explanations = [];



    protected float $confidence = 0;





    /*
    |--------------------------------------------------------------------------
    | CONSTRUCTOR
    |--------------------------------------------------------------------------
    */


    public function __construct(
        array $data = [],
        array $context = []
    )
    {

        $this->data =
            $data;


        $this->context =
            $context;

    }









    /*
    |--------------------------------------------------------------------------
    | EJECUTAR ANALISIS
    |--------------------------------------------------------------------------
    */


    public function analyze(): array
    {


        try {


            $this->validate();



            $this->result =
                $this->process();



            return [

                'model'=>
                    $this->model,


                'provider'=>
                    $this->provider,


                'generated_at'=>
                    date('Y-m-d H:i:s'),


                'confidence'=>
                    $this->confidence,


                'context'=>
                    $this->context,


                'result'=>
                    $this->result,


                'explanations'=>
                    $this->explanations

            ];


        }
        catch(Throwable $e)
        {


            return [

                'model'=>
                    $this->model,


                'error'=>true,


                'message'=>
                    $e->getMessage()


            ];


        }


    }








    /*
    |--------------------------------------------------------------------------
    | PROCESAMIENTO IA
    |--------------------------------------------------------------------------
    */


    abstract protected function process(): array;









    /*
    |--------------------------------------------------------------------------
    | VALIDACIÓN
    |--------------------------------------------------------------------------
    */


    protected function validate(): void
    {


        if(!$this->data)
        {

            throw new RuntimeException(
                'No hay datos para analizar.'
            );

        }


    }









    /*
    |--------------------------------------------------------------------------
    | SET DATA
    |--------------------------------------------------------------------------
    */


    public function setData(
        array $data
    ): static
    {


        $this->data =
            $data;


        return $this;

    }








    /*
    |--------------------------------------------------------------------------
    | SET CONTEXTO
    |--------------------------------------------------------------------------
    */


    public function setContext(
        array $context
    ): static
    {


        $this->context =
            $context;


        return $this;

    }








    /*
    |--------------------------------------------------------------------------
    | MEMORIA
    |--------------------------------------------------------------------------
    */


    public function remember(
        string $key,
        mixed $value
    ): static
    {


        $this->memory[$key] =
            $value;


        return $this;

    }



    public function memory(): array
    {

        return $this->memory;

    }









    /*
    |--------------------------------------------------------------------------
    | RESULTADO
    |--------------------------------------------------------------------------
    */


    public function result(): array
    {

        return $this->result;

    }








    /*
    |--------------------------------------------------------------------------
    | EXPLICACIONES
    |--------------------------------------------------------------------------
    */


    protected function explain(
        string $message
    ): void
    {

        $this->explanations[] =
            $message;

    }








    /*
    |--------------------------------------------------------------------------
    | CONFIANZA
    |--------------------------------------------------------------------------
    */


    protected function confidence(
        float $value
    ): void
    {


        if($value < 0)
        {

            $value = 0;

        }


        if($value > 100)
        {

            $value = 100;

        }



        $this->confidence =
            round(
                $value,
                2
            );


    }









    /*
    |--------------------------------------------------------------------------
    | PROMEDIO
    |--------------------------------------------------------------------------
    */


    protected function average(
        array $values
    ): float
    {


        if(!$values)
        {

            return 0;

        }



        return

            array_sum($values)
            /
            count($values);


    }









    /*
    |--------------------------------------------------------------------------
    | TENDENCIA
    |--------------------------------------------------------------------------
    */


    protected function trend(
        float $old,
        float $new
    ): float
    {


        if($old == 0)
        {

            return 0;

        }



        return round(

            (($new-$old)/$old)*100,

            2

        );


    }









    /*
    |--------------------------------------------------------------------------
    | DETECCIÓN DE ANOMALÍAS
    |--------------------------------------------------------------------------
    */


    protected function anomaly(
        float $value,
        float $average,
        float $limit = 30
    ): bool
    {


        if($average == 0)
        {

            return false;

        }



        $difference =

            abs(

                (($value-$average)
                /
                $average)
                *
                100

            );



        return

            $difference >= $limit;


    }









    /*
    |--------------------------------------------------------------------------
    | ALERTAS
    |--------------------------------------------------------------------------
    */


    protected function alert(
        string $type,
        string $message,
        array $data = []
    ): array
    {


        return [

            'type'=>
                $type,


            'message'=>
                $message,


            'data'=>
                $data,


            'date'=>
                date('Y-m-d H:i:s')


        ];


    }









    /*
    |--------------------------------------------------------------------------
    | SCORE
    |--------------------------------------------------------------------------
    */


    protected function score(
        float $value,
        float $max
    ): float
    {


        if($max<=0)
        {

            return 0;

        }



        return round(

            ($value/$max)*100,

            2

        );


    }









}