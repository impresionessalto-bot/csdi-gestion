<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;

final class Logger
{
    /**
     * Carpeta de logs
     */
    private static string $path = __DIR__ . '/../../storage/logs/';

    /**
     * =========================================================
     * LOG GENERICO
     * =========================================================
     */
    public static function write(
        string $level,
        string $message,
        array $context = []
    ): void {

        self::ensureDirectory();

        $file = self::$path . date('Y-m-d') . '.log';

        $record = [
            'datetime' => date('Y-m-d H:i:s'),
            'level'    => strtoupper($level),
            'message'  => $message,
            'user_id'  => Session::userId(),
            'user'     => Session::userName(),
            'ip'       => $_SERVER['REMOTE_ADDR'] ?? '',
            'url'      => $_SERVER['REQUEST_URI'] ?? '',
            'method'   => $_SERVER['REQUEST_METHOD'] ?? '',
            'context'  => $context
        ];

        file_put_contents(
            $file,
            json_encode($record, JSON_UNESCAPED_UNICODE) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }

    /**
     * =========================================================
     * NIVELES
     * =========================================================
     */

    public static function info(
        string $message,
        array $context = []
    ): void {

        self::write('INFO', $message, $context);
    }

    public static function warning(
        string $message,
        array $context = []
    ): void {

        self::write('WARNING', $message, $context);
    }

    public static function error(
        string $message,
        array $context = []
    ): void {

        self::write('ERROR', $message, $context);
    }

    public static function debug(
        string $message,
        array $context = []
    ): void {

        self::write('DEBUG', $message, $context);
    }

    /**
     * =========================================================
     * EXCEPCIONES
     * =========================================================
     */

    public static function exception(Throwable $e): void
    {
        self::write('EXCEPTION', $e->getMessage(), [

            'file'  => $e->getFile(),

            'line'  => $e->getLine(),

            'trace' => $e->getTraceAsString()

        ]);
    }

    /**
     * =========================================================
     * AUDITORIA
     * =========================================================
     */

    public static function audit(
        string $module,
        string $action,
        int|string|null $recordId = null,
        array $before = [],
        array $after = []
    ): void {

        self::write('AUDIT', "{$module}: {$action}", [

            'record_id' => $recordId,

            'before' => $before,

            'after' => $after

        ]);
    }

    /**
     * =========================================================
     * LOGIN
     * =========================================================
     */

    public static function login(
        string $username
    ): void {

        self::write('LOGIN', 'Inicio de sesión', [

            'username' => $username

        ]);
    }

    public static function logout(): void
    {
        self::write('LOGOUT', 'Cierre de sesión');
    }

    /**
     * =========================================================
     * SQL
     * =========================================================
     */

    public static function sql(
        string $sql,
        array $params = []
    ): void {

        self::write('SQL', $sql, [

            'params' => $params

        ]);
    }

    /**
     * =========================================================
     * API
     * =========================================================
     */

    public static function api(
        string $endpoint,
        array $request = [],
        array $response = []
    ): void {

        self::write('API', $endpoint, [

            'request' => $request,

            'response' => $response

        ]);
    }

    /**
     * =========================================================
     * DIRECTORIO
     * =========================================================
     */

    private static function ensureDirectory(): void
    {
        if (!is_dir(self::$path)) {

            mkdir(self::$path, 0775, true);

        }
    }
}