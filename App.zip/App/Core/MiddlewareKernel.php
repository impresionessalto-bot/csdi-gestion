<?php

declare(strict_types=1);

namespace App\Core;


use App\Services\Permissions\PermissionService;
use RuntimeException;



/**
 * =========================================================
 * ERP CSDI PRO
 *
 * MiddlewareKernel
 *
 * Ejecuta pila de middlewares de rutas
 *
 * Soporta:
 *
 * auth
 * role:admin
 * permission:permiso
 *
 * =========================================================
 */
final class MiddlewareKernel
{


    public static function run(
        array $middlewares
    ): void
    {


        foreach($middlewares as $middleware)
        {


            $middleware =
                trim(
                    (string)$middleware
                );




            if($middleware === ''){

                continue;

            }








            /*
            |--------------------------------------------------------------------------
            | AUTH
            |--------------------------------------------------------------------------
            */


            if(
                strtolower($middleware)
                ===
                'auth'
            )
            {


                \App\Middleware\AuthMiddleware::handle();


                continue;


            }









            /*
            |--------------------------------------------------------------------------
            | ROLE
            |--------------------------------------------------------------------------
            |
            | Ejemplo:
            |
            | role:admin
            | role:tecnico
            |
            */


            if(
                str_starts_with(
                    strtolower($middleware),
                    'role:'
                )
            )
            {


                $role =
                    substr(
                        $middleware,
                        5
                    );



                \App\Middleware\RoleMiddleware::handle(
                    $role
                );


                continue;


            }









            /*
            |--------------------------------------------------------------------------
            | PERMISSION
            |--------------------------------------------------------------------------
            |
            | Ejemplo:
            |
            | permission:menu_clientes
            |
            */


            if(
                str_starts_with(
                    strtolower($middleware),
                    'permission:'
                )
            )
            {


                $permission =
                    substr(
                        $middleware,
                        11
                    );




                $service =

                    Container::getInstance()
                        ->make(
                            PermissionService::class
                        );





                $service->authorize(
                    $permission
                );



                continue;


            }









            /*
            |--------------------------------------------------------------------------
            | MIDDLEWARE CLASE
            |--------------------------------------------------------------------------
            */


            $class =

                "App\\Middleware\\"

                .

                ucfirst(
                    strtolower(
                        $middleware
                    )
                )

                .

                "Middleware";







            if(
                class_exists($class)
            )
            {


                $class::handle();


                continue;


            }








            throw new RuntimeException(

                "Middleware no existe: {$middleware}"

            );


        }


    }



}