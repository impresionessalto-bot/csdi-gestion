<?php

declare(strict_types=1);

namespace App\Core;

final class Debug
{
    private static float $start = 0;

    private static array $data = [];

    /* =========================
       START TIMER
    ========================= */

    public static function start(): void
    {
        self::$start = microtime(true);
    }

    /* =========================
       SET VALUE
    ========================= */

    public static function set(string $key, mixed $value): void
    {
        self::$data[$key] = $value;
    }

    /* =========================
       ADD ARRAY VALUE
    ========================= */

    public static function add(string $key, mixed $value): void
    {
        if (!isset(self::$data[$key])) {
            self::$data[$key] = [];
        }

        self::$data[$key][] = $value;
    }

    /* =========================
       EXECUTION TIME
    ========================= */

    public static function time(): float
    {
        return round(
            (microtime(true) - self::$start) * 1000,
            2
        );
    }

    /* =========================
       RENDER PANEL
    ========================= */

    public static function render(): void
    {
        echo "
        <div style='
            position:fixed;
            bottom:0;
            left:0;
            right:0;
            max-height:300px;
            overflow:auto;
            background:#0f172a;
            color:#22c55e;
            font-family:monospace;
            font-size:12px;
            padding:12px;
            z-index:999999;
            border-top:3px solid #22c55e;
        '>";

        echo "<b>🚀 ERP DEBUG PANEL</b>";
        echo " | ";
        echo self::time() . " ms";
        echo "<hr>";

        foreach (self::$data as $key => $value) {

            echo "<div style='margin-bottom:10px'>";

            echo "<b style='color:#38bdf8'>";
            echo htmlspecialchars($key);
            echo "</b>";

            echo "<pre style='white-space:pre-wrap;color:#e5e7eb'>";

            print_r($value);

            echo "</pre>";

            echo "</div>";
        }

        echo "</div>";
    }
}