<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;


/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| BASE REPORT V2
|--------------------------------------------------------------------------
|
| Clase base para reportes del ERP.
|
| Permite:
|
| - Reportes HTML
| - CSV
| - Excel
| - Preparación PDF
| - Filtros
| - Columnas dinámicas
| - Metadatos
| - Control de permisos
|
*/


abstract class BaseReport
{


    /*
    |--------------------------------------------------------------------------
    | INFORMACIÓN DEL REPORTE
    |--------------------------------------------------------------------------
    */


    protected string $title = 'Reporte ERP';


    protected string $filename = 'reporte';


    protected string $module = '';


    protected string $category = 'General';


    protected string $permission = '';



    /*
    |--------------------------------------------------------------------------
    | CONFIGURACIÓN
    |--------------------------------------------------------------------------
    */


    protected array $columns = [];


    protected array $filters = [];


    protected array $sort = [];


    protected ?int $limit = null;



    /*
    |--------------------------------------------------------------------------
    | DATOS
    |--------------------------------------------------------------------------
    */


    abstract protected function data(): array;




    /*
    |--------------------------------------------------------------------------
    | GETTERS
    |--------------------------------------------------------------------------
    */


    public function title(): string
    {
        return $this->title;
    }



    public function filename(): string
    {
        return $this->filename;
    }



    public function module(): string
    {
        return $this->module;
    }



    public function category(): string
    {
        return $this->category;
    }



    public function permission(): string
    {
        return $this->permission;
    }



    public function columns(): array
    {
        return $this->columns;
    }



    public function filters(): array
    {
        return $this->filters;
    }




    /*
    |--------------------------------------------------------------------------
    | GENERAR REPORTE
    |--------------------------------------------------------------------------
    */


    public function generate(): array
    {

        $rows = $this->data();



        if(
            $this->limit !== null
        ){

            $rows =
                array_slice(
                    $rows,
                    0,
                    $this->limit
                );

        }



        return [

            'title' =>
                $this->title,


            'module' =>
                $this->module,


            'category' =>
                $this->category,


            'created_at' =>
                date(
                    'Y-m-d H:i:s'
                ),


            'columns' =>
                $this->columns,


            'filters' =>
                $this->filters,


            'sort' =>
                $this->sort,


            'rows' =>
                $rows

        ];

    }





    /*
    |--------------------------------------------------------------------------
    | FILTROS
    |--------------------------------------------------------------------------
    */


    public function setFilters(
        array $filters
    ): static {

        $this->filters = $filters;

        return $this;

    }





    /*
    |--------------------------------------------------------------------------
    | ORDEN
    |--------------------------------------------------------------------------
    */


    public function setSort(
        array $sort
    ): static {

        $this->sort = $sort;

        return $this;

    }





    /*
    |--------------------------------------------------------------------------
    | LIMITE
    |--------------------------------------------------------------------------
    */


    public function setLimit(
        ?int $limit
    ): static {

        $this->limit = $limit;

        return $this;

    }





    /*
    |--------------------------------------------------------------------------
    | HTML
    |--------------------------------------------------------------------------
    */


    public function html(): string
    {

        $report =
            $this->generate();



        $html = '
        <table border="1"
               cellpadding="5"
               cellspacing="0"
               width="100%">';



        $html .= '<thead><tr>';



        foreach(
            $this->columns
            as $label
        ){

            $html .= '
            <th>'
            .
            htmlspecialchars(
                $label,
                ENT_QUOTES,
                'UTF-8'
            )
            .
            '</th>';

        }



        $html .= '
        </tr>
        </thead>';



        $html .= '<tbody>';



        foreach(
            $report['rows']
            as $row
        ){

            $html .= '<tr>';



            foreach(
                array_keys($this->columns)
                as $field
            ){

                $value =
                    $row[$field]
                    ??
                    '';



                $html .= '
                <td>'
                .
                htmlspecialchars(
                    (string)$value,
                    ENT_QUOTES,
                    'UTF-8'
                )
                .
                '</td>';

            }



            $html .= '</tr>';

        }



        $html .= '
        </tbody>
        </table>';



        return $html;

    }





    /*
    |--------------------------------------------------------------------------
    | CSV
    |--------------------------------------------------------------------------
    */


    public function csv(): void
    {

        header(
            'Content-Type: text/csv; charset=utf-8'
        );


        header(
            'Content-Disposition: attachment; filename="' .
            $this->filename .
            '.csv"'
        );



        $output =
            fopen(
                'php://output',
                'w'
            );



        fputcsv(
            $output,
            array_values(
                $this->columns
            )
        );



        foreach(
            $this->generate()['rows']
            as $row
        ){

            $line = [];



            foreach(
                array_keys($this->columns)
                as $field
            ){

                $line[] =
                    $row[$field]
                    ??
                    '';

            }



            fputcsv(
                $output,
                $line
            );

        }



        fclose($output);

        exit;

    }





    /*
    |--------------------------------------------------------------------------
    | EXCEL
    |--------------------------------------------------------------------------
    */


    public function excel(): void
    {

        header(
            'Content-Type: application/vnd.ms-excel'
        );


        header(
            'Content-Disposition: attachment; filename="' .
            $this->filename .
            '.xls"'
        );



        echo $this->html();



        exit;

    }





    /*
    |--------------------------------------------------------------------------
    | PDF DATA
    |--------------------------------------------------------------------------
    */


    public function pdfData(): array
    {

        return $this->generate();

    }





    /*
    |--------------------------------------------------------------------------
    | TOTALES
    |--------------------------------------------------------------------------
    */


    protected function total(
        array $rows,
        string $field
    ): float
    {

        $total = 0;



        foreach(
            $rows
            as $row
        ){

            $total +=
                (float)(
                    $row[$field]
                    ??
                    0
                );

        }



        return $total;

    }





    /*
    |--------------------------------------------------------------------------
    | VALIDACIONES
    |--------------------------------------------------------------------------
    */


    protected function requireColumn(
        string $column
    ): void
    {

        if(
            !isset(
                $this->columns[$column]
            )
        ){

            throw new RuntimeException(
                "Columna no definida: {$column}"
            );

        }

    }



}