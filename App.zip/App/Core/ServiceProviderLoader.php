<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;
use Throwable;


/**
 * =========================================================
 * ERP CSDI PRO
 * SERVICE PROVIDER LOADER
 * =========================================================
 *
 * Carga servicios globales del ERP.
 *
 * Busca:
 *
 * App/Providers/*Provider.php
 *
 * Ejemplo:
 *
 * AppServiceProvider.php
 * DatabaseServiceProvider.php
 * MailServiceProvider.php
 * StorageServiceProvider.php
 *
 * =========================================================
 */

final class ServiceProviderLoader
{


    private static bool $loaded = false;




    /**
     * Cargar Providers
     */
    public static function load():void
    {


        if(self::$loaded){

            return;

        }


        self::$loaded=true;



        $container =
            Container::getInstance();




        $path =
            BASE_PATH
            .
            '/App/Providers/*Provider.php';





        $providers =
            glob($path);





        if(!$providers){

            return;

        }






        foreach($providers as $file){



            try{



                self::registerProvider(
                    $file,
                    $container
                );



            }
            catch(Throwable $e){



                throw new RuntimeException(

                    "Error cargando ServiceProvider "
                    .
                    basename($file)
                    .
                    ": "
                    .
                    $e->getMessage()

                );



            }



        }



    }









    private static function registerProvider(
        string $file,
        Container $container
    ):void
    {



        require_once $file;




        $class =
            self::classFromFile(
                $file
            );





        if(!$class){

            return;

        }






        if(!class_exists($class)){


            throw new RuntimeException(

                "Provider no encontrado: ".$class

            );


        }






        $provider =
            new $class(
                $container
            );





        if(
            !$provider instanceof ServiceProvider
        ){


            throw new RuntimeException(

                "{$class} debe extender ServiceProvider"

            );


        }






        $provider->register();



    }









    private static function classFromFile(
        string $file
    ):?string
    {


        $name =
            basename(
                $file,
                '.php'
            );



        if(!$name){

            return null;

        }



        return
            'App\\Providers\\'
            .
            $name;



    }









    public static function reset():void
    {

        self::$loaded=false;

    }


}