<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * =========================================================
 * CRUD ENGINE
 * =========================================================
 */

final class Crud
{
    public static function listing(
        PDO $db,
        string $table,
        array $searchable = [],
        string $defaultOrder = 'id DESC'
    ): array {

        $search =
            trim($_GET['search'] ?? '');

        $sort =
            trim($_GET['sort'] ?? $defaultOrder);

        $sql = "
            SELECT *
            FROM {$table}
        ";

        $params = [];

        /*
        |---------------------------------------------------------
        | SEARCH
        ----------------------------------------------------------
        */

        if (
            $search !== ''
            &&
            !empty($searchable)
        ) {

            $where = [];

            foreach ($searchable as $field) {

                $where[] =
                    "{$field} LIKE ?";
            }

            $sql .= '
                WHERE
                ' . implode(' OR ', $where);

            foreach ($searchable as $field) {

                $params[] =
                    '%' . $search . '%';
            }
        }

        /*
        |---------------------------------------------------------
        | ORDER
        ----------------------------------------------------------
        */

        $sql .= "
            ORDER BY {$sort}
        ";

        $stmt = $db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll();
    }
}