<?php

declare(strict_types=1);

namespace App\Core;

final class Csrf
{
    public static function generate(): void
    {
        if (empty($_SESSION['csrf_token'])) {

            $_SESSION['csrf_token'] =
                bin2hex(random_bytes(32));
        }
    }

    public static function token(): string
    {
        return $_SESSION['csrf_token'];
    }

    public static function validate(?string $token): bool
    {
        return hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $token ?? ''
        );
    }
}