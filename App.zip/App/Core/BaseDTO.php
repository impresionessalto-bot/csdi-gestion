<?php

declare(strict_types=1);

namespace App\Core;

use JsonSerializable;
use ReflectionClass;
use ReflectionNamedType;
use InvalidArgumentException;


abstract class BaseDTO implements JsonSerializable
{


    protected array $errors=[];




    public static function fromArray(
        array $data
    ): static
    {


        $reflection =
            new ReflectionClass(
                static::class
            );


        $constructor =
            $reflection->getConstructor();



        if(!$constructor){

            return new static();

        }



        $args=[];



        foreach(
            $constructor->getParameters()
            as $parameter
        ){


            $name =
                $parameter->getName();


            $value =
                $data[$name] ?? null;



            $type =
                $parameter->getType();



            if(
                $type instanceof ReflectionNamedType
            ){

                switch(
                    $type->getName()
                ){

                    case 'int':
                        $value=(int)$value;
                        break;


                    case 'float':
                        $value=(float)$value;
                        break;


                    case 'bool':
                        $value=(bool)$value;
                        break;


                    case 'string':
                        $value=trim((string)$value);
                        break;

                }

            }



            $args[]=$value;


        }



        $dto =
            $reflection->newInstanceArgs(
                $args
            );



        $dto->validate();



        return $dto;

    }





    public static function fromJson(
        string $json
    ): static
    {

        return static::fromArray(
            json_decode(
                $json,
                true
            ) ?? []
        );

    }





    public function toArray(): array
    {

        return get_object_vars(
            $this
        );

    }





    public function toJson(): string
    {

        return json_encode(
            $this,
            JSON_UNESCAPED_UNICODE
        );

    }





    public function jsonSerialize(): array
    {

        return $this->toArray();

    }





    public function get(
        string $property
    ): mixed
    {

        if(!property_exists($this,$property)){

            throw new InvalidArgumentException(
                "Propiedad inexistente: {$property}"
            );

        }


        return $this->{$property};

    }





    public function has(
        string $property
    ): bool
    {

        return property_exists(
            $this,
            $property
        );

    }





    protected function validate(): void
    {

    }


}