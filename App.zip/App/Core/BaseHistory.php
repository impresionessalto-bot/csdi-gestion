<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use RuntimeException;

abstract class BaseHistory
{
    protected PDO $db;


    /**
     * Tabla donde se guarda el historial.
     *
     * Ejemplo:
     * registros
     * movimientos
     * auditoria_clientes
     */
    protected string $table;



    /**
     * Campo de relación.
     *
     * Ejemplo:
     * cliente_id
     * equipo_id
     */
    protected string $foreignKey = 'id';



    public function __construct(PDO $db)
    {
        $this->db = $db;


        if (empty($this->table)) {

            throw new RuntimeException(
                'Tabla de historial no definida en ' . static::class
            );

        }
    }



    /* ==========================================================
     * LISTADO HISTORIAL
     * ========================================================== */

    public function all(
        int $id,
        int $limit = 100
    ): array {

        $sql = "
            SELECT *
            FROM {$this->table}
            WHERE {$this->foreignKey} = ?
            ORDER BY fecha DESC
            LIMIT {$limit}
        ";


        $stmt = $this->db->prepare($sql);


        $stmt->execute([
            $id
        ]);


        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }




    /* ==========================================================
     * ULTIMO REGISTRO
     * ========================================================== */

    public function last(
        int $id
    ): ?array {


        $sql = "
            SELECT *
            FROM {$this->table}
            WHERE {$this->foreignKey} = ?
            ORDER BY fecha DESC
            LIMIT 1
        ";


        $stmt = $this->db->prepare($sql);


        $stmt->execute([
            $id
        ]);


        $data =
            $stmt->fetch(PDO::FETCH_ASSOC);


        return $data ?: null;

    }




    /* ==========================================================
     * BUSCAR POR FECHAS
     * ========================================================== */

    public function between(
        string $desde,
        string $hasta,
        ?int $id = null
    ): array {


        $sql = "
            SELECT *
            FROM {$this->table}
            WHERE fecha BETWEEN ? AND ?
        ";


        $params = [
            $desde,
            $hasta
        ];



        if ($id !== null) {


            $sql .= "
                AND {$this->foreignKey} = ?
            ";


            $params[] = $id;

        }



        $sql .= "
            ORDER BY fecha DESC
        ";



        $stmt = $this->db->prepare($sql);


        $stmt->execute($params);


        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }





    /* ==========================================================
     * ELIMINAR HISTORIAL
     * ========================================================== */


    public function delete(
        int $id
    ): bool {


        $sql = "
            DELETE FROM {$this->table}
            WHERE id = ?
        ";


        $stmt = $this->db->prepare($sql);


        $stmt->execute([
            $id
        ]);



        return $stmt->rowCount() > 0;

    }





    /* ==========================================================
     * CONTADOR DE MOVIMIENTOS
     * ========================================================== */


    public function count(
        int $id
    ): int {


        $sql = "
            SELECT COUNT(*)
            FROM {$this->table}
            WHERE {$this->foreignKey} = ?
        ";


        $stmt = $this->db->prepare($sql);


        $stmt->execute([
            $id
        ]);



        return (int)$stmt->fetchColumn();

    }





    /* ==========================================================
     * ÚLTIMOS MOVIMIENTOS GLOBALES
     * ========================================================== */


    public function latest(
        int $limit = 50
    ): array {


        $sql = "
            SELECT *
            FROM {$this->table}
            ORDER BY fecha DESC
            LIMIT {$limit}
        ";



        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC);

    }





    /* ==========================================================
     * REGISTRO MANUAL
     * ========================================================== */


    public function insert(
        array $data
    ): int {


        if (!$data) {

            throw new RuntimeException(
                'No hay datos para guardar historial.'
            );

        }



        $fields =
            array_keys($data);



        $columns =
            implode(',', $fields);



        $values =
            implode(
                ',',
                array_fill(
                    0,
                    count($fields),
                    '?'
                )
            );



        $sql = "
            INSERT INTO {$this->table}
            ({$columns})
            VALUES
            ({$values})
        ";



        $stmt = $this->db->prepare($sql);


        $stmt->execute(
            array_values($data)
        );



        return (int)$this->db->lastInsertId();

    }





    /* ==========================================================
     * ESTADÍSTICAS
     * ========================================================== */


    public function stats(): array
    {

        return [

            'total' =>
                (int)$this->db
                    ->query(
                        "SELECT COUNT(*) FROM {$this->table}"
                    )
                    ->fetchColumn()

        ];

    }

}