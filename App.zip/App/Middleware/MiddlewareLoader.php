<?php

declare(strict_types=1);

namespace App\Core;

final class MiddlewareLoader
{
    private static array $map = [
        'auth'  => \App\Core\Middleware\AuthMiddleware::class,
        'csrf'  => \App\Core\Middleware\CsrfMiddleware::class,
        'admin' => \App\Core\Middleware\AdminMiddleware::class,
    ];

    public static function resolve(string|object $middleware): object
    {
        if (is_object($middleware)) {
            return $middleware;
        }

        $class = self::$map[$middleware] ?? $middleware;

        self::autoloadIfNeeded($class);

        if (!class_exists($class)) {
            throw new \Exception("Middleware not found: " . $class);
        }

        $instance = new $class();

        if (!method_exists($instance, 'handle')) {
            throw new \Exception("Invalid middleware: missing handle()");
        }

        return $instance;
    }

    private static function autoloadIfNeeded(string $class): void
    {
        if (class_exists($class)) {
            return;
        }

        $basePath = BASE_PATH . '/App/';

        $relative = str_replace('App\\', '', $class);
        $file = $basePath . str_replace('\\', '/', $relative) . '.php';

        if (file_exists($file)) {
            require_once $file;
        }
    }
}