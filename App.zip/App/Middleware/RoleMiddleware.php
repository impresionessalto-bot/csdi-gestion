<?php

declare(strict_types=1);

namespace App\Middleware;


final class RoleMiddleware
{


    public static function handle(
        string $roleRequired
    ): void
    {


        if(
            session_status()
            ===
            PHP_SESSION_NONE
        ){

            session_start();

        }



        $user =
            $_SESSION['user']
            ??
            [];






        /*
        |--------------------------------------------------------------------------
        | SUPER ADMIN BYPASS
        |--------------------------------------------------------------------------
        */


        if(
            !empty($user['es_superadmin'])
            &&
            (int)$user['es_superadmin'] === 1
        ){

            return;

        }







        /*
        |--------------------------------------------------------------------------
        | ROL ACTUAL
        |--------------------------------------------------------------------------
        */


        $role =

            strtolower(

                (string)(

                    $user['role']
                    ??
                    $user['rol']
                    ??
                    $_SESSION['role']
                    ??
                    ''

                )

            );







        /*
        |--------------------------------------------------------------------------
        | VALIDAR
        |--------------------------------------------------------------------------
        */


        if(
            $role !== strtolower($roleRequired)
        ){


            self::deny(
                $roleRequired
            );


        }


    }









    private static function deny(
        string $roleRequired
    ): void
    {


        http_response_code(403);



        if(
            isset($_SERVER['HTTP_X_REQUESTED_WITH'])
            &&
            $_SERVER['HTTP_X_REQUESTED_WITH']
            ===
            'XMLHttpRequest'
        ){


            header(
                'Content-Type: application/json; charset=utf-8'
            );


            echo json_encode([

                'success'=>false,

                'message'=>
                    "Acceso denegado. Requiere rol: {$roleRequired}"

            ]);


            exit;


        }






        echo "

            <h1>403 - Acceso Denegado</h1>

            <p>
            No tienes permisos para acceder a este recurso.
            </p>

        ";


        exit;


    }



}