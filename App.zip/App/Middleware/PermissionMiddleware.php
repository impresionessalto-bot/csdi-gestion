<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Services\Permission\PermissionService;
use RuntimeException;


final class PermissionMiddleware
{


    /**
     * Ejecutar middleware
     */
    public static function handle(
        string $permission
    ): void
    {


        if(
            session_status()
            ===
            PHP_SESSION_NONE
        ){

            session_start();

        }





        /*
        |--------------------------------------------------------------------------
        | Usuario autenticado
        |--------------------------------------------------------------------------
        */


        $user =
            $_SESSION['user']
            ??
            null;



        if(!$user)
        {

            self::deny(
                'Usuario no autenticado.'
            );

        }







        /*
        |--------------------------------------------------------------------------
        | Crear servicio
        |--------------------------------------------------------------------------
        |
        | Usa el contenedor si existe.
        | Si no, crea con PDO directo.
        |
        |--------------------------------------------------------------------------
        */


        try {


            $service =
                \App\Core\Container::make(
                    PermissionService::class
                );



        }
        catch(\Throwable $e)
        {


            $db =
                \App\Core\Container::db();



            $service =
                new PermissionService(
                    $db
                );


        }








        /*
        |--------------------------------------------------------------------------
        | Validar permiso
        |--------------------------------------------------------------------------
        */


        if(
            !$service->can(
                $permission
            )
        )
        {

            self::deny(
                "Sin permiso: {$permission}"
            );

        }



    }









    /**
     * Respuesta acceso denegado
     */
    private static function deny(
        string $message
    ):void
    {


        http_response_code(403);



        /*
        |--------------------------------------------------------------------------
        | AJAX
        |--------------------------------------------------------------------------
        */


        if(
            isset($_SERVER['HTTP_X_REQUESTED_WITH'])
            &&
            strtolower(
                $_SERVER['HTTP_X_REQUESTED_WITH']
            )
            ===
            'xmlhttprequest'
        )
        {


            header(
                'Content-Type: application/json; charset=utf-8'
            );


            echo json_encode([

                'success'=>false,

                'message'=>$message

            ]);


            exit;

        }







        /*
        |--------------------------------------------------------------------------
        | HTML normal
        |--------------------------------------------------------------------------
        */


        echo "

        <!DOCTYPE html>

        <html>

        <head>

            <title>403</title>

            <style>

                body{

                    font-family:Arial;
                    background:#111;
                    color:#fff;
                    text-align:center;
                    padding-top:80px;

                }


                .box{

                    background:#222;
                    display:inline-block;
                    padding:30px;
                    border-radius:10px;

                }

            </style>

        </head>


        <body>


            <div class='box'>


                <h1>
                    403 - Acceso Denegado
                </h1>


                <p>
                    {$message}
                </p>


            </div>


        </body>


        </html>

        ";


        exit;


    }



}