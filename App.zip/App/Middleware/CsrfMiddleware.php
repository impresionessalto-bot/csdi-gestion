<?php
declare(strict_types=1);

namespace App\Middleware;

final class CsrfMiddleware implements MiddlewareInterface
{
    public static function handle(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

            if (
                empty($_SESSION['csrf_token']) 
                || !hash_equals($_SESSION['csrf_token'], $token)
            ) {
                http_response_code(403);
                
                if (
                    isset($_SERVER['HTTP_X_REQUESTED_WITH'])
                    && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest'
                ) {
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode([
                        'success' => false,
                        'message' => 'Token CSRF inválido o expirado.'
                    ]);
                    exit;
                }

                header('Location: /login?error=csrf');
                exit;
            }
        }
    }
}