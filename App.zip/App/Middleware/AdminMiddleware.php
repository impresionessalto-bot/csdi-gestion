<?php
declare(strict_types=1);

namespace App\Middleware;

final class AdminMiddleware implements MiddlewareInterface
{
    public static function handle(): void
    {
        // Lógica específica para verificar permisos de administrador
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $user = $_SESSION['user'] ?? null;

        // Validar si es admin (ajustá según tu lógica de roles)
        if (!is_array($user) || empty($user) || ($user['role'] ?? '') !== 'admin') {
            http_response_code(403);
            if (!headers_sent()) {
                header('Location: /unauthorized');
            }
            exit;
        }
    }
}