<?php

declare(strict_types=1);

namespace App\Middleware;


final class AuthMiddleware implements MiddlewareInterface
{


    public static function handle(): void
    {


        $user =
            $_SESSION['user']
            ?? null;



        if(
            !is_array($user)
            ||
            empty($user)
        )
        {

            self::deny();

        }


    }





    private static function deny(): never
    {


        $isAjax =
            (
                $_SERVER['HTTP_X_REQUESTED_WITH']
                ??
                ''
            )
            ===
            'XMLHttpRequest';




        if($isAjax)
        {


            http_response_code(401);


            header(
                'Content-Type: application/json; charset=utf-8'
            );



            echo json_encode(

                [
                    'success'=>false,
                    'message'=>'Sesión expirada.'
                ],

                JSON_UNESCAPED_UNICODE

            );


            exit;


        }





        if(!headers_sent())
        {

            header(
                'Location: /login'
            );

        }



        exit;


    }



}