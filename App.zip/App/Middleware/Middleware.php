<?php

declare(strict_types=1);

namespace App\Core\Middleware;

final class Middleware
{
    /**
     * Ejecuta lista de middlewares con control de flujo
     */
    public static function handle(array $middlewares = []): void
    {
        foreach ($middlewares as $middlewareClass) {

            if (!class_exists($middlewareClass)) {
                throw new \Exception("Middleware no existe: {$middlewareClass}");
            }

            $instance = new $middlewareClass();

            if (!$instance instanceof MiddlewareInterface) {
                throw new \Exception("Middleware inválido: {$middlewareClass}");
            }

            /**
             * IMPORTANTE:
             * El middleware puede cortar ejecución
             */
            $result = $instance->handle();

            if ($result === false) {
                // Middleware bloqueó acceso
                exit;
            }
        }
    }
}