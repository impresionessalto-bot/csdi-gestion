<?php

declare(strict_types=1);

namespace App\Middleware;

use Closure;
use RuntimeException;


final class PortalTngMiddleware
{


    /*
    |--------------------------------------------------------------------------
    | HANDLE
    |--------------------------------------------------------------------------
    */

    public function handle(
        Closure $next
    ): mixed
    {


        /*
        |--------------------------------------------------------------------------
        | USUARIO LOGUEADO
        |--------------------------------------------------------------------------
        */


        if(
            empty($_SESSION['user'])
        ){

            header(
                'Location: /login'
            );

            exit;

        }





        /*
        |--------------------------------------------------------------------------
        | PERMISOS
        |--------------------------------------------------------------------------
        */


        $usuario =
            $_SESSION['user'];



        $permisos =
            $usuario['permissions']
            ??
            [];





        /*
        |--------------------------------------------------------------------------
        | PERMISO PORTAL TNG
        |--------------------------------------------------------------------------
        */


        if(
            !in_array(
                'portal_tng.view',
                $permisos,
                true
            )
        ){

            throw new RuntimeException(
                'No tiene permisos para acceder al Portal TNG.'
            );

        }





        /*
        |--------------------------------------------------------------------------
        | CONTINUAR
        |--------------------------------------------------------------------------
        */


        return $next();

    }


}