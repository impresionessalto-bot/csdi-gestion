namespace App\Interfaces;

interface CounterProviderInterface {
    public function getLatestReading(int $equipmentId): array;
    public function getConsumptions(int $equipmentId, int $year): array;
}