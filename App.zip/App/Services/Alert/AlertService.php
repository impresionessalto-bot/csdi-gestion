<?php

declare(strict_types=1);

namespace App\Services\Alert;

use PDO;
use Throwable;


final class AlertService
{


    public function __construct(
        private readonly PDO $db
    )
    {

    }







    /**
     * Alertas generales ERP
     */
    public function generales():array
    {


        $alertas=[];



        $alertas=array_merge(

            $alertas,

            $this->clientes(),

            $this->equipos(),

            $this->servicios(),

            $this->inventarioGeneral()

        );



        return $alertas;


    }









    /**
     * Alertas cliente
     */
    public function cliente(
        int $clienteId
    ):array
    {


        if($clienteId<=0)
        {

            return [];

        }



        return [];

    }









    /**
     * Alertas equipo
     */
    public function equipo(
        int $equipoId
    ):array
    {

        return [];

    }









    /**
     * Alertas técnico
     */
    public function tecnico(
        int $tecnicoId
    ):array
    {

        return [];

    }









    /**
     * Alertas contrato
     */
    public function contrato(
        int $contratoId
    ):array
    {

        return [];

    }









    /**
     * Alertas producto
     */
    public function inventario(
        int $productoId
    ):array
    {

        return [];

    }









    /**
     * Clientes inactivos
     */
    private function clientes():array
    {


        try {


            $cantidad=(int)
                $this->db
                ->query("
                    SELECT COUNT(*)
                    FROM clientes
                    WHERE activo=0
                ")
                ->fetchColumn();



            if($cantidad>0)
            {

                return [

                    [

                        'tipo'=>'warning',

                        'titulo'=>'Clientes',

                        'modulo'=>'clientes',

                        'mensaje'=>
                            "{$cantidad} clientes inactivos"

                    ]

                ];

            }


        }
        catch(Throwable)
        {


        }



        return [];


    }









    /**
     * Equipos sin cliente
     */
    private function equipos():array
    {


        try {


            $cantidad=(int)
                $this->db
                ->query("
                    SELECT COUNT(*)
                    FROM equipos
                    WHERE cliente_id IS NULL
                    OR cliente_id=0
                ")
                ->fetchColumn();



            if($cantidad>0)
            {

                return [

                    [

                        'tipo'=>'warning',

                        'titulo'=>'Equipos',

                        'modulo'=>'equipos',

                        'mensaje'=>
                            "{$cantidad} equipos sin cliente asignado"

                    ]

                ];

            }



        }
        catch(Throwable)
        {


        }



        return [];

    }









    /**
     * Servicios pendientes
     */
    private function servicios():array
    {


        try {


            $cantidad=(int)
                $this->db
                ->query("
                    SELECT COUNT(*)
                    FROM servicios
                    WHERE estado='Pendiente'
                ")
                ->fetchColumn();



            if($cantidad>0)
            {

                return [

                    [

                        'tipo'=>'danger',

                        'titulo'=>'Servicio Técnico',

                        'modulo'=>'servicios',

                        'mensaje'=>
                            "{$cantidad} servicios pendientes"

                    ]

                ];

            }



        }
        catch(Throwable)
        {


        }



        return [];

    }









    /**
     * Inventario
     */
    private function inventarioGeneral():array
    {


        return [];


    }



}