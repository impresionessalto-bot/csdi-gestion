	<?php
declare(strict_types=1);

namespace App\Services\Export;

use PDO;
use RuntimeException;


final class NumberService
{


    public function __construct(
        private PDO $db
    )
    {

    }




    /**
     * Obtener siguiente número
     *
     * Ej:
     * OT-000126
     */
    public function next(
        string $tipo
    ): string
    {


        $this->db->beginTransaction();


        try {


            $stmt =
                $this->db->prepare(

                    "
                    SELECT *
                    FROM numeradores
                    WHERE tipo = ?
                    FOR UPDATE
                    "

                );


            $stmt->execute([
                $tipo
            ]);



            $numerador =
                $stmt->fetch(
                    PDO::FETCH_ASSOC
                );



            if(!$numerador){

                throw new RuntimeException(
                    "No existe numerador: {$tipo}"
                );

            }




            $nuevoNumero =
                (int)$numerador['ultimo_numero']
                +
                1;




            $update =
                $this->db->prepare(

                    "
                    UPDATE numeradores

                    SET ultimo_numero = ?

                    WHERE tipo = ?

                    "

                );



            $update->execute([

                $nuevoNumero,

                $tipo

            ]);






            $this->db->commit();




            return
                $this->format(

                    $numerador['prefijo'],

                    $nuevoNumero,

                    (int)$numerador['longitud']

                );



        }
        catch(\Throwable $e)
        {


            if(
                $this->db->inTransaction()
            ){

                $this->db->rollBack();

            }


            throw $e;


        }


    }





    /**
     * Crear numerador nuevo
     */
    public function create(
        string $tipo,
        ?string $prefijo = null,
        int $inicio = 0,
        int $longitud = 6
    ):void
    {


        $stmt =
            $this->db->prepare(

                "
                INSERT INTO numeradores
                (
                    tipo,
                    prefijo,
                    ultimo_numero,
                    longitud
                )

                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?
                )

                "

            );



        $stmt->execute([

            $tipo,

            $prefijo,

            $inicio,

            $longitud

        ]);


    }





    /**
     * Vista previa
     */
    public function preview(
        string $tipo
    ):string
    {


        $stmt =
            $this->db->prepare(

                "
                SELECT *
                FROM numeradores
                WHERE tipo = ?
                "

            );



        $stmt->execute([
            $tipo
        ]);



        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );



        if(!$row){

            throw new RuntimeException(
                'Numerador inexistente'
            );

        }



        return
            $this->format(

                $row['prefijo'],

                (int)$row['ultimo_numero'] + 1,

                (int)$row['longitud']

            );


    }





    /**
     * Formatear número
     */
    private function format(
        ?string $prefijo,
        int $numero,
        int $longitud
    ):string
    {


        $numeroFormateado =
            str_pad(
                (string)$numero,
                $longitud,
                '0',
                STR_PAD_LEFT
            );



        return

            ($prefijo
                ? $prefijo.'-'
                : ''
            )
            .
            $numeroFormateado;


    }





}