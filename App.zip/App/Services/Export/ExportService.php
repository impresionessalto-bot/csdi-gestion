<?php
declare(strict_types=1);

namespace App\Services\Export;


final class ExportService
{


    public function csv(
        array $datos
    ): string
    {

        $archivo = fopen(
            'php://temp',
            'r+'
        );


        if(!empty($datos)){

            fputcsv(
                $archivo,
                array_keys($datos[0])
            );


            foreach($datos as $fila){

                fputcsv(
                    $archivo,
                    $fila
                );

            }

        }


        rewind($archivo);


        return stream_get_contents($archivo);


    }



}