<?php
declare(strict_types=1);

namespace App\Services\Export;

use RuntimeException;


final class ExcelService
{


    /**
     * Descargar Excel
     */
    public function download(
        array $datos,
        string $nombre = 'export.xlsx'
    ):void
    {


        if(empty($datos))
        {

            throw new RuntimeException(
                'No hay datos para exportar'
            );

        }



        $filename =
            preg_replace(
                '/[^a-zA-Z0-9_\-\.]/',
                '_',
                $nombre
            );





        header(
            'Content-Type: application/vnd.ms-excel; charset=utf-8'
        );


        header(
            'Content-Disposition: attachment; filename="'.$filename.'"'
        );



        header(
            'Pragma: no-cache'
        );


        header(
            'Expires: 0'
        );







        echo "\xEF\xBB\xBF";



        $columnas =
            array_keys(
                $datos[0]
            );



        echo implode(
            ';',
            $columnas
        );

        echo "\n";







        foreach($datos as $fila)
        {


            $linea=[];



            foreach($columnas as $columna)
            {

                $valor =
                    $fila[$columna]
                    ??
                    '';



                $valor =
                    str_replace(
                        [
                            ";",
                            "\n",
                            "\r"
                        ],
                        [
                            ",",
                            " ",
                            " "
                        ],
                        (string)$valor
                    );



                $linea[]=$valor;


            }



            echo implode(
                ';',
                $linea
            );


            echo "\n";


        }




        exit;


    }









    /**
     * Generar archivo físico
     */
    public function generar(
        array $datos,
        string $nombre
    ):string
    {


        $directorio =
            BASE_PATH.'/storage/export';



        if(!is_dir($directorio))
        {

            mkdir(
                $directorio,
                0775,
                true
            );

        }




        $archivo =
            $directorio
            .'/'
            .$nombre;





        $handle =
            fopen(
                $archivo,
                'w'
            );



        if(!$handle)
        {

            throw new RuntimeException(
                'No se pudo crear archivo Excel'
            );

        }





        if(!empty($datos))
        {


            fputcsv(
                $handle,
                array_keys($datos[0]),
                ';'
            );



            foreach($datos as $fila)
            {

                fputcsv(
                    $handle,
                    $fila,
                    ';'
                );

            }


        }



        fclose($handle);



        return $archivo;


    }



}