<?php

declare(strict_types=1);

namespace App\Services\Export;


use RuntimeException;
use Throwable;



final class CsvService
{


    private string $directory;





    public function __construct()
    {


        $base =
            defined('BASE_PATH')
            ?
            BASE_PATH
            :
            dirname(__DIR__,3);



        $this->directory =
            $base
            .
            '/storage/export/csv';



        $this->ensureDirectory();


    }









    /**
     * Descargar CSV directo al navegador
     */
    public function download(
        array $datos,
        string $nombre = 'export.csv'
    ):void
    {


        header(
            'Content-Type: text/csv; charset=UTF-8'
        );


        header(
            'Content-Disposition: attachment; filename="'.$nombre.'"'
        );



        // BOM para Excel
        echo "\xEF\xBB\xBF";



        $salida =
            fopen(
                'php://output',
                'w'
            );



        $this->write(
            $salida,
            $datos
        );



        fclose(
            $salida
        );


        exit;


    }









    /**
     * Generar archivo físico
     */
    public function generar(
        array $datos,
        string $nombre='export'
    ):string
    {


        try {


            $archivo =

                $this->directory
                .
                '/'
                .
                $this->filename(
                    $nombre
                );



            $handle =
                fopen(
                    $archivo,
                    'w'
                );



            if(!$handle){


                throw new RuntimeException(
                    'No se pudo crear CSV'
                );

            }



            // BOM Excel
            fwrite(
                $handle,
                "\xEF\xBB\xBF"
            );



            $this->write(
                $handle,
                $datos
            );



            fclose(
                $handle
            );



            return $archivo;



        }
        catch(Throwable $e)
        {

            throw new RuntimeException(
                $e->getMessage()
            );

        }


    }









    /**
     * Escribir datos CSV
     */
    private function write(
        mixed $handle,
        array $datos
    ):void
    {


        if(empty($datos)){
            return;
        }



        fputcsv(
            $handle,
            array_keys(
                $datos[0]
            )
        );



        foreach($datos as $fila){


            fputcsv(
                $handle,
                $fila
            );


        }


    }









    /**
     * Nombre seguro
     */
    private function filename(
        string $nombre
    ):string
    {


        $nombre =

            strtolower(
                preg_replace(
                    '/[^a-zA-Z0-9]/',
                    '_',
                    $nombre
                )
            );



        return

            $nombre
            .
            '_'
            .
            date('Ymd_His')
            .
            '.csv';


    }









    /**
     * Crear carpeta
     */
    private function ensureDirectory():void
    {


        if(!is_dir($this->directory)){


            mkdir(
                $this->directory,
                0775,
                true
            );


        }


    }


}