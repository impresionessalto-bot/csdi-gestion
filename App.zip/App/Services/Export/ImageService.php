<?php
declare(strict_types=1);

namespace App\Services\Export;


final class ImageService
{


    public function guardar(
        array $archivo,
        string $carpeta
    ): string
    {

        // validar extensión
        // crear carpeta
        // mover archivo
        // devolver ruta

    }



    public function eliminar(
        string $ruta
    ): bool
    {

        if(is_file($ruta)){
            return unlink($ruta);
        }

        return false;

    }



    public function validar(
        array $archivo
    ): bool
    {

        $permitidos = [
            'jpg',
            'jpeg',
            'png',
            'webp'
        ];


        $extension = strtolower(
            pathinfo(
                $archivo['name'],
                PATHINFO_EXTENSION
            )
        );


        return in_array(
            $extension,
            $permitidos,
            true
        );

    }



}