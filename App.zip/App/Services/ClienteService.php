<?php
declare(strict_types=1);

namespace App\Services;

use App\Repositories\ClienteRepository;
use RuntimeException;


final class ClienteService
{


    public function __construct(
        private ClienteRepository $repo
    )
    {

    }





    /*
    |--------------------------------------------------------------------------
    | COMBO GENERAL
    |--------------------------------------------------------------------------
    */

    public function combo(): array
    {

        return $this->repo->combo();

    }





    /*
    |--------------------------------------------------------------------------
    | TODOS LOS CLIENTES
    |
    | Compatibilidad módulos ERP
    |--------------------------------------------------------------------------
    */

    public function todos(): array
    {

        return $this->repo->all();

    }





    /*
    |--------------------------------------------------------------------------
    | LISTADO GENERAL
    |--------------------------------------------------------------------------
    */

    public function listado(): array
    {

        return $this->repo->all();

    }





    /*
    |--------------------------------------------------------------------------
    | CLIENTES POR LOCALIDAD
    |--------------------------------------------------------------------------
    */

    public function porLocalidad(
        int $localidadId
    ): array
    {


        if($localidadId <= 0){

            return [];

        }



        return $this->repo->porLocalidad(
            $localidadId
        );


    }





    /*
    |--------------------------------------------------------------------------
    | OBTENER CLIENTE
    |--------------------------------------------------------------------------
    */

    public function obtener(
        int $id
    ): array
    {


        $cliente =
            $this->repo->find($id);



        if(!$cliente){


            throw new RuntimeException(
                'Cliente inexistente'
            );


        }



        return $cliente;


    }





    /*
    |--------------------------------------------------------------------------
    | BUSCADOR
    |--------------------------------------------------------------------------
    */

    public function buscar(
        string $texto
    ): array
    {


        $texto =
            trim($texto);



        if($texto === ''){

            return [];

        }



        return $this->repo->search(
            $texto
        );


    }





    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(
        array $data
    ): int
    {


        if(empty($data['nombre'])){


            throw new RuntimeException(
                'El nombre del cliente es obligatorio'
            );


        }



        return $this->repo->create(
            $data
        );


    }





    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(
        int $id,
        array $data
    ): bool
    {


        return $this->repo->update(
            $id,
            $data
        );


    }





    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(
        int $id
    ): bool
    {


        return $this->repo->delete(
            $id
        );


    }





    /*
    |--------------------------------------------------------------------------
    | EXISTE
    |--------------------------------------------------------------------------
    */

    public function existe(
        int $id
    ): bool
    {


        return $this->repo->find($id) !== null;


    }


}