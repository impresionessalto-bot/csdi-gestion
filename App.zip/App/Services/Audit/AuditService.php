<?php

declare(strict_types=1);

namespace App\Services\Audit;

use PDO;
use Throwable;

/**
 * =========================================================
 * CSDI ERP PRO
 *
 * AUDIT SERVICE
 *
 * Servicio transversal de auditoría
 *
 * Registra:
 * - Altas
 * - Modificaciones
 * - Eliminaciones
 * - Historial de cambios
 *
 * =========================================================
 */
final class AuditService
{
    public function __construct(
        private readonly PDO $db
    ) {}

    /**
     * Registro general
     */
    public function log(
        string $modulo,
        string $accion,
        ?string $tabla = null,
        ?int $registroId = null,
        ?string $descripcion = null,
        ?array $antes = null,
        ?array $despues = null
    ): void {
        try {
            $usuarioId = $_SESSION['user']['id'] ?? $_SESSION['usuario_id'] ?? null;
            $ip = $_SERVER['REMOTE_ADDR'] ?? null;

            $sql = "
                INSERT INTO auditoria
                (
                    usuario_id,
                    modulo,
                    accion,
                    tabla_afectada,
                    registro_id,
                    descripcion,
                    datos_anteriores,
                    datos_nuevos,
                    ip
                )
                VALUES
                (
                    :usuario_id,
                    :modulo,
                    :accion,
                    :tabla,
                    :registro_id,
                    :descripcion,
                    :antes,
                    :despues,
                    :ip
                )
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                ':usuario_id' => $usuarioId,
                ':modulo' => $modulo,
                ':accion' => $accion,
                ':tabla' => $tabla,
                ':registro_id' => $registroId,
                ':descripcion' => $descripcion,
                ':antes' => $this->json($antes),
                ':despues' => $this->json($despues),
                ':ip' => $ip
            ]);
        } catch (Throwable) {
            /* La auditoría nunca rompe el ERP */
            return;
        }
    }

    /**
     * Convertir arrays a JSON
     */
    private function json(?array $data): ?string
    {
        if (!$data) {
            return null;
        }

        $json = json_encode(
            $data,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        return $json ?: null;
    }

    /**
     * Registro creación
     */
    public function created(string $modulo, string $tabla, int $id, array $datos = []): void
    {
        $this->log($modulo, 'CREATE', $tabla, $id, 'Registro creado', null, $datos);
    }

    /**
     * Registro actualización
     */
    public function updated(string $modulo, string $tabla, int $id, array $antes, array $despues): void
    {
        $this->log($modulo, 'UPDATE', $tabla, $id, 'Registro actualizado', $antes, $despues);
    }

    /**
     * Registro eliminación
     */
    public function deleted(string $modulo, string $tabla, int $id, array $datos = []): void
    {
        $this->log($modulo, 'DELETE', $tabla, $id, 'Registro eliminado', $datos, null);
    }

    /**
     * Historial
     */
    public function history(?string $modulo = null, ?int $registroId = null): array
    {
        try {
            $sql = "
                SELECT *
                FROM auditoria
                WHERE 1=1
            ";

            $params = [];

            if ($modulo !== null) {
                $sql .= " AND modulo = :modulo ";
                $params[':modulo'] = $modulo;
            }

            if ($registroId !== null) {
                $sql .= " AND registro_id = :registro ";
                $params[':registro'] = $registroId;
            }

            $sql .= " ORDER BY fecha DESC ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable) {
            return [];
        }
    }
}