<?php
declare(strict_types=1);

namespace App\Services;

use PDO;

final class EquipoService
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Obtiene los equipos de un cliente específico o el stock técnico libre (si clienteId es 0)
     */
    public function porCliente(int $clienteId, ?string $propiedad = null): array
    {
        // CORRECCIÓN CLAVE: Si es 0, cambiamos la consulta para traer máquinas en stock/taller (cliente_id es NULL o 0)
        if ($clienteId === 0) {
            $sql = "
                SELECT 
                    e.id,
                    e.codigo_interno,
                    e.serie,
                    e.propiedad,
                    e.estado,
                    e.activo,
                    m.nombre_modelo,
                    m.marca,
                    m.tipo
                FROM equipos e
                LEFT JOIN modelos_equipos m ON m.id = e.modelo_id
                WHERE (e.cliente_id IS NULL OR e.cliente_id = 0)
            ";
            $params = [];
        } else {
            if ($clienteId < 0) {
                return [];
            }
            $sql = "
                SELECT 
                    e.id,
                    e.codigo_interno,
                    e.serie,
                    e.propiedad,
                    e.estado,
                    e.activo,
                    m.nombre_modelo,
                    m.marca,
                    m.tipo
                FROM equipos e
                LEFT JOIN modelos_equipos m ON m.id = e.modelo_id
                WHERE e.cliente_id = ?
            ";
            $params = [$clienteId];
        }

        if ($propiedad !== null) {
            $sql .= " AND e.propiedad = ? ";
            $params[] = $propiedad;
        }

        $sql .= " AND e.activo = 1 ORDER BY m.nombre_modelo ASC ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Buscar equipo por ID
     */
    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT 
                e.*,
                m.nombre_modelo,
                m.marca
            FROM equipos e
            LEFT JOIN modelos_equipos m ON m.id=e.modelo_id
            WHERE e.id = ?
            LIMIT 1
        ");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * ALIAS REQUERIDO POR CONTROLLER ANTERIOR
     */
    public function buscar(string $id): array
    {
        $res = $this->find((int)$id);
        return $res ? [$id => $res] : [];
    }

    public function csdi(int $clienteId): array
    {
        return $this->porCliente($clienteId, 'CSDI');
    }

    public function tng(int $clienteId): array
    {
        return $this->porCliente($clienteId, 'TNG');
    }

    public function todos(?string $propiedad=null): array
    {
        $sql = "
            SELECT 
                e.id,
                e.serie,
                e.propiedad,
                c.nombre AS cliente_nombre,
                m.nombre_modelo
            FROM equipos e
            LEFT JOIN clientes c ON c.id=e.cliente_id
            LEFT JOIN modelos_equipos m ON m.id=e.modelo_id
            WHERE e.activo=1
        ";
        $params = [];

        if ($propiedad) {
            $sql .= " AND e.propiedad=? ";
            $params[] = $propiedad;
        }

        $sql .= " ORDER BY c.nombre ASC ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * =====================================================
     * NUEVOS MÉTODOS CRUD INTERNOS (EVITAN EL ERROR 500)
     * =====================================================
     */

    /**
     * Cambia el estado técnico del equipo (Ej: Disponible, En Reparación, Baja)
     */
    public function actualizarEstado(int $id, string $estado, array $metadata = []): bool
    {
        $observaciones = $metadata['observaciones'] ?? '';
        $sql = "UPDATE equipos SET estado = ?, observaciones = CONCAT(IFNULL(observaciones,''), ?) WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$estado, " | " . $observaciones, $id]);
    }

    /**
     * Vincula un equipo de stock a un cliente nuevo y lo pone en estado 'Activo'
     */
    public function asignarCliente(int $id, int $clienteId): bool
    {
        $sql = "UPDATE equipos SET cliente_id = ?, estado = 'Activo' WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$clienteId, $id]);
    }
}