<?php
declare(strict_types=1);

namespace App\Services;

use PDO;


final class ConfigService
{


    private array $cache = [];



    public function __construct(
        private PDO $db
    )
    {

    }






    /**
     * Obtener configuración
     *
     * Busca primero:
     * configuracion_global
     * luego:
     * configuracion_sistema
     */
    public function get(
        string $clave,
        mixed $default = null
    ):mixed
    {


        if(isset($this->cache[$clave])){

            return $this->cache[$clave];

        }





        /*
        |--------------------------------------------------------------------------
        | GLOBAL
        |--------------------------------------------------------------------------
        */


        $stmt =
            $this->db->prepare(

            "
            SELECT valor,tipo

            FROM configuracion_global

            WHERE clave = ?

            LIMIT 1
            "

        );


        $stmt->execute([
            $clave
        ]);




        $row =
            $stmt->fetch(PDO::FETCH_ASSOC);







        /*
        |--------------------------------------------------------------------------
        | SISTEMA
        |--------------------------------------------------------------------------
        */


        if(!$row){


            $stmt =
                $this->db->prepare(

                "
                SELECT valor

                FROM configuracion_sistema

                WHERE clave = ?

                LIMIT 1
                "

            );


            $stmt->execute([
                $clave
            ]);



            $row =
                $stmt->fetch(PDO::FETCH_ASSOC);



            if($row){

                $row['tipo']='string';

            }


        }








        if(!$row){

            return $default;

        }






        $valor =
            $this->convert(
                $row['valor'],
                $row['tipo'] ?? 'string'
            );




        $this->cache[$clave]=$valor;



        return $valor;


    }









    /**
     * Guardar configuración global
     */
    public function setGlobal(
        string $clave,
        mixed $valor,
        string $tipo='text'
    ):void
    {



        $stmt =
            $this->db->prepare(

            "

            UPDATE configuracion_global

            SET valor = ?

            WHERE clave = ?

            "

        );



        $stmt->execute([

            (string)$valor,

            $clave

        ]);



        unset(
            $this->cache[$clave]
        );


    }









    /**
     * Guardar configuración sistema
     */
    public function setSistema(
        string $clave,
        mixed $valor
    ):void
    {


        $stmt =
            $this->db->prepare(

            "

            UPDATE configuracion_sistema

            SET valor = ?

            WHERE clave = ?

            "

        );



        $stmt->execute([

            (string)$valor,

            $clave

        ]);



        unset(
            $this->cache[$clave]
        );


    }









    /**
     * Todas configuraciones
     */
    public function all():array
    {


        $global =
            $this->db
            ->query(
                "
                SELECT *

                FROM configuracion_global

                ORDER BY categoria,clave
                "
            )
            ->fetchAll(PDO::FETCH_ASSOC);




        $sistema =
            $this->db
            ->query(
                "
                SELECT *

                FROM configuracion_sistema

                ORDER BY clave
                "
            )
            ->fetchAll(PDO::FETCH_ASSOC);





        return [

            'global'=>$global,

            'sistema'=>$sistema

        ];


    }









    private function convert(
        mixed $valor,
        string $tipo
    ):mixed
    {


        return match($tipo){


            'number',
            'integer',
            'int'
                =>
                (float)$valor,



            'boolean'
                =>
                (bool)$valor,



            default
                =>
                $valor


        };


    }








    public function clear():void
    {

        $this->cache=[];

    }


}