<?php

declare(strict_types=1);

namespace App\Services\Document;

use PDO;
use Throwable;


final class DocumentService
{

    public function __construct(
        private readonly PDO $db
    ) {
    }


    public function equipo(int $id): array
    {
        return $this->buscar(
            'equipo',
            $id
        );
    }



    public function cliente(int $id): array
    {
        return $this->buscar(
            'cliente',
            $id
        );
    }



    public function contrato(int $id): array
    {
        return $this->buscar(
            'contrato',
            $id
        );
    }



    public function inventario(int $id): array
    {
        return $this->buscar(
            'inventario',
            $id
        );
    }



    public function tecnico(int $id): array
    {
        return $this->buscar(
            'tecnico',
            $id
        );
    }





    private function buscar(
        string $tipo,
        int $id
    ): array
    {

        try {

            /*
             * Tabla genérica de documentos ERP
             * Se adapta cuando existan las tablas definitivas
             */

            $stmt = $this->db->prepare("
                SELECT *
                FROM documentos
                WHERE tipo = ?
                AND registro_id = ?
                ORDER BY id DESC
            ");


            $stmt->execute([
                $tipo,
                $id
            ]);


            return $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );


        }
        catch(Throwable)
        {

            return [];

        }

    }



}