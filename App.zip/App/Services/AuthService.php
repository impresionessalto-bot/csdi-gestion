<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use RuntimeException;

final class AuthService
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /**
     * Valida las credenciales del usuario contra la base de datos
     */
    public function login(array $postData): array
    {
        $usuario = trim($postData['usuario'] ?? '');
        $password = $postData['password'] ?? '';

        if ($usuario === '' || $password === '') {
            throw new RuntimeException('Credenciales incompletas.');
        }

        $stmt = $this->db->prepare("
            SELECT id, usuario, nombre, email, password, rol, activo 
            FROM usuarios 
            WHERE usuario = ? OR email = ?
            LIMIT 1
        ");
        $stmt->execute([$usuario, $usuario]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            throw new RuntimeException('Usuario no encontrado.');
        }

        if ((int)$user['activo'] !== 1) {
            throw new RuntimeException('El usuario está inactivo.');
        }

        if (!password_verify($password, $user['password'])) {
            throw new RuntimeException('Contraseña incorrecta.');
        }

        unset($user['password']);

        return $user;
    }
}