<?php

declare(strict_types=1);

namespace App\Services\AI;


use RuntimeException;
use Throwable;



final class IaService
{


    private string $provider;


    private ?string $apiKey;


    private bool $enabled;







    public function __construct()
    {


        $this->provider =
            $_ENV['IA_PROVIDER']
            ??
            'local';



        $this->apiKey =
            $_ENV['IA_API_KEY']
            ??
            null;



        $this->enabled =
            !empty($this->apiKey);

    }









    /**
     * Consulta general IA
     */
    public function ask(
        string $prompt
    ):string
    {


        if(trim($prompt)===''){

            throw new RuntimeException(
                'Prompt vacío'
            );

        }



        try {


            if(
                $this->provider==='local'
            ){

                return $this->localResponse(
                    $prompt
                );

            }



            return $this->requestApi(
                $prompt
            );


        }
        catch(Throwable $e)
        {

            return
                'Error IA: '
                .
                $e->getMessage();

        }


    }









    /**
     * Diagnóstico equipo técnico
     */
    public function diagnosticoEquipo(
        array $datos
    ):string
    {


        $prompt = "

        Actúa como técnico especialista.

        Equipo:
        ".($datos['equipo'] ?? '')."

        Marca:
        ".($datos['marca'] ?? '')."

        Modelo:
        ".($datos['modelo'] ?? '')."

        Problema informado:
        ".($datos['problema'] ?? '')."


        Generar:

        1- posibles causas
        2- pruebas recomendadas
        3- solución sugerida
        4- repuestos posibles


        ";




        return $this->ask(
            $prompt
        );


    }









    /**
     * Analizar informes técnicos TNG
     */
    public function analizarInforme(
        array $datos
    ):string
    {


        $prompt = "

        Analizar informe técnico:

        Cliente:
        ".($datos['cliente'] ?? '')."


        Equipo:
        ".($datos['equipo'] ?? '')."


        Observaciones:
        ".($datos['observaciones'] ?? '')."



        Generar resumen ejecutivo
        y recomendaciones.


        ";



        return $this->ask(
            $prompt
        );


    }









    /**
     * Resumen automático
     */
    public function resumir(
        string $texto
    ):string
    {


        return $this->ask(

            "

            Resumir:

            ".$texto

        );


    }









    /**
     * Asistente ERP
     */
    public function asistente(
        string $consulta
    ):string
    {


        return $this->ask(

            "

            Eres asistente interno ERP CSDI.

            Consulta:

            ".$consulta

        );


    }









    /**
     * Estado IA
     */
    public function enabled():bool
    {

        return $this->enabled;

    }









    /**
     * Proveedor activo
     */
    public function provider():string
    {

        return $this->provider;

    }









    /**
     * Respuesta local
     */
    private function localResponse(
        string $prompt
    ):string
    {


        return

            "IA LOCAL ERP CSDI\n\n"

            .

            "Consulta recibida:\n"

            .

            $prompt

            .

            "\n\n"

            .

            "Proveedor externo no conectado.";


    }









    /**
     * API externa futura
     */
    private function requestApi(
        string $prompt
    ):string
    {


        if(!$this->apiKey){

            throw new RuntimeException(
                'API KEY IA no configurada'
            );

        }



        /*
        |--------------------------------------------------------------------------
        |
        | Aquí irá:
        |
        | OpenAI API
        | Gemini API
        | Azure OpenAI
        |
        |--------------------------------------------------------------------------
        */


        return
            'Respuesta IA externa pendiente';



    }



}