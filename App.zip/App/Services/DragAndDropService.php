<?php

declare(strict_types=1);

namespace App\Services;

use PDO;
use InvalidArgumentException;
use RuntimeException;

/**
 * =========================================================
 * ERP CSDI PRO
 * SERVICIO GLOBAL DRAG & DROP
 * =========================================================
 *
 * Servicio transversal para workflows tipo Kanban.
 *
 * NO conoce m�dulos concretos.
 *
 * El m�dulo consumidor define:
 *
 * - tabla
 * - campo ID
 * - campo estado
 * - estados permitidos
 *
 * =========================================================
 */
final class DragAndDropService
{
    public function __construct(
        private readonly PDO $db
    ) {
    }


    /**
     * Cambia el estado de un registro.
     *
     * @param string[] $estadosPermitidos
     */
    public function cambiarEstado(
        string $tabla,
        int $id,
        string $estado,
        array $estadosPermitidos,
        string $campoId = 'id',
        string $campoEstado = 'estado'
    ): array {

        $tabla = $this->identificador($tabla);
        $campoId = $this->identificador($campoId);
        $campoEstado = $this->identificador($campoEstado);

        $estado = trim($estado);

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de registro inv�lido.'
            );
        }

        if ($estado === '') {
            throw new InvalidArgumentException(
                'El estado es obligatorio.'
            );
        }

        if (!in_array(
            $estado,
            $estadosPermitidos,
            true
        )) {
            throw new InvalidArgumentException(
                'El estado seleccionado no es v�lido.'
            );
        }

        /*
         * Verificar que exista el registro.
         */
        $sqlExiste = "
            SELECT
                {$campoId},
                {$campoEstado}
            FROM {$tabla}
            WHERE {$campoId} = :id
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sqlExiste);

        $stmt->execute([
            ':id' => $id,
        ]);

        $actual = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$actual) {
            throw new RuntimeException(
                'El registro solicitado no existe.'
            );
        }

        $estadoAnterior =
            (string)(
                $actual[$campoEstado]
                ?? ''
            );

        /*
         * Si ya est� en ese estado,
         * no necesitamos ejecutar UPDATE.
         */
        if ($estadoAnterior === $estado) {
            return [
                'id' => $id,
                'estado_anterior' => $estadoAnterior,
                'estado' => $estado,
                'cambio' => false,
            ];
        }

        /*
         * Actualizar estado.
         */
        $sqlUpdate = "
            UPDATE {$tabla}
            SET {$campoEstado} = :estado
            WHERE {$campoId} = :id
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sqlUpdate);

        $stmt->execute([
            ':estado' => $estado,
            ':id' => $id,
        ]);

        if ($stmt->rowCount() < 1) {

            /*
             * Puede ocurrir si MySQL considera
             * que el valor no cambi�.
             */
            $verificacion = $this->obtenerEstado(
                $tabla,
                $id,
                $campoId,
                $campoEstado
            );

            if ($verificacion !== $estado) {
                throw new RuntimeException(
                    'No fue posible actualizar el estado.'
                );
            }
        }

        return [
            'id' => $id,
            'estado_anterior' => $estadoAnterior,
            'estado' => $estado,
            'cambio' => true,
        ];
    }


    /**
     * Devuelve el estado actual.
     */
    public function obtenerEstado(
        string $tabla,
        int $id,
        string $campoId = 'id',
        string $campoEstado = 'estado'
    ): ?string {

        $tabla = $this->identificador($tabla);
        $campoId = $this->identificador($campoId);
        $campoEstado = $this->identificador($campoEstado);

        if ($id <= 0) {
            return null;
        }

        $sql = "
            SELECT {$campoEstado}
            FROM {$tabla}
            WHERE {$campoId} = :id
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $id,
        ]);

        $resultado = $stmt->fetchColumn();

        if ($resultado === false) {
            return null;
        }

        return (string)$resultado;
    }


    /**
     * Verifica un identificador SQL.
     *
     * Los nombres de tabla/campo no pueden
     * ser par�metros PDO.
     */
    private function identificador(
        string $value
    ): string {

        $value = trim($value);

        if (
            $value === ''
            ||
            !preg_match(
                '/^[a-zA-Z_][a-zA-Z0-9_]*$/',
                $value
            )
        ) {
            throw new InvalidArgumentException(
                'Identificador SQL inv�lido.'
            );
        }

        return $value;
    }
}