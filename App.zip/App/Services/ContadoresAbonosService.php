<?php

declare(strict_types=1);

namespace App\Services;

use PDO;
use Throwable;
use RuntimeException;
use App\Services\NotificationService; // Servicio de notificaciones / WhatsApp de tu FTP

/**
 * Servicio Global de Control de Odómetros, Integridad de Consumos y Abonos.
 */
final class ContadoresAbonosService
{
    /**
     * El constructor recibe la conexión PDO y el servicio de notificaciones multicanal.
     */
    public function __construct(
        private readonly PDO $db,
        private readonly NotificationService $notificationService
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | 1) VALIDACIÓN LOGICA DE LECTURAS (Evita contadores en reversa y detecta Mono)
    |--------------------------------------------------------------------------
    */
    /**
     * Valida de forma inteligente una lectura antes de ser insertada.
     * - Detecta si el equipo es Monocromático para ignorar y no exigir el contador Color.
     * - Valida que los nuevos contadores jamás sean inferiores a los anteriores registrados en el ERP.
     */
    public function validarLectura(int $equipoId, int $monoActual, int $colorActual): array
    {
        try {
            // 1. Consultar el tipo de equipo (Monocromático o Color) en base a su modelo
            $stmtEquipo = $this->db->prepare("
                SELECT e.id, m.tipo AS tipo_modelo
                FROM equipos e
                LEFT JOIN modelos_equipos m ON m.id = e.modelo_id
                WHERE e.id = :id
                LIMIT 1
            ");
            $stmtEquipo->execute([':id' => $equipoId]);
            $equipo = $stmtEquipo->fetch(PDO::FETCH_ASSOC);

            if (!$equipo) {
                throw new RuntimeException('El equipo seleccionado no existe en el sistema.');
            }

            $esMonocromatico = (strtoupper((string)($equipo['tipo_modelo'] ?? '')) === 'MONO' || strtoupper((string)($equipo['tipo_modelo'] ?? '')) === 'MONOCROMATICO');

            // 2. Consultar la última lectura registrada para este equipo
            $stmtUltimo = $this->db->prepare("
                SELECT contador_actual, contador_actual_color 
                FROM registros 
                WHERE equipo_id = :id 
                ORDER BY fecha DESC, id DESC 
                LIMIT 1
            ");
            $stmtUltimo->execute([':id' => $equipoId]);
            $ultimo = $stmtUltimo->fetch(PDO::FETCH_ASSOC);

            if ($ultimo) {
                $anteriorMono = (int)($ultimo['contador_actual'] ?? 0);
                $anteriorColor = (int)($ultimo['contador_actual_color'] ?? 0);

                // Validación Mono: El nuevo no puede ser menor al anterior
                if ($monoActual < $anteriorMono) {
                    throw new RuntimeException("Error: El contador Mono actual ({$monoActual}) no puede ser inferior al anterior registrado ({$anteriorMono}).");
                }

                // Validación Color: Solo si la máquina NO es monocromática
                if (!$esMonocromatico) {
                    if ($colorActual < $anteriorColor) {
                        throw new RuntimeException("Error: El equipo es Color. El contador Color actual ({$colorActual}) no puede ser inferior al anterior registrado ({$anteriorColor}).");
                    }
                } else {
                    // Si es monocromática, forzamos de forma defensiva el contador color a 0
                    $colorActual = 0;
                }
            }

            return [
                'valido'          => true,
                'es_monocromatico'=> $esMonocromatico,
                'color_ajustado'  => $colorActual,
                'mensaje'         => 'Lectura validada correctamente.'
            ];

        } catch (Throwable $e) {
            return [
                'valido'          => false,
                'es_monocromatico'=> false,
                'color_ajustado'  => 0,
                'mensaje'         => $e->getMessage()
            ];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | 2) AUDITORÍA DE LECTURAS PENDIENTES DEL MES
    |--------------------------------------------------------------------------
    */
    /**
     * Escanea y detecta qué clientes con fotocopiadoras activas no han cargado aún su contador del período.
     */
    public function auditarLecturasPendientesMes(int $mes, int $anio): array
    {
        try {
            $sql = "
                SELECT 
                    e.id AS equipo_id,
                    e.serie,
                    c.id AS cliente_id,
                    c.nombre AS cliente_nombre,
                    c.telefono AS cliente_telefono,
                    m.nombre_modelo AS modelo
                FROM equipos e
                INNER JOIN clientes c ON c.id = e.cliente_id
                LEFT JOIN modelos_equipos m ON m.id = e.modelo_id
                WHERE e.activo = 1 
                  AND e.propiedad = 'CSDI'
                  AND NOT EXISTS (
                      SELECT 1 
                      FROM registros r 
                      WHERE r.equipo_id = e.id 
                        AND r.periodo_mes = :mes 
                        AND r.periodo_anio = :anio
                  )
                ORDER BY c.nombre ASC
            ";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':mes'  => $mes,
                ':anio' => $anio
            ]);

            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable) {
            return [];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | 3) AUTOMATIZACIÓN DE RECORDATORIOS POR WHATSAPP (Sincronizado)
    |--------------------------------------------------------------------------
    */
    /**
     * Escanea las lecturas pendientes del mes actual y envía de forma automática
     * una plantilla de solicitud de odómetro por WhatsApp a cada cliente moroso.
     */
    public function despacharRecordatoriosPendientes(): array
    {
        $mes = (int)date('m');
        $anio = (int)date('Y');

        // 1. Obtenemos el listado real de clientes y máquinas sin lectura
        $pendientes = $this->auditarLecturasPendientesMes($mes, $anio);
        
        $enviados = 0;
        $fallidos = 0;

        foreach ($pendientes as $p) {
            $telefono = trim((string)($p['cliente_telefono'] ?? ''));
            $clienteNombre = (string)($p['cliente_nombre'] ?? 'Cliente');
            $modelo = (string)($p['modelo'] ?? 'Fotocopiadora');
            $serie = (string)($p['serie'] ?? '');

            if ($telefono === '') {
                $fallidos++;
                continue; // Si el cliente no tiene teléfono de contacto registrado, lo salta de forma defensiva
            }

            // 2. Formateamos la plantilla institucional de CSDI PRO
            $mensaje = "Hola, *{$clienteNombre}*. 📝 Desde administracion de *CSDI* le recordamos que aún no disponemos de la lectura mensual de su equipo *{$modelo}* (Serie: *{$serie}*). \n\nPor favor, cargue sus contadores ingresando aquí a su Portal de Cliente: " . base_url('/portal') . " para evitar cargos estimados en su abono. ¡Muchas gracias!";

            try {
                // 3. Despachamos el mensaje consumiendo tu NotificationService global de tu FTP
                $enviado = $this->notificationService->sendWhatsApp($telefono, $mensaje);
                
                if ($enviado) {
                    $enviados++;
                } else {
                    $fallidos++;
                }
            } catch (Throwable) {
                $fallidos++;
            }
        }

        return [
            'success'    => true,
            'procesados' => count($pendientes),
            'enviados'   => $enviados,
            'fallidos'   => $fallidos
        ];
    }
}