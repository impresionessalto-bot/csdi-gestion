<?php
declare(strict_types=1);

namespace App\Providers;


use App\Core\ServiceProvider;
use App\Services\Export\PdfService;


final class AppServiceProvider extends ServiceProvider
{


    public function register():void
    {


        $this->container->singleton(
            PdfService::class,
            PdfService::class
        );


    }


}