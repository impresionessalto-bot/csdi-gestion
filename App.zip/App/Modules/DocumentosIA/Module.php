<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA;

use App\Core\Module as CoreModule;

final class Module extends CoreModule
{
    public function name(): string
    {
        return 'DocumentosIA';
    }

    public function description(): string
    {
        return 'Clasificación, OCR, extracción y validación inteligente de documentos.';
    }

    public function version(): string
    {
        return '1.1.0';
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function priority(): int
    {
        return 90;
    }

    public function menu(): array
    {
        return [
            [
                'title' => 'Documentos IA',
                'icon' => 'fa-solid fa-file-invoice',
                'url' => '/documentos-ia',
                'group' => 'Herramientas',
                'order' => 90,
                'permission' => 'documentos_ia.ver',
                'visible' => true,
                'children' => []
            ]
        ];
    }

    public function icon(): string
    {
        return 'fa-solid fa-file-invoice';
    }

    public function url(): string
    {
        return '/documentos-ia';
    }

    public function group(): string
    {
        return 'Herramientas';
    }

    public function order(): int
    {
        return 90;
    }

    public function permissions(): array
    {
        return [
            'documentos_ia.ver',
            'documentos_ia.procesar',
            'documentos_ia.reprocesar',
            'documentos_ia.eliminar',
        ];
    }

    public function dependencies(): array
    {
        return [];
    }

    public function widgets(): array
    {
        return [];
    }

    public function kpis(): array
    {
        return [];
    }

    public function enabled(): bool
    {
        return true;
    }

    public function boot(): void
    {
        // Reservado para futuras integraciones.
    }
}