<?php

declare(strict_types=1);

$error = $error ?? null;
$success = $success ?? null;
$resultado = $resultado ?? null;

$csrfToken = '';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = (string) $_SESSION['_csrf'];

$nombreArchivo = '';

if (
    is_array($resultado)
    && isset($resultado['nombre_archivo'])
) {
    $nombreArchivo = (string) $resultado['nombre_archivo'];
}

if (
    is_array($resultado)
    && isset($resultado['archivo']['nombre'])
) {
    $nombreArchivo = (string) $resultado['archivo']['nombre'];
}
?>

<div class="container-fluid py-4 documentos-ia-page">

    <!-- =========================================================
         HEADER
    ========================================================== -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 mb-1">
                <i class="bi bi-cloud-arrow-up me-2"></i>
                Cargar documento
            </h1>

            <div class="text-muted">
                Recepción y clasificación automática de documentos
            </div>
        </div>

        <div class="mt-2 mt-md-0">

            <a
                href="/documentos-ia"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Volver
            </a>

        </div>

    </div>


    <!-- =========================================================
         MENSAJES
    ========================================================== -->

    <?php if ($error): ?>

        <div
            class="alert alert-danger alert-dismissible fade show"
            role="alert"
        >

            <i class="bi bi-exclamation-triangle-fill me-2"></i>

            <?= htmlspecialchars(
                (string) $error,
                ENT_QUOTES,
                'UTF-8'
            ) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
                aria-label="Cerrar"
            ></button>

        </div>

    <?php endif; ?>


    <?php if ($success): ?>

        <div
            class="alert alert-success alert-dismissible fade show"
            role="alert"
        >

            <i class="bi bi-check-circle-fill me-2"></i>

            <?= htmlspecialchars(
                (string) $success,
                ENT_QUOTES,
                'UTF-8'
            ) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
                aria-label="Cerrar"
            ></button>

        </div>

    <?php endif; ?>


    <!-- =========================================================
         FORMULARIO
    ========================================================== -->

    <form
        id="documentoIAForm"
        action="/documentos-ia/subir"
        method="POST"
        enctype="multipart/form-data"
        autocomplete="off"
    >

        <!-- CSRF -->

        <input
            type="hidden"
            name="_csrf"
            value="<?= htmlspecialchars(
                $csrfToken,
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >


        <div class="row g-4">

            <!-- =================================================
                 COLUMNA PRINCIPAL
            ================================================== -->

            <div class="col-lg-8">

                <div class="card shadow-sm">

                    <div class="card-header">

                        <strong>
                            <i class="bi bi-file-earmark-arrow-up me-2"></i>
                            Archivo
                        </strong>

                    </div>


                    <div class="card-body">

                        <!-- =====================================
                             DROPZONE
                        ====================================== -->

                        <div
                            id="documentoDropzone"
                            class="documentos-ia-dropzone"
                            tabindex="0"
                            role="button"
                            aria-label="Seleccionar archivo"
                        >

                            <div class="documentos-ia-dropzone-icon">

                                <i class="bi bi-cloud-arrow-up"></i>

                            </div>


                            <h4 class="mb-2">
                                Arrastrá el documento aquí
                            </h4>


                            <p class="text-muted mb-3">

                                o seleccioná un archivo desde tu computadora

                            </p>


                            <!--
                                IMPORTANTE:

                                No usamos display:none.

                                Se utiliza una técnica de ocultación
                                visual para que el input siga siendo
                                accesible.
                            -->

                            <input
                                type="file"
                                id="archivo"
                                name="archivo"
                                class="documentos-ia-file-input"
                                accept=".pdf,.jpg,.jpeg,.png,.webp,.tif,.tiff"
                            >


                            <label
                                for="archivo"
                                id="btnSeleccionarArchivo"
                                class="btn btn-primary documentos-ia-select-button"
                            >

                                <i class="bi bi-folder2-open me-2"></i>

                                Seleccionar archivo

                            </label>


                            <div
                                id="archivoSeleccionado"
                                class="documentos-ia-file-name mt-3"
                            >

                                <span class="text-muted">
                                    Ningún archivo seleccionado
                                </span>

                            </div>


                            <div class="small text-muted mt-3">

                                PDF, JPG, JPEG, PNG, WEBP, TIFF

                            </div>

                        </div>


                        <!-- =====================================
                             PROGRESO
                        ====================================== -->

                        <div
                            id="documentoUploadProgress"
                            class="documentos-ia-progress mt-4"
                            style="display:none;"
                        >

                            <div class="d-flex justify-content-between mb-1">

                                <span>
                                    Subiendo documento...
                                </span>

                                <span id="documentoUploadPercent">
                                    0%
                                </span>

                            </div>

                            <div class="progress">

                                <div
                                    id="documentoUploadProgressBar"
                                    class="progress-bar progress-bar-striped progress-bar-animated"
                                    role="progressbar"
                                    style="width:0%;"
                                ></div>

                            </div>

                        </div>


                        <!-- =====================================
                             ESTADO
                        ====================================== -->

                        <div
                            id="documentoUploadStatus"
                            class="mt-3"
                            style="display:none;"
                        ></div>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 COLUMNA INFORMACIÓN
            ================================================== -->

            <div class="col-lg-4">

                <div class="card shadow-sm mb-4">

                    <div class="card-header">

                        <strong>
                            <i class="bi bi-info-circle me-2"></i>
                            Clasificación
                        </strong>

                    </div>


                    <div class="card-body">

                        <p class="text-muted small mb-3">

                            El sistema intentará identificar automáticamente
                            el tipo de documento mediante OCR y reglas de
                            clasificación.

                        </p>


                        <div class="mb-3">

                            <label
                                for="tipo_documento"
                                class="form-label"
                            >
                                Tipo de documento
                            </label>

                            <select
                                name="tipo_documento"
                                id="tipo_documento"
                                class="form-select"
                            >

                                <option value="OTRO">
                                    Automático
                                </option>

                                <option value="FACTURA">
                                    Factura
                                </option>

                                <option value="REMITO">
                                    Remito
                                </option>

                                <option value="ORDEN_COMPRA">
                                    Orden de compra
                                </option>

                                <option value="PRESUPUESTO">
                                    Presupuesto
                                </option>

                                <option value="INFORME_TECNICO">
                                    Informe técnico
                                </option>

                                <option value="RECIBO">
                                    Recibo
                                </option>

                                <option value="TICKET">
                                    Ticket
                                </option>

                            </select>

                        </div>


                        <div class="mb-3">

                            <label
                                for="origen"
                                class="form-label"
                            >
                                Origen
                            </label>

                            <select
                                name="origen"
                                id="origen"
                                class="form-select"
                            >

                                <option value="MANUAL">
                                    Manual
                                </option>

                                <option value="EMAIL">
                                    Email
                                </option>

                                <option value="WHATSAPP">
                                    WhatsApp
                                </option>

                                <option value="SISTEMA">
                                    Sistema
                                </option>

                            </select>

                        </div>


                        <div class="mb-3">

                            <label
                                for="observacion"
                                class="form-label"
                            >
                                Observación
                            </label>

                            <textarea
                                name="observacion"
                                id="observacion"
                                class="form-control"
                                rows="4"
                                placeholder="Información adicional..."
                            ></textarea>

                        </div>

                    </div>

                </div>


                <!-- =============================================
                     ACCIONES
                ============================================== -->

                <div class="card shadow-sm">

                    <div class="card-body">

                        <button
                            type="submit"
                            id="btnSubirDocumento"
                            class="btn btn-success w-100"
                        >

                            <i class="bi bi-cloud-upload me-2"></i>

                            Cargar documento

                        </button>


                        <a
                            href="/documentos-ia"
                            class="btn btn-outline-secondary w-100 mt-2"
                        >

                            Cancelar

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </form>


    <!-- =========================================================
         RESULTADO
    ========================================================== -->

    <?php if (is_array($resultado) && !empty($resultado)): ?>

        <div class="card shadow-sm mt-4">

            <div class="card-header">

                <strong>
                    <i class="bi bi-check2-circle me-2"></i>
                    Documento cargado
                </strong>

            </div>

            <div class="card-body">

                <div class="row">

                    <div class="col-md-6">

                        <strong>
                            Archivo:
                        </strong>

                        <?= htmlspecialchars(
                            $nombreArchivo !== ''
                                ? $nombreArchivo
                                : 'Documento',
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    </div>


                    <?php if (isset($resultado['id'])): ?>

                        <div class="col-md-6">

                            <a
                                href="/documentos-ia/ver/<?= (int) $resultado['id'] ?>"
                                class="btn btn-primary btn-sm"
                            >

                                <i class="bi bi-eye me-1"></i>

                                Ver documento

                            </a>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    <?php endif; ?>

</div>


<!-- =========================================================
     JAVASCRIPT
========================================================== -->

<script
    src="/assets/js/documentos-ia.js?v=20260830"
    defer
></script>