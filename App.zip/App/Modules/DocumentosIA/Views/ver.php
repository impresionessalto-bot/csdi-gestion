<?php

/*
|--------------------------------------------------------------------------
| DOCUMENTOS IA
|--------------------------------------------------------------------------
| Visualización y análisis
|--------------------------------------------------------------------------
*/

$documento = is_array($documento ?? null)
    ? $documento
    : [];

$error = trim((string) ($error ?? ''));
$mensaje = trim((string) ($mensaje ?? ''));

function documentosIaVerEsc(mixed $valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES,
        'UTF-8'
    );
}

$id = (int) (
    $documento['id']
    ?? 0
);

$nombre = (string) (
    $documento['nombre_archivo']
    ?? 'Documento'
);

$path = trim(
    (string) (
        $documento['archivo_path']
        ?? ''
    )
);

$mime = strtolower(
    trim(
        (string) (
            $documento['mime_type']
            ?? ''
        )
    )
);

$extension = strtolower(
    trim(
        (string) (
            $documento['extension']
            ?? ''
        )
    )
);

$tipo = strtoupper(
    trim(
        (string) (
            $documento['tipo_documento']
            ?? 'OTRO'
        )
    )
);

$subtipo = trim(
    (string) (
        $documento['subtipo_documento']
        ?? ''
    )
);

$origen = strtoupper(
    trim(
        (string) (
            $documento['origen']
            ?? 'MANUAL'
        )
    )
);

$estado = strtoupper(
    trim(
        (string) (
            $documento['estado']
            ?? 'PENDIENTE'
        )
    )
);

$confianza = $documento['confianza']
    ?? null;

$textoExtraido = (string) (
    $documento['texto_extraido']
    ?? ''
);

$datosJson = $documento['datos_json']
    ?? null;

$errorMensaje = trim(
    (string) (
        $documento['error_mensaje']
        ?? ''
    )
);

$proveedorIa = trim(
    (string) (
        $documento['proveedor_ia']
        ?? ''
    )
);

$modeloIa = trim(
    (string) (
        $documento['modelo_ia']
        ?? ''
    )
);

$fechaCreacion = (string) (
    $documento['creado_en']
    ?? ''
);

$fechaProcesado = (string) (
    $documento['procesado_en']
    ?? ''
);


/*
|--------------------------------------------------------------------------
| URL DEL ARCHIVO
|--------------------------------------------------------------------------
*/

$archivoUrl = '';

if ($path !== '') {

    if (
        str_starts_with(
            $path,
            'http://'
        )
        ||
        str_starts_with(
            $path,
            'https://'
        )
    ) {

        $archivoUrl = $path;

    } elseif (
        str_starts_with(
            $path,
            '/'
        )
    ) {

        $archivoUrl = $path;

    } else {

        $archivoUrl =
            '/'
            . ltrim(
                $path,
                '/'
            );

    }
}


/*
|--------------------------------------------------------------------------
| DATOS JSON
|--------------------------------------------------------------------------
*/

$datos = [];

if (is_array($datosJson)) {

    $datos = $datosJson;

} elseif (
    is_string($datosJson)
    &&
    trim($datosJson) !== ''
) {

    $decoded = json_decode(
        $datosJson,
        true
    );

    if (is_array($decoded)) {
        $datos = $decoded;
    }

}


/*
|--------------------------------------------------------------------------
| DETECCIÓN DE PREVIEW
|--------------------------------------------------------------------------
*/

$esPdf =
    $mime === 'application/pdf'
    ||
    $extension === 'pdf';

$esImagen =
    str_starts_with(
        $mime,
        'image/'
    )
    ||
    in_array(
        $extension,
        [
            'jpg',
            'jpeg',
            'png',
            'webp',
            'gif'
        ],
        true
    );


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (
    session_status() !== PHP_SESSION_ACTIVE
) {
    @session_start();
}

$csrfToken = (string) (
    $_SESSION['_csrf']
    ?? ''
);

?>

<link
    rel="stylesheet"
    href="/assets/css/documentos-ia.css"
>


<div class="container-fluid documentos-ia-page">


    <!-- =====================================================
         CABECERA
    ====================================================== -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 mb-1">

                <i class="bi bi-file-earmark-text"></i>

                <?= documentosIaVerEsc($nombre) ?>

            </h1>

            <div class="text-muted">

                Documento #<?= $id ?>

            </div>

        </div>


        <div class="d-flex gap-2 mt-3 mt-md-0">

            <a
                href="/documentos-ia"
                class="btn btn-outline-secondary"
            >

                <i class="bi bi-arrow-left"></i>

                Volver

            </a>


            <?php if ($archivoUrl !== ''): ?>

                <a
                    href="<?= documentosIaVerEsc($archivoUrl) ?>"
                    target="_blank"
                    class="btn btn-outline-primary"
                >

                    <i class="bi bi-box-arrow-up-right"></i>

                    Abrir archivo

                </a>

            <?php endif; ?>

        </div>

    </div>


    <!-- =====================================================
         MENSAJES
    ====================================================== -->

    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">

            <?= documentosIaVerEsc($error) ?>

        </div>

    <?php endif; ?>


    <?php if ($mensaje !== ''): ?>

        <div class="alert alert-success">

            <?= documentosIaVerEsc($mensaje) ?>

        </div>

    <?php endif; ?>


    <div class="row g-4">


        <!-- =================================================
             VISOR
        ================================================== -->

        <div class="col-xl-8">

            <div class="card shadow-sm h-100">

                <div class="card-header d-flex justify-content-between">

                    <strong>

                        <i class="bi bi-eye"></i>

                        Documento original

                    </strong>

                    <span class="badge bg-secondary">

                        <?= documentosIaVerEsc(
                            strtoupper(
                                $extension !== ''
                                    ? $extension
                                    : 'archivo'
                            )
                        ) ?>

                    </span>

                </div>


                <div class="card-body p-2 documentos-ia-viewer">


                    <?php if ($archivoUrl === ''): ?>

                        <div class="documentos-ia-preview-empty">

                            <i class="bi bi-file-earmark-x"></i>

                            <h5>
                                Archivo no disponible
                            </h5>

                            <p class="text-muted">
                                El registro existe pero no contiene una ruta de archivo válida.
                            </p>

                        </div>


                    <?php elseif ($esPdf): ?>

                        <iframe
                            src="<?= documentosIaVerEsc($archivoUrl) ?>"
                            class="documentos-ia-pdf-viewer"
                            title="Documento PDF"
                        ></iframe>


                    <?php elseif ($esImagen): ?>

                        <div class="documentos-ia-image-viewer">

                            <img
                                src="<?= documentosIaVerEsc($archivoUrl) ?>"
                                alt="<?= documentosIaVerEsc($nombre) ?>"
                                class="img-fluid"
                            >

                        </div>


                    <?php else: ?>

                        <div class="documentos-ia-preview-empty">

                            <i class="bi bi-file-earmark"></i>

                            <h5>
                                Vista previa no disponible
                            </h5>

                            <p class="text-muted">

                                Este tipo de archivo no puede visualizarse directamente.

                            </p>


                            <a
                                href="<?= documentosIaVerEsc($archivoUrl) ?>"
                                target="_blank"
                                class="btn btn-primary"
                            >

                                Abrir archivo

                            </a>

                        </div>

                    <?php endif; ?>


                </div>

            </div>

        </div>


        <!-- =================================================
             INFORMACIÓN
        ================================================== -->

        <div class="col-xl-4">


            <div class="card shadow-sm mb-4">

                <div class="card-header">

                    <strong>

                        <i class="bi bi-tags"></i>

                        Clasificación

                    </strong>

                </div>


                <div class="card-body">


                    <div class="documentos-ia-classification-main">

                        <div class="small text-muted">
                            Tipo detectado
                        </div>

                        <div class="documentos-ia-classification-title">

                            <?= documentosIaVerEsc($tipo) ?>

                        </div>


                        <?php if ($subtipo !== ''): ?>

                            <div class="mt-2">

                                <span class="badge bg-light text-dark border">

                                    <?= documentosIaVerEsc(
                                        $subtipo
                                    ) ?>

                                </span>

                            </div>

                        <?php endif; ?>

                    </div>


                    <hr>


                    <div class="row g-3">


                        <div class="col-6">

                            <div class="small text-muted">
                                Estado
                            </div>

                            <strong>

                                <?= documentosIaVerEsc(
                                    $estado
                                ) ?>

                            </strong>

                        </div>


                        <div class="col-6">

                            <div class="small text-muted">
                                Confianza
                            </div>

                            <strong>

                                <?php if (
                                    $confianza !== null
                                    &&
                                    $confianza !== ''
                                ): ?>

                                    <?= documentosIaVerEsc(
                                        $confianza
                                    ) ?>%

                                <?php else: ?>

                                    —

                                <?php endif; ?>

                            </strong>

                        </div>


                        <div class="col-6">

                            <div class="small text-muted">
                                Origen
                            </div>

                            <strong>

                                <?= documentosIaVerEsc(
                                    $origen
                                ) ?>

                            </strong>

                        </div>


                        <div class="col-6">

                            <div class="small text-muted">
                                ID
                            </div>

                            <strong>
                                #<?= $id ?>
                            </strong>

                        </div>

                    </div>


                    <?php if (
                        $estado !== 'PROCESADO'
                    ): ?>

                        <hr>

                        <button
                            type="button"
                            id="btnProcesarDocumento"
                            class="btn btn-primary w-100"
                            data-url="/documentos-ia/procesar/<?= $id ?>"
                            data-csrf="<?= documentosIaVerEsc($csrfToken) ?>"
                        >

                            <i class="bi bi-cpu"></i>

                            Analizar documento

                        </button>

                    <?php endif; ?>


                </div>

            </div>


            <!-- =================================================
                 DISTRIBUCIÓN
            ================================================== -->

            <div class="card shadow-sm mb-4">

                <div class="card-header">

                    <strong>

                        <i class="bi bi-diagram-3"></i>

                        Distribución

                    </strong>

                </div>


                <div class="card-body">


                    <?php if (!empty($datos)): ?>

                        <?php foreach ($datos as $clave => $valor): ?>

                            <?php if (
                                is_scalar($valor)
                                &&
                                trim((string) $valor) !== ''
                            ): ?>

                                <div class="documentos-ia-data-row">

                                    <span class="text-muted">

                                        <?= documentosIaVerEsc(
                                            ucwords(
                                                str_replace(
                                                    [
                                                        '_',
                                                        '-'
                                                    ],
                                                    ' ',
                                                    (string) $clave
                                                )
                                            )
                                        ) ?>

                                    </span>

                                    <strong>

                                        <?= documentosIaVerEsc(
                                            $valor
                                        ) ?>

                                    </strong>

                                </div>

                            <?php endif; ?>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <div class="text-muted small">

                            Todavía no hay datos estructurados.

                            <br>

                            El siguiente paso será identificar automáticamente proveedor, cliente, CUIT, importe, fecha y demás información.

                        </div>

                    <?php endif; ?>

                </div>

            </div>


            <!-- =================================================
                 MOTOR
            ================================================== -->

            <div class="card shadow-sm">

                <div class="card-header">

                    <strong>

                        <i class="bi bi-cpu"></i>

                        Procesamiento

                    </strong>

                </div>


                <div class="card-body">


                    <div class="documentos-ia-data-row">

                        <span class="text-muted">
                            Proveedor IA
                        </span>

                        <strong>

                            <?= documentosIaVerEsc(
                                $proveedorIa !== ''
                                    ? $proveedorIa
                                    : 'OCR / Classifier'
                            ) ?>

                        </strong>

                    </div>


                    <div class="documentos-ia-data-row">

                        <span class="text-muted">
                            Modelo
                        </span>

                        <strong>

                            <?= documentosIaVerEsc(
                                $modeloIa !== ''
                                    ? $modeloIa
                                    : 'Local'
                            ) ?>

                        </strong>

                    </div>


                    <?php if ($fechaCreacion !== ''): ?>

                        <div class="documentos-ia-data-row">

                            <span class="text-muted">
                                Creado
                            </span>

                            <strong>

                                <?= documentosIaVerEsc(
                                    $fechaCreacion
                                ) ?>

                            </strong>

                        </div>

                    <?php endif; ?>


                    <?php if ($fechaProcesado !== ''): ?>

                        <div class="documentos-ia-data-row">

                            <span class="text-muted">
                                Procesado
                            </span>

                            <strong>

                                <?= documentosIaVerEsc(
                                    $fechaProcesado
                                ) ?>

                            </strong>

                        </div>

                    <?php endif; ?>


                    <?php if ($errorMensaje !== ''): ?>

                        <div class="alert alert-danger mt-3 mb-0">

                            <strong>
                                Error de procesamiento
                            </strong>

                            <div class="small mt-1">

                                <?= documentosIaVerEsc(
                                    $errorMensaje
                                ) ?>

                            </div>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         TEXTO OCR
    ====================================================== -->

    <div class="card shadow-sm mt-4">

        <div class="card-header d-flex justify-content-between">

            <strong>

                <i class="bi bi-file-text"></i>

                Texto extraído por OCR

            </strong>

            <?php if ($textoExtraido !== ''): ?>

                <span class="badge bg-success">
                    OCR disponible
                </span>

            <?php endif; ?>

        </div>


        <div class="card-body">

            <?php if ($textoExtraido !== ''): ?>

                <pre class="documentos-ia-ocr-text"><?= documentosIaVerEsc($textoExtraido) ?></pre>

            <?php else: ?>

                <div class="documentos-ia-preview-empty py-4">

                    <i class="bi bi-file-text"></i>

                    <div class="text-muted">

                        Todavía no hay texto extraído.

                    </div>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<script src="/assets/js/documentos-ia.js"></script>