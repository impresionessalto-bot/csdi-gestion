<?php

/*
|--------------------------------------------------------------------------
| DOCUMENTOS IA
|--------------------------------------------------------------------------
| Dashboard
|--------------------------------------------------------------------------
*/

$resumen = is_array($resumen ?? null)
    ? $resumen
    : [];

$documentos = is_array($documentos ?? null)
    ? $documentos
    : [];

$procesos = is_array($procesos ?? null)
    ? $procesos
    : [];

$error = trim((string) ($error ?? ''));

function documentosIaEsc(mixed $valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES,
        'UTF-8'
    );
}

function documentosIaEstadoClass(string $estado): string
{
    return match (strtoupper(trim($estado))) {
        'PROCESADO' => 'success',
        'PROCESANDO' => 'warning',
        'ERROR' => 'danger',
        default => 'secondary',
    };
}

function documentosIaTipoLabel(string $tipo): string
{
    return match (strtoupper(trim($tipo))) {
        'FACTURA' => 'Factura',
        'FACTURA_A' => 'Factura A',
        'FACTURA_B' => 'Factura B',
        'FACTURA_C' => 'Factura C',
        'REMITO' => 'Remito',
        'ORDEN_COMPRA' => 'Orden de compra',
        'PRESUPUESTO' => 'Presupuesto',
        'INFORME_TECNICO' => 'Informe técnico',
        'RECIBO' => 'Recibo',
        'TICKET' => 'Ticket',
        default => 'Otro',
    };
}

$csrfToken = '';

if (
    session_status() !== PHP_SESSION_ACTIVE
) {
    @session_start();
}

if (
    isset($_SESSION['_csrf'])
) {
    $csrfToken = (string) $_SESSION['_csrf'];
}
?>

<link
    rel="stylesheet"
    href="/assets/css/documentos-ia.css"
>

<div class="container-fluid documentos-ia-page">

    <!-- =====================================================
         CABECERA
    ====================================================== -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 mb-1">
                <i class="bi bi-file-earmark-text"></i>
                Documentos IA
            </h1>

            <div class="text-muted">
                Recepción, identificación, clasificación y distribución automática de documentos.
            </div>
        </div>

        <div class="mt-3 mt-md-0">

            <a
                href="/documentos-ia/subir"
                class="btn btn-primary"
            >
                <i class="bi bi-cloud-arrow-up"></i>
                Cargar documento
            </a>

        </div>

    </div>


    <!-- =====================================================
         ERROR
    ====================================================== -->

    <?php if ($error !== ''): ?>

        <div class="alert alert-danger shadow-sm">
            <i class="bi bi-exclamation-triangle"></i>

            <?= documentosIaEsc($error) ?>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         RESUMEN
    ====================================================== -->

    <div class="row g-3 mb-4">

        <div class="col-6 col-xl-3">

            <div class="card documentos-ia-stat-card h-100">

                <div class="card-body">

                    <div class="documentos-ia-stat-icon">
                        <i class="bi bi-files"></i>
                    </div>

                    <div class="text-muted small">
                        Total documentos
                    </div>

                    <div class="documentos-ia-stat-number">
                        <?= documentosIaEsc(
                            $resumen['total']
                            ?? $resumen['total_documentos']
                            ?? count($documentos)
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl-3">

            <div class="card documentos-ia-stat-card h-100">

                <div class="card-body">

                    <div class="documentos-ia-stat-icon text-warning">
                        <i class="bi bi-hourglass-split"></i>
                    </div>

                    <div class="text-muted small">
                        Pendientes
                    </div>

                    <div class="documentos-ia-stat-number">

                        <?= documentosIaEsc(
                            $resumen['pendientes']
                            ?? $resumen['pendiente']
                            ?? 0
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl-3">

            <div class="card documentos-ia-stat-card h-100">

                <div class="card-body">

                    <div class="documentos-ia-stat-icon text-success">
                        <i class="bi bi-check-circle"></i>
                    </div>

                    <div class="text-muted small">
                        Procesados
                    </div>

                    <div class="documentos-ia-stat-number">

                        <?= documentosIaEsc(
                            $resumen['procesados']
                            ?? $resumen['procesado']
                            ?? 0
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl-3">

            <div class="card documentos-ia-stat-card h-100">

                <div class="card-body">

                    <div class="documentos-ia-stat-icon text-danger">
                        <i class="bi bi-exclamation-circle"></i>
                    </div>

                    <div class="text-muted small">
                        Con errores
                    </div>

                    <div class="documentos-ia-stat-number">

                        <?= documentosIaEsc(
                            $resumen['errores']
                            ?? $resumen['error']
                            ?? 0
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         ACCIONES
    ====================================================== -->

    <div class="card shadow-sm mb-4">

        <div class="card-header d-flex justify-content-between align-items-center">

            <strong>
                <i class="bi bi-robot"></i>
                Procesamiento inteligente
            </strong>

            <button
                type="button"
                id="btnProcesarPendientes"
                class="btn btn-sm btn-outline-primary"
                data-url="/documentos-ia/procesar-pendientes"
                data-csrf="<?= documentosIaEsc($csrfToken) ?>"
            >
                <i class="bi bi-cpu"></i>
                Procesar pendientes
            </button>

        </div>

        <div class="card-body">

            <div class="row g-3">

                <div class="col-md-4">

                    <div class="documentos-ia-flow-step">

                        <span class="documentos-ia-flow-number">
                            1
                        </span>

                        <div>
                            <strong>Recepción</strong>
                            <div class="text-muted small">
                                Se carga el PDF o imagen.
                            </div>
                        </div>

                    </div>

                </div>


                <div class="col-md-4">

                    <div class="documentos-ia-flow-step">

                        <span class="documentos-ia-flow-number">
                            2
                        </span>

                        <div>
                            <strong>OCR + clasificación</strong>
                            <div class="text-muted small">
                                Se extrae texto y se identifica el documento.
                            </div>
                        </div>

                    </div>

                </div>


                <div class="col-md-4">

                    <div class="documentos-ia-flow-step">

                        <span class="documentos-ia-flow-number">
                            3
                        </span>

                        <div>
                            <strong>Distribución</strong>
                            <div class="text-muted small">
                                Se determina proveedor, cliente y destino.
                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         DOCUMENTOS
    ====================================================== -->

    <div class="card shadow-sm">

        <div class="card-header">

            <div class="d-flex justify-content-between align-items-center">

                <strong>
                    <i class="bi bi-folder2-open"></i>
                    Documentos recibidos
                </strong>

                <span class="badge bg-secondary">
                    <?= count($documentos) ?>
                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (empty($documentos)): ?>

                <div class="documentos-ia-empty">

                    <i class="bi bi-inbox"></i>

                    <h5>
                        No hay documentos
                    </h5>

                    <p class="text-muted">
                        Todavía no se cargaron documentos.
                    </p>

                    <a
                        href="/documentos-ia/subir"
                        class="btn btn-primary"
                    >
                        Cargar primer documento
                    </a>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead>

                            <tr>

                                <th>
                                    Documento
                                </th>

                                <th>
                                    Tipo
                                </th>

                                <th>
                                    Origen
                                </th>

                                <th>
                                    Estado
                                </th>

                                <th>
                                    Confianza
                                </th>

                                <th>
                                    Fecha
                                </th>

                                <th class="text-end">
                                    Acciones
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php foreach ($documentos as $documento): ?>

                            <?php

                            $id = (int) (
                                $documento['id']
                                ?? 0
                            );

                            $nombre = (string) (
                                $documento['nombre_archivo']
                                ?? $documento['nombre']
                                ?? 'Documento'
                            );

                            $tipo = strtoupper(
                                (string) (
                                    $documento['tipo_documento']
                                    ?? 'OTRO'
                                )
                            );

                            $origen = strtoupper(
                                (string) (
                                    $documento['origen']
                                    ?? 'MANUAL'
                                )
                            );

                            $estado = strtoupper(
                                (string) (
                                    $documento['estado']
                                    ?? 'PENDIENTE'
                                )
                            );

                            $confianza = $documento['confianza']
                                ?? null;

                            $fecha = $documento['creado_en']
                                ?? $documento['fecha']
                                ?? '';

                            ?>

                            <tr>

                                <td>

                                    <div class="d-flex align-items-center gap-2">

                                        <div class="documentos-ia-file-icon">

                                            <i class="bi bi-file-earmark-text"></i>

                                        </div>

                                        <div>

                                            <div class="fw-semibold">

                                                <?= documentosIaEsc(
                                                    $nombre
                                                ) ?>

                                            </div>

                                            <?php if (!empty($documento['extension'])): ?>

                                                <div class="text-muted small">

                                                    <?= documentosIaEsc(
                                                        strtoupper(
                                                            (string) $documento['extension']
                                                        )
                                                    ) ?>

                                                </div>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </td>


                                <td>

                                    <span class="badge bg-light text-dark border">

                                        <?= documentosIaEsc(
                                            documentosIaTipoLabel($tipo)
                                        ) ?>

                                    </span>

                                    <?php if (!empty($documento['subtipo_documento'])): ?>

                                        <div class="small text-muted mt-1">

                                            <?= documentosIaEsc(
                                                $documento['subtipo_documento']
                                            ) ?>

                                        </div>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <span class="text-muted">

                                        <?= documentosIaEsc(
                                            $origen
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <span
                                        class="badge bg-<?= documentosIaEsc(
                                            documentosIaEstadoClass($estado)
                                        ) ?>"
                                    >
                                        <?= documentosIaEsc($estado) ?>
                                    </span>

                                </td>


                                <td>

                                    <?php if ($confianza !== null && $confianza !== ''): ?>

                                        <div class="documentos-ia-confidence">

                                            <span>
                                                <?= documentosIaEsc(
                                                    $confianza
                                                ) ?>%
                                            </span>

                                        </div>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            —
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <span class="text-muted small">

                                        <?= documentosIaEsc(
                                            $fecha
                                        ) ?>

                                    </span>

                                </td>


                                <td class="text-end">

                                    <div class="btn-group">

                                        <a
                                            href="/documentos-ia/ver/<?= $id ?>"
                                            class="btn btn-sm btn-outline-secondary"
                                            title="Ver documento"
                                        >
                                            <i class="bi bi-eye"></i>
                                        </a>


                                        <?php if ($estado !== 'PROCESADO'): ?>

                                            <button
                                                type="button"
                                                class="btn btn-sm btn-outline-primary btn-procesar-documento"
                                                data-id="<?= $id ?>"
                                                data-url="/documentos-ia/procesar/<?= $id ?>"
                                                data-csrf="<?= documentosIaEsc($csrfToken) ?>"
                                                title="Procesar"
                                            >
                                                <i class="bi bi-cpu"></i>
                                            </button>

                                        <?php endif; ?>


                                        <button
                                            type="button"
                                            class="btn btn-sm btn-outline-danger btn-eliminar-documento"
                                            data-id="<?= $id ?>"
                                            data-url="/documentos-ia/eliminar/<?= $id ?>"
                                            data-csrf="<?= documentosIaEsc($csrfToken) ?>"
                                            title="Eliminar"
                                        >
                                            <i class="bi bi-trash"></i>
                                        </button>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<script src="/assets/js/documentos-ia.js"></script>