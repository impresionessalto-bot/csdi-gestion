<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Repositories;

use PDO;
use RuntimeException;
use Throwable;

final class Repository
{
    private PDO $db;

    private string $table = 'documentos_ia';

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        return [
            'resumen'    => $this->resumen(),
            'documentos' => $this->listar(100),
            'procesos'   => $this->procesos(),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN
    |--------------------------------------------------------------------------
    */

    public function resumen(): array
    {
        $sql = "
            SELECT
                COUNT(*) AS total,

                SUM(
                    CASE
                        WHEN estado = 'PENDIENTE'
                        THEN 1 ELSE 0
                    END
                ) AS pendientes,

                SUM(
                    CASE
                        WHEN estado = 'PROCESANDO'
                        THEN 1 ELSE 0
                    END
                ) AS procesando,

                SUM(
                    CASE
                        WHEN estado = 'PROCESADO'
                        THEN 1 ELSE 0
                    END
                ) AS procesados,

                SUM(
                    CASE
                        WHEN estado = 'ERROR'
                        THEN 1 ELSE 0
                    END
                ) AS errores

            FROM {$this->table}
        ";

        $stmt = $this->db->query($sql);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!is_array($row)) {
            return [
                'total'      => 0,
                'pendientes' => 0,
                'procesando' => 0,
                'procesados' => 0,
                'errores'    => 0,
            ];
        }

        return [
            'total'      => (int) ($row['total'] ?? 0),
            'pendientes' => (int) ($row['pendientes'] ?? 0),
            'procesando' => (int) ($row['procesando'] ?? 0),
            'procesados' => (int) ($row['procesados'] ?? 0),
            'errores'    => (int) ($row['errores'] ?? 0),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAR
    |--------------------------------------------------------------------------
    */

    public function listar(
        int $limite = 100,
        int $offset = 0
    ): array {

        $limite = max(1, min($limite, 500));
        $offset = max(0, $offset);

        $sql = "
            SELECT
                id,
                empresa_id,
                tipo_documento,
                origen,
                nombre_archivo,
                archivo_path,
                mime_type,
                extension,
                tamano_bytes,
                estado,
                proveedor_ia,
                modelo_ia,
                texto_extraido,
                datos_json,
                confianza,
                error_mensaje,
                usuario_id,
                creado_en,
                actualizado_en,
                procesado_en

            FROM {$this->table}

            ORDER BY creado_en DESC, id DESC

            LIMIT {$limite}
            OFFSET {$offset}
        ";

        $stmt = $this->db->query($sql);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return is_array($rows)
            ? $rows
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER
    |--------------------------------------------------------------------------
    */

    public function obtener(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        $sql = "
            SELECT
                id,
                empresa_id,
                tipo_documento,
                origen,
                nombre_archivo,
                archivo_path,
                mime_type,
                extension,
                tamano_bytes,
                estado,
                proveedor_ia,
                modelo_ia,
                texto_extraido,
                datos_json,
                confianza,
                error_mensaje,
                usuario_id,
                creado_en,
                actualizado_en,
                procesado_en

            FROM {$this->table}

            WHERE id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $id,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row)
            ? $row
            : null;
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(array $data): int
    {
        $sql = "
            INSERT INTO {$this->table}
            (
                empresa_id,
                tipo_documento,
                origen,
                nombre_archivo,
                archivo_path,
                mime_type,
                extension,
                tamano_bytes,
                estado,
                proveedor_ia,
                modelo_ia,
                texto_extraido,
                datos_json,
                confianza,
                error_mensaje,
                usuario_id,
                creado_en,
                actualizado_en,
                procesado_en
            )
            VALUES
            (
                :empresa_id,
                :tipo_documento,
                :origen,
                :nombre_archivo,
                :archivo_path,
                :mime_type,
                :extension,
                :tamano_bytes,
                :estado,
                :proveedor_ia,
                :modelo_ia,
                :texto_extraido,
                :datos_json,
                :confianza,
                :error_mensaje,
                :usuario_id,
                NOW(),
                :actualizado_en,
                :procesado_en
            )
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':empresa_id'       => $data['empresa_id'] ?? null,
            ':tipo_documento'  => $data['tipo_documento'] ?? 'OTRO',
            ':origen'          => $data['origen'] ?? 'MANUAL',
            ':nombre_archivo'  => $data['nombre_archivo'] ?? null,
            ':archivo_path'    => $data['archivo_path'] ?? null,
            ':mime_type'       => $data['mime_type'] ?? null,
            ':extension'       => $data['extension'] ?? null,
            ':tamano_bytes'    => $data['tamano_bytes'] ?? null,
            ':estado'          => $data['estado'] ?? 'PENDIENTE',
            ':proveedor_ia'    => $data['proveedor_ia'] ?? null,
            ':modelo_ia'       => $data['modelo_ia'] ?? null,
            ':texto_extraido'  => $data['texto_extraido'] ?? null,
            ':datos_json'      => $data['datos_json'] ?? null,
            ':confianza'       => $data['confianza'] ?? null,
            ':error_mensaje'   => $data['error_mensaje'] ?? null,
            ':usuario_id'      => $data['usuario_id'] ?? null,
            ':actualizado_en'  => $data['actualizado_en'] ?? null,
            ':procesado_en'    => $data['procesado_en'] ?? null,
        ]);

        return (int) $this->db->lastInsertId();
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(
        int $id,
        array $data
    ): bool {

        if ($id <= 0 || empty($data)) {
            return false;
        }

        $permitidos = [
            'empresa_id',
            'tipo_documento',
            'origen',
            'nombre_archivo',
            'archivo_path',
            'mime_type',
            'extension',
            'tamano_bytes',
            'estado',
            'proveedor_ia',
            'modelo_ia',
            'texto_extraido',
            'datos_json',
            'confianza',
            'error_mensaje',
            'usuario_id',
            'actualizado_en',
            'procesado_en',
        ];

        $sets = [];
        $params = [
            ':id' => $id,
        ];

        foreach ($permitidos as $campo) {

            if (!array_key_exists($campo, $data)) {
                continue;
            }

            $sets[] = "{$campo} = :{$campo}";

            $params[":{$campo}"] = $data[$campo];
        }

        if (!$sets) {
            return false;
        }

        /*
         * Siempre actualizamos la fecha de modificación,
         * salvo que ya haya sido enviada explícitamente.
         */

        if (!array_key_exists('actualizado_en', $data)) {
            $sets[] = 'actualizado_en = NOW()';
        }

        $sql = "
            UPDATE {$this->table}

            SET
                " . implode(",\n", $sets) . "

            WHERE id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute($params);
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(int $id): bool
    {
        if ($id <= 0) {
            return false;
        }

        $stmt = $this->db->prepare(
            "
            DELETE FROM {$this->table}
            WHERE id = :id
            LIMIT 1
            "
        );

        return $stmt->execute([
            ':id' => $id,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | PENDIENTES
    |--------------------------------------------------------------------------
    */

    public function pendientes(
        int $limite = 100
    ): array {

        $limite = max(1, min($limite, 500));

        $sql = "
            SELECT
                id,
                empresa_id,
                tipo_documento,
                origen,
                nombre_archivo,
                archivo_path,
                mime_type,
                extension,
                tamano_bytes,
                estado,
                proveedor_ia,
                modelo_ia,
                texto_extraido,
                datos_json,
                confianza,
                error_mensaje,
                usuario_id,
                creado_en,
                actualizado_en,
                procesado_en

            FROM {$this->table}

            WHERE estado = 'PENDIENTE'

            ORDER BY creado_en ASC, id ASC

            LIMIT {$limite}
        ";

        $stmt = $this->db->query($sql);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return is_array($rows)
            ? $rows
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | PROCESOS
    |--------------------------------------------------------------------------
    |
    | Este método es el que faltaba.
    |
    | Devuelve información para el dashboard sobre el
    | procesamiento de documentos.
    |
    */

    public function procesos(): array
    {
        $sql = "
            SELECT
                estado,
                COUNT(*) AS cantidad

            FROM {$this->table}

            GROUP BY estado

            ORDER BY
                CASE estado
                    WHEN 'PROCESANDO' THEN 1
                    WHEN 'PENDIENTE' THEN 2
                    WHEN 'PROCESADO' THEN 3
                    WHEN 'ERROR' THEN 4
                    ELSE 5
                END
        ";

        $stmt = $this->db->query($sql);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!is_array($rows)) {
            return [];
        }

        $resultado = [];

        foreach ($rows as $row) {

            $estado = (string) (
                $row['estado'] ?? ''
            );

            if ($estado === '') {
                continue;
            }

            $resultado[] = [
                'estado' => $estado,
                'cantidad' => (int) (
                    $row['cantidad'] ?? 0
                ),
            ];
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | CONTAR
    |--------------------------------------------------------------------------
    */

    public function contar(): int
    {
        $stmt = $this->db->query(
            "
            SELECT COUNT(*)
            FROM {$this->table}
            "
        );

        return (int) $stmt->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | CAMBIAR ESTADO
    |--------------------------------------------------------------------------
    */

    public function cambiarEstado(
        int $id,
        string $estado,
        ?string $error = null
    ): bool {

        $estadosValidos = [
            'PENDIENTE',
            'PROCESANDO',
            'PROCESADO',
            'ERROR',
        ];

        if (
            $id <= 0
            ||
            !in_array(
                $estado,
                $estadosValidos,
                true
            )
        ) {
            return false;
        }

        $sql = "
            UPDATE {$this->table}

            SET
                estado = :estado,
                error_mensaje = :error,
                actualizado_en = NOW()

            WHERE id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':estado' => $estado,
            ':error'  => $error,
            ':id'     => $id,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADOS DE PROCESAMIENTO
    |--------------------------------------------------------------------------
    */

    /**
     * Marca el documento como PROCESANDO.
     *
     * Se mantiene como método explícito porque el Service orquesta el flujo
     * y necesita distinguir el inicio del procesamiento de su resultado.
     */
    public function marcarProcesando(int $id): bool
    {
        if ($id <= 0) {
            return false;
        }

        $sql = "
            UPDATE {$this->table}
            SET
                estado = 'PROCESANDO',
                error_mensaje = NULL,
                actualizado_en = NOW()
            WHERE id = :id
              AND estado <> 'PROCESANDO'
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        if (!$stmt->execute([':id' => $id])) {
            return false;
        }

        return $stmt->rowCount() > 0;
    }

    /**
     * Marca el documento como procesado.
     *
     * El resultado detallado se persiste mediante guardarResultado().
     * Este método existe para mantener un contrato claro con el Service.
     */
    public function marcarProcesado(int $id): bool
    {
        return $this->cambiarEstado($id, 'PROCESADO');
    }

    /**
     * Marca el documento como ERROR y conserva el mensaje para diagnóstico.
     */
    public function marcarError(int $id, ?string $error = null): bool
    {
        return $this->cambiarEstado($id, 'ERROR', $error);
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR RESULTADO DE PROCESAMIENTO
    |--------------------------------------------------------------------------
    */

    public function guardarResultado(
        int $id,
        array $resultado
    ): bool {

        if ($id <= 0) {
            return false;
        }

        $datosJson = null;

        if (
            array_key_exists(
                'datos_json',
                $resultado
            )
        ) {

            if (
                is_array(
                    $resultado['datos_json']
                )
            ) {

                $datosJson = json_encode(
                    $resultado['datos_json'],
                    JSON_UNESCAPED_UNICODE |
                    JSON_UNESCAPED_SLASHES
                );

            } else {

                $datosJson =
                    $resultado['datos_json'];
            }
        }

        $sql = "
            UPDATE {$this->table}

            SET
                estado = :estado,
                proveedor_ia = :proveedor_ia,
                modelo_ia = :modelo_ia,
                texto_extraido = :texto_extraido,
                datos_json = :datos_json,
                confianza = :confianza,
                error_mensaje = :error_mensaje,
                procesado_en = :procesado_en,
                actualizado_en = NOW()

            WHERE id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':estado'         => $resultado['estado'] ?? 'PROCESADO',
            ':proveedor_ia'   => $resultado['proveedor_ia'] ?? null,
            ':modelo_ia'      => $resultado['modelo_ia'] ?? null,
            ':texto_extraido' => $resultado['texto_extraido'] ?? null,
            ':datos_json'     => $datosJson,
            ':confianza'      => $resultado['confianza'] ?? null,
            ':error_mensaje'  => $resultado['error_mensaje'] ?? null,
            ':procesado_en'   => $resultado['procesado_en'] ?? date('Y-m-d H:i:s'),
            ':id'             => $id,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR
    |--------------------------------------------------------------------------
    */

    public function buscar(
        string $texto,
        int $limite = 100
    ): array {

        $texto = trim($texto);

        if ($texto === '') {
            return [];
        }

        $limite = max(1, min($limite, 500));

        $sql = "
            SELECT
                id,
                empresa_id,
                tipo_documento,
                origen,
                nombre_archivo,
                archivo_path,
                mime_type,
                extension,
                tamano_bytes,
                estado,
                proveedor_ia,
                modelo_ia,
                texto_extraido,
                datos_json,
                confianza,
                error_mensaje,
                usuario_id,
                creado_en,
                actualizado_en,
                procesado_en

            FROM {$this->table}

            WHERE
                nombre_archivo LIKE :texto
                OR texto_extraido LIKE :texto
                OR tipo_documento LIKE :texto

            ORDER BY creado_en DESC, id DESC

            LIMIT {$limite}
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':texto' => '%' . $texto . '%',
        ]);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return is_array($rows)
            ? $rows
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | DOCUMENTOS POR ESTADO
    |--------------------------------------------------------------------------
    */

    public function porEstado(
        string $estado,
        int $limite = 100
    ): array {

        $estadosValidos = [
            'PENDIENTE',
            'PROCESANDO',
            'PROCESADO',
            'ERROR',
        ];

        if (
            !in_array(
                $estado,
                $estadosValidos,
                true
            )
        ) {
            return [];
        }

        $limite = max(1, min($limite, 500));

        $sql = "
            SELECT
                *

            FROM {$this->table}

            WHERE estado = :estado

            ORDER BY creado_en DESC, id DESC

            LIMIT {$limite}
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':estado' => $estado,
        ]);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return is_array($rows)
            ? $rows
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | ULTIMOS PROCESADOS
    |--------------------------------------------------------------------------
    */

    public function ultimosProcesados(
        int $limite = 20
    ): array {

        $limite = max(1, min($limite, 100));

        $sql = "
            SELECT
                id,
                nombre_archivo,
                tipo_documento,
                confianza,
                estado,
                creado_en,
                procesado_en

            FROM {$this->table}

            WHERE estado = 'PROCESADO'

            ORDER BY procesado_en DESC, id DESC

            LIMIT {$limite}
        ";

        $stmt = $this->db->query($sql);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return is_array($rows)
            ? $rows
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS POR TIPO
    |--------------------------------------------------------------------------
    */

    public function estadisticasTipos(): array
    {
        $sql = "
            SELECT
                tipo_documento,
                COUNT(*) AS cantidad,
                AVG(confianza) AS confianza_promedio

            FROM {$this->table}

            GROUP BY tipo_documento

            ORDER BY cantidad DESC
        ";

        $stmt = $this->db->query($sql);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {

            $row['cantidad'] =
                (int) (
                    $row['cantidad'] ?? 0
                );

            $row['confianza_promedio'] =
                $row['confianza_promedio'] !== null
                    ? round(
                        (float) $row['confianza_promedio'],
                        2
                    )
                    : null;
        }

        unset($row);

        return $rows;
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS POR ESTADO
    |--------------------------------------------------------------------------
    */

    public function estadisticasEstados(): array
    {
        $sql = "
            SELECT
                estado,
                COUNT(*) AS cantidad

            FROM {$this->table}

            GROUP BY estado

            ORDER BY cantidad DESC
        ";

        $stmt = $this->db->query($sql);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {

            $row['cantidad'] =
                (int) (
                    $row['cantidad'] ?? 0
                );
        }

        unset($row);

        return $rows;
    }

    /*
    |--------------------------------------------------------------------------
    | REINICIAR PROCESAMIENTO
    |--------------------------------------------------------------------------
    */

    public function reiniciarProcesamiento(
        int $id
    ): bool {

        if ($id <= 0) {
            return false;
        }

        $sql = "
            UPDATE {$this->table}

            SET
                estado = 'PENDIENTE',
                proveedor_ia = NULL,
                modelo_ia = NULL,
                texto_extraido = NULL,
                datos_json = NULL,
                confianza = NULL,
                error_mensaje = NULL,
                procesado_en = NULL,
                actualizado_en = NOW()

            WHERE id = :id

            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            ':id' => $id,
        ]);
    }
}