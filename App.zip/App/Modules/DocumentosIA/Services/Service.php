<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Services;

use App\Modules\DocumentosIA\Engines\Classifier;
use App\Modules\DocumentosIA\Engines\EntityResolver;
use App\Modules\DocumentosIA\Engines\Extractor;
use App\Modules\DocumentosIA\Engines\TextExtractor;
use App\Modules\DocumentosIA\Support\FileManager;
use App\Modules\DocumentosIA\Engines\Validator;
use App\Modules\DocumentosIA\Providers\OcrSpaceProvider;
use App\Modules\DocumentosIA\Repositories\Repository;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class Service
{
    public function __construct(
        private readonly Repository $repository,
        private readonly Classifier $classifier,
        private readonly Validator $validator,
        private readonly TextExtractor $textExtractor,
        private readonly EntityResolver $entityResolver,
        private readonly Extractor $extractor,
        private readonly FileManager $storage,
        private readonly OcrSpaceProvider $ocrProvider
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        return [
            'resumen' => $this->repository->resumen(),
            'documentos' => $this->repository->listar(),
            'procesos' => $this->repository->procesos(),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER
    |--------------------------------------------------------------------------
    */

    public function obtener(int $id): ?array
    {
        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de documento inválido.'
            );
        }

        return $this->repository->obtener($id);
    }

    /*
    |--------------------------------------------------------------------------
    | SUBIR DOCUMENTO
    |--------------------------------------------------------------------------
    */

    public function subir(
        array $archivo,
        string $tipoDocumento = 'OTRO',
        string $origen = 'MANUAL',
        ?int $usuarioId = null,
        string $observacion = ''
    ): array {
        $this->validarArchivo($archivo);

        $tipoDocumento = strtoupper(
            trim($tipoDocumento)
        );

        if ($tipoDocumento === '') {
            $tipoDocumento = 'OTRO';
        }

        $origen = strtoupper(
            trim($origen)
        );

        if ($origen === '') {
            $origen = 'MANUAL';
        }

        /*
        |--------------------------------------------------------------------------
        | GUARDAR ARCHIVO
        |--------------------------------------------------------------------------
        */

        $archivoGuardado = $this->storage->guardar(
            $archivo
        );

        try {

            /*
            |--------------------------------------------------------------------------
            | CREAR DOCUMENTO
            |--------------------------------------------------------------------------
            */

            $id = $this->repository->crear([
                'tipo_documento' =>
                    $tipoDocumento,

                'categoria' =>
                    null,

                'subcategoria' =>
                    null,

                'modulo_destino' =>
                    null,

                'origen' =>
                    $origen,

                'entidad_tipo' =>
                    null,

                'entidad_id' =>
                    null,

                'nombre_archivo' =>
                    (string) ($archivoGuardado['nombre_original'] ?? $archivoGuardado['nombre_fisico'] ?? 'documento'),

                'archivo_path' =>
                    $archivoGuardado['archivo_path'],

                'mime_type' =>
                    $archivoGuardado['mime_type'],

                'extension' =>
                    $archivoGuardado['extension'],

                'tamano_bytes' =>
                    $archivoGuardado['tamano_bytes'],

                'estado' =>
                    'PENDIENTE',

                'proveedor_ia' =>
                    null,

                'modelo_ia' =>
                    null,

                'texto_extraido' =>
                    null,

                'datos_json' =>
                    null,

                'confianza' =>
                    null,

                'clasificacion_manual' =>
                    0,

                'error_mensaje' =>
                    null,

                'usuario_id' =>
                    $usuarioId,
            ]);

            if ($id <= 0) {
                throw new RuntimeException(
                    'No se pudo crear el registro del documento.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | PROCESAMIENTO AUTOMÁTICO
            |--------------------------------------------------------------------------
            |
            | El documento queda primero registrado como PENDIENTE.
            | Luego intentamos procesarlo.
            |
            */

            $resultadoProcesamiento =
                $this->procesar($id);

            return [
                'id' =>
                    $id,

                'archivo' =>
                    $archivoGuardado,

                'documento' =>
                    $resultadoProcesamiento,
            ];

        } catch (Throwable $e) {

            /*
            |--------------------------------------------------------------------------
            | ROLLBACK FÍSICO
            |--------------------------------------------------------------------------
            |
            | Si se creó el archivo pero falló el registro,
            | eliminamos el archivo para no dejar basura.
            |
            */

            $this->storage->eliminar(
                (string) (
                    $archivoGuardado['archivo_path']
                    ?? ''
                )
            );

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PROCESAR DOCUMENTO
    |--------------------------------------------------------------------------
    */

    public function procesar(int $id): array
    {
        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de documento inválido.'
            );
        }

        $documento =
            $this->repository->obtener($id);

        if (!is_array($documento)) {
            throw new RuntimeException(
                'El documento no existe.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | ESTADO
        |--------------------------------------------------------------------------
        */

        $estado =
            strtoupper(
                (string) (
                    $documento['estado']
                    ?? 'PENDIENTE'
                )
            );

        if (
            $estado === 'PROCESANDO'
        ) {
            throw new RuntimeException(
                'El documento ya se encuentra en proceso.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | MARCAR PROCESANDO
        |--------------------------------------------------------------------------
        */

        $this->repository->marcarProcesando(
            $id
        );

        try {

            /*
            |--------------------------------------------------------------------------
            | RUTA FÍSICA
            |--------------------------------------------------------------------------
            */

            $archivoPath =
                trim(
                    (string) (
                        $documento['archivo_path']
                        ?? ''
                    )
                );

            if ($archivoPath === '') {
                throw new RuntimeException(
                    'El documento no tiene una ruta de archivo.'
                );
            }

            $archivoFisico =
                $this->storage->resolver(
                    $archivoPath
                );

            if (
                $archivoFisico === null
                || !is_file(
                    $archivoFisico
                )
            ) {
                throw new RuntimeException(
                    'El archivo físico del documento no existe.'
                );
            }

            if (
                !is_readable(
                    $archivoFisico
                )
            ) {
                throw new RuntimeException(
                    'El archivo del documento no se puede leer.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | MIME
            |--------------------------------------------------------------------------
            */

            $mimeType =
                trim(
                    (string) (
                        $documento['mime_type']
                        ?? ''
                    )
                );

            if ($mimeType === '') {
                $mimeType = null;
            }

            /*
            |--------------------------------------------------------------------------
            | EXTRAER TEXTO
            |--------------------------------------------------------------------------
            */

            $textoExtraido =
                $this->extraerTexto(
                    $archivoFisico,
                    $mimeType
                );

            $textoExtraido = trim($textoExtraido);

            /*
            |------------------------------------------------------------------
            | OCR REMOTO
            |------------------------------------------------------------------
            | Si el extractor PHP no obtiene texto (caso habitual en JPG/PNG
            | y PDFs escaneados), usamos el Provider OCR. Esto es obligatorio
            | para que las imágenes puedan entrar al mismo pipeline de
            | clasificación/extracción. No se ejecuta ningún binario del SO.
            */
            $ocrResult = null;
            if ($textoExtraido === '' && $this->ocrProvider->disponible()) {
                $ocrResult = $this->ocrProvider->procesar([
                    'path' => $archivoFisico,
                    'mime_type' => $mimeType ?? '',
                    'language' => 'spa',
                ]);

                if (($ocrResult['success'] ?? false) === true) {
                    $textoOcr = trim((string) (($ocrResult['data']['texto'] ?? '')));
                    if ($textoOcr !== '') {
                        $textoExtraido = $textoOcr;
                    }
                }
            }

            /*
            |--------------------------------------------------------------------------
            | CLASIFICAR
            |--------------------------------------------------------------------------
            */

            $clasificacion =
                $this->classifier->classify(
                    $textoExtraido,
                    $mimeType
                );

            /*
            |--------------------------------------------------------------------------
            | TIPO DOCUMENTO
            |--------------------------------------------------------------------------
            */

            $tipoDocumento =
                strtoupper(
                    trim(
                        (string) (
                            $clasificacion['tipo_documento']
                            ?? 'OTRO'
                        )
                    )
                );

            if ($tipoDocumento === '') {
                $tipoDocumento = 'OTRO';
            }

            /*
            |--------------------------------------------------------------------------
            | CATEGORÍA
            |--------------------------------------------------------------------------
            */

            $categoria =
                $clasificacion['categoria']
                ?? null;

            if (
                $categoria !== null
                &&
                trim((string) $categoria) === ''
            ) {
                $categoria = null;
            }

            /*
            |--------------------------------------------------------------------------
            | SUBTIPO
            |--------------------------------------------------------------------------
            */

            $subcategoria =
                $clasificacion['subtipo_documento']
                ?? null;

            if (
                $subcategoria !== null
                &&
                trim((string) $subcategoria) === ''
            ) {
                $subcategoria = null;
            }

            /*
            |--------------------------------------------------------------------------
            | MÓDULO
            |--------------------------------------------------------------------------
            */

            $moduloDestino =
                $clasificacion['modulo_destino']
                ?? null;

            if (
                $moduloDestino !== null
                &&
                trim((string) $moduloDestino) === ''
            ) {
                $moduloDestino = null;
            }

            /*
            |--------------------------------------------------------------------------
            | DATOS EXTRAÍDOS
            |--------------------------------------------------------------------------
            |
            | TextExtractor puede devolver solamente texto o,
            | si posteriormente lo ampliamos, datos estructurados.
            |
            */

            $datosExtraidos = [];

            /*
            |--------------------------------------------------------------------------
            | DATOS EXISTENTES
            |--------------------------------------------------------------------------
            */

            $datosExistentes = [];

            if (
                isset(
                    $documento['datos_json']
                )
            ) {
                $json =
                    json_decode(
                        (string) $documento['datos_json'],
                        true
                    );

                if (
                    is_array($json)
                ) {
                    $datosExistentes =
                        $json;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | EXTRAER DATOS ESTRUCTURADOS
            |--------------------------------------------------------------------------
            */

            $datosExtraidos = $this->extractor->extract($textoExtraido);

            /*
            |--------------------------------------------------------------------------
            | UNIFICAR DATOS
            |--------------------------------------------------------------------------
            */

            $datos =
                array_merge(
                    $datosExistentes,
                    $datosExtraidos
                );

            /*
            |--------------------------------------------------------------------------
            | INFORMACIÓN DE CLASIFICACIÓN
            |--------------------------------------------------------------------------
            */

            $datos['_clasificacion'] = [
                'tipo_documento' =>
                    $tipoDocumento,

                'categoria' =>
                    $categoria,

                'subcategoria' =>
                    $subcategoria,

                'modulo_destino' =>
                    $moduloDestino,

                'coincidencias' =>
                    is_array(
                        $clasificacion['coincidencias']
                        ?? null
                    )
                        ? $clasificacion['coincidencias']
                        : [],

                'puntaje' =>
                    (int) (
                        $clasificacion['puntaje']
                        ?? 0
                    ),
            ];

            /*
            |--------------------------------------------------------------------------
            | VALIDACIÓN
            |--------------------------------------------------------------------------
            */

            $datosParaValidar = array_merge(
                $datos,
                [
                    'tipo_documento' => $tipoDocumento,
                    'importes' => [
                        'subtotal' => $datos['subtotal'] ?? null,
                        'iva' => $datos['iva'] ?? null,
                        'total' => $datos['total'] ?? null,
                    ],
                ]
            );

            $validacion =
                $this->validator->validate(
                    $datosParaValidar
                );

            $datos['_validacion'] =
                $validacion;

            /*
            |--------------------------------------------------------------------------
            | RESOLVER ENTIDAD
            |--------------------------------------------------------------------------
            */

            $entidad =
                $this->entityResolver->resolve(
                    $datos,
                    $tipoDocumento
                );

            if (
                isset(
                    $entidad['entidad_tipo']
                )
                &&
                $entidad['entidad_tipo'] !== null
            ) {

                $datos['_entidad'] =
                    $entidad;
            }

            /*
            |--------------------------------------------------------------------------
            | CONFIANZA
            |--------------------------------------------------------------------------
            */

            $confianza =
                $clasificacion['confianza']
                ?? null;

            if (
                $confianza !== null
            ) {
                $confianza =
                    round(
                        (float) $confianza,
                        2
                    );
            }

            /*
            |--------------------------------------------------------------------------
            | SI VALIDACIÓN FALLA
            |--------------------------------------------------------------------------
            */

            $estadoFinal =
                'PROCESADO';

            $errorMensaje = null;

            if (
                !($validacion['valido'] ?? true)
            ) {

                /*
                 * No marcamos ERROR por una inconsistencia
                 * documental. El documento fue procesado,
                 * pero queda registrada la validación.
                 */

                $datos['_validacion']['requiere_revision'] =
                    true;
            }

            /*
            |--------------------------------------------------------------------------
            | ACTUALIZAR ENTIDAD
            |--------------------------------------------------------------------------
            */

            $entidadTipo =
                $entidad['entidad_tipo']
                ?? null;

            $entidadId =
                $entidad['entidad_id']
                ?? null;

            if (
                $entidadTipo !== null
            ) {
                $entidadTipo =
                    strtoupper(
                        trim(
                            (string) $entidadTipo
                        )
                    );
            }

            if (
                $entidadId !== null
            ) {
                $entidadId =
                    (int) $entidadId;

                if ($entidadId <= 0) {
                    $entidadId = null;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | GUARDAR RESULTADO
            |--------------------------------------------------------------------------
            */

            $proveedorIA = $ocrResult['proveedor'] ?? 'local-rules';
            $modeloIA = $ocrResult['modelo'] ?? 'local-rules';

            $this->repository->guardarResultado(
                $id,
                [
                    'tipo_documento' =>
                        $tipoDocumento,

                    'proveedor_ia' =>
                        $proveedorIA,

                    'modelo_ia' =>
                        $modeloIA,

                    'categoria' =>
                        $categoria,

                    'subcategoria' =>
                        $subcategoria,

                    'modulo_destino' =>
                        $moduloDestino,

                    'entidad_tipo' =>
                        $entidadTipo,

                    'entidad_id' =>
                        $entidadId,

                    'mime_type' =>
                        $mimeType,

                    'texto_extraido' =>
                        $textoExtraido,

                    'datos_json' =>
                        json_encode(
                            $datos,
                            JSON_UNESCAPED_UNICODE
                            |
                            JSON_UNESCAPED_SLASHES
                            |
                            JSON_INVALID_UTF8_SUBSTITUTE
                        ),

                    'confianza' =>
                        $confianza,

                    'estado' =>
                        $estadoFinal,

                    'error_mensaje' =>
                        $errorMensaje,
                ]
            );

            /*
            |--------------------------------------------------------------------------
            | RESULTADO
            |--------------------------------------------------------------------------
            */

            return [
                'id' =>
                    $id,

                'estado' =>
                    $estadoFinal,

                'tipo_documento' =>
                    $tipoDocumento,

                'categoria' =>
                    $categoria,

                'subcategoria' =>
                    $subcategoria,

                'modulo_destino' =>
                    $moduloDestino,

                'entidad' =>
                    $entidad,

                'confianza' =>
                    $confianza,

                'texto_extraido' =>
                    $textoExtraido,

                'datos' =>
                    $datos,

                'validacion' =>
                    $validacion,

                'clasificacion' =>
                    $clasificacion,
            ];

        } catch (Throwable $e) {

            /*
            |--------------------------------------------------------------------------
            | ERROR
            |--------------------------------------------------------------------------
            */

            $mensaje =
                trim(
                    $e->getMessage()
                );

            if ($mensaje === '') {
                $mensaje =
                    'Error desconocido al procesar el documento.';
            }

            try {

                $this->repository->marcarError(
                    $id,
                    $mensaje
                );

            } catch (Throwable) {
                /*
                 * No ocultamos el error original.
                 */
            }

            throw $e;
        }
    }

    /**
     * Confirma/corrige manualmente el resultado procesado.
     * No crea entidades en módulos destino: solo deja el documento
     * validado y listo para una integración posterior.
     */
    public function confirmar(int $id, array $datos = []): array
    {
        if ($id <= 0) {
            throw new InvalidArgumentException('ID de documento inválido.');
        }

        $documento = $this->repository->obtener($id);
        if (!is_array($documento)) {
            throw new RuntimeException('El documento no existe.');
        }

        $existentes = [];
        $json = $documento['datos_json'] ?? null;
        if (is_string($json) && trim($json) !== '') {
            $decodificado = json_decode($json, true);
            if (is_array($decodificado)) {
                $existentes = $decodificado;
            }
        } elseif (is_array($json)) {
            $existentes = $json;
        }

        $permitidos = [
            'cuit','razon_social','fecha','numero_comprobante',
            'tipo_comprobante','subtotal','iva','total','cliente',
            'proveedor','items','observaciones','diagnostico',
            'trabajo_realizado','serie','equipo',
        ];

        foreach ($permitidos as $campo) {
            if (array_key_exists($campo, $datos)) {
                $existentes[$campo] = $datos[$campo];
            }
        }

        $existentes['_confirmacion'] = [
            'confirmado' => true,
            'fecha' => date('Y-m-d H:i:s'),
        ];

        $ok = $this->repository->actualizar($id, [
            'datos_json' => json_encode($existentes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE),
            'estado' => 'PROCESADO',
            'error_mensaje' => null,
        ]);

        if (!$ok) {
            throw new RuntimeException('No se pudo confirmar el documento.');
        }

        $actualizado = $this->repository->obtener($id);
        return $actualizado ?? ['id' => $id, 'estado' => 'PROCESADO', 'datos' => $existentes];
    }

    /*
    |--------------------------------------------------------------------------
    | PROCESAR PENDIENTES
    |--------------------------------------------------------------------------
    */

    public function procesarPendientes(
        int $limite = 20
    ): array {
        $limite =
            max(
                1,
                min(
                    100,
                    $limite
                )
            );

        $documentos =
            $this->repository->pendientes(
                $limite
            );

        $procesados = [];
        $errores = [];

        foreach ($documentos as $documento) {

            $id =
                (int) (
                    $documento['id']
                    ?? 0
                );

            if ($id <= 0) {
                continue;
            }

            try {

                $resultado =
                    $this->procesar(
                        $id
                    );

                $procesados[] = [
                    'id' =>
                        $id,

                    'success' =>
                        true,

                    'resultado' =>
                        $resultado,
                ];

            } catch (Throwable $e) {

                $errores[] = [
                    'id' =>
                        $id,

                    'success' =>
                        false,

                    'error' =>
                        $e->getMessage(),
                ];
            }
        }

        return [
            'total' =>
                count($documentos),

            'procesados' =>
                count($procesados),

            'errores' =>
                count($errores),

            'detalle' => [
                'procesados' =>
                    $procesados,

                'errores' =>
                    $errores,
            ],
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(
        int $id
    ): array {
        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de documento inválido.'
            );
        }

        $documento =
            $this->repository->obtener(
                $id
            );

        if (!is_array($documento)) {
            throw new RuntimeException(
                'El documento no existe.'
            );
        }

        $archivoPath =
            trim(
                (string) (
                    $documento['archivo_path']
                    ?? ''
                )
            );

        /*
        |--------------------------------------------------------------------------
        | ELIMINAR REGISTRO
        |--------------------------------------------------------------------------
        */

        $eliminado =
            $this->repository->eliminar(
                $id
            );

        if (!$eliminado) {
            throw new RuntimeException(
                'No se pudo eliminar el documento.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | ELIMINAR ARCHIVO
        |--------------------------------------------------------------------------
        */

        $archivoEliminado = true;

        if ($archivoPath !== '') {

            $archivoEliminado =
                $this->storage->eliminar(
                    $archivoPath
                );
        }

        return [
            'id' =>
                $id,

            'registro_eliminado' =>
                true,

            'archivo_eliminado' =>
                $archivoEliminado,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | EXTRAER TEXTO
    |--------------------------------------------------------------------------
    */

    private function extraerTexto(
        string $archivoFisico,
        ?string $mimeType
    ): string {
        /*
        |----------------------------------------------------------------------
        | Compatibilidad con diferentes implementaciones de TextExtractor.
        |----------------------------------------------------------------------
        */

        if (
            method_exists(
                $this->textExtractor,
                'extract'
            )
        ) {

            $resultado =
                $this->textExtractor->extract(
                    $archivoFisico,
                    $mimeType
                );

            if (
                is_string($resultado)
            ) {
                return $resultado;
            }

            if (
                is_array($resultado)
            ) {

                return trim(
                    (string) (
                        $resultado['texto']
                        ??
                        $resultado['text']
                        ??
                        ''
                    )
                );
            }
        }

        if (
            method_exists(
                $this->textExtractor,
                'extraer'
            )
        ) {

            $resultado =
                $this->textExtractor->extraer(
                    $archivoFisico,
                    $mimeType
                );

            if (
                is_string($resultado)
            ) {
                return $resultado;
            }

            if (
                is_array($resultado)
            ) {

                return trim(
                    (string) (
                        $resultado['texto']
                        ??
                        $resultado['text']
                        ??
                        ''
                    )
                );
            }
        }

        throw new RuntimeException(
            'TextExtractor no implementa un método de extracción compatible.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDAR ARCHIVO
    |--------------------------------------------------------------------------
    */

    private function validarArchivo(
        array $archivo
    ): void {
        $error =
            (int) (
                $archivo['error']
                ?? UPLOAD_ERR_NO_FILE
            );

        if (
            $error !== UPLOAD_ERR_OK
        ) {
            throw new InvalidArgumentException(
                $this->mensajeUploadError(
                    $error
                )
            );
        }

        $tmpName =
            trim(
                (string) (
                    $archivo['tmp_name']
                    ?? ''
                )
            );

        if ($tmpName === '') {
            throw new InvalidArgumentException(
                'No se recibió el archivo temporal.'
            );
        }

        if (
            !is_file(
                $tmpName
            )
        ) {
            throw new InvalidArgumentException(
                'El archivo temporal no existe.'
            );
        }

        if (
            !is_readable(
                $tmpName
            )
        ) {
            throw new InvalidArgumentException(
                'El archivo temporal no se puede leer.'
            );
        }

        $nombre =
            trim(
                (string) (
                    $archivo['name']
                    ?? ''
                )
            );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El archivo no tiene nombre.'
            );
        }

        $tamano =
            (int) (
                $archivo['size']
                ?? 0
            );

        if ($tamano <= 0) {
            throw new InvalidArgumentException(
                'El archivo está vacío.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | EXTENSIÓN
        |--------------------------------------------------------------------------
        */

        $extension =
            strtolower(
                pathinfo(
                    $nombre,
                    PATHINFO_EXTENSION
                )
            );

        if ($extension === '') {
            throw new InvalidArgumentException(
                'El archivo no tiene extensión.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | EXTENSIONES PERMITIDAS
        |--------------------------------------------------------------------------
        */

        $permitidas = [
            'pdf',
            'jpg',
            'jpeg',
            'png',
            'webp',
            'gif',
            'txt',
            'csv',
        ];

        if (
            !in_array(
                $extension,
                $permitidas,
                true
            )
        ) {
            throw new InvalidArgumentException(
                'Tipo de archivo no permitido: .'
                . $extension
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MENSAJE UPLOAD
    |--------------------------------------------------------------------------
    */

    private function mensajeUploadError(
        int $codigo
    ): string {
        return match ($codigo) {

            UPLOAD_ERR_INI_SIZE,
            UPLOAD_ERR_FORM_SIZE =>
                'El archivo supera el tamaño permitido.',

            UPLOAD_ERR_PARTIAL =>
                'El archivo se cargó parcialmente.',

            UPLOAD_ERR_NO_FILE =>
                'No se seleccionó ningún archivo.',

            UPLOAD_ERR_NO_TMP_DIR =>
                'No existe el directorio temporal del servidor.',

            UPLOAD_ERR_CANT_WRITE =>
                'No se pudo escribir el archivo.',

            UPLOAD_ERR_EXTENSION =>
                'Una extensión del servidor bloqueó la carga.',

            default =>
                'Error desconocido al cargar el archivo.',
        };
    }
}