<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Engines;

use RuntimeException;
use Throwable;

final class TextExtractor
{
    /**
     * Extrae texto de un archivo físico.
     *
     * Soporta inicialmente:
     *
     * - TXT
     * - CSV
     * - PDF
     * - DOC
     * - DOCX
     * - JPG / JPEG
     * - PNG
     *
     * Para PDF/DOC/DOCX se utilizan herramientas externas
     * cuando están disponibles en el servidor.
     */
    public function extract(
        string $path,
        ?string $mimeType = null
    ): string {
        $path = trim($path);

        if ($path === '') {
            throw new RuntimeException(
                'No se indicó el archivo para extraer texto.'
            );
        }

        if (!is_file($path)) {
            throw new RuntimeException(
                'El archivo no existe: ' . $path
            );
        }

        if (!is_readable($path)) {
            throw new RuntimeException(
                'El archivo no se puede leer: ' . $path
            );
        }

        $extension = strtolower(
            pathinfo(
                $path,
                PATHINFO_EXTENSION
            )
        );

        $mimeType = $this->detectarMimeType(
            $path,
            $mimeType
        );

        /*
        |--------------------------------------------------------------------------
        | TEXTO PLANO
        |--------------------------------------------------------------------------
        */

        if (
            $extension === 'txt'
            ||
            $extension === 'csv'
            ||
            $mimeType === 'text/plain'
            ||
            $mimeType === 'text/csv'
        ) {
            return $this->extraerTextoPlano($path);
        }

        /*
        |--------------------------------------------------------------------------
        | PDF
        |--------------------------------------------------------------------------
        */

        if (
            $extension === 'pdf'
            ||
            $mimeType === 'application/pdf'
        ) {
            return $this->extraerPdf($path);
        }

        /*
        |--------------------------------------------------------------------------
        | DOCX
        |--------------------------------------------------------------------------
        */

        if (
            $extension === 'docx'
            ||
            $mimeType ===
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ) {
            return $this->extraerDocx($path);
        }

        /*
        |--------------------------------------------------------------------------
        | DOC
        |--------------------------------------------------------------------------
        */

        if (
            $extension === 'doc'
            ||
            $mimeType === 'application/msword'
        ) {
            return $this->extraerDoc($path);
        }

        /*
        |--------------------------------------------------------------------------
        | IMÁGENES
        |--------------------------------------------------------------------------
        */

        if (
            in_array(
                $extension,
                [
                    'jpg',
                    'jpeg',
                    'png',
                    'gif',
                    'webp',
                ],
                true
            )
            ||
            str_starts_with(
                strtolower($mimeType ?? ''),
                'image/'
            )
        ) {
            return $this->extraerImagen($path);
        }

        /*
        |--------------------------------------------------------------------------
        | FALLBACK
        |--------------------------------------------------------------------------
        */

        return '';
    }

    /*
    |--------------------------------------------------------------------------
    | TEXTO PLANO
    |--------------------------------------------------------------------------
    */

    private function extraerTextoPlano(
        string $path
    ): string {
        $contenido = @file_get_contents($path);

        if ($contenido === false) {
            throw new RuntimeException(
                'No se pudo leer el archivo de texto.'
            );
        }

        return $this->limpiarTexto(
            $contenido
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PDF
    |--------------------------------------------------------------------------
    */

    private function extraerPdf(
        string $path
    ): string {
        /*
         * En Ferozo puede no estar disponible pdftotext.
         *
         * Primero verificamos si existe.
         */

        $binario = $this->buscarBinario(
            [
                'pdftotext',
                '/usr/bin/pdftotext',
                '/usr/local/bin/pdftotext',
            ]
        );

        if ($binario === null) {
            /*
             * No hacemos fallar todo el procesamiento.
             *
             * El documento queda disponible para OCR/IA.
             */

            return '';
        }

        $temporal = tempnam(
            sys_get_temp_dir(),
            'docia_'
        );

        if ($temporal === false) {
            throw new RuntimeException(
                'No se pudo crear un archivo temporal.'
            );
        }

        try {

            $comando =
                escapeshellarg($binario)
                . ' -layout '
                . escapeshellarg($path)
                . ' '
                . escapeshellarg($temporal);

            $salida = [];
            $codigo = 0;

            exec(
                $comando . ' 2>&1',
                $salida,
                $codigo
            );

            if ($codigo !== 0) {
                return '';
            }

            $texto = @file_get_contents(
                $temporal
            );

            if ($texto === false) {
                return '';
            }

            return $this->limpiarTexto(
                $texto
            );

        } catch (Throwable) {

            return '';

        } finally {

            if (is_file($temporal)) {
                @unlink($temporal);
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DOCX
    |--------------------------------------------------------------------------
    */

    private function extraerDocx(
        string $path
    ): string {
        if (!class_exists(\ZipArchive::class)) {
            return '';
        }

        $zip = new \ZipArchive();

        if (
            $zip->open($path)
            !== true
        ) {
            return '';
        }

        try {

            $contenido =
                $zip->getFromName(
                    'word/document.xml'
                );

            if (
                !is_string($contenido)
                ||
                $contenido === ''
            ) {
                return '';
            }

            $contenido =
                preg_replace(
                    '/<w:tab[^>]*\/>/i',
                    ' ',
                    $contenido
                )
                ??
                $contenido;

            $contenido =
                preg_replace(
                    '/<\/w:p>/i',
                    "\n",
                    $contenido
                )
                ??
                $contenido;

            $contenido =
                preg_replace(
                    '/<[^>]+>/',
                    '',
                    $contenido
                )
                ??
                $contenido;

            $contenido =
                html_entity_decode(
                    $contenido,
                    ENT_QUOTES |
                    ENT_XML1,
                    'UTF-8'
                );

            return $this->limpiarTexto(
                $contenido
            );

        } finally {

            $zip->close();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DOC
    |--------------------------------------------------------------------------
    */

    private function extraerDoc(
        string $path
    ): string {
        /*
         * DOC antiguo requiere una herramienta externa.
         *
         * Intentamos antiword si está disponible.
         */

        $binario = $this->buscarBinario(
            [
                'antiword',
                '/usr/bin/antiword',
                '/usr/local/bin/antiword',
            ]
        );

        if ($binario === null) {
            return '';
        }

        try {

            $comando =
                escapeshellarg($binario)
                . ' '
                . escapeshellarg($path);

            $salida = [];
            $codigo = 0;

            exec(
                $comando . ' 2>&1',
                $salida,
                $codigo
            );

            if ($codigo !== 0) {
                return '';
            }

            return $this->limpiarTexto(
                implode(
                    "\n",
                    $salida
                )
            );

        } catch (Throwable) {

            return '';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | IMAGEN / OCR
    |--------------------------------------------------------------------------
    */

    private function extraerImagen(
        string $path
    ): string {
        /*
         * El OCR lo dejamos desacoplado.
         *
         * Si Tesseract está instalado,
         * intentamos utilizarlo.
         */

        $binario = $this->buscarBinario(
            [
                'tesseract',
                '/usr/bin/tesseract',
                '/usr/local/bin/tesseract',
            ]
        );

        if ($binario === null) {
            return '';
        }

        $baseTemporal = tempnam(
            sys_get_temp_dir(),
            'ocr_'
        );

        if ($baseTemporal === false) {
            return '';
        }

        /*
         * Tesseract agrega extensiones.
         */

        @unlink($baseTemporal);

        try {

            $comando =
                escapeshellarg($binario)
                . ' '
                . escapeshellarg($path)
                . ' '
                . escapeshellarg($baseTemporal)
                . ' -l spa';

            $salida = [];
            $codigo = 0;

            exec(
                $comando . ' 2>&1',
                $salida,
                $codigo
            );

            if ($codigo !== 0) {
                return '';
            }

            $archivoTexto =
                $baseTemporal . '.txt';

            if (
                !is_file(
                    $archivoTexto
                )
            ) {
                return '';
            }

            $texto =
                @file_get_contents(
                    $archivoTexto
                );

            if ($texto === false) {
                return '';
            }

            return $this->limpiarTexto(
                $texto
            );

        } catch (Throwable) {

            return '';

        } finally {

            $archivoTexto =
                $baseTemporal . '.txt';

            if (
                is_file(
                    $archivoTexto
                )
            ) {
                @unlink(
                    $archivoTexto
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DETECTAR MIME
    |--------------------------------------------------------------------------
    */

    private function detectarMimeType(
        string $path,
        ?string $mimeType
    ): ?string {
        if (
            is_string($mimeType)
            &&
            trim($mimeType) !== ''
        ) {
            return strtolower(
                trim($mimeType)
            );
        }

        if (
            class_exists(
                \finfo::class
            )
        ) {
            try {

                $finfo =
                    new \finfo(
                        FILEINFO_MIME_TYPE
                    );

                $mime =
                    $finfo->file(
                        $path
                    );

                if (
                    is_string($mime)
                    &&
                    $mime !== ''
                ) {
                    return strtolower(
                        $mime
                    );
                }

            } catch (Throwable) {
                // Fallback.
            }
        }

        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR BINARIO
    |--------------------------------------------------------------------------
    */

    private function buscarBinario(
        array $candidatos
    ): ?string {
        foreach (
            $candidatos as $candidato
        ) {

            $candidato =
                trim(
                    (string) $candidato
                );

            if ($candidato === '') {
                continue;
            }

            /*
             * Ruta absoluta.
             */

            if (
                str_contains(
                    $candidato,
                    DIRECTORY_SEPARATOR
                )
            ) {

                if (
                    is_file($candidato)
                    &&
                    is_executable($candidato)
                ) {
                    return $candidato;
                }

                continue;
            }

            /*
             * Buscar en PATH.
             */

            $which = [];

            $codigo = 0;

            @exec(
                'command -v '
                . escapeshellarg($candidato)
                . ' 2>/dev/null',
                $which,
                $codigo
            );

            if (
                $codigo === 0
                &&
                isset($which[0])
                &&
                is_string($which[0])
                &&
                trim($which[0]) !== ''
            ) {
                return trim(
                    $which[0]
                );
            }
        }

        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | LIMPIAR TEXTO
    |--------------------------------------------------------------------------
    */

    private function limpiarTexto(
        string $texto
    ): string {
        $texto =
            str_replace(
                [
                    "\r\n",
                    "\r",
                    "\t",
                ],
                [
                    "\n",
                    "\n",
                    ' ',
                ],
                $texto
            );

        /*
         * Eliminar espacios repetidos.
         */

        $texto =
            preg_replace(
                '/[ ]{2,}/u',
                ' ',
                $texto
            )
            ??
            $texto;

        /*
         * Eliminar demasiados saltos.
         */

        $texto =
            preg_replace(
                "/\n{3,}/u",
                "\n\n",
                $texto
            )
            ??
            $texto;

        return trim(
            $texto
        );
    }
}