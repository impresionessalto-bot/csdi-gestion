<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Providers;

final class LocalProvider implements ProviderInterface
{
    public function procesar(array $input): array
    {
        return [
            'success' => false,
            'procesado' => false,
            'proveedor' => $this->nombre(),
            'modelo' => $this->modelo(),
            'mensaje' => 'El proveedor local no tiene un motor IA configurado.',
            'data' => [],
        ];
    }

    public function nombre(): string { return 'local'; }
    public function modelo(): string { return 'local-rules'; }
    public function disponible(): bool { return true; }
}
