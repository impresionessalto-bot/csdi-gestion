<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Providers;

use RuntimeException;

/**
 * OCR HTTP para imágenes y PDFs sin ejecutar binarios del sistema.
 *
 * Requiere cURL habilitado en PHP. La API key puede configurarse con:
 * DOCUMENTOS_IA_OCR_API_KEY
 *
 * Se utiliza OCR.Space como proveedor desacoplado. Para producción se
 * recomienda configurar una clave propia y/o reemplazar este Provider.
 */
final class OcrSpaceProvider implements ProviderInterface
{
    private const ENDPOINT = 'https://api.ocr.space/parse/image';

    public function procesar(array $input): array
    {
        $path = trim((string) ($input['path'] ?? ''));
        $mime = trim((string) ($input['mime_type'] ?? ''));

        if ($path === '' || !is_file($path) || !is_readable($path)) {
            return $this->error('El archivo para OCR no existe o no se puede leer.');
        }

        if (!function_exists('curl_init')) {
            return $this->error('cURL no está disponible en PHP. No se puede ejecutar OCR remoto.');
        }

        $apiKey = trim((string) ($_ENV['DOCUMENTOS_IA_OCR_API_KEY'] ?? getenv('DOCUMENTOS_IA_OCR_API_KEY') ?: 'helloworld'));
        $endpoint = trim((string) ($_ENV['DOCUMENTOS_IA_OCR_ENDPOINT'] ?? getenv('DOCUMENTOS_IA_OCR_ENDPOINT') ?: self::ENDPOINT));

        $mime = $mime !== '' ? $mime : $this->mime($path);
        $language = strtoupper(trim((string) ($input['language'] ?? 'spa')));
        if ($language === '') {
            $language = 'spa';
        }

        $curl = curl_init();
        if ($curl === false) {
            return $this->error('No se pudo inicializar cURL.');
        }

        $post = [
            'apikey' => $apiKey,
            'language' => $language,
            'isOverlayRequired' => 'false',
            'OCREngine' => '2',
            'isTable' => 'true',
            'file' => new \CURLFile($path, $mime !== '' ? $mime : 'application/octet-stream', basename($path)),
        ];

        curl_setopt_array($curl, [
            CURLOPT_URL => $endpoint,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $post,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 90,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);

        $response = curl_exec($curl);
        $curlError = curl_error($curl);
        $httpCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if (!is_string($response) || $response === '') {
            return $this->error('El proveedor OCR no devolvió respuesta.' . ($curlError !== '' ? ' ' . $curlError : ''));
        }

        $json = json_decode($response, true);
        if (!is_array($json)) {
            return $this->error('El proveedor OCR devolvió una respuesta inválida.', $httpCode);
        }

        if (($json['IsErroredOnProcessing'] ?? false) === true) {
            $mensaje = $json['ErrorMessage'] ?? $json['ErrorDetails'] ?? 'Error del proveedor OCR.';
            if (is_array($mensaje)) {
                $mensaje = implode(' ', array_map('strval', $mensaje));
            }
            return $this->error((string) $mensaje, $httpCode);
        }

        $texto = '';
        $results = $json['ParsedResults'] ?? [];
        if (is_array($results)) {
            $partes = [];
            foreach ($results as $result) {
                if (!is_array($result)) {
                    continue;
                }
                $parsed = $result['ParsedText'] ?? '';
                if (is_string($parsed) && trim($parsed) !== '') {
                    $partes[] = trim($parsed);
                }
            }
            $texto = trim(implode("\n\n", $partes));
        }

        if ($texto === '') {
            return [
                'success' => true,
                'procesado' => false,
                'proveedor' => $this->nombre(),
                'modelo' => $this->modelo(),
                'mensaje' => 'OCR ejecutado pero no se detectó texto.',
                'data' => ['texto' => '', 'http_code' => $httpCode],
            ];
        }

        return [
            'success' => true,
            'procesado' => true,
            'proveedor' => $this->nombre(),
            'modelo' => $this->modelo(),
            'mensaje' => 'OCR completado correctamente.',
            'data' => [
                'texto' => $this->limpiar($texto),
                'http_code' => $httpCode,
            ],
        ];
    }

    public function nombre(): string
    {
        return 'ocr.space';
    }

    public function modelo(): string
    {
        return 'OCR.space-Engine-2';
    }

    public function disponible(): bool
    {
        return function_exists('curl_init');
    }

    private function error(string $mensaje, int $httpCode = 0): array
    {
        return [
            'success' => false,
            'procesado' => false,
            'proveedor' => $this->nombre(),
            'modelo' => $this->modelo(),
            'mensaje' => $mensaje,
            'data' => ['texto' => '', 'http_code' => $httpCode],
        ];
    }

    private function mime(string $path): string
    {
        if (class_exists('finfo')) {
            try {
                $finfo = new \finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($path);
                if (is_string($mime) && $mime !== '') {
                    return $mime;
                }
            } catch (\Throwable) {
            }
        }
        return 'application/octet-stream';
    }

    private function limpiar(string $texto): string
    {
        $texto = str_replace(["\r\n", "\r", "\t"], ["\n", "\n", ' '], $texto);
        $texto = preg_replace('/[ ]{2,}/u', ' ', $texto) ?? $texto;
        $texto = preg_replace("/\n{3,}/u", "\n\n", $texto) ?? $texto;
        return trim($texto);
    }
}
