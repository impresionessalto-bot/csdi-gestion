<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Providers;

final class NullProvider implements ProviderInterface
{
    public function procesar(array $input): array
    {
        return [
            'success' => false,
            'procesado' => false,
            'proveedor' => $this->nombre(),
            'modelo' => $this->modelo(),
            'mensaje' => 'No hay proveedor IA configurado.',
            'data' => [],
        ];
    }

    public function nombre(): string
    {
        return 'null';
    }

    public function modelo(): string
    {
        return 'none';
    }

    public function disponible(): bool
    {
        return false;
    }
}