<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Providers;

use Throwable;

interface ProviderInterface
{
    /**
     * Procesa un documento.
     *
     * @param array $input
     * @return array
     */
    public function procesar(array $input): array;

    /**
     * Nombre identificador del proveedor.
     */
    public function nombre(): string;

    /**
     * Modelo utilizado.
     */
    public function modelo(): string;

    /**
     * Indica si el proveedor está disponible.
     */
    public function disponible(): bool;
}