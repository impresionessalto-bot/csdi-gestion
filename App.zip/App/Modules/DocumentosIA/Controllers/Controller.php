<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Controllers;

use App\Core\BaseController;
use App\Modules\DocumentosIA\Services\Service;
use InvalidArgumentException;
use Throwable;

final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        try {

            $data = $this->service->dashboard();

            $resumen = is_array($data['resumen'] ?? null)
                ? $data['resumen']
                : [];

            $documentos = is_array($data['documentos'] ?? null)
                ? $data['documentos']
                : [];

            $procesos = is_array($data['procesos'] ?? null)
                ? $data['procesos']
                : [];

            $this->moduleView(
                'DocumentosIA',
                'index',
                [
                    'resumen'    => $resumen,
                    'documentos' => $documentos,
                    'procesos'   => $procesos,
                    'error'      => null,
                    'mensaje'    => null,
                ]
            );

        } catch (Throwable $e) {

            $this->moduleView(
                'DocumentosIA',
                'index',
                [
                    'resumen'    => [],
                    'documentos' => [],
                    'procesos'   => [],
                    'error'      => $e->getMessage(),
                    'mensaje'    => null,
                ]
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | FORMULARIO
    |--------------------------------------------------------------------------
    */

    public function crear(): void
    {
        $this->moduleView(
            'DocumentosIA',
            'form',
            [
                'error'     => null,
                'success'   => null,
                'resultado' => null,
            ]
        );
    }


    /*
    |--------------------------------------------------------------------------
    | SUBIR DOCUMENTO
    |--------------------------------------------------------------------------
    */

    public function subir(): void
    {
        try {

            $method = strtoupper(
                (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')
            );

            if ($method !== 'POST') {
                $this->redirect('/documentos-ia/subir');
            }

            $archivo = $_FILES['archivo'] ?? null;

            if (!is_array($archivo)) {
                throw new InvalidArgumentException(
                    'No se recibió ningún archivo.'
                );
            }

            $codigoError = (int) (
                $archivo['error'] ?? UPLOAD_ERR_NO_FILE
            );

            if ($codigoError !== UPLOAD_ERR_OK) {
                throw new InvalidArgumentException(
                    $this->mensajeUploadError($codigoError)
                );
            }

            $tmpName = trim(
                (string) (
                    $archivo['tmp_name'] ?? ''
                )
            );

            $nombreArchivo = trim(
                (string) (
                    $archivo['name'] ?? ''
                )
            );

            $tamano = (int) (
                $archivo['size'] ?? 0
            );

            if ($tmpName === '') {
                throw new InvalidArgumentException(
                    'No se encontró el archivo temporal.'
                );
            }

            if (!is_uploaded_file($tmpName)) {
                throw new InvalidArgumentException(
                    'El archivo recibido no es válido.'
                );
            }

            if ($nombreArchivo === '') {
                throw new InvalidArgumentException(
                    'El archivo no tiene nombre.'
                );
            }

            if ($tamano <= 0) {
                throw new InvalidArgumentException(
                    'El archivo está vacío.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | DATOS OPCIONALES
            |--------------------------------------------------------------------------
            */

            $tipoDocumento = strtoupper(
                trim(
                    (string) (
                        $_POST['tipo_documento'] ?? 'OTRO'
                    )
                )
            );

            if ($tipoDocumento === '') {
                $tipoDocumento = 'OTRO';
            }

            $origen = strtoupper(
                trim(
                    (string) (
                        $_POST['origen'] ?? 'MANUAL'
                    )
                )
            );

            if ($origen === '') {
                $origen = 'MANUAL';
            }

            $observacion = trim(
                (string) (
                    $_POST['observacion'] ?? ''
                )
            );

            /*
            |--------------------------------------------------------------------------
            | USUARIO
            |--------------------------------------------------------------------------
            */

            $usuarioId = null;

            if (
                isset($_SESSION['user'])
                &&
                is_array($_SESSION['user'])
                &&
                isset($_SESSION['user']['id'])
                &&
                is_numeric($_SESSION['user']['id'])
            ) {
                $usuarioId = (int) $_SESSION['user']['id'];
            }

            /*
            |--------------------------------------------------------------------------
            | SERVICE
            |--------------------------------------------------------------------------
            */

            $resultado = $this->service->subir(
                $archivo,
                $tipoDocumento,
                $origen,
                $usuarioId,
                $observacion
            );

            /*
            |--------------------------------------------------------------------------
            | AJAX
            |--------------------------------------------------------------------------
            */

            if ($this->esAjax()) {

                $this->json(
                    [
                        'success' => true,
                        'message' => 'Documento cargado correctamente.',
                        'data'    => $resultado,
                    ]
                );
            }

            /*
            |--------------------------------------------------------------------------
            | RESPUESTA NORMAL
            |--------------------------------------------------------------------------
            */

            $this->moduleView(
                'DocumentosIA',
                'form',
                [
                    'error'     => null,
                    'success'   => 'Documento cargado correctamente.',
                    'resultado' => $resultado,
                ]
            );

        } catch (Throwable $e) {

            if ($this->esAjax()) {

                $this->json(
                    [
                        'success' => false,
                        'message' => $e->getMessage(),
                        'errors'  => [],
                    ],
                    422
                );
            }

            $this->moduleView(
                'DocumentosIA',
                'form',
                [
                    'error'     => $e->getMessage(),
                    'success'   => null,
                    'resultado' => null,
                ]
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | VER DOCUMENTO
    |--------------------------------------------------------------------------
    */

    public function ver(int $id): void
    {
        try {

            if ($id <= 0) {
                throw new InvalidArgumentException(
                    'ID de documento inválido.'
                );
            }

            $documento = $this->service->obtener($id);

            if (!$documento) {

                $this->moduleView(
                    'DocumentosIA',
                    'index',
                    [
                        'resumen'    => [],
                        'documentos' => [],
                        'procesos'   => [],
                        'error'      => 'El documento no existe.',
                        'mensaje'    => null,
                    ]
                );

                return;
            }

            $this->moduleView(
                'DocumentosIA',
                'ver',
                [
                    'documento' => $documento,
                    'error'     => null,
                    'mensaje'   => null,
                ]
            );

        } catch (Throwable $e) {

            $this->moduleView(
                'DocumentosIA',
                'index',
                [
                    'resumen'    => [],
                    'documentos' => [],
                    'procesos'   => [],
                    'error'      => $e->getMessage(),
                    'mensaje'    => null,
                ]
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PROCESAR DOCUMENTO
    |--------------------------------------------------------------------------
    */

    public function procesar(int $id): void
    {
        try {

            if ($id <= 0) {
                throw new InvalidArgumentException(
                    'ID de documento inválido.'
                );
            }

            $resultado = $this->service->procesar($id);

            $this->json(
                [
                    'success' => true,
                    'message' => 'Documento procesado correctamente.',
                    'data'    => $resultado,
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' => false,
                    'message' => $e->getMessage(),
                    'errors'  => [],
                ],
                422
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PROCESAR PENDIENTES
    |--------------------------------------------------------------------------
    */

    public function procesarPendientes(): void
    {
        try {

            $resultado =
                $this->service->procesarPendientes();

            $this->json(
                [
                    'success' => true,
                    'message' => 'Documentos pendientes procesados.',
                    'data'    => $resultado,
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' => false,
                    'message' => $e->getMessage(),
                    'errors'  => [],
                ],
                422
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CONFIRMAR / CORREGIR
    |--------------------------------------------------------------------------
    */

    public function confirmar(int $id): void
    {
        try {
            if ($id <= 0) {
                throw new InvalidArgumentException('ID de documento inválido.');
            }

            $payload = $_POST['datos'] ?? [];
            if (is_string($payload)) {
                $decoded = json_decode($payload, true);
                $payload = is_array($decoded) ? $decoded : [];
            }
            if (!is_array($payload)) {
                $payload = [];
            }

            $resultado = $this->service->confirmar($id, $payload);

            $this->json([
                'success' => true,
                'message' => 'Documento confirmado correctamente.',
                'data' => $resultado,
            ]);
        } catch (Throwable $e) {
            $this->json([
                'success' => false,
                'message' => $e->getMessage(),
                'errors' => [],
            ], 422);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(int $id): void
    {
        try {

            if ($id <= 0) {
                throw new InvalidArgumentException(
                    'ID de documento inválido.'
                );
            }

            $resultado =
                $this->service->eliminar($id);

            $this->json(
                [
                    'success' => true,
                    'message' => 'Documento eliminado correctamente.',
                    'data'    => $resultado,
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' => false,
                    'message' => $e->getMessage(),
                    'errors'  => [],
                ],
                422
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | AJAX
    |--------------------------------------------------------------------------
    */

    private function esAjax(): bool
    {
        return isset(
            $_SERVER['HTTP_X_REQUESTED_WITH']
        )
        &&
        strtolower(
            (string) $_SERVER['HTTP_X_REQUESTED_WITH']
        ) === 'xmlhttprequest';
    }


    /*
    |--------------------------------------------------------------------------
    | ERRORES DE UPLOAD
    |--------------------------------------------------------------------------
    */

    private function mensajeUploadError(
        int $codigo
    ): string {

        return match ($codigo) {

            UPLOAD_ERR_INI_SIZE,
            UPLOAD_ERR_FORM_SIZE =>
                'El archivo supera el tamaño permitido.',

            UPLOAD_ERR_PARTIAL =>
                'El archivo se cargó parcialmente.',

            UPLOAD_ERR_NO_FILE =>
                'No se seleccionó ningún archivo.',

            UPLOAD_ERR_NO_TMP_DIR =>
                'No existe el directorio temporal del servidor.',

            UPLOAD_ERR_CANT_WRITE =>
                'No se pudo escribir el archivo.',

            UPLOAD_ERR_EXTENSION =>
                'Una extensión del servidor bloqueó la carga.',

            default =>
                'Error desconocido al cargar el archivo.',
        };
    }
}
