<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Config;

use App\Core\Router;
use App\Modules\DocumentosIA\Controllers\Controller;

Router::group(
    '/documentos-ia',
    [
        'auth'
    ],
    function (): void {

        /*
        |--------------------------------------------------------------------------
        | DASHBOARD
        |--------------------------------------------------------------------------
        */

        Router::get(
            '',
            [
                Controller::class,
                'index'
            ]
        );

        Router::get(
            '/',
            [
                Controller::class,
                'index'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | CARGA
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/subir',
            [
                Controller::class,
                'crear'
            ]
        );

        Router::post(
            '/subir',
            [
                Controller::class,
                'subir'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | DOCUMENTO
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/ver/{id}',
            [
                Controller::class,
                'ver'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | PROCESAR
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/procesar/{id}',
            [
                Controller::class,
                'procesar'
            ]
        );

        Router::post(
            '/procesar-pendientes',
            [
                Controller::class,
                'procesarPendientes'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | CONFIRMAR / CORREGIR
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/confirmar/{id}',
            [
                Controller::class,
                'confirmar'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | ELIMINAR
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/eliminar/{id}',
            [
                Controller::class,
                'eliminar'
            ]
        );
    }
);