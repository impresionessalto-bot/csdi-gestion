<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Engines;

final class Validator
{
    public function validate(
        array $resultado
    ): array {
        $errores = [];
        $advertencias = [];

        $tipo =
            strtoupper(
                (string) (
                    $resultado['tipo_documento']
                    ?? 'OTRO'
                )
            );

        if ($tipo === 'FACTURA') {

            $importes =
                is_array(
                    $resultado['importes']
                    ?? null
                )
                    ? $resultado['importes']
                    : [];

            $subtotal =
                $importes['subtotal']
                ?? null;

            $iva =
                $importes['iva']
                ?? null;

            $total =
                $importes['total']
                ?? null;

            if (
                $subtotal !== null
                &&
                $iva !== null
                &&
                $total !== null
            ) {
                $esperado =
                    round(
                        (float) $subtotal
                        +
                        (float) $iva,
                        2
                    );

                if (
                    abs(
                        $esperado
                        -
                        (float) $total
                    ) > 0.05
                ) {
                    $errores[] = [
                        'campo' =>
                            'total',

                        'mensaje' =>
                            'Los importes de la factura no coinciden.',
                    ];
                }
            } else {
                $advertencias[] = [
                    'campo' =>
                        'importes',

                    'mensaje' =>
                        'No se pudieron validar todos los importes.',
                ];
            }
        }

        /*
         * CUIT
         */
        $cuit =
            $resultado['cuit']
            ?? null;

        if (
            $cuit !== null
            &&
            !preg_match(
                '/^\d{2}-\d{8}-\d$/',
                (string) $cuit
            )
        ) {
            $advertencias[] = [
                'campo' =>
                    'cuit',

                'mensaje' =>
                    'El CUIT extraído no tiene un formato válido.',
            ];
        }

        /*
         * Fecha
         */
        $fecha =
            $resultado['fecha']
            ?? null;

        if ($fecha !== null) {

            $fechaValida =
                \DateTime::createFromFormat(
                    'Y-m-d',
                    (string) $fecha
                );

            if (
                !$fechaValida
                ||
                $fechaValida->format('Y-m-d')
                !==
                $fecha
            ) {
                $advertencias[] = [
                    'campo' =>
                        'fecha',

                    'mensaje' =>
                        'La fecha extraída no es válida.',
                ];
            }
        }

        return [
            'valido' =>
                count($errores) === 0,

            'errores' =>
                $errores,

            'advertencias' =>
                $advertencias,
        ];
    }
}