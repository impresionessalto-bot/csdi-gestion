<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Services;

use RuntimeException;

final class Storage
{
    /*
    |--------------------------------------------------------------------------
    | CONFIGURACIÓN
    |--------------------------------------------------------------------------
    */

    private string $basePath;

    private string $relativePath;

    public function __construct()
    {
        /*
         * BASE_PATH ya debería estar definido por el bootstrap
         * de la aplicación.
         */

        if (
            !defined('BASE_PATH')
        ) {
            throw new RuntimeException(
                'BASE_PATH no está definido.'
            );
        }

        /*
         * Directorio físico:
         *
         * /tu-proyecto/storage/documentos_ia
         */

        $this->basePath =
            rtrim(
                BASE_PATH,
                DIRECTORY_SEPARATOR
            )
            . DIRECTORY_SEPARATOR
            . 'storage'
            . DIRECTORY_SEPARATOR
            . 'documentos_ia';

        /*
         * Ruta relativa que se guarda en la BD.
         */

        $this->relativePath =
            'storage/documentos_ia';
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR UPLOAD
    |--------------------------------------------------------------------------
    */

    public function guardar(
        array $archivo
    ): array {

        $tmpName = trim(
            (string) (
                $archivo['tmp_name'] ?? ''
            )
        );

        $nombreOriginal = trim(
            (string) (
                $archivo['name'] ?? ''
            )
        );

        $tamano = (int) (
            $archivo['size'] ?? 0
        );

        if ($tmpName === '') {

            throw new RuntimeException(
                'No se recibió el archivo temporal.'
            );
        }

        if (!is_file($tmpName)) {

            throw new RuntimeException(
                'El archivo temporal no existe.'
            );
        }

        if (!is_readable($tmpName)) {

            throw new RuntimeException(
                'El archivo temporal no se puede leer.'
            );
        }

        if ($nombreOriginal === '') {

            throw new RuntimeException(
                'El archivo no tiene nombre.'
            );
        }

        if ($tamano <= 0) {

            throw new RuntimeException(
                'El archivo está vacío.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | EXTENSIÓN
        |--------------------------------------------------------------------------
        */

        $extension =
            strtolower(
                pathinfo(
                    $nombreOriginal,
                    PATHINFO_EXTENSION
                )
            );

        if ($extension === '') {

            throw new RuntimeException(
                'El archivo no tiene extensión.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | DIRECTORIO
        |--------------------------------------------------------------------------
        */

        $directorio = $this->crearDirectorio();

        /*
        |--------------------------------------------------------------------------
        | NOMBRE ÚNICO
        |--------------------------------------------------------------------------
        */

        $nombreArchivo =
            $this->generarNombre(
                $extension
            );

        $destino =
            $directorio
            . DIRECTORY_SEPARATOR
            . $nombreArchivo;

        /*
        |--------------------------------------------------------------------------
        | MOVER ARCHIVO
        |--------------------------------------------------------------------------
        */

        $movido = false;

        /*
         * Primero intentamos move_uploaded_file().
         */

        if (
            is_uploaded_file(
                $tmpName
            )
        ) {

            $movido =
                move_uploaded_file(
                    $tmpName,
                    $destino
                );
        }

        /*
         * En algunos flujos internos puede que el archivo
         * no sea considerado upload HTTP.
         */

        if (!$movido) {

            $movido =
                @rename(
                    $tmpName,
                    $destino
                );
        }

        /*
         * Último recurso: copiar.
         */

        if (!$movido) {

            $movido =
                @copy(
                    $tmpName,
                    $destino
                );
        }

        if (!$movido) {

            throw new RuntimeException(
                'No se pudo guardar el archivo en: '
                . $destino
            );
        }

        /*
        |--------------------------------------------------------------------------
        | PERMISOS
        |--------------------------------------------------------------------------
        */

        @chmod(
            $destino,
            0644
        );

        /*
        |--------------------------------------------------------------------------
        | RUTA RELATIVA
        |--------------------------------------------------------------------------
        */

        $relative =
            $this->relativePath
            . '/'
            . date('Y')
            . '/'
            . date('m')
            . '/'
            . $nombreArchivo;

        /*
        |--------------------------------------------------------------------------
        | MIME
        |--------------------------------------------------------------------------
        */

        $mimeType =
            $this->detectarMimeType(
                $destino
            );

        /*
        |--------------------------------------------------------------------------
        | RESULTADO
        |--------------------------------------------------------------------------
        */

        return [
            'nombre_archivo' =>
                $nombreOriginal,

            'archivo_path' =>
                $relative,

            'mime_type' =>
                $mimeType,

            'extension' =>
                $extension,

            'tamano_bytes' =>
                filesize($destino)
                ?: $tamano,

            'archivo_fisico' =>
                $destino,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | DIRECTORIO
    |--------------------------------------------------------------------------
    */

    private function crearDirectorio(): string
    {
        $anio =
            date('Y');

        $mes =
            date('m');

        $directorio =
            $this->basePath
            . DIRECTORY_SEPARATOR
            . $anio
            . DIRECTORY_SEPARATOR
            . $mes;

        if (
            is_dir(
                $directorio
            )
        ) {

            if (
                !is_writable(
                    $directorio
                )
            ) {

                throw new RuntimeException(
                    'El directorio de almacenamiento no tiene permisos de escritura.'
                );
            }

            return $directorio;
        }

        if (
            !mkdir(
                $directorio,
                0755,
                true
            )
        ) {

            throw new RuntimeException(
                'No se pudo crear el directorio de almacenamiento: '
                . $directorio
            );
        }

        @chmod(
            $directorio,
            0755
        );

        return $directorio;
    }

    /*
    |--------------------------------------------------------------------------
    | NOMBRE ÚNICO
    |--------------------------------------------------------------------------
    */

    private function generarNombre(
        string $extension
    ): string {

        $extension =
            strtolower(
                trim(
                    $extension
                )
            );

        /*
         * 32 caracteres hexadecimales.
         */

        $hash =
            bin2hex(
                random_bytes(
                    16
                )
            );

        return $hash
            . '.'
            . $extension;
    }

    /*
    |--------------------------------------------------------------------------
    | MIME
    |--------------------------------------------------------------------------
    */

    private function detectarMimeType(
        string $path
    ): ?string {

        if (
            !is_file(
                $path
            )
        ) {

            return null;
        }

        /*
        |--------------------------------------------------------------------------
        | finfo
        |--------------------------------------------------------------------------
        */

        if (
            class_exists(
                \finfo::class
            )
        ) {

            try {

                $finfo =
                    new \finfo(
                        FILEINFO_MIME_TYPE
                    );

                $mime =
                    $finfo->file(
                        $path
                    );

                if (
                    is_string($mime)
                    &&
                    $mime !== ''
                ) {

                    return strtolower(
                        $mime
                    );
                }

            } catch (\Throwable) {
                // Continuamos con la detección por extensión.
            }
        }

        /*
        |--------------------------------------------------------------------------
        | FALLBACK
        |--------------------------------------------------------------------------
        */

        $extension =
            strtolower(
                pathinfo(
                    $path,
                    PATHINFO_EXTENSION
                )
            );

        return match ($extension) {

            'pdf' =>
                'application/pdf',

            'jpg',
            'jpeg' =>
                'image/jpeg',

            'png' =>
                'image/png',

            'gif' =>
                'image/gif',

            'webp' =>
                'image/webp',

            'txt' =>
                'text/plain',

            'csv' =>
                'text/csv',

            default =>
                null,
        };
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER RUTA FÍSICA
    |--------------------------------------------------------------------------
    */

    public function path(
        string $relativePath
    ): string {

        $relativePath =
            str_replace(
                ['/', '\\'],
                DIRECTORY_SEPARATOR,
                trim(
                    $relativePath
                )
            );

        /*
         * Evitamos traversal.
         */

        if (
            $relativePath === ''
            ||
            str_contains(
                $relativePath,
                '..'
            )
        ) {

            throw new RuntimeException(
                'Ruta de archivo inválida.'
            );
        }

        $prefix =
            str_replace(
                ['/', '\\'],
                DIRECTORY_SEPARATOR,
                $this->relativePath
            )
            . DIRECTORY_SEPARATOR;

        if (
            !str_starts_with(
                $relativePath,
                $prefix
            )
        ) {

            throw new RuntimeException(
                'La ruta no pertenece al almacenamiento de Documentos IA.'
            );
        }

        return
            rtrim(
                BASE_PATH,
                DIRECTORY_SEPARATOR
            )
            . DIRECTORY_SEPARATOR
            . $relativePath;
    }

    /*
    |--------------------------------------------------------------------------
    | EXISTE
    |--------------------------------------------------------------------------
    */

    public function existe(
        string $relativePath
    ): bool {

        try {

            $path =
                $this->path(
                    $relativePath
                );

            return is_file(
                $path
            );

        } catch (\Throwable) {

            return false;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(
        string $relativePath
    ): bool {

        if (
            trim(
                $relativePath
            ) === ''
        ) {

            return false;
        }

        try {

            $path =
                $this->path(
                    $relativePath
                );

            if (
                !is_file(
                    $path
                )
            ) {

                return true;
            }

            return @unlink(
                $path
            );

        } catch (\Throwable) {

            return false;
        }
    }
}