<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Engines;

use RuntimeException;
use Throwable;

/**
 * Extractor de texto 100% compatible con hosting restringido.
 *
 * IMPORTANTE:
 * - No utiliza exec(), shell_exec(), system(), passthru() ni escapeshellarg().
 * - PDF: utiliza Smalot\PdfParser si está instalado.
 * - DOCX: extrae document.xml mediante ZipArchive/XML.
 * - DOC binario e imágenes: devuelven texto vacío; el OCR/IA se delega a Providers.
 */
final class TextExtractor
{
    public function extract(string $path, ?string $mimeType = null): string
    {
        $path = trim($path);

        if ($path === '') {
            throw new RuntimeException('No se indicó el archivo para extraer texto.');
        }

        if (!is_file($path)) {
            throw new RuntimeException('El archivo no existe: ' . $path);
        }

        if (!is_readable($path)) {
            throw new RuntimeException('El archivo no se puede leer: ' . $path);
        }

        $extension = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
        $mimeType = $this->detectarMimeType($path, $mimeType);

        if (
            in_array($extension, ['txt', 'csv'], true)
            || $mimeType === 'text/plain'
            || $mimeType === 'text/csv'
        ) {
            return $this->extraerTextoPlano($path);
        }

        if ($extension === 'pdf' || $mimeType === 'application/pdf') {
            return $this->extraerPdf($path);
        }

        if (
            $extension === 'docx'
            || $mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ) {
            return $this->extraerDocx($path);
        }

        // DOC antiguo requiere un parser externo. No ejecutamos binarios del sistema.
        if ($extension === 'doc' || $mimeType === 'application/msword') {
            return '';
        }

        // Imágenes: OCR queda desacoplado y será responsabilidad de Providers.
        if (
            in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)
            || str_starts_with(strtolower($mimeType ?? ''), 'image/')
        ) {
            return '';
        }

        return '';
    }

    private function extraerTextoPlano(string $path): string
    {
        $contenido = @file_get_contents($path);

        if ($contenido === false) {
            throw new RuntimeException('No se pudo leer el archivo de texto.');
        }

        return $this->limpiarTexto($contenido);
    }

    private function extraerPdf(string $path): string
    {
        // Parser PHP puro, si Composer lo proporciona.
        if (class_exists('Smalot\\PdfParser\\Parser')) {
            try {
                $parser = new \Smalot\PdfParser\Parser();
                $pdf = $parser->parseFile($path);
                $texto = $pdf->getText();

                if (is_string($texto) && trim($texto) !== '') {
                    return $this->limpiarTexto($texto);
                }
            } catch (Throwable) {
                // Continuamos con fallback vacío.
            }
        }

        return '';
    }

    private function extraerDocx(string $path): string
    {
        if (!class_exists('ZipArchive')) {
            return '';
        }

        $zip = new \ZipArchive();
        $resultado = $zip->open($path);

        if ($resultado !== true) {
            return '';
        }

        try {
            $xml = $zip->getFromName('word/document.xml');

            if (!is_string($xml) || trim($xml) === '') {
                return '';
            }

            // WordprocessingML: cada <w:t> contiene texto y <w:p> representa párrafo.
            $xml = preg_replace('/<w:tab\s*\/?\s*>/i', ' ', $xml) ?? $xml;
            $xml = preg_replace('/<w:br\s*\/?\s*>/i', "\n", $xml) ?? $xml;
            $xml = preg_replace('/<w:p(?:\s[^>]*)?>/i', "\n", $xml) ?? $xml;

            $texto = strip_tags($xml);
            $texto = html_entity_decode($texto, ENT_QUOTES | ENT_XML1, 'UTF-8');

            return $this->limpiarTexto($texto);
        } catch (Throwable) {
            return '';
        } finally {
            $zip->close();
        }
    }

    private function detectarMimeType(string $path, ?string $mimeType): ?string
    {
        if (is_string($mimeType) && trim($mimeType) !== '') {
            return strtolower(trim($mimeType));
        }

        if (class_exists('finfo')) {
            try {
                $finfo = new \finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($path);

                if (is_string($mime) && $mime !== '') {
                    return strtolower($mime);
                }
            } catch (Throwable) {
                // Fallback por extensión.
            }
        }

        return null;
    }

    private function limpiarTexto(string $texto): string
    {
        $texto = str_replace(["\r\n", "\r", "\t"], ["\n", "\n", ' '], $texto);
        $texto = preg_replace('/[ ]{2,}/u', ' ', $texto) ?? $texto;
        $texto = preg_replace("/\n{3,}/u", "\n\n", $texto) ?? $texto;

        return trim($texto);
    }
}
