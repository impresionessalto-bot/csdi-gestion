<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Engines;

use PDO;
use Throwable;

final class EntityResolver
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    public function resolve(
        array $datos,
        string $tipoDocumento
    ): array {
        $cuit = $this->normalizarCuit(
            $datos['cuit'] ?? null
        );

        $razonSocial =
            trim(
                (string) (
                    $datos['razon_social']
                    ?? ''
                )
            );

        $cliente =
            trim(
                (string) (
                    $datos['cliente']
                    ?? ''
                )
            );

        $proveedor =
            trim(
                (string) (
                    $datos['proveedor']
                    ?? ''
                )
            );

        $resultado = [
            'entidad_tipo' => null,
            'entidad_id' => null,
            'entidad_nombre' => null,
            'confianza' => 0,
            'metodo' => null,
        ];

        if (
            $this->esCompra(
                $tipoDocumento
            )
        ) {
            $resultado = $this->buscarProveedor(
                $cuit,
                $proveedor !== ''
                    ? $proveedor
                    : $razonSocial
            );

            if ($resultado['entidad_id'] !== null) {
                $resultado['entidad_tipo'] = 'PROVEEDOR';
                return $resultado;
            }
        }

        if (
            $this->esVenta(
                $tipoDocumento
            )
        ) {
            $resultado = $this->buscarCliente(
                $cuit,
                $cliente !== ''
                    ? $cliente
                    : $razonSocial
            );

            if ($resultado['entidad_id'] !== null) {
                $resultado['entidad_tipo'] = 'CLIENTE';
                return $resultado;
            }
        }

        if (
            strtoupper(
                $tipoDocumento
            ) === 'INFORME_TECNICO'
        ) {
            $resultado = $this->buscarCliente(
                $cuit,
                $cliente !== ''
                    ? $cliente
                    : $razonSocial
            );

            if ($resultado['entidad_id'] !== null) {
                $resultado['entidad_tipo'] = 'CLIENTE';
                return $resultado;
            }
        }

        return $resultado;
    }

    private function buscarProveedor(
        ?string $cuit,
        string $nombre
    ): array {
        try {
            if (
                !$this->tablaExiste(
                    'proveedores'
                )
            ) {
                return $this->resultadoVacio();
            }

            $columnas =
                $this->columnas(
                    'proveedores'
                );

            $idColumn =
                $this->buscarColumna(
                    $columnas,
                    [
                        'id',
                        'idproveedor',
                        'proveedor_id'
                    ]
                );

            $cuitColumn =
                $this->buscarColumna(
                    $columnas,
                    [
                        'cuit',
                        'cuit_cuil',
                        'cuitcuil',
                        'documento'
                    ]
                );

            $nombreColumn =
                $this->buscarColumna(
                    $columnas,
                    [
                        'nombre',
                        'razon_social',
                        'razonsocial',
                        'denominacion',
                        'proveedor'
                    ]
                );

            if ($idColumn === null) {
                return $this->resultadoVacio();
            }

            if (
                $cuit !== null
                && $cuitColumn !== null
            ) {
                $sql =
                    'SELECT * FROM proveedores ' .
                    'WHERE REPLACE(REPLACE(REPLACE(`' .
                    $cuitColumn .
                    '`, "-", ""), " ", ""), ".", "") = :cuit ' .
                    'LIMIT 1';

                $stmt = $this->db->prepare(
                    $sql
                );

                $stmt->execute([
                    'cuit' => str_replace(
                        '-',
                        '',
                        $cuit
                    ),
                ]);

                $fila = $stmt->fetch(
                    PDO::FETCH_ASSOC
                );

                if (is_array($fila)) {
                    return $this->resultado(
                        $fila,
                        $idColumn,
                        $nombreColumn,
                        100,
                        'CUIT'
                    );
                }
            }

            if (
                $nombre !== ''
                && $nombreColumn !== null
            ) {
                $stmt = $this->db->prepare(
                    'SELECT * FROM proveedores
                     WHERE LOWER(`' .
                    $nombreColumn .
                    '`) LIKE LOWER(:nombre)
                     LIMIT 5'
                );

                $stmt->execute([
                    'nombre' =>
                        '%' .
                        $nombre .
                        '%',
                ]);

                $filas = $stmt->fetchAll(
                    PDO::FETCH_ASSOC
                );

                if (
                    count($filas) === 1
                ) {
                    return $this->resultado(
                        $filas[0],
                        $idColumn,
                        $nombreColumn,
                        85,
                        'NOMBRE'
                    );
                }
            }
        } catch (Throwable) {
        }

        return $this->resultadoVacio();
    }

    private function buscarCliente(
        ?string $cuit,
        string $nombre
    ): array {
        try {
            if (
                !$this->tablaExiste(
                    'clientes'
                )
            ) {
                return $this->resultadoVacio();
            }

            $columnas =
                $this->columnas(
                    'clientes'
                );

            $idColumn =
                $this->buscarColumna(
                    $columnas,
                    [
                        'id',
                        'idcliente',
                        'cliente_id'
                    ]
                );

            $cuitColumn =
                $this->buscarColumna(
                    $columnas,
                    [
                        'cuit',
                        'cuit_cuil',
                        'cuitcuil',
                        'documento'
                    ]
                );

            $nombreColumn =
                $this->buscarColumna(
                    $columnas,
                    [
                        'nombre',
                        'razon_social',
                        'razonsocial',
                        'denominacion',
                        'cliente'
                    ]
                );

            if ($idColumn === null) {
                return $this->resultadoVacio();
            }

            if (
                $cuit !== null
                && $cuitColumn !== null
            ) {
                $sql =
                    'SELECT * FROM clientes ' .
                    'WHERE REPLACE(REPLACE(REPLACE(`' .
                    $cuitColumn .
                    '`, "-", ""), " ", ""), ".", "") = :cuit ' .
                    'LIMIT 1';

                $stmt = $this->db->prepare(
                    $sql
                );

                $stmt->execute([
                    'cuit' => str_replace(
                        '-',
                        '',
                        $cuit
                    ),
                ]);

                $fila = $stmt->fetch(
                    PDO::FETCH_ASSOC
                );

                if (is_array($fila)) {
                    return $this->resultado(
                        $fila,
                        $idColumn,
                        $nombreColumn,
                        100,
                        'CUIT'
                    );
                }
            }

            if (
                $nombre !== ''
                && $nombreColumn !== null
            ) {
                $stmt = $this->db->prepare(
                    'SELECT * FROM clientes
                     WHERE LOWER(`' .
                    $nombreColumn .
                    '`) LIKE LOWER(:nombre)
                     LIMIT 5'
                );

                $stmt->execute([
                    'nombre' =>
                        '%' .
                        $nombre .
                        '%',
                ]);

                $filas = $stmt->fetchAll(
                    PDO::FETCH_ASSOC
                );

                if (
                    count($filas) === 1
                ) {
                    return $this->resultado(
                        $filas[0],
                        $idColumn,
                        $nombreColumn,
                        85,
                        'NOMBRE'
                    );
                }
            }
        } catch (Throwable) {
        }

        return $this->resultadoVacio();
    }

    private function resultado(
        array $fila,
        string $idColumn,
        ?string $nombreColumn,
        int $confianza,
        string $metodo
    ): array {
        return [
            'entidad_tipo' => null,
            'entidad_id' => isset(
                $fila[$idColumn]
            )
                ? (int) $fila[$idColumn]
                : null,
            'entidad_nombre' =>
                $nombreColumn !== null
                && isset($fila[$nombreColumn])
                    ? (string) $fila[$nombreColumn]
                    : null,
            'confianza' => $confianza,
            'metodo' => $metodo,
        ];
    }

    private function resultadoVacio(): array
    {
        return [
            'entidad_tipo' => null,
            'entidad_id' => null,
            'entidad_nombre' => null,
            'confianza' => 0,
            'metodo' => null,
        ];
    }

    private function esCompra(
        string $tipo
    ): bool {
        return in_array(
            strtoupper($tipo),
            [
                'FACTURA_COMPRA',
                'COMPRA',
            ],
            true
        );
    }

    private function esVenta(
        string $tipo
    ): bool {
        return in_array(
            strtoupper($tipo),
            [
                'FACTURA_VENTA',
                'VENTA',
            ],
            true
        );
    }

    private function normalizarCuit(
        mixed $cuit
    ): ?string {
        if (
            !is_string($cuit)
            && !is_numeric($cuit)
        ) {
            return null;
        }

        $valor = preg_replace(
            '/\D+/',
            '',
            (string) $cuit
        );

        if (
            $valor === null
            || strlen($valor) !== 11
        ) {
            return null;
        }

        return substr(
            $valor,
            0,
            2
        )
        . '-'
        .
        substr(
            $valor,
            2,
            8
        )
        . '-'
        .
        substr(
            $valor,
            10,
            1
        );
    }

    private function tablaExiste(
        string $tabla
    ): bool {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*)
             FROM information_schema.tables
             WHERE table_schema = DATABASE()
             AND table_name = :tabla'
        );

        $stmt->execute([
            'tabla' => $tabla,
        ]);

        return (int) $stmt->fetchColumn() > 0;
    }

    private function columnas(
        string $tabla
    ): array {
        $stmt = $this->db->query(
            'SHOW COLUMNS FROM `' .
            $tabla .
            '`'
        );

        $resultado = [];

        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            ) as $fila
        ) {
            if (
                isset(
                    $fila['Field']
                )
            ) {
                $resultado[] =
                    strtolower(
                        (string) $fila['Field']
                    );
            }
        }

        return $resultado;
    }

    private function buscarColumna(
        array $columnas,
        array $posibles
    ): ?string {
        foreach ($posibles as $posible) {
            $posible =
                strtolower(
                    $posible
                );

            if (
                in_array(
                    $posible,
                    $columnas,
                    true
                )
            ) {
                return $posible;
            }
        }

        return null;
    }
}