<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Engines;

final class Classifier
{
    public function classify(
        string $texto,
        ?string $mimeType = null
    ): array {

        $textoOriginal =
            trim($texto);


        if ($textoOriginal === '') {

            return [
                'tipo_documento' =>
                    'OTRO',

                'subtipo_documento' =>
                    null,

                'categoria' =>
                    'SIN_CLASIFICAR',

                'modulo_destino' =>
                    null,

                'confianza' =>
                    0,

                'coincidencias' =>
                    [],

                'puntaje' =>
                    0,
            ];
        }


        $textoNormalizado =
            $this->normalizar(
                $textoOriginal
            );


        $reglas = [

            'FACTURA' => [

                'categoria' =>
                    'GASTO',

                'modulo' =>
                    'COMPRAS',

                'palabras' => [

                    'factura' =>
                        50,

                    'comprobante' =>
                        15,

                    'cuit' =>
                        10,

                    'cae' =>
                        25,

                    'caea' =>
                        25,

                    'punto de venta' =>
                        20,

                    'importe neto' =>
                        10,

                    'iva' =>
                        15,

                    'total' =>
                        5,

                    'fecha de vencimiento' =>
                        10,

                    'responsable inscripto' =>
                        10,

                    'monotributo' =>
                        10,
                ],
            ],


            'REMITO' => [

                'categoria' =>
                    'COMPRA',

                'modulo' =>
                    'INVENTARIO',

                'palabras' => [

                    'remito' =>
                        60,

                    'remision' =>
                        40,

                    'mercaderia' =>
                        20,

                    'mercaderia entregada' =>
                        30,

                    'entrega' =>
                        10,

                    'recibi conforme' =>
                        25,

                    'bultos' =>
                        10,

                    'cantidad' =>
                        5,
                ],
            ],


            'ORDEN_COMPRA' => [

                'categoria' =>
                    'COMPRA',

                'modulo' =>
                    'COMPRAS',

                'palabras' => [

                    'orden de compra' =>
                        70,

                    'orden compra' =>
                        50,

                    'purchase order' =>
                        60,

                    'oc nro' =>
                        30,

                    'proveedor' =>
                        10,

                    'cantidad' =>
                        5,

                    'precio unitario' =>
                        10,
                ],
            ],


            'PRESUPUESTO' => [

                'categoria' =>
                    'PRESUPUESTO',

                'modulo' =>
                    'COMPRAS',

                'palabras' => [

                    'presupuesto' =>
                        65,

                    'cotizacion' =>
                        60,

                    'cotización' =>
                        60,

                    'presupuestado' =>
                        30,

                    'validez de la oferta' =>
                        30,

                    'oferta' =>
                        10,

                    'precio unitario' =>
                        10,
                ],
            ],


            'INFORME_TECNICO' => [

                'categoria' =>
                    'SERVICIO_TECNICO',

                'modulo' =>
                    'SERVICIOS',

                'palabras' => [

                    'informe tecnico' =>
                        70,

                    'informe técnico' =>
                        70,

                    'diagnostico' =>
                        55,

                    'diagnóstico' =>
                        55,

                    'servicio tecnico' =>
                        60,

                    'servicio técnico' =>
                        60,

                    'reparacion' =>
                        50,

                    'reparación' =>
                        50,

                    'falla detectada' =>
                        45,

                    'trabajo realizado' =>
                        40,

                    'mantenimiento' =>
                        35,

                    'tecnico' =>
                        15,

                    'técnico' =>
                        15,

                    'equipo' =>
                        8,

                    'contador' =>
                        8,

                    'serie' =>
                        8,

                    'repuesto' =>
                        20,

                    'repuestos' =>
                        20,

                    'observaciones' =>
                        10,
                ],
            ],


            'RECIBO' => [

                'categoria' =>
                    'PAGO',

                'modulo' =>
                    'FACTURACION',

                'palabras' => [

                    'recibo' =>
                        60,

                    'importe recibido' =>
                        40,

                    'pago recibido' =>
                        40,

                    'saldo' =>
                        10,

                    'efectivo' =>
                        10,

                    'transferencia' =>
                        10,
                ],
            ],


            'TICKET' => [

                'categoria' =>
                    'GASTO',

                'modulo' =>
                    'COMPRAS',

                'palabras' => [

                    'ticket' =>
                        55,

                    'ticket factura' =>
                        65,

                    'comprobante de venta' =>
                        35,

                    'cajero' =>
                        25,

                    'subtotal' =>
                        10,

                    'total' =>
                        5,

                    'iva' =>
                        10,

                    'consumidor final' =>
                        15,
                ],
            ],
        ];


        $resultados = [];


        foreach (
            $reglas as $tipo => $regla
        ) {

            $puntaje = 0;

            $coincidencias = [];


            foreach (
                $regla['palabras']
                as $palabra => $valor
            ) {

                $normalizada =
                    $this->normalizar(
                        $palabra
                    );


                if (
                    $normalizada !== ''
                    &&
                    str_contains(
                        $textoNormalizado,
                        $normalizada
                    )
                ) {

                    $puntaje +=
                        (int) $valor;


                    $coincidencias[] =
                        $palabra;
                }
            }


            if ($puntaje > 0) {

                $resultados[$tipo] = [

                    'puntaje' =>
                        $puntaje,

                    'coincidencias' =>
                        $coincidencias,

                    'categoria' =>
                        $regla['categoria'],

                    'modulo' =>
                        $regla['modulo'],
                ];
            }
        }


        if (!$resultados) {

            return [
                'tipo_documento' =>
                    'OTRO',

                'subtipo_documento' =>
                    null,

                'categoria' =>
                    'SIN_CLASIFICAR',

                'modulo_destino' =>
                    null,

                'confianza' =>
                    10,

                'coincidencias' =>
                    [],

                'puntaje' =>
                    0,
            ];
        }


        uasort(
            $resultados,
            static function (
                array $a,
                array $b
            ): int {

                return
                    $b['puntaje']
                    <=>
                    $a['puntaje'];
            }
        );


        $mejorTipo =
            array_key_first(
                $resultados
            );


        $mejor =
            $resultados[
                $mejorTipo
            ];


        $segundoPuntaje = 0;

        $contador = 0;


        foreach (
            $resultados as $resultado
        ) {

            $contador++;


            if ($contador === 2) {

                $segundoPuntaje =
                    (int) (
                        $resultado['puntaje']
                    );

                break;
            }
        }


        $diferencia =
            (int) (
                $mejor['puntaje']
                -
                $segundoPuntaje
            );


        $confianza =
            $this->confianza(
                (int) $mejor['puntaje'],
                $diferencia,
                count(
                    $mejor['coincidencias']
                )
            );


        $subtipo = null;


        if (
            $mejorTipo === 'FACTURA'
        ) {

            $subtipo =
                $this->subtipoFactura(
                    $textoOriginal
                );
        }


        return [

            'tipo_documento' =>
                $mejorTipo,

            'subtipo_documento' =>
                $subtipo,

            'categoria' =>
                $mejor['categoria'],

            'modulo_destino' =>
                $mejor['modulo'],

            'confianza' =>
                $confianza,

            'coincidencias' =>
                $mejor['coincidencias'],

            'puntaje' =>
                $mejor['puntaje'],
        ];
    }


    private function normalizar(
        string $texto
    ): string {

        $texto =
            mb_strtolower(
                trim($texto),
                'UTF-8'
            );


        $texto =
            preg_replace(
                '/\s+/u',
                ' ',
                $texto
            )
            ??
            $texto;


        return trim($texto);
    }


    private function subtipoFactura(
        string $texto
    ): ?string {

        $texto =
            mb_strtolower(
                $texto,
                'UTF-8'
            );


        if (
            preg_match(
                '/\bfactura\s*a\b/u',
                $texto
            )
            ||
            preg_match(
                '/\ba\s*[-:]?\s*\d{4,}/u',
                $texto
            )
        ) {

            return 'FACTURA_A';
        }


        if (
            preg_match(
                '/\bfactura\s*b\b/u',
                $texto
            )
            ||
            preg_match(
                '/\bb\s*[-:]?\s*\d{4,}/u',
                $texto
            )
        ) {

            return 'FACTURA_B';
        }


        if (
            preg_match(
                '/\bfactura\s*c\b/u',
                $texto
            )
            ||
            preg_match(
                '/\bc\s*[-:]?\s*\d{4,}/u',
                $texto
            )
        ) {

            return 'FACTURA_C';
        }


        return null;
    }


    private function confianza(
        int $puntaje,
        int $diferencia,
        int $coincidencias
    ): float {

        if ($puntaje >= 120) {

            $confianza = 96;

        } elseif ($puntaje >= 90) {

            $confianza = 92;

        } elseif ($puntaje >= 60) {

            $confianza = 84;

        } elseif ($puntaje >= 35) {

            $confianza = 70;

        } else {

            $confianza = 50;
        }


        if ($coincidencias >= 5) {

            $confianza += 3;

        } elseif ($coincidencias >= 3) {

            $confianza += 2;
        }


        if ($diferencia <= 10) {

            $confianza -= 15;

        } elseif ($diferencia <= 20) {

            $confianza -= 8;
        }


        return max(
            0,
            min(
                99,
                round(
                    $confianza,
                    2
                )
            )
        );
    }
}