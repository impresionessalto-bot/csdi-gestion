<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Engines;

final class Extractor
{
    public function extract(
        string $texto
    ): array {
        $texto = trim($texto);

        if ($texto === '') {
            return $this->resultadoVacio();
        }

        return [
            'cuit' =>
                $this->extraerCuit($texto),

            'razon_social' =>
                $this->extraerRazonSocial($texto),

            'fecha' =>
                $this->extraerFecha($texto),

            'numero_comprobante' =>
                $this->extraerNumeroComprobante(
                    $texto
                ),

            'tipo_comprobante' =>
                $this->extraerTipoComprobante(
                    $texto
                ),

            'subtotal' =>
                $this->extraerImporte(
                    $texto,
                    [
                        'subtotal',
                        'sub total',
                    ]
                ),

            'iva' =>
                $this->extraerImporte(
                    $texto,
                    [
                        'iva',
                    ]
                ),

            'total' =>
                $this->extraerImporte(
                    $texto,
                    [
                        'total',
                    ]
                ),

            'cliente' =>
                $this->extraerCampo(
                    $texto,
                    [
                        'cliente',
                        'cliente:',
                    ]
                ),

            'proveedor' =>
                $this->extraerCampo(
                    $texto,
                    [
                        'proveedor',
                        'proveedor:',
                    ]
                ),

            'equipo' =>
                $this->extraerCampo(
                    $texto,
                    [
                        'equipo',
                        'equipo:',
                    ]
                ),

            'serie' =>
                $this->extraerCampo(
                    $texto,
                    [
                        'serie',
                        'nro de serie',
                        'número de serie',
                    ]
                ),

            'diagnostico' =>
                $this->extraerCampo(
                    $texto,
                    [
                        'diagnóstico',
                        'diagnostico',
                    ]
                ),

            'trabajo_realizado' =>
                $this->extraerCampo(
                    $texto,
                    [
                        'trabajo realizado',
                        'trabajo efectuado',
                        'reparación realizada',
                        'reparacion realizada',
                    ]
                ),
        ];
    }

    private function resultadoVacio(): array
    {
        return [
            'cuit' => null,
            'razon_social' => null,
            'fecha' => null,
            'numero_comprobante' => null,
            'tipo_comprobante' => null,
            'subtotal' => null,
            'iva' => null,
            'total' => null,
            'cliente' => null,
            'proveedor' => null,
            'equipo' => null,
            'serie' => null,
            'diagnostico' => null,
            'trabajo_realizado' => null,
        ];
    }

    private function extraerCuit(
        string $texto
    ): ?string {
        if (
            preg_match(
                '/\b(?:CUIT|C\.U\.I\.T\.?)\s*:?\s*(\d{2})[-\s]?(\d{8})[-\s]?(\d)\b/i',
                $texto,
                $match
            )
        ) {
            return
                $match[1]
                . '-'
                . $match[2]
                . '-'
                . $match[3];
        }

        if (
            preg_match(
                '/\b(\d{2})[-\s]?(\d{8})[-\s]?(\d)\b/',
                $texto,
                $match
            )
        ) {
            return
                $match[1]
                . '-'
                . $match[2]
                . '-'
                . $match[3];
        }

        return null;
    }

    private function extraerRazonSocial(
        string $texto
    ): ?string {
        $patrones = [
            '/raz[oó]n\s+social\s*:?\s*(.+)/iu',
            '/empresa\s*:?\s*(.+)/iu',
            '/proveedor\s*:?\s*(.+)/iu',
        ];

        foreach ($patrones as $patron) {
            if (
                preg_match(
                    $patron,
                    $texto,
                    $match
                )
            ) {
                $valor = trim(
                    $match[1]
                );

                $valor =
                    preg_split(
                        '/\r?\n/',
                        $valor
                    )[0]
                    ?? $valor;

                if ($valor !== '') {
                    return trim(
                        $valor
                    );
                }
            }
        }

        return null;
    }

    private function extraerFecha(
        string $texto
    ): ?string {
        if (
            preg_match(
                '/\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})\b/',
                $texto,
                $match
            )
        ) {
            $dia = str_pad(
                $match[1],
                2,
                '0',
                STR_PAD_LEFT
            );

            $mes = str_pad(
                $match[2],
                2,
                '0',
                STR_PAD_LEFT
            );

            $anio = (int) $match[3];

            if ($anio < 100) {
                $anio += 2000;
            }

            return sprintf(
                '%04d-%02d-%02d',
                $anio,
                (int) $mes,
                (int) $dia
            );
        }

        return null;
    }

    private function extraerNumeroComprobante(
        string $texto
    ): ?string {
        $patrones = [
            '/\b(\d{4})\s*[-]\s*(\d{8})\b/',
            '/\b(\d{4})\s+(\d{8})\b/',
            '/(?:comprobante|factura|nro|n°|numero)\s*:?\s*(\d{4}[-\s]\d{4,8})/iu',
        ];

        foreach ($patrones as $patron) {
            if (
                preg_match(
                    $patron,
                    $texto,
                    $match
                )
            ) {
                if (isset($match[2])) {
                    return
                        str_pad(
                            $match[1],
                            4,
                            '0',
                            STR_PAD_LEFT
                        )
                        . '-'
                        . str_pad(
                            $match[2],
                            8,
                            '0',
                            STR_PAD_LEFT
                        );
                }

                return trim(
                    $match[1]
                );
            }
        }

        return null;
    }

    private function extraerTipoComprobante(
        string $texto
    ): ?string {
        $textoNormalizado =
            mb_strtolower(
                $texto,
                'UTF-8'
            );

        if (
            str_contains(
                $textoNormalizado,
                'factura a'
            )
        ) {
            return 'A';
        }

        if (
            str_contains(
                $textoNormalizado,
                'factura b'
            )
        ) {
            return 'B';
        }

        if (
            str_contains(
                $textoNormalizado,
                'factura c'
            )
        ) {
            return 'C';
        }

        if (
            str_contains(
                $textoNormalizado,
                'factura'
            )
        ) {
            return 'FACTURA';
        }

        return null;
    }

    private function extraerImporte(
        string $texto,
        array $etiquetas
    ): ?float {
        foreach ($etiquetas as $etiqueta) {
            $patron =
                '/'
                . preg_quote(
                    $etiqueta,
                    '/'
                )
                . '\s*:?\s*\$?\s*([\d\.\,]+)/iu';

            if (
                preg_match(
                    $patron,
                    $texto,
                    $match
                )
            ) {
                return $this->normalizarImporte(
                    $match[1]
                );
            }
        }

        return null;
    }

    private function normalizarImporte(
        string $valor
    ): float {
        $valor = trim(
            $valor
        );

        if (
            str_contains(
                $valor,
                ','
            )
        ) {
            $valor = str_replace(
                '.',
                '',
                $valor
            );

            $valor = str_replace(
                ',',
                '.',
                $valor
            );
        } else {
            $valor = str_replace(
                ',',
                '',
                $valor
            );
        }

        return (float) $valor;
    }

    private function extraerCampo(
        string $texto,
        array $etiquetas
    ): ?string {
        foreach ($etiquetas as $etiqueta) {
            $patron =
                '/'
                . preg_quote(
                    $etiqueta,
                    '/'
                )
                . '\s*:?\s*(.+)/iu';

            if (
                preg_match(
                    $patron,
                    $texto,
                    $match
                )
            ) {
                $valor = trim(
                    $match[1]
                );

                $lineas =
                    preg_split(
                        '/\r?\n/',
                        $valor
                    );

                $valor =
                    trim(
                        $lineas[0]
                        ?? $valor
                    );

                if ($valor !== '') {
                    return $valor;
                }
            }
        }

        return null;
    }
}