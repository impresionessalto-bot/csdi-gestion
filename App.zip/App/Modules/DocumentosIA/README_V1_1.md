# DocumentosIA 1.1.0

Refactor estructural del módulo manteniendo el MVC existente.

## Cambios principales
- Eliminadas implementaciones duplicadas de Storage, TextExtractor y Validator.
- `Support/FileManager` centraliza almacenamiento, resolución y eliminación de archivos.
- `Engines/TextExtractor` queda como extractor de texto.
- `Engines/Extractor` queda como extractor estructurado de campos.
- `Service` orquesta extracción de texto, extracción estructurada, clasificación, validación y resolución de entidades.
- `ProviderInterface`, `LocalProvider` y `NullProvider` ahora comparten el mismo contrato.
- Corregido el nombre de archivo `Classifier.php` para compatibilidad PSR-4/Linux.
- Agregada confirmación/corrección manual mediante `POST /documentos-ia/confirmar/{id}`.
- La confirmación no crea registros en módulos destino; deja el documento listo para integración futura.
- Compatible con hosting sin `exec()`, `shell_exec()` ni `escapeshellarg()` como dependencia obligatoria.

## Importante
El módulo conserva el estado `PROCESADO` para documentos confirmados para evitar exigir una modificación SQL de estados existente. La marca de confirmación se guarda dentro de `datos_json` como `_confirmacion`.
