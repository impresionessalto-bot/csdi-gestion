<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Support;

use Throwable;

final class TextExtractor
{
    /**
     * Extraer texto según tipo de archivo.
     */
    public function extract(
        string $ruta,
        string $mimeType = '',
        string $extension = ''
    ): string {
        if (!is_file($ruta)) {
            return '';
        }

        $extension = strtolower(
            trim($extension)
        );

        $mimeType = strtolower(
            trim($mimeType)
        );

        /*
         * TXT
         */
        if (
            $extension === 'txt'
            || $mimeType === 'text/plain'
        ) {
            return $this->leerTexto(
                $ruta
            );
        }

        /*
         * CSV
         */
        if (
            $extension === 'csv'
            || $mimeType === 'text/csv'
        ) {
            return $this->leerTexto(
                $ruta
            );
        }

        /*
         * HTML
         */
        if (
            in_array(
                $extension,
                ['html', 'htm'],
                true
            )
            ||
            str_contains(
                $mimeType,
                'html'
            )
        ) {
            return $this->extraerHtml(
                $ruta
            );
        }

        /*
         * XML
         */
        if (
            $extension === 'xml'
            || str_contains(
                $mimeType,
                'xml'
            )
        ) {
            return $this->extraerXml(
                $ruta
            );
        }

        /*
         * PDF
         */
        if (
            $extension === 'pdf'
            || $mimeType === 'application/pdf'
        ) {
            return $this->extraerPdf(
                $ruta
            );
        }

        /*
         * Imágenes.
         *
         * Actualmente no hacemos OCR porque Ferozo
         * no dispone de Tesseract/API OCR en este entorno.
         */
        if (
            str_starts_with(
                $mimeType,
                'image/'
            )
            ||
            in_array(
                $extension,
                [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp',
                    'bmp',
                    'gif',
                    'tif',
                    'tiff',
                ],
                true
            )
        ) {
            return '';
        }

        /*
         * Último intento para archivos pequeños.
         */
        return $this->extraerGenerico(
            $ruta
        );
    }

    /**
     * PDF.
     *
     * Utiliza Smalot PdfParser si está instalado.
     */
    private function extraerPdf(
        string $ruta
    ): string {
        if (
            class_exists(
                '\\Smalot\\PdfParser\\Parser'
            )
        ) {
            try {
                $parser =
                    new \Smalot\PdfParser\Parser();

                $pdf =
                    $parser->parseFile(
                        $ruta
                    );

                $texto =
                    $pdf->getText();

                if (
                    is_string($texto)
                    &&
                    trim($texto) !== ''
                ) {
                    return trim($texto);
                }
            } catch (Throwable) {
                // No interrumpimos el procesamiento.
            }
        }

        /*
         * No utilizamos:
         *
         * exec()
         * shell_exec()
         * system()
         * passthru()
         *
         * porque no están disponibles/convenientes
         * en el hosting actual.
         */
        return '';
    }

    /**
     * HTML.
     */
    private function extraerHtml(
        string $ruta
    ): string {
        $contenido =
            $this->leerTexto($ruta);

        if ($contenido === '') {
            return '';
        }

        /*
         * Eliminamos scripts y estilos.
         */
        $contenido = preg_replace(
            '/<script\b[^>]*>.*?<\/script>/is',
            ' ',
            $contenido
        ) ?? $contenido;

        $contenido = preg_replace(
            '/<style\b[^>]*>.*?<\/style>/is',
            ' ',
            $contenido
        ) ?? $contenido;

        $contenido = strip_tags(
            $contenido
        );

        $contenido = html_entity_decode(
            $contenido,
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );

        return $this->normalizarTexto(
            $contenido
        );
    }

    /**
     * XML.
     */
    private function extraerXml(
        string $ruta
    ): string {
        $contenido =
            $this->leerTexto($ruta);

        if ($contenido === '') {
            return '';
        }

        /*
         * Para documentos XML simples,
         * quitar tags es suficiente para el
         * clasificador inicial.
         */
        $contenido = strip_tags(
            $contenido
        );

        return $this->normalizarTexto(
            $contenido
        );
    }

    /**
     * Leer texto plano.
     */
    private function leerTexto(
        string $ruta
    ): string {
        if (!is_file($ruta)) {
            return '';
        }

        $contenido =
            @file_get_contents($ruta);

        if (!is_string($contenido)) {
            return '';
        }

        if ($contenido === '') {
            return '';
        }

        /*
         * Detectamos BOM UTF-8.
         */
        if (
            str_starts_with(
                $contenido,
                "\xEF\xBB\xBF"
            )
        ) {
            $contenido = substr(
                $contenido,
                3
            );
        }

        return $this->normalizarTexto(
            $contenido
        );
    }

    /**
     * Último intento.
     */
    private function extraerGenerico(
        string $ruta
    ): string {
        if (!is_file($ruta)) {
            return '';
        }

        $size = filesize(
            $ruta
        );

        if (
            $size === false
            || $size > 5 * 1024 * 1024
        ) {
            return '';
        }

        $contenido =
            @file_get_contents($ruta);

        if (
            !is_string($contenido)
            || $contenido === ''
        ) {
            return '';
        }

        /*
         * Intentamos eliminar caracteres de control
         * sin destruir saltos de línea.
         */
        $contenido = preg_replace(
            '/[^\P{C}\n\r\t]+/u',
            ' ',
            $contenido
        );

        if (!is_string($contenido)) {
            return '';
        }

        return $this->normalizarTexto(
            $contenido
        );
    }

    /**
     * Normalización general.
     */
    private function normalizarTexto(
        string $texto
    ): string {
        $texto = str_replace(
            ["\r\n", "\r"],
            "\n",
            $texto
        );

        /*
         * Espacios repetidos.
         */
        $texto = preg_replace(
            '/[ \t]+/u',
            ' ',
            $texto
        ) ?? $texto;

        /*
         * Más de dos saltos consecutivos.
         */
        $texto = preg_replace(
            '/\n{3,}/u',
            "\n\n",
            $texto
        ) ?? $texto;

        return trim(
            $texto
        );
    }
}