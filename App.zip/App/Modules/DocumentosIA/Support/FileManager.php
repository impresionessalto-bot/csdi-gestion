<?php

declare(strict_types=1);

namespace App\Modules\DocumentosIA\Support;

use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class FileManager
{
    private const MAX_SIZE = 25 * 1024 * 1024;

    private string $directory;

    /**
     * Extensiones permitidas.
     */
    private const EXTENSIONES_PERMITIDAS = [
        'pdf',
        'txt',
        'csv',
        'xml',
        'html',
        'htm',
        'jpg',
        'jpeg',
        'png',
        'webp',
        'bmp',
        'gif',
        'tif',
        'tiff',
    ];

    public function __construct()
    {
        $this->directory = rtrim(
            BASE_PATH . '/uploads/documentos_ia',
            '/\\'
        );
    }

    /**
     * Validar archivo recibido por $_FILES.
     */
    public function validar(array $archivo): void
    {
        $error = (int) (
            $archivo['error']
            ?? UPLOAD_ERR_NO_FILE
        );

        if ($error !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException(
                $this->mensajeUploadError($error)
            );
        }

        $tmpName = trim(
            (string) (
                $archivo['tmp_name']
                ?? ''
            )
        );

        if ($tmpName === '') {
            throw new InvalidArgumentException(
                'No se recibió el archivo temporal.'
            );
        }

        if (!is_uploaded_file($tmpName)) {
            throw new InvalidArgumentException(
                'El archivo recibido no es válido.'
            );
        }

        $tamano = (int) (
            $archivo['size']
            ?? 0
        );

        if ($tamano <= 0) {
            throw new InvalidArgumentException(
                'El archivo está vacío.'
            );
        }

        if ($tamano > self::MAX_SIZE) {
            throw new InvalidArgumentException(
                'El archivo supera el límite de 25 MB.'
            );
        }

        $nombre = trim(
            (string) (
                $archivo['name']
                ?? ''
            )
        );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El archivo no tiene nombre.'
            );
        }

        $extension = $this->extension(
            $nombre
        );

        if (
            !in_array(
                $extension,
                self::EXTENSIONES_PERMITIDAS,
                true
            )
        ) {
            throw new InvalidArgumentException(
                'Tipo de archivo no permitido. '
                . 'Permitidos: PDF, TXT, CSV, XML, HTML e imágenes.'
            );
        }
    }

    /**
     * Guardar archivo físico.
     *
     * @return array{
     *     nombre_original:string,
     *     nombre_fisico:string,
     *     archivo_path:string,
     *     extension:string,
     *     mime_type:string,
     *     tamano_bytes:int,
     *     ruta_fisica:string
     * }
     */
    public function guardar(array $archivo): array
    {
        $this->validar($archivo);

        $nombreOriginal = trim(
            (string) $archivo['name']
        );

        $tmpName = trim(
            (string) $archivo['tmp_name']
        );

        $tamano = (int) $archivo['size'];

        $extension = $this->extension(
            $nombreOriginal
        );

        $mimeType = $this->obtenerMimeType(
            $tmpName,
            (string) (
                $archivo['type']
                ?? ''
            )
        );

        $this->crearDirectorio();

        $nombreFisico =
            date('Ymd_His')
            . '_'
            . bin2hex(random_bytes(8))
            . '.'
            . $extension;

        $rutaFisica =
            $this->directory
            . DIRECTORY_SEPARATOR
            . $nombreFisico;

        if (!move_uploaded_file(
            $tmpName,
            $rutaFisica
        )) {
            throw new RuntimeException(
                'No se pudo guardar físicamente el documento.'
            );
        }

        return [
            'nombre_original' => $nombreOriginal,
            'nombre_fisico'   => $nombreFisico,
            'archivo_path'    =>
                'uploads/documentos_ia/'
                . $nombreFisico,
            'extension'       => $extension,
            'mime_type'       => $mimeType,
            'tamano_bytes'    => $tamano,
            'ruta_fisica'     => $rutaFisica,
        ];
    }

    /**
     * Resolver ruta física a partir de la ruta guardada en BD.
     */
    public function resolver(string $archivoPath): ?string
    {
        $archivoPath = str_replace(
            ['\\', '..'],
            ['/', ''],
            $archivoPath
        );

        $archivoPath = ltrim(
            $archivoPath,
            '/'
        );

        if ($archivoPath === '') {
            return null;
        }

        /*
         * Ruta normal:
         *
         * BASE_PATH/uploads/...
         */
        $ruta = BASE_PATH
            . DIRECTORY_SEPARATOR
            . str_replace(
                '/',
                DIRECTORY_SEPARATOR,
                $archivoPath
            );

        if (is_file($ruta)) {
            return $ruta;
        }

        /*
         * Compatibilidad con:
         *
         * BASE_PATH/public/uploads/...
         */
        $rutaPublic = BASE_PATH
            . DIRECTORY_SEPARATOR
            . 'public'
            . DIRECTORY_SEPARATOR
            . str_replace(
                '/',
                DIRECTORY_SEPARATOR,
                $archivoPath
            );

        if (is_file($rutaPublic)) {
            return $rutaPublic;
        }

        /*
         * Compatibilidad con archivos existentes
         * en la carpeta conocida.
         */
        $nombre = basename(
            $archivoPath
        );

        $ruta = $this->directory
            . DIRECTORY_SEPARATOR
            . $nombre;

        if (is_file($ruta)) {
            return $ruta;
        }

        return null;
    }

    /**
     * Eliminar archivo.
     */
    public function eliminar(string $archivoPath): bool
    {
        $ruta = $this->resolver(
            $archivoPath
        );

        if ($ruta === null) {
            return false;
        }

        if (!is_file($ruta)) {
            return false;
        }

        return @unlink($ruta);
    }

    /**
     * Obtener extensión.
     */
    public function extension(string $nombre): string
    {
        $extension = strtolower(
            pathinfo(
                $nombre,
                PATHINFO_EXTENSION
            )
        );

        if ($extension === '') {
            throw new InvalidArgumentException(
                'El archivo no tiene una extensión válida.'
            );
        }

        return $extension;
    }

    /**
     * Obtener MIME real del archivo.
     */
    public function obtenerMimeType(
        string $ruta,
        string $mimeInformado = ''
    ): string {
        if (class_exists('\\finfo')) {
            try {
                $finfo = new \finfo(
                    FILEINFO_MIME_TYPE
                );

                $mime = $finfo->file(
                    $ruta
                );

                if (
                    is_string($mime)
                    && $mime !== ''
                ) {
                    return $mime;
                }
            } catch (Throwable) {
                // Continuamos con el MIME informado.
            }
        }

        return trim($mimeInformado) !== ''
            ? trim($mimeInformado)
            : 'application/octet-stream';
    }

    /**
     * Crear directorio de documentos.
     */
    private function crearDirectorio(): void
    {
        if (is_dir($this->directory)) {
            return;
        }

        if (
            !@mkdir(
                $this->directory,
                0755,
                true
            )
            &&
            !is_dir($this->directory)
        ) {
            throw new RuntimeException(
                'No se pudo crear el directorio de documentos IA: '
                . $this->directory
            );
        }
    }

    /**
     * Mensajes de upload.
     */
    private function mensajeUploadError(
        int $codigo
    ): string {
        return match ($codigo) {
            UPLOAD_ERR_INI_SIZE,
            UPLOAD_ERR_FORM_SIZE =>
                'El archivo supera el tamaño permitido.',

            UPLOAD_ERR_PARTIAL =>
                'El archivo se cargó parcialmente.',

            UPLOAD_ERR_NO_FILE =>
                'No se seleccionó ningún archivo.',

            UPLOAD_ERR_NO_TMP_DIR =>
                'No existe el directorio temporal del servidor.',

            UPLOAD_ERR_CANT_WRITE =>
                'No se pudo escribir el archivo.',

            UPLOAD_ERR_EXTENSION =>
                'Una extensión del servidor bloqueó la carga.',

            default =>
                'Error desconocido al cargar el archivo.',
        };
    }
}