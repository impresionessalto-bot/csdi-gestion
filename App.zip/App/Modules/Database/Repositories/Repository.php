<?php

declare(strict_types=1);

namespace App\Modules\Database\Repositories;

use PDO;
use Throwable;

/**
 * Repositorio de acceso a datos técnicos exclusivo para el módulo Database.
 */
final class Repository
{
    /**
     * Inyección explícita de la conexión PDO gestionada por el contenedor de CSDI PRO.
     */
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /**
     * Consulta el catálogo técnico de MySQL para auditar los tamaños de las tablas del ERP.
     * Retorna un array plano ordenado por tamaño físico descendente o array vacío en caso de fallo.
     */
    public function obtenerMetricasTablas(string $schema): array
    {
        $sql = "SELECT 
                    TABLE_NAME AS tabla,
                    ENGINE AS motor,
                    TABLE_ROWS AS filas,
                    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) AS tamaño_mb,
                    ROUND((INDEX_LENGTH / 1024 / 1024), 2) AS indice_mb
                FROM information_schema.TABLES
                WHERE TABLE_SCHEMA = :schema
                ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['schema' => $schema]);
            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return is_array($resultado) ? $resultado : [];
        } catch (Throwable) {
            return [];
        }
    }
}