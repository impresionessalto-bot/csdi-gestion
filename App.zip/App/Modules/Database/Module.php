<?php

declare(strict_types=1);

namespace App\Modules\Database;

use App\Core\Module as CoreModule;

/**
 * ============================================================================
 * CSDI PRO
 * DATABASE MODULE
 * ============================================================================
 *
 * Consola administrativa de base de datos.
 *
 * Estructura:
 *
 * App/Modules/Database/
 * ├── Module.php
 * ├── Config/
 * │   └── routes.php
 * ├── Controllers/
 * │   └── DatabaseController.php
 * ├── Services/
 * │   └── Service.php
 * └── Views/
 *
 * ============================================================================
 */
final class Module extends CoreModule
{
    /*
    |--------------------------------------------------------------------------
    | INFORMACIÓN
    |--------------------------------------------------------------------------
    */

    public function name(): string
    {
        return 'Database';
    }

    public function description(): string
    {
        return 'Consola de auditoría física, volumetría y optimización del motor SQL';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    /*
    |--------------------------------------------------------------------------
    | RUTAS
    |--------------------------------------------------------------------------
    */

    /**
     * Archivo de rutas del módulo.
     *
     * Ubicación real:
     *
     * App/Modules/Database/Config/routes.php
     */
    public function routes(): string
    {
        return $this->configPath() . '/routes.php';
    }

    /*
    |--------------------------------------------------------------------------
    | PRIORIDAD
    |--------------------------------------------------------------------------
    */

    public function priority(): int
    {
        return 15;
    }

    /*
    |--------------------------------------------------------------------------
    | MENÚ
    |--------------------------------------------------------------------------
    */

    public function menu(): array
    {
        return [
            [
                'title'      => 'Base de Datos',
                'icon'       => 'fa-solid fa-database',
                'url'        => '/admin/database',
                'group'      => 'Herramientas',
                'order'      => 15,
                'permission' => 'database.ver',
                'visible'    => true,
                'children'   => [],
            ],
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS DE MENÚ
    |--------------------------------------------------------------------------
    */

    public function icon(): string
    {
        return 'fa-solid fa-database';
    }

    public function url(): string
    {
        return '/admin/database';
    }

    public function group(): string
    {
        return 'Herramientas';
    }

    public function order(): int
    {
        return 15;
    }

    /*
    |--------------------------------------------------------------------------
    | PERMISOS
    |--------------------------------------------------------------------------
    */

    public function permissions(): array
    {
        return [
            'database.ver',
            'database.estructura',
            'database.registros',
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | DEPENDENCIAS
    |--------------------------------------------------------------------------
    */

    public function dependencies(): array
    {
        return [];
    }

    /*
    |--------------------------------------------------------------------------
    | WIDGETS
    |--------------------------------------------------------------------------
    */

    public function widgets(): array
    {
        return [];
    }

    /*
    |--------------------------------------------------------------------------
    | KPIs
    |--------------------------------------------------------------------------
    */

    public function kpis(): array
    {
        return [];
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADO
    |--------------------------------------------------------------------------
    */

    public function enabled(): bool
    {
        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | BOOT
    |--------------------------------------------------------------------------
    */

    public function boot(): void
    {
        // Sin inicialización adicional.
    }
}