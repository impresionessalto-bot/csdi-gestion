<?php

declare(strict_types=1);

namespace App\Modules\Database\Controllers;

use App\Core\BaseController;
use App\Modules\Database\Services\Service;
use RuntimeException;
use Throwable;

/**
 * ============================================================================
 * CSDI ERP PRO
 * DATABASE - CONTROLLER
 * ============================================================================
 *
 * Consola administrativa de base de datos.
 *
 * Responsabilidades:
 *
 * - Autenticación.
 * - Validación de parámetros HTTP.
 * - Coordinación con Database\Service.
 * - Preparación de datos para las vistas.
 *
 * NO contiene SQL.
 * NO accede directamente a PDO.
 * NO contiene lógica de base de datos.
 * NO contiene HTML.
 * NO implementa reglas de negocio.
 *
 * Rutas:
 *
 * GET /admin/database
 * GET /admin/database/estructura?tabla=clientes
 * GET /admin/database/registros?tabla=clientes
 *
 * ============================================================================
 */
final class DatabaseController extends BaseController
{
    /**
     * Constructor.
     */
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    /**
     * Consola principal.
     */
    public function index(): void
    {
        $this->database();
    }

    /*
    |--------------------------------------------------------------------------
    | DATABASE
    |--------------------------------------------------------------------------
    */

    /**
     * Explorador principal de tablas.
     */
    public function database(): void
    {
        $this->requireAuth();

        try {

            $tablas = $this->service->listarTablas();

            if (!is_array($tablas)) {
                $tablas = [];
            }

            $this->moduleView(
                'Database',
                'index',
                [
                    'titulo' => 'Explorador Base de Datos',

                    'tablas' => $tablas,

                    'csrf' => $this->csrf(),

                    'moduleCss' => [
                        '/assets/css/database/style.css',
                    ],

                    'moduleJs' => [
                        '/assets/js/database/script.js',
                    ],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ESTRUCTURA
    |--------------------------------------------------------------------------
    */

    /**
     * Muestra la estructura de una tabla.
     *
     * GET:
     * /admin/database/estructura?tabla=clientes
     */
    public function estructura(): void
    {
        $this->requireAuth();

        try {

            $tabla = $this->obtenerTablaDesdeRequest();

            $columnas = $this->service->verEstructura(
                $tabla
            );

            if (!is_array($columnas)) {
                $columnas = [];
            }

            $this->moduleView(
                'Database',
                'estructura',
                [
                    'titulo' => 'Estructura: ' . $tabla,

                    'tabla' => $tabla,

                    'columnas' => $columnas,

                    'csrf' => $this->csrf(),

                    'moduleCss' => [
                        '/assets/css/database/style.css',
                    ],

                    'moduleJs' => [
                        '/assets/js/database/script.js',
                    ],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTROS
    |--------------------------------------------------------------------------
    */

    /**
     * Muestra los registros de una tabla.
     *
     * GET:
     * /admin/database/registros?tabla=clientes
     */
    public function registros(): void
    {
        $this->requireAuth();

        try {

            $tabla = $this->obtenerTablaDesdeRequest();

            $columnas = $this->service->verEstructura(
                $tabla
            );

            $registros = $this->service->verRegistros(
                $tabla
            );

            if (!is_array($columnas)) {
                $columnas = [];
            }

            if (!is_array($registros)) {
                $registros = [];
            }

            $this->moduleView(
                'Database',
                'registros',
                [
                    'titulo' => 'Registros: ' . $tabla,

                    'tabla' => $tabla,

                    'columnas' => $columnas,

                    'registros' => $registros,

                    'csrf' => $this->csrf(),

                    'moduleCss' => [
                        '/assets/css/database/style.css',
                    ],

                    'moduleJs' => [
                        '/assets/js/database/script.js',
                    ],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene y valida el nombre de tabla recibido por GET.
     *
     * No permitimos nombres arbitrarios.
     *
     * El Repository/Service debe seguir siendo la última barrera
     * de seguridad antes de ejecutar cualquier operación SQL.
     */
    private function obtenerTablaDesdeRequest(): string
    {
        $tabla = trim(
            (string)(
                $_GET['tabla']
                ?? ''
            )
        );

        if ($tabla === '') {
            throw new RuntimeException(
                'No se especificó ninguna tabla.'
            );
        }

        /*
         * Los nombres de tablas MySQL no deben llegar con caracteres
         * extraños desde la URL.
         *
         * Permitimos:
         *
         * letras
         * números
         * guion bajo
         */
        if (
            !preg_match(
                '/^[a-zA-Z0-9_]+$/',
                $tabla
            )
        ) {
            throw new RuntimeException(
                'El nombre de la tabla no es válido.'
            );
        }

        /*
         * Evitamos nombres excesivamente largos.
         */
        if (strlen($tabla) > 64) {
            throw new RuntimeException(
                'El nombre de la tabla es demasiado largo.'
            );
        }

        return $tabla;
    }
}