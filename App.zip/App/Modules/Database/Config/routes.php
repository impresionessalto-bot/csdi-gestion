<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Database\Controllers\DatabaseController;

/*
|--------------------------------------------------------------------------
| DATABASE MODULE
|--------------------------------------------------------------------------
| Consola administrativa de base de datos.
|--------------------------------------------------------------------------
*/

Router::group(
    '/admin',
    ['auth'],
    function (): void {

        Router::get(
            '/database',
            [DatabaseController::class, 'index']
        );

        Router::get(
            '/database/estructura',
            [DatabaseController::class, 'estructura']
        );

        Router::get(
            '/database/registros',
            [DatabaseController::class, 'registros']
        );
    }
);