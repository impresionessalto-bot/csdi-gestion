<?php

declare(strict_types=1);

namespace App\Modules\Database\Services;

use PDO;
use PDOException;
use RuntimeException;
use Throwable;

/**
 * ============================================================================
 * CSDI PRO
 * DATABASE - SERVICE
 * ============================================================================
 *
 * Servicio de exploración administrativa de la base de datos.
 *
 * Responsabilidades:
 *
 * - Listar tablas.
 * - Obtener estructura de tablas.
 * - Obtener registros.
 * - Validar nombres de tablas.
 * - Evitar SQL Injection en identificadores.
 * - Trabajar exclusivamente sobre la base activa del PDO.
 *
 * IMPORTANTE:
 *
 * Este servicio es SOLO de lectura.
 *
 * No:
 * - crea tablas
 * - modifica tablas
 * - elimina tablas
 * - inserta registros
 * - actualiza registros
 * - elimina registros
 *
 * ============================================================================
 */
final class Service
{
    public function __construct(
        private readonly PDO $db
    ) {
    }


    /*
    |--------------------------------------------------------------------------
    | LISTAR TABLAS
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene todas las tablas de la base de datos actualmente seleccionada.
     *
     * @return array<int,string>
     */
    public function listarTablas(): array
    {
        try {

            /*
             * --------------------------------------------------------------
             * Obtener la base actualmente seleccionada por PDO.
             * --------------------------------------------------------------
             */
            $stmtDb = $this->db->query(
                'SELECT DATABASE()'
            );

            $database = $stmtDb
                ? trim(
                    (string)$stmtDb->fetchColumn()
                )
                : '';

            if ($database === '') {
                throw new RuntimeException(
                    'No hay una base de datos seleccionada en la conexión PDO.'
                );
            }


            /*
             * --------------------------------------------------------------
             * INFORMATION_SCHEMA
             * --------------------------------------------------------------
             */
            $stmt = $this->db->prepare(
                "
                SELECT
                    TABLE_NAME
                FROM
                    INFORMATION_SCHEMA.TABLES
                WHERE
                    TABLE_SCHEMA = :database
                    AND TABLE_TYPE = 'BASE TABLE'
                ORDER BY
                    TABLE_NAME ASC
                "
            );

            $stmt->execute([
                ':database' => $database,
            ]);

            $tablas = $stmt->fetchAll(
                PDO::FETCH_COLUMN
            );

            if (!is_array($tablas)) {
                return [];
            }

            /*
             * --------------------------------------------------------------
             * Normalización
             * --------------------------------------------------------------
             */
            $resultado = [];

            foreach ($tablas as $tabla) {

                $tabla = trim(
                    (string)$tabla
                );

                if ($tabla === '') {
                    continue;
                }

                if (
                    !preg_match(
                        '/^[a-zA-Z0-9_]+$/',
                        $tabla
                    )
                ) {
                    continue;
                }

                $resultado[] = $tabla;
            }

            return array_values(
                array_unique($resultado)
            );

        } catch (Throwable $e) {

            error_log(
                '[Database Service::listarTablas] '
                . $e->getMessage()
            );

            return [];
        }
    }


    /*
    |--------------------------------------------------------------------------
    | ESTRUCTURA
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene la estructura completa de una tabla.
     *
     * Devuelve una estructura compatible con:
     *
     * - SHOW COLUMNS
     * - Views existentes del módulo Database
     *
     * Campos devueltos:
     *
     * Field
     * Type
     * Null
     * Key
     * Default
     * Extra
     *
     * @return array<int,array<string,mixed>>
     */
    public function verEstructura(
        string $tabla
    ): array {

        $tabla = trim($tabla);

        $this->validarTabla(
            $tabla
        );


        try {

            /*
             * --------------------------------------------------------------
             * Obtener base de datos activa
             * --------------------------------------------------------------
             */
            $stmtDb = $this->db->query(
                'SELECT DATABASE()'
            );

            if (!$stmtDb) {
                throw new RuntimeException(
                    'No se pudo determinar la base de datos activa.'
                );
            }

            $database = trim(
                (string)$stmtDb->fetchColumn()
            );

            if ($database === '') {
                throw new RuntimeException(
                    'No hay una base de datos activa.'
                );
            }


            /*
             * --------------------------------------------------------------
             * Verificar que la tabla exista realmente.
             * --------------------------------------------------------------
             */
            $stmtExiste = $this->db->prepare(
                "
                SELECT
                    COUNT(*)
                FROM
                    INFORMATION_SCHEMA.TABLES
                WHERE
                    TABLE_SCHEMA = :database
                    AND TABLE_NAME = :tabla
                    AND TABLE_TYPE = 'BASE TABLE'
                "
            );

            $stmtExiste->execute([
                ':database' => $database,
                ':tabla'    => $tabla,
            ]);

            $existe = (int)$stmtExiste->fetchColumn();

            if ($existe <= 0) {

                throw new RuntimeException(
                    "La tabla '{$tabla}' no existe en la base de datos activa."
                );
            }


            /*
             * --------------------------------------------------------------
             * Obtener columnas
             * --------------------------------------------------------------
             */
            $stmt = $this->db->prepare(
                "
                SELECT
                    COLUMN_NAME AS Field,
                    COLUMN_TYPE AS Type,
                    CASE
                        WHEN IS_NULLABLE = 'YES'
                        THEN 'YES'
                        ELSE 'NO'
                    END AS `Null`,
                    COLUMN_KEY AS `Key`,
                    COLUMN_DEFAULT AS `Default`,
                    EXTRA AS Extra
                FROM
                    INFORMATION_SCHEMA.COLUMNS
                WHERE
                    TABLE_SCHEMA = :database
                    AND TABLE_NAME = :tabla
                ORDER BY
                    ORDINAL_POSITION ASC
                "
            );

            $stmt->execute([
                ':database' => $database,
                ':tabla'    => $tabla,
            ]);

            $columnas = $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );

            if (!is_array($columnas)) {
                return [];
            }

            /*
             * --------------------------------------------------------------
             * Normalizar respuesta
             * --------------------------------------------------------------
             */
            $resultado = [];

            foreach ($columnas as $columna) {

                if (!is_array($columna)) {
                    continue;
                }

                $resultado[] = [
                    'Field'   => (string)(
                        $columna['Field']
                        ?? ''
                    ),

                    'Type'    => (string)(
                        $columna['Type']
                        ?? ''
                    ),

                    'Null'    => (string)(
                        $columna['Null']
                        ?? ''
                    ),

                    'Key'     => (string)(
                        $columna['Key']
                        ?? ''
                    ),

                    'Default' => $columna['Default']
                        ?? null,

                    'Extra'   => (string)(
                        $columna['Extra']
                        ?? ''
                    ),
                ];
            }

            return $resultado;

        } catch (PDOException $e) {

            error_log(
                '[Database Service::verEstructura PDO] '
                . 'Tabla: '
                . $tabla
                . ' | '
                . $e->getMessage()
            );

            throw new RuntimeException(
                'No se pudo obtener la estructura de la tabla.',
                (int)$e->getCode(),
                $e
            );

        } catch (Throwable $e) {

            error_log(
                '[Database Service::verEstructura] '
                . 'Tabla: '
                . $tabla
                . ' | '
                . $e->getMessage()
            );

            throw $e;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | REGISTROS
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene los primeros 100 registros de una tabla.
     *
     * @return array<int,array<string,mixed>>
     */
    public function verRegistros(
        string $tabla
    ): array {

        $tabla = trim($tabla);

        $this->validarTabla(
            $tabla
        );

        try {

            /*
             * --------------------------------------------------------------
             * Verificar que exista
             * --------------------------------------------------------------
             */
            $this->verificarTabla(
                $tabla
            );


            /*
             * --------------------------------------------------------------
             * Identificador seguro
             *
             * Los nombres de tabla NO pueden parametrizarse con PDO.
             *
             * validarTabla() garantiza que solamente existan:
             *
             * letras
             * números
             * _
             *
             * --------------------------------------------------------------
             */
            $sql =
                'SELECT * '
                . 'FROM `'
                . $tabla
                . '` '
                . 'LIMIT 100';

            $stmt = $this->db->query(
                $sql
            );

            if (!$stmt) {
                return [];
            }

            $registros = $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );

            return is_array($registros)
                ? $registros
                : [];

        } catch (PDOException $e) {

            error_log(
                '[Database Service::verRegistros PDO] '
                . 'Tabla: '
                . $tabla
                . ' | '
                . $e->getMessage()
            );

            throw new RuntimeException(
                'No se pudieron obtener los registros de la tabla.',
                (int)$e->getCode(),
                $e
            );

        } catch (Throwable $e) {

            error_log(
                '[Database Service::verRegistros] '
                . 'Tabla: '
                . $tabla
                . ' | '
                . $e->getMessage()
            );

            throw $e;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | VERIFICAR TABLA
    |--------------------------------------------------------------------------
    */

    /**
     * Verifica que la tabla exista en la base activa.
     */
    private function verificarTabla(
        string $tabla
    ): void {

        $stmtDb = $this->db->query(
            'SELECT DATABASE()'
        );

        if (!$stmtDb) {
            throw new RuntimeException(
                'No se pudo determinar la base de datos activa.'
            );
        }

        $database = trim(
            (string)$stmtDb->fetchColumn()
        );

        if ($database === '') {
            throw new RuntimeException(
                'No hay una base de datos activa.'
            );
        }

        $stmt = $this->db->prepare(
            "
            SELECT
                COUNT(*)
            FROM
                INFORMATION_SCHEMA.TABLES
            WHERE
                TABLE_SCHEMA = :database
                AND TABLE_NAME = :tabla
                AND TABLE_TYPE = 'BASE TABLE'
            "
        );

        $stmt->execute([
            ':database' => $database,
            ':tabla'    => $tabla,
        ]);

        $existe = (int)$stmt->fetchColumn();

        if ($existe <= 0) {
            throw new RuntimeException(
                "La tabla '{$tabla}' no existe."
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | VALIDAR TABLA
    |--------------------------------------------------------------------------
    */

    /**
     * Valida estrictamente un identificador SQL.
     *
     * No se puede parametrizar un nombre de tabla mediante PDO,
     * por lo que esta validación es obligatoria.
     */
    private function validarTabla(
        string $tabla
    ): void {

        if ($tabla === '') {
            throw new RuntimeException(
                'No se especificó ninguna tabla.'
            );
        }

        if (
            !preg_match(
                '/^[a-zA-Z0-9_]+$/',
                $tabla
            )
        ) {
            throw new RuntimeException(
                'Nombre de tabla inválido.'
            );
        }

        /*
         * Límite defensivo.
         */
        if (strlen($tabla) > 128) {
            throw new RuntimeException(
                'Nombre de tabla demasiado largo.'
            );
        }
    }
}