<?php
declare(strict_types=1);
// Verificación defensiva del contenedor de datos
$diagnostico = $diagnostico ?? [];
$tablas = $diagnostico['tablas'] ?? [];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consola de Base de Datos - CSDI PRO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: system-ui, -apple-system, sans-serif; }
        .card { border-radius: 12px; border: 1px solid #dee2e6; }
        .table-responsive { background: white; border-radius: 12px; padding: 15px; border: 1px solid #dee2e6; }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-1 text-dark fw-bold">Consola de Base de Datos</h1>
            <p class="text-muted mb-0">Auditoría física y rendimiento de almacenamiento del ERP</p>
        </div>
        <span class="badge bg-success-subtle text-success border border-success px-3 py-2">
            Estado: <?= htmlspecialchars((string)($diagnostico['estado'] ?? 'Inactivo')) ?>
        </span>
    </div>

    <!-- Bloque de KPIs Principales -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card p-3 shadow-sm">
                <h6 class="text-muted text-uppercase fs-7 fw-semibold">Versión del Motor</h6>
                <p class="fs-3 fw-bold text-dark mb-0">
                    <?= htmlspecialchars((string)($diagnostico['version'] ?? 'Desconocida')) ?>
                </p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm">
                <h6 class="text-muted text-uppercase fs-7 fw-semibold">Esquema Activo</h6>
                <p class="fs-3 fw-bold text-primary mb-0">
                    <?= htmlspecialchars((string)($diagnostico['schema'] ?? 'Desconocido')) ?>
                </p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 shadow-sm">
                <h6 class="text-muted text-uppercase fs-7 fw-semibold">Peso en Disco Total</h6>
                <p class="fs-3 fw-bold text-danger mb-0">
                    <?= (float)(is_array($diagnostico) ? ($diagnostico['total_mb'] ?? 0.0) : $diagnostico) ?> MB
                </p>
            </div>
        </div>
    </div>

    <!-- Listado Físico de Tablas -->
    <div class="table-responsive shadow-sm">
        <h5 class="fw-bold mb-3 text-dark">Estructura y volumetría de tablas</h5>
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Nombre de la Tabla</th>
                    <th>Motor</th>
                    <th class="text-end">Total de Filas</th>
                    <th class="text-end">Peso Físico (MB)</th>
                    <th class="text-end">Peso de Índices (MB)</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($tablas)): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">No se detectaron tablas en el esquema actual.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($tablas as $row): ?>
                        <tr>
                            <td class="fw-semibold text-dark"><?= htmlspecialchars((string)($row['tabla'] ?? '')) ?></td>
                            <td><span class="badge bg-secondary-subtle text-secondary"><?= htmlspecialchars((string)($row['motor'] ?? '')) ?></span></td>
                            <td class="text-end"><?= number_format((int)($row['filas'] ?? 0)) ?></td>
                            <td class="text-end fw-bold text-dark"><?= number_format((float)($row['tamaño_mb'] ?? 0.0), 2) ?> MB</td>
                            <td class="text-end text-muted"><?= number_format((float)($row['indice_mb'] ?? 0.0), 2) ?> MB</td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>