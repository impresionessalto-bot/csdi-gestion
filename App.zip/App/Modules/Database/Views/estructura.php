<?php
declare(strict_types=1);
$titulo = $titulo ?? 'Estructura de Tabla';
$tabla = $tabla ?? '';
$campos = $campos ?? [];
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">
                <i class="fa-solid fa-columns text-info"></i> <?= h($titulo) ?>
            </h2>
            <p class="text-muted">Definición de campos de la tabla <strong><?= h($tabla) ?></strong></p>
        </div>
        <div>
            <a href="<?= base_url('admin/database') ?>" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Campo</th>
                            <th>Tipo</th>
                            <th>Nulo</th>
                            <th>Clave</th>
                            <th>Por defecto</th>
                            <th>Extra</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($campos)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No se pudo obtener la estructura</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($campos as $c): ?>
                                <tr>
                                    <td><strong><?= h($c['Field'] ?? '') ?></strong></td>
                                    <td><code><?= h($c['Type'] ?? '') ?></code></td>
                                    <td><?= h($c['Null'] ?? '') ?></td>
                                    <td><span class="badge bg-<?= !empty($c['Key']) ? 'warning text-dark' : 'secondary' ?>"><?= h($c['Key'] ?? '') ?></span></td>
                                    <td><?= h($c['Default'] ?? 'NULL') ?></td>
                                    <td><?= h($c['Extra'] ?? '') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>