<?php
declare(strict_types=1);

$titulo = $titulo ?? 'Registros de Tabla';
$tabla = $tabla ?? '';
$registros = $registros ?? [];
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">
                <i class="fa-solid fa-table text-primary"></i> <?= htmlspecialchars($titulo) ?>
            </h2>
            <p class="text-muted">Visualizando registros de la tabla <strong><?= htmlspecialchars($tabla) ?></strong></p>
        </div>
        <div>
            <a href="<?= base_url('admin/database') ?>" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <?php if (!empty($registros) && is_array($registros[0])): ?>
                                <?php foreach (array_keys($registros[0]) as $columna): ?>
                                    <th><?= htmlspecialchars((string)$columna) ?></th>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <th>Información</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($registros)): ?>
                            <tr>
                                <td class="text-center py-4 text-muted">No se encontraron registros en esta tabla.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($registros as $fila): ?>
                                <tr>
                                    <?php foreach ($fila as $valor): ?>
                                        <td><?= htmlspecialchars((string)($valor ?? 'NULL')) ?></td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>