<?php
declare(strict_types=1);

$titulo = $titulo ?? 'Explorador Base de Datos';
$tablas = $tablas ?? [];
?>

<div class="container-fluid py-4">
    
    <!-- =====================================================
         HEADER DE LA SECCIÓN (Con contraste text-dark)
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h2 class="fw-bold text-dark mb-1"> <!-- Cambiado de text-white a text-dark -->
                <i class="fa-solid fa-database text-primary me-2"></i> <?= htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') ?>
            </h2>
            <p class="text-muted small mb-0">
                Consola de administración, volumetría y consultas inteligentes de CSDI PRO
            </p>
        </div>
        <div>
            <!-- Botón de retorno al panel administrativo -->
            <a href="<?= base_url('/admin') ?>" class="btn btn-outline-secondary btn-sm px-3 fw-semibold">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver al Dashboard
            </a>
        </div>
    </div>

    <!-- =====================================================
         NAVEGACIÓN POR PESTAÑAS (Estilo nativo Bootstrap 5 para fondo claro)
         ===================================================== -->
    <ul class="nav nav-tabs mb-4 border-bottom" id="databaseConsoleTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active text-dark fw-bold bg-transparent px-3 py-2 border-bottom border-primary border-0" id="tablas-tab" data-bs-toggle="tab" data-bs-target="#tablas-pane" type="button" role="tab" aria-controls="tablas-pane" aria-selected="true">
                <i class="fa-solid fa-table-list text-primary me-2"></i> Tablas del Sistema
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link text-muted bg-transparent border-0 px-3 py-2 fw-semibold" id="ia-tab" data-bs-toggle="tab" data-bs-target="#ia-pane" type="button" role="tab" aria-controls="ia-pane" aria-selected="false">
                <i class="fa-solid fa-robot text-danger me-2"></i> Asistente IA (CSDI Brain)
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link text-muted bg-transparent border-0 px-3 py-2 fw-semibold" id="diagnostico-tab" data-bs-toggle="tab" data-bs-target="#diagnostico-pane" type="button" role="tab" aria-controls="diagnostico-pane" aria-selected="false">
                <i class="fa-solid fa-circle-info text-info me-2"></i> Estado del Servidor
            </button>
        </li>
    </ul>

    <!-- =====================================================
         CONTENIDO DE LAS PESTAÑAS
         ===================================================== -->
    <div class="tab-content" id="databaseConsoleTabContent">
        
        <!-- ---------------------------------------------------
             PESTAÑA 1: EXPLORADOR DE TABLAS (Fondo Claro)
             --------------------------------------------------- -->
        <div class="tab-pane fade show active" id="tablas-pane" role="tabpanel" aria-labelledby="tablas-tab" tabindex="0">
            
            <!-- Barra de búsqueda rápida -->
            <div class="row mb-3">
                <div class="col-12 col-md-4 ms-auto">
                    <div class="input-group shadow-sm">
                        <span class="input-group-text bg-white border-end-0 text-muted">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </span>
                        <input type="text" id="buscadorTablas" class="form-control border-start-0 ps-0" placeholder="Buscar tabla por nombre...">
                    </div>
                </div>
            </div>

            <!-- Tarjeta y Tabla de Listado Original (Usa bordes y fondo claro) -->
            <div class="card border border-light-subtle shadow-sm rounded-3 overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tablaEstructuraDb">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4 py-3 text-secondary">Tabla</th>
                                <th class="text-end pe-4 text-secondary" width="220">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($tablas)): ?>
                            <tr>
                                <td colspan="2" class="text-center text-muted py-5">
                                    <i class="fa-solid fa-folder-open d-block fs-3 mb-2 text-secondary"></i>
                                    No se encontraron tablas en el esquema actual.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($tablas as $tabla): ?>
                                <?php
                                if (is_array($tabla)) {
                                    $nombre = $tabla['nombre'] ?? $tabla['tabla'] ?? '';
                                } else {
                                    $nombre = (string)$tabla;
                                }
                                ?>
                                <tr class="fila-tabla">
                                    <td class="ps-4 py-3">
                                        <div class="d-flex align-items-center">
                                            <i class="fa-solid fa-table text-secondary me-2 fs-6"></i>
                                            <strong class="nombre-tabla text-dark"> <!-- Cambiado a text-dark -->
                                                <?= h($nombre) ?>
                                            </strong>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= base_url('/admin/database/estructura?tabla=' . urlencode($nombre)) ?>" class="btn btn-outline-info px-2" title="Estructura de Columnas">
                                                <i class="fa-solid fa-columns"></i> Estructura
                                            </a>
                                            <a href="<?= base_url('/admin/database/registros?tabla=' . urlencode($nombre)) ?>" class="btn btn-outline-primary px-2" title="Ver Registros">
                                                <i class="fa-solid fa-table"></i> Registros
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- ---------------------------------------------------
             PESTAÑA 2: ASISTENTE INTELIGENCIA ARTIFICIAL (Chat)
             --------------------------------------------------- -->
        <div class="tab-pane fade" id="ia-pane" role="tabpanel" aria-labelledby="ia-tab" tabindex="0">
            
            <div class="row g-4">
                <div class="col-12 col-lg-8">
                    <!-- Chat del Asistente adaptado al diseño claro -->
                    <div class="card border border-light-subtle shadow-sm rounded-3 overflow-hidden">
                        <div class="bg-light text-dark fw-bold p-3 border-bottom border-light-subtle">
                            <i class="fa-solid fa-comments me-2 text-primary"></i> CSDI Brain - Consultas Inteligentes SQL
                        </div>
                        <div class="p-3 d-flex flex-column justify-content-between" style="min-height: 400px; background-color: #ffffff;">
                            <div id="aiChatContainer" class="mb-3 p-3 border border-light-subtle rounded" style="flex-grow: 1; max-height: 320px; overflow-y: auto; background-color: #f8f9fa;">
                                <p class="text-muted text-center my-auto">Pregúntale a CSDI Brain sobre la estructura de tus tablas o solicita reportes SQL inteligentes...</p>
                            </div>
                            <form id="formAiChat" class="d-flex gap-2">
                                <input type="text" id="aiPromptInput" class="form-control border-light-subtle" placeholder="Ej. ¿Qué campos tiene la tabla clientes?..." required>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa-solid fa-paper-plane"></i> Enviar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-4">
                    <!-- Estado del Motor IA -->
                    <div class="card border border-light-subtle shadow-sm rounded-3 p-4 mb-4" style="background-color: #ffffff;">
                        <h5 class="text-dark fw-bold mb-3">
                            <i class="fa-solid fa-chart-pie text-danger me-2"></i> Estado de CSDI Brain
                        </h5>
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2 d-flex justify-content-between text-secondary">
                                <span>Motor IA:</span>
                                <strong class="text-dark">CSDI AI Optimizer</strong>
                            </li>
                            <li class="mb-2 d-flex justify-content-between text-secondary">
                                <span>Conexión:</span>
                                <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0.5">En Línea</span>
                            </li>
                            <li class="d-flex justify-content-between text-secondary">
                                <span>Version:</span>
                                <strong class="text-dark">1.2.0</strong>
                            </li>
                        </ul>
                    </div>

                    <!-- Comandos sugeridos para la Base de Datos -->
                    <div class="card border border-light-subtle shadow-sm rounded-3 p-4" style="background-color: #ffffff;">
                        <h5 class="text-dark fw-bold mb-3">
                            <i class="fa-solid fa-lightbulb text-warning me-2"></i> Comandos Rápidos IA
                        </h5>
                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-secondary btn-sm text-start text-secondary" type="button" onclick="document.getElementById('aiPromptInput').value = 'Analizar estructura física de la base de datos';">
                                <i class="fa-solid fa-database me-2"></i> Analizar estructura de tablas
                            </button>
                            <button class="btn btn-outline-secondary btn-sm text-start text-secondary" type="button" onclick="document.getElementById('aiPromptInput').value = 'Buscar índices faltantes o duplicados';">
                                <i class="fa-solid fa-key me-2"></i> Revisar claves e índices
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- ---------------------------------------------------
             PESTAÑA 3: DIAGNÓSTICO Y ESTADO DEL SERVIDOR SQL (Contraste Claro)
             --------------------------------------------------- -->
        <div class="tab-pane fade" id="diagnostico-pane" role="tabpanel" aria-labelledby="diagnostico-tab" tabindex="0">
            
            <div class="card border border-light-subtle shadow-sm rounded-3 p-4" style="background-color: #ffffff;">
                <h5 class="text-dark fw-bold mb-3"> <!-- Cambiado de text-white a text-dark -->
                    <i class="fa-solid fa-server text-info me-2"></i> Estado de Infraestructura de Datos
                </h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-3 d-flex justify-content-between border-bottom pb-2 text-secondary"> <!-- Cambiado de text-white-50 a text-secondary -->
                        <span>Motor de Base de Datos:</span>
                        <strong class="text-dark">MySQL (InnoDB Transaccional)</strong> <!-- Cambiado de text-white a text-dark -->
                    </li>
                    <li class="mb-3 d-flex justify-content-between border-bottom pb-2 text-secondary">
                        <span>Esquema de Datos Activo:</span>
                        <strong class="text-dark">w270276_conta</strong>
                    </li>
                    <li class="mb-3 d-flex justify-content-between border-bottom pb-2 text-secondary">
                        <span>Total de Tablas Registradas:</span>
                        <strong class="text-dark"><?= count($tablas) ?></strong>
                    </li>
                    <li class="d-flex justify-content-between text-secondary">
                        <span>Entorno Operativo:</span>
                        <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-1 fw-bold">Activo y Estable</span>
                    </li>
                </ul>
            </div>

        </div>

    </div>
</div>

<!-- =====================================================
     SCRIPTS AUXILIARES
     ===================================================== -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Buscador instantáneo de tablas
        const buscador = document.getElementById('buscadorTablas');
        const filas = document.querySelectorAll('.fila-tabla');

        if (buscador) {
            buscador.addEventListener('keyup', function() {
                const busqueda = this.value.toLowerCase().trim();

                filas.forEach(fila => {
                    const nombreTabla = fila.querySelector('.nombre-tabla').textContent.toLowerCase();
                    if (nombreTabla.includes(busqueda)) {
                        fila.style.display = ''; 
                    } else {
                        fila.style.display = 'none'; 
                    }
                });
            });
        }

        // 2. Interacción básica del Chat del Asistente en caliente
        const formChat = document.getElementById('formAiChat');
        const inputPrompt = document.getElementById('aiPromptInput');
        const containerChat = document.getElementById('aiChatContainer');

        if (formChat && inputPrompt && containerChat) {
            formChat.addEventListener('submit', function(e) {
                e.preventDefault();
                const prompt = inputPrompt.value.trim();
                if (prompt === '') return;

                // Limpiar mensaje por defecto si existe
                if (containerChat.querySelector('.text-muted') || containerChat.querySelector('.text-center')) {
                    containerChat.innerHTML = '';
                }

                // Añadir mensaje de usuario al chat
                containerChat.innerHTML += `<div class="mb-2 text-end"><span class="badge bg-primary text-wrap text-start p-2" style="max-width: 85%;">${prompt}</span></div>`;
                
                // Respuesta simulada de CSDI Brain para base de datos
                setTimeout(() => {
                    containerChat.innerHTML += `<div class="mb-2"><span class="badge text-wrap text-start p-2" style="max-width: 85%; background-color: #e9ecef !important; color: #212529 !important;"><i class="fa-solid fa-robot me-1 text-danger"></i> Analizando el esquema para: "${prompt}". Cargando telemetría...</span></div>`;
                    containerChat.scrollTop = containerChat.scrollHeight;
                }, 800);

                inputPrompt.value = '';
                containerChat.scrollTop = containerChat.scrollHeight;
            });
        }
    });
</script>