<?php

declare(strict_types=1);

namespace App\Modules\Compras\Repositories;

use App\Core\Container;
use PDO;
use RuntimeException;
use Throwable;

final class Repository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Container::getInstance()->db();

        $this->db->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

        $this->db->setAttribute(
            PDO::ATTR_DEFAULT_FETCH_MODE,
            PDO::FETCH_ASSOC
        );

        $this->db->setAttribute(
            PDO::ATTR_EMULATE_PREPARES,
            false
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function resumen(): array
    {
        $this->asegurarTablas();

        $stmt = $this->db->query("
            SELECT
                COUNT(*) AS total,

                COALESCE(
                    SUM(estado = 'BORRADOR'),
                    0
                ) AS borradores,

                COALESCE(
                    SUM(estado = 'PENDIENTE'),
                    0
                ) AS pendientes,

                COALESCE(
                    SUM(estado = 'CONFIRMADA'),
                    0
                ) AS confirmadas,

                COALESCE(
                    SUM(estado = 'RECIBIDA'),
                    0
                ) AS recibidas,

                COALESCE(
                    SUM(estado = 'ANULADA'),
                    0
                ) AS anuladas,

                COALESCE(
                    SUM(
                        CASE
                            WHEN estado IN (
                                'CONFIRMADA',
                                'RECIBIDA'
                            )
                            THEN total
                            ELSE 0
                        END
                    ),
                    0
                ) AS importe_total

            FROM compras
        ");

        return $stmt->fetch() ?: [];
    }

    public function ultimas(int $limit = 10): array
    {
        $this->asegurarTablas();

        $limit = max(
            1,
            min($limit, 100)
        );

        $stmt = $this->db->query("
            SELECT
                c.*,
                p.nombre AS proveedor_nombre
            FROM compras c
            LEFT JOIN proveedores p
                ON p.id = c.proveedor_id
            ORDER BY
                c.fecha DESC,
                c.id DESC
            LIMIT {$limit}
        ");

        return $stmt->fetchAll();
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAR
    |--------------------------------------------------------------------------
    */

    public function listar(array $filtros = []): array
    {
        $this->asegurarTablas();

        $where = [];
        $params = [];

        /*
        |--------------------------------------------------------------------------
        | EMPRESA
        |--------------------------------------------------------------------------
        |
        | Si el llamador proporciona empresa_id se respeta.
        | No se fuerza un valor 1 en las consultas.
        |
        */

        if (
            isset($filtros['empresa_id'])
            && (int) $filtros['empresa_id'] > 0
        ) {
            $where[] = 'c.empresa_id = :empresa_id';

            $params['empresa_id'] =
                (int) $filtros['empresa_id'];
        }

        /*
        |--------------------------------------------------------------------------
        | ESTADO
        |--------------------------------------------------------------------------
        */

        if (!empty($filtros['estado'])) {
            $where[] = 'c.estado = :estado';

            $params['estado'] =
                strtoupper(
                    trim(
                        (string) $filtros['estado']
                    )
                );
        }

        /*
        |--------------------------------------------------------------------------
        | PROVEEDOR
        |--------------------------------------------------------------------------
        */

        if (
            isset($filtros['proveedor_id'])
            && (int) $filtros['proveedor_id'] > 0
        ) {
            $where[] =
                'c.proveedor_id = :proveedor_id';

            $params['proveedor_id'] =
                (int) $filtros['proveedor_id'];
        }

        /*
        |--------------------------------------------------------------------------
        | FECHAS
        |--------------------------------------------------------------------------
        */

        if (!empty($filtros['desde'])) {
            $where[] =
                'c.fecha >= :desde';

            $params['desde'] =
                trim(
                    (string) $filtros['desde']
                );
        }

        if (!empty($filtros['hasta'])) {
            $where[] =
                'c.fecha <= :hasta';

            $params['hasta'] =
                trim(
                    (string) $filtros['hasta']
                );
        }

        /*
        |--------------------------------------------------------------------------
        | BÚSQUEDA
        |--------------------------------------------------------------------------
        */

        $q =
            $filtros['q']
            ?? $filtros['buscar']
            ?? '';

        $q = trim((string) $q);

        if ($q !== '') {
            $where[] = "
                (
                    c.numero LIKE :q
                    OR p.nombre LIKE :q
                    OR c.observacion LIKE :q
                )
            ";

            $params['q'] =
                '%' . $q . '%';
        }

        /*
        |--------------------------------------------------------------------------
        | ID
        |--------------------------------------------------------------------------
        */

        if (
            isset($filtros['id'])
            && (int) $filtros['id'] > 0
        ) {
            $where[] =
                'c.id = :id';

            $params['id'] =
                (int) $filtros['id'];
        }

        /*
        |--------------------------------------------------------------------------
        | SQL
        |--------------------------------------------------------------------------
        */

        $sql = "
            SELECT
                c.*,
                p.nombre AS proveedor_nombre
            FROM compras c
            LEFT JOIN proveedores p
                ON p.id = c.proveedor_id
        ";

        if ($where) {
            $sql .=
                ' WHERE '
                . implode(
                    ' AND ',
                    $where
                );
        }

        $sql .= "
            ORDER BY
                c.fecha DESC,
                c.id DESC
        ";

        /*
        |--------------------------------------------------------------------------
        | PAGINACIÓN
        |--------------------------------------------------------------------------
        */

        if (
            isset($filtros['limit'])
            && (int) $filtros['limit'] > 0
        ) {
            $limit = max(
                1,
                min(
                    (int) $filtros['limit'],
                    500
                )
            );

            $sql .=
                " LIMIT {$limit}";

            if (
                isset($filtros['offset'])
                && (int) $filtros['offset'] > 0
            ) {
                $offset = max(
                    0,
                    (int) $filtros['offset']
                );

                $sql .=
                    " OFFSET {$offset}";
            }
        }

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER
    |--------------------------------------------------------------------------
    */

    public function obtener(int $id): ?array
    {
        $this->asegurarTablas();

        if ($id <= 0) {
            return null;
        }

        $stmt = $this->db->prepare("
            SELECT
                c.*,
                p.nombre AS proveedor_nombre
            FROM compras c
            LEFT JOIN proveedores p
                ON p.id = c.proveedor_id
            WHERE c.id = :id
            LIMIT 1
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        $compra =
            $stmt->fetch();

        if (!$compra) {
            return null;
        }

        $compra['items'] =
            $this->items($id);

        return $compra;
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(
        array $cabecera,
        array $items
    ): int {
        $this->asegurarTablas();

        if (!$items) {
            throw new RuntimeException(
                'La compra debe contener al menos un artículo.'
            );
        }

        $empresaId =
            filter_var(
                $cabecera['empresa_id'] ?? null,
                FILTER_VALIDATE_INT
            );

        if (
            $empresaId === false
            || $empresaId <= 0
        ) {
            throw new RuntimeException(
                'La empresa de la compra no es válida.'
            );
        }

        $proveedorId =
            filter_var(
                $cabecera['proveedor_id'] ?? null,
                FILTER_VALIDATE_INT
            );

        if (
            $proveedorId === false
            || $proveedorId <= 0
        ) {
            throw new RuntimeException(
                'El proveedor de la compra no es válido.'
            );
        }

        $fecha =
            trim(
                (string) (
                    $cabecera['fecha']
                    ?? date('Y-m-d')
                )
            );

        if (
            $fecha === ''
            || !$this->fechaValida($fecha)
        ) {
            throw new RuntimeException(
                'La fecha de la compra no es válida.'
            );
        }

        $this->db->beginTransaction();

        try {
            $subtotal = 0.0;

            $itemsNormalizados = [];

            foreach ($items as $item) {
                $insumoId =
                    filter_var(
                        $item['insumo_id'] ?? null,
                        FILTER_VALIDATE_INT
                    );

                if (
                    $insumoId === false
                    || $insumoId <= 0
                ) {
                    throw new RuntimeException(
                        'Artículo de compra inválido.'
                    );
                }

                $cantidad =
                    $this->numeroPositivo(
                        $item['cantidad'] ?? null
                    );

                if ($cantidad === null) {
                    throw new RuntimeException(
                        'La cantidad debe ser mayor que cero.'
                    );
                }

                $precio =
                    $this->numeroNoNegativo(
                        $item['precio_unitario'] ?? null
                    );

                if ($precio === null) {
                    throw new RuntimeException(
                        'El precio unitario no puede ser negativo.'
                    );
                }

                $this->verificarInsumo(
                    $insumoId,
                    $empresaId
                );

                $itemSubtotal =
                    round(
                        $cantidad * $precio,
                        2
                    );

                $subtotal +=
                    $itemSubtotal;

                $itemsNormalizados[] = [
                    'insumo_id' =>
                        $insumoId,

                    'cantidad' =>
                        $cantidad,

                    'precio_unitario' =>
                        $precio,

                    'subtotal' =>
                        $itemSubtotal,
                ];
            }

            $descuento =
                $this->numeroNoNegativo(
                    $cabecera['descuento'] ?? 0
                );

            if ($descuento === null) {
                $descuento = 0.0;
            }

            $iva =
                $this->numeroNoNegativo(
                    $cabecera['iva'] ?? 0
                );

            if ($iva === null) {
                $iva = 0.0;
            }

            $total =
                round(
                    $subtotal
                    + $iva
                    - $descuento,
                    2
                );

            $total =
                max(
                    0,
                    $total
                );

            $numero =
                trim(
                    (string) (
                        $cabecera['numero']
                        ?? ''
                    )
                );

            if ($numero === '') {
                $numero =
                    $this->generarNumero();
            }

            $moneda =
                strtoupper(
                    trim(
                        (string) (
                            $cabecera['moneda']
                            ?? 'ARS'
                        )
                    )
                );

            if ($moneda === '') {
                $moneda = 'ARS';
            }

            $cotizacion =
                $cabecera['cotizacion_usd']
                ?? null;

            if ($moneda === 'USD') {
                $cotizacion =
                    $this->numeroPositivo(
                        $cotizacion
                    );

                if ($cotizacion === null) {
                    throw new RuntimeException(
                        'La cotización USD debe ser mayor que cero.'
                    );
                }
            } elseif ($cotizacion !== null && $cotizacion !== '') {
                $cotizacion =
                    $this->numeroPositivo(
                        $cotizacion
                    );
            }

            $stmt = $this->db->prepare("
                INSERT INTO compras (
                    empresa_id,
                    proveedor_id,
                    numero,
                    fecha,
                    estado,
                    subtotal,
                    descuento,
                    iva,
                    total,
                    observacion,
                    moneda,
                    cotizacion_usd,
                    usuario_id,
                    created_at,
                    updated_at
                ) VALUES (
                    :empresa_id,
                    :proveedor_id,
                    :numero,
                    :fecha,
                    'BORRADOR',
                    :subtotal,
                    :descuento,
                    :iva,
                    :total,
                    :observacion,
                    :moneda,
                    :cotizacion_usd,
                    :usuario_id,
                    NOW(),
                    NOW()
                )
            ");

            $stmt->execute([
                'empresa_id' =>
                    $empresaId,

                'proveedor_id' =>
                    $proveedorId,

                'numero' =>
                    $numero,

                'fecha' =>
                    $fecha,

                'subtotal' =>
                    $subtotal,

                'descuento' =>
                    $descuento,

                'iva' =>
                    $iva,

                'total' =>
                    $total,

                'observacion' =>
                    $this->nullableString(
                        $cabecera['observacion'] ?? null
                    ),

                'moneda' =>
                    $moneda,

                'cotizacion_usd' =>
                    $cotizacion,

                'usuario_id' =>
                    $this->nullablePositiveInt(
                        $cabecera['usuario_id'] ?? null
                    ),
            ]);

            $compraId =
                (int) $this->db->lastInsertId();

            if ($compraId <= 0) {
                throw new RuntimeException(
                    'No se pudo obtener el ID de la compra.'
                );
            }

            $stmtItem =
                $this->db->prepare("
                    INSERT INTO compras_items (
                        compra_id,
                        insumo_id,
                        cantidad,
                        precio_unitario,
                        subtotal,
                        created_at
                    ) VALUES (
                        :compra_id,
                        :insumo_id,
                        :cantidad,
                        :precio_unitario,
                        :subtotal,
                        NOW()
                    )
                ");

            foreach ($itemsNormalizados as $item) {
                $stmtItem->execute([
                    'compra_id' =>
                        $compraId,

                    'insumo_id' =>
                        $item['insumo_id'],

                    'cantidad' =>
                        $item['cantidad'],

                    'precio_unitario' =>
                        $item['precio_unitario'],

                    'subtotal' =>
                        $item['subtotal'],
                ]);
            }

            $this->db->commit();

            return $compraId;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(
        int $id,
        array $data
    ): bool {
        $this->asegurarTablas();

        if ($id <= 0) {
            throw new RuntimeException(
                'Compra inválida.'
            );
        }

        $compra =
            $this->obtenerCabecera($id);

        if (!$compra) {
            throw new RuntimeException(
                'Compra no encontrada.'
            );
        }

        $estado =
            strtoupper(
                (string) (
                    $compra['estado'] ?? ''
                )
            );

        if (
            in_array(
                $estado,
                [
                    'CONFIRMADA',
                    'RECIBIDA',
                    'ANULADA',
                    'CERRADA',
                ],
                true
            )
        ) {
            throw new RuntimeException(
                'La compra no puede modificarse en su estado actual.'
            );
        }

        if (!$data) {
            return false;
        }

        $permitidos = [
            'proveedor_id',
            'numero',
            'fecha',
            'observacion',
            'moneda',
            'cotizacion_usd',
            'descuento',
            'iva',
        ];

        $sets = [];
        $params = [
            'id' => $id,
        ];

        foreach ($permitidos as $campo) {
            if (
                !array_key_exists(
                    $campo,
                    $data
                )
            ) {
                continue;
            }

            switch ($campo) {
                case 'proveedor_id':
                    $valor =
                        filter_var(
                            $data[$campo],
                            FILTER_VALIDATE_INT
                        );

                    if (
                        $valor === false
                        || $valor <= 0
                    ) {
                        throw new RuntimeException(
                            'El proveedor no es válido.'
                        );
                    }

                    $sets[] =
                        'proveedor_id = :proveedor_id';

                    $params[$campo] =
                        $valor;

                    break;

                case 'fecha':
                    $fecha =
                        trim(
                            (string) $data[$campo]
                        );

                    if (
                        !$this->fechaValida($fecha)
                    ) {
                        throw new RuntimeException(
                            'La fecha no es válida.'
                        );
                    }

                    $sets[] =
                        'fecha = :fecha';

                    $params[$campo] =
                        $fecha;

                    break;

                case 'numero':
                    $numero =
                        trim(
                            (string) $data[$campo]
                        );

                    if ($numero === '') {
                        throw new RuntimeException(
                            'El número de compra no puede quedar vacío.'
                        );
                    }

                    $sets[] =
                        'numero = :numero';

                    $params[$campo] =
                        $numero;

                    break;

                case 'moneda':
                    $moneda =
                        strtoupper(
                            trim(
                                (string) $data[$campo]
                            )
                        );

                    if ($moneda === '') {
                        throw new RuntimeException(
                            'La moneda no es válida.'
                        );
                    }

                    $sets[] =
                        'moneda = :moneda';

                    $params[$campo] =
                        $moneda;

                    break;

                case 'cotizacion_usd':
                    $valor =
                        $data[$campo];

                    if (
                        $valor === null
                        || $valor === ''
                    ) {
                        $valor = null;
                    } else {
                        $valor =
                            $this->numeroPositivo(
                                $valor
                            );

                        if ($valor === null) {
                            throw new RuntimeException(
                                'La cotización USD no es válida.'
                            );
                        }
                    }

                    $sets[] =
                        'cotizacion_usd = :cotizacion_usd';

                    $params[$campo] =
                        $valor;

                    break;

                case 'descuento':
                case 'iva':
                    $valor =
                        $this->numeroNoNegativo(
                            $data[$campo]
                        );

                    if ($valor === null) {
                        throw new RuntimeException(
                            "El campo {$campo} no es válido."
                        );
                    }

                    $sets[] =
                        "{$campo} = :{$campo}";

                    $params[$campo] =
                        $valor;

                    break;

                case 'observacion':
                    $sets[] =
                        'observacion = :observacion';

                    $params[$campo] =
                        $this->nullableString(
                            $data[$campo]
                        );

                    break;
            }
        }

        if (!$sets) {
            return false;
        }

        /*
        |--------------------------------------------------------------------------
        | Recalcular total si cambia descuento o IVA
        |--------------------------------------------------------------------------
        */

        if (
            array_key_exists('descuento', $data)
            || array_key_exists('iva', $data)
        ) {
            $subtotal =
                (float) (
                    $compra['subtotal']
                    ?? 0
                );

            $descuento =
                array_key_exists(
                    'descuento',
                    $data
                )
                    ? (float) $data['descuento']
                    : (float) (
                        $compra['descuento']
                        ?? 0
                    );

            $iva =
                array_key_exists(
                    'iva',
                    $data
                )
                    ? (float) $data['iva']
                    : (float) (
                        $compra['iva']
                        ?? 0
                    );

            $total =
                max(
                    0,
                    round(
                        $subtotal
                        + $iva
                        - $descuento,
                        2
                    )
                );

            $sets[] =
                'total = :total';

            $params['total'] =
                $total;
        }

        $sets[] =
            'updated_at = NOW()';

        $sql = "
            UPDATE compras
            SET "
            . implode(
                ', ',
                $sets
            )
            . "
            WHERE id = :id
        ";

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->rowCount() > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | ITEMS
    |--------------------------------------------------------------------------
    */

    public function items(int $compraId): array
    {
        $this->asegurarTablas();

        if ($compraId <= 0) {
            return [];
        }

        $stmt = $this->db->prepare("
            SELECT
                ci.*,
                i.nombre_insumo,
                i.codigo_parte,
                i.unidad_medida,
                i.stock_actual,
                i.precio_costo
            FROM compras_items ci
            LEFT JOIN insumos i
                ON i.id = ci.insumo_id
            WHERE ci.compra_id = :compra_id
            ORDER BY ci.id ASC
        ");

        $stmt->execute([
            'compra_id' => $compraId,
        ]);

        return $stmt->fetchAll();
    }

    public function agregarItem(
        int $compraId,
        array $data
    ): int {
        $this->asegurarTablas();

        $this->validarCompraEditable(
            $compraId
        );

        $insumoId =
            filter_var(
                $data['insumo_id'] ?? null,
                FILTER_VALIDATE_INT
            );

        if (
            $insumoId === false
            || $insumoId <= 0
        ) {
            throw new RuntimeException(
                'El artículo no es válido.'
            );
        }

        $cantidad =
            $this->numeroPositivo(
                $data['cantidad'] ?? null
            );

        if ($cantidad === null) {
            throw new RuntimeException(
                'La cantidad debe ser mayor que cero.'
            );
        }

        $precio =
            $this->numeroNoNegativo(
                $data['precio_unitario'] ?? null
            );

        if ($precio === null) {
            throw new RuntimeException(
                'El precio unitario no puede ser negativo.'
            );
        }

        $this->verificarInsumo(
            $insumoId,
            (int) (
                $this->obtenerCabecera($compraId)['empresa_id']
                ?? 0
            )
        );

        $subtotal =
            round(
                $cantidad * $precio,
                2
            );

        $stmt = $this->db->prepare("
            INSERT INTO compras_items (
                compra_id,
                insumo_id,
                cantidad,
                precio_unitario,
                subtotal,
                created_at
            ) VALUES (
                :compra_id,
                :insumo_id,
                :cantidad,
                :precio_unitario,
                :subtotal,
                NOW()
            )
        ");

        $stmt->execute([
            'compra_id' =>
                $compraId,

            'insumo_id' =>
                $insumoId,

            'cantidad' =>
                $cantidad,

            'precio_unitario' =>
                $precio,

            'subtotal' =>
                $subtotal,
        ]);

        $itemId =
            (int) $this->db->lastInsertId();

        $this->recalcular(
            $compraId
        );

        return $itemId;
    }

    public function actualizarItem(
        int $itemId,
        array $data
    ): bool {
        $this->asegurarTablas();

        $item =
            $this->obtenerItem($itemId);

        if (!$item) {
            throw new RuntimeException(
                'Artículo de compra no encontrado.'
            );
        }

        $compraId =
            (int) $item['compra_id'];

        $this->validarCompraEditable(
            $compraId
        );

        $cantidad =
            $this->numeroPositivo(
                $data['cantidad'] ?? null
            );

        if ($cantidad === null) {
            throw new RuntimeException(
                'La cantidad debe ser mayor que cero.'
            );
        }

        $precio =
            $this->numeroNoNegativo(
                $data['precio_unitario'] ?? null
            );

        if ($precio === null) {
            throw new RuntimeException(
                'El precio unitario no puede ser negativo.'
            );
        }

        $subtotal =
            round(
                $cantidad * $precio,
                2
            );

        $stmt = $this->db->prepare("
            UPDATE compras_items
            SET
                cantidad = :cantidad,
                precio_unitario = :precio,
                subtotal = :subtotal
            WHERE id = :id
        ");

        $stmt->execute([
            'cantidad' =>
                $cantidad,

            'precio' =>
                $precio,

            'subtotal' =>
                $subtotal,

            'id' =>
                $itemId,
        ]);

        $modificado =
            $stmt->rowCount() > 0;

        $this->recalcular(
            $compraId
        );

        return $modificado;
    }

    public function eliminarItem(
        int $itemId
    ): bool {
        $this->asegurarTablas();

        $item =
            $this->obtenerItem($itemId);

        if (!$item) {
            return false;
        }

        $compraId =
            (int) $item['compra_id'];

        $this->validarCompraEditable(
            $compraId
        );

        $stmt = $this->db->prepare("
            DELETE FROM compras_items
            WHERE id = :id
        ");

        $stmt->execute([
            'id' => $itemId,
        ]);

        $eliminado =
            $stmt->rowCount() > 0;

        $this->recalcular(
            $compraId
        );

        return $eliminado;
    }

    public function reemplazarItems(
        int $compraId,
        array $items
    ): void {
        $this->asegurarTablas();

        $this->validarCompraEditable(
            $compraId
        );

        if (!$items) {
            throw new RuntimeException(
                'La compra debe contener al menos un artículo.'
            );
        }

        $compra =
            $this->obtenerCabecera(
                $compraId
            );

        if (!$compra) {
            throw new RuntimeException(
                'Compra no encontrada.'
            );
        }

        $empresaId =
            (int) (
                $compra['empresa_id']
                ?? 0
            );

        $this->db->beginTransaction();

        try {
            $stmtDelete =
                $this->db->prepare("
                    DELETE FROM compras_items
                    WHERE compra_id = :id
                ");

            $stmtDelete->execute([
                'id' => $compraId,
            ]);

            $stmtInsert =
                $this->db->prepare("
                    INSERT INTO compras_items (
                        compra_id,
                        insumo_id,
                        cantidad,
                        precio_unitario,
                        subtotal,
                        created_at
                    ) VALUES (
                        :compra_id,
                        :insumo_id,
                        :cantidad,
                        :precio_unitario,
                        :subtotal,
                        NOW()
                    )
                ");

            foreach ($items as $item) {
                $insumoId =
                    filter_var(
                        $item['insumo_id'] ?? null,
                        FILTER_VALIDATE_INT
                    );

                if (
                    $insumoId === false
                    || $insumoId <= 0
                ) {
                    throw new RuntimeException(
                        'Artículo de compra inválido.'
                    );
                }

                $cantidad =
                    $this->numeroPositivo(
                        $item['cantidad'] ?? null
                    );

                if ($cantidad === null) {
                    throw new RuntimeException(
                        'La cantidad debe ser mayor que cero.'
                    );
                }

                $precio =
                    $this->numeroNoNegativo(
                        $item['precio_unitario'] ?? null
                    );

                if ($precio === null) {
                    throw new RuntimeException(
                        'El precio unitario no puede ser negativo.'
                    );
                }

                $this->verificarInsumo(
                    $insumoId,
                    $empresaId
                );

                $subtotal =
                    round(
                        $cantidad * $precio,
                        2
                    );

                $stmtInsert->execute([
                    'compra_id' =>
                        $compraId,

                    'insumo_id' =>
                        $insumoId,

                    'cantidad' =>
                        $cantidad,

                    'precio_unitario' =>
                        $precio,

                    'subtotal' =>
                        $subtotal,
                ]);
            }

            $this->recalcular(
                $compraId
            );

            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RECALCULAR
    |--------------------------------------------------------------------------
    */

    public function recalcular(
        int $id
    ): array {
        $this->asegurarTablas();

        if ($id <= 0) {
            throw new RuntimeException(
                'Compra inválida.'
            );
        }

        $stmt = $this->db->prepare("
            SELECT
                COALESCE(
                    SUM(subtotal),
                    0
                ) AS subtotal
            FROM compras_items
            WHERE compra_id = :id
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        $subtotal =
            (float) (
                $stmt->fetchColumn()
                ?: 0
            );

        $stmt = $this->db->prepare("
            SELECT
                descuento,
                iva
            FROM compras
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        $cabecera =
            $stmt->fetch();

        if (!$cabecera) {
            throw new RuntimeException(
                'Compra no encontrada.'
            );
        }

        $descuento =
            (float) (
                $cabecera['descuento']
                ?? 0
            );

        $iva =
            (float) (
                $cabecera['iva']
                ?? 0
            );

        $total =
            max(
                0,
                round(
                    $subtotal
                    + $iva
                    - $descuento,
                    2
                )
            );

        $stmt = $this->db->prepare("
            UPDATE compras
            SET
                subtotal = :subtotal,
                total = :total,
                updated_at = NOW()
            WHERE id = :id
        ");

        $stmt->execute([
            'subtotal' =>
                $subtotal,

            'total' =>
                $total,

            'id' =>
                $id,
        ]);

        return [
            'subtotal' =>
                $subtotal,

            'descuento' =>
                $descuento,

            'iva' =>
                $iva,

            'total' =>
                $total,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | CONFIRMAR
    |--------------------------------------------------------------------------
    */

    public function confirmar(
        int $id
    ): bool {
        $this->asegurarTablas();

        if ($id <= 0) {
            return false;
        }

        $this->verificarTieneItems(
            $id
        );

        $stmt = $this->db->prepare("
            UPDATE compras
            SET
                estado = 'CONFIRMADA',
                updated_at = NOW()
            WHERE id = :id
              AND estado = 'BORRADOR'
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        return $stmt->rowCount() > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | ANULAR
    |--------------------------------------------------------------------------
    */

    public function anular(
        int $id,
        ?string $motivo = null
    ): bool {
        $this->asegurarTablas();

        if ($id <= 0) {
            return false;
        }

        $compra =
            $this->obtenerCabecera($id);

        if (!$compra) {
            throw new RuntimeException(
                'Compra no encontrada.'
            );
        }

        $estado =
            strtoupper(
                (string) (
                    $compra['estado'] ?? ''
                )
            );

        if ($estado === 'ANULADA') {
            return false;
        }

        if ($estado === 'RECIBIDA') {
            throw new RuntimeException(
                'Una compra recibida no puede anularse desde este circuito.'
            );
        }

        $stmt = $this->db->prepare("
            UPDATE compras
            SET
                estado = 'ANULADA',
                motivo_anulacion = :motivo,
                fecha_anulacion = NOW(),
                updated_at = NOW()
            WHERE id = :id
              AND estado <> 'ANULADA'
        ");

        $stmt->execute([
            'id' =>
                $id,

            'motivo' =>
                $this->nullableString(
                    $motivo
                ),
        ]);

        return $stmt->rowCount() > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | RECEPCIONES
    |--------------------------------------------------------------------------
    */

    public function recepciones(
        array $filtros = []
    ): array {
        $this->asegurarTablas();

        $where = [
            "c.estado IN ('CONFIRMADA', 'PENDIENTE')",
        ];

        $params = [];

        if (
            isset($filtros['empresa_id'])
            && (int) $filtros['empresa_id'] > 0
        ) {
            $where[] =
                'c.empresa_id = :empresa_id';

            $params['empresa_id'] =
                (int) $filtros['empresa_id'];
        }

        $limit = max(
            1,
            min(
                (int) (
                    $filtros['limit']
                    ?? 50
                ),
                200
            )
        );

        $sql = "
            SELECT
                c.*,
                p.nombre AS proveedor_nombre
            FROM compras c
            LEFT JOIN proveedores p
                ON p.id = c.proveedor_id
            WHERE "
            . implode(
                ' AND ',
                $where
            )
            . "
            ORDER BY
                c.fecha ASC,
                c.id ASC
            LIMIT {$limit}
        ";

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    public function pendientes(
        int $limit = 10
    ): array {
        return $this->recepciones([
            'limit' => $limit,
        ]);
    }

    public function pendientesRecepcion(
        int $id
    ): array {
        $compra =
            $this->obtenerCabecera($id);

        if (!$compra) {
            return [];
        }

        $estado =
            strtoupper(
                (string) (
                    $compra['estado'] ?? ''
                )
            );

        if (
            !in_array(
                $estado,
                [
                    'CONFIRMADA',
                    'PENDIENTE',
                ],
                true
            )
        ) {
            return [];
        }

        $items =
            $this->items($id);

        foreach ($items as &$item) {
            $item['cantidad_pendiente'] =
                (float) (
                    $item['cantidad']
                    ?? 0
                );

            $item['cantidad_recibida'] =
                0.0;
        }

        unset($item);

        return $items;
    }

    /*
    |--------------------------------------------------------------------------
    | RECIBIR
    |--------------------------------------------------------------------------
    |
    | La recepción es TOTAL.
    |
    | En una única transacción:
    |
    | 1. Verifica la compra.
    | 2. Verifica todos los insumos.
    | 3. Incrementa insumos.stock_actual.
    | 4. Registra stock_movimientos.
    | 5. Cambia la compra a RECIBIDA.
    |
    */

    public function recibir(
        int $id,
        array $data = [],
        ?int $usuarioId = null
    ): array {
        $this->asegurarTablas();

        if ($id <= 0) {
            throw new RuntimeException(
                'Compra inválida.'
            );
        }

        $compra =
            $this->obtenerCabecera(
                $id
            );

        if (!$compra) {
            throw new RuntimeException(
                'Compra no encontrada.'
            );
        }

        $estado =
            strtoupper(
                (string) (
                    $compra['estado'] ?? ''
                )
            );

        if ($estado === 'RECIBIDA') {
            throw new RuntimeException(
                'La compra ya fue recibida.'
            );
        }

        if ($estado === 'ANULADA') {
            throw new RuntimeException(
                'Una compra anulada no puede recibirse.'
            );
        }

        if (
            !in_array(
                $estado,
                [
                    'CONFIRMADA',
                    'PENDIENTE',
                ],
                true
            )
        ) {
            throw new RuntimeException(
                'La compra no está disponible para recepción.'
            );
        }

        $items =
            $this->items($id);

        if (!$items) {
            throw new RuntimeException(
                'La compra no contiene artículos.'
            );
        }

        $empresaId =
            (int) (
                $compra['empresa_id']
                ?? 0
            );

        if ($empresaId <= 0) {
            throw new RuntimeException(
                'La compra no tiene una empresa válida.'
            );
        }

        $usuarioId =
            $this->nullablePositiveInt(
                $usuarioId
            );

        $this->db->beginTransaction();

        try {
            /*
            |--------------------------------------------------------------------------
            | Verificar todos los insumos antes de modificar stock
            |--------------------------------------------------------------------------
            */

            foreach ($items as $item) {
                $insumoId =
                    (int) (
                        $item['insumo_id']
                        ?? 0
                    );

                $cantidad =
                    (float) (
                        $item['cantidad']
                        ?? 0
                    );

                if ($insumoId <= 0) {
                    throw new RuntimeException(
                        'La compra contiene un insumo inválido.'
                    );
                }

                if ($cantidad <= 0) {
                    throw new RuntimeException(
                        'La compra contiene una cantidad inválida.'
                    );
                }

                $this->verificarInsumo(
                    $insumoId,
                    $empresaId
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Actualizar stock
            |--------------------------------------------------------------------------
            */

            $stmtStock =
                $this->db->prepare("
                    UPDATE insumos
                    SET
                        stock_actual =
                            COALESCE(stock_actual, 0)
                            + :cantidad
                    WHERE id = :id
                      AND empresa_id = :empresa_id
                      AND activo = 1
                ");

            /*
            |--------------------------------------------------------------------------
            | Registrar movimientos
            |--------------------------------------------------------------------------
            */

            $tieneMovimientos =
                $this->tablaExiste(
                    'stock_movimientos'
                );

            $stmtMovimiento = null;

            if ($tieneMovimientos) {
                $stmtMovimiento =
                    $this->db->prepare("
                        INSERT INTO stock_movimientos (
                            insumo_id,
                            tipo,
                            cantidad,
                            fecha,
                            usuario_id,
                            cliente_id,
                            equipo_id,
                            servicio_id,
                            observacion,
                            costo_unitario,
                            nro_comprobante
                        ) VALUES (
                            :insumo_id,
                            'ENTRADA',
                            :cantidad,
                            NOW(),
                            :usuario_id,
                            NULL,
                            NULL,
                            NULL,
                            :observacion,
                            :costo_unitario,
                            :nro_comprobante
                        )
                    ");
            }

            foreach ($items as $item) {
                $insumoId =
                    (int) $item['insumo_id'];

                $cantidad =
                    (float) $item['cantidad'];

                $costo =
                    (float) (
                        $item['precio_unitario']
                        ?? 0
                    );

                $stmtStock->execute([
                    'cantidad' =>
                        $cantidad,

                    'id' =>
                        $insumoId,

                    'empresa_id' =>
                        $empresaId,
                ]);

                if (
                    $stmtStock->rowCount() <= 0
                ) {
                    throw new RuntimeException(
                        "No se pudo actualizar el stock del insumo #{$insumoId}."
                    );
                }

                if ($stmtMovimiento !== null) {
                    $stmtMovimiento->execute([
                        'insumo_id' =>
                            $insumoId,

                        'cantidad' =>
                            $cantidad,

                        'usuario_id' =>
                            $usuarioId,

                        'observacion' =>
                            "Entrada por compra #{$id}",

                        'costo_unitario' =>
                            $costo,

                        'nro_comprobante' =>
                            (string) (
                                $compra['numero']
                                ?? "COMP-{$id}"
                            ),
                    ]);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | Marcar compra como recibida
            |--------------------------------------------------------------------------
            */

            $stmtCompra =
                $this->db->prepare("
                    UPDATE compras
                    SET
                        estado = 'RECIBIDA',
                        fecha_recepcion = NOW(),
                        updated_at = NOW()
                    WHERE id = :id
                      AND estado IN (
                          'CONFIRMADA',
                          'PENDIENTE'
                      )
                ");

            $stmtCompra->execute([
                'id' => $id,
            ]);

            if ($stmtCompra->rowCount() <= 0) {
                throw new RuntimeException(
                    'La compra no pudo pasar a estado RECIBIDA.'
                );
            }

            $this->db->commit();

            return $this->obtener(
                $id
            ) ?? [];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PROVEEDORES
    |--------------------------------------------------------------------------
    */

    public function proveedores(): array
    {
        if (
            !$this->tablaExiste(
                'proveedores'
            )
        ) {
            return [];
        }

        $stmt = $this->db->query("
            SELECT
                id,
                nombre
            FROM proveedores
            WHERE activo = 1
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll();
    }

    /*
    |--------------------------------------------------------------------------
    | INSUMOS
    |--------------------------------------------------------------------------
    */

    public function insumos(
        string $q = ''
    ): array {
        if (
            !$this->tablaExiste(
                'insumos'
            )
        ) {
            return [];
        }

        $q =
            trim($q);

        $sql = "
            SELECT
                id,
                empresa_id,
                nombre_insumo,
                codigo_parte,
                codigo_barras,
                unidad_medida,
                stock_actual,
                stock_minimo,
                stock_maximo,
                precio_costo,
                costo_compra,
                costo_compra_usd,
                cotizacion_usd_compra,
                activo
            FROM insumos
            WHERE activo = 1
        ";

        $params = [];

        if ($q !== '') {
            $sql .= "
                AND (
                    nombre_insumo LIKE :q
                    OR codigo_parte LIKE :q
                    OR codigo_barras LIKE :q
                )
            ";

            $params['q'] =
                '%' . $q . '%';
        }

        $sql .= "
            ORDER BY
                nombre_insumo ASC
            LIMIT 50
        ";

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute(
            $params
        );

        return $stmt->fetchAll();
    }

    /*
    |--------------------------------------------------------------------------
    | CABECERA INTERNA
    |--------------------------------------------------------------------------
    */

    private function obtenerCabecera(
        int $id
    ): ?array {
        if ($id <= 0) {
            return null;
        }

        $stmt =
            $this->db->prepare("
                SELECT *
                FROM compras
                WHERE id = :id
                LIMIT 1
            ");

        $stmt->execute([
            'id' => $id,
        ]);

        $resultado =
            $stmt->fetch();

        return $resultado ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | ITEM INTERNO
    |--------------------------------------------------------------------------
    */

    private function obtenerItem(
        int $itemId
    ): ?array {
        if ($itemId <= 0) {
            return null;
        }

        $stmt =
            $this->db->prepare("
                SELECT
                    *
                FROM compras_items
                WHERE id = :id
                LIMIT 1
            ");

        $stmt->execute([
            'id' => $itemId,
        ]);

        $item =
            $stmt->fetch();

        return $item ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDAR COMPRA EDITABLE
    |--------------------------------------------------------------------------
    */

    private function validarCompraEditable(
        int $compraId
    ): void {
        $compra =
            $this->obtenerCabecera(
                $compraId
            );

        if (!$compra) {
            throw new RuntimeException(
                'Compra no encontrada.'
            );
        }

        $estado =
            strtoupper(
                (string) (
                    $compra['estado'] ?? ''
                )
            );

        if (
            $estado !== 'BORRADOR'
        ) {
            throw new RuntimeException(
                'Solo se puede modificar una compra en estado BORRADOR.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDAR QUE TENGA ITEMS
    |--------------------------------------------------------------------------
    */

    private function verificarTieneItems(
        int $compraId
    ): void {
        $stmt =
            $this->db->prepare("
                SELECT COUNT(*)
                FROM compras_items
                WHERE compra_id = :id
            ");

        $stmt->execute([
            'id' => $compraId,
        ]);

        if (
            (int) $stmt->fetchColumn() <= 0
        ) {
            throw new RuntimeException(
                'No se puede confirmar una compra sin artículos.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDAR INSUMO
    |--------------------------------------------------------------------------
    */

    private function verificarInsumo(
        int $insumoId,
        int $empresaId
    ): void {
        if ($insumoId <= 0) {
            throw new RuntimeException(
                'Insumo inválido.'
            );
        }

        if ($empresaId <= 0) {
            throw new RuntimeException(
                'Empresa inválida.'
            );
        }

        if (
            !$this->tablaExiste(
                'insumos'
            )
        ) {
            throw new RuntimeException(
                'La tabla de insumos no existe.'
            );
        }

        $stmt =
            $this->db->prepare("
                SELECT
                    id
                FROM insumos
                WHERE id = :id
                  AND empresa_id = :empresa_id
                  AND activo = 1
                LIMIT 1
            ");

        $stmt->execute([
            'id' =>
                $insumoId,

            'empresa_id' =>
                $empresaId,
        ]);

        if (!$stmt->fetchColumn()) {
            throw new RuntimeException(
                "El insumo #{$insumoId} no existe, está inactivo o pertenece a otra empresa."
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | TABLAS
    |--------------------------------------------------------------------------
    */

    private function asegurarTablas(): void
    {
        $this->crearTablaCompras();
        $this->crearTablaComprasItems();
    }

    private function crearTablaCompras(): void
    {
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS compras (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,

                empresa_id INT UNSIGNED NOT NULL,

                proveedor_id INT UNSIGNED NULL,

                numero VARCHAR(100) NOT NULL,

                fecha DATE NOT NULL,

                estado ENUM(
                    'BORRADOR',
                    'CONFIRMADA',
                    'RECIBIDA',
                    'ANULADA',
                    'PENDIENTE',
                    'CERRADA'
                ) NOT NULL DEFAULT 'BORRADOR',

                subtotal DECIMAL(15,2)
                    NOT NULL DEFAULT 0,

                descuento DECIMAL(15,2)
                    NOT NULL DEFAULT 0,

                iva DECIMAL(15,2)
                    NOT NULL DEFAULT 0,

                total DECIMAL(15,2)
                    NOT NULL DEFAULT 0,

                observacion TEXT NULL,

                moneda VARCHAR(10)
                    NOT NULL DEFAULT 'ARS',

                cotizacion_usd DECIMAL(15,6)
                    NULL,

                fecha_recepcion DATETIME NULL,

                motivo_anulacion TEXT NULL,

                fecha_anulacion DATETIME NULL,

                usuario_id INT UNSIGNED NULL,

                created_at DATETIME
                    NOT NULL DEFAULT CURRENT_TIMESTAMP,

                updated_at DATETIME
                    NOT NULL DEFAULT CURRENT_TIMESTAMP
                    ON UPDATE CURRENT_TIMESTAMP,

                PRIMARY KEY (id),

                INDEX idx_empresa (
                    empresa_id
                ),

                INDEX idx_proveedor (
                    proveedor_id
                ),

                INDEX idx_estado (
                    estado
                ),

                INDEX idx_fecha (
                    fecha
                ),

                INDEX idx_numero (
                    numero
                )
            )
            ENGINE=InnoDB
            DEFAULT CHARSET=utf8mb4
            COLLATE=utf8mb4_unicode_ci
        ");
    }

    private function crearTablaComprasItems(): void
    {
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS compras_items (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,

                compra_id INT UNSIGNED NOT NULL,

                insumo_id INT UNSIGNED NOT NULL,

                cantidad DECIMAL(15,3)
                    NOT NULL DEFAULT 0,

                precio_unitario DECIMAL(15,2)
                    NOT NULL DEFAULT 0,

                subtotal DECIMAL(15,2)
                    NOT NULL DEFAULT 0,

                created_at DATETIME
                    NOT NULL DEFAULT CURRENT_TIMESTAMP,

                PRIMARY KEY (id),

                INDEX idx_compra (
                    compra_id
                ),

                INDEX idx_insumo (
                    insumo_id
                )
            )
            ENGINE=InnoDB
            DEFAULT CHARSET=utf8mb4
            COLLATE=utf8mb4_unicode_ci
        ");
    }

    /*
    |--------------------------------------------------------------------------
    | TABLA EXISTE
    |--------------------------------------------------------------------------
    */

    private function tablaExiste(
        string $tabla
    ): bool {
        if (
            !preg_match(
                '/^[a-zA-Z0-9_]+$/',
                $tabla
            )
        ) {
            return false;
        }

        $stmt =
            $this->db->prepare("
                SELECT COUNT(*)
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
                  AND table_name = :tabla
            ");

        $stmt->execute([
            'tabla' =>
                $tabla,
        ]);

        return
            (int) $stmt->fetchColumn()
            > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | NÚMEROS
    |--------------------------------------------------------------------------
    */

    private function numeroPositivo(
        mixed $valor
    ): ?float {
        if (
            $valor === null
            || $valor === ''
            || is_bool($valor)
        ) {
            return null;
        }

        if (
            !is_numeric($valor)
        ) {
            return null;
        }

        $numero =
            (float) $valor;

        return
            $numero > 0
                ? $numero
                : null;
    }

    private function numeroNoNegativo(
        mixed $valor
    ): ?float {
        if (
            $valor === null
            || $valor === ''
            || is_bool($valor)
        ) {
            return null;
        }

        if (
            !is_numeric($valor)
        ) {
            return null;
        }

        $numero =
            (float) $valor;

        return
            $numero >= 0
                ? $numero
                : null;
    }

    /*
    |--------------------------------------------------------------------------
    | INT POSITIVO
    |--------------------------------------------------------------------------
    */

    private function nullablePositiveInt(
        mixed $valor
    ): ?int {
        if (
            $valor === null
            || $valor === ''
        ) {
            return null;
        }

        $resultado =
            filter_var(
                $valor,
                FILTER_VALIDATE_INT
            );

        if (
            $resultado === false
            || $resultado <= 0
        ) {
            return null;
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | STRING NULLABLE
    |--------------------------------------------------------------------------
    */

    private function nullableString(
        mixed $valor
    ): ?string {
        if ($valor === null) {
            return null;
        }

        $valor =
            trim(
                (string) $valor
            );

        return
            $valor === ''
                ? null
                : $valor;
    }

    /*
    |--------------------------------------------------------------------------
    | FECHA
    |--------------------------------------------------------------------------
    */

    private function fechaValida(
        string $fecha
    ): bool {
        $fecha =
            trim($fecha);

        if (
            !preg_match(
                '/^\d{4}-\d{2}-\d{2}$/',
                $fecha
            )
        ) {
            return false;
        }

        [$anio, $mes, $dia] =
            array_map(
                'intval',
                explode(
                    '-',
                    $fecha
                )
            );

        return checkdate(
            $mes,
            $dia,
            $anio
        );
    }

    /*
    |--------------------------------------------------------------------------
    | NÚMERO AUTOMÁTICO
    |--------------------------------------------------------------------------
    */

    private function generarNumero(): string
    {
        $base =
            'COMP-'
            . date('YmdHis');

        $numero =
            $base;

        $contador = 1;

        while ($this->numeroExiste($numero)) {
            $numero =
                $base
                . '-'
                . $contador;

            $contador++;

            if ($contador > 1000) {
                throw new RuntimeException(
                    'No se pudo generar un número único para la compra.'
                );
            }
        }

        return $numero;
    }

    private function numeroExiste(
        string $numero
    ): bool {
        $stmt =
            $this->db->prepare("
                SELECT COUNT(*)
                FROM compras
                WHERE numero = :numero
            ");

        $stmt->execute([
            'numero' =>
                $numero,
        ]);

        return
            (int) $stmt->fetchColumn()
            > 0;
    }
}