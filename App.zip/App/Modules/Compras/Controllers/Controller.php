<?php

declare(strict_types=1);

namespace App\Modules\Compras\Controllers;

use App\Core\BaseController;
use App\Modules\Compras\Services\Service;
use InvalidArgumentException;
use Throwable;

final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {
            $dashboard = $this->service->dashboard();

            $this->assets()->addModule('Compras');

            $this->moduleView(
                'Compras',
                'index',
                [
                    'titulo' => 'Compras',
                    'csrf'   => $this->csrf(),

                    'resumen' => is_array($dashboard['resumen'] ?? null)
                        ? $dashboard['resumen']
                        : [],

                    'compras' => is_array($dashboard['compras'] ?? null)
                        ? $dashboard['compras']
                        : [],

                    'pendientes' => is_array($dashboard['pendientes'] ?? null)
                        ? $dashboard['pendientes']
                        : [],

                    'recepciones' => is_array($dashboard['recepciones'] ?? null)
                        ? $dashboard['recepciones']
                        : [],

                    'ultimas' => is_array($dashboard['ultimas'] ?? null)
                        ? $dashboard['ultimas']
                        : [],

                    'error' => null,
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(): void
    {
        $this->requireAuth();

        try {
            $datos = $this->service->datosFormulario();

            $this->assets()->addModule('Compras');

            $this->moduleView(
                'Compras',
                'form',
                [
                    'titulo' => 'Nueva compra',
                    'csrf'   => $this->csrf(),
                    'compra' => null,

                    'proveedores' => is_array($datos['proveedores'] ?? null)
                        ? $datos['proveedores']
                        : [],

                    'insumos' => is_array($datos['insumos'] ?? null)
                        ? $datos['insumos']
                        : [],

                    'error' => null,
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR
    |--------------------------------------------------------------------------
    */

    public function guardar(): void
    {
        $this->requireAuth();

        try {
            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $data = $this->requestData();

            $id = $this->service->guardar(
                $data,
                $this->userId()
            );

            $this->json([
                'success' => true,
                'message' => 'Compra registrada correctamente.',
                'id'      => (int) $id,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function listado(): void
    {
        $this->requireAuth();

        try {
            $filtros = is_array($_GET ?? null)
                ? $_GET
                : [];

            $data = $this->service->listar($filtros);

            if (!is_array($data)) {
                $data = [];
            }

            $this->json([
                'success' => true,
                'data'    => $data,
                'total'   => count($data),
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VER
    |--------------------------------------------------------------------------
    */

    public function ver(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            $compra = $this->service->obtener($id);

            if (!$compra) {
                $this->notFound('Compra no encontrada.');
                return;
            }

            $this->assets()->addModule('Compras');

            $this->json([
                'success' => true,
                'data'    => $compra,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR
    |--------------------------------------------------------------------------
    */

    public function editar(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            $compra = $this->service->obtener($id);

            if (!$compra) {
                $this->notFound('Compra no encontrada.');
                return;
            }

            $datos = $this->service->datosFormulario();

            $this->assets()->addModule('Compras');

            $this->moduleView(
                'Compras',
                'form',
                [
                    'titulo' => 'Editar compra',
                    'csrf'   => $this->csrf(),
                    'compra' => $compra,

                    'proveedores' => is_array($datos['proveedores'] ?? null)
                        ? $datos['proveedores']
                        : [],

                    'insumos' => is_array($datos['insumos'] ?? null)
                        ? $datos['insumos']
                        : [],

                    'error' => null,
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $data = $this->requestData();

            $resultado = $this->service->actualizar(
                $id,
                $data,
                $this->userId()
            );

            $this->json([
                'success' => (bool) $resultado,
                'message' => $resultado
                    ? 'Compra actualizada correctamente.'
                    : 'No se realizaron cambios.',
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CONFIRMAR
    |--------------------------------------------------------------------------
    */

    public function confirmar(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $resultado = $this->service->confirmar(
                $id,
                $this->userId()
            );

            $this->json([
                'success' => true,
                'message' => 'Compra confirmada correctamente.',
                'data'    => $resultado,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ANULAR
    |--------------------------------------------------------------------------
    */

    public function anular(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $data = $this->requestData();

            $motivo = trim(
                (string) ($data['motivo'] ?? '')
            );

            $resultado = $this->service->anular(
                $id,
                $this->userId(),
                $motivo !== '' ? $motivo : null
            );

            $this->json([
                'success' => (bool) $resultado,
                'message' => $resultado
                    ? 'Compra anulada correctamente.'
                    : 'No se pudo anular la compra.',
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RECEPCIONES
    |--------------------------------------------------------------------------
    */

    public function recepciones(): void
    {
        $this->requireAuth();

        try {
            $filtros = is_array($_GET ?? null)
                ? $_GET
                : [];

            $data = $this->service->recepciones($filtros);

            if (!is_array($data)) {
                $data = [];
            }

            $this->json([
                'success' => true,
                'data'    => $data,
                'total'   => count($data),
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RECEPCIÓN INDIVIDUAL
    |--------------------------------------------------------------------------
    */

    public function recepcion(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            $compra = $this->service->obtener($id);

            if (!$compra) {
                $this->notFound('Compra no encontrada.');
                return;
            }

            $pendientes = $this->service->pendientesRecepcion($id);

            $this->json([
                'success' => true,
                'data' => [
                    'compra'    => $compra,
                    'pendientes' => is_array($pendientes)
                        ? $pendientes
                        : [],
                ],
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR RECEPCIÓN
    |--------------------------------------------------------------------------
    */

    public function guardarRecepcion(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $data = $this->requestData();

            $resultado = $this->service->guardarRecepcion(
                $id,
                $data,
                $this->userId()
            );

            $this->json([
                'success' => true,
                'message' => 'Recepción registrada correctamente.',
                'data'    => $resultado,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR INSUMOS
    |--------------------------------------------------------------------------
    */

    public function buscar(): void
    {
        $this->requireAuth();

        try {
            $q = trim(
                (string) ($_GET['q'] ?? '')
            );

            $limit = (int) ($_GET['limit'] ?? 20);

            if ($limit < 1) {
                $limit = 20;
            }

            if ($limit > 100) {
                $limit = 100;
            }

            $data = $this->service->buscar(
                $q,
                $limit
            );

            $this->json([
                'success' => true,
                'data'    => is_array($data)
                    ? $data
                    : [],
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ITEMS
    |--------------------------------------------------------------------------
    */

    public function items(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            $data = $this->service->items($id);

            $this->json([
                'success' => true,
                'data'    => is_array($data)
                    ? $data
                    : [],
                'total'   => is_array($data)
                    ? count($data)
                    : 0,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | AGREGAR ITEM
    |--------------------------------------------------------------------------
    */

    public function agregarItem(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $data = $this->requestData();

            $itemId = $this->service->agregarItem(
                $id,
                $data
            );

            $this->json([
                'success' => true,
                'message' => 'Artículo agregado correctamente.',
                'id'      => $itemId,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR ITEM
    |--------------------------------------------------------------------------
    */

    public function actualizarItem(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $data = $this->requestData();

            $resultado = $this->service->actualizarItem(
                $id,
                $data
            );

            $this->json([
                'success' => (bool) $resultado,
                'message' => $resultado
                    ? 'Artículo actualizado correctamente.'
                    : 'No se realizaron cambios.',
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR ITEM
    |--------------------------------------------------------------------------
    */

    public function eliminarItem(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            if (!$this->validateCsrf()) {
                $this->validation([
                    'csrf' => 'Token de seguridad inválido o vencido.',
                ]);

                return;
            }

            $resultado = $this->service->eliminarItem($id);

            $this->json([
                'success' => (bool) $resultado,
                'message' => $resultado
                    ? 'Artículo eliminado correctamente.'
                    : 'No se pudo eliminar el artículo.',
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RECALCULAR
    |--------------------------------------------------------------------------
    */

    public function recalcular(string|int $id): void
    {
        $this->requireAuth();

        try {
            $id = $this->normalizarId($id);

            $resultado = $this->service->recalcular($id);

            $this->json([
                'success' => true,
                'data'    => $resultado,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PROVEEDORES
    |--------------------------------------------------------------------------
    */

    public function proveedores(): void
    {
        $this->requireAuth();

        try {
            $data = $this->service->proveedores();

            $this->json([
                'success' => true,
                'data'    => is_array($data)
                    ? $data
                    : [],
                'total'   => is_array($data)
                    ? count($data)
                    : 0,
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS FORMULARIO
    |--------------------------------------------------------------------------
    */

    public function datosFormulario(): void
    {
        $this->requireAuth();

        try {
            $data = $this->service->datosFormulario();

            $this->json([
                'success' => true,
                'data'    => is_array($data)
                    ? $data
                    : [],
            ]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REQUEST DATA
    |--------------------------------------------------------------------------
    */

    private function requestData(): array
    {
        $contentType = strtolower(
            (string) ($_SERVER['CONTENT_TYPE'] ?? '')
        );

        if (str_contains($contentType, 'application/json')) {
            $raw = file_get_contents('php://input');

            if ($raw === false || trim($raw) === '') {
                return [];
            }

            try {
                $data = json_decode(
                    $raw,
                    true,
                    512,
                    JSON_THROW_ON_ERROR
                );
            } catch (\JsonException) {
                throw new InvalidArgumentException(
                    'El contenido JSON enviado no es válido.'
                );
            }

            return is_array($data)
                ? $data
                : [];
        }

        return is_array($_POST ?? null)
            ? $_POST
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | NORMALIZAR ID
    |--------------------------------------------------------------------------
    */

    private function normalizarId(string|int $id): int
    {
        if (is_string($id)) {
            $id = trim($id);
        }

        if ($id === '' || !is_numeric($id)) {
            throw new InvalidArgumentException(
                'ID de compra inválido.'
            );
        }

        $id = (int) $id;

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de compra inválido.'
            );
        }

        return $id;
    }

    /*
    |--------------------------------------------------------------------------
    | JSON ERROR
    |--------------------------------------------------------------------------
    */

    private function jsonError(Throwable $e): never
    {
        $status = 400;

        if ($e instanceof InvalidArgumentException) {
            $status = 422;
        }

        $this->json(
            [
                'success' => false,
                'message' => $e->getMessage(),
                'errors'  => [],
            ],
            $status
        );
    }
}