<?php

declare(strict_types=1);

namespace App\Modules\Compras;

use App\Core\Module as CoreModule;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * MÓDULO COMPRAS
 * =========================================================
 */
final class Module extends CoreModule
{
    public function name(): string
    {
        return 'Compras';
    }

    public function description(): string
    {
        return 'Gestión integral del circuito de compras y abastecimiento.';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function priority(): int
    {
        return 30;
    }

    public function menu(): array
    {
        return [
            [
                'title'      => 'Compras',
                'icon'       => 'fa-solid fa-cart-shopping',
                'url'        => '/compras',
                'group'      => 'Administración',
                'order'      => 30,
                'permission' => 'compras.ver',
                'visible'    => true,

                'children' => [
                    [
                        'title'      => 'Dashboard',
                        'icon'       => 'fa-solid fa-chart-line',
                        'url'        => '/compras',
                        'permission' => 'compras.ver',
                        'visible'    => true,
                    ],

                    [
                        'title'      => 'Nueva compra',
                        'icon'       => 'fa-solid fa-plus',
                        'url'        => '/compras/crear',
                        'permission' => 'compras.crear',
                        'visible'    => true,
                    ],

                    [
                        'title'      => 'Compras',
                        'icon'       => 'fa-solid fa-file-invoice',
                        'url'        => '/compras/listado',
                        'permission' => 'compras.ver',
                        'visible'    => true,
                    ],

                    [
                        'title'      => 'Recepciones',
                        'icon'       => 'fa-solid fa-box-open',
                        'url'        => '/compras/recepciones',
                        'permission' => 'compras.recibir',
                        'visible'    => true,
                    ],
                ],
            ],
        ];
    }

    public function icon(): string
    {
        return 'fa-solid fa-cart-shopping';
    }

    public function url(): string
    {
        return '/compras';
    }

    public function group(): string
    {
        return 'Administración';
    }

    public function order(): int
    {
        return 30;
    }

    public function permissions(): array
    {
        return [
            'compras.ver',
            'compras.crear',
            'compras.editar',
            'compras.confirmar',
            'compras.recibir',
            'compras.anular',
        ];
    }

    public function dependencies(): array
    {
        return [
            'Clientes',
            'Inventario',
        ];
    }

    public function widgets(): array
    {
        return [];
    }

    public function kpis(): array
    {
        return [];
    }

    public function enabled(): bool
    {
        return true;
    }

    public function boot(): void
    {
        // Sin lógica de negocio durante el bootstrap.
    }
}