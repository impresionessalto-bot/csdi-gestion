<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ERP CSDI PRO - COMPRAS
| Dashboard principal
|--------------------------------------------------------------------------
|
| Vista preparada para trabajar con:
|
| - Compras
| - Compras pendientes
| - Recepciones
| - Proveedores
| - Importes
| - Últimas compras
|
| La vista es tolerante a datos inexistentes.
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| DATOS
|--------------------------------------------------------------------------
*/

$resumen = is_array($resumen ?? null)
    ? $resumen
    : [];

$compras = is_array($compras ?? null)
    ? $compras
    : [];

$pendientes = is_array($pendientes ?? null)
    ? $pendientes
    : [];

$recepciones = is_array($recepciones ?? null)
    ? $recepciones
    : [];

$ultimas = is_array($ultimas ?? null)
    ? $ultimas
    : [];

$error = $error ?? null;


/*
|--------------------------------------------------------------------------
| HELPERS LOCALES
|--------------------------------------------------------------------------
*/

if (!function_exists('compras_e')) {
    function compras_e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}


if (!function_exists('compras_money')) {
    function compras_money(
        mixed $value,
        int $decimales = 2
    ): string {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            $decimales,
            ',',
            '.'
        );
    }
}


if (!function_exists('compras_int')) {
    function compras_int(mixed $value): string
    {
        return number_format(
            (int) ($value ?? 0),
            0,
            ',',
            '.'
        );
    }
}


if (!function_exists('compras_fecha')) {
    function compras_fecha(mixed $fecha): string
    {
        if (
            $fecha === null
            || trim((string) $fecha) === ''
        ) {
            return '-';
        }

        $timestamp = strtotime(
            (string) $fecha
        );

        if ($timestamp === false) {
            return compras_e($fecha);
        }

        return date(
            'd/m/Y H:i',
            $timestamp
        );
    }
}


if (!function_exists('compras_estado_badge')) {
    function compras_estado_badge(
        mixed $estado
    ): string {

        $estado = strtoupper(
            trim((string) $estado)
        );

        return match ($estado) {

            'PENDIENTE',
            'PENDIENTES' =>
                'text-bg-warning',

            'RECIBIDA',
            'RECIBIDO',
            'FINALIZADA',
            'FINALIZADO',
            'CERRADA',
            'CERRADO' =>
                'text-bg-success',

            'ANULADA',
            'ANULADO',
            'CANCELADA',
            'CANCELADO' =>
                'text-bg-danger',

            'PARCIAL',
            'PARCIALMENTE_RECIBIDA' =>
                'text-bg-info',

            default =>
                'text-bg-secondary',
        };
    }
}


/*
|--------------------------------------------------------------------------
| KPIs
|--------------------------------------------------------------------------
*/

$totalCompras = (int) (
    $resumen['total']
    ?? $resumen['total_compras']
    ?? count($compras)
);

$pendientesTotal = (int) (
    $resumen['pendientes']
    ?? $resumen['compras_pendientes']
    ?? count($pendientes)
);

$recepcionesTotal = (int) (
    $resumen['recepciones_pendientes']
    ?? $resumen['pendientes_recepcion']
    ?? count($recepciones)
);

$totalImporte = (float) (
    $resumen['importe_total']
    ?? $resumen['total_importe']
    ?? $resumen['compras_mes']
    ?? 0
);

?>

<div class="container-fluid py-4">

    <!-- ================================================================
         ENCABEZADO
    ================================================================= -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-cart-check me-2"></i>

                Compras

            </h1>

            <p class="text-muted mb-0">

                Gestión de compras, proveedores, recepciones y costos.

            </p>

        </div>


        <!-- ============================================================
             ACCIONES
        ============================================================= -->

        <div class="d-flex flex-wrap gap-2 mt-3 mt-md-0">

            <a
                href="/compras/crear"
                class="btn btn-primary"
            >

                <i class="bi bi-plus-lg me-1"></i>

                Nueva compra

            </a>


            <a
                href="/compras/listado"
                class="btn btn-outline-secondary"
            >

                <i class="bi bi-list-ul me-1"></i>

                Ver compras

            </a>


            <a
                href="/compras/recepciones"
                class="btn btn-outline-success"
            >

                <i class="bi bi-box-arrow-in-down me-1"></i>

                Recepciones

            </a>

        </div>

    </div>


    <!-- ================================================================
         ERROR
    ================================================================= -->

    <?php if ($error): ?>

        <div
            class="alert alert-danger alert-dismissible fade show"
            role="alert"
        >

            <strong>

                <i class="bi bi-exclamation-triangle me-1"></i>

                Error:

            </strong>

            <?= compras_e($error) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
            ></button>

        </div>

    <?php endif; ?>


    <!-- ================================================================
         KPIs
    ================================================================= -->

    <div class="row g-3 mb-4">


        <!-- TOTAL COMPRAS -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm border-0 h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-start">

                        <div>

                            <div class="text-muted small text-uppercase fw-semibold">

                                Compras

                            </div>

                            <div class="fs-2 fw-bold mt-1">

                                <?= compras_int(
                                    $totalCompras
                                ) ?>

                            </div>

                        </div>

                        <div class="fs-2 text-primary">

                            <i class="bi bi-cart-check"></i>

                        </div>

                    </div>

                    <div class="small text-muted mt-2">

                        Operaciones registradas

                    </div>

                </div>

            </div>

        </div>


        <!-- PENDIENTES -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm border-0 h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-start">

                        <div>

                            <div class="text-muted small text-uppercase fw-semibold">

                                Pendientes

                            </div>

                            <div class="fs-2 fw-bold text-warning mt-1">

                                <?= compras_int(
                                    $pendientesTotal
                                ) ?>

                            </div>

                        </div>

                        <div class="fs-2 text-warning">

                            <i class="bi bi-hourglass-split"></i>

                        </div>

                    </div>

                    <div class="small text-muted mt-2">

                        Compras pendientes

                    </div>

                </div>

            </div>

        </div>


        <!-- RECEPCIONES -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm border-0 h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-start">

                        <div>

                            <div class="text-muted small text-uppercase fw-semibold">

                                Recepciones

                            </div>

                            <div class="fs-2 fw-bold text-info mt-1">

                                <?= compras_int(
                                    $recepcionesTotal
                                ) ?>

                            </div>

                        </div>

                        <div class="fs-2 text-info">

                            <i class="bi bi-box-seam"></i>

                        </div>

                    </div>

                    <div class="small text-muted mt-2">

                        Pendientes de ingreso

                    </div>

                </div>

            </div>

        </div>


        <!-- IMPORTE -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm border-0 h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-start">

                        <div>

                            <div class="text-muted small text-uppercase fw-semibold">

                                Importe

                            </div>

                            <div class="fs-4 fw-bold mt-2">

                                <?= compras_money(
                                    $totalImporte
                                ) ?>

                            </div>

                        </div>

                        <div class="fs-2 text-success">

                            <i class="bi bi-cash-stack"></i>

                        </div>

                    </div>

                    <div class="small text-muted mt-2">

                        Total de compras

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================
         ACCESOS RÁPIDOS
    ================================================================= -->

    <div class="row g-3 mb-4">

        <div class="col-12 col-md-4">

            <a
                href="/compras/crear"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="fs-1 text-primary me-3">

                                <i class="bi bi-cart-plus"></i>

                            </div>

                            <div>

                                <h5 class="mb-1 text-dark">

                                    Nueva compra

                                </h5>

                                <div class="text-muted small">

                                    Registrar una nueva orden de compra.

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-4">

            <a
                href="/compras/recepciones"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="fs-1 text-success me-3">

                                <i class="bi bi-box-arrow-in-down"></i>

                            </div>

                            <div>

                                <h5 class="mb-1 text-dark">

                                    Recibir mercadería

                                </h5>

                                <div class="text-muted small">

                                    Ingresar productos recibidos al inventario.

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-4">

            <a
                href="/compras/listado"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center">

                            <div class="fs-1 text-secondary me-3">

                                <i class="bi bi-search"></i>

                            </div>

                            <div>

                                <h5 class="mb-1 text-dark">

                                    Consultar compras

                                </h5>

                                <div class="text-muted small">

                                    Buscar, filtrar y consultar operaciones.

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>

    </div>


    <!-- ================================================================
         COMPRAS PENDIENTES
    ================================================================= -->

    <div class="card shadow-sm border-0 mb-4">

        <div class="card-header bg-white py-3">

            <div class="d-flex justify-content-between align-items-center">

                <strong>

                    <i class="bi bi-hourglass-split text-warning me-2"></i>

                    Compras pendientes

                </strong>

                <span class="badge text-bg-warning">

                    <?= count($pendientes) ?>

                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (!$pendientes): ?>

                <div class="p-4 text-center text-muted">

                    <i class="bi bi-check-circle fs-2 d-block mb-2"></i>

                    No hay compras pendientes.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-3">
                                    Fecha
                                </th>

                                <th>
                                    Compra
                                </th>

                                <th>
                                    Proveedor
                                </th>

                                <th>
                                    Estado
                                </th>

                                <th class="text-end">
                                    Importe
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                            <?php foreach ($pendientes as $item): ?>

                                <?php

                                $estado = strtoupper(
                                    (string) (
                                        $item['estado']
                                        ?? 'PENDIENTE'
                                    )
                                );

                                $id = (int) (
                                    $item['id']
                                    ?? $item['compra_id']
                                    ?? 0
                                );

                                ?>

                                <tr>

                                    <td class="ps-3">

                                        <?= compras_fecha(
                                            $item['fecha']
                                            ?? $item['fecha_compra']
                                            ?? null
                                        ) ?>

                                    </td>


                                    <td>

                                        <strong>

                                            <?php if ($id > 0): ?>

                                                #<?= $id ?>

                                            <?php else: ?>

                                                <?= compras_e(
                                                    $item['numero']
                                                    ?? $item['numero_compra']
                                                    ?? '-'
                                                ) ?>

                                            <?php endif; ?>

                                        </strong>

                                    </td>


                                    <td>

                                        <?= compras_e(
                                            $item['proveedor_nombre']
                                            ?? $item['proveedor']
                                            ?? '-'
                                        ) ?>

                                    </td>


                                    <td>

                                        <span class="badge <?= compras_estado_badge($estado) ?>">

                                            <?= compras_e(
                                                $estado
                                            ) ?>

                                        </span>

                                    </td>


                                    <td class="text-end fw-semibold">

                                        <?= compras_money(
                                            $item['total']
                                            ?? $item['importe_total']
                                            ?? $item['importe']
                                            ?? 0
                                        ) ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- ================================================================
         RECEPCIONES PENDIENTES
    ================================================================= -->

    <div class="card shadow-sm border-0 mb-4">

        <div class="card-header bg-white py-3">

            <div class="d-flex justify-content-between align-items-center">

                <strong>

                    <i class="bi bi-box-seam text-info me-2"></i>

                    Recepciones pendientes

                </strong>

                <span class="badge text-bg-info">

                    <?= count($recepciones) ?>

                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (!$recepciones): ?>

                <div class="p-4 text-center text-muted">

                    <i class="bi bi-box-seam fs-2 d-block mb-2"></i>

                    No hay recepciones pendientes.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-3">
                                    Compra
                                </th>

                                <th>
                                    Proveedor
                                </th>

                                <th>
                                    Fecha
                                </th>

                                <th class="text-end">
                                    Pendiente
                                </th>

                                <th class="text-end">
                                    Acción
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php foreach ($recepciones as $item): ?>

                                <?php

                                $id = (int) (
                                    $item['id']
                                    ?? $item['compra_id']
                                    ?? 0
                                );

                                ?>

                                <tr>

                                    <td class="ps-3">

                                        <strong>

                                            #<?= $id ?>

                                        </strong>

                                    </td>


                                    <td>

                                        <?= compras_e(
                                            $item['proveedor_nombre']
                                            ?? $item['proveedor']
                                            ?? '-'
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= compras_fecha(
                                            $item['fecha']
                                            ?? $item['fecha_compra']
                                            ?? null
                                        ) ?>

                                    </td>


                                    <td class="text-end">

                                        <?= compras_int(
                                            $item['pendiente']
                                            ?? $item['cantidad_pendiente']
                                            ?? 0
                                        ) ?>

                                    </td>


                                    <td class="text-end">

                                        <?php if ($id > 0): ?>

                                            <a
                                                href="/compras/recepciones/<?= $id ?>"
                                                class="btn btn-sm btn-outline-success"
                                            >

                                                <i class="bi bi-box-arrow-in-down"></i>

                                                Recibir

                                            </a>

                                        <?php else: ?>

                                            <span class="text-muted">

                                                -

                                            </span>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- ================================================================
         ÚLTIMAS COMPRAS
    ================================================================= -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-white py-3">

            <div class="d-flex justify-content-between align-items-center">

                <strong>

                    <i class="bi bi-clock-history me-2"></i>

                    Últimas compras

                </strong>

                <a
                    href="/compras/listado"
                    class="btn btn-sm btn-outline-secondary"
                >

                    Ver todas

                    <i class="bi bi-arrow-right ms-1"></i>

                </a>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (!$ultimas): ?>

                <div class="p-5 text-center text-muted">

                    <i class="bi bi-cart-x fs-1 d-block mb-3"></i>

                    <h5>

                        No hay compras registradas

                    </h5>

                    <p class="mb-3">

                        Comenzá registrando la primera compra.

                    </p>

                    <a
                        href="/compras/crear"
                        class="btn btn-primary"
                    >

                        <i class="bi bi-plus-lg me-1"></i>

                        Nueva compra

                    </a>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-3">
                                    Fecha
                                </th>

                                <th>
                                    Compra
                                </th>

                                <th>
                                    Proveedor
                                </th>

                                <th>
                                    Estado
                                </th>

                                <th class="text-end">
                                    Total
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php foreach ($ultimas as $item): ?>

                                <?php

                                $estado = strtoupper(
                                    (string) (
                                        $item['estado']
                                        ?? 'PENDIENTE'
                                    )
                                );

                                $id = (int) (
                                    $item['id']
                                    ?? $item['compra_id']
                                    ?? 0
                                );

                                ?>

                                <tr>

                                    <td class="ps-3">

                                        <?= compras_fecha(
                                            $item['fecha']
                                            ?? $item['fecha_compra']
                                            ?? $item['created_at']
                                            ?? null
                                        ) ?>

                                    </td>


                                    <td>

                                        <?php if ($id > 0): ?>

                                            <a
                                                href="/compras/<?= $id ?>"
                                                class="fw-semibold text-decoration-none"
                                            >

                                                #<?= $id ?>

                                            </a>

                                        <?php else: ?>

                                            <span class="fw-semibold">

                                                <?= compras_e(
                                                    $item['numero']
                                                    ?? $item['numero_compra']
                                                    ?? '-'
                                                ) ?>

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <?= compras_e(
                                            $item['proveedor_nombre']
                                            ?? $item['proveedor']
                                            ?? '-'
                                        ) ?>

                                    </td>


                                    <td>

                                        <span class="badge <?= compras_estado_badge($estado) ?>">

                                            <?= compras_e(
                                                $estado
                                            ) ?>

                                        </span>

                                    </td>


                                    <td class="text-end fw-semibold">

                                        <?= compras_money(
                                            $item['total']
                                            ?? $item['importe_total']
                                            ?? $item['importe']
                                            ?? 0
                                        ) ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>