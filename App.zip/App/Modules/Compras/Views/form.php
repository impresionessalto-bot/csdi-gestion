<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ERP CSDI PRO
| COMPRAS - FORMULARIO
|--------------------------------------------------------------------------
|
| Variables esperadas:
|
| $titulo
| $csrf
| $compra
| $proveedores
| $insumos
|
*/

$titulo = isset($titulo)
    ? (string) $titulo
    : 'Nueva compra';

$csrf = isset($csrf)
    ? (string) $csrf
    : '';

$compra = is_array($compra ?? null)
    ? $compra
    : [];

$proveedores = is_array($proveedores ?? null)
    ? $proveedores
    : [];

$insumos = is_array($insumos ?? null)
    ? $insumos
    : [];

$compraId = (int) (
    $compra['id']
    ?? 0
);

$numero = (string) (
    $compra['numero']
    ?? ''
);

$fecha = (string) (
    $compra['fecha']
    ?? date('Y-m-d')
);

$estado = strtoupper(
    trim(
        (string) (
            $compra['estado']
            ?? 'BORRADOR'
        )
    )
);

$proveedorId = (int) (
    $compra['proveedor_id']
    ?? 0
);

$moneda = strtoupper(
    trim(
        (string) (
            $compra['moneda']
            ?? 'ARS'
        )
    )
);

if (!in_array($moneda, ['ARS', 'USD'], true)) {
    $moneda = 'ARS';
}

$cotizacion = (float) (
    $compra['cotizacion_usd']
    ?? 0
);

$observacion = (string) (
    $compra['observacion']
    ?? ''
);

$subtotalInicial = (float) (
    $compra['subtotal']
    ?? 0
);

$descuentoInicial = (float) (
    $compra['descuento']
    ?? 0
);

$ivaInicial = (float) (
    $compra['iva']
    ?? 0
);

$totalInicial = (float) (
    $compra['total']
    ?? 0
);

$items = is_array($compra['items'] ?? null)
    ? $compra['items']
    : [];

?>

<div class="container-fluid py-3">

    <!-- ========================================================= -->
    <!-- CABECERA -->
    <!-- ========================================================= -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">

        <div>
            <h1 class="h3 mb-1">
                <?= htmlspecialchars(
                    $titulo,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h1>

            <div class="text-muted small">
                Gestión de compras e ingreso de mercadería
            </div>
        </div>

        <div class="d-flex gap-2">

            <a
                href="/compras"
                class="btn btn-outline-secondary"
            >
                <i class="fa-solid fa-arrow-left me-1"></i>
                Volver
            </a>

        </div>

    </div>


    <!-- ========================================================= -->
    <!-- ALERTAS -->
    <!-- ========================================================= -->

    <div
        id="comprasAlert"
        class="alert d-none"
        role="alert"
    ></div>


    <!-- ========================================================= -->
    <!-- FORMULARIO -->
    <!-- ========================================================= -->

    <form
        id="formCompra"
        method="post"
        autocomplete="off"
    >

        <input
            type="hidden"
            name="csrf"
            id="csrf"
            value="<?= htmlspecialchars(
                $csrf,
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >

        <?php if ($compraId > 0): ?>

            <input
                type="hidden"
                name="id"
                value="<?= $compraId ?>"
            >

        <?php endif; ?>


        <!-- ===================================================== -->
        <!-- DATOS GENERALES -->
        <!-- ===================================================== -->

        <div class="card shadow-sm mb-3">

            <div class="card-header bg-body">

                <div class="d-flex align-items-center">

                    <i class="fa-solid fa-file-invoice-dollar me-2"></i>

                    <strong>
                        Datos de la compra
                    </strong>

                </div>

            </div>

            <div class="card-body">

                <div class="row g-3">

                    <!-- PROVEEDOR -->

                    <div class="col-lg-5">

                        <label
                            for="proveedor_id"
                            class="form-label"
                        >
                            Proveedor
                            <span class="text-danger">*</span>
                        </label>

                        <select
                            name="proveedor_id"
                            id="proveedor_id"
                            class="form-select"
                            required
                        >

                            <option value="">
                                Seleccionar proveedor...
                            </option>

                            <?php foreach ($proveedores as $proveedor): ?>

                                <?php
                                $id = (int) (
                                    $proveedor['id']
                                    ?? 0
                                );

                                $nombre = (string) (
                                    $proveedor['nombre']
                                    ?? ''
                                );
                                ?>

                                <?php if ($id <= 0): ?>
                                    <?php continue; ?>
                                <?php endif; ?>

                                <option
                                    value="<?= $id ?>"
                                    <?= $id === $proveedorId
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= htmlspecialchars(
                                        $nombre,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- NUMERO -->

                    <div class="col-lg-3">

                        <label
                            for="numero"
                            class="form-label"
                        >
                            Número de compra
                        </label>

                        <input
                            type="text"
                            name="numero"
                            id="numero"
                            class="form-control"
                            maxlength="100"
                            value="<?= htmlspecialchars(
                                $numero,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            placeholder="Ej. FC-0001-00001234"
                        >

                    </div>


                    <!-- FECHA -->

                    <div class="col-lg-2">

                        <label
                            for="fecha"
                            class="form-label"
                        >
                            Fecha
                        </label>

                        <input
                            type="date"
                            name="fecha"
                            id="fecha"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $fecha,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            required
                        >

                    </div>


                    <!-- ESTADO -->

                    <div class="col-lg-2">

                        <label
                            class="form-label"
                        >
                            Estado
                        </label>

                        <div class="form-control bg-body-secondary">

                            <span
                                class="badge
                                <?=
                                match ($estado) {
                                    'BORRADOR' =>
                                        'text-bg-secondary',

                                    'CONFIRMADA' =>
                                        'text-bg-primary',

                                    'RECIBIDA' =>
                                        'text-bg-success',

                                    'ANULADA' =>
                                        'text-bg-danger',

                                    default =>
                                        'text-bg-warning',
                                }
                                ?>"
                            >
                                <?= htmlspecialchars(
                                    $estado,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </span>

                        </div>

                    </div>


                    <!-- MONEDA -->

                    <div class="col-lg-3">

                        <label
                            for="moneda"
                            class="form-label"
                        >
                            Moneda
                        </label>

                        <select
                            name="moneda"
                            id="moneda"
                            class="form-select"
                        >

                            <option
                                value="ARS"
                                <?= $moneda === 'ARS'
                                    ? 'selected'
                                    : '' ?>
                            >
                                ARS - Pesos
                            </option>

                            <option
                                value="USD"
                                <?= $moneda === 'USD'
                                    ? 'selected'
                                    : '' ?>
                            >
                                USD - Dólares
                            </option>

                        </select>

                    </div>


                    <!-- COTIZACION -->

                    <div
                        class="col-lg-3"
                        id="contenedorCotizacion"
                    >

                        <label
                            for="cotizacion_usd"
                            class="form-label"
                        >
                            Cotización USD
                        </label>

                        <input
                            type="number"
                            name="cotizacion_usd"
                            id="cotizacion_usd"
                            class="form-control"
                            min="0"
                            step="0.0001"
                            value="<?= $cotizacion > 0
                                ? htmlspecialchars(
                                    (string) $cotizacion,
                                    ENT_QUOTES,
                                    'UTF-8'
                                )
                                : '' ?>"
                        >

                    </div>


                    <!-- OBSERVACION -->

                    <div class="col-lg-6">

                        <label
                            for="observacion"
                            class="form-label"
                        >
                            Observaciones
                        </label>

                        <input
                            type="text"
                            name="observacion"
                            id="observacion"
                            class="form-control"
                            maxlength="1000"
                            value="<?= htmlspecialchars(
                                $observacion,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            placeholder="Observaciones de la compra..."
                        >

                    </div>

                </div>

            </div>

        </div>


        <!-- ===================================================== -->
        <!-- BUSCADOR DE ARTICULOS -->
        <!-- ===================================================== -->

        <div class="card shadow-sm mb-3">

            <div class="card-header bg-body">

                <div class="d-flex justify-content-between align-items-center">

                    <div>

                        <i class="fa-solid fa-magnifying-glass me-2"></i>

                        <strong>
                            Agregar artículos
                        </strong>

                    </div>

                    <span class="text-muted small">
                        Buscar por nombre, código o código de barras
                    </span>

                </div>

            </div>

            <div class="card-body">

                <div class="row g-2">

                    <div class="col">

                        <div class="position-relative">

                            <input
                                type="search"
                                id="smartSearchInsumo"
                                class="form-control form-control-lg"
                                placeholder="Buscar artículo..."
                                autocomplete="off"
                                spellcheck="false"
                            >

                            <div
                                id="resultadosInsumos"
                                class="list-group position-absolute w-100 shadow-sm d-none"
                                style="
                                    z-index:1080;
                                    max-height:350px;
                                    overflow-y:auto;
                                "
                            ></div>

                        </div>

                    </div>

                    <div class="col-auto">

                        <button
                            type="button"
                            id="btnBuscarInsumo"
                            class="btn btn-primary btn-lg"
                        >
                            <i class="fa-solid fa-search"></i>
                            Buscar
                        </button>

                    </div>

                </div>


                <div
                    id="mensajeBusqueda"
                    class="small text-muted mt-2"
                ></div>

            </div>

        </div>


        <!-- ===================================================== -->
        <!-- ARTICULOS -->
        <!-- ===================================================== -->

        <div class="card shadow-sm mb-3">

            <div class="card-header bg-body">

                <div class="d-flex justify-content-between align-items-center">

                    <strong>

                        <i class="fa-solid fa-boxes-stacked me-2"></i>

                        Artículos de la compra

                    </strong>

                    <span
                        id="cantidadItems"
                        class="badge text-bg-secondary"
                    >
                        <?= count($items) ?>
                    </span>

                </div>

            </div>

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table
                        class="table table-hover align-middle mb-0"
                        id="tablaItems"
                    >

                        <thead class="table-light">

                            <tr>

                                <th style="width:35%">
                                    Artículo
                                </th>

                                <th style="width:12%">
                                    Cantidad
                                </th>

                                <th style="width:15%">
                                    Costo unitario
                                </th>

                                <th style="width:12%">
                                    Descuento
                                </th>

                                <th style="width:16%">
                                    Subtotal
                                </th>

                                <th style="width:10%"
                                    class="text-end"
                                >
                                    Acción
                                </th>

                            </tr>

                        </thead>

                        <tbody id="itemsBody">

                            <?php foreach ($items as $index => $item): ?>

                                <?php
                                $itemId = (int) (
                                    $item['id']
                                    ?? 0
                                );

                                $insumoId = (int) (
                                    $item['insumo_id']
                                    ?? 0
                                );

                                $nombreInsumo = (string) (
                                    $item['nombre_insumo']
                                    ?? $item['nombre']
                                    ?? 'Artículo'
                                );

                                $codigo = (string) (
                                    $item['codigo_parte']
                                    ?? ''
                                );

                                $cantidad = (float) (
                                    $item['cantidad']
                                    ?? 0
                                );

                                $precio = (float) (
                                    $item['precio_unitario']
                                    ?? 0
                                );

                                $descuento = (float) (
                                    $item['descuento']
                                    ?? 0
                                );

                                $subtotal = (float) (
                                    $item['subtotal']
                                    ?? (
                                        $cantidad * $precio
                                        - $descuento
                                    )
                                );

                                if ($subtotal < 0) {
                                    $subtotal = 0;
                                }
                                ?>

                                <tr
                                    class="compra-item"
                                    data-item-id="<?= $itemId ?>"
                                    data-insumo-id="<?= $insumoId ?>"
                                >

                                    <td>

                                        <div class="fw-semibold">

                                            <?= htmlspecialchars(
                                                $nombreInsumo,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        </div>

                                        <?php if ($codigo !== ''): ?>

                                            <div class="small text-muted">

                                                Código:
                                                <?= htmlspecialchars(
                                                    $codigo,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>

                                            </div>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <input
                                            type="number"
                                            class="form-control item-cantidad"
                                            min="0.001"
                                            step="0.001"
                                            value="<?= htmlspecialchars(
                                                (string) $cantidad,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>"
                                        >

                                    </td>


                                    <td>

                                        <input
                                            type="number"
                                            class="form-control item-precio"
                                            min="0"
                                            step="0.01"
                                            value="<?= htmlspecialchars(
                                                (string) $precio,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>"
                                        >

                                    </td>


                                    <td>

                                        <input
                                            type="number"
                                            class="form-control item-descuento"
                                            min="0"
                                            step="0.01"
                                            value="<?= htmlspecialchars(
                                                (string) $descuento,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>"
                                        >

                                    </td>


                                    <td>

                                        <span class="fw-semibold item-subtotal">

                                            <?= number_format(
                                                $subtotal,
                                                2,
                                                ',',
                                                '.'
                                            ) ?>

                                        </span>

                                    </td>


                                    <td class="text-end">

                                        <button
                                            type="button"
                                            class="btn btn-outline-danger btn-sm btn-eliminar-item"
                                            title="Eliminar artículo"
                                        >
                                            <i class="fa-solid fa-trash"></i>
                                        </button>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                        <tfoot>

                            <tr>

                                <td
                                    colspan="4"
                                    class="text-end fw-semibold"
                                >
                                    Subtotal
                                </td>

                                <td
                                    colspan="2"
                                    id="totalSubtotal"
                                    class="fw-bold"
                                >
                                    <?= number_format(
                                        $subtotalInicial,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                            </tr>

                        </tfoot>

                    </table>

                </div>


                <!-- SIN ITEMS -->

                <div
                    id="sinItems"
                    class="text-center text-muted py-5 <?= $items
                        ? 'd-none'
                        : '' ?>"
                >

                    <i class="fa-solid fa-box-open fa-2x mb-2"></i>

                    <div>
                        Todavía no agregaste artículos.
                    </div>

                    <div class="small">
                        Utilizá el buscador superior para agregarlos.
                    </div>

                </div>

            </div>

        </div>


        <!-- ===================================================== -->
        <!-- TOTALES -->
        <!-- ===================================================== -->

        <div class="row justify-content-end">

            <div class="col-xl-5 col-lg-6">

                <div class="card shadow-sm mb-3">

                    <div class="card-header bg-body">

                        <strong>
                            Totales
                        </strong>

                    </div>

                    <div class="card-body">

                        <div class="d-flex justify-content-between mb-2">

                            <span>
                                Subtotal
                            </span>

                            <strong id="resumenSubtotal">
                                <?= number_format(
                                    $subtotalInicial,
                                    2,
                                    ',',
                                    '.'
                                ) ?>
                            </strong>

                        </div>


                        <div class="mb-3">

                            <label
                                for="descuento"
                                class="form-label"
                            >
                                Descuento general
                            </label>

                            <input
                                type="number"
                                name="descuento"
                                id="descuento"
                                class="form-control text-end"
                                min="0"
                                step="0.01"
                                value="<?= htmlspecialchars(
                                    (string) $descuentoInicial,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label
                                for="iva"
                                class="form-label"
                            >
                                IVA
                            </label>

                            <input
                                type="number"
                                name="iva"
                                id="iva"
                                class="form-control text-end"
                                min="0"
                                step="0.01"
                                value="<?= htmlspecialchars(
                                    (string) $ivaInicial,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </div>


                        <hr>


                        <div class="d-flex justify-content-between align-items-center">

                            <span class="fs-5">
                                Total
                            </span>

                            <strong
                                id="resumenTotal"
                                class="fs-4"
                            >
                                <?= number_format(
                                    $totalInicial,
                                    2,
                                    ',',
                                    '.'
                                ) ?>
                            </strong>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- ===================================================== -->
        <!-- ACCIONES -->
        <!-- ===================================================== -->

        <div class="d-flex justify-content-between align-items-center mb-4">

            <a
                href="/compras"
                class="btn btn-outline-secondary"
            >
                Cancelar
            </a>

            <div class="d-flex gap-2">

                <?php if ($compraId > 0): ?>

                    <button
                        type="button"
                        id="btnGuardarCambios"
                        class="btn btn-primary btn-lg"
                    >
                        <i class="fa-solid fa-save me-1"></i>
                        Guardar cambios
                    </button>

                <?php else: ?>

                    <button
                        type="submit"
                        id="btnGuardarCompra"
                        class="btn btn-primary btn-lg"
                    >
                        <i class="fa-solid fa-save me-1"></i>
                        Guardar compra
                    </button>

                <?php endif; ?>

            </div>

        </div>

    </form>

</div>


<!-- ============================================================= -->
<!-- MODAL RESULTADOS DE BUSQUEDA -->
<!-- ============================================================= -->

<div
    class="modal fade"
    id="modalResultadosInsumos"
    tabindex="-1"
    aria-hidden="true"
>

    <div class="modal-dialog modal-lg modal-dialog-scrollable">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">

                    <i class="fa-solid fa-boxes-stacked me-2"></i>

                    Seleccionar artículo

                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Cerrar"
                ></button>

            </div>

            <div class="modal-body">

                <div
                    id="modalResultadosBody"
                    class="list-group"
                ></div>

            </div>

        </div>

    </div>

</div>


<script>
(function () {

    'use strict';

    /*
    |--------------------------------------------------------------------------
    | CONFIGURACION
    |--------------------------------------------------------------------------
    */

    const form =
        document.getElementById('formCompra');

    const csrf =
        document.getElementById('csrf')?.value || '';

    const searchInput =
        document.getElementById('smartSearchInsumo');

    const searchButton =
        document.getElementById('btnBuscarInsumo');

    const results =
        document.getElementById('resultadosInsumos');

    const modalResults =
        document.getElementById('modalResultadosBody');

    const alertBox =
        document.getElementById('comprasAlert');

    const itemsBody =
        document.getElementById('itemsBody');

    const sinItems =
        document.getElementById('sinItems');

    const cantidadItems =
        document.getElementById('cantidadItems');

    const subtotalElement =
        document.getElementById('totalSubtotal');

    const resumenSubtotal =
        document.getElementById('resumenSubtotal');

    const resumenTotal =
        document.getElementById('resumenTotal');

    const descuentoInput =
        document.getElementById('descuento');

    const ivaInput =
        document.getElementById('iva');

    const monedaInput =
        document.getElementById('moneda');

    const cotizacionContainer =
        document.getElementById('contenedorCotizacion');


    /*
    |--------------------------------------------------------------------------
    | UTILIDADES
    |--------------------------------------------------------------------------
    */

    function escapeHtml(value) {

        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');

    }


    function numero(value) {

        const n =
            parseFloat(
                String(value ?? '')
                    .replace(',', '.')
            );

        return Number.isFinite(n)
            ? n
            : 0;

    }


    function dinero(value) {

        return numero(value).toLocaleString(
            'es-AR',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

    }


    function mostrarError(message) {

        if (!alertBox) {
            return;
        }

        alertBox.className =
            'alert alert-danger';

        alertBox.textContent =
            String(message || 'Ocurrió un error.');

        alertBox.classList.remove('d-none');

        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });

    }


    function mostrarExito(message) {

        if (!alertBox) {
            return;
        }

        alertBox.className =
            'alert alert-success';

        alertBox.textContent =
            String(message || 'Operación realizada.');

        alertBox.classList.remove('d-none');

    }


    function ocultarAlerta() {

        if (!alertBox) {
            return;
        }

        alertBox.classList.add('d-none');

    }


    /*
    |--------------------------------------------------------------------------
    | COTIZACION
    |--------------------------------------------------------------------------
    */

    function actualizarMoneda() {

        if (!monedaInput || !cotizacionContainer) {
            return;
        }

        cotizacionContainer.style.display =
            monedaInput.value === 'USD'
                ? ''
                : 'none';

    }

    monedaInput?.addEventListener(
        'change',
        actualizarMoneda
    );

    actualizarMoneda();


    /*
    |--------------------------------------------------------------------------
    | CALCULAR ITEM
    |--------------------------------------------------------------------------
    */

    function calcularItem(row) {

        const cantidad =
            numero(
                row.querySelector(
                    '.item-cantidad'
                )?.value
            );

        const precio =
            numero(
                row.querySelector(
                    '.item-precio'
                )?.value
            );

        const descuento =
            numero(
                row.querySelector(
                    '.item-descuento'
                )?.value
            );

        let subtotal =
            cantidad * precio
            - descuento;

        if (subtotal < 0) {
            subtotal = 0;
        }

        const subtotalElement =
            row.querySelector(
                '.item-subtotal'
            );

        if (subtotalElement) {

            subtotalElement.textContent =
                dinero(subtotal);

        }

        return subtotal;

    }


    /*
    |--------------------------------------------------------------------------
    | CALCULAR TOTALES
    |--------------------------------------------------------------------------
    */

    function recalcularTotales() {

        if (!itemsBody) {
            return;
        }

        let subtotal = 0;

        const rows =
            itemsBody.querySelectorAll(
                '.compra-item'
            );

        rows.forEach(
            function (row) {

                subtotal +=
                    calcularItem(row);

            }
        );

        const descuento =
            numero(
                descuentoInput?.value
            );

        const iva =
            numero(
                ivaInput?.value
            );

        let total =
            subtotal
            - descuento
            + iva;

        if (total < 0) {
            total = 0;
        }

        if (subtotalElement) {

            subtotalElement.textContent =
                dinero(subtotal);

        }

        if (resumenSubtotal) {

            resumenSubtotal.textContent =
                dinero(subtotal);

        }

        if (resumenTotal) {

            resumenTotal.textContent =
                dinero(total);

        }

        if (cantidadItems) {

            cantidadItems.textContent =
                String(rows.length);

        }

        if (sinItems) {

            sinItems.classList.toggle(
                'd-none',
                rows.length > 0
            );

        }

    }


    /*
    |--------------------------------------------------------------------------
    | AGREGAR ITEM VISUALMENTE
    |--------------------------------------------------------------------------
    */

    function agregarItemVisual(item) {

        const insumoId =
            Number(item.id || item.insumo_id || 0);

        if (insumoId <= 0) {

            mostrarError(
                'El artículo seleccionado no tiene un ID válido.'
            );

            return;

        }


        /*
         * Evitar duplicados.
         */

        const existente =
            itemsBody.querySelector(
                '[data-insumo-id="' +
                insumoId +
                '"]'
            );

        if (existente) {

            const cantidadInput =
                existente.querySelector(
                    '.item-cantidad'
                );

            const cantidadActual =
                numero(
                    cantidadInput?.value
                );

            if (cantidadInput) {

                cantidadInput.value =
                    String(
                        cantidadActual + 1
                    );

            }

            recalcularTotales();

            return;

        }


        const nombre =
            String(
                item.nombre_insumo
                || item.nombre
                || item.descripcion
                || 'Artículo'
            );

        const codigo =
            String(
                item.codigo_parte
                || item.codigo
                || ''
            );

        const precio =
            numero(
                item.precio_costo
                ?? item.costo
                ?? item.precio
                ?? 0
            );


        const row =
            document.createElement('tr');

        row.className =
            'compra-item';

        row.dataset.itemId =
            '0';

        row.dataset.insumoId =
            String(insumoId);


        row.innerHTML = `

            <td>

                <div class="fw-semibold">
                    ${escapeHtml(nombre)}
                </div>

                ${
                    codigo !== ''
                        ? `
                            <div class="small text-muted">
                                Código:
                                ${escapeHtml(codigo)}
                            </div>
                          `
                        : ''
                }

            </td>

            <td>

                <input
                    type="number"
                    class="form-control item-cantidad"
                    min="0.001"
                    step="0.001"
                    value="1"
                >

            </td>

            <td>

                <input
                    type="number"
                    class="form-control item-precio"
                    min="0"
                    step="0.01"
                    value="${precio.toFixed(2)}"
                >

            </td>

            <td>

                <input
                    type="number"
                    class="form-control item-descuento"
                    min="0"
                    step="0.01"
                    value="0"
                >

            </td>

            <td>

                <span class="fw-semibold item-subtotal">
                    ${dinero(precio)}
                </span>

            </td>

            <td class="text-end">

                <button
                    type="button"
                    class="btn btn-outline-danger btn-sm btn-eliminar-item"
                    title="Eliminar artículo"
                >
                    <i class="fa-solid fa-trash"></i>
                </button>

            </td>

        `;


        itemsBody.appendChild(row);

        recalcularTotales();

    }


    /*
    |--------------------------------------------------------------------------
    | BUSQUEDA
    |--------------------------------------------------------------------------
    */

    let searchTimer = null;


    async function buscarInsumos() {

        const q =
            searchInput?.value.trim() || '';

        if (q.length < 2) {

            if (results) {

                results.classList.add(
                    'd-none'
                );

            }

            return;

        }


        if (results) {

            results.innerHTML = `
                <div class="list-group-item text-muted">
                    <i class="fa-solid fa-spinner fa-spin me-2"></i>
                    Buscando...
                </div>
            `;

            results.classList.remove(
                'd-none'
            );

        }


        try {

            const url =
                '/compras/buscar?q=' +
                encodeURIComponent(q) +
                '&limit=50';


            const response =
                await fetch(
                    url,
                    {
                        headers: {
                            'X-Requested-With':
                                'XMLHttpRequest'
                        }
                    }
                );


            const data =
                await response.json();


            if (!response.ok) {

                throw new Error(
                    data.message
                    || 'No se pudo realizar la búsqueda.'
                );

            }


            if (!data.success) {

                throw new Error(
                    data.message
                    || 'No se pudo realizar la búsqueda.'
                );

            }


            const items =
                Array.isArray(data.data)
                    ? data.data
                    : [];


            if (items.length === 0) {

                if (results) {

                    results.innerHTML = `
                        <div class="list-group-item text-muted">
                            No se encontraron artículos.
                        </div>
                    `;

                }

                return;

            }


            /*
             * Un resultado:
             *
             * se puede agregar directamente.
             *
             * Varios:
             *
             * mostramos modal/listado.
             */

            if (items.length === 1) {

                agregarItemVisual(
                    items[0]
                );

                if (results) {

                    results.classList.add(
                        'd-none'
                    );

                }

                if (searchInput) {

                    searchInput.value =
                        '';

                }

                return;

            }


            mostrarResultados(
                items
            );

        } catch (error) {

            mostrarError(
                error?.message
                || 'Error buscando artículos.'
            );

        }

    }


    function mostrarResultados(items) {

        if (!modalResults) {
            return;
        }

        modalResults.innerHTML = '';


        items.forEach(
            function (item) {

                const button =
                    document.createElement(
                        'button'
                    );

                button.type =
                    'button';

                button.className =
                    'list-group-item list-group-item-action';

                const nombre =
                    String(
                        item.nombre_insumo
                        || item.nombre
                        || item.descripcion
                        || 'Artículo'
                    );

                const codigo =
                    String(
                        item.codigo_parte
                        || item.codigo
                        || ''
                    );

                const precio =
                    numero(
                        item.precio_costo
                        ?? item.costo
                        ?? item.precio
                        ?? 0
                    );


                button.innerHTML = `

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="fw-semibold">
                                ${escapeHtml(nombre)}
                            </div>

                            ${
                                codigo !== ''
                                    ? `
                                        <div class="small text-muted">
                                            Código:
                                            ${escapeHtml(codigo)}
                                        </div>
                                      `
                                    : ''
                            }

                        </div>

                        <div class="fw-semibold">
                            $ ${dinero(precio)}
                        </div>

                    </div>

                `;


                button.addEventListener(
                    'click',
                    function () {

                        agregarItemVisual(
                            item
                        );

                        const modalElement =
                            document.getElementById(
                                'modalResultadosInsumos'
                            );

                        if (
                            modalElement
                            && window.bootstrap
                        ) {

                            const modal =
                                bootstrap.Modal
                                    .getInstance(
                                        modalElement
                                    );

                            modal?.hide();

                        }

                        if (searchInput) {

                            searchInput.value =
                                '';

                        }

                    }
                );


                modalResults.appendChild(
                    button
                );

            }
        );


        if (
            window.bootstrap
            && document.getElementById(
                'modalResultadosInsumos'
            )
        ) {

            const modal =
                new bootstrap.Modal(
                    document.getElementById(
                        'modalResultadosInsumos'
                    )
                );

            modal.show();

        }

    }


    /*
    |--------------------------------------------------------------------------
    | EVENTOS BUSCADOR
    |--------------------------------------------------------------------------
    */

    searchInput?.addEventListener(
        'input',
        function () {

            clearTimeout(
                searchTimer
            );

            searchTimer =
                setTimeout(
                    buscarInsumos,
                    300
                );

        }
    );


    searchInput?.addEventListener(
        'keydown',
        function (event) {

            if (
                event.key === 'Enter'
            ) {

                event.preventDefault();

                buscarInsumos();

            }

            if (
                event.key === 'Escape'
            ) {

                if (results) {

                    results.classList.add(
                        'd-none'
                    );

                }

            }

        }
    );


    searchButton?.addEventListener(
        'click',
        function () {

            buscarInsumos();

        }
    );


    /*
    |--------------------------------------------------------------------------
    | EVENTOS TABLA
    |--------------------------------------------------------------------------
    */

    itemsBody?.addEventListener(
        'input',
        function (event) {

            if (
                event.target.classList.contains(
                    'item-cantidad'
                )
                || event.target.classList.contains(
                    'item-precio'
                )
                || event.target.classList.contains(
                    'item-descuento'
                )
            ) {

                recalcularTotales();

            }

        }
    );


    itemsBody?.addEventListener(
        'click',
        function (event) {

            const button =
                event.target.closest(
                    '.btn-eliminar-item'
                );

            if (!button) {
                return;
            }

            const row =
                button.closest(
                    '.compra-item'
                );

            row?.remove();

            recalcularTotales();

        }
    );


    descuentoInput?.addEventListener(
        'input',
        recalcularTotales
    );


    ivaInput?.addEventListener(
        'input',
        recalcularTotales
    );


    /*
    |--------------------------------------------------------------------------
    | CERRAR RESULTADOS AL HACER CLICK AFUERA
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'click',
        function (event) {

            if (
                !searchInput
                || !results
            ) {
                return;
            }

            if (
                event.target === searchInput
                || results.contains(
                    event.target
                )
            ) {
                return;
            }

            results.classList.add(
                'd-none'
            );

        }
    );


    /*
    |--------------------------------------------------------------------------
    | CONSTRUIR PAYLOAD
    |--------------------------------------------------------------------------
    */

    function construirPayload() {

        const items = [];


        itemsBody
            ?.querySelectorAll(
                '.compra-item'
            )
            .forEach(
                function (row) {

                    const insumoId =
                        Number(
                            row.dataset.insumoId
                            || 0
                        );

                    if (insumoId <= 0) {
                        return;
                    }


                    const cantidad =
                        numero(
                            row.querySelector(
                                '.item-cantidad'
                            )?.value
                        );

                    const precio =
                        numero(
                            row.querySelector(
                                '.item-precio'
                            )?.value
                        );

                    const descuento =
                        numero(
                            row.querySelector(
                                '.item-descuento'
                            )?.value
                        );


                    items.push({
                        id:
                            Number(
                                row.dataset.itemId
                                || 0
                            ),

                        item_id:
                            Number(
                                row.dataset.itemId
                                || 0
                            ),

                        insumo_id:
                            insumoId,

                        cantidad:
                            cantidad,

                        precio_unitario:
                            precio,

                        costo_unitario:
                            precio,

                        descuento:
                            descuento
                    });

                }
            );


        return {

            csrf:
                csrf,

            proveedor_id:
                Number(
                    document.getElementById(
                        'proveedor_id'
                    )?.value
                    || 0
                ),

            numero:
                document.getElementById(
                    'numero'
                )?.value
                || '',

            fecha:
                document.getElementById(
                    'fecha'
                )?.value
                || '',

            moneda:
                monedaInput?.value
                || 'ARS',

            cotizacion_usd:
                numero(
                    document.getElementById(
                        'cotizacion_usd'
                    )?.value
                ),

            observacion:
                document.getElementById(
                    'observacion'
                )?.value
                || '',

            descuento:
                numero(
                    descuentoInput?.value
                ),

            iva:
                numero(
                    ivaInput?.value
                ),

            items:
                items

        };

    }


    /*
    |--------------------------------------------------------------------------
    | GUARDAR
    |--------------------------------------------------------------------------
    */

    async function guardarCompra() {

        ocultarAlerta();


        const payload =
            construirPayload();


        if (
            payload.proveedor_id <= 0
        ) {

            mostrarError(
                'Debe seleccionar un proveedor.'
            );

            return;

        }


        if (
            payload.items.length === 0
        ) {

            mostrarError(
                'Debe agregar al menos un artículo a la compra.'
            );

            return;

        }


        if (
            payload.moneda === 'USD'
            && payload.cotizacion_usd <= 0
        ) {

            mostrarError(
                'Debe indicar la cotización del dólar.'
            );

            return;

        }


        const compraId =
            <?= $compraId ?>;


        const url =
            compraId > 0
                ? '/compras/' +
                  compraId
                : '/compras';


        const method =
            'POST';


        const button =
            compraId > 0
                ? document.getElementById(
                    'btnGuardarCambios'
                )
                : document.getElementById(
                    'btnGuardarCompra'
                );


        if (button) {

            button.disabled =
                true;

            button.dataset.originalText =
                button.innerHTML;

            button.innerHTML = `
                <i class="fa-solid fa-spinner fa-spin me-1"></i>
                Guardando...
            `;

        }


        try {

            const response =
                await fetch(
                    url,
                    {
                        method:
                            method,

                        headers: {

                            'Content-Type':
                                'application/json',

                            'X-CSRF-TOKEN':
                                csrf,

                            'X-Requested-With':
                                'XMLHttpRequest'

                        },

                        body:
                            JSON.stringify(
                                payload
                            )

                    }
                );


            const data =
                await response.json();


            if (
                !response.ok
                || !data.success
            ) {

                throw new Error(
                    data.message
                    || 'No se pudo guardar la compra.'
                );

            }


            mostrarExito(
                data.message
                || 'Compra guardada correctamente.'
            );


            if (
                compraId <= 0
                && data.id
            ) {

                window.location.href =
                    '/compras/' +
                    Number(data.id);

                return;

            }


            setTimeout(
                function () {

                    window.location.href =
                        '/compras';

                },
                600
            );


        } catch (error) {

            mostrarError(
                error?.message
                || 'No se pudo guardar la compra.'
            );


        } finally {

            if (button) {

                button.disabled =
                    false;

                if (
                    button.dataset.originalText
                ) {

                    button.innerHTML =
                        button.dataset.originalText;

                }

            }

        }

    }


    form?.addEventListener(
        'submit',
        function (event) {

            event.preventDefault();

            guardarCompra();

        }
    );


    document
        .getElementById(
            'btnGuardarCambios'
        )
        ?.addEventListener(
            'click',
            guardarCompra
        );


    /*
    |--------------------------------------------------------------------------
    | INICIALIZACION
    |--------------------------------------------------------------------------
    */

    recalcularTotales();

})();
</script>