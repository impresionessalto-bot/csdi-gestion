<?php

declare(strict_types=1);

namespace App\Modules\Compras\Services;

use App\Modules\Compras\Repositories\Repository;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADOS
    |--------------------------------------------------------------------------
    */

    public const ESTADO_BORRADOR   = 'BORRADOR';
    public const ESTADO_PENDIENTE  = 'PENDIENTE';
    public const ESTADO_CONFIRMADA = 'CONFIRMADA';
    public const ESTADO_RECIBIDA   = 'RECIBIDA';
    public const ESTADO_ANULADA    = 'ANULADA';
    public const ESTADO_CERRADA    = 'CERRADA';

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        $compras = $this->safeArray(
            fn (): array => $this->repository->listar([
                'limit'  => 10,
                'offset' => 0,
            ])
        );

        $pendientes = $this->safeArray(
            fn (): array => $this->repository->pendientes(10)
        );

        $ultimas = $this->safeArray(
            fn (): array => $this->repository->ultimas(10)
        );

        $proveedores = $this->safeArray(
            fn (): array => $this->repository->proveedores()
        );

        $resumen = $this->safeArray(
            fn (): array => $this->repository->resumen()
        );

        return [
            'resumen'     => $resumen,
            'compras'     => $compras,
            'pendientes'  => $pendientes,
            'recepciones' => $pendientes,
            'ultimas'     => $ultimas,
            'proveedores' => $proveedores,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS FORMULARIO
    |--------------------------------------------------------------------------
    */

    public function datosFormulario(): array
    {
        $resultado = [
            'proveedores' => [],
            'insumos'     => [],
        ];

        /*
        |--------------------------------------------------------------------------
        | MÉTODO ESPECÍFICO DEL REPOSITORY
        |--------------------------------------------------------------------------
        */

        if (method_exists($this->repository, 'datosFormulario')) {
            try {
                $datos = $this->repository->datosFormulario();

                if (is_array($datos)) {
                    return [
                        'proveedores' => is_array(
                            $datos['proveedores'] ?? null
                        )
                            ? $datos['proveedores']
                            : [],

                        'insumos' => is_array(
                            $datos['insumos'] ?? null
                        )
                            ? $datos['insumos']
                            : [],
                    ];
                }
            } catch (Throwable) {
                // Continuamos con los métodos individuales.
            }
        }

        /*
        |--------------------------------------------------------------------------
        | PROVEEDORES
        |--------------------------------------------------------------------------
        */

        if (method_exists($this->repository, 'proveedores')) {
            $resultado['proveedores'] = $this->safeArray(
                fn (): array => $this->repository->proveedores()
            );
        }

        /*
        |--------------------------------------------------------------------------
        | INSUMOS
        |--------------------------------------------------------------------------
        */

        if (method_exists($this->repository, 'insumos')) {
            $resultado['insumos'] = $this->safeArray(
                fn (): array => $this->repository->insumos()
            );
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function listar(
        array $filtros = []
    ): array {
        return $this->repository->listar(
            $this->normalizarFiltros($filtros)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER
    |--------------------------------------------------------------------------
    */

    public function obtener(
        int $id
    ): ?array {
        if ($id <= 0) {
            return null;
        }

        $resultado = $this->repository->obtener($id);

        return is_array($resultado)
            ? $resultado
            : null;
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR
    |--------------------------------------------------------------------------
    */

    public function buscar(
        string $termino,
        int $limit = 20
    ): array {
        $termino = trim($termino);

        $limit = max(
            1,
            min(100, $limit)
        );

        return $this->repository->buscar(
            $termino,
            $limit
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(
        array $data,
        ?int $usuarioId = null
    ): int {
        $data = $this->validarCompra($data);

        $data['usuario_id'] = $usuarioId;
        $data['estado'] = self::ESTADO_BORRADOR;

        return $this->repository->crear($data);
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR
    |--------------------------------------------------------------------------
    |
    | Método utilizado por Controller::guardar().
    |
    | Se mantiene crear() como alias de compatibilidad para
    | cualquier código existente que todavía lo utilice.
    |--------------------------------------------------------------------------
    */

    public function guardar(
        array $data,
        ?int $usuarioId = null
    ): int {
        return $this->crear(
            $data,
            $usuarioId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(
        int $id,
        array $data,
        ?int $usuarioId = null
    ): bool {
        $compra = $this->obtenerObligatorio($id);

        $estado = $this->estadoCompra($compra);

        if (
            in_array(
                $estado,
                [
                    self::ESTADO_RECIBIDA,
                    self::ESTADO_CERRADA,
                    self::ESTADO_ANULADA,
                ],
                true
            )
        ) {
            throw new RuntimeException(
                'La compra no puede modificarse en su estado actual.'
            );
        }

        $data = $this->validarCompra(
            $data,
            false
        );

        /*
        |--------------------------------------------------------------------------
        | CAMPOS PROTEGIDOS
        |--------------------------------------------------------------------------
        */

        unset(
            $data['id'],
            $data['empresa_id'],
            $data['usuario_id'],
            $data['estado'],
            $data['fecha_recepcion'],
            $data['fecha_cierre'],
            $data['total'],
            $data['subtotal'],
            $data['total_iva'],
            $data['total_final'],
            $data['stock_actual']
        );

        /*
        |--------------------------------------------------------------------------
        | USUARIO MODIFICACIÓN
        |--------------------------------------------------------------------------
        |
        | Solamente se agrega si el Repository / DB admite el campo.
        | No forzamos su inclusión para evitar romper esquemas
        | existentes.
        |--------------------------------------------------------------------------
        */

        if (
            $usuarioId !== null
            && method_exists(
                $this->repository,
                'actualizar'
            )
        ) {
            /*
             * La actualización se mantiene delegada al Repository.
             */
        }

        return $this->repository->actualizar(
            $id,
            $data
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ANULAR
    |--------------------------------------------------------------------------
    */

    public function anular(
        int $id,
        ?int $usuarioId = null,
        ?string $motivo = null
    ): bool {
        $compra = $this->obtenerObligatorio($id);

        $estado = $this->estadoCompra($compra);

        if ($estado === self::ESTADO_ANULADA) {
            return true;
        }

        if ($estado === self::ESTADO_RECIBIDA) {
            throw new RuntimeException(
                'Una compra recibida no puede anularse directamente. Debe utilizarse el proceso de devolución.'
            );
        }

        if ($estado === self::ESTADO_CERRADA) {
            throw new RuntimeException(
                'Una compra cerrada no puede anularse.'
            );
        }

        return $this->repository->anular(
            $id,
            $usuarioId,
            $motivo
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CONFIRMAR
    |--------------------------------------------------------------------------
    */

    public function confirmar(
        int $id,
        ?int $usuarioId = null
    ): array {
        $compra = $this->obtenerObligatorio($id);

        $estado = $this->estadoCompra($compra);

        if ($estado === self::ESTADO_CONFIRMADA) {
            return $compra;
        }

        if ($estado !== self::ESTADO_BORRADOR) {
            throw new RuntimeException(
                'La compra no puede confirmarse desde su estado actual.'
            );
        }

        $this->validarItemsCompra($id);

        $ok = $this->repository->confirmar(
            $id,
            $usuarioId
        );

        if (!$ok) {
            throw new RuntimeException(
                'No se pudo confirmar la compra.'
            );
        }

        return $this->obtenerObligatorio($id);
    }

    /*
    |--------------------------------------------------------------------------
    | RECIBIR
    |--------------------------------------------------------------------------
    */

    public function recibir(
        int $id,
        array $data = [],
        ?int $usuarioId = null
    ): array {
        $compra = $this->obtenerObligatorio($id);

        $estado = $this->estadoCompra($compra);

        if (
            !in_array(
                $estado,
                [
                    self::ESTADO_CONFIRMADA,
                    self::ESTADO_PENDIENTE,
                ],
                true
            )
        ) {
            throw new RuntimeException(
                'La compra no está disponible para recepción.'
            );
        }

        $items = $this->repository->items($id);

        if (!$items) {
            throw new RuntimeException(
                'La compra no contiene artículos.'
            );
        }

        $fecha = $data['fecha_recepcion']
            ?? date('Y-m-d H:i:s');

        $fecha = trim((string) $fecha);

        if (
            $fecha === ''
            || strtotime($fecha) === false
        ) {
            throw new InvalidArgumentException(
                'La fecha de recepción no es válida.'
            );
        }

        $observacion = isset($data['observacion'])
            ? trim((string) $data['observacion'])
            : null;

        return $this->ejecutarRecepcionCompleta(
            $id,
            $fecha,
            $usuarioId,
            $observacion
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RECEPCIONES
    |--------------------------------------------------------------------------
    */

    public function recepciones(
        array $filtros = []
    ): array {
        if (method_exists($this->repository, 'recepciones')) {
            $resultado = $this->repository->recepciones(
                $filtros
            );

            return is_array($resultado)
                ? $resultado
                : [];
        }

        return $this->safeArray(
            fn (): array =>
                $this->repository->pendientes(100)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PENDIENTES RECEPCIÓN
    |--------------------------------------------------------------------------
    */

    public function pendientesRecepcion(
        int $id
    ): array {
        if ($id <= 0) {
            return [];
        }

        if (
            method_exists(
                $this->repository,
                'pendientesRecepcion'
            )
        ) {
            $resultado =
                $this->repository->pendientesRecepcion($id);

            return is_array($resultado)
                ? $resultado
                : [];
        }

        $items = $this->repository->items($id);

        if (!is_array($items)) {
            return [];
        }

        $resultado = [];

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $cantidad = (float) (
                $item['cantidad'] ?? 0
            );

            $recibida = (float) (
                $item['cantidad_recibida'] ?? 0
            );

            $pendiente = max(
                0,
                $cantidad - $recibida
            );

            if ($pendiente <= 0) {
                continue;
            }

            $item['cantidad_pendiente'] = $pendiente;

            $resultado[] = $item;
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR RECEPCIÓN
    |--------------------------------------------------------------------------
    */

    public function guardarRecepcion(
        int $id,
        array $data = [],
        ?int $usuarioId = null
    ): array {
        $items = $data['items'] ?? null;

        if (is_array($items) && $items) {
            return $this->recibirParcial(
                $id,
                $items,
                $usuarioId,
                isset($data['observacion'])
                    ? trim((string) $data['observacion'])
                    : null
            );
        }

        return $this->recibir(
            $id,
            $data,
            $usuarioId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RECEPCIÓN PARCIAL
    |--------------------------------------------------------------------------
    */

    public function recibirParcial(
        int $id,
        array $items,
        ?int $usuarioId = null,
        ?string $observacion = null
    ): array {
        $compra = $this->obtenerObligatorio($id);

        $estado = $this->estadoCompra($compra);

        if (
            !in_array(
                $estado,
                [
                    self::ESTADO_CONFIRMADA,
                    self::ESTADO_PENDIENTE,
                ],
                true
            )
        ) {
            throw new RuntimeException(
                'La compra no está disponible para recepción.'
            );
        }

        if (!$items) {
            throw new InvalidArgumentException(
                'Debe indicar al menos un artículo recibido.'
            );
        }

        $normalizados = [];

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $itemId = (int) (
                $item['item_id']
                ?? $item['id']
                ?? 0
            );

            $cantidad = (float) (
                $item['cantidad']
                ?? $item['cantidad_recibida']
                ?? 0
            );

            if ($itemId <= 0) {
                throw new InvalidArgumentException(
                    'Artículo de compra inválido.'
                );
            }

            if ($cantidad <= 0) {
                throw new InvalidArgumentException(
                    'La cantidad recibida debe ser mayor que cero.'
                );
            }

            $normalizados[] = [
                'item_id'  => $itemId,
                'cantidad' => $cantidad,
            ];
        }

        if (!$normalizados) {
            throw new InvalidArgumentException(
                'No se encontraron artículos válidos para recibir.'
            );
        }

        return $this->repository->recibirParcial(
            $id,
            $normalizados,
            $usuarioId,
            $observacion
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ITEMS
    |--------------------------------------------------------------------------
    */

    public function items(
        int $compraId
    ): array {
        if ($compraId <= 0) {
            return [];
        }

        $resultado =
            $this->repository->items($compraId);

        return is_array($resultado)
            ? $resultado
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | AGREGAR ITEM
    |--------------------------------------------------------------------------
    */

    public function agregarItem(
        int $compraId,
        array $data
    ): int {
        $compra =
            $this->obtenerObligatorio($compraId);

        $estado =
            $this->estadoCompra($compra);

        if (
            !in_array(
                $estado,
                [
                    self::ESTADO_BORRADOR,
                    self::ESTADO_PENDIENTE,
                ],
                true
            )
        ) {
            throw new RuntimeException(
                'No se pueden agregar artículos a una compra en este estado.'
            );
        }

        $insumoId =
            (int) ($data['insumo_id'] ?? 0);

        $cantidad =
            (float) ($data['cantidad'] ?? 0);

        $costo =
            (float) ($data['costo_unitario'] ?? 0);

        if ($insumoId <= 0) {
            throw new InvalidArgumentException(
                'Debe indicar un insumo válido.'
            );
        }

        if ($cantidad <= 0) {
            throw new InvalidArgumentException(
                'La cantidad debe ser mayor que cero.'
            );
        }

        if ($costo < 0) {
            throw new InvalidArgumentException(
                'El costo unitario no puede ser negativo.'
            );
        }

        $descuento =
            (float) ($data['descuento'] ?? 0);

        if ($descuento < 0) {
            throw new InvalidArgumentException(
                'El descuento no puede ser negativo.'
            );
        }

        return $this->repository->agregarItem(
            $compraId,
            [
                'insumo_id' => $insumoId,
                'cantidad' => $cantidad,
                'costo_unitario' => $costo,
                'descuento' => $descuento,
                'observacion' => $data['observacion'] ?? null,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR ITEM
    |--------------------------------------------------------------------------
    */

    public function actualizarItem(
        int $itemId,
        array $data
    ): bool {
        if ($itemId <= 0) {
            throw new InvalidArgumentException(
                'Artículo de compra inválido.'
            );
        }

        $cantidad =
            (float) ($data['cantidad'] ?? 0);

        $costo =
            (float) ($data['costo_unitario'] ?? 0);

        if ($cantidad <= 0) {
            throw new InvalidArgumentException(
                'La cantidad debe ser mayor que cero.'
            );
        }

        if ($costo < 0) {
            throw new InvalidArgumentException(
                'El costo unitario no puede ser negativo.'
            );
        }

        $descuento =
            (float) ($data['descuento'] ?? 0);

        if ($descuento < 0) {
            throw new InvalidArgumentException(
                'El descuento no puede ser negativo.'
            );
        }

        return $this->repository->actualizarItem(
            $itemId,
            [
                'cantidad' => $cantidad,
                'costo_unitario' => $costo,
                'descuento' => $descuento,
                'observacion' => $data['observacion'] ?? null,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR ITEM
    |--------------------------------------------------------------------------
    */

    public function eliminarItem(
        int $itemId
    ): bool {
        if ($itemId <= 0) {
            throw new InvalidArgumentException(
                'Artículo de compra inválido.'
            );
        }

        return $this->repository->eliminarItem(
            $itemId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PROVEEDORES
    |--------------------------------------------------------------------------
    */

    public function proveedores(): array
    {
        $resultado =
            $this->repository->proveedores();

        return is_array($resultado)
            ? $resultado
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | TOTALES
    |--------------------------------------------------------------------------
    */

    public function recalcular(
        int $id
    ): array {
        $this->obtenerObligatorio($id);

        $resultado =
            $this->repository->recalcular($id);

        return is_array($resultado)
            ? $resultado
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADOS
    |--------------------------------------------------------------------------
    */

    public function estados(): array
    {
        return [
            self::ESTADO_BORRADOR,
            self::ESTADO_PENDIENTE,
            self::ESTADO_CONFIRMADA,
            self::ESTADO_RECIBIDA,
            self::ESTADO_ANULADA,
            self::ESTADO_CERRADA,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDACIÓN COMPRA
    |--------------------------------------------------------------------------
    */

    private function validarCompra(
        array $data,
        bool $crear = true
    ): array {
        /*
        |--------------------------------------------------------------------------
        | PROVEEDOR
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['proveedor_id'])
            && (int) $data['proveedor_id'] < 0
        ) {
            throw new InvalidArgumentException(
                'Proveedor inválido.'
            );
        }

        if (
            $crear
            && empty($data['proveedor_id'])
        ) {
            throw new InvalidArgumentException(
                'Debe seleccionar un proveedor.'
            );
        }

        if (
            !$crear
            && array_key_exists(
                'proveedor_id',
                $data
            )
            && (int) $data['proveedor_id'] <= 0
        ) {
            throw new InvalidArgumentException(
                'Proveedor inválido.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | FECHA
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['fecha'])
            && trim((string) $data['fecha']) !== ''
        ) {
            $fecha =
                trim((string) $data['fecha']);

            if (strtotime($fecha) === false) {
                throw new InvalidArgumentException(
                    'La fecha de compra no es válida.'
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | OBSERVACIÓN
        |--------------------------------------------------------------------------
        */

        if (
            isset($data['observacion'])
            && !is_scalar($data['observacion'])
            && $data['observacion'] !== null
        ) {
            throw new InvalidArgumentException(
                'La observación no es válida.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | MONEDA
        |--------------------------------------------------------------------------
        */

        $moneda =
            strtoupper(
                trim(
                    (string) (
                        $data['moneda']
                        ?? 'ARS'
                    )
                )
            );

        if (
            !in_array(
                $moneda,
                [
                    'ARS',
                    'USD',
                ],
                true
            )
        ) {
            throw new InvalidArgumentException(
                'La moneda debe ser ARS o USD.'
            );
        }

        $data['moneda'] =
            $moneda;

        /*
        |--------------------------------------------------------------------------
        | COTIZACIÓN USD
        |--------------------------------------------------------------------------
        */

        if ($moneda === 'USD') {
            $cotizacion =
                (float) (
                    $data['cotizacion_usd']
                    ?? 0
                );

            if ($cotizacion <= 0) {
                throw new InvalidArgumentException(
                    'Debe indicar la cotización del dólar para una compra en USD.'
                );
            }

            $data['cotizacion_usd'] =
                $cotizacion;
        } else {
            /*
             * No dejamos cotización residual cuando
             * la operación está expresada en ARS.
             */
            $data['cotizacion_usd'] = 1;
        }

        /*
        |--------------------------------------------------------------------------
        | TOTALES CALCULADOS
        |--------------------------------------------------------------------------
        |
        | Nunca confiamos en totales enviados desde el navegador.
        |--------------------------------------------------------------------------
        */

        unset(
            $data['total'],
            $data['subtotal'],
            $data['total_iva'],
            $data['total_final'],
            $data['stock_actual']
        );

        return $data;
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDAR ITEMS
    |--------------------------------------------------------------------------
    */

    private function validarItemsCompra(
        int $compraId
    ): void {
        $items =
            $this->repository->items($compraId);

        if (!$items) {
            throw new InvalidArgumentException(
                'No se puede confirmar una compra sin artículos.'
            );
        }

        foreach ($items as $item) {
            if (!is_array($item)) {
                throw new InvalidArgumentException(
                    'La compra contiene un artículo inválido.'
                );
            }

            $cantidad =
                (float) (
                    $item['cantidad']
                    ?? 0
                );

            $insumoId =
                (int) (
                    $item['insumo_id']
                    ?? 0
                );

            if ($cantidad <= 0) {
                throw new InvalidArgumentException(
                    'La compra contiene un artículo con cantidad inválida.'
                );
            }

            if ($insumoId <= 0) {
                throw new InvalidArgumentException(
                    'La compra contiene un artículo sin insumo válido.'
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER OBLIGATORIO
    |--------------------------------------------------------------------------
    */

    private function obtenerObligatorio(
        int $id
    ): array {
        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de compra inválido.'
            );
        }

        $compra =
            $this->repository->obtener($id);

        if (
            !is_array($compra)
            || !$compra
        ) {
            throw new InvalidArgumentException(
                'La compra no existe.'
            );
        }

        return $compra;
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADO
    |--------------------------------------------------------------------------
    */

    private function estadoCompra(
        array $compra
    ): string {
        return strtoupper(
            trim(
                (string) (
                    $compra['estado']
                    ?? ''
                )
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | FILTROS
    |--------------------------------------------------------------------------
    */

    private function normalizarFiltros(
        array $filtros
    ): array {
        $permitidos = [
            'id',
            'proveedor_id',
            'estado',
            'fecha_desde',
            'fecha_hasta',
            'numero',
            'buscar',
            'q',
            'limit',
            'offset',
            'orden',
            'direccion',
        ];

        $resultado = [];

        foreach ($permitidos as $campo) {
            if (
                array_key_exists(
                    $campo,
                    $filtros
                )
            ) {
                $resultado[$campo] =
                    $filtros[$campo];
            }
        }

        if (
            isset($resultado['limit'])
        ) {
            $resultado['limit'] =
                max(
                    1,
                    min(
                        200,
                        (int) $resultado['limit']
                    )
                );
        }

        if (
            isset($resultado['offset'])
        ) {
            $resultado['offset'] =
                max(
                    0,
                    (int) $resultado['offset']
                );
        }

        if (
            isset($resultado['estado'])
            && $resultado['estado'] !== ''
        ) {
            $resultado['estado'] =
                strtoupper(
                    trim(
                        (string) $resultado['estado']
                    )
                );
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | RECEPCIÓN COMPLETA
    |--------------------------------------------------------------------------
    */

    private function ejecutarRecepcionCompleta(
        int $id,
        string $fecha,
        ?int $usuarioId,
        ?string $observacion
    ): array {
        if (
            !method_exists(
                $this->repository,
                'recibir'
            )
        ) {
            throw new RuntimeException(
                'El Repository de Compras no implementa el proceso de recepción.'
            );
        }

        $resultado =
            $this->repository->recibir(
                $id,
                $fecha,
                $usuarioId,
                $observacion
            );

        if (!is_array($resultado)) {
            throw new RuntimeException(
                'La recepción no devolvió un resultado válido.'
            );
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | SAFE ARRAY
    |--------------------------------------------------------------------------
    */

    private function safeArray(
        callable $callback
    ): array {
        try {
            $resultado =
                $callback();

            return is_array($resultado)
                ? $resultado
                : [];
        } catch (Throwable) {
            return [];
        }
    }
}