CREATE TABLE IF NOT EXISTS facturacion_items (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 origen_tipo VARCHAR(50) NOT NULL,
 origen_id INT UNSIGNED NOT NULL,
 cliente_id INT NULL,
 concepto VARCHAR(100) NOT NULL,
 descripcion VARCHAR(500) NULL,
 periodo_mes TINYINT UNSIGNED NULL,
 periodo_anio SMALLINT UNSIGNED NULL,
 cantidad DECIMAL(12,3) NOT NULL DEFAULT 1,
 precio_unitario DECIMAL(15,2) NOT NULL DEFAULT 0,
 importe DECIMAL(15,2) NOT NULL DEFAULT 0,
 estado ENUM('PENDIENTE','FACTURABLE','FACTURADO','NO_FACTURAR') NOT NULL DEFAULT 'PENDIENTE',
 factura_id INT UNSIGNED NULL,
 fecha_facturacion DATETIME NULL,
 observaciones TEXT NULL,
 created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id), UNIQUE KEY uq_origen(origen_tipo,origen_id), KEY idx_cliente(cliente_id), KEY idx_estado(estado), KEY idx_periodo(periodo_anio,periodo_mes), KEY idx_factura(factura_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS facturacion_facturas (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 cliente_id INT NULL,
 tipo_comprobante VARCHAR(20) NULL,
 punto_venta VARCHAR(10) NULL,
 numero_comprobante VARCHAR(30) NULL,
 proveedor VARCHAR(30) NULL,
 fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,
 impuestos DECIMAL(15,2) NOT NULL DEFAULT 0,
 total DECIMAL(15,2) NOT NULL DEFAULT 0,
 estado ENUM('BORRADOR','PENDIENTE','EMITIDA','ANULADA') NOT NULL DEFAULT 'BORRADOR',
 cae VARCHAR(50) NULL,
 cae_vencimiento DATE NULL,
 observaciones TEXT NULL,
 created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id), KEY idx_cliente(cliente_id), KEY idx_estado(estado), KEY idx_fecha(fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS facturacion_factura_items (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 factura_id INT UNSIGNED NOT NULL,
 item_id INT UNSIGNED NOT NULL,
 descripcion VARCHAR(500) NULL,
 cantidad DECIMAL(12,3) NOT NULL DEFAULT 1,
 precio_unitario DECIMAL(15,2) NOT NULL DEFAULT 0,
 importe DECIMAL(15,2) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(id), UNIQUE KEY uq_factura_item(factura_id,item_id), KEY idx_factura(factura_id), KEY idx_item(item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
