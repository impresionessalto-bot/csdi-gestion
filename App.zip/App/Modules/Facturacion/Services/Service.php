<?php

declare(strict_types=1);

namespace App\Modules\Facturacion\Services;

use App\Modules\Facturacion\Repositories\Repository;
use InvalidArgumentException;

final class Service
{
    private const ORIGENES = [
        'CONTADOR',
        'TNG',
        'SERVICIO',
        'VENTA',
    ];

    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(
        array $filtros = []
    ): array {

        $filtros =
            $this->normalizarFiltros(
                $filtros
            );

        return [
            'titulo' =>
                'Facturación',

            'resumen' =>
                $this->repository->resumen(
                    $filtros
                ),

            'items' =>
                $this->repository->listar(
                    $filtros
                ),

            'clientes' =>
                $this->repository->clientes(),

            'periodos' =>
                $this->repository->periodos(),

            'estados' =>
                $this->repository->estados(),

            'origenes' =>
                self::ORIGENES,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | DISPONIBLES
    |--------------------------------------------------------------------------
    */

    public function disponibles(
        string $origen,
        int $clienteId
    ): array {

        $origen =
            strtoupper(
                trim($origen)
            );

        if (
            !in_array(
                $origen,
                self::ORIGENES,
                true
            )
        ) {
            throw new InvalidArgumentException(
                'Origen de facturación no válido.'
            );
        }

        return match ($origen) {

            'CONTADOR' =>
                $this->repository
                    ->contadoresFacturables(
                        $clienteId
                    ),

            'TNG' =>
                $this->repository
                    ->informesTngFacturables(
                        $clienteId
                    ),

            'SERVICIO' =>
                $this->repository
                    ->serviciosFacturables(
                        $clienteId
                    ),

            'VENTA' =>
                $this->repository
                    ->ventasFacturables(),

            default =>
                [],
        };
    }

    /*
    |--------------------------------------------------------------------------
    | PREPARAR FACTURA
    |--------------------------------------------------------------------------
    */

    public function prepararFactura(
        array $data
    ): array {

        $clienteId =
            (int) (
                $data['cliente_id']
                ?? 0
            );

        $origen =
            strtoupper(
                trim(
                    (string) (
                        $data['origen_tipo']
                        ?? ''
                    )
                )
            );

        $origenId =
            (int) (
                $data['origen_id']
                ?? 0
            );

        if ($clienteId <= 0) {
            throw new InvalidArgumentException(
                'Debe seleccionar un cliente.'
            );
        }

        if (
            !in_array(
                $origen,
                self::ORIGENES,
                true
            )
        ) {
            throw new InvalidArgumentException(
                'Origen de facturación no válido.'
            );
        }

        if ($origenId <= 0) {
            throw new InvalidArgumentException(
                'Debe seleccionar un registro.'
            );
        }

        $registro =
            $this->repository
                ->obtenerOrigenFacturable(
                    $origen,
                    $origenId,
                    $clienteId
                );

        if (!$registro) {
            throw new InvalidArgumentException(
                'El registro no está disponible para facturación.'
            );
        }

        $cantidad =
            max(
                0.001,
                (float) (
                    $data['cantidad']
                    ?? 1
                )
            );

        $precio =
            max(
                0,
                (float) (
                    $data['precio_unitario']
                    ?? 0
                )
            );

        $importe =
            max(
                0,
                (float) (
                    $data['importe']
                    ?? 0
                )
            );

        if ($importe <= 0) {
            $importe =
                $cantidad * $precio;
        }

        $concepto =
            trim(
                (string) (
                    $data['concepto']
                    ?? ''
                )
            );

        if ($concepto === '') {
            $concepto =
                $this->conceptoPorOrigen(
                    $origen
                );
        }

        return [
            'cliente_id' =>
                $clienteId,

            'origen_tipo' =>
                $origen,

            'origen_id' =>
                $origenId,

            'concepto' =>
                $concepto,

            'descripcion' =>
                trim(
                    (string) (
                        $data['descripcion']
                        ?? ''
                    )
                ),

            'cantidad' =>
                $cantidad,

            'precio_unitario' =>
                $precio,

            'importe' =>
                $importe,

            'registro' =>
                $registro,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL
    |--------------------------------------------------------------------------
    */

    public function historial(
        array $filtros = []
    ): array {

        return $this->repository->historial(
            $this->normalizarFiltros(
                $filtros
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientes(): array
    {
        return $this->repository->clientes();
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR CLIENTE
    |--------------------------------------------------------------------------
    */

    public function crearCliente(
        array $data
    ): array {

        $nombre =
            trim(
                (string) (
                    $data['nombre']
                    ?? ''
                )
            );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El nombre del cliente es obligatorio.'
            );
        }

        $id =
            $this->repository->crearCliente(
                [
                    'nombre' =>
                        $nombre,

                    'cuit' =>
                        trim(
                            (string) (
                                $data['cuit']
                                ?? ''
                            )
                        ),

                    'email' =>
                        trim(
                            (string) (
                                $data['email']
                                ?? ''
                            )
                        ),

                    'telefono' =>
                        trim(
                            (string) (
                                $data['telefono']
                                ?? ''
                            )
                        ),
                ]
            );

        return [
            'id' =>
                $id,

            'nombre' =>
                $nombre,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | FILTROS
    |--------------------------------------------------------------------------
    */

    private function normalizarFiltros(
        array $filtros
    ): array {

        $origen =
            strtoupper(
                trim(
                    (string) (
                        $filtros['origen_tipo']
                        ?? ''
                    )
                )
            );

        if (
            $origen !== ''
            && !in_array(
                $origen,
                self::ORIGENES,
                true
            )
        ) {
            $origen = '';
        }

        return [
            'origen_tipo' =>
                $origen,

            'estado_facturacion' =>
                strtolower(
                    trim(
                        (string) (
                            $filtros[
                                'estado_facturacion'
                            ] ?? ''
                        )
                    )
                ),

            'cliente_id' =>
                max(
                    0,
                    (int) (
                        $filtros[
                            'cliente_id'
                        ] ?? 0
                    )
                ),

            'periodo_mes' =>
                max(
                    0,
                    (int) (
                        $filtros[
                            'periodo_mes'
                        ] ?? 0
                    )
                ),

            'periodo_anio' =>
                max(
                    0,
                    (int) (
                        $filtros[
                            'periodo_anio'
                        ] ?? 0
                    )
                ),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | CONCEPTO
    |--------------------------------------------------------------------------
    */

    private function conceptoPorOrigen(
        string $origen
    ): string {

        return match ($origen) {

            'CONTADOR' =>
                'Facturación por contador',

            'TNG' =>
                'Informe técnico TNG',

            'SERVICIO' =>
                'Servicio técnico',

            'VENTA' =>
                'Venta',

            default =>
                'Factura',
        };
    }
}