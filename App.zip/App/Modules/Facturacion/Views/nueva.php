<?php

declare(strict_types=1);

/**
 * ============================================================================
 * CSDI ERP PRO
 * FACTURACIÓN - NUEVA FACTURA
 * ============================================================================
 *
 * Vista:
 * App/Modules/Facturacion/Views/nueva.php
 *
 * Responsabilidad:
 *
 * - Seleccionar cliente.
 * - Seleccionar origen facturable.
 * - Cargar dinámicamente los registros disponibles.
 * - Preparar una factura.
 *
 * IMPORTANTE:
 *
 * Esta vista NO conecta con DUX.
 * Esta vista NO conecta con ARCA.
 *
 * El backend solamente prepara el origen de facturación.
 *
 * Orígenes soportados:
 *
 *   CONTADOR
 *   TNG
 *   SERVICIO
 *   ALQUILER
 *   VENTA
 *
 * ============================================================================
 */

$titulo = (string)($titulo ?? 'Nueva factura');

$csrf = (string)($csrf ?? '');

$tipo = strtoupper(
    trim(
        (string)($tipo ?? '')
    )
);

$clientes = is_array($clientes ?? null)
    ? $clientes
    : [];

$equipos = is_array($equipos ?? null)
    ? $equipos
    : [];

$informes = is_array($informes ?? null)
    ? $informes
    : [];

$servicios = is_array($servicios ?? null)
    ? $servicios
    : [];

$contadores = is_array($contadores ?? null)
    ? $contadores
    : [];

$ventas = is_array($ventas ?? null)
    ? $ventas
    : [];

$alquileres = is_array($alquileres ?? null)
    ? $alquileres
    : [];

/*
|--------------------------------------------------------------------------
| TIPO INICIAL
|--------------------------------------------------------------------------
*/

$tiposPermitidos = [
    'CONTADOR',
    'TNG',
    'SERVICIO',
    'ALQUILER',
    'VENTA',
];

if (
    $tipo !== '' &&
    !in_array(
        $tipo,
        $tiposPermitidos,
        true
    )
) {
    $tipo = '';
}

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

$esc = static function (
    mixed $value
): string {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
};

$selected = static function (
    string $value,
    string $current
): string {
    return $value === $current
        ? ' selected'
        : '';
};

$money = static function (
    mixed $value
): string {
    return number_format(
        (float)$value,
        2,
        ',',
        '.'
    );
};

?>

<div class="container-fluid py-4">

    <!-- ================================================================ -->
    <!-- HEADER -->
    <!-- ================================================================ -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 mb-1">
                <i class="bi bi-receipt me-2"></i>
                <?= $esc($titulo) ?>
            </h1>

            <div class="text-muted">
                Preparación de factura
            </div>
        </div>

        <div class="mt-3 mt-md-0">

            <a
                href="/facturacion"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Volver
            </a>

        </div>

    </div>


    <!-- ================================================================ -->
    <!-- AVISO -->
    <!-- ================================================================ -->

    <div class="alert alert-info border-0 shadow-sm">

        <div class="d-flex align-items-start">

            <i class="bi bi-info-circle fs-4 me-3"></i>

            <div>

                <strong>Preparación de factura</strong>

                <div class="small mt-1">

                    En esta etapa se selecciona y prepara el
                    origen facturable.

                    La emisión fiscal todavía no está conectada
                    con DUX ni con ARCA.

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================ -->
    <!-- FORMULARIO PRINCIPAL -->
    <!-- ================================================================ -->

    <form
        id="formNuevaFactura"
        method="post"
        action="/facturacion/guardar"
        autocomplete="off"
    >

        <input
            type="hidden"
            name="csrf"
            value="<?= $esc($csrf) ?>"
        >

        <input
            type="hidden"
            name="origen_tipo"
            id="origen_tipo"
            value="<?= $esc($tipo) ?>"
        >

        <input
            type="hidden"
            name="origen_id"
            id="origen_id"
            value=""
        >

        <div class="row g-4">


            <!-- ======================================================== -->
            <!-- COLUMNA IZQUIERDA -->
            <!-- ======================================================== -->

            <div class="col-12 col-xl-8">

                <!-- ==================================================== -->
                <!-- CLIENTE -->
                <!-- ==================================================== -->

                <div class="card shadow-sm border-0 mb-4">

                    <div class="card-header bg-white">

                        <h2 class="h6 mb-0">

                            <i class="bi bi-person me-2"></i>

                            Cliente

                        </h2>

                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-12">

                                <label
                                    for="cliente_id"
                                    class="form-label"
                                >
                                    Cliente
                                    <span class="text-danger">*</span>
                                </label>

                                <select
                                    class="form-select"
                                    id="cliente_id"
                                    name="cliente_id"
                                    required
                                >

                                    <option value="">
                                        Seleccionar cliente...
                                    </option>

                                    <?php foreach ($clientes as $cliente): ?>

                                        <?php

                                        if (!is_array($cliente)) {
                                            continue;
                                        }

                                        $clienteId =
                                            (int)(
                                                $cliente['id']
                                                ?? 0
                                            );

                                        $clienteNombre =
                                            (string)(
                                                $cliente['nombre']
                                                ?? ''
                                            );

                                        if ($clienteId <= 0) {
                                            continue;
                                        }

                                        ?>

                                        <option
                                            value="<?= $clienteId ?>"
                                        >
                                            <?= $esc($clienteNombre) ?>
                                        </option>

                                    <?php endforeach; ?>

                                </select>

                                <div class="form-text">
                                    El cliente determina los registros
                                    facturables disponibles.
                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- ==================================================== -->
                <!-- ORIGEN -->
                <!-- ==================================================== -->

                <div class="card shadow-sm border-0 mb-4">

                    <div class="card-header bg-white">

                        <h2 class="h6 mb-0">

                            <i class="bi bi-diagram-3 me-2"></i>

                            Origen de facturación

                        </h2>

                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <!-- CONTADOR -->

                            <div class="col-12 col-md-6 col-xl-4">

                                <button
                                    type="button"
                                    class="btn btn-outline-primary w-100 tipo-facturacion"
                                    data-tipo="CONTADOR"
                                >

                                    <i class="bi bi-speedometer2 d-block fs-3 mb-2"></i>

                                    <strong>
                                        Contador
                                    </strong>

                                    <small class="d-block text-muted mt-1">
                                        Lecturas / facturación por contador
                                    </small>

                                </button>

                            </div>


                            <!-- TNG -->

                            <div class="col-12 col-md-6 col-xl-4">

                                <button
                                    type="button"
                                    class="btn btn-outline-primary w-100 tipo-facturacion"
                                    data-tipo="TNG"
                                >

                                    <i class="bi bi-file-earmark-text d-block fs-3 mb-2"></i>

                                    <strong>
                                        Informe TNG
                                    </strong>

                                    <small class="d-block text-muted mt-1">
                                        Informes técnicos facturables
                                    </small>

                                </button>

                            </div>


                            <!-- SERVICIO -->

                            <div class="col-12 col-md-6 col-xl-4">

                                <button
                                    type="button"
                                    class="btn btn-outline-primary w-100 tipo-facturacion"
                                    data-tipo="SERVICIO"
                                >

                                    <i class="bi bi-tools d-block fs-3 mb-2"></i>

                                    <strong>
                                        Servicio técnico
                                    </strong>

                                    <small class="d-block text-muted mt-1">
                                        Servicios técnicos finalizados
                                    </small>

                                </button>

                            </div>


                            <!-- ALQUILER -->

                            <div class="col-12 col-md-6 col-xl-4">

                                <button
                                    type="button"
                                    class="btn btn-outline-primary w-100 tipo-facturacion"
                                    data-tipo="ALQUILER"
                                >

                                    <i class="bi bi-printer d-block fs-3 mb-2"></i>

                                    <strong>
                                        Alquiler
                                    </strong>

                                    <small class="d-block text-muted mt-1">
                                        Contratos de alquiler activos
                                    </small>

                                </button>

                            </div>


                            <!-- VENTA -->

                            <div class="col-12 col-md-6 col-xl-4">

                                <button
                                    type="button"
                                    class="btn btn-outline-primary w-100 tipo-facturacion"
                                    data-tipo="VENTA"
                                >

                                    <i class="bi bi-cart3 d-block fs-3 mb-2"></i>

                                    <strong>
                                        Venta
                                    </strong>

                                    <small class="d-block text-muted mt-1">
                                        Ventas todavía no facturadas
                                    </small>

                                </button>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- ==================================================== -->
                <!-- REGISTROS DISPONIBLES -->
                <!-- ==================================================== -->

                <div
                    class="card shadow-sm border-0 mb-4"
                    id="cardRegistros"
                >

                    <div class="card-header bg-white">

                        <div class="d-flex justify-content-between align-items-center">

                            <h2 class="h6 mb-0">

                                <i class="bi bi-list-check me-2"></i>

                                Registros disponibles

                            </h2>

                            <span
                                class="badge text-bg-secondary"
                                id="badgeCantidad"
                            >
                                0
                            </span>

                        </div>

                    </div>

                    <div class="card-body p-0">

                        <div
                            id="loadingRegistros"
                            class="text-center py-5 d-none"
                        >

                            <div
                                class="spinner-border text-primary"
                                role="status"
                            ></div>

                            <div class="small text-muted mt-2">
                                Cargando registros...
                            </div>

                        </div>


                        <div
                            id="mensajeRegistros"
                            class="text-center text-muted py-5 px-3"
                        >

                            <i class="bi bi-arrow-up-circle fs-1 d-block mb-3"></i>

                            <div>
                                Seleccione un cliente y un
                                origen de facturación.
                            </div>

                        </div>


                        <div
                            id="contenedorRegistros"
                            class="table-responsive d-none"
                        >

                            <table class="table table-hover align-middle mb-0">

                                <thead class="table-light">

                                    <tr id="cabeceraRegistros">
                                        <!-- JS -->
                                    </tr>

                                </thead>

                                <tbody id="tablaRegistros">
                                    <!-- JS -->
                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>


                <!-- ==================================================== -->
                <!-- DETALLE -->
                <!-- ==================================================== -->

                <div
                    class="card shadow-sm border-0 mb-4"
                    id="cardDetalle"
                >

                    <div class="card-header bg-white">

                        <h2 class="h6 mb-0">

                            <i class="bi bi-card-text me-2"></i>

                            Detalle

                        </h2>

                    </div>

                    <div class="card-body">

                        <div
                            id="detalleVacio"
                            class="text-muted text-center py-4"
                        >

                            <i class="bi bi-receipt fs-1 d-block mb-2"></i>

                            Seleccione un registro para continuar.

                        </div>


                        <div
                            id="detalleSeleccionado"
                            class="d-none"
                        >

                            <div class="row g-3">

                                <div class="col-12 col-md-6">

                                    <label class="form-label">
                                        Concepto
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        name="concepto"
                                        id="concepto"
                                        maxlength="150"
                                    >

                                </div>


                                <div class="col-12 col-md-6">

                                    <label class="form-label">
                                        Descripción
                                    </label>

                                    <input
                                        type="text"
                                        class="form-control"
                                        name="descripcion"
                                        id="descripcion"
                                        maxlength="500"
                                    >

                                </div>


                                <div class="col-12 col-md-4">

                                    <label class="form-label">
                                        Cantidad
                                    </label>

                                    <input
                                        type="number"
                                        class="form-control"
                                        name="cantidad"
                                        id="cantidad"
                                        min="0.001"
                                        step="0.001"
                                        value="1"
                                    >

                                </div>


                                <div class="col-12 col-md-4">

                                    <label class="form-label">
                                        Precio unitario
                                    </label>

                                    <input
                                        type="number"
                                        class="form-control"
                                        name="precio_unitario"
                                        id="precio_unitario"
                                        min="0"
                                        step="0.01"
                                        value="0"
                                    >

                                </div>


                                <div class="col-12 col-md-4">

                                    <label class="form-label">
                                        Importe
                                    </label>

                                    <input
                                        type="number"
                                        class="form-control"
                                        name="importe"
                                        id="importe"
                                        min="0"
                                        step="0.01"
                                        value="0"
                                    >

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- ======================================================== -->
            <!-- COLUMNA DERECHA -->
            <!-- ======================================================== -->

            <div class="col-12 col-xl-4">

                <!-- ==================================================== -->
                <!-- RESUMEN -->
                <!-- ==================================================== -->

                <div class="card shadow-sm border-0 mb-4 sticky-xl-top"
                     style="top: 1rem;">

                    <div class="card-header bg-white">

                        <h2 class="h6 mb-0">

                            <i class="bi bi-receipt-cutoff me-2"></i>

                            Resumen

                        </h2>

                    </div>

                    <div class="card-body">

                        <div class="mb-3">

                            <div class="small text-muted">
                                Cliente
                            </div>

                            <div
                                class="fw-semibold"
                                id="resumenCliente"
                            >
                                —
                            </div>

                        </div>


                        <div class="mb-3">

                            <div class="small text-muted">
                                Origen
                            </div>

                            <div
                                class="fw-semibold"
                                id="resumenOrigen"
                            >
                                —
                            </div>

                        </div>


                        <div class="mb-3">

                            <div class="small text-muted">
                                Registro
                            </div>

                            <div
                                class="fw-semibold"
                                id="resumenRegistro"
                            >
                                —
                            </div>

                        </div>


                        <hr>


                        <div class="d-flex justify-content-between mb-2">

                            <span>
                                Cantidad
                            </span>

                            <strong id="resumenCantidad">
                                0
                            </strong>

                        </div>


                        <div class="d-flex justify-content-between mb-2">

                            <span>
                                Precio unitario
                            </span>

                            <strong id="resumenPrecio">
                                $ 0,00
                            </strong>

                        </div>


                        <div class="d-flex justify-content-between fs-5">

                            <span>
                                Importe
                            </span>

                            <strong id="resumenImporte">
                                $ 0,00
                            </strong>

                        </div>


                        <hr>


                        <!-- ESTADO -->

                        <div class="mb-3">

                            <label
                                for="estado"
                                class="form-label"
                            >
                                Estado
                            </label>

                            <select
                                class="form-select"
                                id="estado"
                                name="estado"
                            >

                                <option value="PENDIENTE">
                                    Pendiente
                                </option>

                                <option
                                    value="FACTURABLE"
                                    selected
                                >
                                    Facturable
                                </option>

                                <option value="NO_FACTURAR">
                                    No facturar
                                </option>

                            </select>

                        </div>


                        <!-- OBSERVACIONES -->

                        <div class="mb-3">

                            <label
                                for="observaciones"
                                class="form-label"
                            >
                                Observaciones
                            </label>

                            <textarea
                                class="form-control"
                                id="observaciones"
                                name="observaciones"
                                rows="3"
                            ></textarea>

                        </div>


                        <!-- BOTÓN -->

                        <button
                            type="submit"
                            id="btnGuardar"
                            class="btn btn-primary w-100"
                            disabled
                        >

                            <i class="bi bi-check2-circle me-1"></i>

                            Preparar factura

                        </button>


                        <div
                            id="mensajeGuardar"
                            class="mt-3 d-none"
                        ></div>

                    </div>

                </div>


                <!-- ==================================================== -->
                <!-- INFORMACIÓN -->
                <!-- ==================================================== -->

                <div class="card border-0 bg-light">

                    <div class="card-body">

                        <h3 class="h6">

                            <i class="bi bi-shield-check me-2"></i>

                            Flujo de facturación

                        </h3>

                        <ol class="small text-muted mb-0 ps-3">

                            <li class="mb-2">
                                Seleccionar cliente.
                            </li>

                            <li class="mb-2">
                                Seleccionar origen.
                            </li>

                            <li class="mb-2">
                                Seleccionar registro.
                            </li>

                            <li class="mb-2">
                                Revisar importe.
                            </li>

                            <li>
                                Preparar factura.
                            </li>

                        </ol>

                        <hr>

                        <div class="small text-muted">

                            <strong>Próxima etapa:</strong>

                            el resultado preparado podrá ser
                            enviado mediante el conector fiscal
                            correspondiente.

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </form>

</div>


<script>

(function () {

    'use strict';

    /*
    |--------------------------------------------------------------------------
    | CONFIGURACIÓN
    |--------------------------------------------------------------------------
    */

    const urls = {

        clientes:
            '/facturacion/clientes',

        equipos:
            '/facturacion/equipos',

        informes:
            '/facturacion/informes',

        servicios:
            '/facturacion/servicios',

        contadores:
            '/facturacion/contadores',

        ventas:
            '/facturacion/ventas',

        alquileres:
            '/facturacion/alquileres',

        guardar:
            '/facturacion/guardar'

    };


    /*
    |--------------------------------------------------------------------------
    | ELEMENTOS
    |--------------------------------------------------------------------------
    */

    const form =
        document.getElementById(
            'formNuevaFactura'
        );

    const cliente =
        document.getElementById(
            'cliente_id'
        );

    const origenTipo =
        document.getElementById(
            'origen_tipo'
        );

    const origenId =
        document.getElementById(
            'origen_id'
        );

    const contenedor =
        document.getElementById(
            'contenedorRegistros'
        );

    const tabla =
        document.getElementById(
            'tablaRegistros'
        );

    const cabecera =
        document.getElementById(
            'cabeceraRegistros'
        );

    const mensaje =
        document.getElementById(
            'mensajeRegistros'
        );

    const loading =
        document.getElementById(
            'loadingRegistros'
        );

    const badgeCantidad =
        document.getElementById(
            'badgeCantidad'
        );

    const btnGuardar =
        document.getElementById(
            'btnGuardar'
        );

    const concepto =
        document.getElementById(
            'concepto'
        );

    const descripcion =
        document.getElementById(
            'descripcion'
        );

    const cantidad =
        document.getElementById(
            'cantidad'
        );

    const precio =
        document.getElementById(
            'precio_unitario'
        );

    const importe =
        document.getElementById(
            'importe'
        );

    const resumenCliente =
        document.getElementById(
            'resumenCliente'
        );

    const resumenOrigen =
        document.getElementById(
            'resumenOrigen'
        );

    const resumenRegistro =
        document.getElementById(
            'resumenRegistro'
        );

    const resumenCantidad =
        document.getElementById(
            'resumenCantidad'
        );

    const resumenPrecio =
        document.getElementById(
            'resumenPrecio'
        );

    const resumenImporte =
        document.getElementById(
            'resumenImporte'
        );

    const mensajeGuardar =
        document.getElementById(
            'mensajeGuardar'
        );


    /*
    |--------------------------------------------------------------------------
    | ESTADO
    |--------------------------------------------------------------------------
    */

    let registrosActuales = [];

    let registroSeleccionado = null;


    /*
    |--------------------------------------------------------------------------
    | NOMBRES
    |--------------------------------------------------------------------------
    */

    const nombresOrigen = {

        CONTADOR:
            'Contador',

        TNG:
            'Informe TNG',

        SERVICIO:
            'Servicio técnico',

        ALQUILER:
            'Alquiler',

        VENTA:
            'Venta'

    };


    /*
    |--------------------------------------------------------------------------
    | HELPERS
    |--------------------------------------------------------------------------
    */

    function escapeHtml(value) {

        const div =
            document.createElement('div');

        div.textContent =
            value == null
                ? ''
                : String(value);

        return div.innerHTML;

    }


    function money(value) {

        const number =
            Number(value || 0);

        return number.toLocaleString(
            'es-AR',
            {
                style: 'currency',
                currency: 'ARS'
            }
        );

    }


    function number(value) {

        const result =
            Number(value || 0);

        return result.toLocaleString(
            'es-AR',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

    }


    function getCsrf() {

        const input =
            form.querySelector(
                'input[name="csrf"]'
            );

        return input
            ? input.value
            : '';

    }


    async function request(
        url,
        options = {}
    ) {

        const response =
            await fetch(
                url,
                {
                    credentials: 'same-origin',
                    ...options
                }
            );

        let data;

        try {

            data =
                await response.json();

        } catch (error) {

            throw new Error(
                'La respuesta del servidor no es válida.'
            );

        }

        if (
            !response.ok ||
            data.success === false
        ) {

            throw new Error(
                data.message ||
                'No fue posible completar la operación.'
            );

        }

        return data;

    }


    /*
    |--------------------------------------------------------------------------
    | SELECCIONAR TIPO
    |--------------------------------------------------------------------------
    */

    document
        .querySelectorAll(
            '.tipo-facturacion'
        )
        .forEach(
            function (button) {

                button.addEventListener(
                    'click',
                    function () {

                        document
                            .querySelectorAll(
                                '.tipo-facturacion'
                            )
                            .forEach(
                                function (item) {

                                    item.classList.remove(
                                        'active'
                                    );

                                }
                            );

                        this.classList.add(
                            'active'
                        );

                        origenTipo.value =
                            this.dataset.tipo || '';

                        limpiarSeleccion();

                        cargarRegistros();

                    }
                );

            }
        );


    /*
    |--------------------------------------------------------------------------
    | CLIENTE
    |--------------------------------------------------------------------------
    */

    cliente.addEventListener(
        'change',
        function () {

            limpiarSeleccion();

            cargarRegistros();

        }
    );


    /*
    |--------------------------------------------------------------------------
    | CARGAR REGISTROS
    |--------------------------------------------------------------------------
    */

    async function cargarRegistros() {

        const clienteId =
            Number(
                cliente.value || 0
            );

        const tipo =
            origenTipo.value;

        limpiarSeleccion();

        if (
            clienteId <= 0 ||
            tipo === ''
        ) {

            mostrarMensaje(
                'Seleccione un cliente y un origen de facturación.'
            );

            return;

        }

        const url =
            obtenerUrlOrigen(tipo);

        if (!url) {

            mostrarMensaje(
                'Origen de facturación no soportado.'
            );

            return;

        }

        mostrarLoading(true);

        try {

            const data =
                await request(
                    url +
                    '?cliente_id=' +
                    encodeURIComponent(
                        clienteId
                    )
                );

            registrosActuales =
                obtenerRegistros(data);

            renderRegistros(
                registrosActuales
            );

        } catch (error) {

            registrosActuales = [];

            mostrarMensaje(
                error.message ||
                'No fue posible cargar los registros.'
            );

        } finally {

            mostrarLoading(false);

        }

    }


    /*
    |--------------------------------------------------------------------------
    | URL SEGÚN ORIGEN
    |--------------------------------------------------------------------------
    */

    function obtenerUrlOrigen(
        tipo
    ) {

        switch (tipo) {

            case 'CONTADOR':
                return urls.contadores;

            case 'TNG':
                return urls.informes;

            case 'SERVICIO':
                return urls.servicios;

            case 'ALQUILER':
                return urls.alquileres;

            case 'VENTA':
                return urls.ventas;

            default:
                return null;

        }

    }


    /*
    |--------------------------------------------------------------------------
    | EXTRAER DATA
    |--------------------------------------------------------------------------
    */

    function obtenerRegistros(
        response
    ) {

        if (
            Array.isArray(
                response.data
            )
        ) {

            return response.data;

        }

        const tipo =
            origenTipo.value;

        const keys = {

            CONTADOR:
                'contadores',

            TNG:
                'informes',

            SERVICIO:
                'servicios',

            ALQUILER:
                'alquileres',

            VENTA:
                'ventas'

        };

        const key =
            keys[tipo];

        if (
            key &&
            Array.isArray(
                response[key]
            )
        ) {

            return response[key];

        }

        return [];

    }


    /*
    |--------------------------------------------------------------------------
    | RENDER
    |--------------------------------------------------------------------------
    */

    function renderRegistros(
        rows
    ) {

        tabla.innerHTML = '';

        cabecera.innerHTML = '';

        badgeCantidad.textContent =
            rows.length;

        if (
            !rows.length
        ) {

            contenedor.classList.add(
                'd-none'
            );

            mostrarMensaje(
                'No hay registros disponibles para facturar.'
            );

            return;

        }

        construirCabecera();

        rows.forEach(
            function (
                row,
                index
            ) {

                const tr =
                    document.createElement(
                        'tr'
                    );

                tr.dataset.index =
                    String(index);

                tr.style.cursor =
                    'pointer';

                tr.innerHTML =
                    construirFila(
                        row,
                        index
                    );

                tr.addEventListener(
                    'click',
                    function () {

                        seleccionarRegistro(
                            row,
                            index
                        );

                    }
                );

                tabla.appendChild(
                    tr
                );

            }
        );

        mensaje.classList.add(
            'd-none'
        );

        contenedor.classList.remove(
            'd-none'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | CABECERA
    |--------------------------------------------------------------------------
    */

    function construirCabecera() {

        const tipo =
            origenTipo.value;

        let html = '';

        html += '<th>ID</th>';

        if (
            tipo === 'TNG'
        ) {

            html +=
                '<th>Informe</th>';

        }

        html += '<th>Fecha / período</th>';

        html += '<th>Descripción</th>';

        html +=
            '<th class="text-end">Importe</th>';

        html +=
            '<th class="text-center">Estado</th>';

        cabecera.innerHTML =
            html;

    }


    /*
    |--------------------------------------------------------------------------
    | FILA
    |--------------------------------------------------------------------------
    */

    function construirFila(
        row,
        index
    ) {

        const tipo =
            origenTipo.value;

        const id =
            row.id ??
            row.origen_id ??
            '';

        let html = '';

        html +=
            '<td>' +
            '<span class="fw-semibold">' +
            escapeHtml(id) +
            '</span>' +
            '</td>';


        if (
            tipo === 'TNG'
        ) {

            html +=
                '<td>' +
                escapeHtml(
                    row.nro_informe ??
                    ''
                ) +
                '</td>';

        }


        html +=
            '<td>' +
            escapeHtml(
                obtenerPeriodo(row)
            ) +
            '</td>';


        html +=
            '<td>' +
            escapeHtml(
                obtenerDescripcion(row)
            ) +
            '</td>';


        html +=
            '<td class="text-end">' +
            money(
                obtenerImporte(row)
            ) +
            '</td>';


        html +=
            '<td class="text-center">' +
            estadoBadge(
                row.estado
            ) +
            '</td>';


        return html;

    }


    /*
    |--------------------------------------------------------------------------
    | PERIODO
    |--------------------------------------------------------------------------
    */

    function obtenerPeriodo(
        row
    ) {

        if (
            row.fecha
        ) {

            return String(
                row.fecha
            );

        }

        if (
            row.fecha_solicitud
        ) {

            return String(
                row.fecha_solicitud
            );

        }

        const mes =
            row.periodo_mes ??
            row.periodo ??
            '';

        const anio =
            row.periodo_anio ??
            row.anio ??
            '';

        if (
            mes !== '' ||
            anio !== ''
        ) {

            return (
                String(mes) +
                '/' +
                String(anio)
            );

        }

        return '—';

    }


    /*
    |--------------------------------------------------------------------------
    | DESCRIPCIÓN
    |--------------------------------------------------------------------------
    */

    function obtenerDescripcion(
        row
    ) {

        return (
            row.descripcion ??
            row.concepto ??
            row.descripcion_problema ??
            row.tipo_servicio ??
            'Registro facturable'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | IMPORTE
    |--------------------------------------------------------------------------
    */

    function obtenerImporte(
        row
    ) {

        if (
            row.importe !== undefined &&
            row.importe !== null
        ) {

            return Number(
                row.importe
            );

        }

        if (
            row.total_venta !== undefined
        ) {

            return Number(
                row.total_venta
            );

        }

        if (
            row.monto_facturar !== undefined
        ) {

            return Number(
                row.monto_facturar
            );

        }

        if (
            row.precio_unitario !== undefined
        ) {

            return Number(
                row.precio_unitario
            );

        }

        return 0;

    }


    /*
    |--------------------------------------------------------------------------
    | ESTADO
    |--------------------------------------------------------------------------
    */

    function estadoBadge(
        estado
    ) {

        const value =
            String(
                estado || 'PENDIENTE'
            ).toUpperCase();

        let cls =
            'text-bg-secondary';

        if (
            value === 'FACTURABLE'
        ) {

            cls =
                'text-bg-success';

        } else if (
            value === 'FACTURADO'
        ) {

            cls =
                'text-bg-primary';

        } else if (
            value === 'NO_FACTURAR'
        ) {

            cls =
                'text-bg-danger';

        }

        return (
            '<span class="badge ' +
            cls +
            '">' +
            escapeHtml(value) +
            '</span>'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | SELECCIONAR REGISTRO
    |--------------------------------------------------------------------------
    */

    function seleccionarRegistro(
        row,
        index
    ) {

        registroSeleccionado =
            row;

        const id =
            Number(
                row.id ??
                row.origen_id ??
                0
            );

        if (
            id <= 0
        ) {

            return;

        }

        origenId.value =
            String(id);

        /*
        |--------------------------------------------------------------------------
        | DETALLE
        |--------------------------------------------------------------------------
        */

        const descripcionValor =
            obtenerDescripcion(
                row
            );

        concepto.value =
            row.concepto ??
            obtenerConceptoPorTipo();

        descripcion.value =
            row.descripcion ??
            descripcionValor;

        cantidad.value =
            row.cantidad ??
            1;

        precio.value =
            row.precio_unitario ??
            obtenerImporte(row);

        importe.value =
            row.importe ??
            obtenerImporte(row);

        /*
        |--------------------------------------------------------------------------
        | RESUMEN
        |--------------------------------------------------------------------------
        */

        resumenCliente.textContent =
            cliente.options[
                cliente.selectedIndex
            ]?.text ||
            '—';

        resumenOrigen.textContent =
            nombresOrigen[
                origenTipo.value
            ] ||
            origenTipo.value ||
            '—';

        resumenRegistro.textContent =
            '#' + id;

        actualizarResumen();

        document
            .querySelectorAll(
                '#tablaRegistros tr'
            )
            .forEach(
                function (tr) {

                    tr.classList.remove(
                        'table-primary'
                    );

                }
            );

        const fila =
            document.querySelector(
                '#tablaRegistros tr[data-index="' +
                index +
                '"]'
            );

        if (fila) {

            fila.classList.add(
                'table-primary'
            );

        }

        document
            .getElementById(
                'detalleVacio'
            )
            .classList.add(
                'd-none'
            );

        document
            .getElementById(
                'detalleSeleccionado'
            )
            .classList.remove(
                'd-none'
            );

        btnGuardar.disabled =
            false;

    }


    /*
    |--------------------------------------------------------------------------
    | CONCEPTO AUTOMÁTICO
    |--------------------------------------------------------------------------
    */

    function obtenerConceptoPorTipo() {

        switch (
            origenTipo.value
        ) {

            case 'CONTADOR':
                return 'Facturación por contador';

            case 'TNG':
                return 'Informe técnico TNG';

            case 'SERVICIO':
                return 'Servicio técnico';

            case 'ALQUILER':
                return 'Alquiler de equipo';

            case 'VENTA':
                return 'Venta';

            default:
                return 'Factura';

        }

    }


    /*
    |--------------------------------------------------------------------------
    | RESUMEN
    |--------------------------------------------------------------------------
    */

    function actualizarResumen() {

        const cantidadValor =
            Number(
                cantidad.value || 0
            );

        const precioValor =
            Number(
                precio.value || 0
            );

        let importeValor =
            Number(
                importe.value || 0
            );

        /*
         * Si el importe no fue ingresado manualmente,
         * calculamos cantidad x precio.
         */

        if (
            importeValor <= 0 &&
            cantidadValor > 0 &&
            precioValor > 0
        ) {

            importeValor =
                cantidadValor *
                precioValor;

            importe.value =
                importeValor.toFixed(2);

        }

        resumenCantidad.textContent =
            number(
                cantidadValor
            );

        resumenPrecio.textContent =
            money(
                precioValor
            );

        resumenImporte.textContent =
            money(
                importeValor
            );

    }


    cantidad.addEventListener(
        'input',
        actualizarResumen
    );

    precio.addEventListener(
        'input',
        function () {

            /*
             * Recalcular importe al modificar
             * cantidad/precio.
             */

            const cantidadValor =
                Number(
                    cantidad.value || 0
                );

            const precioValor =
                Number(
                    precio.value || 0
                );

            if (
                cantidadValor > 0 &&
                precioValor >= 0
            ) {

                importe.value =
                    (
                        cantidadValor *
                        precioValor
                    ).toFixed(2);

            }

            actualizarResumen();

        }
    );

    importe.addEventListener(
        'input',
        actualizarResumen
    );


    /*
    |--------------------------------------------------------------------------
    | GUARDAR
    |--------------------------------------------------------------------------
    */

    form.addEventListener(
        'submit',
        async function (event) {

            event.preventDefault();

            if (
                !registroSeleccionado
            ) {

                mostrarGuardarError(
                    'Debe seleccionar un registro.'
                );

                return;

            }

            if (
                !origenTipo.value
            ) {

                mostrarGuardarError(
                    'Debe seleccionar el origen de facturación.'
                );

                return;

            }

            if (
                !origenId.value ||
                Number(origenId.value) <= 0
            ) {

                mostrarGuardarError(
                    'El registro seleccionado no es válido.'
                );

                return;

            }

            if (
                !cliente.value ||
                Number(cliente.value) <= 0
            ) {

                mostrarGuardarError(
                    'Debe seleccionar un cliente.'
                );

                return;

            }

            const formData =
                new FormData(form);

            btnGuardar.disabled =
                true;

            btnGuardar.innerHTML =
                '<span class="spinner-border spinner-border-sm me-1"></span>' +
                'Preparando...';

            ocultarMensajeGuardar();

            try {

                const response =
                    await request(
                        urls.guardar,
                        {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-Requested-With':
                                    'XMLHttpRequest'
                            }
                        }
                    );

                mostrarGuardarOk(
                    response.message ||
                    'Factura preparada correctamente.'
                );

                /*
                |--------------------------------------------------------------------------
                | Si el backend devuelve datos,
                | mostramos información.
                |--------------------------------------------------------------------------
                */

                if (
                    response.data
                ) {

                    mostrarResultado(
                        response.data
                    );

                }

            } catch (error) {

                mostrarGuardarError(
                    error.message ||
                    'No fue posible preparar la factura.'
                );

                btnGuardar.disabled =
                    false;

            } finally {

                btnGuardar.innerHTML =
                    '<i class="bi bi-check2-circle me-1"></i>' +
                    'Preparar factura';

            }

        }
    );


    /*
    |--------------------------------------------------------------------------
    | RESULTADO
    |--------------------------------------------------------------------------
    */

    function mostrarResultado(
        data
    ) {

        if (
            !data ||
            typeof data !== 'object'
        ) {

            return;

        }

        const id =
            data.id ??
            data.origen_id ??
            '';

        if (
            id !== ''
        ) {

            resumenRegistro.textContent =
                '#' + id;

        }

    }


    /*
    |--------------------------------------------------------------------------
    | LIMPIAR SELECCIÓN
    |--------------------------------------------------------------------------
    */

    function limpiarSeleccion() {

        registroSeleccionado =
            null;

        origenId.value =
            '';

        concepto.value =
            '';

        descripcion.value =
            '';

        cantidad.value =
            '1';

        precio.value =
            '0';

        importe.value =
            '0';

        resumenCliente.textContent =
            cliente.options[
                cliente.selectedIndex
            ]?.text ||
            '—';

        resumenOrigen.textContent =
            nombresOrigen[
                origenTipo.value
            ] ||
            '—';

        resumenRegistro.textContent =
            '—';

        actualizarResumen();

        btnGuardar.disabled =
            true;

        document
            .getElementById(
                'detalleVacio'
            )
            .classList.remove(
                'd-none'
            );

        document
            .getElementById(
                'detalleSeleccionado'
            )
            .classList.add(
                'd-none'
            );

        tabla.innerHTML =
            '';

        badgeCantidad.textContent =
            '0';

        contenedor.classList.add(
            'd-none'
        );

    }


    /*
    |--------------------------------------------------------------------------
    | MENSAJES
    |--------------------------------------------------------------------------
    */

    function mostrarMensaje(
        text
    ) {

        mensaje.innerHTML =
            '<i class="bi bi-info-circle fs-1 d-block mb-3"></i>' +
            '<div>' +
            escapeHtml(text) +
            '</div>';

        mensaje.classList.remove(
            'd-none'
        );

        contenedor.classList.add(
            'd-none'
        );

        badgeCantidad.textContent =
            '0';

    }


    function mostrarLoading(
        visible
    ) {

        if (visible) {

            loading.classList.remove(
                'd-none'
            );

            mensaje.classList.add(
                'd-none'
            );

            contenedor.classList.add(
                'd-none'
            );

        } else {

            loading.classList.add(
                'd-none'
            );

        }

    }


    function mostrarGuardarOk(
        text
    ) {

        mensajeGuardar.className =
            'alert alert-success mt-3';

        mensajeGuardar.innerHTML =
            '<i class="bi bi-check-circle me-1"></i>' +
            escapeHtml(text);

    }


    function mostrarGuardarError(
        text
    ) {

        mensajeGuardar.className =
            'alert alert-danger mt-3';

        mensajeGuardar.innerHTML =
            '<i class="bi bi-exclamation-triangle me-1"></i>' +
            escapeHtml(text);

    }


    function ocultarMensajeGuardar() {

        mensajeGuardar.className =
            'd-none';

        mensajeGuardar.innerHTML =
            '';

    }


    /*
    |--------------------------------------------------------------------------
    | INICIALIZACIÓN
    |--------------------------------------------------------------------------
    */

    const tipoInicial =
        <?= json_encode(
            $tipo,
            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES
        ) ?>;

    if (
        tipoInicial
    ) {

        const button =
            document.querySelector(
                '.tipo-facturacion[data-tipo="' +
                tipoInicial +
                '"]'
            );

        if (button) {

            button.classList.add(
                'active'
            );

        }

        origenTipo.value =
            tipoInicial;

    }

    actualizarResumen();

})();

</script>