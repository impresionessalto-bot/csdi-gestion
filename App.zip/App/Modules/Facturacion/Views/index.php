<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| DATOS
|--------------------------------------------------------------------------
*/

$titulo = $titulo ?? 'Facturación';

$resumen = is_array($resumen ?? null)
    ? $resumen
    : [];

$items = is_array($items ?? null)
    ? $items
    : [];

$clientes = is_array($clientes ?? null)
    ? $clientes
    : [];

$periodos = is_array($periodos ?? null)
    ? $periodos
    : [];

$estados = is_array($estados ?? null)
    ? $estados
    : [];

$origenes = is_array($origenes ?? null)
    ? $origenes
    : [];

$filtros = is_array($filtros ?? null)
    ? $filtros
    : [];

$csrf = (string)($csrf ?? '');


/*
|--------------------------------------------------------------------------
| RESUMEN
|--------------------------------------------------------------------------
*/

$total = (int)(
    $resumen['total'] ?? 0
);

$pendientes = (int)(
    $resumen['pendientes'] ?? 0
);

$facturados = (int)(
    $resumen['facturados'] ?? 0
);

$errores = (int)(
    $resumen['errores'] ?? 0
);

$importeTotal = (float)(
    $resumen['importe_total'] ?? 0
);

$importePendiente = (float)(
    $resumen['importe_pendiente'] ?? 0
);


/*
|--------------------------------------------------------------------------
| FILTROS ACTUALES
|--------------------------------------------------------------------------
*/

$filtroOrigen = strtoupper(
    trim(
        (string)(
            $filtros['origen_tipo'] ?? ''
        )
    )
);

$filtroCliente = (int)(
    $filtros['cliente_id'] ?? 0
);

$filtroMes = (int)(
    $filtros['periodo_mes'] ?? 0
);

$filtroAnio = (int)(
    $filtros['periodo_anio'] ?? 0
);

$filtroEstado = strtolower(
    trim(
        (string)(
            $filtros['estado_facturacion'] ?? ''
        )
    )
);

?>

<div class="container-fluid py-3">

    <!-- ================================================================
         CABECERA
         ================================================================ -->

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 mb-1">
                <?= htmlspecialchars(
                    $titulo,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h1>

            <div class="text-muted">
                Gestión centralizada de conceptos facturables
            </div>

        </div>

        <div class="mt-2 mt-md-0">

            <a
                href="/facturacion"
                class="btn btn-outline-secondary"
            >
                Limpiar filtros
            </a>

        </div>

    </div>


    <!-- ================================================================
         RESUMEN
         ================================================================ -->

    <div class="row g-3 mb-4">

        <!-- TOTAL -->

        <div class="col-12 col-md-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="text-muted small">
                        Total
                    </div>

                    <div class="fs-3 fw-bold">
                        <?= number_format(
                            $total,
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <!-- PENDIENTES -->

        <div class="col-12 col-md-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="text-muted small">
                        Pendientes
                    </div>

                    <div class="fs-3 fw-bold text-warning">
                        <?= number_format(
                            $pendientes,
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <!-- FACTURADOS -->

        <div class="col-12 col-md-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="text-muted small">
                        Facturados
                    </div>

                    <div class="fs-3 fw-bold text-success">
                        <?= number_format(
                            $facturados,
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <!-- IMPORTE PENDIENTE -->

        <div class="col-12 col-md-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <div class="text-muted small">
                        Importe pendiente
                    </div>

                    <div class="fs-3 fw-bold">

                        $
                        <?= number_format(
                            $importePendiente,
                            2,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================
         INFORMACIÓN ADICIONAL
         ================================================================ -->

    <div class="row g-3 mb-4">

        <div class="col-md-4">

            <div class="card shadow-sm">

                <div class="card-body">

                    <div class="text-muted small">
                        Importe total
                    </div>

                    <div class="fs-5 fw-bold">

                        $
                        <?= number_format(
                            $importeTotal,
                            2,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card shadow-sm">

                <div class="card-body">

                    <div class="text-muted small">
                        Errores
                    </div>

                    <div class="fs-5 fw-bold text-danger">
                        <?= number_format(
                            $errores,
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card shadow-sm">

                <div class="card-body">

                    <div class="text-muted small">
                        Registros mostrados
                    </div>

                    <div class="fs-5 fw-bold">
                        <?= number_format(
                            count($items),
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================
         FILTROS
         ================================================================ -->

    <div class="card shadow-sm mb-4">

        <div class="card-header">

            <strong>
                Filtros de facturación
            </strong>

        </div>


        <div class="card-body">

            <form
                method="GET"
                action="/facturacion"
                class="row g-3"
            >

                <!-- ORIGEN -->

                <div class="col-12 col-md-3">

                    <label
                        for="origen_tipo"
                        class="form-label"
                    >
                        Origen
                    </label>

                    <select
                        id="origen_tipo"
                        name="origen_tipo"
                        class="form-select"
                    >

                        <option value="">
                            Todos
                        </option>

                        <?php foreach ($origenes as $origen): ?>

                            <?php
                            $origenValor = strtoupper(
                                trim(
                                    (string)$origen
                                )
                            );
                            ?>

                            <option
                                value="<?= htmlspecialchars(
                                    $origenValor,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                                <?= $filtroOrigen === $origenValor
                                    ? 'selected'
                                    : ''
                                ?>
                            >

                                <?= htmlspecialchars(
                                    $origenValor,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- CLIENTE -->

                <div class="col-12 col-md-4">

                    <label
                        for="cliente_id"
                        class="form-label"
                    >
                        Cliente
                    </label>

                    <select
                        id="cliente_id"
                        name="cliente_id"
                        class="form-select"
                    >

                        <option value="0">
                            Todos
                        </option>

                        <?php foreach ($clientes as $cliente): ?>

                            <?php
                            $clienteId = (int)(
                                $cliente['id'] ?? 0
                            );

                            $clienteNombre = trim(
                                (string)(
                                    $cliente['nombre']
                                    ?? $cliente['nombre_fantasia']
                                    ?? ''
                                )
                            );
                            ?>

                            <option
                                value="<?= $clienteId ?>"
                                <?= $filtroCliente === $clienteId
                                    ? 'selected'
                                    : ''
                                ?>
                            >

                                <?= htmlspecialchars(
                                    $clienteNombre,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- MES -->

                <div class="col-12 col-md-2">

                    <label
                        for="periodo_mes"
                        class="form-label"
                    >
                        Mes
                    </label>

                    <select
                        id="periodo_mes"
                        name="periodo_mes"
                        class="form-select"
                    >

                        <option value="0">
                            Todos
                        </option>

                        <?php for (
                            $mes = 1;
                            $mes <= 12;
                            $mes++
                        ): ?>

                            <option
                                value="<?= $mes ?>"
                                <?= $filtroMes === $mes
                                    ? 'selected'
                                    : ''
                                ?>
                            >

                                <?= str_pad(
                                    (string)$mes,
                                    2,
                                    '0',
                                    STR_PAD_LEFT
                                ) ?>

                            </option>

                        <?php endfor; ?>

                    </select>

                </div>


                <!-- AÑO -->

                <div class="col-12 col-md-2">

                    <label
                        for="periodo_anio"
                        class="form-label"
                    >
                        Año
                    </label>

                    <select
                        id="periodo_anio"
                        name="periodo_anio"
                        class="form-select"
                    >

                        <option value="0">
                            Todos
                        </option>

                        <?php foreach ($periodos as $periodo): ?>

                            <?php
                            $anio = (int)(
                                $periodo['periodo_anio']
                                ?? 0
                            );
                            ?>

                            <?php if ($anio <= 0): ?>

                                <?php continue; ?>

                            <?php endif; ?>

                            <option
                                value="<?= $anio ?>"
                                <?= $filtroAnio === $anio
                                    ? 'selected'
                                    : ''
                                ?>
                            >

                                <?= $anio ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- BOTÓN -->

                <div class="col-12 col-md-1 d-flex align-items-end">

                    <button
                        type="submit"
                        class="btn btn-primary w-100"
                    >
                        Filtrar
                    </button>

                </div>

            </form>

        </div>

    </div>


    <!-- ================================================================
         LISTADO
         ================================================================ -->

    <div class="card shadow-sm">

        <div class="card-header d-flex justify-content-between align-items-center">

            <strong>
                Registros de facturación
            </strong>

            <span class="badge bg-secondary">
                <?= count($items) ?>
            </span>

        </div>


        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover table-striped mb-0">

                    <thead>

                        <tr>

                            <th>
                                ID
                            </th>

                            <th>
                                Origen
                            </th>

                            <th>
                                Cliente
                            </th>

                            <th>
                                Fecha
                            </th>

                            <th>
                                Período
                            </th>

                            <th class="text-end">
                                Importe
                            </th>

                            <th>
                                Estado
                            </th>

                            <th class="text-end">
                                Acción
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php if (empty($items)): ?>

                            <tr>

                                <td
                                    colspan="8"
                                    class="text-center text-muted py-5"
                                >
                                    No hay registros para los filtros seleccionados.
                                </td>

                            </tr>

                        <?php else: ?>

                            <?php foreach ($items as $item): ?>

                                <?php

                                $itemId = (int)(
                                    $item['id'] ?? 0
                                );

                                $origen = strtoupper(
                                    trim(
                                        (string)(
                                            $item['origen_tipo']
                                            ?? ''
                                        )
                                    )
                                );

                                $clienteNombre = (string)(
                                    $item['cliente_nombre']
                                    ?? ''
                                );

                                $clienteId = (int)(
                                    $item['cliente_id']
                                    ?? 0
                                );

                                $fecha = (string)(
                                    $item['fecha']
                                    ?? ''
                                );

                                $mes = (int)(
                                    $item['periodo_mes']
                                    ?? 0
                                );

                                $anio = (int)(
                                    $item['periodo_anio']
                                    ?? 0
                                );

                                $importe = (float)(
                                    $item['importe']
                                    ?? 0
                                );

                                $estado = (string)(
                                    $item['estado']
                                    ?? $item['estado_facturacion']
                                    ?? 'pendiente'
                                );

                                ?>

                                <tr>

                                    <!-- ID -->

                                    <td>
                                        <?= $itemId ?>
                                    </td>


                                    <!-- ORIGEN -->

                                    <td>

                                        <?php

                                        $badgeClass = match ($origen) {

                                            'CONTADOR' =>
                                                'bg-primary',

                                            'TNG' =>
                                                'bg-info text-dark',

                                            'SERVICIO' =>
                                                'bg-warning text-dark',

                                            'VENTA' =>
                                                'bg-success',

                                            default =>
                                                'bg-secondary',

                                        };

                                        ?>

                                        <span
                                            class="badge <?= $badgeClass ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $origen,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- CLIENTE -->

                                    <td>

                                        <?= htmlspecialchars(
                                            $clienteNombre,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    </td>


                                    <!-- FECHA -->

                                    <td>

                                        <?= htmlspecialchars(
                                            $fecha,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    </td>


                                    <!-- PERIODO -->

                                    <td>

                                        <?php if (
                                            $mes > 0
                                            && $anio > 0
                                        ): ?>

                                            <?= str_pad(
                                                (string)$mes,
                                                2,
                                                '0',
                                                STR_PAD_LEFT
                                            ) ?>/<?= $anio ?>

                                        <?php elseif ($anio > 0): ?>

                                            <?= $anio ?>

                                        <?php else: ?>

                                            —

                                        <?php endif; ?>

                                    </td>


                                    <!-- IMPORTE -->

                                    <td class="text-end">

                                        $

                                        <?= number_format(
                                            $importe,
                                            2,
                                            ',',
                                            '.'
                                        ) ?>

                                    </td>


                                    <!-- ESTADO -->

                                    <td>

                                        <?php

                                        $estadoNormalizado = strtolower(
                                            trim($estado)
                                        );

                                        $estadoClass = match (
                                            $estadoNormalizado
                                        ) {

                                            'facturado',
                                            'enviado_dux' =>
                                                'bg-success',

                                            'error' =>
                                                'bg-danger',

                                            'generado' =>
                                                'bg-info text-dark',

                                            'facturable',
                                            'pendiente' =>
                                                'bg-warning text-dark',

                                            default =>
                                                'bg-secondary',

                                        };

                                        ?>

                                        <span
                                            class="badge <?= $estadoClass ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $estado,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- ACCIÓN -->

                                    <td class="text-end">

                                        <?php if (
                                            $itemId > 0
                                            && $origen !== ''
                                        ): ?>

                                            <button
                                                type="button"
                                                class="btn btn-sm btn-primary btn-preparar-factura"
                                                data-origen="<?= htmlspecialchars(
                                                    $origen,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>"
                                                data-id="<?= $itemId ?>"
                                                data-cliente="<?= $clienteId ?>"
                                            >
                                                Preparar
                                            </button>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                —
                                            </span>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>


<!-- ================================================================
     CONFIGURACIÓN JAVASCRIPT
     ================================================================ -->

<script>

window.FacturacionConfig = {

    csrf: <?= json_encode(
        $csrf,
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
    ) ?>,

    disponiblesUrl:
        '/facturacion/disponibles',

    prepararUrl:
        '/facturacion/preparar',

    historialUrl:
        '/facturacion/historial',

    clientesUrl:
        '/facturacion/clientes'

};

</script>