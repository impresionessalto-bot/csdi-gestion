<?php

declare(strict_types=1);

namespace App\Modules\Facturacion;

use App\Core\Module as CoreModule;

final class Module extends CoreModule
{
    /*
    |--------------------------------------------------------------------------
    | IDENTIDAD
    |--------------------------------------------------------------------------
    */

    public function name(): string
    {
        return 'Facturacion';
    }


    /*
    |--------------------------------------------------------------------------
    | RUTAS
    |--------------------------------------------------------------------------
    */

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }


    /*
    |--------------------------------------------------------------------------
    | MENÚ
    |--------------------------------------------------------------------------
    */

    public function icon(): string
    {
        return 'bi-receipt';
    }


    public function url(): string
    {
        return '/facturacion';
    }


    public function group(): string
    {
        return 'Administración';
    }


    public function order(): int
    {
        return 40;
    }


    /*
    |--------------------------------------------------------------------------
    | PERMISOS
    |--------------------------------------------------------------------------
    */

    public function permissions(): array
    {
        return [
            'facturacion.view',
            'facturacion.create',
            'facturacion.edit',
            'facturacion.delete',
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | BOOT
    |--------------------------------------------------------------------------
    */

    public function boot(): void
    {
        /*
         * El módulo no necesita inicialización adicional.
         */
    }
}