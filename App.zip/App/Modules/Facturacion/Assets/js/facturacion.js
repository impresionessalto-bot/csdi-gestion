document.addEventListener('DOMContentLoaded',()=>console.debug('CSDI ERP Facturación listo'));
