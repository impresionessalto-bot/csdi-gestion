<?php

declare(strict_types=1);

namespace App\Modules\Facturacion\Repositories;

use PDO;
use PDOException;
use RuntimeException;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN
    |--------------------------------------------------------------------------
    */

    public function resumen(
        array $filtros = []
    ): array {

        $contador =
            $this->resumenContadores(
                $filtros
            );

        $tng =
            $this->resumenTng(
                $filtros
            );

        $servicios =
            $this->resumenServicios(
                $filtros
            );

        $ventas =
            $this->resumenVentas(
                $filtros
            );

        return [
            'total' =>
                $contador['total']
                + $tng['total']
                + $servicios['total']
                + $ventas['total'],

            'pendientes' =>
                $contador['pendientes']
                + $tng['pendientes']
                + $servicios['pendientes']
                + $ventas['pendientes'],

            'facturados' =>
                $contador['facturados']
                + $tng['facturados']
                + $servicios['facturados']
                + $ventas['facturados'],

            'errores' =>
                $contador['errores'],

            'importe_total' =>
                $contador['importe_total']
                + $tng['importe_total']
                + $servicios['importe_total']
                + $ventas['importe_total'],

            'importe_pendiente' =>
                $contador['importe_pendiente']
                + $tng['importe_pendiente']
                + $servicios['importe_pendiente']
                + $ventas['importe_pendiente'],

            'contador' =>
                $contador,

            'tng' =>
                $tng,

            'servicios' =>
                $servicios,

            'ventas' =>
                $ventas,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO UNIFICADO
    |--------------------------------------------------------------------------
    */

    public function listar(
        array $filtros = []
    ): array {

        $resultado = [];

        foreach (
            $this->listarContadores($filtros)
            as $row
        ) {
            $resultado[] = $row;
        }

        foreach (
            $this->listarTng($filtros)
            as $row
        ) {
            $resultado[] = $row;
        }

        foreach (
            $this->listarServicios($filtros)
            as $row
        ) {
            $resultado[] = $row;
        }

        foreach (
            $this->listarVentas($filtros)
            as $row
        ) {
            $resultado[] = $row;
        }

        usort(
            $resultado,
            static function (
                array $a,
                array $b
            ): int {

                return strcmp(
                    (string) (
                        $b['fecha'] ?? ''
                    ),
                    (string) (
                        $a['fecha'] ?? ''
                    )
                );
            }
        );

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | CONTADORES FACTURABLES
    |--------------------------------------------------------------------------
    */

    public function contadoresFacturables(
        int $clienteId
    ): array {

        if ($clienteId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                f.id,
                'CONTADOR' AS origen_tipo,

                f.cliente_id,
                c.nombre AS cliente_nombre,

                f.equipo_id,

                e.codigo_interno,
                e.serie,

                f.periodo_mes,
                f.periodo_anio,

                f.contador_anterior,
                f.contador_actual,
                f.consumo,

                f.precio_mono,
                f.precio_color,

                f.importe_calculado,

                f.estado,

                f.fecha_generacion

            FROM facturacion_control f

            LEFT JOIN clientes c
                ON c.id = f.cliente_id

            LEFT JOIN equipos e
                ON e.id = f.equipo_id

            WHERE f.cliente_id = :cliente_id

              AND LOWER(
                    COALESCE(f.estado, '')
                  ) NOT IN (
                    'facturado',
                    'enviado_dux'
                  )

            ORDER BY
                f.periodo_anio DESC,
                f.periodo_mes DESC,
                f.id DESC
            ",
            [
                'cliente_id' => $clienteId,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | TNG FACTURABLES
    |--------------------------------------------------------------------------
    */

    public function informesTngFacturables(
        int $clienteId
    ): array {

        if ($clienteId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT

                h.id,
                'TNG' AS origen_tipo,

                h.cliente_id,
                h.cliente AS cliente_nombre,

                h.equipo_id,

                h.nro_informe,

                h.localidad,
                h.fecha,

                h.periodo,
                h.anio,

                h.estado,
                h.estado_facturacion,

                h.fact_contador_arca,
                h.fact_contador_general,
                h.fact_servicio_tecnico,

                h.visita_tng_id,

                h.observaciones

            FROM historial_informes h

            WHERE h.cliente_id = :cliente_id

              AND LOWER(
                    COALESCE(
                        h.estado_facturacion,
                        'pendiente'
                    )
                  ) IN (
                    'pendiente',
                    'facturable'
                  )

              AND h.estado <> 'ANULADO'

            ORDER BY
                h.anio DESC,
                h.periodo DESC,
                h.id DESC
            ",
            [
                'cliente_id' => $clienteId,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICIOS FACTURABLES
    |--------------------------------------------------------------------------
    */

    public function serviciosFacturables(
        int $clienteId
    ): array {

        if ($clienteId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT

                s.id,
                'SERVICIO' AS origen_tipo,

                s.cliente_id,
                c.nombre AS cliente_nombre,

                s.equipo_id,

                s.fecha_solicitud,
                s.fecha_finalizacion,

                s.descripcion_problema,
                s.solucion_aplicada,

                s.estado,
                s.facturable,

                s.monto_facturar,
                s.servicio_total_pagar,

                s.tecnico_asignado_nombre

            FROM servicios s

            LEFT JOIN clientes c
                ON c.id = s.cliente_id

            WHERE s.cliente_id = :cliente_id

              AND s.facturable = 1

              AND (
                    s.dux_factura_id IS NULL
                    OR s.dux_factura_id = ''
                  )

            ORDER BY
                s.fecha_solicitud DESC,
                s.id DESC
            ",
            [
                'cliente_id' => $clienteId,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VENTAS FACTURABLES
    |--------------------------------------------------------------------------
    |
    | La tabla ventas no tiene cliente_id.
    | Por eso no filtramos por cliente.
    |
    */

    public function ventasFacturables(): array
    {
        return $this->fetchAll(
            "
            SELECT

                v.id,
                'VENTA' AS origen_tipo,

                v.cliente_nombre,

                v.fecha,
                v.total_venta

            FROM ventas v

            ORDER BY
                v.fecha DESC,
                v.id DESC
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER ORIGEN
    |--------------------------------------------------------------------------
    */

    public function obtenerOrigenFacturable(
        string $origen,
        int $origenId,
        int $clienteId
    ): ?array {

        return match ($origen) {

            'CONTADOR' =>
                $this->obtenerContador(
                    $origenId,
                    $clienteId
                ),

            'TNG' =>
                $this->obtenerTng(
                    $origenId,
                    $clienteId
                ),

            'SERVICIO' =>
                $this->obtenerServicio(
                    $origenId,
                    $clienteId
                ),

            'VENTA' =>
                $this->obtenerVenta(
                    $origenId
                ),

            default =>
                null,
        };
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL
    |--------------------------------------------------------------------------
    */

    public function historial(
        array $filtros = []
    ): array {

        $resultado = [];

        foreach (
            $this->listarContadores(
                $filtros,
                true
            ) as $row
        ) {
            $resultado[] = $row;
        }

        foreach (
            $this->listarTng(
                $filtros,
                true
            ) as $row
        ) {
            $resultado[] = $row;
        }

        foreach (
            $this->listarServicios(
                $filtros,
                true
            ) as $row
        ) {
            $resultado[] = $row;
        }

        foreach (
            $this->listarVentas(
                $filtros,
                true
            ) as $row
        ) {
            $resultado[] = $row;
        }

        usort(
            $resultado,
            static function (
                array $a,
                array $b
            ): int {

                return strcmp(
                    (string) (
                        $b['fecha'] ?? ''
                    ),
                    (string) (
                        $a['fecha'] ?? ''
                    )
                );
            }
        );

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientes(): array
    {
        return $this->fetchAll(
            "
            SELECT

                id,
                nombre,
                nombre_fantasia,
                categoria_fiscal,
                dux_cliente_id,
                id_dux

            FROM clientes

            WHERE activo = 1

            ORDER BY nombre ASC
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR CLIENTE
    |--------------------------------------------------------------------------
    */

    public function crearCliente(
        array $data
    ): int {

        try {

            $stmt = $this->db->prepare(
                "
                INSERT INTO clientes
                (
                    nombre,
                    email,
                    telefono,
                    activo
                )
                VALUES
                (
                    :nombre,
                    :email,
                    :telefono,
                    1
                )
                "
            );

            $stmt->execute(
                [
                    'nombre' =>
                        $data['nombre'] ?? '',

                    'email' =>
                        $data['email'] ?? '',

                    'telefono' =>
                        $data['telefono'] ?? '',
                ]
            );

            return (int) $this->db->lastInsertId();

        } catch (PDOException $e) {

            throw new RuntimeException(
                'No se pudo crear el cliente.',
                0,
                $e
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADOS
    |--------------------------------------------------------------------------
    */

    public function estados(): array
    {
        return [
            'pendiente',
            'facturable',
            'generado',
            'enviado_dux',
            'facturado',
            'error',
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | PERIODOS
    |--------------------------------------------------------------------------
    */

    public function periodos(): array
    {
        return $this->fetchAll(
            "
            SELECT DISTINCT
                periodo_mes,
                periodo_anio

            FROM facturacion_control

            ORDER BY
                periodo_anio DESC,
                periodo_mes DESC

            LIMIT 60
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CONTADOR - DETALLE
    |--------------------------------------------------------------------------
    */

    private function obtenerContador(
        int $id,
        int $clienteId
    ): ?array {

        $rows = $this->fetchAll(
            "
            SELECT

                f.id,
                'CONTADOR' AS origen_tipo,

                f.cliente_id,
                c.nombre AS cliente_nombre,

                f.equipo_id,

                e.codigo_interno,
                e.serie,

                f.periodo_mes,
                f.periodo_anio,

                f.contador_anterior,
                f.contador_actual,
                f.consumo,

                f.precio_mono,
                f.precio_color,

                f.importe_calculado,

                f.estado

            FROM facturacion_control f

            LEFT JOIN clientes c
                ON c.id = f.cliente_id

            LEFT JOIN equipos e
                ON e.id = f.equipo_id

            WHERE f.id = :id
              AND f.cliente_id = :cliente_id

            LIMIT 1
            ",
            [
                'id' =>
                    $id,

                'cliente_id' =>
                    $clienteId,
            ]
        );

        return $rows[0] ?? null;
    }

    /*
    |--------------------------------------------------------------------------
    | TNG - DETALLE
    |--------------------------------------------------------------------------
    */

    private function obtenerTng(
        int $id,
        int $clienteId
    ): ?array {

        $rows = $this->fetchAll(
            "
            SELECT

                h.id,
                'TNG' AS origen_tipo,

                h.cliente_id,
                h.cliente AS cliente_nombre,

                h.equipo_id,

                h.nro_informe,
                h.localidad,

                h.fecha,

                h.periodo,
                h.anio,

                h.estado,
                h.estado_facturacion,

                h.visita_tng_id

            FROM historial_informes h

            WHERE h.id = :id
              AND h.cliente_id = :cliente_id

              AND h.estado <> 'ANULADO'

            LIMIT 1
            ",
            [
                'id' =>
                    $id,

                'cliente_id' =>
                    $clienteId,
            ]
        );

        return $rows[0] ?? null;
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICIO - DETALLE
    |--------------------------------------------------------------------------
    */

    private function obtenerServicio(
        int $id,
        int $clienteId
    ): ?array {

        $rows = $this->fetchAll(
            "
            SELECT

                s.id,
                'SERVICIO' AS origen_tipo,

                s.cliente_id,
                c.nombre AS cliente_nombre,

                s.equipo_id,

                s.fecha_solicitud,
                s.fecha_finalizacion,

                s.descripcion_problema,
                s.solucion_aplicada,

                s.facturable,
                s.monto_facturar,

                s.estado

            FROM servicios s

            LEFT JOIN clientes c
                ON c.id = s.cliente_id

            WHERE s.id = :id
              AND s.cliente_id = :cliente_id

              AND s.facturable = 1

            LIMIT 1
            ",
            [
                'id' =>
                    $id,

                'cliente_id' =>
                    $clienteId,
            ]
        );

        return $rows[0] ?? null;
    }

    /*
    |--------------------------------------------------------------------------
    | VENTA - DETALLE
    |--------------------------------------------------------------------------
    */

    private function obtenerVenta(
        int $id
    ): ?array {

        $rows = $this->fetchAll(
            "
            SELECT

                v.id,
                'VENTA' AS origen_tipo,

                v.fecha,
                v.cliente_nombre,
                v.total_venta

            FROM ventas v

            WHERE v.id = :id

            LIMIT 1
            ",
            [
                'id' =>
                    $id,
            ]
        );

        return $rows[0] ?? null;
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAR CONTADORES
    |--------------------------------------------------------------------------
    */

    private function listarContadores(
        array $filtros,
        bool $historial = false
    ): array {

        $where = [];
        $params = [];

        $this->filtroContador(
            $where,
            $params,
            $filtros,
            $historial
        );

        $sql = "
            SELECT

                f.id,

                'CONTADOR' AS origen_tipo,

                f.cliente_id,
                c.nombre AS cliente_nombre,

                f.equipo_id,
                e.codigo_interno,
                e.serie,

                f.periodo_mes,
                f.periodo_anio,

                f.consumo,
                f.importe_calculado AS importe,

                f.estado,

                f.fecha_generacion AS fecha,

                f.factura_numero,
                f.dux_id

            FROM facturacion_control f

            LEFT JOIN clientes c
                ON c.id = f.cliente_id

            LEFT JOIN equipos e
                ON e.id = f.equipo_id
        ";

        if ($where) {
            $sql .=
                ' WHERE '
                . implode(
                    ' AND ',
                    $where
                );
        }

        $sql .= "
            ORDER BY
                f.periodo_anio DESC,
                f.periodo_mes DESC,
                f.id DESC
        ";

        return $this->fetchAll(
            $sql,
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAR TNG
    |--------------------------------------------------------------------------
    */

    private function listarTng(
        array $filtros,
        bool $historial = false
    ): array {

        $where = [];
        $params = [];

        if (
            !empty(
                $filtros['cliente_id']
            )
        ) {
            $where[] =
                'h.cliente_id = :tng_cliente_id';

            $params['tng_cliente_id'] =
                (int) $filtros['cliente_id'];
        }

        if (
            !empty(
                $filtros['origen_tipo']
            )
            && $filtros['origen_tipo']
                !== 'TNG'
        ) {
            return [];
        }

        $sql = "
            SELECT

                h.id,

                'TNG' AS origen_tipo,

                h.cliente_id,
                h.cliente AS cliente_nombre,

                h.equipo_id,

                h.nro_informe,

                h.fecha,

                h.periodo,
                h.anio,

                h.estado,

                h.estado_facturacion,

                NULL AS importe

            FROM historial_informes h
        ";

        if (!$historial) {

            $where[] = "
                h.estado_facturacion
                IN (
                    'PENDIENTE',
                    'FACTURABLE'
                )
            ";
        }

        if ($where) {
            $sql .=
                ' WHERE '
                . implode(
                    ' AND ',
                    $where
                );
        }

        $sql .= "
            ORDER BY
                h.anio DESC,
                h.periodo DESC,
                h.id DESC
        ";

        return $this->fetchAll(
            $sql,
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAR SERVICIOS
    |--------------------------------------------------------------------------
    */

    private function listarServicios(
        array $filtros,
        bool $historial = false
    ): array {

        $where = [];
        $params = [];

        if (
            !empty(
                $filtros['cliente_id']
            )
        ) {
            $where[] =
                's.cliente_id = :serv_cliente_id';

            $params['serv_cliente_id'] =
                (int) $filtros['cliente_id'];
        }

        if (
            !empty(
                $filtros['origen_tipo']
            )
            && $filtros['origen_tipo']
                !== 'SERVICIO'
        ) {
            return [];
        }

        $sql = "
            SELECT

                s.id,

                'SERVICIO' AS origen_tipo,

                s.cliente_id,
                c.nombre AS cliente_nombre,

                s.equipo_id,

                s.fecha_solicitud AS fecha,

                s.estado,

                s.facturable,

                s.monto_facturar AS importe,

                s.dux_factura_id

            FROM servicios s

            LEFT JOIN clientes c
                ON c.id = s.cliente_id
        ";

        if (!$historial) {

            $where[] = "
                s.facturable = 1

                AND (
                    s.dux_factura_id IS NULL
                    OR s.dux_factura_id = ''
                )
            ";
        }

        if ($where) {
            $sql .=
                ' WHERE '
                . implode(
                    ' AND ',
                    $where
                );
        }

        $sql .= "
            ORDER BY
                s.fecha_solicitud DESC,
                s.id DESC
        ";

        return $this->fetchAll(
            $sql,
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAR VENTAS
    |--------------------------------------------------------------------------
    */

    private function listarVentas(
        array $filtros,
        bool $historial = false
    ): array {

        if (
            !empty(
                $filtros['origen_tipo']
            )
            && $filtros['origen_tipo']
                !== 'VENTA'
        ) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT

                v.id,

                'VENTA' AS origen_tipo,

                NULL AS cliente_id,

                v.cliente_nombre,

                NULL AS equipo_id,

                v.fecha,

                NULL AS estado,

                v.total_venta AS importe

            FROM ventas v

            ORDER BY
                v.fecha DESC,
                v.id DESC
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | FILTRO CONTADORES
    |--------------------------------------------------------------------------
    */

    private function filtroContador(
        array &$where,
        array &$params,
        array $filtros,
        bool $historial
    ): void {

        if (
            !empty(
                $filtros['origen_tipo']
            )
            && $filtros['origen_tipo']
                !== 'CONTADOR'
        ) {
            $where[] = '1 = 0';

            return;
        }

        if (
            !empty(
                $filtros['cliente_id']
            )
        ) {
            $where[] =
                'f.cliente_id = :contador_cliente_id';

            $params['contador_cliente_id'] =
                (int) $filtros['cliente_id'];
        }

        if (
            !empty(
                $filtros['periodo_mes']
            )
        ) {
            $where[] =
                'f.periodo_mes = :contador_mes';

            $params['contador_mes'] =
                (int) $filtros['periodo_mes'];
        }

        if (
            !empty(
                $filtros['periodo_anio']
            )
        ) {
            $where[] =
                'f.periodo_anio = :contador_anio';

            $params['contador_anio'] =
                (int) $filtros['periodo_anio'];
        }

        if (!$historial) {

            $where[] = "
                LOWER(
                    COALESCE(f.estado, '')
                ) NOT IN (
                    'facturado',
                    'enviado_dux'
                )
            ";
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN CONTADORES
    |--------------------------------------------------------------------------
    */

    private function resumenContadores(
        array $filtros
    ): array {

        $where = [];
        $params = [];

        $this->filtroContador(
            $where,
            $params,
            $filtros,
            true
        );

        return $this->fetchOne(
            "
            SELECT

                COUNT(*) AS total,

                COALESCE(
                    SUM(
                        CASE
                            WHEN LOWER(
                                COALESCE(f.estado, '')
                            ) = 'pendiente'
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS pendientes,

                COALESCE(
                    SUM(
                        CASE
                            WHEN LOWER(
                                COALESCE(f.estado, '')
                            ) = 'facturado'
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS facturados,

                COALESCE(
                    SUM(
                        CASE
                            WHEN LOWER(
                                COALESCE(f.estado, '')
                            ) = 'error'
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS errores,

                COALESCE(
                    SUM(
                        f.importe_calculado
                    ),
                    0
                ) AS importe_total,

                COALESCE(
                    SUM(
                        CASE
                            WHEN LOWER(
                                COALESCE(f.estado, '')
                            ) <> 'facturado'
                            THEN f.importe_calculado
                            ELSE 0
                        END
                    ),
                    0
                ) AS importe_pendiente

            FROM facturacion_control f
            "
            . (
                $where
                    ? ' WHERE '
                        . implode(
                            ' AND ',
                            $where
                        )
                    : ''
            ),
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN TNG
    |--------------------------------------------------------------------------
    */

    private function resumenTng(
        array $filtros
    ): array {

        $where = [
            "h.estado <> 'ANULADO'"
        ];

        $params = [];

        if (
            !empty(
                $filtros['cliente_id']
            )
        ) {
            $where[] =
                'h.cliente_id = :cliente_id';

            $params['cliente_id'] =
                (int) $filtros['cliente_id'];
        }

        return $this->fetchOne(
            "
            SELECT

                COUNT(*) AS total,

                SUM(
                    CASE
                        WHEN h.estado_facturacion
                            IN (
                                'PENDIENTE',
                                'FACTURABLE'
                            )
                        THEN 1
                        ELSE 0
                    END
                ) AS pendientes,

                SUM(
                    CASE
                        WHEN h.estado_facturacion =
                            'FACTURADO'
                        THEN 1
                        ELSE 0
                    END
                ) AS facturados,

                0 AS errores,

                0 AS importe_total,

                0 AS importe_pendiente

            FROM historial_informes h

            WHERE "
            . implode(
                ' AND ',
                $where
            ),
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN SERVICIOS
    |--------------------------------------------------------------------------
    */

    private function resumenServicios(
        array $filtros
    ): array {

        $where = [
            's.facturable = 1'
        ];

        $params = [];

        if (
            !empty(
                $filtros['cliente_id']
            )
        ) {
            $where[] =
                's.cliente_id = :cliente_id';

            $params['cliente_id'] =
                (int) $filtros['cliente_id'];
        }

        return $this->fetchOne(
            "
            SELECT

                COUNT(*) AS total,

                SUM(
                    CASE
                        WHEN (
                            s.dux_factura_id IS NULL
                            OR s.dux_factura_id = ''
                        )
                        THEN 1
                        ELSE 0
                    END
                ) AS pendientes,

                SUM(
                    CASE
                        WHEN s.dux_factura_id IS NOT NULL
                         AND s.dux_factura_id <> ''
                        THEN 1
                        ELSE 0
                    END
                ) AS facturados,

                0 AS errores,

                COALESCE(
                    SUM(
                        s.monto_facturar
                    ),
                    0
                ) AS importe_total,

                COALESCE(
                    SUM(
                        CASE
                            WHEN (
                                s.dux_factura_id IS NULL
                                OR s.dux_factura_id = ''
                            )
                            THEN s.monto_facturar
                            ELSE 0
                        END
                    ),
                    0
                ) AS importe_pendiente

            FROM servicios s

            WHERE "
            . implode(
                ' AND ',
                $where
            ),
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN VENTAS
    |--------------------------------------------------------------------------
    */

    private function resumenVentas(
        array $filtros
    ): array {

        if (
            !empty(
                $filtros['origen_tipo']
            )
            && $filtros['origen_tipo']
                !== 'VENTA'
        ) {
            return [
                'total' => 0,
                'pendientes' => 0,
                'facturados' => 0,
                'errores' => 0,
                'importe_total' => 0,
                'importe_pendiente' => 0,
            ];
        }

        return $this->fetchOne(
            "
            SELECT

                COUNT(*) AS total,

                COUNT(*) AS pendientes,

                0 AS facturados,

                0 AS errores,

                COALESCE(
                    SUM(total_venta),
                    0
                ) AS importe_total,

                COALESCE(
                    SUM(total_venta),
                    0
                ) AS importe_pendiente

            FROM ventas
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PDO
    |--------------------------------------------------------------------------
    */

    private function fetchAll(
        string $sql,
        array $params = []
    ): array {

        try {

            $stmt =
                $this->db->prepare($sql);

            $stmt->execute(
                $params
            );

            return $stmt->fetchAll(
                PDO::FETCH_ASSOC
            ) ?: [];

        } catch (PDOException $e) {

            throw new RuntimeException(
                'Error consultando facturación: '
                . $e->getMessage(),
                0,
                $e
            );
        }
    }

    private function fetchOne(
        string $sql,
        array $params = []
    ): array {

        $rows =
            $this->fetchAll(
                $sql,
                $params
            );

        return $rows[0] ?? [];
    }
}