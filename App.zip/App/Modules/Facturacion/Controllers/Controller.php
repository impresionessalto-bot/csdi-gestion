<?php

declare(strict_types=1);

namespace App\Modules\Facturacion\Controllers;

use App\Core\BaseController;
use App\Modules\Facturacion\Services\Service;
use InvalidArgumentException;
use Throwable;

final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | ASSETS
    |--------------------------------------------------------------------------
    */

    private function loadAssets(): void
    {
        $this->assets()->addModule(
            'Facturacion'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | FILTROS
    |--------------------------------------------------------------------------
    */

    private function obtenerFiltros(): array
    {
        return [
            'origen_tipo' => strtoupper(
                trim(
                    (string) (
                        $_GET['origen_tipo'] ?? ''
                    )
                )
            ),

            'estado_facturacion' => strtolower(
                trim(
                    (string) (
                        $_GET['estado_facturacion'] ?? ''
                    )
                )
            ),

            'cliente_id' => max(
                0,
                (int) (
                    $_GET['cliente_id'] ?? 0
                )
            ),

            'periodo_mes' => max(
                0,
                (int) (
                    $_GET['periodo_mes'] ?? 0
                )
            ),

            'periodo_anio' => max(
                0,
                (int) (
                    $_GET['periodo_anio'] ?? 0
                )
            ),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {

            $this->loadAssets();

            $filtros =
                $this->obtenerFiltros();

            $data =
                $this->service->dashboard(
                    $filtros
                );

            $this->moduleView(
                'Facturacion',
                'index',
                [
                    'titulo' =>
                        $data['titulo']
                        ?? 'Facturación',

                    'resumen' =>
                        $data['resumen']
                        ?? [],

                    'items' =>
                        $data['items']
                        ?? [],

                    'clientes' =>
                        $data['clientes']
                        ?? [],

                    'periodos' =>
                        $data['periodos']
                        ?? [],

                    'estados' =>
                        $data['estados']
                        ?? [],

                    'origenes' =>
                        $data['origenes']
                        ?? [],

                    'filtros' =>
                        $filtros,

                    'csrf' =>
                        $this->csrf(),
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DISPONIBLES
    |--------------------------------------------------------------------------
    */

    public function disponibles(): void
    {
        $this->requireAuth();

        try {

            $clienteId =
                max(
                    0,
                    (int) (
                        $_GET['cliente_id']
                        ?? 0
                    )
                );

            $origen =
                strtoupper(
                    trim(
                        (string) (
                            $_GET['origen_tipo']
                            ?? ''
                        )
                    )
                );

            if ($origen === '') {

                throw new InvalidArgumentException(
                    'Debe seleccionar un origen.'
                );
            }

            $data =
                $this->service->disponibles(
                    $origen,
                    $clienteId
                );

            $this->json(
                [
                    'success' => true,
                    'data' => $data,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                    'data' => [],
                ],
                422
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL
    |--------------------------------------------------------------------------
        */

    public function historial(): void
    {
        $this->requireAuth();

        try {

            $filtros = [
                'cliente_id' =>
                    max(
                        0,
                        (int) (
                            $_GET['cliente_id']
                            ?? 0
                        )
                    ),

                'origen_tipo' =>
                    strtoupper(
                        trim(
                            (string) (
                                $_GET['origen_tipo']
                                ?? ''
                            )
                        )
                    ),

                'periodo_mes' =>
                    max(
                        0,
                        (int) (
                            $_GET['periodo_mes']
                            ?? 0
                        )
                    ),

                'periodo_anio' =>
                    max(
                        0,
                        (int) (
                            $_GET['periodo_anio']
                            ?? 0
                        )
                    ),
            ];

            $this->json(
                [
                    'success' => true,

                    'data' =>
                        $this->service->historial(
                            $filtros
                        ),
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientes(): void
    {
        $this->requireAuth();

        try {

            $this->json(
                [
                    'success' => true,

                    'data' =>
                        $this->service->clientes(),
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PREPARAR
    |--------------------------------------------------------------------------
    */

    public function preparar(): void
    {
        $this->requireAuth();

        try {

            $this->validateCsrf();

            $data = [
                'cliente_id' =>
                    max(
                        0,
                        (int) (
                            $_POST['cliente_id']
                            ?? 0
                        )
                    ),

                'origen_tipo' =>
                    strtoupper(
                        trim(
                            (string) (
                                $_POST['origen_tipo']
                                ?? ''
                            )
                        )
                    ),

                'origen_id' =>
                    max(
                        0,
                        (int) (
                            $_POST['origen_id']
                            ?? 0
                        )
                    ),

                'concepto' =>
                    trim(
                        (string) (
                            $_POST['concepto']
                            ?? ''
                        )
                    ),

                'descripcion' =>
                    trim(
                        (string) (
                            $_POST['descripcion']
                            ?? ''
                        )
                    ),

                'cantidad' =>
                    (float) (
                        $_POST['cantidad']
                        ?? 1
                    ),

                'precio_unitario' =>
                    (float) (
                        $_POST['precio_unitario']
                        ?? 0
                    ),

                'importe' =>
                    (float) (
                        $_POST['importe']
                        ?? 0
                    ),
            ];

            $resultado =
                $this->service->prepararFactura(
                    $data
                );

            $this->json(
                [
                    'success' => true,

                    'message' =>
                        'Concepto preparado correctamente.',

                    'data' =>
                        $resultado,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                    'data' => [],
                ],
                422
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR CLIENTE
    |--------------------------------------------------------------------------
    */

    public function crearCliente(): void
    {
        $this->requireAuth();

        try {

            $this->validateCsrf();

            $cliente =
                $this->service->crearCliente(
                    [
                        'nombre' =>
                            trim(
                                (string) (
                                    $_POST['nombre']
                                    ?? ''
                                )
                            ),

                        'cuit' =>
                            trim(
                                (string) (
                                    $_POST['cuit']
                                    ?? ''
                                )
                            ),

                        'email' =>
                            trim(
                                (string) (
                                    $_POST['email']
                                    ?? ''
                                )
                            ),

                        'telefono' =>
                            trim(
                                (string) (
                                    $_POST['telefono']
                                    ?? ''
                                )
                            ),
                    ]
                );

            $this->json(
                [
                    'success' => true,

                    'message' =>
                        'Cliente creado correctamente.',

                    'data' =>
                        $cliente,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                    'data' => [],
                ],
                422
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }
}