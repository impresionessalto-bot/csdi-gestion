<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Counter\Controllers\Controller;

// Función para registrar las rutas del módulo Counter
$registrarRutasCounter = static function (): void {

    /*
    |--------------------------------------------------------------------------
    | VISTAS PRINCIPALES
    |--------------------------------------------------------------------------
    */

    Router::get('', [Controller::class, 'index']);
    Router::get('/', [Controller::class, 'index']);

    Router::get('/nuevo', [Controller::class, 'nuevo']);
    
    // Edición con ID (Ej: /contadores/editar/5 o /counter/editar/5)
    Router::get('/editar/{id}', [Controller::class, 'editar']);
    Router::get('/ver/{id}', [Controller::class, 'ver']);
    Router::get('/historial/{id}', [Controller::class, 'historial']);

    /*
    |--------------------------------------------------------------------------
    | API / CONSULTAS AJAX (Soporta llamadas con y sin /api/)
    |--------------------------------------------------------------------------
    */

    Router::get('/clientes', [Controller::class, 'clientes']);
    Router::get('/api/clientes', [Controller::class, 'clientes']);

    Router::get('/equipos', [Controller::class, 'equipos']);
    Router::get('/api/equipos', [Controller::class, 'equipos']);

    Router::get('/ultimo-contador', [Controller::class, 'ultimoContador']);
    Router::get('/api/ultimo-contador', [Controller::class, 'ultimoContador']);

    Router::get('/preparar-lectura', [Controller::class, 'prepararLectura']);
    Router::get('/api/preparar-lectura', [Controller::class, 'prepararLectura']);

    Router::get('/registro-periodo', [Controller::class, 'registroPeriodo']);
    Router::get('/api/registro-periodo', [Controller::class, 'registroPeriodo']);

    /*
    |--------------------------------------------------------------------------
    | ESCRITURA Y ELIMINACIÓN (STORE / UPDATE / DELETE)
    |--------------------------------------------------------------------------
    */

    Router::post('/store', [Controller::class, 'store']);
    Router::post('/update/{id}', [Controller::class, 'update']);
    Router::post('/eliminar/{id}', [Controller::class, 'destroy']);

    /*
    |--------------------------------------------------------------------------
    | EXPORTACIONES Y WHATSAPP
    |--------------------------------------------------------------------------
    */

    Router::get('/exportar-pdf', [Controller::class, 'exportarPdf']);
    Router::get('/exportar/pdf', [Controller::class, 'exportarPdf']);

    Router::get('/exportar-excel', [Controller::class, 'exportarExcel']);
    Router::get('/exportar/excel', [Controller::class, 'exportarExcel']);

    Router::post('/recordatorios', [Controller::class, 'enviarRecordatorios']);
    Router::post('/whatsapp/enviar', [Controller::class, 'enviarWhatsApp']);
};

// 1. Grupo en español: /contadores
Router::group('/contadores', ['auth'], $registrarRutasCounter);

// 2. Grupo en inglés: /counter (Coincide con Module.php)
Router::group('/counter', ['auth'], $registrarRutasCounter);