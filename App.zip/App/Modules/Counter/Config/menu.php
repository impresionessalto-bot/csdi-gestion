<?php

declare(strict_types=1);

return [

    'title'      => 'Control de Contadores',

    'url'        => '/contadores',

    'icon'       => 'fa-solid fa-gauge-high',

    'permission' => 'counter.ver',

    'order'      => 20,

    'badge'      => null

];