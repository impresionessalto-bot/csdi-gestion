<?php

declare(strict_types=1);

return [

    /*
    |--------------------------------------------------------------------------
    | Permisos Módulo Contadores
    |--------------------------------------------------------------------------
    */

    'counter.ver' => [
        'nombre' => 'Ver contadores',
        'descripcion' => 'Permite acceder al módulo de control de contadores',
        'grupo' => 'Contadores'
    ],


    'counter.crear' => [
        'nombre' => 'Crear contador',
        'descripcion' => 'Permite cargar nuevas lecturas de contador',
        'grupo' => 'Contadores'
    ],


    'counter.editar' => [
        'nombre' => 'Editar contador',
        'descripcion' => 'Permite modificar lecturas de contador',
        'grupo' => 'Contadores'
    ],


    'counter.eliminar' => [
        'nombre' => 'Eliminar contador',
        'descripcion' => 'Permite eliminar registros de contador',
        'grupo' => 'Contadores'
    ]

];