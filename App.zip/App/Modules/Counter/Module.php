<?php

declare(strict_types=1);

namespace App\Modules\Counter;

use App\Core\Module as CoreModule;

final class Module extends CoreModule
{
    public function name(): string
    {
        return 'Counter';
    }

    public function description(): string
    {
        return 'Consola de odómetros, control de lecturas y consumos mensuales de equipos';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    public function routes(): string
    {
        $rutaConfig = __DIR__ . '/Config/routes.php';
        if (is_file($rutaConfig)) {
            return $rutaConfig;
        }

        return __DIR__ . '/config/routes.php';
    }

    public function priority(): int
    {
        return 20;
    }

    public function menu(): array
    {
        return [
            [
                'title'      => 'Contadores',
                'icon'       => 'fa-solid fa-gauge-high',
                'url'        => '/counter',
                'group'      => 'Operaciones',
                'order'      => 20,
                'permission' => 'counter.ver',
                'visible'    => true,
                'children'   => [
                    [
                        'title'      => 'Nueva Lectura',
                        'url'        => '/counter/nuevo',
                        'permission' => 'counter.crear'
                    ]
                ]
            ]
        ];
    }

    public function icon(): string
    {
        return 'fa-solid fa-gauge-high';
    }

    public function url(): string
    {
        return '/counter';
    }

    public function group(): string
    {
        return 'Operaciones';
    }

    public function order(): int
    {
        return 20;
    }

    public function permissions(): array
    {
        return [
            'counter.ver',
            'counter.crear',
            'counter.editar',
            'counter.eliminar',
            'counter.whatsapp'
        ];
    }

    public function dependencies(): array
    {
        return [
            'Clientes',
            'Equipos'
        ];
    }

    public function widgets(): array
    {
        return [];
    }

    public function kpis(): array
    {
        return [];
    }

    public function enabled(): bool
    {
        return true;
    }

    public function boot(): void
    {
    }
}