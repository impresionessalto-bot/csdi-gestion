<?php

declare(strict_types=1);


if (!function_exists('e')) {

    function e(mixed $v): string
    {
        return htmlspecialchars(
            (string)($v ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }

}



$localidades =
$localidades ?? [];



$csrf =
$_SESSION['csrf'] ?? '';

?>


<div class="container-fluid">


<div class="d-flex justify-content-between align-items-center mb-4">


<div>

<h2 class="fw-bold">

<i class="fa-solid fa-plus text-primary me-2"></i>

Nueva Lectura

</h2>


<p class="text-muted mb-0">

Carga de contador CSDI

</p>

</div>




<a href="/contadores"
class="btn btn-secondary">

<i class="fa-solid fa-arrow-left"></i>

Volver

</a>


</div>






<div class="card shadow-sm">


<div class="card-body">



<form id="formCounter"

method="POST"

action="/contadores/guardar">



<input type="hidden"
name="csrf"
value="<?=e($csrf)?>">






<div class="row g-3">



<div class="col-md-4">


<label class="form-label">

Localidad

</label>


<select

id="localidad_id"

name="localidad_id"

class="form-select">


<option value="">

Seleccione localidad

</option>


<?php foreach($localidades as $l): ?>


<option value="<?=e($l['id'])?>">

<?=e($l['nombre'])?>

</option>


<?php endforeach; ?>


</select>


</div>








<div class="col-md-4">


<label class="form-label">

Cliente

</label>


<select

id="cliente_id"

name="cliente_id"

class="form-select"

disabled>


<option>

Seleccione localidad primero

</option>


</select>


</div>








<div class="col-md-4">


<label class="form-label">

Equipo

</label>


<select

id="equipo_id"

name="equipo_id"

class="form-select"

disabled>


<option>

Seleccione cliente primero

</option>


</select>


</div>



</div>






<hr>







<div class="row g-3">



<div class="col-md-6">


<label class="form-label">

Contador Mono

</label>


<input

type="number"

min="0"

id="contador_actual"

name="contador_actual"

class="form-control"

value="0"

>


</div>







<div class="col-md-6">


<label class="form-label">

Contador Color

</label>


<input

type="number"

min="0"

id="contador_actual_color"

name="contador_actual_color"

class="form-control"

value="0"

>


</div>



</div>






<div class="mt-4">


<button

id="btnGuardar"

type="submit"

class="btn btn-primary">


<i class="fa-solid fa-save me-1"></i>

Guardar lectura


</button>



</div>




</form>


</div>


</div>


</div>





<!-- JS exclusivo Counter -->

<script src="<?=asset('js/modules/counter/create.js')?>?v=2"></script>