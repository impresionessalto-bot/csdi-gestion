<?php

declare(strict_types=1);

namespace App\Modules\Counter\Controllers;

use App\Core\BaseController;
use App\Modules\Counter\Services\Service;
use RuntimeException;
use Throwable;

/**
 * ============================================================================
 * CSDI ERP PRO
 * COUNTER - API CONTROLLER
 * ============================================================================
 *
 * Responsabilidad:
 *
 * - Exponer endpoints AJAX del módulo Contadores.
 * - Validar autenticación.
 * - Delegar toda la lógica al Service.
 * - No ejecutar SQL directamente.
 * - No contener reglas de negocio.
 *
 * Arquitectura:
 *
 * API
 *  ↓
 * Service
 *  ↓
 * Repository
 *  ↓
 * PDO
 *
 * ============================================================================
 */
final class Api extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function listar(): void
    {
        $this->requireAuth();

        try {
            $data =
                $this->service
                    ->listarRegistros();

            $this->success(
                $data ?: [],
                'Listado obtenido correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | LOCALIDADES
    |--------------------------------------------------------------------------
    */

    public function localidades(): void
    {
        $this->requireAuth();

        try {
            $data =
                $this->service
                    ->localidades();

            $this->success(
                $data ?: [],
                'Localidades obtenidas correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES POR LOCALIDAD
    |--------------------------------------------------------------------------
    */

    public function clientes(): void
    {
        $this->requireAuth();

        try {
            $localidadId =
                (int)(
                    $_GET['localidad_id']
                    ?? 0
                );

            if ($localidadId <= 0) {
                throw new RuntimeException(
                    'Localidad inválida.'
                );
            }

            $data =
                $this->service
                    ->clientesPorLocalidad(
                        $localidadId
                    );

            $this->success(
                $data ?: [],
                'Clientes obtenidos correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS POR CLIENTE
    |--------------------------------------------------------------------------
    */

    public function equipos(): void
    {
        $this->requireAuth();

        try {
            $clienteId =
                (int)(
                    $_GET['cliente_id']
                    ?? 0
                );

            if ($clienteId <= 0) {
                throw new RuntimeException(
                    'Cliente inválido.'
                );
            }

            $data =
                $this->service
                    ->equiposPorCliente(
                        $clienteId
                    );

            $this->success(
                $data ?: [],
                'Equipos obtenidos correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ÚLTIMO CONTADOR
    |--------------------------------------------------------------------------
    */

    public function ultimoContador(): void
    {
        $this->requireAuth();

        try {
            $equipoId =
                (int)(
                    $_GET['equipo_id']
                    ?? 0
                );

            if ($equipoId <= 0) {
                throw new RuntimeException(
                    'Equipo inválido.'
                );
            }

            $data =
                $this->service
                    ->obtenerUltimoContador(
                        $equipoId
                    );

            $this->success(
                $data,
                'Último contador obtenido correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PREPARAR LECTURA
    |--------------------------------------------------------------------------
    |
    | Obtiene toda la información necesaria para comenzar una nueva lectura:
    |
    | - equipo
    | - tipo
    | - contador anterior
    | - contador anterior color
    | - período
    | - existencia de lectura en el período
    |
    */

    public function prepararLectura(): void
    {
        $this->requireAuth();

        try {
            $equipoId =
                (int)(
                    $_GET['equipo_id']
                    ?? 0
                );

            $mes =
                (int)(
                    $_GET['periodo_mes']
                    ?? date('m')
                );

            $anio =
                (int)(
                    $_GET['periodo_anio']
                    ?? date('Y')
                );

            if ($equipoId <= 0) {
                throw new RuntimeException(
                    'Equipo inválido.'
                );
            }

            if (
                $mes < 1 ||
                $mes > 12
            ) {
                throw new RuntimeException(
                    'Mes inválido.'
                );
            }

            if (
                $anio < 2000 ||
                $anio > 2100
            ) {
                throw new RuntimeException(
                    'Año inválido.'
                );
            }

            $data =
                $this->service
                    ->prepararNuevaLectura(
                        $equipoId,
                        $mes,
                        $anio
                    );

            $this->success(
                $data,
                'Lectura preparada correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTRO POR PERÍODO
    |--------------------------------------------------------------------------
    */

    public function registroPeriodo(): void
    {
        $this->requireAuth();

        try {
            $equipoId =
                (int)(
                    $_GET['equipo_id']
                    ?? 0
                );

            $mes =
                (int)(
                    $_GET['periodo_mes']
                    ?? date('m')
                );

            $anio =
                (int)(
                    $_GET['periodo_anio']
                    ?? date('Y')
                );

            if ($equipoId <= 0) {
                throw new RuntimeException(
                    'Equipo inválido.'
                );
            }

            $registro =
                $this->service
                    ->obtenerRegistroPorPeriodo(
                        $equipoId,
                        $mes,
                        $anio
                    );

            $this->success(
                [
                    'encontrado' =>
                        $registro !== [],

                    'registro' =>
                        $registro
                ],
                'Consulta de período realizada'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR RÁPIDO
    |--------------------------------------------------------------------------
    */

    public function guardarRapido(): void
    {
        $this->requireAuth();

        try {
            if (
                strtoupper(
                    (string)(
                        $_SERVER['REQUEST_METHOD']
                        ?? ''
                    )
                ) !== 'POST'
            ) {
                throw new RuntimeException(
                    'Método no permitido.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | OBTENER DATOS
            |--------------------------------------------------------------------------
            |
            | Primero intentamos POST tradicional.
            | Si no hay datos, intentamos JSON.
            |
            */

            $data = $_POST;

            if (
                $data === []
                &&
                str_contains(
                    strtolower(
                        (string)(
                            $_SERVER['CONTENT_TYPE']
                            ?? ''
                        )
                    ),
                    'application/json'
                )
            ) {
                $raw =
                    file_get_contents(
                        'php://input'
                    );

                if (
                    is_string($raw)
                    && trim($raw) !== ''
                ) {
                    $json =
                        json_decode(
                            $raw,
                            true
                        );

                    if (
                        is_array($json)
                    ) {
                        $data = $json;
                    }
                }
            }

            if (
                !is_array($data)
                || $data === []
            ) {
                throw new RuntimeException(
                    'No se recibieron datos.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CSRF
            |--------------------------------------------------------------------------
            |
            | El token puede venir:
            |
            | - _csrf
            | - csrf
            |
            */

            $csrf =
                (string)(
                    $data['_csrf']
                    ?? $data['csrf']
                    ?? ''
                );

            if ($csrf === '') {
                throw new RuntimeException(
                    'Token CSRF ausente.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | VALIDACIÓN CSRF
            |--------------------------------------------------------------------------
            */

            if (
                !$this->validateCsrf(
                    $csrf
                )
            ) {
                throw new RuntimeException(
                    'Token CSRF inválido.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | PROCESAMIENTO
            |--------------------------------------------------------------------------
            |
            | Toda la lógica queda centralizada
            | en Service::procesarNuevo().
            |
            */

            $id =
                $this->service
                    ->procesarNuevo(
                        $data
                    );

            if ($id <= 0) {
                throw new RuntimeException(
                    'No fue posible guardar la lectura.'
                );
            }

            $this->success(
                [
                    'id' =>
                        $id,

                    'redirect' =>
                        '/contadores/ver/' . $id
                ],
                'Contador registrado con éxito'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }
}
