<?php

declare(strict_types=1);

namespace App\Modules\Counter\Controllers;

use App\Core\BaseController;
use App\Modules\Counter\Services\Service;
use App\Modules\Clientes\Services\ClienteService;
use App\Modules\Equipos\Services\EquipoService;
use App\Modules\Localidades\Services\LocalidadService;
use App\Services\Swap\SwapService;
use App\Modules\Counter\Services\ContadoresAbonosService;
use Throwable;

/**
 * ============================================================================
 * CSDI PRO
 * MÓDULO CONTADORES
 * Controller
 * ============================================================================
 *
 * Responsabilidad:
 *
 * - recibir requests;
 * - autenticar;
 * - validar CSRF;
 * - obtener parámetros;
 * - delegar al Service correspondiente;
 * - devolver vistas / JSON.
 *
 * El Controller NO:
 *
 * - ejecuta SQL;
 * - calcula copias;
 * - determina Mono/Color;
 * - modifica equipos directamente;
 * - ejecuta lógica de negocio de Swap.
 */
final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service,
        private readonly LocalidadService $localidadService,
        private readonly ClienteService $clienteService,
        private readonly EquipoService $equipoService,
        private readonly SwapService $swapService,
        private readonly ContadoresAbonosService $contadoresAbonosService,
    ) {
        parent::__construct();
    }

    /**
     * =========================================================================
     * ASSETS
     * =========================================================================
     */
    private function loadAssets(): void
    {
        $this->assets()->addModule('Counter');
    }

    /**
     * =========================================================================
     * INDEX
     * =========================================================================
     */
    public function index(): void
    {
        $this->requireAuth();

        $this->loadAssets();

        $datos = $this->service->getIndexData();

        $mesActual = (int)date('m');
        $anioActual = (int)date('Y');

        $pendientes = [];

        try {
            $pendientes =
                $this->contadoresAbonosService
                    ->auditarLecturasPendientesMes(
                        $mesActual,
                        $anioActual
                    );
        } catch (Throwable) {
            /*
             * La auditoría no debe impedir que cargue Contadores.
             */
            $pendientes = [];
        }

        $datos['pendientes_abonos'] = $pendientes;

        $this->view(
            'counter/index',
            $datos
        );
    }

    /**
     * =========================================================================
     * NUEVO
     * =========================================================================
     */
    public function nuevo(): void
    {
        $this->requireAuth();

        $this->loadAssets();

        $datos = $this->service->getCreateData();

        $this->view(
            'counter/create',
            $datos
        );
    }

    /**
     * =========================================================================
     * CLIENTES POR LOCALIDAD
     * =========================================================================
     */
    public function clientes(): void
    {
        $this->requireAuth();

        $localidadId = (int)(
            $_GET['localidad_id']
            ?? $_POST['localidad_id']
            ?? 0
        );

        if ($localidadId <= 0) {
            $this->json([
                'ok' => false,
                'message' => 'Localidad inválida.',
                'data' => [],
            ], 422);

            return;
        }

        try {
            $clientes =
                $this->service->clientesPorLocalidad(
                    $localidadId
                );

            $this->json([
                'ok' => true,
                'data' => $clientes,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
                'data' => [],
            ], 500);
        }
    }

    /**
     * =========================================================================
     * EQUIPOS POR CLIENTE
     * =========================================================================
     *
     * Endpoint AJAX:
     *
     * GET /contadores/equipos?cliente_id=123
     */
    public function equipos(): void
    {
        $this->requireAuth();

        $clienteId = (int)(
            $_GET['cliente_id']
            ?? $_POST['cliente_id']
            ?? 0
        );

        if ($clienteId <= 0) {
            $this->json([
                'ok' => false,
                'message' => 'Cliente inválido.',
                'data' => [],
            ], 422);

            return;
        }

        try {
            $equipos =
                $this->service->equiposPorCliente(
                    $clienteId
                );

            $this->json([
                'ok' => true,
                'data' => $equipos,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
                'data' => [],
            ], 500);
        }
    }

    /**
     * =========================================================================
     * EQUIPO INDIVIDUAL
     * =========================================================================
     *
     * Endpoint AJAX utilizado por la pantalla de Swap.
     *
     * GET /contadores/equipo/{id}
     */
    public function equipo(int $id): void
    {
        $this->requireAuth();

        if ($id <= 0) {
            $this->json([
                'ok' => false,
                'message' => 'Equipo inválido.',
            ], 422);

            return;
        }

        try {

            $equipo =
                $this->service->obtenerEquipo(
                    $id
                );

            if (!$equipo) {
                $this->json([
                    'ok' => false,
                    'message' => 'Equipo no encontrado.',
                ], 404);

                return;
            }

            /*
             * Obtenemos la última lectura física del equipo.
             */
            $ultimoContador =
                $this->service->obtenerUltimoContador(
                    $id
                );

            /*
             * El Service es quien determina Mono/Color.
             */
            $tipo =
                $this->service->obtenerTipoEquipo(
                    $id
                );

            /*
             * Enriquecemos la respuesta sin modificar la lógica
             * de negocio.
             */
            $equipo['tipo_equipo'] = $tipo;
            $equipo['ultimo_contador'] = $ultimoContador;

            $this->json([
                'ok' => true,
                'data' => $equipo,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * =========================================================================
     * ÚLTIMO CONTADOR
     * =========================================================================
     *
     * GET /contadores/ultimo-contador?equipo_id=123
     */
    public function ultimoContador(): void
    {
        $this->requireAuth();

        $equipoId = (int)(
            $_GET['equipo_id']
            ?? $_POST['equipo_id']
            ?? 0
        );

        if ($equipoId <= 0) {
            $this->json([
                'ok' => false,
                'message' => 'Equipo inválido.',
            ], 422);

            return;
        }

        try {

            $contador =
                $this->service->obtenerUltimoContador(
                    $equipoId
                );

            $this->json([
                'ok' => true,
                'data' => $contador,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * =========================================================================
     * GUARDAR LECTURA
     * =========================================================================
     */
    public function store(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json([
                'ok' => false,
                'message' => 'Método no permitido.',
            ], 405);

            return;
        }

        try {

            $this->validateCsrfRequest();

            $resultado =
                $this->service->procesarNuevo(
                    $_POST
                );

            $this->json([
                'ok' => true,
                'message' =>
                    'Lectura de contador registrada correctamente.',
                'data' => $resultado,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * =========================================================================
     * VER
     * =========================================================================
     */
    public function ver(int $id): void
    {
        $this->requireAuth();

        $this->loadAssets();

        if ($id <= 0) {
            $this->notFound();

            return;
        }

        try {

            $datos =
                $this->service->obtenerFicha360(
                    $id
                );

            if (!$datos) {
                $this->notFound();

                return;
            }

            $this->view(
                'counter/ver',
                $datos
            );

        } catch (Throwable $e) {

            $this->serverError(
                $e->getMessage()
            );
        }
    }

    /**
     * =========================================================================
     * EDITAR
     * =========================================================================
     */
    public function editar(int $id): void
    {
        $this->requireAuth();

        $this->loadAssets();

        if ($id <= 0) {
            $this->notFound();

            return;
        }

        try {

            $registro =
                $this->service->obtenerRegistro(
                    $id
                );

            if (!$registro) {
                $this->notFound();

                return;
            }

            $this->view(
                'counter/editar',
                [
                    'registro' => $registro,
                ]
            );

        } catch (Throwable $e) {

            $this->serverError(
                $e->getMessage()
            );
        }
    }

    /**
     * =========================================================================
     * HISTORIAL
     * =========================================================================
     *
     * Historial físico + continuidad transversal mediante Swap.
     */
    public function historial(int $equipoId): void
    {
        $this->requireAuth();

        if ($equipoId <= 0) {
            $this->json([
                'ok' => false,
                'message' => 'Equipo inválido.',
            ], 422);

            return;
        }

        try {

            $historial =
                $this->service->historialEquipo(
                    $equipoId
                );

            $this->json([
                'ok' => true,
                'data' => $historial,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * =========================================================================
     * VISTA SWAP
     * =========================================================================
     *
     * GET /contadores/swap
     *
     * IMPORTANTE:
     * No ejecuta el Swap.
     * Solamente prepara la pantalla.
     */
    public function swapForm(): void
    {
        $this->requireAuth();

        $this->loadAssets();

        try {

            /*
             * Equipos disponibles para entrar en un Swap.
             *
             * El Repository/Service ya aplica las reglas de disponibilidad.
             */
            $equiposDisponibles =
                $this->service->equiposDisponiblesSwap();

            /*
             * Localidades para la instalación.
             */
            $datos = $this->service->getCreateData();

            $localidades =
                $datos['localidades']
                ?? [];

            $this->view(
                'counter/swap/index',
                [
                    'equiposDisponibles' =>
                        $equiposDisponibles,

                    'localidades' =>
                        $localidades,

                    'csrf' =>
                        $_SESSION['csrf_token']
                        ?? '',
                ]
            );

        } catch (Throwable $e) {

            $this->serverError(
                $e->getMessage()
            );
        }
    }

    /**
     * =========================================================================
     * SWAP
     * =========================================================================
     *
     * POST /contadores/swap
     *
     * Toda la lógica de negocio queda en SwapService.
     */
    public function swap(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json([
                'ok' => false,
                'message' => 'Método no permitido.',
            ], 405);

            return;
        }

        try {

            $this->validateCsrfRequest();

            /*
             * --------------------------------------------------------------
             * EQUIPOS
             * --------------------------------------------------------------
             */

            $salienteId = (int)(
                $_POST['equipo_saliente_id']
                ?? $_POST['saliente_id']
                ?? 0
            );

            $entranteId = (int)(
                $_POST['equipo_entrante_id']
                ?? $_POST['entrante_id']
                ?? 0
            );

            if ($salienteId <= 0) {
                throw new \RuntimeException(
                    'Debe indicar el equipo saliente.'
                );
            }

            if ($entranteId <= 0) {
                throw new \RuntimeException(
                    'Debe indicar el equipo entrante.'
                );
            }

            if ($salienteId === $entranteId) {
                throw new \RuntimeException(
                    'El equipo saliente y el entrante no pueden ser el mismo.'
                );
            }

            /*
             * --------------------------------------------------------------
             * CLIENTE / LOCALIDAD
             * --------------------------------------------------------------
             *
             * El cliente NO debería ser una fuente de verdad del Swap:
             * SwapService lo obtiene del equipo saliente.
             *
             * Lo aceptamos únicamente para compatibilidad con el formulario
             * actual, pero no se lo imponemos al Service.
             */

            $clienteId = (int)(
                $_POST['cliente_id']
                ?? 0
            );

            $localidadId = (int)(
                $_POST['localidad_id']
                ?? 0
            );

            if ($localidadId <= 0) {
                throw new \RuntimeException(
                    'Debe indicar la localidad.'
                );
            }

            /*
             * --------------------------------------------------------------
             * MOTIVO
             * --------------------------------------------------------------
             */

            $motivo = trim(
                (string)(
                    $_POST['motivo']
                    ?? ''
                )
            );

            if ($motivo === '') {
                throw new \RuntimeException(
                    'Debe indicar el motivo del Swap.'
                );
            }

            /*
             * --------------------------------------------------------------
             * USUARIO
             * --------------------------------------------------------------
             */

            $usuarioId =
                $this->obtenerUsuarioId();

            /*
             * --------------------------------------------------------------
             * LECTURAS
             * --------------------------------------------------------------
             *
             * IMPORTANTE:
             *
             * El Service determina Mono/Color.
             * El Controller solamente transporta los valores.
             */

            $lecturas = [

                'cliente_id' =>
                    $clienteId,

                'localidad_id' =>
                    $localidadId,

                'fecha' =>
                    trim(
                        (string)(
                            $_POST['fecha']
                            ?? date('Y-m-d')
                        )
                    ),

                /*
                 * ----------------------------------------------------------
                 * EQUIPO SALIENTE
                 * ----------------------------------------------------------
                 */

                'saliente_anterior' =>
                    $this->intPost(
                        'saliente_anterior'
                    ),

                'saliente_actual' =>
                    $this->intPost(
                        'saliente_actual'
                    ),

                'saliente_anterior_color' =>
                    $this->intPost(
                        'saliente_anterior_color'
                    ),

                'saliente_actual_color' =>
                    $this->intPost(
                        'saliente_actual_color'
                    ),

                /*
                 * ----------------------------------------------------------
                 * EQUIPO ENTRANTE
                 * ----------------------------------------------------------
                 *
                 * ESTE ES EL NOMBRE QUE ESPERA SwapService:
                 *
                 * entrante_inicial
                 * entrante_inicial_color
                 * ----------------------------------------------------------
                 */

                'entrante_inicial' =>
                    $this->intPost(
                        'entrante_inicial'
                    ),

                'entrante_inicial_color' =>
                    $this->intPost(
                        'entrante_inicial_color'
                    ),
            ];

            /*
             * --------------------------------------------------------------
             * EJECUTAR SWAP
             * --------------------------------------------------------------
             */

            $resultado =
                $this->swapService->ejecutar(
                    $salienteId,
                    $entranteId,
                    $motivo,
                    $lecturas,
                    $usuarioId
                );

            /*
             * --------------------------------------------------------------
             * RESPUESTA
             * --------------------------------------------------------------
             */

            $this->json([
                'ok' => true,

                'message' =>
                    'Swap realizado correctamente.',

                'data' =>
                    $resultado,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * =========================================================================
     * RESULTADO DEL SWAP
     * =========================================================================
     *
     * GET /contadores/swap/resultado/{id}
     */
    public function swapResultado(int $id): void
    {
        $this->requireAuth();

        $this->loadAssets();

        if ($id <= 0) {
            $this->notFound();

            return;
        }

        try {

            /*
             * Obtenemos la información directamente mediante la ficha
             * relacionada con el historial de cambio.
             *
             * Si posteriormente tenemos un método específico en Service,
             * se puede reemplazar esta parte.
             */
            $historial =
                $this->service->obtenerHistorialSwap(
                    $id
                );

            if (!$historial) {
                $this->notFound();

                return;
            }

            $this->view(
                'counter/swap/resultado',
                [
                    'resultado' =>
                        $historial,
                ]
            );

        } catch (Throwable $e) {

            $this->serverError(
                $e->getMessage()
            );
        }
    }

    /**
     * =========================================================================
     * ENVIAR RECORDATORIOS
     * =========================================================================
     */
    public function enviarRecordatorios(): void
    {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json([
                'ok' => false,
                'message' => 'Método no permitido.',
            ], 405);

            return;
        }

        try {

            $this->validateCsrfRequest();

            $resultado =
                $this->service->enviarRecordatorios(
                    $_POST
                );

            $this->json([
                'ok' => true,
                'data' => $resultado,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * =========================================================================
     * EXPORTAR PDF
     * =========================================================================
     */
    public function exportarPdf(int $id): void
    {
        $this->requireAuth();

        if ($id <= 0) {
            $this->notFound();

            return;
        }

        try {

            $datos =
                $this->service->obtenerFicha360(
                    $id
                );

            if (!$datos) {
                $this->notFound();

                return;
            }

            /*
             * Dejamos la delegación al PdfService para la implementación
             * definitiva.
             */
            $this->json([
                'ok' => true,
                'data' => $datos,
            ]);

        } catch (Throwable $e) {

            $this->json([
                'ok' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * =========================================================================
     * USUARIO AUTENTICADO
     * =========================================================================
     */
    private function obtenerUsuarioId(): int
    {
        $usuario = $_SESSION['user'] ?? null;

        if (is_array($usuario)) {

            $id = (int)(
                $usuario['id']
                ?? $usuario['usuario_id']
                ?? 0
            );

            if ($id > 0) {
                return $id;
            }
        }

        $id = (int)(
            $_SESSION['usuario_id']
            ?? 0
        );

        if ($id > 0) {
            return $id;
        }

        throw new \RuntimeException(
            'No se pudo identificar al usuario autenticado.'
        );
    }

    /**
     * =========================================================================
     * ENTERO POST
     * =========================================================================
     */
    private function intPost(string $key): int
    {
        $value = $_POST[$key] ?? 0;

        if ($value === '' || $value === null) {
            return 0;
        }

        if (
            filter_var(
                $value,
                FILTER_VALIDATE_INT
            ) === false
        ) {
            throw new \RuntimeException(
                "El valor {$key} no es válido."
            );
        }

        $value = (int)$value;

        if ($value < 0) {
            throw new \RuntimeException(
                "El valor {$key} no puede ser negativo."
            );
        }

        return $value;
    }

    /**
     * =========================================================================
     * CSRF
     * =========================================================================
     */
    private function validateCsrfRequest(): void
    {
        $token =
            (string)(
                $_POST['_token']
                ?? $_POST['_csrf']
                ?? $_POST['csrf_token']
                ?? ''
            );

        if ($token === '') {
            throw new \RuntimeException(
                'Token CSRF no informado.'
            );
        }

        if (!$this->verifyCsrf($token)) {
            throw new \RuntimeException(
                'Token CSRF inválido.'
            );
        }
    }
}