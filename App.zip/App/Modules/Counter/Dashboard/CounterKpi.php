<?php

declare(strict_types=1);

namespace App\Modules\Counter\Dashboard;


use App\Modules\Counter\Repositories\Repository;


final class CounterKpi
{


    public function __construct(
        private readonly Repository $repository
    )
    {

    }




    public function pendientes():array
    {


        return [

            'nombre'=>
                'contadores_pendientes',


            'titulo'=>
                'Contadores Pendientes',


            'valor'=>
                function(){

                    return $this
                        ->repository
                        ->pendientes();

                },


            'icono'=>
                'fa-solid fa-clock',


            'color'=>
                'warning',


            'ruta'=>
                '/contadores'

        ];


    }


}