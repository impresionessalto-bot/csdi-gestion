<?php

declare(strict_types=1);

namespace App\Modules\Counter\Widgets;


use App\Widgets\Widget;
use App\Modules\Counter\Services\Service;


final class CounterStatsWidget extends Widget
{


    public function __construct(
        private readonly Service $service
    )
    {

    }



    public function name():string
    {
        return 'counter_stats';
    }




    public function data():array
    {

        $stats =
            $this->service->estadisticas();


        return [

            'titulo'=>'Contadores',

            'icono'=>'fa-solid fa-gauge-high',

            'tipo'=>'card',


            'valor'=>
                $stats['total'] ?? 0,


            'color'=>'primary'

        ];

    }



}