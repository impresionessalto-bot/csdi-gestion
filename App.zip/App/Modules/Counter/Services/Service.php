<?php

declare(strict_types=1);

namespace App\Modules\Counter\Services;

use App\Modules\Counter\Repositories\Repository;
use RuntimeException;
use Throwable;

final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function listarRegistros(): array
    {
        return $this->repository->listarRegistros();
    }

    public function getIndexData(): array
    {
        $items = $this->listarRegistros();

        $equipos = [];
        $consumo = 0;

        foreach ($items as $row) {
            $equipoId = (int) (
                $row['equipo_id'] ?? 0
            );

            if ($equipoId > 0) {
                $equipos[$equipoId] = true;
            }

            $consumo += max(
                0,
                (int) ($row['copias'] ?? 0)
            );

            $consumo += max(
                0,
                (int) ($row['copias_color'] ?? 0)
            );
        }

        return [
            'titulo' => 'Contadores CSDI',

            'items' => $items,

            'kpis' => [
                'equipos' => count($equipos),
                'lecturas' => count($items),
                'pendientes' => 0,
                'consumo' => $consumo,
            ],
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function getCreateData(): array
    {
        return [
            'fecha' => date('Y-m-d'),
            'periodo_mes' => (int) date('m'),
            'periodo_anio' => (int) date('Y'),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTRO
    |--------------------------------------------------------------------------
    */

    public function obtenerRegistro(int $id): array
    {
        if ($id <= 0) {
            return [];
        }

        return $this->repository
            ->obtenerRegistro($id);
    }

    /*
    |--------------------------------------------------------------------------
    | FICHA 360
    |--------------------------------------------------------------------------
    |
    | La ficha parte del registro solicitado.
    |
    | Después incorpora:
    |
    | - equipo físico;
    | - modelo;
    | - tipo Mono/Color;
    | - historial de contadores;
    | - historial de Swap.
    |
    */

    public function obtenerFicha360(int $id): array
    {
        if ($id <= 0) {
            throw new RuntimeException(
                'Registro de contador inválido.'
            );
        }

        $ficha = $this->repository
            ->obtenerFicha360($id);

        if ($ficha === []) {
            throw new RuntimeException(
                'No se encontró el registro de contador solicitado.'
            );
        }

        $equipoId = (int) (
            $ficha['equipo_id'] ?? 0
        );

        /*
         * El Repository deberá devolver la información principal.
         *
         * Agregamos el tipo normalizado desde el equipo/modelo.
         */
        $tipo = $this->obtenerTipoEquipo(
            $equipoId
        );

        $ficha['tipo'] = $tipo;
        $ficha['es_monocromatico'] =
            $tipo === 'Mono';

        /*
         * Historial transversal.
         *
         * No se mezclan contadores.
         * Solamente se establece la relación:
         *
         * equipo viejo -> Swap -> equipo nuevo
         */
        if ($equipoId > 0) {
            $ficha['historial_swap'] =
                $this->obtenerHistorialSwap(
                    $equipoId
                );
        } else {
            $ficha['historial_swap'] = [];
        }

        return $ficha;
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL DE EQUIPO
    |--------------------------------------------------------------------------
    */

    public function historialEquipo(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        $equipo =
            $this->obtenerEquipo($equipoId);

        $tipo =
            $this->obtenerTipoEquipo($equipoId);

        /*
         * Registros físicos del equipo.
         */
        $registros =
            $this->repository
                ->historialEquipo($equipoId);

        /*
         * Swaps relacionados.
         */
        $swaps =
            $this->obtenerHistorialSwap(
                $equipoId
            );

        /*
         * Para Mono, nunca devolvemos un contador color
         * aunque existan datos incorrectos históricos.
         */
        if ($tipo === 'Mono') {
            foreach ($registros as &$registro) {
                $registro['contador_anterior_color'] = 0;
                $registro['contador_actual_color'] = 0;
                $registro['copias_color'] = 0;
            }

            unset($registro);
        }

        return [
            'equipo' => $equipo,

            'tipo' => $tipo,

            'es_monocromatico' =>
                $tipo === 'Mono',

            'registros' => $registros,

            'swaps' => $swaps,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL TRANSVERSAL DE SWAP
    |--------------------------------------------------------------------------
    |
    | Importante:
    |
    | Esta información NO reemplaza los registros.
    |
    | registros = historia física del contador.
    |
    | historial_cambios = relación entre equipos.
    |
    */

    public function obtenerHistorialSwap(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        return $this->repository
            ->obtenerHistorialSwap($equipoId);
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientesPorLocalidad(
        int $localidadId
    ): array {
        if ($localidadId <= 0) {
            return [];
        }

        return $this->repository
            ->obtenerClientesPorLocalidad(
                $localidadId
            );
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS
    |--------------------------------------------------------------------------
    */

    public function equiposPorCliente(
        int $clienteId
    ): array {
        if ($clienteId <= 0) {
            return [];
        }

        return $this->repository
            ->obtenerEquiposPorCliente(
                $clienteId
            );
    }

    public function obtenerEquipo(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            throw new RuntimeException(
                'ID de equipo inválido.'
            );
        }

        $equipo =
            $this->repository
                ->obtenerEquipo($equipoId);

        if ($equipo === []) {
            throw new RuntimeException(
                'El equipo solicitado no existe.'
            );
        }

        return $equipo;
    }

    /*
    |--------------------------------------------------------------------------
    | TIPO DE EQUIPO
    |--------------------------------------------------------------------------
    |
    | FUENTE ÚNICA DE VERDAD:
    |
    | equipos.modelo_id
    |       ↓
    | modelos_equipos.id
    |       ↓
    | modelos_equipos.tipo
    |
    | No se detecta por nombre.
    | No se detecta por "COLOR".
    | No se recibe del formulario.
    |
    */

    public function obtenerTipoEquipo(
        int $equipoId
    ): string {
        if ($equipoId <= 0) {
            throw new RuntimeException(
                'ID de equipo inválido.'
            );
        }

        $equipo =
            $this->obtenerEquipo($equipoId);

        $tipo = trim(
            (string) (
                $equipo['tipo']
                ?? ''
            )
        );

        if ($tipo === 'Mono') {
            return 'Mono';
        }

        if ($tipo === 'Color') {
            return 'Color';
        }

        throw new RuntimeException(
            'El equipo #' .
            $equipoId .
            ' no tiene un tipo válido en modelos_equipos.'
        );
    }

    public function esEquipoMonocromatico(
        array $equipo
    ): bool {
        $tipo = trim(
            (string) (
                $equipo['tipo']
                ?? ''
            )
        );

        if ($tipo === 'Mono') {
            return true;
        }

        if ($tipo === 'Color') {
            return false;
        }

        throw new RuntimeException(
            'El equipo no tiene un tipo válido en modelos_equipos.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ÚLTIMO CONTADOR
    |--------------------------------------------------------------------------
    */

    public function obtenerUltimoContador(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            throw new RuntimeException(
                'ID de equipo inválido.'
            );
        }

        $equipo =
            $this->obtenerEquipo($equipoId);

        $tipo =
            $this->obtenerTipoEquipo(
                $equipoId
            );

        $esMonocromatico =
            $tipo === 'Mono';

        $ultimo =
            $this->repository
                ->obtenerUltimoContador(
                    $equipoId
                );

        $fechaAnterior = 'Sin registros';

        if (!empty($ultimo['fecha'])) {
            $timestamp =
                strtotime(
                    (string) $ultimo['fecha']
                );

            if ($timestamp !== false) {
                $fechaAnterior =
                    date(
                        'd/m/Y',
                        $timestamp
                    );
            }
        }

        /*
         * El contador físico pertenece a ESTE equipo.
         *
         * Nunca buscamos el último contador del equipo anterior
         * a través de historial_cambios para usarlo como contador
         * inicial del nuevo.
         */
        $mono = (int) (
            $ultimo['contador_actual']
            ?? 0
        );

        $color = $esMonocromatico
            ? 0
            : (int) (
                $ultimo[
                    'contador_actual_color'
                ] ?? 0
            );

        return [
            'encontrado' =>
                $ultimo !== [],

            'registro_id' =>
                (int) (
                    $ultimo['id'] ?? 0
                ),

            'equipo_id' =>
                $equipoId,

            'tipo' =>
                $tipo,

            'es_monocromatico' =>
                $esMonocromatico,

            'mono' =>
                $mono,

            'color' =>
                $color,

            'contador_anterior' =>
                $mono,

            'contador_anterior_color' =>
                $color,

            'fecha_anterior' =>
                $fechaAnterior,

            'periodo_mes' =>
                (int) (
                    $ultimo['periodo_mes'] ?? 0
                ),

            'periodo_anio' =>
                (int) (
                    $ultimo['periodo_anio'] ?? 0
                ),

            'registro' =>
                $ultimo,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTRO POR PERÍODO
    |--------------------------------------------------------------------------
    */

    public function obtenerRegistroPorPeriodo(
        int $equipoId,
        int $mes,
        int $anio
    ): array {
        if ($equipoId <= 0) {
            throw new RuntimeException(
                'ID de equipo inválido.'
            );
        }

        $this->validarPeriodo(
            $mes,
            $anio
        );

        return $this->repository
            ->obtenerRegistroPorPeriodo(
                $equipoId,
                $mes,
                $anio
            );
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTRO ANTERIOR
    |--------------------------------------------------------------------------
    */

    public function obtenerRegistroAnterior(
        int $equipoId,
        int $mes,
        int $anio
    ): array {
        if ($equipoId <= 0) {
            throw new RuntimeException(
                'ID de equipo inválido.'
            );
        }

        $this->validarPeriodo(
            $mes,
            $anio
        );

        /*
         * IMPORTANTE:
         *
         * Este método trabaja con el equipo físico indicado.
         *
         * Si hubo Swap:
         *
         * Equipo A -> historial_cambios -> Equipo B
         *
         * el primer registro de B será su APERTURA.
         *
         * No utilizamos el último contador de A como contador
         * físico de B.
         */
        return $this->repository
            ->obtenerRegistroAnterior(
                $equipoId,
                $mes,
                $anio
            );
    }

    /*
    |--------------------------------------------------------------------------
    | PREPARAR NUEVA LECTURA
    |--------------------------------------------------------------------------
    */

    public function prepararNuevaLectura(
        int $equipoId,
        int $mes,
        int $anio
    ): array {
        if ($equipoId <= 0) {
            throw new RuntimeException(
                'Debe seleccionar un equipo válido.'
            );
        }

        $this->validarPeriodo(
            $mes,
            $anio
        );

        $equipo =
            $this->obtenerEquipo(
                $equipoId
            );

        $tipo =
            $this->obtenerTipoEquipo(
                $equipoId
            );

        $esMonocromatico =
            $tipo === 'Mono';

        /*
         * ================================================================
         * 1. VERIFICAR DUPLICADO DEL PERÍODO
         * ================================================================
         */
        $registroPeriodo =
            $this->repository
                ->obtenerRegistroPorPeriodo(
                    $equipoId,
                    $mes,
                    $anio
                );

        if ($registroPeriodo !== []) {
            return [
                'disponible' => false,

                'ya_registrado' => true,

                'equipo' => $equipo,

                'tipo' => $tipo,

                'es_monocromatico' =>
                    $esMonocromatico,

                'registro' =>
                    $registroPeriodo,

                'contador_anterior' =>
                    (int) (
                        $registroPeriodo[
                            'contador_anterior'
                        ] ?? 0
                    ),

                'contador_anterior_color' =>
                    $esMonocromatico
                        ? 0
                        : (int) (
                            $registroPeriodo[
                                'contador_anterior_color'
                            ] ?? 0
                        ),

                'mensaje' =>
                    'El equipo ya posee una lectura registrada para el período seleccionado.',
            ];
        }

        /*
         * ================================================================
         * 2. BUSCAR ANTERIOR DEL MISMO EQUIPO
         * ================================================================
         */
        $anterior =
            $this->repository
                ->obtenerRegistroAnterior(
                    $equipoId,
                    $mes,
                    $anio
                );

        $contadorAnterior =
            (int) (
                $anterior[
                    'contador_actual'
                ] ?? 0
            );

        $contadorAnteriorColor =
            $esMonocromatico
                ? 0
                : (int) (
                    $anterior[
                        'contador_actual_color'
                    ] ?? 0
                );

        $fechaAnterior =
            'Sin tomas previas';

        if (!empty($anterior['fecha'])) {
            $ts = strtotime(
                (string) $anterior['fecha']
            );

            if ($ts !== false) {
                $fechaAnterior =
                    date(
                        'd/m/Y',
                        $ts
                    );
            }
        }

        /*
         * ================================================================
         * 3. INFORMACIÓN DE SWAP
         * ================================================================
         *
         * Esto permite que la UI sepa si el equipo forma parte de una
         * cadena de reemplazos.
         */
        $historialSwap =
            $this->obtenerHistorialSwap(
                $equipoId
            );

        return [
            'disponible' => true,

            'ya_registrado' => false,

            'equipo' => $equipo,

            'tipo' => $tipo,

            'es_monocromatico' =>
                $esMonocromatico,

            'registro' =>
                $anterior,

            'contador_anterior' =>
                $contadorAnterior,

            'contador_anterior_color' =>
                $contadorAnteriorColor,

            'fecha_anterior' =>
                $fechaAnterior,

            'historial_swap' =>
                $historialSwap,

            'mensaje' =>
                $anterior !== []
                    ? 'Lectura anterior obtenida con éxito.'
                    : 'No existe una lectura anterior para este equipo. El contador se iniciará desde cero.',
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDAR LECTURA
    |--------------------------------------------------------------------------
    */

    public function validarLectura(
        array $post,
        bool $esEdicion = false
    ): array {
        $equipoId =
            (int) (
                $post['equipo_id'] ?? 0
            );

        if ($equipoId <= 0) {
            throw new RuntimeException(
                'Debe seleccionar un equipo válido.'
            );
        }

        $equipo =
            $this->obtenerEquipo(
                $equipoId
            );

        /*
         * ================================================================
         * TIPO REAL
         * ================================================================
         */
        $tipo =
            $this->obtenerTipoEquipo(
                $equipoId
            );

        $esMonocromatico =
            $tipo === 'Mono';

        /*
         * ================================================================
         * CLIENTE
         * ================================================================
         *
         * Para una lectura normal utilizamos el cliente actualmente
         * asociado al equipo.
         */
        $clienteEquipo =
            (int) (
                $equipo['cliente_id'] ?? 0
            );

        if ($clienteEquipo <= 0) {
            throw new RuntimeException(
                'El equipo seleccionado no posee un cliente asociado.'
            );
        }

        /*
         * Si viene cliente_id desde el formulario, no permitimos que
         * pueda cargar una lectura histórica para otro cliente.
         */
        $clientePost =
            (int) (
                $post['cliente_id'] ?? 0
            );

        if (
            $clientePost > 0 &&
            $clientePost !== $clienteEquipo
        ) {
            throw new RuntimeException(
                'El equipo seleccionado no pertenece al cliente indicado.'
            );
        }

        $clienteId =
            $clienteEquipo;

        /*
         * ================================================================
         * PERÍODO
         * ================================================================
         */
        $mes =
            (int) (
                $post['periodo_mes']
                ?? date('m')
            );

        $anio =
            (int) (
                $post['periodo_anio']
                ?? date('Y')
            );

        $this->validarPeriodo(
            $mes,
            $anio
        );

        /*
         * ================================================================
         * CONTADORES ACTUALES
         * ================================================================
         */
        $actualMono =
            (int) (
                $post['contador_actual']
                ?? 0
            );

        if ($actualMono < 0) {
            throw new RuntimeException(
                'El contador Mono actual no puede ser negativo.'
            );
        }

        /*
         * Para Mono, color SIEMPRE es cero.
         */
        $actualColor =
            $esMonocromatico
                ? 0
                : (int) (
                    $post[
                        'contador_actual_color'
                    ] ?? 0
                );

        if ($actualColor < 0) {
            throw new RuntimeException(
                'El contador Color actual no puede ser negativo.'
            );
        }

        /*
         * ================================================================
         * DUPLICADO
         * ================================================================
         */
        $existente =
            $this->repository
                ->obtenerRegistroPorPeriodo(
                    $equipoId,
                    $mes,
                    $anio
                );

        if ($existente !== []) {

            /*
             * En edición, el registro que estamos editando puede ser
             * precisamente el encontrado.
             */
            $registroExistenteId =
                (int) (
                    $existente['id'] ?? 0
                );

            $registroEditadoId =
                (int) (
                    $post['id'] ?? 0
                );

            if (
                !$esEdicion ||
                $registroExistenteId !== $registroEditadoId
            ) {
                throw new RuntimeException(
                    'El equipo ya posee una lectura cargada en el período '
                    . sprintf(
                        '%02d/%04d',
                        $mes,
                        $anio
                    )
                    . '.'
                );
            }
        }

        /*
         * ================================================================
         * REGISTRO ANTERIOR
         * ================================================================
         */
        $anterior =
            $this->repository
                ->obtenerRegistroAnterior(
                    $equipoId,
                    $mes,
                    $anio
                );

        $anteriorMono =
            (int) (
                $anterior[
                    'contador_actual'
                ] ?? 0
            );

        $anteriorColor =
            $esMonocromatico
                ? 0
                : (int) (
                    $anterior[
                        'contador_actual_color'
                    ] ?? 0
                );

        /*
         * ================================================================
         * VALIDAR CONTINUIDAD FÍSICA
         * ================================================================
         */
        if ($actualMono < $anteriorMono) {
            throw new RuntimeException(
                'El contador Mono actual (' .
                $actualMono .
                ') no puede ser inferior al contador anterior (' .
                $anteriorMono .
                ').'
            );
        }

        if (
            !$esMonocromatico &&
            $actualColor < $anteriorColor
        ) {
            throw new RuntimeException(
                'El contador Color actual (' .
                $actualColor .
                ') no puede ser inferior al contador anterior (' .
                $anteriorColor .
                ').'
            );
        }

        /*
         * ================================================================
         * COPIAS
         * ================================================================
         */
        $copias =
            $actualMono -
            $anteriorMono;

        $copiasColor =
            $esMonocromatico
                ? 0
                : $actualColor -
                  $anteriorColor;

        return [
            'equipo' =>
                $equipo,

            'tipo' =>
                $tipo,

            'cliente_id' =>
                $clienteId,

            'equipo_id' =>
                $equipoId,

            'periodo_mes' =>
                $mes,

            'periodo_anio' =>
                $anio,

            'es_monocromatico' =>
                $esMonocromatico,

            'contador_anterior' =>
                $anteriorMono,

            'contador_actual' =>
                $actualMono,

            'contador_anterior_color' =>
                $anteriorColor,

            'contador_actual_color' =>
                $actualColor,

            'copias' =>
                $copias,

            'copias_color' =>
                $copiasColor,

            'registro_anterior' =>
                $anterior,

            'historial_swap' =>
                $this->obtenerHistorialSwap(
                    $equipoId
                ),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | PROCESAR NUEVA LECTURA
    |--------------------------------------------------------------------------
    */

    public function procesarNuevo(
        array $post
    ): int {
        $validado =
            $this->validarLectura(
                $post,
                false
            );

        $fecha =
            trim(
                (string) (
                    $post['fecha'] ?? ''
                )
            );

        if ($fecha === '') {
            $fecha = date(
                'Y-m-d H:i:s'
            );
        }

        $data = [
            'cliente_id' =>
                (int) $validado[
                    'cliente_id'
                ],

            'equipo_id' =>
                (int) $validado[
                    'equipo_id'
                ],

            'periodo_mes' =>
                (int) $validado[
                    'periodo_mes'
                ],

            'periodo_anio' =>
                (int) $validado[
                    'periodo_anio'
                ],

            'fecha' =>
                $fecha,

            'contador_anterior' =>
                (int) $validado[
                    'contador_anterior'
                ],

            'contador_actual' =>
                (int) $validado[
                    'contador_actual'
                ],

            'contador_anterior_color' =>
                (int) $validado[
                    'contador_anterior_color'
                ],

            'contador_actual_color' =>
                (int) $validado[
                    'contador_actual_color'
                ],

            'copias' =>
                (int) $validado[
                    'copias'
                ],

            'copias_color' =>
                (int) $validado[
                    'copias_color'
                ],

            'observaciones' =>
                trim(
                    (string) (
                        $post[
                            'observaciones'
                        ] ?? ''
                    )
                ),
        ];

        $id =
            $this->repository
                ->crearRegistro($data);

        if ($id <= 0) {
            throw new RuntimeException(
                'No fue posible registrar la lectura en la base de datos.'
            );
        }

        return $id;
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function procesarActualizacion(
        int $id,
        array $post
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'ID de lectura no válido.'
            );
        }

        $registroExistente =
            $this->obtenerRegistro($id);

        if ($registroExistente === []) {
            throw new RuntimeException(
                'No se encontró el registro que se intenta actualizar.'
            );
        }

        /*
         * En una edición utilizamos el equipo indicado en el registro
         * si el formulario no manda equipo_id.
         */
        if (
            empty($post['equipo_id']) &&
            !empty($registroExistente['equipo_id'])
        ) {
            $post['equipo_id'] =
                (int) $registroExistente[
                    'equipo_id'
                ];
        }

        /*
         * Permitimos que el registro actual sea el existente del período.
         */
        $post['id'] = $id;

        $validado =
            $this->validarLectura(
                $post,
                true
            );

        $fecha =
            trim(
                (string) (
                    $post['fecha']
                    ?? $registroExistente[
                        'fecha'
                    ]
                    ?? date('Y-m-d H:i:s')
                )
            );

        $data = [
            'cliente_id' =>
                (int) $validado[
                    'cliente_id'
                ],

            'equipo_id' =>
                (int) $validado[
                    'equipo_id'
                ],

            'periodo_mes' =>
                (int) $validado[
                    'periodo_mes'
                ],

            'periodo_anio' =>
                (int) $validado[
                    'periodo_anio'
                ],

            'fecha' =>
                $fecha,

            'contador_anterior' =>
                (int) $validado[
                    'contador_anterior'
                ],

            'contador_actual' =>
                (int) $validado[
                    'contador_actual'
                ],

            'contador_anterior_color' =>
                (int) $validado[
                    'contador_anterior_color'
                ],

            'contador_actual_color' =>
                (int) $validado[
                    'contador_actual_color'
                ],

            'copias' =>
                (int) $validado[
                    'copias'
                ],

            'copias_color' =>
                (int) $validado[
                    'copias_color'
                ],

            'observaciones' =>
                trim(
                    (string) (
                        $post[
                            'observaciones'
                        ] ?? ''
                    )
                ),
        ];

        return $this->repository
            ->actualizarRegistro(
                $id,
                $data
            );
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminarRegistro(
        int $id
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'ID de lectura no válido.'
            );
        }

        $registro =
            $this->obtenerRegistro($id);

        if ($registro === []) {
            throw new RuntimeException(
                'El registro a eliminar no existe.'
            );
        }

        return $this->repository
            ->eliminarRegistro($id);
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR
    |--------------------------------------------------------------------------
    */

    public function obtenerDatosExportar(
        array $filtros
    ): array {
        return $this->repository
            ->obtenerDatosExportar(
                $filtros
            );
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS
    |--------------------------------------------------------------------------
    */

    private function validarPeriodo(
        int $mes,
        int $anio
    ): void {
        if ($mes < 1 || $mes > 12) {
            throw new RuntimeException(
                'Mes inválido.'
            );
        }

        if ($anio < 2000) {
            throw new RuntimeException(
                'Año inválido.'
            );
        }
    }
}