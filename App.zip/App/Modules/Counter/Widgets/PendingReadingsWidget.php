<?php

declare(strict_types=1);

namespace App\Modules\Counter\Widgets;


use App\Widgets\Widget;


final class PendingReadingsWidget extends Widget
{


    public function name(): string
    {
        return 'counter_pending_readings';
    }





    public function data(): array
    {

        return [

            'titulo'=>
                'Lecturas Pendientes',


            'icono'=>
                'fa-solid fa-clock',



            'tipo'=>
                'alert',



            'valor'=>
                $this->get(
                    'valor',
                    0
                ),



            'color'=>
                'warning',



            'ruta'=>
                '/contadores?estado=pendiente'


        ];

    }



}