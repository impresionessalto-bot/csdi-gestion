<?php

declare(strict_types=1);

namespace App\Modules\Counter\Widgets;


use App\Widgets\Widget;


final class ConsumptionChartWidget extends Widget
{


    public function name(): string
    {
        return 'counter_consumption_chart';
    }





    public function data(): array
    {


        return [

            'titulo'=>
                'Consumo mensual',



            'icono'=>
                'fa-solid fa-chart-line',



            'tipo'=>
                'chart',



            'chart'=>
            [

                'tipo'=>
                    'line',


                'labels'=>
                    $this->get(
                        'labels',
                        []
                    ),



                'datasets'=>
                    [

                        [

                            'label'=>
                                'Copias B/N',


                            'data'=>
                                $this->get(
                                    'mono',
                                    []
                                )

                        ],



                        [

                            'label'=>
                                'Copias Color',


                            'data'=>
                                $this->get(
                                    'color',
                                    []
                                )

                        ]

                    ]

            ]


        ];


    }



}