<?php

declare(strict_types=1);

namespace App\Modules\Counter\Widgets;


use App\Widgets\Widget;


final class CounterKpiWidget extends Widget
{


    public function name(): string
    {
        return 'counter_kpi';
    }





    public function data(): array
    {

        return [

            'titulo'=>'Lecturas Contadores',

            'icono'=>'fa-solid fa-gauge-high',

            'tipo'=>'kpi',

            'valor'=>
                $this->get(
                    'valor',
                    0
                ),


            'color'=>'primary',


            'ruta'=>'/contadores'


        ];

    }



}