<?php

declare(strict_types=1);

namespace App\Modules\Counter\Widgets;


use App\Widgets\Widget;


final class BillingStatusWidget extends Widget
{


    public function name(): string
    {
        return 'counter_billing_status';
    }





    public function data(): array
    {


        return [

            'titulo'=>
                'Facturación',



            'icono'=>
                'fa-solid fa-file-invoice-dollar',



            'tipo'=>
                'status',



            'contenido'=>[


                'pendiente'=>
                    $this->get(
                        'pendiente',
                        0
                    ),



                'facturado'=>
                    $this->get(
                        'facturado',
                        0
                    ),



                'pagado'=>
                    $this->get(
                        'pagado',
                        0
                    ),



                'anulado'=>
                    $this->get(
                        'anulado',
                        0
                    )


            ],



            'ruta'=>
                '/contadores/facturacion'


        ];


    }



}