<?php

declare(strict_types=1);

namespace App\Modules\Counter\Widgets;


use App\Widgets\Widget;
use App\Modules\Counter\Services\Service;
use Throwable;



final class CounterWidget extends Widget
{


    public function __construct(
        private readonly Service $service,
        array $data = []
    )
    {

        parent::__construct($data);

    }








    /**
     * Nombre único
     */
    public function name(): string
    {
        return 'counter_widget';
    }










    /**
     * Datos del widget
     */
    public function data(): array
    {


        try {


            $pendientes =
                $this->service->pendientes();



        }
        catch(Throwable)
        {

            $pendientes = 0;

        }






        return [


            'nombre'=>
                $this->name(),



            'titulo'=>
                'Contadores Pendientes',



            'valor'=>
                $pendientes,



            'icono'=>
                'fa-solid fa-gauge-high',



            'color'=>
                'warning',



            'tipo'=>
                'card',



            'ruta'=>
                '/contadores'


        ];


    }









    /**
     * Render HTML
     */
    public function render():string
    {


        $data =
            $this->data();




        return '

<div class="card shadow-sm border-0 h-100">


<div class="card-body">


<div class="d-flex align-items-center">


<div class="rounded-circle 
            bg-'.$this->e($data['color']).'
            text-white
            p-3
            me-3">


<i class="
'.$this->e($data['icono']).'
fa-lg">
</i>


</div>



<div>


<h6 class="text-muted mb-1">
'.$this->e($data['titulo']).'
</h6>



<h3 class="fw-bold mb-0">
'.number_format(
    (int)$data['valor'],
    0,
    ',',
    '.'
).'
</h3>



</div>



</div>


</div>


</div>';

    }



}