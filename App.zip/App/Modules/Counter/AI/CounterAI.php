<?php
declare(strict_types=1);

namespace App\Modules\Counter\AI;

use App\Core\BaseAI;


final class CounterAI extends BaseAI
{

    protected string $model =
        'Counter-Predictor';



    protected function process(): array
    {

        $copias =
            array_column(
                $this->data,
                'copias'
            );


        $promedio =
            $this->average($copias);



        $ultimo =
            end($copias);



        return [

            'promedio_mensual' =>
                $promedio,


            'proximo_estimado' =>
                round($promedio),


            'alerta' =>
                $this->anomaly(
                    $ultimo,
                    $promedio
                )

        ];

    }

}