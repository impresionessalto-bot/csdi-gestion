<?php

declare(strict_types=1);

namespace App\Modules\Counter\Repositories;

use PDO;
use RuntimeException;
use Throwable;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | Helpers
    |--------------------------------------------------------------------------
    */

    private function fetchAll(
        string $sql,
        array $params = []
    ): array {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return is_array($result)
                ? $result
                : [];
        } catch (Throwable) {
            return [];
        }
    }

    private function fetchOne(
        string $sql,
        array $params = []
    ): array {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            return is_array($row)
                ? $row
                : [];
        } catch (Throwable) {
            return [];
        }
    }

    private function execute(
        string $sql,
        array $params = []
    ): bool {
        try {
            $stmt = $this->db->prepare($sql);

            return $stmt->execute($params);
        } catch (Throwable $e) {
            throw new RuntimeException(
                'Error de base de datos: ' . $e->getMessage(),
                0,
                $e
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTROS
    |--------------------------------------------------------------------------
    */

    public function listarRegistros(): array
    {
        return $this->fetchAll(
            "
            SELECT
                r.*,

                c.nombre AS cliente_nombre,
                c.nombre AS cliente_razon_social,

                e.id AS equipo_id_real,
                e.codigo_interno,
                e.serie,
                e.estado AS estado_equipo,
                e.propiedad,
                e.cliente_id AS equipo_cliente_id,
                e.localidad_id AS equipo_localidad_id,

                m.id AS modelo_id_real,
                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo AS tipo_equipo,

                COALESCE(
                    l.nombre,
                    lc.nombre,
                    ''
                ) AS localidad_nombre

            FROM registros r

            LEFT JOIN clientes c
                ON c.id = r.cliente_id

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            LEFT JOIN localidades l
                ON l.id = r.localidad_id

            LEFT JOIN localidades lc
                ON lc.id = c.localidad_id

            ORDER BY
                r.periodo_anio DESC,
                r.periodo_mes DESC,
                r.fecha DESC,
                r.id DESC
            "
        );
    }

    public function obtenerRegistro(
        int $id
    ): array {
        if ($id <= 0) {
            return [];
        }

        return $this->fetchOne(
            "
            SELECT
                r.*,

                c.nombre AS cliente_nombre,
                c.nombre AS cliente_razon_social,
                '' AS cliente_cuit,
                '' AS cliente_telefono,
                '' AS cliente_email,
                '' AS cliente_domicilio,
                c.localidad_id AS cliente_localidad_id,
                '' AS cliente_condicion_fiscal,
                '' AS cliente_observaciones,

                e.id AS equipo_id_real,
                e.codigo_interno,
                e.cliente_id AS equipo_cliente_id,
                e.modelo_id,
                e.serie,
                e.identificador_externo,
                e.activo AS equipo_activo,
                e.propiedad,
                e.estado AS estado_equipo,
                e.observaciones AS equipo_observaciones,
                e.localidad_id AS equipo_localidad_id,

                m.id AS modelo_id_real,
                m.nombre_modelo AS modelo,
                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo AS tipo_equipo,

                COALESCE(
                    l.nombre,
                    lc.nombre,
                    ''
                ) AS localidad_nombre

            FROM registros r

            LEFT JOIN clientes c
                ON c.id = r.cliente_id

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            LEFT JOIN localidades l
                ON l.id = r.localidad_id

            LEFT JOIN localidades lc
                ON lc.id = c.localidad_id

            WHERE r.id = ?

            LIMIT 1
            ",
            [$id]
        );
    }

    public function obtenerClienteCompleto(
        int $clienteId
    ): array {
        if ($clienteId <= 0) {
            return [];
        }

        return $this->fetchOne(
            "
            SELECT
                c.*,
                l.nombre AS localidad_nombre

            FROM clientes c

            LEFT JOIN localidades l
                ON l.id = c.localidad_id

            WHERE c.id = ?

            LIMIT 1
            ",
            [$clienteId]
        );
    }

    public function obtenerClientesPorLocalidad(
        int $localidadId
    ): array {
        if ($localidadId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                id,
                nombre,
                nombre AS razon_social,
                localidad_id

            FROM clientes

            WHERE localidad_id = ?
              AND activo = 1

            ORDER BY
                nombre ASC
            ",
            [$localidadId]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS
    |--------------------------------------------------------------------------
    */

    public function obtenerEquiposPorCliente(
        int $clienteId
    ): array {
        if ($clienteId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                e.id,
                e.codigo_interno,
                e.serie,
                e.estado,
                e.propiedad,
                e.cliente_id,
                e.localidad_id,
                e.modelo_id,
                e.activo,
                e.identificador_externo,

                m.nombre_modelo AS modelo,
                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo AS tipo

            FROM equipos e

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE e.cliente_id = ?
              AND e.activo = 1
              AND e.deleted_at IS NULL

            ORDER BY
                e.id DESC
            ",
            [$clienteId]
        );
    }

    public function obtenerEquipo(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        return $this->fetchOne(
            "
            SELECT
                e.*,

                m.nombre_modelo AS modelo,
                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo AS tipo_equipo

            FROM equipos e

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE e.id = ?

            LIMIT 1
            ",
            [$equipoId]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CONTADORES
    |--------------------------------------------------------------------------
    */

    public function obtenerUltimoContador(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        return $this->fetchOne(
            "
            SELECT
                r.*,

                m.tipo AS tipo_equipo

            FROM registros r

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE r.equipo_id = ?

            ORDER BY
                r.periodo_anio DESC,
                r.periodo_mes DESC,
                r.fecha DESC,
                r.id DESC

            LIMIT 1
            ",
            [$equipoId]
        );
    }

    public function obtenerRegistroPorPeriodo(
        int $equipoId,
        int $mes,
        int $anio
    ): array {
        if (
            $equipoId <= 0 ||
            $mes < 1 ||
            $mes > 12 ||
            $anio < 2000
        ) {
            return [];
        }

        return $this->fetchOne(
            "
            SELECT
                r.*,

                m.tipo AS tipo_equipo

            FROM registros r

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE r.equipo_id = ?
              AND r.periodo_mes = ?
              AND r.periodo_anio = ?

            ORDER BY
                r.id DESC

            LIMIT 1
            ",
            [
                $equipoId,
                $mes,
                $anio
            ]
        );
    }

    /**
     * Obtiene el último registro anterior al período indicado.
     *
     * Importante:
     * - No toma registros futuros.
     * - No toma otro registro del mismo período.
     * - Mantiene la continuidad física del mismo equipo.
     * - El historial anterior a un Swap no se mezcla numéricamente.
     */
    public function obtenerRegistroAnterior(
        int $equipoId,
        int $mes,
        int $anio
    ): array {
        if (
            $equipoId <= 0 ||
            $mes < 1 ||
            $mes > 12 ||
            $anio < 2000
        ) {
            return [];
        }

        $periodo = ($anio * 100) + $mes;

        return $this->fetchOne(
            "
            SELECT
                r.*,

                m.tipo AS tipo_equipo

            FROM registros r

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE r.equipo_id = ?
              AND (
                    (r.periodo_anio * 100)
                    + r.periodo_mes
                  ) < ?

            ORDER BY
                r.periodo_anio DESC,
                r.periodo_mes DESC,
                r.fecha DESC,
                r.id DESC

            LIMIT 1
            ",
            [
                $equipoId,
                $periodo
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL FÍSICO DEL EQUIPO
    |--------------------------------------------------------------------------
    */

    public function historialEquipo(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                r.*,

                c.nombre AS cliente_nombre,

                e.codigo_interno,
                e.serie,
                e.estado AS estado_equipo,

                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo AS tipo_equipo

            FROM registros r

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN clientes c
                ON c.id = r.cliente_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE r.equipo_id = ?

            ORDER BY
                r.periodo_anio DESC,
                r.periodo_mes DESC,
                r.fecha DESC,
                r.id DESC
            ",
            [$equipoId]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL TRANSVERSAL DE SWAP
    |--------------------------------------------------------------------------
    |
    | Esta es la continuidad entre equipos físicos.
    |
    | NO se crea una tabla "swaps".
    | Se utiliza historial_cambios.
    |
    */

    public function obtenerHistorialSwap(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                hc.id,

                hc.equipo_antiguo_id,
                hc.equipo_nuevo_id,

                hc.cliente_id,
                hc.localidad_id,

                hc.fecha_cambio,
                hc.motivo,
                hc.usuario_id,

                ea.codigo_interno AS codigo_interno_antiguo,
                ea.serie AS serie_antigua,

                ma.nombre_modelo AS modelo_antiguo,
                ma.marca AS marca_antigua,
                ma.tipo AS tipo_antiguo,

                en.codigo_interno AS codigo_interno_nuevo,
                en.serie AS serie_nueva,

                mn.nombre_modelo AS modelo_nuevo,
                mn.marca AS marca_nueva,
                mn.tipo AS tipo_nuevo,

                c.nombre AS cliente_nombre,
                l.nombre AS localidad_nombre

            FROM historial_cambios hc

            LEFT JOIN equipos ea
                ON ea.id = hc.equipo_antiguo_id

            LEFT JOIN modelos_equipos ma
                ON ma.id = ea.modelo_id

            LEFT JOIN equipos en
                ON en.id = hc.equipo_nuevo_id

            LEFT JOIN modelos_equipos mn
                ON mn.id = en.modelo_id

            LEFT JOIN clientes c
                ON c.id = hc.cliente_id

            LEFT JOIN localidades l
                ON l.id = hc.localidad_id

            WHERE
                hc.equipo_antiguo_id = ?
                OR hc.equipo_nuevo_id = ?

            ORDER BY
                hc.fecha_cambio DESC,
                hc.id DESC
            ",
            [
                $equipoId,
                $equipoId
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CONTRATOS
    |--------------------------------------------------------------------------
    */

    public function obtenerContratoActivo(
        int $equipoId
    ): array {
        /*
         * La tabla equipos_contrato no está disponible
         * en la BD actual.
         *
         * No se consulta para evitar romper Counter.
         *
         * Cuando tengamos el DESC real de la tabla,
         * este método puede implementarse correctamente.
         */

        return [];
    }

    /*
    |--------------------------------------------------------------------------
    | TARIFAS
    |--------------------------------------------------------------------------
    */

    public function obtenerTarifas(): array
    {
        return $this->fetchAll(
            "
            SELECT
                *

            FROM tarifas

            ORDER BY
                id DESC
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS DISPONIBLES PARA SWAP
    |--------------------------------------------------------------------------
    |
    | Un equipo disponible para ingresar:
    | - está activo
    | - no está eliminado
    | - no pertenece actualmente a otro cliente
    | - no está dado de baja
    | - no está en reparación
    |
    */

    public function obtenerEquiposDisponiblesSwap(): array
    {
        return $this->fetchAll(
            "
            SELECT
                e.id,
                e.codigo_interno,
                e.serie,
                e.estado,
                e.propiedad,
                e.cliente_id,
                e.localidad_id,
                e.activo,
                e.identificador_externo,
                e.modelo_id,

                m.nombre_modelo AS modelo,
                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo

            FROM equipos e

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE e.activo = 1
              AND e.deleted_at IS NULL
              AND e.cliente_id IS NULL
              AND e.estado NOT IN (
                  'Baja',
                  'En reparación'
              )

            ORDER BY
                e.estado ASC,
                m.marca ASC,
                m.nombre_modelo ASC,
                e.id DESC
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | FICHA 360
    |--------------------------------------------------------------------------
    */

    public function obtenerFicha360(
        int $id
    ): array {
        if ($id <= 0) {
            return [];
        }

        /*
         * El ID recibido normalmente corresponde
         * a un registro de contador.
         */
        $registro = $this->obtenerRegistro($id);

        /*
         * Compatibilidad defensiva:
         * si no es un registro, intentamos interpretarlo
         * como ID de equipo.
         */
        if ($registro === []) {
            $equipoDirecto = $this->obtenerEquipo($id);

            if ($equipoDirecto !== []) {
                $equipoId = $id;

                $ultimo = $this->obtenerUltimoContador(
                    $equipoId
                );

                if ($ultimo !== []) {
                    $registro = $this->obtenerRegistro(
                        (int) ($ultimo['id'] ?? 0)
                    );
                }

                if ($registro === []) {
                    $clienteId = (int) (
                        $equipoDirecto['cliente_id'] ?? 0
                    );

                    $cliente = $this->obtenerClienteCompleto(
                        $clienteId
                    );

                    return [
                        'registro' => [
                            'id' => 0,

                            'cliente_id' => $clienteId,
                            'equipo_id' => $equipoId,

                            'localidad_id' => (int) (
                                $equipoDirecto['localidad_id']
                                ?? $cliente['localidad_id']
                                ?? 0
                            ),

                            'contador_actual' => 0,
                            'contador_anterior' => 0,

                            'contador_actual_color' => 0,
                            'contador_anterior_color' => 0,

                            'copias' => 0,
                            'copias_color' => 0,

                            'fecha' => date(
                                'Y-m-d H:i:s'
                            ),

                            'periodo_mes' => (int) date('m'),
                            'periodo_anio' => (int) date('Y'),

                            'observaciones' =>
                                'Sin lecturas registradas aún'
                        ],

                        'cliente' =>
                            $cliente,

                        'equipo' =>
                            $equipoDirecto,

                        'ultimoContador' =>
                            [],

                        'historial' =>
                            [],

                        'historial_swap' =>
                            $this->obtenerHistorialSwap(
                                $equipoId
                            ),

                        'contrato' =>
                            $this->obtenerContratoActivo(
                                $equipoId
                            ),

                        'tarifas' =>
                            $this->obtenerTarifas(),

                        'equiposDisponibles' =>
                            $this->obtenerEquiposDisponiblesSwap()
                    ];
                }
            } else {
                return [];
            }
        }

        $clienteId = (int) (
            $registro['cliente_id'] ?? 0
        );

        $equipoId = (int) (
            $registro['equipo_id'] ?? 0
        );

        if ($equipoId <= 0) {
            return [];
        }

        return [
            'registro' =>
                $registro,

            'cliente' =>
                $this->obtenerClienteCompleto(
                    $clienteId
                ),

            'equipo' =>
                $this->obtenerEquipo(
                    $equipoId
                ),

            'ultimoContador' =>
                $this->obtenerUltimoContador(
                    $equipoId
                ),

            /*
             * Historial físico del equipo.
             */
            'historial' =>
                $this->historialEquipo(
                    $equipoId
                ),

            /*
             * Continuidad transversal por Swap.
             */
            'historial_swap' =>
                $this->obtenerHistorialSwap(
                    $equipoId
                ),

            'contrato' =>
                $this->obtenerContratoActivo(
                    $equipoId
                ),

            'tarifas' =>
                $this->obtenerTarifas(),

            'equiposDisponibles' =>
                $this->obtenerEquiposDisponiblesSwap()
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | ABM DE REGISTROS
    |--------------------------------------------------------------------------
    */

    public function crearRegistro(
        array $data
    ): int {
        $sql = "
            INSERT INTO registros
            (
                cliente_id,
                equipo_id,
                localidad_id,
                periodo_mes,
                periodo_anio,
                fecha,
                contador_anterior,
                contador_actual,
                contador_anterior_color,
                contador_actual_color,
                copias,
                copias_color,
                observaciones
            )
            VALUES
            (
                :cliente_id,
                :equipo_id,
                :localidad_id,
                :periodo_mes,
                :periodo_anio,
                :fecha,
                :contador_anterior,
                :contador_actual,
                :contador_anterior_color,
                :contador_actual_color,
                :copias,
                :copias_color,
                :observaciones
            )
        ";

        $params = [
            'cliente_id' =>
                (int) ($data['cliente_id'] ?? 0),

            'equipo_id' =>
                (int) ($data['equipo_id'] ?? 0),

            'localidad_id' =>
                (int) ($data['localidad_id'] ?? 0),

            'periodo_mes' =>
                (int) ($data['periodo_mes'] ?? 0),

            'periodo_anio' =>
                (int) ($data['periodo_anio'] ?? 0),

            'fecha' =>
                (string) (
                    $data['fecha']
                    ?? date('Y-m-d H:i:s')
                ),

            'contador_anterior' =>
                (int) ($data['contador_anterior'] ?? 0),

            'contador_actual' =>
                (int) ($data['contador_actual'] ?? 0),

            'contador_anterior_color' =>
                (int) (
                    $data['contador_anterior_color']
                    ?? 0
                ),

            'contador_actual_color' =>
                (int) (
                    $data['contador_actual_color']
                    ?? 0
                ),

            'copias' =>
                (int) ($data['copias'] ?? 0),

            'copias_color' =>
                (int) ($data['copias_color'] ?? 0),

            'observaciones' =>
                (string) (
                    $data['observaciones']
                    ?? ''
                )
        ];

        $this->execute(
            $sql,
            $params
        );

        return (int) $this->db->lastInsertId();
    }

    public function actualizarRegistro(
        int $id,
        array $data
    ): bool {
        if ($id <= 0) {
            return false;
        }

        $sql = "
            UPDATE registros

            SET
                cliente_id =
                    :cliente_id,

                equipo_id =
                    :equipo_id,

                localidad_id =
                    :localidad_id,

                periodo_mes =
                    :periodo_mes,

                periodo_anio =
                    :periodo_anio,

                fecha =
                    :fecha,

                contador_anterior =
                    :contador_anterior,

                contador_actual =
                    :contador_actual,

                contador_anterior_color =
                    :contador_anterior_color,

                contador_actual_color =
                    :contador_actual_color,

                copias =
                    :copias,

                copias_color =
                    :copias_color,

                observaciones =
                    :observaciones

            WHERE id = :id
        ";

        $params = [
            'id' =>
                $id,

            'cliente_id' =>
                (int) ($data['cliente_id'] ?? 0),

            'equipo_id' =>
                (int) ($data['equipo_id'] ?? 0),

            'localidad_id' =>
                (int) ($data['localidad_id'] ?? 0),

            'periodo_mes' =>
                (int) ($data['periodo_mes'] ?? 0),

            'periodo_anio' =>
                (int) ($data['periodo_anio'] ?? 0),

            'fecha' =>
                (string) (
                    $data['fecha']
                    ?? date('Y-m-d H:i:s')
                ),

            'contador_anterior' =>
                (int) ($data['contador_anterior'] ?? 0),

            'contador_actual' =>
                (int) ($data['contador_actual'] ?? 0),

            'contador_anterior_color' =>
                (int) (
                    $data['contador_anterior_color']
                    ?? 0
                ),

            'contador_actual_color' =>
                (int) (
                    $data['contador_actual_color']
                    ?? 0
                ),

            'copias' =>
                (int) ($data['copias'] ?? 0),

            'copias_color' =>
                (int) ($data['copias_color'] ?? 0),

            'observaciones' =>
                (string) (
                    $data['observaciones']
                    ?? ''
                )
        ];

        return $this->execute(
            $sql,
            $params
        );
    }

    public function eliminarRegistro(
        int $id
    ): bool {
        if ($id <= 0) {
            return false;
        }

        return $this->execute(
            "
            DELETE FROM registros
            WHERE id = ?
            ",
            [$id]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTACIÓN
    |--------------------------------------------------------------------------
    */

    public function obtenerDatosExportar(
        array $filtros
    ): array {
        $where = [];
        $params = [];

        if (!empty($filtros['fecha_desde'])) {
            $where[] =
                'DATE(r.fecha) >= ?';

            $params[] =
                $filtros['fecha_desde'];
        }

        if (!empty($filtros['fecha_hasta'])) {
            $where[] =
                'DATE(r.fecha) <= ?';

            $params[] =
                $filtros['fecha_hasta'];
        }

        if (!empty($filtros['localidad_id'])) {
            $where[] =
                '(
                    r.localidad_id = ?
                    OR c.localidad_id = ?
                )';

            $params[] =
                (int) $filtros['localidad_id'];

            $params[] =
                (int) $filtros['localidad_id'];
        }

        if (!empty($filtros['cliente_id'])) {
            $where[] =
                'r.cliente_id = ?';

            $params[] =
                (int) $filtros['cliente_id'];
        }

        if (!empty($filtros['equipo_id'])) {
            $where[] =
                'r.equipo_id = ?';

            $params[] =
                (int) $filtros['equipo_id'];
        }

        $sql = "
            SELECT
                r.*,

                c.nombre AS cliente_nombre,

                e.codigo_interno,
                e.serie,
                e.estado AS estado_equipo,
                e.propiedad,

                m.nombre_modelo AS modelo_nombre,
                m.marca,
                m.tipo AS tipo_equipo,

                COALESCE(
                    l.nombre,
                    lc.nombre,
                    ''
                ) AS localidad_nombre

            FROM registros r

            LEFT JOIN clientes c
                ON c.id = r.cliente_id

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            LEFT JOIN localidades l
                ON l.id = r.localidad_id

            LEFT JOIN localidades lc
                ON lc.id = c.localidad_id
        ";

        if ($where !== []) {
            $sql .=
                ' WHERE '
                . implode(
                    ' AND ',
                    $where
                );
        }

        $sql .= "
            ORDER BY
                r.periodo_anio DESC,
                r.periodo_mes DESC,
                r.fecha DESC,
                r.id DESC
        ";

        return $this->fetchAll(
            $sql,
            $params
        );
    }
}