<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| ARRAYS PRINCIPALES
|--------------------------------------------------------------------------
*/

$registro =
    is_array($registro ?? null)
        ? $registro
        : [];

$cliente =
    is_array($cliente ?? null)
        ? $cliente
        : [];

$equipo =
    is_array($equipo ?? null)
        ? $equipo
        : [];

$contrato =
    is_array($contrato ?? null)
        ? $contrato
        : [];

$ultimoContador =
    is_array($ultimoContador ?? null)
        ? $ultimoContador
        : [];

$tarifas =
    is_array($tarifas ?? null)
        ? $tarifas
        : [];

$historial =
    is_array($historial ?? null)
        ? $historial
        : [];

$equiposDisponibles =
    is_array($equiposDisponibles ?? null)
        ? $equiposDisponibles
        : [];

/*
|--------------------------------------------------------------------------
| IDS
|--------------------------------------------------------------------------
*/

$id =
    (int)(
        $registro['id']
        ?? 0
    );

$clienteId =
    (int)(
        $clienteId
        ?? $registro['cliente_id']
        ?? $cliente['id']
        ?? 0
    );

$equipoId =
    (int)(
        $equipoId
        ?? $registro['equipo_id']
        ?? $equipo['id']
        ?? 0
    );

/*
|--------------------------------------------------------------------------
| CLIENTE
|--------------------------------------------------------------------------
*/

$clienteNombre =
    trim(
        (string)(
            $cliente['nombre']
            ?? $registro['cliente_nombre']
            ?? 'Sin cliente'
        )
    );

$clienteRazonSocial =
    trim(
        (string)(
            $cliente['razon_social']
            ?? $registro['cliente_razon_social']
            ?? ''
        )
    );

$clienteCuit =
    trim(
        (string)(
            $cliente['cuit']
            ?? $registro['cliente_cuit']
            ?? ''
        )
    );

$clienteTelefono =
    trim(
        (string)(
            $cliente['telefono']
            ?? $registro['cliente_telefono']
            ?? ''
        )
    );

$clienteEmail =
    trim(
        (string)(
            $cliente['email']
            ?? $registro['cliente_email']
            ?? ''
        )
    );

$clienteDomicilio =
    trim(
        (string)(
            $cliente['domicilio']
            ?? $registro['cliente_domicilio']
            ?? ''
        )
    );

$clienteLocalidad =
    trim(
        (string)(
            $cliente['localidad_nombre']
            ?? $registro['localidad_nombre']
            ?? ''
        )
    );

$clienteCondicionFiscal =
    trim(
        (string)(
            $cliente['condicion_fiscal']
            ?? $registro['cliente_condicion_fiscal']
            ?? ''
        )
    );

$clienteObservaciones =
    trim(
        (string)(
            $cliente['observaciones']
            ?? $registro['cliente_observaciones']
            ?? ''
        )
    );

/*
|--------------------------------------------------------------------------
| EQUIPO
|--------------------------------------------------------------------------
*/

$codigoInterno =
    trim(
        (string)(
            $equipo['codigo_interno']
            ?? $registro['codigo_interno']
            ?? ''
        )
    );

$serie =
    trim(
        (string)(
            $equipo['serie']
            ?? $registro['serie']
            ?? ''
        )
    );

$marca =
    trim(
        (string)(
            $equipo['marca']
            ?? $registro['marca']
            ?? ''
        )
    );

$modelo =
    trim(
        (string)(
            $equipo['modelo']
            ?? $registro['modelo']
            ?? $registro['modelo_nombre']
            ?? ''
        )
    );

$tipoEquipo =
    trim(
        (string)(
            $equipo['tipo_equipo']
            ?? $registro['tipo_equipo']
            ?? $equipo['tipo']
            ?? ''
        )
    );

$propiedad =
    trim(
        (string)(
            $equipo['propiedad']
            ?? $registro['propiedad']
            ?? ''
        )
    );

$estadoEquipo =
    trim(
        (string)(
            $equipo['estado']
            ?? $registro['estado_equipo']
            ?? ''
        )
    );

$identificadorExterno =
    trim(
        (string)(
            $equipo['identificador_externo']
            ?? $registro['identificador_externo']
            ?? ''
        )
    );

$equipoObservaciones =
    trim(
        (string)(
            $equipo['observaciones']
            ?? $registro['equipo_observaciones']
            ?? ''
        )
    );

/*
|--------------------------------------------------------------------------
| CONTADORES
|--------------------------------------------------------------------------
*/

$contadorActual =
    (int)(
        $registro['contador_actual']
        ?? $ultimoContador['contador_actual']
        ?? 0
    );

$contadorAnterior =
    (int)(
        $registro['contador_anterior']
        ?? $ultimoContador['contador_anterior']
        ?? 0
    );

$contadorActualColor =
    (int)(
        $registro['contador_actual_color']
        ?? $ultimoContador['contador_actual_color']
        ?? 0
    );

$contadorAnteriorColor =
    (int)(
        $registro['contador_anterior_color']
        ?? $ultimoContador['contador_anterior_color']
        ?? 0
    );

$copias =
    (int)(
        $registro['copias']
        ?? $ultimoContador['copias']
        ?? max(
            0,
            $contadorActual - $contadorAnterior
        )
    );

$copiasColor =
    (int)(
        $registro['copias_color']
        ?? $ultimoContador['copias_color']
        ?? max(
            0,
            $contadorActualColor - $contadorAnteriorColor
        )
    );

$tipoNormalizado =
    strtoupper(
        trim($tipoEquipo)
    );

$esColor =
    !in_array(
        $tipoNormalizado,
        [
            'MONO',
            'MONOCROMO',
            'MONOCROMATICO',
            'MONOCROMÁTICO',
            'B/N',
            'NEGRO'
        ],
        true
    );

/*
|--------------------------------------------------------------------------
| FECHA / PERÍODO
|--------------------------------------------------------------------------
*/

$fechaLectura =
    (string)(
        $registro['fecha']
        ?? $ultimoContador['fecha']
        ?? ''
    );

$fechaLecturaFormateada =
    '-';

if ($fechaLectura !== '') {
    $timestamp =
        strtotime($fechaLectura);

    if ($timestamp !== false) {
        $fechaLecturaFormateada =
            date(
                'd/m/Y H:i',
                $timestamp
            );
    }
}

$periodoMes =
    (int)(
        $registro['periodo_mes']
        ?? $ultimoContador['periodo_mes']
        ?? (int)date('m')
    );

$periodoAnio =
    (int)(
        $registro['periodo_anio']
        ?? $ultimoContador['periodo_anio']
        ?? (int)date('Y')
    );

$periodo =
    (
        $periodoMes > 0
        && $periodoAnio > 0
    )
        ? sprintf(
            '%02d/%04d',
            $periodoMes,
            $periodoAnio
        )
        : '-';

/*
|--------------------------------------------------------------------------
| ESTADO CSS
|--------------------------------------------------------------------------
*/

$estadoClass = match (
    strtoupper($estadoEquipo)
) {
    'ACTIVO',
    'INSTALADO',
    'OPERATIVO' => 'success',

    'MANTENIMIENTO',
    'TALLER' => 'warning',

    'BAJA',
    'INACTIVO' => 'danger',

    default => 'secondary'
};

/*
|--------------------------------------------------------------------------
| CONTRATO
|--------------------------------------------------------------------------
*/

$contratoId =
    (int)(
        $contrato['id']
        ?? 0
    );

$contratoEstado =
    trim(
        (string)(
            $contrato['estado']
            ?? ''
        )
    );

$contratoInicio =
    trim(
        (string)(
            $contrato['fecha_inicio']
            ?? $contrato['inicio']
            ?? ''
        )
    );

$contratoFin =
    trim(
        (string)(
            $contrato['fecha_fin']
            ?? $contrato['fin']
            ?? ''
        )
    );

$contratoModalidad =
    trim(
        (string)(
            $contrato['modalidad']
            ?? ''
        )
    );

$contratoObservaciones =
    trim(
        (string)(
            $contrato['observaciones']
            ?? ''
        )
    );

/*
|--------------------------------------------------------------------------
| CSRF Y TAB ACTIVA
|--------------------------------------------------------------------------
*/

$csrf = (string)($csrf ?? '');

$tabActivo = (string)($tabActivo ?? 'resumen');

$tabsPermitidas = [
    'resumen',
    'contadores',
    'cliente',
    'equipo',
    'contrato',
    'tarifas',
    'historial',
    'swap',
    'auditoria'
];

if (!in_array($tabActivo, $tabsPermitidas, true)) {
    $tabActivo = 'resumen';
}

?>

<!-- ================================================================
     HEADER
     ================================================================ -->

<div class="counter-360-header mb-4">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3">
        <div>
            <div class="eyebrow text-muted fw-semibold">
                CSDI ERP PRO · Counter
            </div>

            <h1 class="text-white fw-bold mb-1">
                <?= e($clienteNombre) ?>
            </h1>

            <div class="equipment-meta text-white-50">
                <?php if ($modelo !== ''): ?>
                    <?= e($modelo) ?>
                <?php endif; ?>

                <?php if ($serie !== ''): ?>
                    · Serie <?= e($serie) ?>
                <?php endif; ?>

                <?php if ($codigoInterno !== ''): ?>
                    · Código <?= e($codigoInterno) ?>
                <?php endif; ?>
            </div>
        </div>

        <span class="badge bg-<?= e($estadoClass) ?> fs-6 px-3 py-2">
            <?= e($estadoEquipo !== '' ? $estadoEquipo : 'SIN ESTADO') ?>
        </span>
    </div>
</div>

<!-- ================================================================
     KPIs
     ================================================================ -->

<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3">
        <div class="card p-3 shadow-sm border-0 border-start border-primary border-4 bg-white">
            <div class="text-muted small fw-bold">ÚLTIMO MONO</div>
            <div class="fs-3 fw-bold text-dark">
                <?= number_format($contadorActual, 0, ',', '.') ?>
            </div>
            <div class="small text-muted">
                Anterior: <?= number_format($contadorAnterior, 0, ',', '.') ?>
            </div>
        </div>
    </div>

    <div class="col-6 col-xl-3">
        <div class="card p-3 shadow-sm border-0 border-start border-info border-4 bg-white">
            <div class="text-muted small fw-bold">ÚLTIMO COLOR</div>
            <div class="fs-3 fw-bold text-dark">
                <?php if ($esColor): ?>
                    <?= number_format($contadorActualColor, 0, ',', '.') ?>
                <?php else: ?>
                    <span class="text-muted">N/A</span>
                <?php endif; ?>
            </div>
            <div class="small text-muted">
                <?php if ($esColor): ?>
                    Anterior: <?= number_format($contadorAnteriorColor, 0, ',', '.') ?>
                <?php else: ?>
                    Monocromático
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-6 col-xl-3">
        <div class="card p-3 shadow-sm border-0 border-start border-success border-4 bg-white">
            <div class="text-muted small fw-bold">CONSUMO MONO</div>
            <div class="fs-3 fw-bold text-dark">
                <?= number_format($copias, 0, ',', '.') ?>
            </div>
            <div class="small text-muted">Período <?= e($periodo) ?></div>
        </div>
    </div>

    <div class="col-6 col-xl-3">
        <div class="card p-3 shadow-sm border-0 border-start border-secondary border-4 bg-white">
            <div class="text-muted small fw-bold">ÚLTIMA LECTURA</div>
            <div class="fs-5 fw-bold text-dark mt-1">
                <?= e($fechaLecturaFormateada) ?>
            </div>
            <div class="small text-muted">Registro #<?= e($id) ?></div>
        </div>
    </div>
</div>

<!-- ================================================================
     TABS
     ================================================================ -->

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <ul class="nav nav-tabs px-3 pt-3 border-secondary" id="counter360Tabs" role="tablist">
            <?php
            $tabDefinitions = [
                ['id' => 'resumen', 'label' => 'Resumen', 'icon' => 'gauge-high'],
                ['id' => 'contadores', 'label' => 'Editar Contadores', 'icon' => 'pen-to-square'],
                ['id' => 'cliente', 'label' => 'Cliente', 'icon' => 'user'],
                ['id' => 'equipo', 'label' => 'Equipo', 'icon' => 'print'],
                ['id' => 'contrato', 'label' => 'Contrato', 'icon' => 'file-contract'],
                ['id' => 'tarifas', 'label' => 'Tarifas', 'icon' => 'dollar-sign'],
                ['id' => 'historial', 'label' => 'Historial', 'icon' => 'clock-rotate-left'],
                ['id' => 'swap', 'label' => 'Swap', 'icon' => 'right-left', 'class' => 'text-warning'],
                ['id' => 'auditoria', 'label' => 'Auditoría', 'icon' => 'shield-halved']
            ];
            ?>

            <?php foreach ($tabDefinitions as $tab): ?>
                <li class="nav-item" role="presentation">
                    <button
                        class="nav-link <?= $tabActivo === $tab['id'] ? 'active fw-bold' : '' ?> <?= e($tab['class'] ?? '') ?>"
                        id="tab-button-<?= e($tab['id']) ?>"
                        type="button"
                        role="tab"
                        aria-controls="tab-<?= e($tab['id']) ?>"
                        aria-selected="<?= $tabActivo === $tab['id'] ? 'true' : 'false' ?>"
                        data-counter-tab="tab-<?= e($tab['id']) ?>"
                    >
                        <i class="fa-solid fa-<?= e($tab['icon']) ?> me-1"></i>
                        <?= e($tab['label']) ?>
                    </button>
                </li>
            <?php endforeach; ?>
        </ul>

        <div class="tab-content p-4">

            <!-- ======================================================
                 1. RESUMEN
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'resumen' ? 'show active' : '' ?>" id="tab-resumen" role="tabpanel">
                <h5 class="fw-bold mb-3">Estado General</h5>
                <div class="row g-3">
                    <div class="col-md-6 col-xl-3">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">Cliente</span>
                            <strong class="text-dark"><?= e($clienteNombre) ?></strong>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">Equipo</span>
                            <strong class="text-dark"><?= e($modelo !== '' ? $modelo : 'Sin modelo') ?></strong>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">Serie</span>
                            <strong class="text-dark"><?= e($serie !== '' ? $serie : '-') ?></strong>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">Propiedad</span>
                            <strong class="text-dark"><?= e($propiedad !== '' ? $propiedad : '-') ?></strong>
                        </div>
                    </div>
                </div>

                <h5 class="fw-bold mt-4 mb-3">Identificación CSDI</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">ID Cliente</span>
                            <strong class="text-dark">#<?= e($clienteId) ?></strong>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">ID Equipo</span>
                            <strong class="text-dark">#<?= e($equipoId) ?></strong>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <span class="text-muted small d-block">ID Registro</span>
                            <strong class="text-dark">#<?= e($id) ?></strong>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ======================================================
                 2. EDITAR CONTADORES (FORMULARIO POST A /contadores/update/{id})
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'contadores' ? 'show active' : '' ?>" id="tab-contadores" role="tabpanel">
                <form action="/contadores/update/<?= e($id) ?>" method="POST" class="needs-validation">
                    <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
                    <input type="hidden" name="equipo_id" value="<?= e($equipoId) ?>">
                    <input type="hidden" name="cliente_id" value="<?= e($clienteId) ?>">

                    <div class="row g-3 mb-4">
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Mes Período:</label>
                            <input type="number" class="form-control" name="periodo_mes" min="1" max="12" value="<?= e($periodoMes) ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Año Período:</label>
                            <input type="number" class="form-control" name="periodo_anio" min="2000" value="<?= e($periodoAnio) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Fecha Toma Lectura:</label>
                            <input type="date" class="form-control" name="fecha" value="<?= e($fechaLectura !== '' ? date('Y-m-d', strtotime($fechaLectura)) : date('Y-m-d')) ?>" required>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="card p-3 border">
                                <h6 class="fw-bold text-primary mb-3"><i class="fa-solid fa-print me-2"></i> Contador Monocromático</h6>
                                <div class="mb-3">
                                    <label class="form-label small text-muted">Contador Anterior:</label>
                                    <input type="number" class="form-control bg-light" value="<?= e($contadorAnterior) ?>" readonly>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Contador Actual Mono:</label>
                                    <input type="number" class="form-control form-control-lg fw-bold" name="contador_actual" min="<?= e($contadorAnterior) ?>" value="<?= e($contadorActual) ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card p-3 border">
                                <h6 class="fw-bold text-info mb-3"><i class="fa-solid fa-palette me-2"></i> Contador Color</h6>
                                <?php if ($esColor): ?>
                                    <div class="mb-3">
                                        <label class="form-label small text-muted">Contador Color Anterior:</label>
                                        <input type="number" class="form-control bg-light" value="<?= e($contadorAnteriorColor) ?>" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Contador Actual Color:</label>
                                        <input type="number" class="form-control form-control-lg fw-bold" name="contador_actual_color" min="<?= e($contadorAnteriorColor) ?>" value="<?= e($contadorActualColor) ?>">
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted py-4 mb-0 text-center"><i class="fa-solid fa-ban me-2"></i> Este equipo es Monocromático.</p>
                                    <input type="hidden" name="contador_actual_color" value="0">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="mt-3 mb-4">
                        <label class="form-label fw-bold">Observaciones:</label>
                        <textarea name="observaciones" class="form-control" rows="2" placeholder="Notas sobre la toma de lectura..."><?= e($registro['observaciones'] ?? '') ?></textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary px-4 fw-bold">
                            <i class="fa-solid fa-floppy-disk me-1"></i> Guardar Cambios
                        </button>
                        <a href="/contadores/historial/<?= e($equipoId) ?>" class="btn btn-outline-secondary">
                            <i class="fa-solid fa-clock-rotate-left me-1"></i> Ver Historial
                        </a>
                    </div>
                </form>
            </div>

            <!-- ======================================================
                 3. CLIENTE
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'cliente' ? 'show active' : '' ?>" id="tab-cliente" role="tabpanel">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Datos del Cliente</h5>
                    <a href="/clientes/editar/<?= e($clienteId) ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fa-solid fa-pen me-1"></i> Editar Cliente
                    </a>
                </div>
                <div class="row g-3">
                    <div class="col-md-6"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Nombre</span><strong><?= e($clienteNombre) ?></strong></div></div>
                    <div class="col-md-6"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Razón Social</span><strong><?= e($clienteRazonSocial !== '' ? $clienteRazonSocial : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">CUIT</span><strong><?= e($clienteCuit !== '' ? $clienteCuit : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Teléfono</span><strong><?= e($clienteTelefono !== '' ? $clienteTelefono : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Email</span><strong><?= e($clienteEmail !== '' ? $clienteEmail : '-') ?></strong></div></div>
                    <div class="col-md-8"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Domicilio</span><strong><?= e($clienteDomicilio !== '' ? $clienteDomicilio : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Localidad</span><strong><?= e($clienteLocalidad !== '' ? $clienteLocalidad : '-') ?></strong></div></div>
                </div>
            </div>

            <!-- ======================================================
                 4. EQUIPO
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'equipo' ? 'show active' : '' ?>" id="tab-equipo" role="tabpanel">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Datos del Equipo</h5>
                    <a href="/equipos/editar/<?= e($equipoId) ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fa-solid fa-pen me-1"></i> Editar Equipo
                    </a>
                </div>
                <div class="row g-3">
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Código Interno</span><strong><?= e($codigoInterno !== '' ? $codigoInterno : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Marca</span><strong><?= e($marca !== '' ? $marca : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Modelo</span><strong><?= e($modelo !== '' ? $modelo : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Número de Serie</span><strong><?= e($serie !== '' ? $serie : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Tipo</span><strong><?= e($tipoEquipo !== '' ? $tipoEquipo : '-') ?></strong></div></div>
                    <div class="col-md-4"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Estado</span><strong><?= e($estadoEquipo !== '' ? $estadoEquipo : '-') ?></strong></div></div>
                </div>
            </div>

            <!-- ======================================================
                 5. CONTRATO
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'contrato' ? 'show active' : '' ?>" id="tab-contrato" role="tabpanel">
                <h5 class="fw-bold mb-3">Contrato de Alquiler / Servicio</h5>
                <?php if ($contratoId > 0): ?>
                    <div class="row g-3">
                        <div class="col-md-3"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">ID Contrato</span><strong>#<?= e($contratoId) ?></strong></div></div>
                        <div class="col-md-3"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Estado</span><strong><?= e($contratoEstado) ?></strong></div></div>
                        <div class="col-md-3"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Inicio</span><strong><?= e($contratoInicio) ?></strong></div></div>
                        <div class="col-md-3"><div class="p-3 bg-light rounded"><span class="text-muted small d-block">Fin</span><strong><?= e($contratoFin) ?></strong></div></div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning mb-0"><i class="fa-solid fa-triangle-exclamation me-2"></i> No se encontró un contrato activo asociado a este equipo.</div>
                <?php endif; ?>
            </div>

            <!-- ======================================================
                 6. TARIFAS (Adaptado de forma nativa a la BD de producción)
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'tarifas' ? 'show active' : '' ?>" id="tab-tarifas" role="tabpanel">
                <h5 class="fw-bold mb-3">Planes y Tarifas Disponibles</h5>
                <?php if (empty($tarifas)): ?>
                    <div class="alert alert-warning"><i class="fa-solid fa-triangle-exclamation me-2"></i> No se encontraron tarifas registradas.</div>
                <?php else: ?>
                    <div class="table-responsive shadow-sm border rounded">
                        <table class="table table-hover align-middle mb-0 bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3">Nombre del Plan</th>
                                    <th class="text-end">Precio Mono</th>
                                    <th class="text-end">Precio Color</th>
                                    <th class="text-end">Abono Mono</th>
                                    <th class="text-end">Abono Color</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tarifas as $t): ?>
                                    <tr>
                                        <td class="ps-3 fw-bold text-dark"><?= e($t['nombre_tarifa'] ?? 'Sin nombre') ?></td>
                                        <td class="text-end font-monospace text-success fw-bold">$<?= number_format((float)($t['precio_mono'] ?? 0), 2, ',', '.') ?></td>
                                        <td class="text-end font-monospace text-info fw-bold">$<?= number_format((float)($t['precio_color'] ?? 0), 2, ',', '.') ?></td>
                                        <td class="text-end font-monospace text-secondary">$<?= number_format((float)($t['abono_mensual_mono'] ?? 0), 2, ',', '.') ?></td>
                                        <td class="text-end font-monospace text-secondary">$<?= number_format((float)($t['abono_mensual_color'] ?? 0), 2, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ======================================================
                 7. HISTORIAL
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'historial' ? 'show active' : '' ?>" id="tab-historial" role="tabpanel">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">Historial de Lecturas del Equipo</h5>
                    <a href="/contadores/historial/<?= e($equipoId) ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fa-solid fa-arrow-up-right-from-square me-1"></i> Abrir Historial
                    </a>
                </div>
                <?php if ($historial !== []): ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Mono</th>
                                    <th>Color</th>
                                    <th>Copias</th>
                                    <th>Período</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($historial as $item): ?>
                                    <tr>
                                        <td><?= !empty($item['fecha']) ? date('d/m/Y', strtotime((string)$item['fecha'])) : '-' ?></td>
                                        <td><?= number_format((int)($item['contador_actual'] ?? 0), 0, ',', '.') ?></td>
                                        <td><?= number_format((int)($item['contador_actual_color'] ?? 0), 0, ',', '.') ?></td>
                                        <td><?= number_format((int)($item['copias'] ?? 0), 0, ',', '.') ?></td>
                                        <td><?= sprintf('%02d/%04d', (int)($item['periodo_mes'] ?? 0), (int)($item['periodo_anio'] ?? 0)) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- ======================================================
                 8. SWAP
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'swap' ? 'show active' : '' ?>" id="tab-swap" role="tabpanel">
                <h5 class="fw-bold mb-3">Cambio Físico de Equipo (Swap)</h5>
                <div class="row align-items-center">
                    <div class="col-md-5">
                        <div class="card p-3 border">
                            <span class="badge bg-secondary mb-2 w-auto">EQUIPO SALIENTE</span>
                            <h5><?= e($modelo !== '' ? $modelo : 'Equipo actual') ?></h5>
                            <small class="text-muted">Serie: <?= e($serie) ?> | Código: <?= e($codigoInterno) ?></small>
                        </div>
                    </div>
                    <div class="col-md-2 text-center fs-3 text-warning">
                        <i class="fa-solid fa-right-left"></i>
                    </div>
                    <div class="col-md-5">
                        <div class="card p-3 border">
                            <span class="badge bg-success mb-2 w-auto">EQUIPO ENTRANTE</span>
                            <select id="swap_equipo_id" class="form-select mb-3">
                                <option value="">Seleccione equipo disponible</option>
                                <option value="0" class="text-danger fw-bold">❌ SOLO RETIRAR MÁQUINA (Sin reemplazo)</option>
                                <?php foreach ($equiposDisponibles as $disponible): ?>
                                    <?php $dId = (int)($disponible['id'] ?? 0); if ($dId <= 0 || $dId === $equipoId) continue; ?>
                                    <option value="<?= e($dId) ?>"><?= e($disponible['modelo'] ?? 'Equipo') ?> - Serie: <?= e($disponible['serie'] ?? '') ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="button" class="btn btn-warning fw-bold" id="btnIniciarSwap">
                                <i class="fa-solid fa-right-left me-1"></i> Iniciar Swap
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ======================================================
                 9. AUDITORÍA
                 ====================================================== -->
            <div class="tab-pane fade <?= $tabActivo === 'auditoria' ? 'show active' : '' ?>" id="tab-auditoria" role="tabpanel">
                <h5 class="fw-bold mb-3">Auditoría y Trazabilidad CSDI</h5>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div><strong>Última Lectura:</strong> Registro #<?= e($id) ?></div>
                        <span class="badge bg-primary"><?= e($fechaLecturaFormateada) ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div><strong>Cliente Vinculado:</strong> #<?= e($clienteId) ?> - <?= e($clienteNombre) ?></div>
                        <span class="badge bg-secondary">OK</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div><strong>Equipo Vinculado:</strong> #<?= e($equipoId) ?> - Serie <?= e($serie) ?></div>
                        <span class="badge bg-secondary">OK</span>
                    </li>
                </ul>
            </div>

        </div>
    </div>
</div>

<!-- FOOTER -->
<div class="d-flex justify-content-between align-items-center mt-4">
    <div class="text-muted small">Ficha 360° · Equipo #<?= e($equipoId) ?></div>
    <a href="/contadores" class="btn btn-outline-secondary btn-sm">
        <i class="fa-solid fa-arrow-left me-1"></i> Volver a Contadores
    </a>
</div>

<!-- JAVASCRIPT DE NAVEGACIÓN DE PESTAÑAS Y INTERACCIONES -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('[data-counter-tab]');
    const panes = document.querySelectorAll('.tab-pane');

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            const targetId = this.getAttribute('data-counter-tab');

            buttons.forEach(b => b.classList.remove('active', 'fw-bold'));
            panes.forEach(p => p.classList.remove('show', 'active'));

            this.classList.add('active', 'fw-bold');
            const activePane = document.getElementById(targetId);
            if (activePane) {
                activePane.classList.add('show', 'active');
            }
        });
    });

    // =================================================================
    // MANEJADOR INTERACTIVO DE SWAP / RETIRO DE EQUIPO
    // =================================================================
    const btnIniciarSwap = document.getElementById('btnIniciarSwap');
    const selectSwapEquipo = document.getElementById('swap_equipo_id');

    if (btnIniciarSwap && selectSwapEquipo) {
        btnIniciarSwap.addEventListener('click', function () {
            const nuevoEquipoId = selectSwapEquipo.value;
            if (nuevoEquipoId === "") {
                alert('Por favor, seleccione un equipo entrante o elija la opción "Solo retirar máquina".');
                return;
            }

            let mensaje = '¿Está seguro de que desea realizar el Swap (intercambio físico) de este equipo?';
            if (nuevoEquipoId === "0") {
                mensaje = '¿Está seguro de que desea RETIRAR esta máquina de forma permanente sin colocar un reemplazo?';
            }

            if (confirm(mensaje)) {
                // Crear un formulario temporal dinámico para enviar la petición POST segura
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '/admin/equipos/swap/' + <?= (int)$equipoId ?>;

                // Token CSRF de seguridad indispensable
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = 'csrf_token';
                csrfInput.value = '<?= e($csrf) ?>';
                form.appendChild(csrfInput);

                // ID del nuevo equipo seleccionado (0 para retirar)
                const equipoEntranteInput = document.createElement('input');
                equipoEntranteInput.type = 'hidden';
                equipoEntranteInput.name = 'equipo_entrante_id';
                equipoEntranteInput.value = nuevoEquipoId;
                form.appendChild(equipoEntranteInput);

                // ID del cliente actual
                const clienteIdInput = document.createElement('input');
                clienteIdInput.type = 'hidden';
                clienteIdInput.name = 'cliente_id';
                clienteIdInput.value = '<?= (int)$clienteId ?>';
                form.appendChild(clienteIdInput);

                // Tipo de operación genérica para el controlador (CSDI o RETIRAR)
                const tipoSwapInput = document.createElement('input');
                tipoSwapInput.type = 'hidden';
                tipoSwapInput.name = 'tipo_swap';
                tipoSwapInput.value = nuevoEquipoId === "0" ? 'RETIRAR' : 'CSDI';
                form.appendChild(tipoSwapInput);

                // Motivo descriptivo de la operación
                const motivoInput = document.createElement('input');
                motivoInput.type = 'hidden';
                motivoInput.name = 'motivo';
                motivoInput.value = nuevoEquipoId === "0" 
                    ? 'Retirada permanente de máquina sin reemplazo' 
                    : 'Cambio de equipo a través de Ficha 360°';
                form.appendChild(motivoInput);

                document.body.appendChild(form);
                form.submit();
            }
        });
    }
});
</script>