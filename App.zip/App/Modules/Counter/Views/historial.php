<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP - Counter History View (Historial de Consumos - Gráficos Sincronizados)
|--------------------------------------------------------------------------
*/

$items = is_array($items ?? null) ? $items : [];
$equipo_id = (int)($equipo_id ?? 0);
$titulo = $titulo ?? 'Historial de Consumos';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Extraemos el nombre del cliente del primer registro de forma segura
$clienteNombre = (string)(!empty($items) ? ($items[0]['cliente_nombre'] ?? 'Cliente') : 'Cliente');
?>

<div class="container-fluid py-4">

    <!-- Header de la Sección (Con el Nombre del Cliente destacado) -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">
        <div class="d-flex align-items-center">
            <div class="bg-primary text-white rounded-3 p-3 me-3 shadow-sm">
                <i class="fa-solid fa-chart-line fs-3"></i>
            </div>
            <div>
                <h2 class="fw-bold text-white mb-1"><?= e($titulo) ?></h2>
                <p class="text-muted-erp small mb-0">
                    Cliente: <strong class="text-white fs-6"><?= htmlspecialchars($clienteNombre, ENT_QUOTES, 'UTF-8') ?></strong> | 
                    Bitácora histórica de mediciones de odómetros para el Equipo #<?= $equipo_id ?>
                </p>
            </div>
        </div>
        <div>
            <a href="/contadores" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver al Listado
            </a>
        </div>
    </div>

    <!-- =====================================================
         1) PANEL DE GRÁFICO INTERACTIVO (Chart.js en vivo)
         ===================================================== -->
    <?php if (!empty($items)): ?>
        <div class="card-erp p-4 mb-4">
            <h5 class="text-white fw-bold mb-3 small text-uppercase">
                <i class="fa-solid fa-chart-area text-success me-2"></i> Gráfico de Tendencia de Consumo (Últimos períodos)
            </h5>
            <div style="position: relative; height:320px; width:100%;">
                <canvas id="chartConsumosTng"></canvas>
            </div>
        </div>
    <?php endif; ?>

    <!-- =====================================================
         2) TABLA HISTÓRICA DE MEDICIONES
         ===================================================== -->
    <div class="card shadow-sm border-0 rounded-3 overflow-hidden">
        <div class="card-header bg-dark text-white fw-bold py-3">
            <i class="fa-solid fa-list me-2 text-info"></i> Detalle cronológico de lecturas cargadas
        </div>
        <div class="table-responsive bg-white">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Periodo</th>
                        <th>Fecha de Toma</th>
                        <th class="text-end">Contador Negro (Mono)</th>
                        <th class="text-end">Contador Color</th>
                        <th class="text-end text-warning">Copias Mono</th>
                        <th class="text-end text-info">Copias Color</th>
                        <th class="pe-4">Observaciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5 fs-6">No se encontraron lecturas históricas para este equipo.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($items as $row): ?>
                            <?php
                            $rFecha = (string)($row['fecha'] ?? '');
                            $rMono  = (int)($row['contador_actual'] ?? 0);
                            $rColor = (int)($row['contador_actual_color'] ?? 0);
                            $rCop   = (int)($row['copias'] ?? 0);
                            $rCol   = (int)($row['copias_color'] ?? 0);
                            $rObs   = trim((string)($row['observaciones'] ?? ''));
                            ?>
                            <tr>
                                <td class="ps-4 fw-bold text-dark font-monospace">
                                    <?= e($row['periodo_mes'] ?? '') ?>/<?= e($row['periodo_anio'] ?? '') ?>
                                </td>
                                <td><?= $rFecha !== '' ? date('d/m/Y', strtotime($rFecha)) : '-' ?></td>
                                <td class="text-end font-monospace text-secondary"><?= number_format($rMono) ?></td>
                                <td class="text-end font-monospace text-secondary"><?= number_format($rColor) ?></td>
                                <td class="text-end font-monospace text-warning fw-bold"><?= number_format($rCop) ?></td>
                                <td class="text-end font-monospace text-info fw-bold"><?= number_format($rCol) ?></td>
                                <td class="pe-4 small text-secondary text-truncate" style="max-width: 200px;" title="<?= e($rObs) ?>">
                                    <?= $rObs !== '' ? e($rObs) : '-' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- =====================================================
     3) CARGA DIRECTA DE LA LIBRERÍA DE GRÁFICOS (Bypass de AssetManager)
     ===================================================== -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- =====================================================
     4) SCRIPT: RENDERIZADO DEL GRÁFICO DINÁMICO (Chart.js)
     ===================================================== -->
<?php if (!empty($items)): ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Recuperamos de forma segura el set de datos inyectado por PHP
    const rawData = <?= json_encode(array_reverse($items)) ?>; // Invertimos para mostrar cronología de izquierda a derecha (Pasado -> Presente)

    // 2. Compilamos las etiquetas (labels) del gráfico: "Mes/Año"
    const labels = rawData.map(item => `${item.periodo_mes}/${item.periodo_anio}`);

    // 3. Compilamos los conjuntos de datos (datasets) de copias monocromáticas y color
    const datosMono = rawData.map(item => parseInt(item.copias) || 0);
    const datosColor = rawData.map(item => parseInt(item.copias_color) || 0);

    const ctx = document.getElementById('chartConsumosTng');

    if (ctx && typeof Chart !== 'undefined') {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Copias Monocromáticas (B&W)',
                        data: datosMono,
                        borderColor: '#ffc107', // Amarillo corporativo
                        backgroundColor: 'rgba(255, 193, 7, 0.08)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Copias Color',
                        data: datosColor,
                        borderColor: '#0dcaf0', // Azul/Cian corporativo
                        backgroundColor: 'rgba(13, 202, 240, 0.08)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            font: { size: 11, family: 'sans-serif', weight: 'bold' }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(0, 0, 0, 0.04)' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }
});
</script>
<?php endif; ?>