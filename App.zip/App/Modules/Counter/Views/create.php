<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP - Counter Create View (Nueva Lectura de Contadores - Control UX Avanzado)
|--------------------------------------------------------------------------
*/

$titulo = $titulo ?? 'Registrar Lectura';
$localidades = $localidades ?? [];
$csrf = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        if (is_array($value)) {
            return htmlspecialchars(implode(', ', array_filter($value, 'is_scalar')), ENT_QUOTES, 'UTF-8');
        }
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <!-- Header de la Sección -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h2 class="fw-bold text-white">
                <i class="fa-solid fa-gauge-high text-primary me-2"></i> <?= e($titulo) ?>
            </h2>
            <p class="text-muted-erp small mb-0">Ingrese una nueva lectura física de odómetro para facturación de copias</p>
        </div>
        <div>
            <a href="/contadores" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver al Listado
            </a>
        </div>
    </div>

    <!-- Formulario de Carga -->
    <div class="card-erp p-4">
        <form id="formNuevaLectura" method="POST" action="/contadores/store">
            
            <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

            <h5 class="text-white fw-bold mb-4 small text-uppercase">
                <i class="fa-solid fa-network-wired text-primary me-2"></i> 1. Selección de Ubicación y Hardware
            </h5>

            <div class="row g-3 mb-2">
                <div class="col-md-4">
                    <label class="form-label text-white-50 small fw-bold">Localidad de la Visita</label>
                    <select id="localidad_id" name="localidad_id" class="form-select bg-dark border-secondary text-white" required>
                        <option value="">Seleccione localidad</option>
                        <?php foreach ($localidades as $l): ?>
                            <option value="<?= e($l['id'] ?? '') ?>"><?= e($l['nombre'] ?? '') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label text-white-50 small fw-bold">Cliente Asociado</label>
                    <select id="cliente_id" name="cliente_id" class="form-select bg-dark border-secondary text-white" required>
                        <option value="">Seleccione cliente</option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label text-white-50 small fw-bold">Equipo de Copiado</label>
                    <select id="equipo_id" name="equipo_id" class="form-select bg-dark border-secondary text-white" required>
                        <option value="">Seleccione equipo</option>
                    </select>
                </div>
            </div>

            <!-- =====================================================
                 ALERTA: CONTROL DE CARGA MULTI-EQUIPO
                 ===================================================== -->
            <div id="alert_equipos_pendientes" class="alert alert-warning border-warning-subtle shadow-sm p-3 rounded-3 mt-3 mb-4 d-none animate-fade-in" style="background-color: #fff3cd !important;">
                <h6 class="fw-bold mb-2 text-dark" style="color: #664d03 !important;"><i class="fa-solid fa-triangle-exclamation me-1"></i> Control de Carga Multi-Equipo</h6>
                <p class="small text-dark mb-2">Este cliente tiene <strong id="lbl_cant_equipos">0</strong> fotocopiadoras asociadas. Debes registrar las lecturas de todas ellas antes de cerrar el período de abono:</p>
                <ul class="mb-0 small text-dark fw-semibold" id="lista_equipos_cliente"></ul>
            </div>

            <div class="border-top border-secondary pt-4 mt-2 d-flex justify-content-between align-items-center">
                <h5 class="text-white fw-bold mb-0 small text-uppercase">
                    <i class="fa-solid fa-list-ol text-success me-2"></i> 2. Lecturas del Odómetro y Período
                </h5>
                
                <!-- BOTÓN: Saltar lectura si está fuera de servicio -->
                <button type="button" class="btn btn-outline-warning btn-sm fw-bold px-3" id="btnSaltarLectura" style="display: none;">
                    <i class="fa-solid fa-forward-step me-1"></i> Saltar Lectura (Sin Datos / Fuera Servicio)
                </button>
            </div>

            <!-- Inputs de Odómetros -->
            <div class="row g-3 mb-4 mt-2">
                
                <!-- 1. Odómetro Monocromático (Negro) -->
                <div class="col-md-6 mb-3">
                    <label class="form-label text-white-50 small fw-bold">Contador Monocromático (Negro)</label>
                    <div class="input-group shadow-sm">
                        <span class="input-group-text bg-secondary border-secondary text-white fw-bold" style="background-color: #242b35 !important; border-color: #4a5568 !important; min-width: 140px;">
                            Anterior: <span id="lbl_anterior_mono" class="ms-1 font-monospace">0</span>
                        </span>
                        <input type="number" class="form-control bg-dark border-secondary text-white fw-bold text-warning" id="contador_actual" name="contador_actual" placeholder="Ingrese nuevo contador negro..." required>
                    </div>
                    <input type="hidden" id="contador_anterior" name="contador_anterior" value="0">
                </div>

                <!-- 2. Odómetro Color -->
                <div class="col-md-6 mb-3" id="grupo_color_container">
                    <label class="form-label text-white-50 small fw-bold">Contador Color (Full Color)</label>
                    <div class="input-group shadow-sm">
                        <span class="input-group-text bg-secondary border-secondary text-white fw-bold" style="background-color: #242b35 !important; border-color: #4a5568 !important; min-width: 140px;">
                            Anterior: <span id="lbl_anterior_color" class="ms-1 font-monospace">0</span>
                        </span>
                        <input type="number" class="form-control bg-dark border-secondary text-white fw-bold text-info" id="contador_actual_color" name="contador_actual_color" placeholder="Ingrese nuevo contador color..." required>
                    </div>
                    <input type="hidden" id="contador_anterior_color" name="contador_anterior_color" value="0">
                </div>

                <!-- Fecha de la Nueva Toma -->
                <div class="col-md-4">
                    <label class="form-label text-white-50 small fw-bold">Fecha de la Nueva Toma</label>
                    <input type="date" class="form-control bg-dark border-secondary text-white text-warning fw-bold" name="fecha" value="<?= date('Y-m-d') ?>" required>
                </div>

                <!-- Mes del Período -->
                <div class="col-md-4">
                    <label class="form-label text-white-50 small fw-bold">Mes del Período</label>
                    <select name="periodo_mes" id="periodo_mes" class="form-select bg-dark border-secondary text-white" required>
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $m === (int)date('m') ? 'selected' : '' ?>>
                                <?= date('F', mktime(0, 0, 0, $m, 1)) ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <!-- Año del Período -->
                <div class="col-md-4">
                    <label class="form-label text-white-50 small fw-bold">Año del Período</label>
                    <select name="periodo_anio" id="periodo_anio" class="form-select bg-dark border-secondary text-white" required>
                        <?php for ($y = (int)date('Y') - 1; $y <= (int)date('Y') + 1; $y++): ?>
                            <option value="<?= $y ?>" <?= $y === (int)date('Y') ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <!-- OBSERVACIONES DE LA LECTURA -->
                <div class="col-12 mt-3">
                    <label class="form-label text-white-50 small fw-bold text-uppercase">Notas / Observaciones de la lectura</label>
                    <textarea class="form-control bg-dark border-secondary text-white" id="observaciones" name="observaciones" rows="3" placeholder="Escriba aquí los detalles del salto, visitas fallidas, equipo en reparación o estados especiales de la máquina..."></textarea>
                </div>
            </div>

            <!-- Botones de Acción -->
            <div class="text-end border-top border-secondary pt-3 mt-4">
                <a href="/contadores" class="btn btn-outline-secondary btn-sm px-3 me-2">Cancelar</a>
                <button type="submit" class="btn btn-success btn-sm px-4">
                    <i class="fa-solid fa-save me-1"></i> Guardar Lectura
                </button>
            </div>

        </form>
    </div>

</div>

<!-- =====================================================
     SCRIPT: CASCADAS, AUTOCOMPLETADO ROBUSTO Y MULTI-EQUIPOS
     ===================================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const localidad = document.querySelector('#localidad_id');
    const cliente = document.querySelector('#cliente_id');
    const equipo = document.querySelector('#equipo_id');
    
    const lblAntMono = document.querySelector('#lbl_anterior_mono');
    const valAntMono = document.querySelector('#contador_anterior');
    const actMono    = document.querySelector('#contador_actual');

    const lblAntColor = document.querySelector('#lbl_anterior_color');
    const valAntColor = document.querySelector('#contador_anterior_color');
    const actColor    = document.querySelector('#contador_actual_color');

    const panelPendientes = document.querySelector('#alert_equipos_pendientes');
    const lblCantEquipos = document.querySelector('#lbl_cant_equipos');
    const listaEquipos = document.querySelector('#lista_equipos_cliente');
    const btnSaltar = document.querySelector('#btnSaltarLectura');
    const txtObservaciones = document.querySelector('#observaciones');

    if (!localidad) return;

    // 1. Carga Clientes por Localidad
    localidad.addEventListener('change', async () => {
        cliente.innerHTML = '<option value="">Cargando clientes...</option>';
        equipo.innerHTML = '<option value="">Seleccione equipo</option>';
        resetContadores();

        try {
            const r = await fetch('/contadores/api/clientes?localidad_id=' + localidad.value);
            const json = await r.json();
            const data = Array.isArray(json.data) ? json.data : (json.clientes ?? []);

            cliente.innerHTML = '<option value="">Seleccione cliente</option>';
            data.forEach(c => {
                const cNombre = c.nombre || c.razon_social || 'Cliente';
                cliente.innerHTML += `<option value="${c.id}">${cNombre}</option>`;
            });
        } catch (e) {
            console.error('Error al cargar clientes:', e);
            cliente.innerHTML = '<option value="">Error al cargar clientes</option>';
        }
    });

    // 2. Carga Equipos por Cliente
    cliente.addEventListener('change', async () => {
        if (!cliente.value) {
            equipo.innerHTML = '<option value="">Seleccione equipo</option>';
            resetContadores();
            return;
        }

        equipo.innerHTML = '<option>Cargando equipos...</option>';
        resetContadores();

        try {
            const r = await fetch('/contadores/api/equipos?cliente_id=' + cliente.value);
            const json = await r.json();
            const data = Array.isArray(json.data) ? json.data : (json.data?.equipos ?? json.equipos ?? []);

            equipo.innerHTML = '<option value="">Seleccione equipo</option>';
            listaEquipos.innerHTML = '';

            if (data.length >= 2) {
                lblCantEquipos.textContent = data.length;
                panelPendientes.classList.remove('d-none');
                
                data.forEach(eq => {
                    const modelo = eq.modelo_nombre || eq.modelo || 'Multifuncional';
                    const serie = eq.serie ?? 'S/S';
                    listaEquipos.innerHTML += `<li class="mb-1"><i class="fa-solid fa-print me-1 text-secondary"></i> ${modelo} (Serie: ${serie}) - <span class="badge bg-secondary">Pendiente de Carga</span></li>`;
                });
            } else {
                panelPendientes.classList.add('d-none');
            }

            data.forEach(eq => {
                const modelo = eq.modelo_nombre || eq.modelo || 'Multifuncional';
                const codigo = eq.codigo_interno ?? 'S/C';
                const serie = eq.serie ?? 'S/S';
                
                equipo.innerHTML += `
                <option value="${eq.id}">
                    [${codigo}] - ${modelo} (Serie: ${serie})
                </option>`;
            });
        } catch (e) {
            console.error('Error al cargar equipos:', e);
            equipo.innerHTML = '<option>Error al cargar equipos</option>';
        }
    });

    // 3. Al seleccionar Equipo -> Carga de Contadores Anteriores Extracción Blindada
    equipo.addEventListener('change', async () => {
        if (!equipo.value) {
            resetContadores();
            return;
        }

        if (lblAntMono) lblAntMono.textContent = '...';
        if (lblAntColor) lblAntColor.textContent = '...';

        try {
            const r = await fetch('/contadores/api/ultimo-contador?equipo_id=' + equipo.value);
            const json = await r.json();
            const d = json.data || {};

            // Extracción multivariable blindada
            const esMonocromatico = d.es_monocromatico === true;
            const mono = parseInt(d.contador_anterior ?? d.mono ?? d.contador_actual ?? d.registro?.contador_actual ?? 0) || 0;
            const color = parseInt(d.contador_anterior_color ?? d.color ?? d.contador_actual_color ?? d.registro?.contador_actual_color ?? 0) || 0;

            if (btnSaltar) btnSaltar.style.display = 'inline-block';

            // Asignación en vista
            if (lblAntMono) lblAntMono.textContent = mono.toLocaleString('es-AR');
            if (valAntMono) valAntMono.value = mono;
            if (actMono) actMono.value = mono;

            if (esMonocromatico) {
                if (lblAntColor) lblAntColor.textContent = 'DESACTIVADO';
                if (valAntColor) valAntColor.value = '0';
                if (actColor) {
                    actColor.value = '0';
                    actColor.setAttribute('disabled', 'true');
                    actColor.removeAttribute('required');
                    actColor.style.backgroundColor = '#1a1d24';
                }
            } else {
                if (lblAntColor) lblAntColor.textContent = color.toLocaleString('es-AR');
                if (valAntColor) valAntColor.value = color;
                if (actColor) {
                    actColor.value = color;
                    actColor.removeAttribute('disabled');
                    actColor.setAttribute('required', 'true');
                    actColor.style.backgroundColor = '';
                }
            }
        } catch (e) {
            console.error('Error al cargar el último contador:', e);
            resetContadores();
        }
    });

    // 4. Saltar Lectura
    if (btnSaltar) {
        btnSaltar.addEventListener('click', () => {
            if (confirm('¿Desea omitir el contador de este equipo? El sistema igualará los contadores actuales a los anteriores para registrar 0 copias en el abono.')) {
                if (actMono && valAntMono) actMono.value = valAntMono.value;
                if (actColor && valAntColor) actColor.value = valAntColor.value;

                if (txtObservaciones) {
                    txtObservaciones.value = 'LECTURA OMITIDA / SALTADA: El equipo se encuentra fuera de servicio en el cliente o no se suministraron los datos a tiempo.';
                }

                if (actMono) actMono.removeAttribute('required');
                if (actColor) actColor.removeAttribute('required');

                btnSaltar.style.display = 'none';
            }
        });
    }

    function resetContadores() {
        if (lblAntMono) lblAntMono.textContent = '0';
        if (valAntMono) valAntMono.value = '0';
        if (actMono) {
            actMono.value = '';
            actMono.setAttribute('required', 'true');
        }

        if (lblAntColor) lblAntColor.textContent = '0';
        if (valAntColor) valAntColor.value = '0';
        if (actColor) {
            actColor.value = '';
            actColor.removeAttribute('disabled');
            actColor.setAttribute('required', 'true');
            actColor.style.backgroundColor = '';
        }

        if (btnSaltar) btnSaltar.style.display = 'none';
        if (txtObservaciones) txtObservaciones.value = '';
        if (panelPendientes) panelPendientes.classList.add('d-none');
    }
});
</script>