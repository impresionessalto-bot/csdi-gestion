<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP - Counter Dashboard (Consola Completa con Smart Search y Menú CRUD)
|--------------------------------------------------------------------------
*/

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        if (is_array($value)) {
            return htmlspecialchars(
                implode(', ', array_filter($value, 'is_scalar')),
                ENT_QUOTES,
                'UTF-8'
            );
        }

        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Inicialización defensiva de variables
$items       = is_array($items ?? null) ? $items : [];
$filtros     = is_array($filtros ?? null) ? $filtros : [];
$kpis        = is_array($kpis ?? null) ? $kpis : [];
$localidades = $filtros['localidades'] ?? [];
$csrfToken   = (string)($csrf ?? '');
?>

<div class="container-fluid py-4">

    <!-- Token CSRF oculto para uso de JavaScript/AJAX -->
    <input type="hidden" id="csrf_token_global" value="<?= e($csrfToken) ?>">

    <!-- =====================================================
         1) CABECERA DE LA SECCIÓN
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">
        <div class="d-flex align-items-center">
            <div class="bg-primary text-white rounded-3 p-3 me-3 shadow-sm">
                <i class="fa-solid fa-gauge-high fs-3"></i>
            </div>
            <div>
                <h2 class="fw-bold text-white mb-1 d-flex align-items-center">
                    Contadores CSDI
                </h2>
                <span class="text-white-50 small fw-semibold">Consola de control de lecturas y consumos de equipos</span>
            </div>
        </div>
        
        <!-- Botones de Acción de la Ficha -->
        <div class="d-flex gap-2">
            <!-- Alta de Lectura -->
            <a href="/contadores/nuevo" class="btn btn-primary btn-sm px-3 fw-semibold">
                <i class="fa-solid fa-plus me-1"></i> Nueva Lectura
            </a>
            
            <!-- Disparador de WhatsApp Masivo -->
            <form action="/contadores/recordatorios" method="POST" class="d-inline" onsubmit="return confirm('¿Seguro que desea enviar recordatorios de WhatsApp de forma masiva a todos los clientes con lecturas pendientes del mes actual?');">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                <button type="submit" class="btn btn-success btn-sm px-3 fw-semibold">
                    <i class="fa-brands fa-whatsapp me-1"></i> Recordatorios WhatsApp
                </button>
            </form>

            <!-- Exportador que abre el Modal de Filtros -->
            <button type="button" class="btn btn-danger btn-sm px-3 fw-semibold" data-bs-toggle="modal" data-bs-target="#modalExportarContadores">
                <i class="fa-solid fa-file-export me-1"></i> Exportar Reporte
            </button>
        </div>
    </div>

    <!-- =====================================================
         2) TIRA DE KPIS / METRICAS RÁPIDAS
         ===================================================== -->
    <div class="row g-3 mb-4">
        <?php
        $cards = [
            ['titulo' => 'Equipos CSDI', 'valor' => $kpis['equipos'] ?? 0, 'icon' => 'fa-print', 'color' => 'primary'],
            ['titulo' => 'Lecturas', 'valor' => $kpis['lecturas'] ?? 0, 'icon' => 'fa-list', 'color' => 'success'],
            ['titulo' => 'Pendientes', 'valor' => $kpis['pendientes'] ?? 0, 'icon' => 'fa-clock', 'color' => 'warning'],
            ['titulo' => 'Consumo Mes', 'valor' => $kpis['consumo'] ?? 0, 'icon' => 'fa-copy', 'color' => 'danger']
        ];

        foreach ($cards as $card):
        ?>
            <div class="col-md-3 col-sm-6">
                <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-<?= $card['color'] ?>) !important;">
                    <div class="card-body p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted small text-uppercase fw-semibold d-block mb-1"><?= e($card['titulo']) ?></span>
                            <strong class="fs-4 text-dark">
                                <?= number_format((int)$card['valor'], 0, ',', '.') ?>
                            </strong>
                        </div>
                        <div class="text-<?= $card['color'] ?> p-2">
                            <i class="fa-solid <?= e($card['icon']) ?> fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Pestañas de Navegación -->
    <ul class="nav nav-tabs mb-4 border-secondary" id="counter360Tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active text-white fw-bold border-secondary bg-transparent px-3 py-2" id="lecturas-tab" data-bs-toggle="tab" data-bs-target="#lecturas-pane" type="button" role="tab" aria-controls="lecturas-pane" aria-selected="true" style="border-bottom-color: #1a1a1a !important;">
                <i class="fa-solid fa-list-check text-primary me-2"></i> Últimas Lecturas
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2 fw-semibold" id="historial-tab" data-bs-toggle="tab" data-bs-target="#historial-pane" type="button" role="tab" aria-controls="historial-pane" aria-selected="false">
                <i class="fa-solid fa-chart-line text-success me-2"></i> Historial de Consumos
            </button>
        </li>
    </ul>

    <!-- Contenido de las Pestañas -->
    <div class="tab-content" id="counter360TabContent">

        <!-- PESTAÑA A: ÚLTIMAS LECTURAS -->
        <div class="tab-pane fade show active" id="lecturas-pane" role="tabpanel" aria-labelledby="lecturas-tab" tabindex="0">
            
            <!-- =====================================================
                 3) SMART SEARCH (Buscador en tiempo real)
                 ===================================================== -->
            <div class="row mb-3">
                <div class="col-12 col-md-5 ms-auto">
                    <div class="input-group shadow-sm">
                        <span class="input-group-text bg-white border-end-0 text-muted">
                            <i class="fa-solid fa-magnifying-glass text-secondary"></i>
                        </span>
                        <input type="text" id="smartSearchCounter" class="form-control border-start-0 ps-0 fw-semibold csdi-smart-search" data-target-table="tablaEstructuraDb" placeholder="Buscar por cliente, modelo, serie, periodo o ID...">
                    </div>
                </div>
            </div>

            <!-- Tabla de Listado principal -->
            <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tablaEstructuraDb">
                        <thead class="table-dark">
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Cliente</th>
                                <th>Equipo</th>
                                <th>Mono</th>
                                <th>Color</th>
                                <th>Periodo</th>
                                <th class="text-end pe-4" width="180">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($items)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-5">Sin registros de lectura de contadores.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($items as $row): ?>
                                    <?php
                                    $rowId     = (int)($row['id'] ?? 0);
                                    $rowEq     = (int)($row['equipo_id'] ?? 0);
                                    $rowModelo = (string)($row['modelo_nombre'] ?? $row['modelo'] ?? 'Multifuncional');
                                    $rowSerie  = (string)($row['serie'] ?? '');
                                    ?>
                                    <tr class="fila-tabla">
                                        <td class="ps-4 fw-bold">#<?= $rowId ?></td>
                                        <td>
                                            <strong class="text-dark">
                                                <?= e($row['cliente_nombre'] ?? $row['cliente'] ?? 'Sin cliente') ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <span class="fw-semibold text-dark">
                                                    <?= e($row['codigo_interno'] ?? $row['equipo'] ?? '') ?> - <?= e($rowModelo) ?>
                                                </span>
                                                <small class="text-muted">Serie: <?= e($rowSerie) ?></small>
                                            </div>
                                        </td>
                                        <td class="font-monospace fw-bold text-primary"><?= number_format((int)($row['copias'] ?? 0), 0, ',', '.') ?></td>
                                        <td class="font-monospace fw-bold text-info"><?= number_format((int)($row['copias_color'] ?? 0), 0, ',', '.') ?></td>
                                        <td class="font-monospace text-secondary">
                                            <?= sprintf('%02d/%04d', (int)($row['periodo_mes'] ?? 0), (int)($row['periodo_anio'] ?? 0)) ?>
                                        </td>
                                        
                                        <!-- MENÚ CRUD INTEGRADO EN LA FILA -->
                                        <td class="text-end pe-4">
                                            <div class="btn-group btn-group-sm">
                                                <a href="/contadores/historial/<?= $rowEq ?>" class="btn btn-outline-info px-2" title="Historial del Equipo">
                                                    <i class="fa-solid fa-clock"></i>
                                                </a>
                                                <a href="/contadores/ver/<?= $rowId ?>" class="btn btn-primary px-2" title="Ver Detalle">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a href="/contadores/editar/<?= $rowId ?>" class="btn btn-warning px-2" title="Editar">
                                                    <i class="fa-solid fa-pen text-dark"></i>
                                                </a>
                                                <button type="button" class="btn btn-danger btnEliminarLectura px-2" data-id="<?= $rowId ?>" title="Eliminar">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- PESTAÑA B: HISTORIAL DE CONSUMOS -->
        <div class="tab-pane fade" id="historial-pane" role="tabpanel" aria-labelledby="historial-tab" tabindex="0">
            <div class="card p-4 border-0 shadow-sm rounded-3">
                <h5 class="fw-bold mb-3"><i class="fa-solid fa-chart-line text-success me-2"></i> Análisis de Consumos del Periodo</h5>
                <p class="text-muted mb-0">Esta sección se encuentra lista para alojar gráficos de barras y tendencias acumulativas de copias de los equipos.</p>
            </div>
        </div>

    </div>
</div>

<!-- =====================================================
     4) MODAL DE EXPORTACIÓN INTELIGENTE
     ===================================================== -->
<div class="modal fade" id="modalExportarContadores" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 12px; overflow: hidden;">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-file-export me-2"></i> Exportar Reporte de Lecturas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 bg-white">
                <form id="formExportar" method="GET" action="/contadores/exportar-excel">
                    
                    <!-- Rango de Fechas -->
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label text-dark fw-semibold small">Desde:</label>
                            <input type="date" class="form-control" name="fecha_desde" id="exp_fecha_desde">
                        </div>
                        <div class="col-6">
                            <label class="form-label text-dark fw-semibold small">Hasta:</label>
                            <input type="date" class="form-control" name="fecha_hasta" id="exp_fecha_hasta">
                        </div>
                    </div>

                    <!-- Filtro por Localidad -->
                    <div class="mb-3">
                        <label class="form-label text-dark fw-semibold small">Separar por Localidad:</label>
                        <select id="exp_localidad_id" name="localidad_id" class="form-select">
                            <option value="">Todas las localidades</option>
                            <?php foreach ($localidades as $l): ?>
                                <option value="<?= e(is_array($l) ? ($l['id'] ?? '') : $l) ?>">
                                    <?= e(is_array($l) ? ($l['nombre'] ?? '') : $l) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Filtro por Cliente (Cascada AJAX) -->
                    <div class="mb-3">
                        <label class="form-label text-dark fw-semibold small">Filtrar por Cliente:</label>
                        <select id="exp_cliente_id" name="cliente_id" class="form-select">
                            <option value="">Todos los clientes</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light d-flex justify-content-between">
                <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-success btn-sm fw-semibold" id="btnDescargarExcel">
                        <i class="fa-solid fa-file-excel me-1"></i> Excel
                    </button>
                    <button type="button" class="btn btn-danger btn-sm fw-semibold" id="btnDescargarPdf">
                        <i class="fa-solid fa-file-pdf me-1"></i> PDF
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- =====================================================
     5) SCRIPTS DE INTERACCIÓN Y AJAX CON SEGURIDAD CSRF
     ===================================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {

    const csrfToken = document.getElementById('csrf_token_global')?.value || '';

    // --- ELIMINAR LECTURA MEDIANTE AJAX CON TOKEN CSRF ---
    const botonesEliminar = document.querySelectorAll('.btnEliminarLectura');
    botonesEliminar.forEach(btn => {
        btn.addEventListener('click', async function() {
            const id = this.getAttribute('data-id');
            if (confirm(`¿Seguro que desea eliminar el registro de lectura #${id}? Se recalcularán los consumos automáticamente.`)) {
                try {
                    const formData = new FormData();
                    formData.append('csrf_token', csrfToken);

                    const r = await fetch(`/contadores/eliminar/${id}`, {
                        method: 'POST',
                        body: formData
                    });

                    if (r.ok) {
                        window.location.reload();
                    } else {
                        alert('Ocurrió un error al intentar eliminar la lectura.');
                    }
                } catch (e) {
                    console.error(e);
                    alert('Error técnico de conexión al eliminar el registro.');
                }
            }
        });
    });

    // --- CASCADA MODAL EXPORTADOR ---
    const expLocalidad = document.querySelector('#exp_localidad_id');
    const expCliente = document.querySelector('#exp_cliente_id');
    const formExportar = document.querySelector('#formExportar');
    const btnExcel = document.querySelector('#btnDescargarExcel');
    const btnPdf = document.querySelector('#btnDescargarPdf');

    if (expLocalidad) {
        expLocalidad.addEventListener('change', async () => {
            if (!expLocalidad.value) {
                expCliente.innerHTML = '<option value="">Todos los clientes</option>';
                return;
            }
            expCliente.innerHTML = '<option>Cargando...</option>';

            try {
                const r = await fetch('/contadores/api/clientes?localidad_id=' + expLocalidad.value);
                const json = await r.json();
                const data = Array.isArray(json.data) ? json.data : (json.clientes ?? []);

                expCliente.innerHTML = '<option value="">Todos los clientes</option>';
                data.forEach(c => {
                    const cId = typeof c === 'object' ? (c.id || '') : c;
                    const cNombre = typeof c === 'object' ? (c.nombre || c.razon_social || '') : c;
                    expCliente.innerHTML += `<option value="${cId}">${cNombre}</option>`;
                });
            } catch (e) {
                console.error(e);
                expCliente.innerHTML = '<option value="">Error al cargar clientes</option>';
            }
        });
    }

    if (btnExcel && formExportar) {
        btnExcel.addEventListener('click', () => {
            formExportar.setAttribute('action', '/contadores/exportar-excel');
            formExportar.submit();
        });
    }

    if (btnPdf && formExportar) {
        btnPdf.addEventListener('click', () => {
            formExportar.setAttribute('action', '/contadores/exportar-pdf');
            formExportar.submit();
        });
    }
});
</script>