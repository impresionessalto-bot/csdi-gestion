<?php

declare(strict_types=1);

/**
 * Variables esperadas:
 *
 * $equiposDisponibles
 * $clientes
 * $localidades
 *
 * Opcional:
 * $equipoSaliente
 * $equipoEntrante
 */

$equiposDisponibles = $equiposDisponibles ?? [];
$clientes = $clientes ?? [];
$localidades = $localidades ?? [];

$equipoSaliente = $equipoSaliente ?? null;
$equipoEntrante = $equipoEntrante ?? null;

$csrf = $csrf ?? ($_SESSION['csrf_token'] ?? '');

function e(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}
?>

<div class="container-fluid py-4">

    <!-- HEADER -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="badge bg-primary-subtle text-primary">
                    CONTADORES
                </span>

                <span class="text-muted small">
                    Gesti�n transversal de equipos
                </span>
            </div>

            <h1 class="h3 fw-bold mb-1">
                Swap de equipos
            </h1>

            <p class="text-muted mb-0">
                Reemplaz� un equipo manteniendo la continuidad contractual
                e hist�rica de las lecturas.
            </p>
        </div>

        <div class="mt-3 mt-md-0">
            <a
                href="/contadores"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Volver a contadores
            </a>
        </div>

    </div>


    <!-- ALERTA -->
    <div
        id="swapAlert"
        class="alert d-none"
        role="alert"
    ></div>


    <!-- FLUJO -->
    <div class="row g-4">

        <!-- EQUIPO SALIENTE -->
        <div class="col-xl-5">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-header bg-white border-0 pt-4 px-4">

                    <div class="d-flex align-items-center">

                        <div
                            class="rounded-circle bg-danger-subtle text-danger
                                   d-flex align-items-center justify-content-center
                                   me-3"
                            style="width:42px;height:42px;"
                        >
                            <i class="bi bi-box-arrow-right fs-5"></i>
                        </div>

                        <div>
                            <h5 class="mb-0 fw-bold">
                                Equipo saliente
                            </h5>

                            <small class="text-muted">
                                Equipo actualmente instalado
                            </small>
                        </div>

                    </div>

                </div>


                <div class="card-body px-4">

                    <div class="mb-3">

                        <label
                            for="equipoSaliente"
                            class="form-label fw-semibold"
                        >
                            Equipo
                        </label>

                        <select
                            id="equipoSaliente"
                            name="saliente_id"
                            class="form-select form-select-lg"
                        >

                            <option value="">
                                Seleccionar equipo...
                            </option>

                            <?php if ($equipoSaliente): ?>

                                <option
                                    value="<?= e($equipoSaliente['id']) ?>"
                                    selected
                                >
                                    <?= e($equipoSaliente['codigo_interno'] ?? '') ?>
                                    -
                                    <?= e($equipoSaliente['serie'] ?? '') ?>
                                </option>

                            <?php endif; ?>

                        </select>

                    </div>


                    <!-- FICHA -->
                    <div
                        id="salienteFicha"
                        class="d-none"
                    >

                        <div class="border rounded-3 p-3 bg-light">

                            <div class="row g-3">

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        C�digo
                                    </small>

                                    <strong id="salienteCodigo">
                                        -
                                    </strong>
                                </div>

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        Serie
                                    </small>

                                    <strong id="salienteSerie">
                                        -
                                    </strong>
                                </div>

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        Modelo
                                    </small>

                                    <strong id="salienteModelo">
                                        -
                                    </strong>
                                </div>

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        Tipo
                                    </small>

                                    <span
                                        id="salienteTipo"
                                        class="badge"
                                    >
                                        -
                                    </span>
                                </div>

                                <div class="col-12">
                                    <small class="text-muted d-block">
                                        Cliente
                                    </small>

                                    <strong id="salienteCliente">
                                        -
                                    </strong>
                                </div>

                                <div class="col-12">
                                    <small class="text-muted d-block">
                                        Localidad
                                    </small>

                                    <strong id="salienteLocalidad">
                                        -
                                    </strong>
                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- CONTADORES -->
                    <div
                        id="salienteContadores"
                        class="d-none mt-4"
                    >

                        <h6 class="fw-bold mb-3">
                            Lectura de cierre
                        </h6>

                        <div class="row g-3">

                            <div class="col-md-6">

                                <label class="form-label">
                                    Contador anterior
                                </label>

                                <input
                                    type="number"
                                    min="0"
                                    id="salienteAnterior"
                                    name="saliente_anterior"
                                    class="form-control"
                                    readonly
                                >

                                <small class="text-muted">
                                    Se obtiene del �ltimo registro f�sico.
                                </small>

                            </div>

                            <div class="col-md-6">

                                <label class="form-label">
                                    Contador actual
                                </label>

                                <input
                                    type="number"
                                    min="0"
                                    id="salienteActual"
                                    name="saliente_actual"
                                    class="form-control"
                                >

                            </div>


                            <div
                                id="salienteColorBox"
                                class="row g-3 d-none"
                            >

                                <div class="col-md-6">

                                    <label class="form-label">
                                        Color anterior
                                    </label>

                                    <input
                                        type="number"
                                        min="0"
                                        id="salienteAnteriorColor"
                                        name="saliente_anterior_color"
                                        class="form-control"
                                        readonly
                                    >

                                </div>

                                <div class="col-md-6">

                                    <label class="form-label">
                                        Color actual
                                    </label>

                                    <input
                                        type="number"
                                        min="0"
                                        id="salienteActualColor"
                                        name="saliente_actual_color"
                                        class="form-control"
                                    >

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- FLECHA -->
        <div
            class="col-xl-2 d-none d-xl-flex
                   align-items-center justify-content-center"
        >

            <div class="text-center">

                <div
                    class="rounded-circle bg-primary-subtle text-primary
                           d-flex align-items-center justify-content-center mx-auto mb-2"
                    style="width:58px;height:58px;"
                >
                    <i class="bi bi-arrow-left-right fs-4"></i>
                </div>

                <div class="small fw-semibold">
                    SWAP
                </div>

                <div class="small text-muted">
                    Cambio f�sico
                </div>

            </div>

        </div>


        <!-- EQUIPO ENTRANTE -->
        <div class="col-xl-5">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-header bg-white border-0 pt-4 px-4">

                    <div class="d-flex align-items-center">

                        <div
                            class="rounded-circle bg-success-subtle text-success
                                   d-flex align-items-center justify-content-center
                                   me-3"
                            style="width:42px;height:42px;"
                        >
                            <i class="bi bi-box-arrow-in-left fs-5"></i>
                        </div>

                        <div>
                            <h5 class="mb-0 fw-bold">
                                Equipo entrante
                            </h5>

                            <small class="text-muted">
                                Equipo que ocupar� la instalaci�n
                            </small>
                        </div>

                    </div>

                </div>


                <div class="card-body px-4">

                    <div class="mb-3">

                        <label
                            for="equipoEntrante"
                            class="form-label fw-semibold"
                        >
                            Equipo disponible
                        </label>

                        <select
                            id="equipoEntrante"
                            name="entrante_id"
                            class="form-select form-select-lg"
                        >

                            <option value="">
                                Seleccionar equipo...
                            </option>

                            <?php foreach ($equiposDisponibles as $equipo): ?>

                                <option
                                    value="<?= e($equipo['id']) ?>"
                                    <?= (
                                        $equipoEntrante
                                        && (int)$equipoEntrante['id'] === (int)$equipo['id']
                                    ) ? 'selected' : '' ?>
                                >
                                    <?= e($equipo['codigo_interno'] ?? '') ?>
                                    -
                                    <?= e($equipo['serie'] ?? '') ?>
                                    -
                                    <?= e($equipo['nombre_modelo'] ?? '') ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- FICHA -->
                    <div
                        id="entranteFicha"
                        class="d-none"
                    >

                        <div class="border rounded-3 p-3 bg-light">

                            <div class="row g-3">

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        C�digo
                                    </small>

                                    <strong id="entranteCodigo">
                                        -
                                    </strong>
                                </div>

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        Serie
                                    </small>

                                    <strong id="entranteSerie">
                                        -
                                    </strong>
                                </div>

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        Modelo
                                    </small>

                                    <strong id="entranteModelo">
                                        -
                                    </strong>
                                </div>

                                <div class="col-6">
                                    <small class="text-muted d-block">
                                        Tipo
                                    </small>

                                    <span
                                        id="entranteTipo"
                                        class="badge"
                                    >
                                        -
                                    </span>
                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- CONTADOR INICIAL -->
                    <div
                        id="entranteContadores"
                        class="d-none mt-4"
                    >

                        <h6 class="fw-bold mb-3">
                            Lectura inicial
                        </h6>

                        <div class="row g-3">

                            <div class="col-md-6">

                                <label class="form-label">
                                    Contador inicial
                                </label>

                                <input
                                    type="number"
                                    min="0"
                                    id="entranteInicial"
                                    name="entrante_inicial"
                                    class="form-control"
                                >

                                <small class="text-muted">
                                    Lectura f�sica del nuevo equipo.
                                </small>

                            </div>


                            <div
                                id="entranteColorBox"
                                class="col-md-6 d-none"
                            >

                                <label class="form-label">
                                    Contador color inicial
                                </label>

                                <input
                                    type="number"
                                    min="0"
                                    id="entranteInicialColor"
                                    name="entrante_inicial_color"
                                    class="form-control"
                                >

                            </div>

                        </div>

                        <div class="alert alert-info mt-3 mb-0 small">

                            <i class="bi bi-info-circle me-1"></i>

                            El equipo entrante conserva su propio contador.
                            No se transfiere el contador del equipo saliente.

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- DATOS DEL SWAP -->
    <div class="card border-0 shadow-sm mt-4">

        <div class="card-header bg-white border-0 pt-4 px-4">

            <h5 class="fw-bold mb-1">
                Datos del intercambio
            </h5>

            <p class="text-muted small mb-0">
                Estos datos quedar�n registrados en el historial transversal.
            </p>

        </div>


        <div class="card-body px-4">

            <div class="row g-3">

                <div class="col-md-4">

                    <label
                        for="fechaSwap"
                        class="form-label fw-semibold"
                    >
                        Fecha del cambio
                    </label>

                    <input
                        type="date"
                        id="fechaSwap"
                        name="fecha"
                        class="form-control"
                        value="<?= e(date('Y-m-d')) ?>"
                    >

                </div>


                <div class="col-md-4">

                    <label
                        for="localidadSwap"
                        class="form-label fw-semibold"
                    >
                        Localidad
                    </label>

                    <select
                        id="localidadSwap"
                        name="localidad_id"
                        class="form-select"
                    >

                        <option value="">
                            Seleccionar localidad...
                        </option>

                        <?php foreach ($localidades as $localidad): ?>

                            <option
                                value="<?= e($localidad['id']) ?>"
                                <?= (
                                    $equipoSaliente
                                    && isset($equipoSaliente['localidad_id'])
                                    && (int)$equipoSaliente['localidad_id'] === (int)$localidad['id']
                                ) ? 'selected' : '' ?>
                            >
                                <?= e($localidad['nombre'] ?? '') ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="col-md-4">

                    <label
                        for="motivoSwap"
                        class="form-label fw-semibold"
                    >
                        Motivo
                    </label>

                    <input
                        type="text"
                        id="motivoSwap"
                        name="motivo"
                        class="form-control"
                        maxlength="255"
                        placeholder="Ej.: falla t�cnica, renovaci�n..."
                    >

                </div>

            </div>

        </div>

    </div>


    <!-- RESUMEN -->
    <div
        id="swapResumen"
        class="card border-0 shadow-sm mt-4 d-none"
    >

        <div class="card-header bg-white border-0 pt-4 px-4">

            <h5 class="fw-bold mb-0">
                Resumen del Swap
            </h5>

        </div>

        <div class="card-body px-4">

            <div class="row align-items-center">

                <div class="col-md-5">

                    <div class="border rounded-3 p-3">

                        <small class="text-muted">
                            SALE
                        </small>

                        <h6
                            id="resumenSaliente"
                            class="fw-bold mb-0 mt-1"
                        >
                            -
                        </h6>

                    </div>

                </div>


                <div class="col-md-2 text-center py-3">

                    <i class="bi bi-arrow-right fs-3 text-primary"></i>

                </div>


                <div class="col-md-5">

                    <div class="border rounded-3 p-3">

                        <small class="text-muted">
                            INGRESA
                        </small>

                        <h6
                            id="resumenEntrante"
                            class="fw-bold mb-0 mt-1"
                        >
                            -
                        </h6>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ACCIONES -->
    <div class="d-flex justify-content-end gap-2 mt-4">

        <a
            href="/contadores"
            class="btn btn-outline-secondary"
        >
            Cancelar
        </a>

        <button
            type="button"
            id="btnEjecutarSwap"
            class="btn btn-primary px-4"
            disabled
        >
            <i class="bi bi-arrow-left-right me-1"></i>
            Ejecutar Swap
        </button>

    </div>

</div>


<script>
(() => {

    'use strict';

    const csrf = <?= json_encode($csrf) ?>;

    const salienteSelect =
        document.getElementById('equipoSaliente');

    const entranteSelect =
        document.getElementById('equipoEntrante');

    const btnSwap =
        document.getElementById('btnEjecutarSwap');

    const alertBox =
        document.getElementById('swapAlert');


    let salienteData = null;
    let entranteData = null;


    function mostrarAlerta(mensaje, tipo = 'danger') {

        alertBox.className =
            `alert alert-${tipo}`;

        alertBox.textContent = mensaje;

        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }


    function limpiarAlerta() {

        alertBox.className =
            'alert d-none';

        alertBox.textContent = '';
    }


    async function cargarEquipo(id) {

        if (!id) {
            return null;
        }

        const response = await fetch(
            `/contadores/equipos/${encodeURIComponent(id)}`,
            {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }
        );

        if (!response.ok) {
            throw new Error(
                'No se pudo obtener la informaci�n del equipo.'
            );
        }

        return await response.json();
    }


    function actualizarTipo(elemento, tipo) {

        elemento.textContent = tipo || '-';

        elemento.className =
            'badge ' +
            (
                tipo === 'Color'
                    ? 'bg-primary'
                    : 'bg-secondary'
            );
    }


    function mostrarSaliente(data) {

        salienteData = data;

        document
            .getElementById('salienteFicha')
            .classList.remove('d-none');

        document
            .getElementById('salienteContadores')
            .classList.remove('d-none');


        document.getElementById('salienteCodigo')
            .textContent = data.codigo_interno || '-';

        document.getElementById('salienteSerie')
            .textContent = data.serie || '-';

        document.getElementById('salienteModelo')
            .textContent = data.nombre_modelo || '-';

        actualizarTipo(
            document.getElementById('salienteTipo'),
            data.tipo_equipo || data.tipo || '-'
        );

        document.getElementById('salienteCliente')
            .textContent =
            data.cliente_nombre || '-';

        document.getElementById('salienteLocalidad')
            .textContent =
            data.localidad_nombre || '-';


        const ultimo =
            data.ultimo_contador || null;


        document.getElementById('salienteAnterior')
            .value =
            ultimo
                ? (ultimo.contador_actual || 0)
                : 0;


        const esColor =
            (data.tipo_equipo || data.tipo) === 'Color';


        const colorBox =
            document.getElementById('salienteColorBox');


        if (esColor) {

            colorBox.classList.remove('d-none');

            document.getElementById('salienteAnteriorColor')
                .value =
                ultimo
                    ? (ultimo.contador_actual_color || 0)
                    : 0;

        } else {

            colorBox.classList.add('d-none');

        }


        actualizarResumen();
    }


    function mostrarEntrante(data) {

        entranteData = data;

        document
            .getElementById('entranteFicha')
            .classList.remove('d-none');

        document
            .getElementById('entranteContadores')
            .classList.remove('d-none');


        document.getElementById('entranteCodigo')
            .textContent = data.codigo_interno || '-';

        document.getElementById('entranteSerie')
            .textContent = data.serie || '-';

        document.getElementById('entranteModelo')
            .textContent = data.nombre_modelo || '-';

        actualizarTipo(
            document.getElementById('entranteTipo'),
            data.tipo_equipo || data.tipo || '-'
        );


        const esColor =
            (data.tipo_equipo || data.tipo) === 'Color';

        const colorBox =
            document.getElementById('entranteColorBox');


        if (esColor) {
            colorBox.classList.remove('d-none');
        } else {
            colorBox.classList.add('d-none');
        }


        actualizarResumen();
    }


    function limpiarSaliente() {

        salienteData = null;

        document
            .getElementById('salienteFicha')
            .classList.add('d-none');

        document
            .getElementById('salienteContadores')
            .classList.add('d-none');
    }


    function limpiarEntrante() {

        entranteData = null;

        document
            .getElementById('entranteFicha')
            .classList.add('d-none');

        document
            .getElementById('entranteContadores')
            .classList.add('d-none');
    }


    async function seleccionarSaliente() {

        limpiarAlerta();

        const id =
            salienteSelect.value;

        if (!id) {
            limpiarSaliente();
            actualizarResumen();
            return;
        }

        try {

            const data =
                await cargarEquipo(id);

            mostrarSaliente(data);

        } catch (error) {

            limpiarSaliente();

            mostrarAlerta(
                error.message
            );
        }
    }


    async function seleccionarEntrante() {

        limpiarAlerta();

        const id =
            entranteSelect.value;

        if (!id) {
            limpiarEntrante();
            actualizarResumen();
            return;
        }

        if (
            salienteSelect.value &&
            id === salienteSelect.value
        ) {

            entranteSelect.value = '';

            limpiarEntrante();

            mostrarAlerta(
                'El equipo entrante no puede ser el mismo que el saliente.'
            );

            return;
        }

        try {

            const data =
                await cargarEquipo(id);

            mostrarEntrante(data);

        } catch (error) {

            limpiarEntrante();

            mostrarAlerta(
                error.message
            );
        }
    }


    function actualizarResumen() {

        const resumen =
            document.getElementById('swapResumen');

        if (
            !salienteData ||
            !entranteData
        ) {

            resumen.classList.add('d-none');

            btnSwap.disabled = true;

            return;
        }


        resumen.classList.remove('d-none');

        document.getElementById('resumenSaliente')
            .textContent =
            `${salienteData.codigo_interno || '-'} � ${salienteData.serie || '-'}`;

        document.getElementById('resumenEntrante')
            .textContent =
            `${entranteData.codigo_interno || '-'} � ${entranteData.serie || '-'}`;


        btnSwap.disabled = false;
    }


    function validarFormulario() {

        if (!salienteSelect.value) {
            mostrarAlerta(
                'Seleccion� el equipo saliente.'
            );
            return false;
        }

        if (!entranteSelect.value) {
            mostrarAlerta(
                'Seleccion� el equipo entrante.'
            );
            return false;
        }

        if (!document.getElementById('salienteActual').value) {
            mostrarAlerta(
                'Ingres� el contador actual del equipo saliente.'
            );
            return false;
        }

        if (!document.getElementById('localidadSwap').value) {
            mostrarAlerta(
                'Seleccion� la localidad.'
            );
            return false;
        }

        if (!document.getElementById('entranteInicial').value) {
            mostrarAlerta(
                'Ingres� el contador inicial del equipo entrante.'
            );
            return false;
        }

        return true;
    }


    async function ejecutarSwap() {

        limpiarAlerta();

        if (!validarFormulario()) {
            return;
        }


        const formData =
            new FormData();

        formData.append(
            '_csrf',
            csrf
        );

        formData.append(
            'saliente_id',
            salienteSelect.value
        );

        formData.append(
            'entrante_id',
            entranteSelect.value
        );

        formData.append(
            'fecha',
            document.getElementById('fechaSwap').value
        );

        formData.append(
            'localidad_id',
            document.getElementById('localidadSwap').value
        );

        formData.append(
            'motivo',
            document.getElementById('motivoSwap').value
        );

        formData.append(
            'saliente_anterior',
            document.getElementById('salienteAnterior').value
        );

        formData.append(
            'saliente_actual',
            document.getElementById('salienteActual').value
        );

        formData.append(
            'saliente_anterior_color',
            document.getElementById('salienteAnteriorColor').value || 0
        );

        formData.append(
            'saliente_actual_color',
            document.getElementById('salienteActualColor').value || 0
        );

        formData.append(
            'entrante_inicial',
            document.getElementById('entranteInicial').value
        );

        formData.append(
            'entrante_inicial_color',
            document.getElementById('entranteInicialColor').value || 0
        );


        const textoOriginal =
            btnSwap.innerHTML;

        btnSwap.disabled = true;

        btnSwap.innerHTML =
            '<span class="spinner-border spinner-border-sm me-2"></span>' +
            'Procesando...';


        try {

            const response =
                await fetch(
                    '/contadores/swap',
                    {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With':
                                'XMLHttpRequest'
                        }
                    }
                );


            const data =
                await response.json();


            if (!response.ok || !data.ok) {

                throw new Error(
                    data.message ||
                    data.error ||
                    'No se pudo realizar el Swap.'
                );
            }


            window.location.href =
                `/contadores/swap/resultado/${data.historial_cambio_id}`;


        } catch (error) {

            mostrarAlerta(
                error.message
            );

            btnSwap.disabled = false;

            btnSwap.innerHTML =
                textoOriginal;
        }

    }


    salienteSelect.addEventListener(
        'change',
        seleccionarSaliente
    );

    entranteSelect.addEventListener(
        'change',
        seleccionarEntrante
    );

    btnSwap.addEventListener(
        'click',
        ejecutarSwap
    );

})();
</script>