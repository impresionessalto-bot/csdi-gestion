<?php

declare(strict_types=1);

$swap = $swap ?? [];

function e(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

$saliente = $swap['saliente'] ?? [];
$entrante = $swap['entrante'] ?? [];
$contrato = $swap['contrato'] ?? null;
?>

<div class="container-fluid py-4">

    <div class="mb-4">

        <span class="badge bg-warning-subtle text-warning">
            CONFIRMACIÓN
        </span>

        <h1 class="h3 fw-bold mt-2 mb-1">
            Confirmar Swap
        </h1>

        <p class="text-muted mb-0">
            Revisá los datos antes de confirmar el intercambio.
        </p>

    </div>


    <div class="row g-4">

        <!-- SALIENTE -->
        <div class="col-lg-5">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white border-0 pt-4 px-4">

                    <span class="badge bg-danger">
                        SALE
                    </span>

                    <h5 class="fw-bold mt-2 mb-0">
                        <?= e($saliente['codigo_interno'] ?? '-') ?>
                    </h5>

                </div>

                <div class="card-body px-4">

                    <dl class="row mb-0">

                        <dt class="col-sm-5 text-muted">
                            Serie
                        </dt>

                        <dd class="col-sm-7">
                            <?= e($saliente['serie'] ?? '-') ?>
                        </dd>


                        <dt class="col-sm-5 text-muted">
                            Modelo
                        </dt>

                        <dd class="col-sm-7">
                            <?= e($saliente['nombre_modelo'] ?? '-') ?>
                        </dd>


                        <dt class="col-sm-5 text-muted">
                            Tipo
                        </dt>

                        <dd class="col-sm-7">
                            <?= e($saliente['tipo_equipo'] ?? '-') ?>
                        </dd>


                        <dt class="col-sm-5 text-muted">
                            Contador
                        </dt>

                        <dd class="col-sm-7 fw-bold">
                            <?= e($saliente['contador_actual'] ?? '0') ?>
                        </dd>

                    </dl>

                </div>

            </div>

        </div>


        <!-- ICONO -->
        <div class="col-lg-2 d-flex align-items-center justify-content-center">

            <div class="text-center">

                <i class="bi bi-arrow-right fs-1 text-primary"></i>

                <div class="small text-muted">
                    intercambio
                </div>

            </div>

        </div>


        <!-- ENTRANTE -->
        <div class="col-lg-5">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white border-0 pt-4 px-4">

                    <span class="badge bg-success">
                        INGRESA
                    </span>

                    <h5 class="fw-bold mt-2 mb-0">
                        <?= e($entrante['codigo_interno'] ?? '-') ?>
                    </h5>

                </div>

                <div class="card-body px-4">

                    <dl class="row mb-0">

                        <dt class="col-sm-5 text-muted">
                            Serie
                        </dt>

                        <dd class="col-sm-7">
                            <?= e($entrante['serie'] ?? '-') ?>
                        </dd>


                        <dt class="col-sm-5 text-muted">
                            Modelo
                        </dt>

                        <dd class="col-sm-7">
                            <?= e($entrante['nombre_modelo'] ?? '-') ?>
                        </dd>


                        <dt class="col-sm-5 text-muted">
                            Tipo
                        </dt>

                        <dd class="col-sm-7">
                            <?= e($entrante['tipo_equipo'] ?? '-') ?>
                        </dd>


                        <dt class="col-sm-5 text-muted">
                            Contador inicial
                        </dt>

                        <dd class="col-sm-7 fw-bold">
                            <?= e($entrante['contador_inicial'] ?? '0') ?>
                        </dd>

                    </dl>

                </div>

            </div>

        </div>

    </div>


    <!-- CONTRATO -->
    <?php if ($contrato): ?>

        <div class="card border-0 shadow-sm mt-4">

            <div class="card-header bg-white border-0 pt-4 px-4">

                <h5 class="fw-bold mb-0">
                    Continuidad contractual
                </h5>

            </div>

            <div class="card-body px-4">

                <div class="alert alert-success mb-0">

                    <i class="bi bi-check-circle me-2"></i>

                    El equipo entrante reemplazará al equipo saliente
                    dentro del detalle del contrato existente.

                </div>


                <div class="row mt-3">

                    <div class="col-md-4">

                        <small class="text-muted d-block">
                            Contrato
                        </small>

                        <strong>
                            #<?= e($contrato['id'] ?? '-') ?>
                        </strong>

                    </div>


                    <div class="col-md-4">

                        <small class="text-muted d-block">
                            Tarifa
                        </small>

                        <strong>
                            #<?= e($contrato['tarifa_id'] ?? '-') ?>
                        </strong>

                    </div>


                    <div class="col-md-4">

                        <small class="text-muted d-block">
                            Equipo principal
                        </small>

                        <strong>
                            <?= !empty($contrato['es_equipo_principal'])
                                ? 'Sí'
                                : 'No' ?>
                        </strong>

                    </div>

                </div>

            </div>

        </div>

    <?php else: ?>

        <div class="alert alert-info mt-4">

            <i class="bi bi-info-circle me-2"></i>

            No se encontró un detalle contractual activo asociado
            al equipo saliente. El Swap continuará como cambio físico,
            sin modificar contratos.

        </div>

    <?php endif; ?>


    <!-- ADVERTENCIA -->
    <div class="alert alert-warning mt-4">

        <div class="d-flex">

            <i class="bi bi-exclamation-triangle fs-4 me-3"></i>

            <div>

                <strong>Importante</strong>

                <p class="mb-0 mt-1">
                    Esta operación modificará los equipos, generará
                    registros de contador y quedará registrada en
                    <code>historial_cambios</code>.
                </p>

            </div>

        </div>

    </div>


    <!-- ACCIONES -->
    <div class="d-flex justify-content-end gap-2 mt-4">

        <a
            href="/contadores/swap"
            class="btn btn-outline-secondary"
        >
            Volver
        </a>

        <form
            method="POST"
            action="/contadores/swap/ejecutar"
        >

            <input
                type="hidden"
                name="_csrf"
                value="<?= e($_SESSION['csrf_token'] ?? '') ?>"
            >

            <button
                type="submit"
                class="btn btn-primary px-4"
            >
                <i class="bi bi-check2-circle me-1"></i>
                Confirmar Swap
            </button>

        </form>

    </div>

</div>