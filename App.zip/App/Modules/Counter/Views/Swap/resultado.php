<?php

declare(strict_types=1);

$resultado = $resultado ?? [];

function e(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}
?>

<div class="container-fluid py-5">

    <div class="row justify-content-center">

        <div class="col-xl-8 col-lg-10">

            <div class="card border-0 shadow-sm">

                <div class="card-body text-center p-5">

                    <div
                        class="rounded-circle bg-success-subtle text-success
                               d-flex align-items-center justify-content-center
                               mx-auto mb-4"
                        style="width:80px;height:80px;"
                    >
                        <i class="bi bi-check-lg fs-1"></i>
                    </div>


                    <h1 class="h3 fw-bold mb-2">
                        Swap realizado correctamente
                    </h1>

                    <p class="text-muted mb-4">
                        El cambio de equipo quedó registrado correctamente.
                    </p>


                    <!-- EQUIPOS -->
                    <div class="row g-3 text-start mb-4">

                        <div class="col-md-6">

                            <div class="border rounded-3 p-4 h-100">

                                <span class="badge bg-danger mb-2">
                                    EQUIPO SALIENTE
                                </span>

                                <h5 class="fw-bold">
                                    <?= e(
                                        $resultado['equipo_saliente_id']
                                        ?? '-'
                                    ) ?>
                                </h5>

                                <div class="small text-muted">
                                    Estado: En reparación
                                </div>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="border rounded-3 p-4 h-100">

                                <span class="badge bg-success mb-2">
                                    EQUIPO ENTRANTE
                                </span>

                                <h5 class="fw-bold">
                                    <?= e(
                                        $resultado['equipo_entrante_id']
                                        ?? '-'
                                    ) ?>
                                </h5>

                                <div class="small text-muted">
                                    Estado: Activo
                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- INFORMACIÓN -->
                    <div class="table-responsive">

                        <table class="table table-sm align-middle text-start">

                            <tbody>

                                <tr>

                                    <th class="text-muted">
                                        Cliente
                                    </th>

                                    <td>
                                        #<?= e(
                                            $resultado['cliente_id']
                                            ?? '-'
                                        ) ?>
                                    </td>

                                </tr>


                                <tr>

                                    <th class="text-muted">
                                        Localidad
                                    </th>

                                    <td>
                                        #<?= e(
                                            $resultado['localidad_id']
                                            ?? '-'
                                        ) ?>
                                    </td>

                                </tr>


                                <tr>

                                    <th class="text-muted">
                                        Tipo saliente
                                    </th>

                                    <td>
                                        <?= e(
                                            $resultado['tipo_saliente']
                                            ?? '-'
                                        ) ?>
                                    </td>

                                </tr>


                                <tr>

                                    <th class="text-muted">
                                        Tipo entrante
                                    </th>

                                    <td>
                                        <?= e(
                                            $resultado['tipo_entrante']
                                            ?? '-'
                                        ) ?>
                                    </td>

                                </tr>


                                <tr>

                                    <th class="text-muted">
                                        Historial de cambio
                                    </th>

                                    <td>
                                        #<?= e(
                                            $resultado['historial_cambio_id']
                                            ?? '-'
                                        ) ?>
                                    </td>

                                </tr>


                                <?php if (
                                    !empty($resultado['contrato_id'])
                                ): ?>

                                    <tr>

                                        <th class="text-muted">
                                            Contrato
                                        </th>

                                        <td>
                                            #<?= e(
                                                $resultado['contrato_id']
                                            ) ?>
                                        </td>

                                    </tr>

                                    <tr>

                                        <th class="text-muted">
                                            Detalle contractual
                                        </th>

                                        <td>
                                            #<?= e(
                                                $resultado['contrato_detalle_id']
                                            ) ?>
                                        </td>

                                    </tr>

                                    <tr>

                                        <th class="text-muted">
                                            Tarifa conservada
                                        </th>

                                        <td>
                                            #<?= e(
                                                $resultado['tarifa_id']
                                            ) ?>
                                        </td>

                                    </tr>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>


                    <!-- CONTINUIDAD -->
                    <div class="alert alert-info text-start mt-4 mb-4">

                        <div class="d-flex">

                            <i class="bi bi-info-circle fs-4 me-3"></i>

                            <div>

                                <strong>
                                    Continuidad preservada
                                </strong>

                                <div class="small mt-1">

                                    Los contadores físicos de ambos equipos
                                    permanecen independientes. La relación
                                    entre el equipo saliente y el entrante
                                    queda registrada en
                                    <code>historial_cambios</code>.

                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- ACCIONES -->
                    <div class="d-flex justify-content-center gap-2">

                        <a
                            href="/contadores"
                            class="btn btn-primary px-4"
                        >
                            <i class="bi bi-speedometer2 me-1"></i>
                            Ir a contadores
                        </a>

                        <a
                            href="/contadores/swap"
                            class="btn btn-outline-secondary"
                        >
                            <i class="bi bi-arrow-left-right me-1"></i>
                            Nuevo Swap
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>