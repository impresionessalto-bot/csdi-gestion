<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP - Counter Show View (Detalle de Lectura de Contador - WhatsApp & Copiar Integrados)
|--------------------------------------------------------------------------
*/

$registro = $registro ?? [];
$titulo = $titulo ?? 'Detalle Lectura';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

// Normalización de variables de forma defensiva (PHP 8.3)
$id        = (int)($registro['id'] ?? 0);
$fecha     = (string)($registro['fecha'] ?? '');
$cliente   = (string)($registro['cliente_nombre'] ?? $registro['cliente'] ?? 'Sin cliente');
$codigo    = (string)($registro['codigo_interno'] ?? $registro['equipo'] ?? 'S/C');
$serie     = (string)($registro['serie'] ?? 'S/S');
$modelo    = (string)($registro['modelo_nombre'] ?? $registro['modelo'] ?? 'Multifuncional');

// Recuperación del teléfono del cliente para WhatsApp
$telefono  = preg_replace('/[^0-9]/', '', (string)($registro['cliente_telefono'] ?? ''));

$antMono   = (int)($registro['contador_anterior'] ?? 0);
$actMono   = (int)($registro['contador_actual'] ?? 0);
$copias    = (int)($registro['copias'] ?? 0);

$antColor  = (int)($registro['contador_anterior_color'] ?? 0);
$actColor  = (int)($registro['contador_actual_color'] ?? 0);
$copiasCol = (int)($registro['copias_color'] ?? 0);

$periodo   = ($registro['periodo_mes'] ?? '') . '/' . ($registro['periodo_anio'] ?? '');
$obs       = trim((string)($registro['observaciones'] ?? ''));
?>

<div class="container-fluid py-4">

    <!-- =====================================================
         HEADER DE LA SECCIÓN (Con Botonera de Facturación Rápida)
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">
        <div class="d-flex align-items-center">
            <div class="bg-primary text-white rounded-3 p-3 me-3 shadow-sm">
                <i class="fa-solid fa-file-invoice fs-3"></i>
            </div>
            <div>
                <h2 class="fw-bold text-white mb-1">Lectura de Contador #<?= $id ?></h2>
                <span class="text-muted-erp small fw-semibold">CUIT/ID Cliente vinculado: <?= htmlspecialchars($cliente, ENT_QUOTES, 'UTF-8') ?></span>
            </div>
        </div>
        
        <!-- Botonera de Acciones Rápidas (Unificada) -->
        <div class="d-flex gap-2">
            <!-- 1. Copiar al Portapapeles (NUEVO) -->
            <button type="button" class="btn btn-outline-light btn-sm fw-bold px-3" id="btnCopiarResumen">
                <i class="fa-solid fa-copy me-1"></i> Copiar Resumen
            </button>
            
            <!-- 2. Enviar por WhatsApp (NUEVO) -->
            <a href="#" target="_blank" class="btn btn-success btn-sm fw-bold px-3 text-decoration-none" id="btnEnviarWhatsApp">
                <i class="fa-brands fa-whatsapp me-1"></i> Enviar WhatsApp
            </a>

            <!-- 3. Botones de Navegación Clásicos -->
            <a href="/contadores" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver
            </a>
            <a href="/contadores/editar/<?= $id ?>" class="btn btn-warning btn-sm text-decoration-none fw-bold px-3">
                <i class="fa-solid fa-pen me-1"></i> Editar
            </a>
        </div>
    </div>

    <!-- =====================================================
         DETALLES E INFORMACIÓN DE EQUIPO Y LECTURA
         ===================================================== -->
    <div class="row g-4">
        
        <!-- Tarjeta Izquierda: Información de Hardware y Cliente -->
        <div class="col-12 col-lg-5">
            <div class="card-erp p-4 h-100">
                <h5 class="text-white fw-bold mb-4 small text-uppercase">
                    <i class="fa-solid fa-circle-info text-primary me-2"></i> Detalles de la Instalación
                </h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-3 d-flex justify-content-between text-white-50 border-bottom border-secondary pb-2">
                        <span>Cliente Asociado:</span>
                        <strong class="text-white"><?= htmlspecialchars($cliente, ENT_QUOTES, 'UTF-8') ?></strong>
                    </li>
                    <li class="mb-3 d-flex justify-content-between text-white-50 border-bottom border-secondary pb-2">
                        <span>Código Interno de Máquina:</span>
                        <strong class="text-white">[<?= htmlspecialchars($codigo, ENT_QUOTES, 'UTF-8') ?>]</strong>
                    </li>
                    <li class="mb-3 d-flex justify-content-between text-white-50 border-bottom border-secondary pb-2">
                        <span>Modelo de Fotocopiadora:</span>
                        <strong class="text-white"><?= htmlspecialchars($modelo, ENT_QUOTES, 'UTF-8') ?></strong>
                    </li>
                    <li class="mb-3 d-flex justify-content-between text-white-50 border-bottom border-secondary pb-2">
                        <span>Número de Serie:</span>
                        <strong class="text-white"><?= htmlspecialchars($serie, ENT_QUOTES, 'UTF-8') ?></strong>
                    </li>
                    <li class="mb-3 d-flex justify-content-between text-white-50 border-bottom border-secondary pb-2">
                        <span>Período del Abono:</span>
                        <strong class="text-primary font-monospace"><?= htmlspecialchars($periodo, ENT_QUOTES, 'UTF-8') ?></strong>
                    </li>
                    <li class="d-flex justify-content-between text-white-50">
                        <span>Fecha de Registro:</span>
                        <strong class="text-white"><?= $fecha !== '' ? date('d/m/Y', strtotime($fecha)) : '-' ?></strong>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Tarjeta Derecha: Estado de Contadores y Consumos -->
        <div class="col-12 col-lg-7">
            <div class="card-erp p-4 h-100">
                <h5 class="text-white fw-bold mb-4 small text-uppercase">
                    <i class="fa-solid fa-list-ol text-success me-2"></i> Mediciones de Odómetros y Consumos
                </h5>

                <div class="row g-3">
                    <!-- Detalle Monocromático -->
                    <div class="col-md-6 mb-3">
                        <div class="p-3 border border-secondary rounded-3 bg-dark">
                            <h6 class="text-white-50 small text-uppercase fw-bold mb-2">Lectura Monocromática (B&W)</h6>
                            <div class="d-flex justify-content-between text-white-50 small mb-1">
                                <span>Contador Anterior:</span>
                                <strong><?= number_format($antMono) ?></strong>
                            </div>
                            <div class="d-flex justify-content-between text-white-50 small mb-2">
                                <span>Contador Actual:</span>
                                <strong><?= number_format($actMono) ?></strong>
                            </div>
                            <div class="d-flex justify-content-between align-items-center border-top border-secondary pt-2 mt-2">
                                <span class="text-white fw-semibold">Copias Producidas:</span>
                                <strong class="fs-4 text-warning"><?= number_format($copias) ?></strong>
                            </div>
                        </div>
                    </div>

                    <!-- Detalle Color -->
                    <div class="col-md-6 mb-3">
                        <div class="p-3 border border-secondary rounded-3 bg-dark">
                            <h6 class="text-white-50 small text-uppercase fw-bold mb-2">Lectura Color (Full Color)</h6>
                            <div class="d-flex justify-content-between text-white-50 small mb-1">
                                <span>Contador Anterior:</span>
                                <strong><?= number_format($antColor) ?></strong>
                            </div>
                            <div class="d-flex justify-content-between text-white-50 small mb-2">
                                <span>Contador Actual:</span>
                                <strong><?= number_format($actColor) ?></strong>
                            </div>
                            <div class="d-flex justify-content-between align-items-center border-top border-secondary pt-2 mt-2">
                                <span class="text-white fw-semibold">Copias Producidas:</span>
                                <strong class="fs-4 text-info"><?= number_format($copiasCol) ?></strong>
                            </div>
                        </div>
                    </div>

                    <!-- Notas / Observaciones de la lectura -->
                    <div class="col-12 mt-2">
                        <label class="form-label text-white-50 small fw-bold text-uppercase">Notas / Observaciones de la visita:</label>
                        <div class="p-3 border border-secondary rounded bg-dark text-white" style="min-height: 80px;">
                            <?php if ($obs !== ''): ?>
                                <?= nl2br(htmlspecialchars($obs, ENT_QUOTES, 'UTF-8')) ?>
                            <?php else: ?>
                                <span class="text-muted-erp small">Sin observaciones registradas para este período.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

<!-- =====================================================
     SCRIPT: COMPILACIÓN DE MENSAJE Y COPIADO AL PORTAPAPELES
     ===================================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Compilación dinámica del Mensaje de Liquidación en formato Markdown (Asteriscos para negritas en WhatsApp)
    const textoResumen = `*CSDI ERP - Liquidación de Copias #${id}*
*Periodo:* ${<?= json_encode($periodo) ?>}
*Fecha:* ${<?= json_encode($fecha !== '' ? date('d/m/Y', strtotime($fecha)) : date('d/m/Y')) ?>}
*Cliente:* ${<?= json_encode($cliente) ?>}
*Equipo:* ${<?= json_encode($modelo) ?>} (Serie: ${<?= json_encode($serie) ?>})

*--- LECTURA MONOCROMÁTICA (B&W) ---*
• Contador Anterior: ${<?= json_encode(number_format($antMono)) ?>}
• Contador Actual: ${<?= json_encode(number_format($actMono)) ?>}
*• Copias Producidas:* *${<?= json_encode(number_format($copias)) ?>*

*--- LECTURA COLOR ---*
• Contador Anterior: ${<?= json_encode(number_format($antColor)) ?>}
• Contador Actual: ${<?= json_encode(number_format($actColor)) ?>}
*• Copias Producidas:* *${<?= json_encode(number_format($copiasCol)) ?>*

_Enviado de forma automática desde la consola CSDI ERP PRO_`;

    // 2. Evento para copiar el texto al portapapeles del técnico/operador
    const btnCopiar = document.getElementById('btnCopiarResumen');
    if (btnCopiar) {
        btnCopiar.addEventListener('click', () => {
            navigator.clipboard.writeText(textoResumen).then(() => {
                alert('¡Resumen de liquidación copiado al portapapeles con éxito!');
            }).catch(err => {
                console.error('Error al intentar copiar al portapapeles:', err);
                alert('Fallo de seguridad al copiar. Por favor, copie el texto manualmente.');
            });
        });
    }

    // 3. Evento para armar el link directo y despachar a la API de WhatsApp Web
    const btnWhatsApp = document.getElementById('btnEnviarWhatsApp');
    if (btnWhatsApp) {
        const telefonoCliente = "<?= $telefono ?>";
        const textEncoded = encodeURIComponent(textoResumen);
        
        // Seteamos la URL directa de la API de WhatsApp con el número y el texto pre-cargado
        btnWhatsApp.setAttribute('href', `https://api.whatsapp.com/send?phone=${telefonoCliente}&text=${textEncoded}`);
    }
});
</script>