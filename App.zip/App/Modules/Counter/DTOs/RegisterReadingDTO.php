<?php
declare(strict_types=1);

namespace App\Modules\Counter\DTOs;

use InvalidArgumentException;

final class RegisterReadingDTO
{
    public function __construct(
        public readonly int $cliente_id,
        public readonly int $equipo_id,
        public readonly int $contador_actual,
        public readonly int $contador_actual_color,
        public readonly string $fecha
    ) {
        if ($this->cliente_id <= 0) throw new InvalidArgumentException('Cliente inválido.');
        if ($this->equipo_id <= 0) throw new InvalidArgumentException('Equipo inválido.');
        if ($this->contador_actual < 0) throw new InvalidArgumentException('Contador mono negativo.');
        if ($this->contador_actual_color < 0) throw new InvalidArgumentException('Contador color negativo.');
        if (empty($this->fecha)) throw new InvalidArgumentException('Fecha obligatoria.');
    }

    public static function fromArray(array $data): self
    {
        return new self(
            cliente_id: (int)($data['cliente_id'] ?? 0),
            equipo_id: (int)($data['equipo_id'] ?? 0),
            contador_actual: (int)($data['contador_actual'] ?? 0),
            contador_actual_color: (int)($data['contador_actual_color'] ?? 0),
            fecha: (string)($data['fecha'] ?? date('Y-m-d'))
        );
    }
}