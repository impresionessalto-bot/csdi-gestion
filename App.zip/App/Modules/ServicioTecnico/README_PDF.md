# Servicio Técnico — PDF conectado

## Cambio principal
La generación de PDF quedó conectada para:

- `GET /servicios/exportar-pdf/{id}` — orden individual.
- `GET /servicios/exportar-pdf` — listado general.

## Dependencias
No requiere Dompdf, TCPDF, Composer, `exec()`, `shell_exec()` ni binarios externos.

El archivo `Services/PdfService.php` genera directamente un PDF estándar desde PHP y envía `application/pdf` al navegador.

## Datos utilizados
El PDF individual toma los datos reales devueltos por `Repository::find()` y contempla:

- orden y fecha;
- cliente, teléfono, email y dirección;
- marca, modelo, serie, código interno y propiedad;
- estado;
- contador monocromático y color;
- cables y fuente cuando existen;
- problema reportado;
- solución/trabajo realizado cuando existe;
- observaciones;
- firmas.

La vista `Views/imprimir.php` también fue corregida para UTF-8 y queda disponible como comprobante HTML imprimible.
