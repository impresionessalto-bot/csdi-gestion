<?php

declare(strict_types=1);

namespace App\Modules\ServicioTecnico\Repositories;

use PDO;
use RuntimeException;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }


    /**
     * =========================================================
     * LISTAR
     * =========================================================
     */
    public function listar(
        array $filtros = []
    ): array {

        $sql = "
            SELECT
                s.*,

                c.nombre AS cliente_nombre,
                c.nombre_fantasia AS cliente_nombre_fantasia,
                c.telefono AS cliente_telefono,
                c.email AS cliente_email,
                c.direccion AS cliente_direccion,
                c.localidad_id AS cliente_localidad_id,
                c.lat AS cliente_lat,
                c.lng AS cliente_lng,
                c.persona_contacto AS cliente_contacto,

                e.id AS equipo_real_id,
                e.codigo_interno AS equipo_codigo,
                e.serie AS equipo_serie,
                e.identificador_externo AS equipo_identificador,
                e.propiedad AS equipo_propiedad,
                e.estado AS equipo_estado,

                m.id AS modelo_id,
                m.nombre_modelo AS modelo_oficial,
                m.marca,
                m.tipo AS modelo_tipo,

                s.descripcion_problema AS problema

            FROM servicios s

            LEFT JOIN clientes c
                ON c.id = s.cliente_id

            LEFT JOIN equipos e
                ON e.id = s.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE 1 = 1
        ";


        $params = [];


        /*
         * =====================================================
         * BUSCADOR
         * =====================================================
         */
        $texto =
            trim(
                (string)(
                    $filtros['texto']
                    ?? ''
                )
            );


        if ($texto !== '') {

            $sql .= "
                AND (
                    s.descripcion_problema LIKE ?
                    OR s.solucion_aplicada LIKE ?
                    OR c.nombre LIKE ?
                    OR c.nombre_fantasia LIKE ?
                    OR m.nombre_modelo LIKE ?
                    OR m.marca LIKE ?
                    OR e.serie LIKE ?
                    OR e.codigo_interno LIKE ?
                )
            ";


            $like =
                '%' .
                $texto .
                '%';


            for (
                $i = 0;
                $i < 8;
                $i++
            ) {

                $params[] =
                    $like;
            }
        }


        /*
         * =====================================================
         * ESTADO
         * =====================================================
         */
        $estado =
            trim(
                (string)(
                    $filtros['estado']
                    ?? ''
                )
            );


        if ($estado !== '') {

            $sql .= "
                AND s.estado = ?
            ";


            $params[] =
                $estado;
        }


        $sql .= "
            ORDER BY
                s.id DESC
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute(
            $params
        );


        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }


    /**
     * =========================================================
     * COUNT
     * =========================================================
     */
    public function count(): int
    {
        $stmt =
            $this->db->query("
                SELECT COUNT(*)
                FROM servicios
            ");


        return (int)$stmt->fetchColumn();
    }


    /**
     * =========================================================
     * KPIS
     * =========================================================
     */
    public function obtenerKpis(): array
    {
        $stmt =
            $this->db->query("
                SELECT

                    COUNT(*) AS total,

                    SUM(
                        CASE
                            WHEN estado = 'Pendiente'
                            THEN 1
                            ELSE 0
                        END
                    ) AS pendientes,

                    SUM(
                        CASE
                            WHEN estado = 'En Proceso'
                            THEN 1
                            ELSE 0
                        END
                    ) AS en_proceso,

                    SUM(
                        CASE
                            WHEN estado = 'En Reparacion'
                            THEN 1
                            ELSE 0
                        END
                    ) AS en_reparacion,

                    SUM(
                        CASE
                            WHEN estado = 'Finalizado'
                            THEN 1
                            ELSE 0
                        END
                    ) AS finalizados

                FROM servicios
            ");


        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            )
            ?: [];


        return [

            'total' =>
                (int)(
                    $row['total']
                    ?? 0
                ),

            'pendientes' =>
                (int)(
                    $row['pendientes']
                    ?? 0
                ),

            'en_proceso' =>
                (int)(
                    $row['en_proceso']
                    ?? 0
                ),

            'en_reparacion' =>
                (int)(
                    $row['en_reparacion']
                    ?? 0
                ),

            'finalizados' =>
                (int)(
                    $row['finalizados']
                    ?? 0
                ),
        ];
    }


    /**
     * =========================================================
     * FIND
     * =========================================================
     */
    public function find(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }


        $stmt =
            $this->db->prepare("
                SELECT

                    s.*,

                    c.nombre AS cliente_nombre,
                    c.nombre_fantasia AS cliente_nombre_fantasia,
                    c.telefono AS cliente_telefono,
                    c.email AS cliente_email,
                    c.direccion AS cliente_direccion,
                    c.localidad_id AS cliente_localidad_id,
                    c.lat AS cliente_lat,
                    c.lng AS cliente_lng,
                    c.persona_contacto AS cliente_contacto,
                    c.tipo_cliente AS cliente_tipo,
                    c.categoria_fiscal AS cliente_categoria_fiscal,
                    c.tipo_doc AS cliente_tipo_doc,
                    c.nro_doc AS cliente_nro_doc,

                    e.id AS equipo_real_id,
                    e.codigo_interno AS equipo_codigo,
                    e.cliente_id AS equipo_cliente_id,
                    e.modelo_id AS equipo_modelo_id,
                    e.serie AS equipo_serie,
                    e.identificador_externo,
                    e.propiedad AS equipo_propiedad,
                    e.estado AS equipo_estado,

                    m.id AS modelo_id,
                    m.nombre_modelo AS modelo_oficial,
                    m.marca,
                    m.tipo AS modelo_tipo

                FROM servicios s

                LEFT JOIN clientes c
                    ON c.id = s.cliente_id

                LEFT JOIN equipos e
                    ON e.id = s.equipo_id

                LEFT JOIN modelos_equipos m
                    ON m.id = e.modelo_id

                WHERE s.id = ?

                LIMIT 1
            ");


        $stmt->execute([
            $id
        ]);


        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            )
            ?: null;
    }


    /**
     * =========================================================
     * CREAR
     * =========================================================
     */
    public function crear(
        array $data
    ): int {

        $clienteId =
            (int)(
                $data['cliente_id']
                ?? 0
            );


        $equipoId =
            (int)(
                $data['equipo_id']
                ?? 0
            );


        $problema =
            trim(
                (string)(
                    $data['problema']
                    ?? ''
                )
            );


        $estado =
            trim(
                (string)(
                    $data['estado']
                    ?? 'Pendiente'
                )
            );


        $stmt =
            $this->db->prepare("
                INSERT INTO servicios
                (
                    cliente_id,
                    equipo_id,
                    fecha_solicitud,
                    descripcion_problema,
                    estado
                )
                VALUES
                (
                    ?,
                    ?,
                    NOW(),
                    ?,
                    ?
                )
            ");


        $stmt->execute([

            $clienteId > 0
                ? $clienteId
                : null,

            $equipoId > 0
                ? $equipoId
                : null,

            $problema,

            $estado,
        ]);


        $id =
            (int)$this->db->lastInsertId();


        /*
         * CABLES
         */
        if (
            $this->columnExists(
                'servicios',
                'cables'
            )
        ) {

            $stmt =
                $this->db->prepare("
                    UPDATE servicios
                    SET cables = ?
                    WHERE id = ?
                ");


            $stmt->execute([

                (int)(
                    $data['cables']
                    ?? 0
                ),

                $id,
            ]);
        }


        /*
         * FUENTE
         */
        if (
            $this->columnExists(
                'servicios',
                'fuente'
            )
        ) {

            $stmt =
                $this->db->prepare("
                    UPDATE servicios
                    SET fuente = ?
                    WHERE id = ?
                ");


            $stmt->execute([

                (int)(
                    $data['fuente']
                    ?? 0
                ),

                $id,
            ]);
        }


        /*
         * CONTADOR MONO
         */
        if (
            $this->columnExists(
                'servicios',
                'contador_mono'
            )
        ) {

            $stmt =
                $this->db->prepare("
                    UPDATE servicios
                    SET contador_mono = ?
                    WHERE id = ?
                ");


            $stmt->execute([

                (int)(
                    $data['contador_mono']
                    ?? 0
                ),

                $id,
            ]);
        }


        /*
         * CONTADOR COLOR
         */
        if (
            $this->columnExists(
                'servicios',
                'contador_color'
            )
        ) {

            $stmt =
                $this->db->prepare("
                    UPDATE servicios
                    SET contador_color = ?
                    WHERE id = ?
                ");


            $stmt->execute([

                (int)(
                    $data['contador_color']
                    ?? 0
                ),

                $id,
            ]);
        }


        return $id;
    }


    /**
     * =========================================================
     * ACTUALIZAR
     * =========================================================
     */
    public function actualizar(
        int $id,
        array $data
    ): void {

        if ($id <= 0) {

            throw new RuntimeException(
                'ID de servicio inválido.'
            );
        }


        $clienteId =
            (int)(
                $data['cliente_id']
                ?? 0
            );


        $equipoId =
            (int)(
                $data['equipo_id']
                ?? 0
            );


        $problema =
            trim(
                (string)(
                    $data['problema']
                    ?? ''
                )
            );


        $estado =
            trim(
                (string)(
                    $data['estado']
                    ?? 'Pendiente'
                )
            );


        $stmt =
            $this->db->prepare("
                UPDATE servicios
                SET
                    cliente_id = ?,
                    equipo_id = ?,
                    descripcion_problema = ?,
                    estado = ?
                WHERE id = ?
            ");


        $stmt->execute([

            $clienteId > 0
                ? $clienteId
                : null,

            $equipoId > 0
                ? $equipoId
                : null,

            $problema,

            $estado,

            $id,
        ]);


        $opcionales = [

            'cables',

            'fuente',

            'contador_mono',

            'contador_color',
        ];


        foreach (
            $opcionales as $campo
        ) {

            if (
                !array_key_exists(
                    $campo,
                    $data
                )
            ) {

                continue;
            }


            if (
                !$this->columnExists(
                    'servicios',
                    $campo
                )
            ) {

                continue;
            }


            $stmt =
                $this->db->prepare("
                    UPDATE servicios
                    SET {$campo} = ?
                    WHERE id = ?
                ");


            $stmt->execute([

                (int)$data[$campo],

                $id,
            ]);
        }
    }


    /**
     * =========================================================
     * CAMBIAR ESTADO - FALLBACK
     * =========================================================
     *
     * El flujo principal usa DragAndDropService.
     * Este método queda disponible para compatibilidad.
     */
    public function cambiarEstado(
        int $id,
        string $estado
    ): void {

        $permitidos = [

            'Pendiente',

            'En Proceso',

            'En Reparacion',

            'Finalizado',
        ];


        if ($id <= 0) {

            throw new RuntimeException(
                'ID de servicio inválido.'
            );
        }


        if (!in_array(
            $estado,
            $permitidos,
            true
        )) {

            throw new RuntimeException(
                'Estado de servicio inválido.'
            );
        }


        $stmt =
            $this->db->prepare("
                UPDATE servicios
                SET estado = ?
                WHERE id = ?
            ");


        $stmt->execute([

            $estado,

            $id,
        ]);


        /*
         * Verificar existencia aunque rowCount = 0.
         */
        $check =
            $this->db->prepare("
                SELECT id
                FROM servicios
                WHERE id = ?
                LIMIT 1
            ");


        $check->execute([
            $id
        ]);


        if (
            $check->fetchColumn()
            === false
        ) {

            throw new RuntimeException(
                'El servicio no existe.'
            );
        }
    }


    /**
     * =========================================================
     * ELIMINAR
     * =========================================================
     */
    public function delete(
        int $id
    ): void {

        $stmt =
            $this->db->prepare("
                DELETE FROM servicios
                WHERE id = ?
            ");


        $stmt->execute([
            $id
        ]);
    }


    /**
     * =========================================================
     * CLIENTES
     * =========================================================
     */
    public function obtenerClientes(): array
    {
        return $this->db
            ->query("
                SELECT
                    id,
                    nombre,
                    nombre_fantasia,
                    tipo_cliente,
                    localidad_id,
                    direccion,
                    lat,
                    lng,
                    persona_contacto,
                    telefono,
                    email,
                    categoria_fiscal,
                    tipo_doc,
                    nro_doc,
                    activo
                FROM clientes
                WHERE activo = 1
                ORDER BY nombre ASC
            ")
            ->fetchAll(
                PDO::FETCH_ASSOC
            );
    }


    /**
     * =========================================================
     * CLIENTE
     * =========================================================
     */
    public function obtenerCliente(
        int $id
    ): ?array {

        $stmt =
            $this->db->prepare("
                SELECT
                    c.id,
                    c.nombre,
                    c.nombre_fantasia,
                    c.tipo_cliente,
                    c.localidad_id,
                    c.direccion,
                    c.lat,
                    c.lng,
                    c.persona_contacto,
                    c.telefono,
                    c.email,
                    c.categoria_fiscal,
                    c.tipo_doc,
                    c.nro_doc,
                    c.activo
                FROM clientes c
                WHERE c.id = ?
                LIMIT 1
            ");


        $stmt->execute([
            $id
        ]);


        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            )
            ?: null;
    }


    /**
     * =========================================================
     * CREAR CLIENTE
     * =========================================================
     */
    public function crearCliente(
        array $data
    ): int {

        $stmt =
            $this->db->prepare("
                INSERT INTO clientes
                (
                    nombre,
                    nombre_fantasia,
                    tipo_cliente,
                    localidad_id,
                    direccion,
                    persona_contacto,
                    telefono,
                    email,
                    categoria_fiscal,
                    tipo_doc,
                    nro_doc,
                    activo
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    1
                )
            ");


        $stmt->execute([

            trim(
                (string)(
                    $data['nombre']
                    ?? ''
                )
            ),

            trim(
                (string)(
                    $data['nombre_fantasia']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['tipo_cliente']
                    ?? 'Externo'
                )
            ),

            !empty(
                $data['localidad_id']
            )
                ? (int)$data['localidad_id']
                : null,

            trim(
                (string)(
                    $data['direccion']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['persona_contacto']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['telefono']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['email']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['categoria_fiscal']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['tipo_doc']
                    ?? ''
                )
            ) ?: null,

            trim(
                (string)(
                    $data['nro_doc']
                    ?? ''
                )
            ) ?: null,
        ]);


        return (int)$this->db->lastInsertId();
    }


    /**
     * =========================================================
     * MODELOS
     * =========================================================
     */
    public function obtenerModelos(): array
    {
        return $this->db
            ->query("
                SELECT
                    id,
                    nombre_modelo,
                    marca,
                    tipo
                FROM modelos_equipos
                WHERE activo = 1
                ORDER BY
                    marca ASC,
                    nombre_modelo ASC
            ")
            ->fetchAll(
                PDO::FETCH_ASSOC
            );
    }


    /**
     * =========================================================
     * MODELO
     * =========================================================
     */
    public function obtenerModelo(
        int $id
    ): ?array {

        $stmt =
            $this->db->prepare("
                SELECT
                    id,
                    nombre_modelo,
                    marca,
                    tipo,
                    activo
                FROM modelos_equipos
                WHERE id = ?
                LIMIT 1
            ");


        $stmt->execute([
            $id
        ]);


        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            )
            ?: null;
    }


    /**
     * =========================================================
     * CREAR MODELO
     * =========================================================
     */
    public function crearModelo(
        array $data
    ): int {

        $stmt =
            $this->db->prepare("
                INSERT INTO modelos_equipos
                (
                    nombre_modelo,
                    marca,
                    tipo,
                    activo
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    1
                )
            ");


        $stmt->execute([

            trim(
                (string)(
                    $data['nombre_modelo']
                    ?? ''
                )
            ),

            trim(
                (string)(
                    $data['marca']
                    ?? ''
                )
            ),

            trim(
                (string)(
                    $data['tipo']
                    ?? 'Mono'
                )
            ),
        ]);


        return (int)$this->db->lastInsertId();
    }


    /**
     * =========================================================
     * EQUIPOS
     * =========================================================
     */
    public function obtenerEquipos(
        int $clienteId = 0
    ): array {

        $sql = "
            SELECT
                e.id,
                e.cliente_id,
                e.modelo_id,
                e.codigo_interno,
                e.serie,
                e.identificador_externo,
                e.propiedad,
                e.estado,

                m.nombre_modelo,
                m.marca,
                m.tipo

            FROM equipos e

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE 1 = 1
        ";


        $params = [];


        if ($clienteId > 0) {

            $sql .= "
                AND e.cliente_id = ?
            ";


            $params[] =
                $clienteId;
        }


        $sql .= "
            ORDER BY
                m.marca ASC,
                m.nombre_modelo ASC,
                e.serie ASC
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute(
            $params
        );


        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }


    /**
     * =========================================================
     * OBTENER / CREAR EQUIPO
     * =========================================================
     */
    public function obtenerOCrearEquipo(
        int $clienteId,
        int $modeloId,
        string $serie
    ): int {

        if ($modeloId <= 0) {

            throw new RuntimeException(
                'Modelo de equipo inválido.'
            );
        }


        $serie =
            trim(
                $serie
            );


        /*
         * Buscar equipo existente.
         */
        if ($serie !== '') {

            if ($clienteId > 0) {

                $stmt =
                    $this->db->prepare("
                        SELECT id
                        FROM equipos
                        WHERE cliente_id = ?
                        AND modelo_id = ?
                        AND serie = ?
                        LIMIT 1
                    ");


                $stmt->execute([

                    $clienteId,

                    $modeloId,

                    $serie,
                ]);

            } else {

                $stmt =
                    $this->db->prepare("
                        SELECT id
                        FROM equipos
                        WHERE modelo_id = ?
                        AND serie = ?
                        LIMIT 1
                    ");


                $stmt->execute([

                    $modeloId,

                    $serie,
                ]);
            }


            $existente =
                $stmt->fetchColumn();


            if (
                $existente !== false
            ) {

                return (int)$existente;
            }
        }


        /*
         * Código interno.
         */
        $codigoInterno =
            'ST-' .
            date('YmdHis') .
            '-' .
            random_int(
                100,
                999
            );


        $stmt =
            $this->db->prepare("
                INSERT INTO equipos
                (
                    codigo_interno,
                    cliente_id,
                    modelo_id,
                    serie,
                    identificador_externo,
                    activo,
                    propiedad,
                    estado
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    NULL,
                    1,
                    'Cliente',
                    'Activo'
                )
            ");


        $stmt->execute([

            $codigoInterno,

            $clienteId > 0
                ? $clienteId
                : null,

            $modeloId,

            $serie !== ''
                ? $serie
                : null,
        ]);


        return (int)$this->db->lastInsertId();
    }


    /**
     * =========================================================
     * HISTORIAL
     * =========================================================
     */
    public function historial(
        string $texto = ''
    ): array {

        $sql = "
            SELECT

                s.*,

                c.nombre AS cliente_nombre,
                c.nombre_fantasia AS cliente_nombre_fantasia,
                c.telefono AS cliente_telefono,
                c.direccion AS cliente_direccion,
                c.localidad_id AS cliente_localidad_id,
                c.lat AS cliente_lat,
                c.lng AS cliente_lng,
                c.persona_contacto AS cliente_contacto,

                e.serie AS equipo_serie,
                e.codigo_interno AS equipo_codigo,

                m.nombre_modelo AS modelo_oficial,
                m.marca,
                m.tipo AS modelo_tipo,

                s.descripcion_problema AS problema

            FROM servicios s

            LEFT JOIN clientes c
                ON c.id = s.cliente_id

            LEFT JOIN equipos e
                ON e.id = s.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE s.estado = 'Finalizado'
        ";


        $params = [];


        if ($texto !== '') {

            $sql .= "
                AND (
                    c.nombre LIKE ?
                    OR c.nombre_fantasia LIKE ?
                    OR m.nombre_modelo LIKE ?
                    OR m.marca LIKE ?
                    OR e.serie LIKE ?
                    OR e.codigo_interno LIKE ?
                    OR s.descripcion_problema LIKE ?
                )
            ";


            $like =
                '%' .
                $texto .
                '%';


            for (
                $i = 0;
                $i < 7;
                $i++
            ) {

                $params[] =
                    $like;
            }
        }


        $sql .= "
            ORDER BY
                s.id DESC
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute(
            $params
        );


        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }


    /**
     * =========================================================
     * DASHBOARD
     * =========================================================
     */
    public function dashboard(): array
    {
        return [

            'kpis' =>
                $this->obtenerKpis(),

            'porEstado' =>
                $this->db
                    ->query("
                        SELECT
                            estado,
                            COUNT(*) AS cantidad
                        FROM servicios
                        GROUP BY estado
                        ORDER BY cantidad DESC
                    ")
                    ->fetchAll(
                        PDO::FETCH_ASSOC
                    ),

            'porMarca' =>
                $this->db
                    ->query("
                        SELECT
                            m.marca,
                            COUNT(s.id) AS cantidad
                        FROM servicios s
                        LEFT JOIN equipos e
                            ON e.id = s.equipo_id
                        LEFT JOIN modelos_equipos m
                            ON m.id = e.modelo_id
                        GROUP BY m.marca
                        ORDER BY cantidad DESC
                    ")
                    ->fetchAll(
                        PDO::FETCH_ASSOC
                    ),
        ];
    }


    /**
     * =========================================================
     * VERIFICAR COLUMNA
     * =========================================================
     */
    private function columnExists(
        string $table,
        string $column
    ): bool {

        $stmt =
            $this->db->prepare("
                SELECT COUNT(*)
                FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = ?
                AND COLUMN_NAME = ?
            ");


        $stmt->execute([

            $table,

            $column,
        ]);


        return
            (int)$stmt->fetchColumn()
            > 0;
    }
}