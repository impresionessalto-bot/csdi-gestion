<?php
declare(strict_types=1);

namespace App\Modules\ServicioTecnico;

use App\Core\Module as CoreModule;


final class Module extends CoreModule
{


    /**
     * Nombre del módulo
     */
    public function name(): string
    {
        return 'ServicioTecnico';
    }



    /**
     * Descripción
     */
    public function description(): string
    {
        return 'Gestión de órdenes de servicio técnico.';
    }



    /**
     * Versión
     */
    public function version(): string
    {
        return '1.0.0';
    }



    /**
     * Prioridad de carga
     */
    public function priority(): int
    {
        return 40;
    }



    /**
     * Archivo de rutas
     */
    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }



    /**
     * Menú lateral ERP
     */
    public function menu(): array
    {
        return [

            [

                'title' => 'Servicio Técnico',

                'url'   => '/servicios',

                'icon'  => 'fa-solid fa-screwdriver-wrench',

                'order' => 40

            ]

        ];
    }



    /**
     * Icono
     */
    public function icon(): string
    {
        return 'fa-solid fa-screwdriver-wrench';
    }



    /**
     * URL principal
     */
    public function url(): string
    {
        return '/servicios';
    }



    /**
     * Permisos
     */
    public function permissions(): array
    {
        return [

            'servicios.view',

            'servicios.create',

            'servicios.edit',

            'servicios.delete'

        ];
    }



    /**
     * Dependencias
     */
    public function dependencies(): array
    {
        return [

            'Clientes',

            'Equipos'

        ];
    }



    /**
     * Inicialización del módulo
     */
    public function boot(): void
    {

        // Registro de servicios futuros
        // Eventos
        // Observadores

    }


}