<?php

declare(strict_types=1);

namespace App\Modules\ServicioTecnico\Controllers;

use App\Core\BaseController;
use App\Modules\ServicioTecnico\Services\Service;
use Throwable;

final class Controller extends BaseController
{
    /**
     * =========================================================
     * ESTADOS PERMITIDOS
     * =========================================================
     */
    private const ESTADOS_PERMITIDOS = [
        'Pendiente',
        'En Proceso',
        'En Reparacion',
        'Finalizado',
    ];


    /**
     * =========================================================
     * CONSTRUCTOR
     * =========================================================
     */
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }


    /**
     * =========================================================
     * ASSETS
     * =========================================================
     *
     * Importante:
     *
     * BaseController/AssetManager solamente registran assets.
     * El layout app.php espera recibirlos en:
     *
     * - extraCss
     * - extraJs
     *
     * Por eso este método devuelve ambos arrays.
     */
    private function loadAssets(): array
    {
        $this->assets()
            ->addCss(
                'assets/css/serviciotecnico.css'
            )
            ->addJs(
                'assets/js/drag-and-drop.js'
            )
            ->addJs(
                'assets/js/serviciotecnico.js'
            );

        return [
            'extraCss' =>
                $this->assets()->css(),

            'extraJs' =>
                $this->assets()->js(),
        ];
    }


    /**
     * =========================================================
     * CSRF LOCAL DEL MÓDULO
     * =========================================================
     *
     * No modificamos Core.
     *
     * Validamos directamente contra:
     *
     * $_SESSION['_csrf']
     *
     * Soporta:
     *
     * POST csrf
     * HTTP_X_CSRF_TOKEN
     */
    private function validarCsrfModulo(): bool
    {
        if (
            session_status()
            !==
            PHP_SESSION_ACTIVE
        ) {
            session_start();
        }


        $sessionToken =
            isset(
                $_SESSION['_csrf']
            )
                ? trim(
                    (string)
                    $_SESSION['_csrf']
                )
                : '';


        if (
            $sessionToken === ''
        ) {
            return false;
        }


        /*
         * POST normal / FormData.
         */
        $token =
            isset($_POST['csrf'])
                ? trim(
                    (string)
                    $_POST['csrf']
                )
                : '';


        /*
         * Respaldo por header.
         */
        if (
            $token === ''
        ) {

            $token =
                isset(
                    $_SERVER[
                        'HTTP_X_CSRF_TOKEN'
                    ]
                )
                    ? trim(
                        (string)
                        $_SERVER[
                            'HTTP_X_CSRF_TOKEN'
                        ]
                    )
                    : '';
        }


        if (
            $token === ''
        ) {
            return false;
        }


        return hash_equals(
            $sessionToken,
            $token
        );
    }


    /**
     * =========================================================
     * INDEX
     * =========================================================
     */
    public function index(): void
    {
        try {

            $this->requireAuth();


            $texto =
                trim(
                    (string)
                    $this->request->get(
                        'texto',
                        ''
                    )
                );


            $estado =
                trim(
                    (string)
                    $this->request->get(
                        'estado',
                        ''
                    )
                );


            /*
             * Si llega un filtro de estado inválido,
             * lo ignoramos.
             */
            if (
                $estado !== ''
                &&
                !in_array(
                    $estado,
                    self::ESTADOS_PERMITIDOS,
                    true
                )
            ) {

                $estado = '';
            }


            $filtros = [
                'texto' =>
                    $texto,

                'estado' =>
                    $estado,
            ];


            $data =
                $this->service->index(
                    $filtros
                );


            $assets =
                $this->loadAssets();


            $this->moduleView(
                'ServicioTecnico',
                'index',
                [
                    'title' =>
                        'Servicio Técnico',

                    'servicios' =>
                        is_array(
                            $data['servicios']
                            ?? null
                        )
                            ? $data['servicios']
                            : [],

                    'kpis' =>
                        is_array(
                            $data['kpis']
                            ?? null
                        )
                            ? $data['kpis']
                            : [],

                    'filtros' =>
                        $filtros,

                    'csrf' =>
                        $this->csrf(),

                    'extraCss' =>
                        $assets['extraCss'],

                    'extraJs' =>
                        $assets['extraJs'],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * NUEVO
     * =========================================================
     */
    public function nuevo(): void
    {
        try {

            $this->requireAuth();


            $clientes =
                $this->service
                    ->obtenerClientes();


            $modelos =
                $this->service
                    ->obtenerModelos();


            $assets =
                $this->loadAssets();


            $this->moduleView(
                'ServicioTecnico',
                'nuevo',
                [
                    'title' =>
                        'Nuevo Servicio Técnico',

                    'clientes' =>
                        is_array($clientes)
                            ? $clientes
                            : [],

                    'modelos' =>
                        is_array($modelos)
                            ? $modelos
                            : [],

                    'csrf' =>
                        $this->csrf(),

                    'extraCss' =>
                        $assets['extraCss'],

                    'extraJs' =>
                        $assets['extraJs'],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * BUSCAR EQUIPO
     * =========================================================
     *
     * Pantalla de consulta rápida para técnicos.
     * Utiliza el Service de Equipos existente; no duplica
     * consultas ni lógica del módulo maestro de Equipos.
     */
    public function buscarEquipo(): void
    {
        try {

            $this->requireAuth();

            $texto = trim(
                (string)$this->request->get(
                    'texto',
                    ''
                )
            );

            $equipos = $this->service->buscarEquipos($texto);

            $assets = $this->loadAssets();

            $this->moduleView(
                'ServicioTecnico',
                'buscar-equipo',
                [
                    'title' => 'Buscar equipo',
                    'texto' => $texto,
                    'equipos' => is_array($equipos) ? $equipos : [],
                    'extraCss' => $assets['extraCss'],
                    'extraJs' => $assets['extraJs'],
                ]
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * GUARDAR
     * =========================================================
     */
    public function guardar(): void
    {
        try {

            $this->requireAuth();


            if (
                !$this->validarCsrfModulo()
            ) {

                $this->forbidden(
                    'Token de seguridad inválido o expirado.'
                );

                return;
            }


            $estado =
                trim(
                    (string)
                    $this->request->post(
                        'estado',
                        'Pendiente'
                    )
                );


            if (
                !in_array(
                    $estado,
                    self::ESTADOS_PERMITIDOS,
                    true
                )
            ) {

                $estado =
                    'Pendiente';
            }


            $data = [

                'cliente_id' =>
                    (int)
                    $this->request->post(
                        'cliente_id',
                        0
                    ),

                'modelo_id' =>
                    (int)
                    $this->request->post(
                        'modelo_id',
                        0
                    ),

                'equipo_id' =>
                    (int)
                    $this->request->post(
                        'equipo_id',
                        0
                    ),

                'serie' =>
                    trim(
                        (string)
                        $this->request->post(
                            'serie',
                            ''
                        )
                    ),

                'contador_mono' =>
                    (int)
                    $this->request->post(
                        'contador_mono',
                        0
                    ),

                'contador_color' =>
                    (int)
                    $this->request->post(
                        'contador_color',
                        0
                    ),

                'estado' =>
                    $estado,

                'problema' =>
                    trim(
                        (string)
                        $this->request->post(
                            'problema',
                            ''
                        )
                    ),

                'observaciones' =>
                    trim(
                        (string)
                        $this->request->post(
                            'observaciones',
                            ''
                        )
                    ),

                'cables' =>
                    (int)
                    $this->request->post(
                        'cables',
                        0
                    ),

                'fuente' =>
                    (int)
                    $this->request->post(
                        'fuente',
                        0
                    ),
            ];


            $errors = [];


            if (
                $data['modelo_id'] <= 0
                &&
                $data['equipo_id'] <= 0
            ) {

                $errors['modelo_id'] =
                    'Debe seleccionar un modelo de equipo.';
            }


            if (
                $data['problema'] === ''
            ) {

                $errors['problema'] =
                    'Debe indicar el problema o falla.';
            }


            if (
                $data['contador_mono'] < 0
            ) {

                $errors['contador_mono'] =
                    'El contador monocromático no puede ser negativo.';
            }


            if (
                $data['contador_color'] < 0
            ) {

                $errors['contador_color'] =
                    'El contador color no puede ser negativo.';
            }


            if (
                !empty($errors)
            ) {

                $this->validation(
                    $errors
                );

                return;
            }


            $id =
                $this->service->crear(
                    $data
                );


            $this->redirect(
                '/servicios/ver/' . $id
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * VER
     * =========================================================
     */
    public function ver(
        int|string $id
    ): void {

        try {

            $this->requireAuth();


            $id =
                (int)$id;


            if (
                $id <= 0
            ) {

                $this->notFound(
                    'Servicio inválido.'
                );

                return;
            }


            $servicio =
                $this->service->find(
                    $id
                );


            if (
                !$servicio
            ) {

                $this->notFound(
                    'El servicio solicitado no existe.'
                );

                return;
            }


            $assets =
                $this->loadAssets();


            $this->moduleView(
                'ServicioTecnico',
                'ver',
                [
                    'title' =>
                        'Servicio #' . $id,

                    'servicio' =>
                        $servicio,

                    'csrf' =>
                        $this->csrf(),

                    'extraCss' =>
                        $assets['extraCss'],

                    'extraJs' =>
                        $assets['extraJs'],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * EDITAR
     * =========================================================
     */
    public function editar(
        int|string $id
    ): void {

        try {

            $this->requireAuth();


            $id =
                (int)$id;


            if (
                $id <= 0
            ) {

                $this->notFound(
                    'Servicio inválido.'
                );

                return;
            }


            $servicio =
                $this->service->find(
                    $id
                );


            if (
                !$servicio
            ) {

                $this->notFound(
                    'El servicio solicitado no existe.'
                );

                return;
            }


            $clientes =
                $this->service
                    ->obtenerClientes();


            $modelos =
                $this->service
                    ->obtenerModelos();


            $assets =
                $this->loadAssets();


            $this->moduleView(
                'ServicioTecnico',
                'editar',
                [
                    'title' =>
                        'Editar Servicio #' . $id,

                    'servicio' =>
                        $servicio,

                    'clientes' =>
                        is_array($clientes)
                            ? $clientes
                            : [],

                    'modelos' =>
                        is_array($modelos)
                            ? $modelos
                            : [],

                    'csrf' =>
                        $this->csrf(),

                    'extraCss' =>
                        $assets['extraCss'],

                    'extraJs' =>
                        $assets['extraJs'],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * ACTUALIZAR
     * =========================================================
     */
    public function actualizar(): void
    {
        try {

            $this->requireAuth();


            if (
                !$this->validarCsrfModulo()
            ) {

                $this->forbidden(
                    'Token de seguridad inválido o expirado.'
                );

                return;
            }


            $id =
                (int)
                $this->request->post(
                    'id',
                    0
                );


            if (
                $id <= 0
            ) {

                $this->validation([
                    'id' =>
                        'ID de servicio inválido.'
                ]);

                return;
            }


            $estado =
                trim(
                    (string)
                    $this->request->post(
                        'estado',
                        'Pendiente'
                    )
                );


            if (
                !in_array(
                    $estado,
                    self::ESTADOS_PERMITIDOS,
                    true
                )
            ) {

                $estado =
                    'Pendiente';
            }


            $data = [

                'cliente_id' =>
                    (int)
                    $this->request->post(
                        'cliente_id',
                        0
                    ),

                'modelo_id' =>
                    (int)
                    $this->request->post(
                        'modelo_id',
                        0
                    ),

                'equipo_id' =>
                    (int)
                    $this->request->post(
                        'equipo_id',
                        0
                    ),

                'serie' =>
                    trim(
                        (string)
                        $this->request->post(
                            'serie',
                            ''
                        )
                    ),

                'contador_mono' =>
                    (int)
                    $this->request->post(
                        'contador_mono',
                        0
                    ),

                'contador_color' =>
                    (int)
                    $this->request->post(
                        'contador_color',
                        0
                    ),

                'estado' =>
                    $estado,

                'problema' =>
                    trim(
                        (string)
                        $this->request->post(
                            'problema',
                            ''
                        )
                    ),

                'observaciones' =>
                    trim(
                        (string)
                        $this->request->post(
                            'observaciones',
                            ''
                        )
                    ),

                'cables' =>
                    (int)
                    $this->request->post(
                        'cables',
                        0
                    ),

                'fuente' =>
                    (int)
                    $this->request->post(
                        'fuente',
                        0
                    ),
            ];


            $errors = [];


            if (
                $data['modelo_id'] <= 0
                &&
                $data['equipo_id'] <= 0
            ) {

                $errors['modelo_id'] =
                    'Debe seleccionar un modelo de equipo.';
            }


            if (
                $data['problema'] === ''
            ) {

                $errors['problema'] =
                    'Debe indicar el problema o falla.';
            }


            if (
                $data['contador_mono'] < 0
            ) {

                $errors['contador_mono'] =
                    'El contador monocromático no puede ser negativo.';
            }


            if (
                $data['contador_color'] < 0
            ) {

                $errors['contador_color'] =
                    'El contador color no puede ser negativo.';
            }


            if (
                !empty($errors)
            ) {

                $this->validation(
                    $errors
                );

                return;
            }


            $this->service->actualizar(
                $id,
                $data
            );


            $this->redirect(
                '/servicios/ver/' . $id
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * CAMBIAR ESTADO
     * =========================================================
     *
     * POST:
     *
     * /servicios/api/cambiar-estado
     *
     * Parámetros:
     *
     * id
     * estado
     * csrf
     */
    public function cambiarEstado(): void
    {
        try {

            $this->requireAuth();


            /*
             * =================================================
             * CSRF
             * =================================================
             */
            if (
                !$this->validarCsrfModulo()
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'Token de seguridad inválido o expirado.',

                        'errors' =>
                            [],
                    ],
                    403
                );

                return;
            }


            /*
             * =================================================
             * ID
             * =================================================
             */
            $id =
                (int)
                $this->request->post(
                    'id',
                    0
                );


            if (
                $id <= 0
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'ID de servicio inválido.',

                        'errors' =>
                            [
                                'id' =>
                                    'ID de servicio inválido.',
                            ],
                    ],
                    422
                );

                return;
            }


            /*
             * =================================================
             * ESTADO
             * =================================================
             */
            $estado =
                trim(
                    (string)
                    $this->request->post(
                        'estado',
                        ''
                    )
                );


            if (
                !in_array(
                    $estado,
                    self::ESTADOS_PERMITIDOS,
                    true
                )
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'Estado de servicio no válido.',

                        'errors' =>
                            [
                                'estado' =>
                                    'Estado de servicio no válido.',
                            ],
                    ],
                    422
                );

                return;
            }


            /*
             * =================================================
             * VERIFICAR QUE EXISTA
             * =================================================
             */
            $existente =
                $this->service->find(
                    $id
                );


            if (
                !$existente
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'El servicio solicitado no existe.',

                        'errors' =>
                            [
                                'id' =>
                                    'El servicio solicitado no existe.',
                            ],
                    ],
                    404
                );

                return;
            }


            /*
             * =================================================
             * ACTUALIZAR
             * =================================================
             */
            $this->service->cambiarEstado(
                $id,
                $estado
            );


            /*
             * =================================================
             * OBTENER ACTUALIZADO
             * =================================================
             */
            $servicio =
                $this->service->find(
                    $id
                );


            /*
             * =================================================
             * RESPUESTA
             * =================================================
             */
            $this->json(
                [
                    'success' =>
                        true,

                    'message' =>
                        'Estado actualizado correctamente.',

                    'data' =>
                        $servicio,
                ]
            );

        } catch (Throwable $e) {

            /*
             * Nunca devolver HTML al AJAX.
             */
            $this->json(
                [
                    'success' =>
                        false,

                    'message' =>
                        $e->getMessage(),

                    'errors' =>
                        defined('APP_DEBUG')
                        && APP_DEBUG
                            ? [
                                'exception' =>
                                    get_class($e),

                                'file' =>
                                    $e->getFile(),

                                'line' =>
                                    $e->getLine(),
                            ]
                            : [],
                ],
                500
            );
        }
    }


    /**
     * =========================================================
     * HISTORIAL
     * =========================================================
     */
    public function historial(): void
    {
        try {

            $this->requireAuth();


            $texto =
                trim(
                    (string)
                    $this->request->get(
                        'texto',
                        ''
                    )
                );


            $servicios =
                $this->service->historial(
                    $texto
                );


            $assets =
                $this->loadAssets();


            $this->moduleView(
                'ServicioTecnico',
                'historial',
                [
                    'title' =>
                        'Historial de Servicio Técnico',

                    'servicios' =>
                        is_array($servicios)
                            ? $servicios
                            : [],

                    'texto' =>
                        $texto,

                    'csrf' =>
                        $this->csrf(),

                    'extraCss' =>
                        $assets['extraCss'],

                    'extraJs' =>
                        $assets['extraJs'],
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * ELIMINAR
     * =========================================================
     */
    public function eliminar(): void
    {
        try {

            $this->requireAuth();


            if (
                !$this->validarCsrfModulo()
            ) {

                $this->forbidden(
                    'Token de seguridad inválido o expirado.'
                );

                return;
            }


            $id =
                (int)
                $this->request->post(
                    'id',
                    0
                );


            if (
                $id <= 0
            ) {

                $this->validation([
                    'id' =>
                        'ID de servicio inválido.'
                ]);

                return;
            }


            $servicio =
                $this->service->find(
                    $id
                );


            if (
                !$servicio
            ) {

                $this->notFound(
                    'El servicio solicitado no existe.'
                );

                return;
            }


            $this->service->delete(
                $id
            );


            $this->redirect(
                '/servicios/historial'
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * API EQUIPOS
     * =========================================================
     */
    public function apiEquipos(): void
    {
        try {

            $this->requireAuth();


            $clienteId =
                (int)
                $this->request->get(
                    'cliente_id',
                    0
                );


            $equipos =
                $this->service
                    ->obtenerEquipos(
                        $clienteId
                    );


            $this->json(
                [
                    'success' =>
                        true,

                    'data' =>
                        is_array($equipos)
                            ? $equipos
                            : [],
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' =>
                        false,

                    'message' =>
                        $e->getMessage(),

                    'data' =>
                        [],
                ],
                500
            );
        }
    }


    /**
     * =========================================================
     * API CLIENTE
     * =========================================================
     */
    public function apiCliente(): void
    {
        try {

            $this->requireAuth();


            $id =
                (int)
                $this->request->get(
                    'id',
                    0
                );


            if (
                $id <= 0
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'Cliente inválido.',

                        'data' =>
                            null,
                    ],
                    422
                );

                return;
            }


            $cliente =
                $this->service
                    ->obtenerCliente(
                        $id
                    );


            if (
                !$cliente
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'Cliente no encontrado.',

                        'data' =>
                            null,
                    ],
                    404
                );

                return;
            }


            $this->json(
                [
                    'success' =>
                        true,

                    'data' =>
                        $cliente,
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' =>
                        false,

                    'message' =>
                        $e->getMessage(),

                    'data' =>
                        null,
                ],
                500
            );
        }
    }


    /**
     * =========================================================
     * CREAR CLIENTE
     * =========================================================
     */
    public function crearCliente(): void
    {
        try {

            $this->requireAuth();


            if (
                !$this->validarCsrfModulo()
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'Token de seguridad inválido o expirado.',

                        'errors' =>
                            [],
                    ],
                    403
                );

                return;
            }


            $data = [

                'nombre' =>
                    trim(
                        (string)
                        $this->request->post(
                            'nombre',
                            ''
                        )
                    ),

                'nombre_fantasia' =>
                    trim(
                        (string)
                        $this->request->post(
                            'nombre_fantasia',
                            ''
                        )
                    ),

                'tipo_cliente' =>
                    trim(
                        (string)
                        $this->request->post(
                            'tipo_cliente',
                            'Externo'
                        )
                    ),

                'localidad_id' =>
                    (int)
                    $this->request->post(
                        'localidad_id',
                        0
                    ),

                'direccion' =>
                    trim(
                        (string)
                        $this->request->post(
                            'direccion',
                            ''
                        )
                    ),

                'persona_contacto' =>
                    trim(
                        (string)
                        $this->request->post(
                            'persona_contacto',
                            ''
                        )
                    ),

                'telefono' =>
                    trim(
                        (string)
                        $this->request->post(
                            'telefono',
                            ''
                        )
                    ),

                'email' =>
                    trim(
                        (string)
                        $this->request->post(
                            'email',
                            ''
                        )
                    ),

                'tipo_doc' =>
                    trim(
                        (string)
                        $this->request->post(
                            'tipo_doc',
                            'CUIT'
                        )
                    ),

                'nro_doc' =>
                    trim(
                        (string)
                        $this->request->post(
                            'nro_doc',
                            ''
                        )
                    ),

                'categoria_fiscal' =>
                    trim(
                        (string)
                        $this->request->post(
                            'categoria_fiscal',
                            ''
                        )
                    ),
            ];


            if (
                $data['nombre'] === ''
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'El nombre del cliente es obligatorio.',
                    ],
                    422
                );

                return;
            }


            $id =
                $this->service->crearCliente(
                    $data
                );


            $cliente =
                $this->service->obtenerCliente(
                    $id
                );


            $this->json(
                [
                    'success' =>
                        true,

                    'message' =>
                        'Cliente creado correctamente.',

                    'data' =>
                        $cliente,
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' =>
                        false,

                    'message' =>
                        $e->getMessage(),

                    'data' =>
                        null,
                ],
                500
            );
        }
    }


    /**
     * =========================================================
     * CREAR MODELO
     * =========================================================
     */
    public function crearModelo(): void
    {
        try {

            $this->requireAuth();


            if (
                !$this->validarCsrfModulo()
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'Token de seguridad inválido o expirado.',

                        'errors' =>
                            [],
                    ],
                    403
                );

                return;
            }


            $data = [

                'nombre_modelo' =>
                    trim(
                        (string)
                        $this->request->post(
                            'nombre_modelo',
                            ''
                        )
                    ),

                'marca' =>
                    trim(
                        (string)
                        $this->request->post(
                            'marca',
                            ''
                        )
                    ),

                'tipo' =>
                    trim(
                        (string)
                        $this->request->post(
                            'tipo',
                            'Mono'
                        )
                    ),
            ];


            if (
                $data['nombre_modelo'] === ''
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'El modelo es obligatorio.',
                    ],
                    422
                );

                return;
            }


            if (
                $data['marca'] === ''
            ) {

                $this->json(
                    [
                        'success' =>
                            false,

                        'message' =>
                            'La marca es obligatoria.',
                    ],
                    422
                );

                return;
            }


            $id =
                $this->service->crearModelo(
                    $data
                );


            $modelo =
                $this->service->obtenerModelo(
                    $id
                );


            $this->json(
                [
                    'success' =>
                        true,

                    'message' =>
                        'Modelo creado correctamente.',

                    'data' =>
                        $modelo,
                ]
            );

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' =>
                        false,

                    'message' =>
                        $e->getMessage(),

                    'data' =>
                        null,
                ],
                500
            );
        }
    }


    /**
     * =========================================================
     * EXPORTAR EXCEL
     * =========================================================
     */
    public function exportarExcel(): void
    {
        try {

            $this->requireAuth();

            $this->service->exportarExcel();

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * PDF INDIVIDUAL
     * =========================================================
     */
    public function pdf(
        int|string $id
    ): void {

        try {

            $this->requireAuth();


            $id =
                (int)$id;


            if (
                $id <= 0
            ) {

                $this->notFound(
                    'Servicio inválido.'
                );

                return;
            }


            if (
                !$this->service->find(
                    $id
                )
            ) {

                $this->notFound(
                    'El servicio solicitado no existe.'
                );

                return;
            }


            $this->service->pdf(
                $id
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }


    /**
     * =========================================================
     * PDF GENERAL
     * =========================================================
     */
    public function exportarPdf(): void
    {
        try {

            $this->requireAuth();

            $this->service->exportarPdf();

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }
}