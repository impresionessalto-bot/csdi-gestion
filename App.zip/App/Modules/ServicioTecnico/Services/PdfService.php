<?php

declare(strict_types=1);

namespace App\Modules\ServicioTecnico\Services;

use RuntimeException;

/**
 * Generador PDF autónomo para Servicio Técnico.
 *
 * No depende de Dompdf, TCPDF, exec(), shell_exec() ni binarios externos.
 * Genera un PDF estándar con las primitivas PDF necesarias para impresión.
 */
final class PdfService
{
    public function emitirServicio(array $servicio): void
    {
        $id = (int)($servicio['id'] ?? 0);
        if ($id <= 0) {
            throw new RuntimeException('Servicio inválido para generar PDF.');
        }

        $fecha = $this->fecha($servicio['fecha_solicitud'] ?? $servicio['fecha'] ?? null);
        $cliente = $this->first($servicio, ['cliente_nombre_fantasia', 'cliente_nombre'], 'Taller General');
        $modelo = $this->first($servicio, ['modelo_oficial'], '-');
        $marca = $this->first($servicio, ['marca'], '');
        $serie = $this->first($servicio, ['equipo_serie', 'serie'], 'Sin especificar');
        $estado = $this->first($servicio, ['estado'], 'Pendiente');
        $problema = $this->first($servicio, ['descripcion_problema', 'problema'], 'Sin descripción');
        $observaciones = $this->first($servicio, ['observaciones'], 'Ninguna');
        $solucion = $this->first($servicio, ['solucion_aplicada'], '');
        $cables = ((int)($servicio['cables'] ?? 0)) ? 'Si' : 'No';
        $fuente = ((int)($servicio['fuente'] ?? 0)) ? 'Si' : 'No';
        $mono = $this->first($servicio, ['contador_mono'], '0');
        $color = $this->first($servicio, ['contador_color'], '0');
        $codigo = $this->first($servicio, ['equipo_codigo'], '');
        $propiedad = $this->first($servicio, ['equipo_propiedad', 'propiedad'], '');
        $telefono = $this->first($servicio, ['cliente_telefono'], '');
        $email = $this->first($servicio, ['cliente_email'], '');

        $lines = [
            'CSDI ERP PRO',
            'SERVICIO TECNICO - COMPROBANTE DE INGRESO',
            '',
            'ORDEN DE SERVICIO: #' . $id,
            'Fecha: ' . $fecha,
            'Estado: ' . $estado,
            '',
            'DATOS DEL CLIENTE',
            'Cliente: ' . $cliente,
        ];
        if ($telefono !== '') $lines[] = 'Telefono: ' . $telefono;
        if ($email !== '') $lines[] = 'Email: ' . $email;
        $lines[] = '';
        $lines[] = 'DATOS DEL EQUIPO';
        $lines[] = 'Marca: ' . ($marca !== '' ? $marca : '-');
        $lines[] = 'Modelo: ' . $modelo;
        $lines[] = 'Nro. de serie: ' . $serie;
        if ($codigo !== '') $lines[] = 'Codigo interno: ' . $codigo;
        if ($propiedad !== '') $lines[] = 'Propiedad: ' . $propiedad;
        $lines[] = 'Contador B/N: ' . $mono;
        $lines[] = 'Contador color: ' . $color;
        $lines[] = 'Cables: ' . $cables . '    Fuente: ' . $fuente;
        $lines[] = '';
        $lines[] = 'REPORTE DE FALLA';
        foreach ($this->wrap($problema, 92) as $line) $lines[] = $line;
        $lines[] = '';
        if ($solucion !== '') {
            $lines[] = '';
            $lines[] = 'SOLUCION / TRABAJO REALIZADO';
            foreach ($this->wrap($solucion, 92) as $line) $lines[] = $line;
        }
        $lines[] = '';
        $lines[] = 'OBSERVACIONES / ACCESORIOS';
        foreach ($this->wrap($observaciones, 92) as $line) $lines[] = $line;
        $lines[] = '';
        $lines[] = 'Firma del cliente: ______________________________';
        $lines[] = '';
        $lines[] = 'Firma / sello taller: ___________________________';

        $this->sendPdf('orden-servicio-' . $id . '.pdf', $lines, 'Orden de Servicio #' . $id);
    }

    public function emitirListado(array $servicios): void
    {
        $lines = [
            'CSDI ERP PRO',
            'SERVICIO TECNICO - LISTADO DE ORDENES',
            'Generado: ' . date('d/m/Y H:i'),
            '',
            'ID       FECHA       ESTADO           CLIENTE / EQUIPO',
            str_repeat('-', 96),
        ];

        foreach ($servicios as $servicio) {
            $id = (string)($servicio['id'] ?? '');
            $fecha = $this->fecha($servicio['fecha_solicitud'] ?? $servicio['fecha'] ?? null);
            $estado = $this->first($servicio, ['estado'], '');
            $cliente = $this->first($servicio, ['cliente_nombre_fantasia', 'cliente_nombre'], '');
            $modelo = $this->first($servicio, ['modelo_oficial'], '');
            $serie = $this->first($servicio, ['equipo_serie', 'serie'], '');
            $equipo = trim($modelo . ($serie !== '' ? ' / ' . $serie : ''));
            $lines[] = sprintf('%-8s %-12s %-16s %s', $id, $fecha, $estado, $cliente);
            if ($equipo !== '') $lines[] = '         Equipo: ' . $equipo;
        }

        if (count($servicios) === 0) {
            $lines[] = 'No hay ordenes de servicio para mostrar.';
        }

        $this->sendPdf('servicios-tecnicos-' . date('Ymd-His') . '.pdf', $lines, 'Listado de Servicios Tecnicos');
    }

    private function sendPdf(string $filename, array $lines, string $title): void
    {
        $pdf = $this->buildPdf($lines, $title);

        if (headers_sent()) {
            throw new RuntimeException('No se puede enviar el PDF porque ya se enviaron encabezados.');
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . $this->safeFilename($filename) . '"');
        header('Content-Length: ' . strlen($pdf));
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        echo $pdf;
        exit;
    }

    private function buildPdf(array $lines, string $title): string
    {
        $pages = array_chunk($lines, 48);
        if ($pages === []) $pages = [['']];

        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $pageRefs = [];
        $next = 4;
        foreach ($pages as $pageIndex => $pageLines) {
            $contentObject = $next++;
            $pageObject = $next++;
            $pageRefs[] = $pageObject . ' 0 R';

            $content = "BT\n/F1 11 Tf\n50 790 Td\n14 TL\n";
            $first = true;
            foreach ($pageLines as $line) {
                if (!$first) $content .= "T*\n";
                $first = false;
                $content .= '(' . $this->pdfText((string)$line) . ") Tj\n";
            }
            $content .= "ET\n";

            $objects[$contentObject] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "endstream";
            $objects[$pageObject] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ' . $contentObject . ' 0 R >>';
        }

        $kids = implode(' ', $pageRefs);
        $objects[2] = '<< /Type /Pages /Kids [' . $kids . '] /Count ' . count($pageRefs) . ' >>';
        $objects[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';

        ksort($objects);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [0 => 0];
        $max = max(array_keys($objects));
        for ($i = 1; $i <= $max; $i++) {
            $offsets[$i] = strlen($pdf);
            $pdf .= $i . " 0 obj\n" . ($objects[$i] ?? '<<>>') . "\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . ($max + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R /Info << /Title (" . $this->pdfText($title) . ") >> >>\n";
        $pdf .= "startxref\n" . $xref . "\n%%EOF\n";
        return $pdf;
    }

    private function pdfText(string $text): string
    {
        $text = str_replace(["\r", "\n", "\t"], ' ', $text);
        if (function_exists('iconv')) {
            $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT', $text);
            if ($converted !== false) $text = $converted;
        }
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    }

    private function wrap(string $text, int $width): array
    {
        $text = trim(preg_replace('/\s+/u', ' ', str_replace(["\r", "\n"], ' ', $text)) ?? '');
        if ($text === '') return ['-'];
        return explode("\n", wordwrap($text, $width, "\n", true));
    }

    private function first(array $data, array $keys, string $default): string
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $data) && trim((string)$data[$key]) !== '') {
                return trim((string)$data[$key]);
            }
        }
        return $default;
    }

    private function fecha(mixed $value): string
    {
        $value = trim((string)$value);
        if ($value === '') return date('d/m/Y H:i');
        $timestamp = strtotime($value);
        return $timestamp !== false ? date('d/m/Y H:i', $timestamp) : $value;
    }

    private function safeFilename(string $filename): string
    {
        return preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) ?: 'documento.pdf';
    }
}
