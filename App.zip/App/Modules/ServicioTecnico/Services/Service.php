<?php

declare(strict_types=1);

namespace App\Modules\ServicioTecnico\Services;

use App\Services\DragAndDropService;
use App\Modules\ServicioTecnico\Repositories\Repository;
use App\Modules\Clientes\Services\Service as ClienteService;
use App\Modules\Equipos\Services\Service as EquipoService;
use RuntimeException;
use App\Modules\ServicioTecnico\Services\PdfService;

final class Service
{
    public function __construct(
        private readonly Repository $repository,
        private readonly ?ClienteService $clienteService = null,
        private readonly ?EquipoService $equipoService = null,
        private readonly ?DragAndDropService $dragAndDropService = null,
        private readonly ?PdfService $pdfService = null
    ) {
    }


    /**
     * =========================================================
     * TOTAL
     * =========================================================
     */
    public function count(): int
    {
        return $this->repository->count();
    }


    /**
     * =========================================================
     * LISTAR
     * =========================================================
     */
    public function listar(
        array $filtros = []
    ): array {

        return $this->repository->listar(
            $filtros
        );
    }


    /**
     * =========================================================
     * FIND
     * =========================================================
     */
    public function find(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }

        $data =
            $this->repository->find(
                $id
            );

        return is_array($data)
            ? $data
            : null;
    }


    /**
     * =========================================================
     * BUSCAR EQUIPOS
     * =========================================================
     */
    public function buscarEquipos(
        string $texto = ''
    ): array {

        if ($this->equipoService === null) {
            throw new RuntimeException(
                'El servicio de Equipos no está disponible.'
            );
        }

        return $this->equipoService->listar([
            'texto' => trim($texto),
        ]);
    }


    /**
     * =========================================================
     * CREAR
     * =========================================================
     */
    public function crear(
        array $data
    ): int {

        if (empty($data)) {

            throw new RuntimeException(
                'Datos de servicio vacíos.'
            );
        }


        $clienteId =
            (int)(
                $data['cliente_id']
                ?? 0
            );


        $modeloId =
            (int)(
                $data['modelo_id']
                ?? 0
            );


        $equipoId =
            (int)(
                $data['equipo_id']
                ?? 0
            );


        $serie =
            trim(
                (string)(
                    $data['serie']
                    ?? ''
                )
            );


        /*
         * Si ya existe equipo utilizamos ese equipo.
         *
         * Si no existe equipo pero existe modelo,
         * generamos/obtenemos el equipo.
         */
        if (
            $equipoId <= 0
            &&
            $modeloId > 0
        ) {

            $equipoId =
                $this->repository
                    ->obtenerOCrearEquipo(
                        $clienteId,
                        $modeloId,
                        $serie
                    );
        }


        if ($equipoId <= 0) {

            throw new RuntimeException(
                'No fue posible determinar el equipo.'
            );
        }


        $data['equipo_id'] =
            $equipoId;


        return $this->repository->crear(
            $data
        );
    }


    /**
     * =========================================================
     * ACTUALIZAR
     * =========================================================
     */
    public function actualizar(
        int $id,
        array $data
    ): void {

        if ($id <= 0) {

            throw new RuntimeException(
                'ID de servicio inválido.'
            );
        }


        $this->repository->actualizar(
            $id,
            $data
        );
    }


    /**
     * =========================================================
     * CAMBIAR ESTADO
     *
     * Utiliza DragAndDropService global.
     * =========================================================
     */
    public function cambiarEstado(
        int $id,
        string $estado
    ): array {

        $estadosPermitidos = [

            'Pendiente',

            'En Proceso',

            'En Reparacion',

            'Finalizado',
        ];


        if ($id <= 0) {

            throw new RuntimeException(
                'ID de servicio inválido.'
            );
        }


        $estado =
            trim($estado);


        if ($estado === '') {

            throw new RuntimeException(
                'El estado es obligatorio.'
            );
        }


        if (!in_array(
            $estado,
            $estadosPermitidos,
            true
        )) {

            throw new RuntimeException(
                'El estado seleccionado no es válido.'
            );
        }


        /*
         * -----------------------------------------------------
         * SERVICIO GLOBAL
         * -----------------------------------------------------
         */

        if (
            $this->dragAndDropService !== null
        ) {

            return $this->dragAndDropService
                ->cambiarEstado(
                    'servicios',
                    $id,
                    $estado,
                    $estadosPermitidos,
                    'id',
                    'estado'
                );
        }


        /*
         * -----------------------------------------------------
         * FALLBACK
         * -----------------------------------------------------
         *
         * Mantiene compatibilidad si el Container todavía
         * no está inyectando DragAndDropService.
         */

        $servicioAnterior =
            $this->repository->find(
                $id
            );


        if (!$servicioAnterior) {

            throw new RuntimeException(
                'El servicio no existe.'
            );
        }


        $estadoAnterior =
            (string)(
                $servicioAnterior['estado']
                ?? ''
            );


        if (
            $estadoAnterior ===
            $estado
        ) {

            return [
                'id' =>
                    $id,

                'estado_anterior' =>
                    $estadoAnterior,

                'estado' =>
                    $estado,

                'cambio' =>
                    false,
            ];
        }


        $this->repository->cambiarEstado(
            $id,
            $estado
        );


        return [
            'id' =>
                $id,

            'estado_anterior' =>
                $estadoAnterior,

            'estado' =>
                $estado,

            'cambio' =>
                true,
        ];
    }


    /**
     * =========================================================
     * ELIMINAR
     * =========================================================
     */
    public function delete(
        int $id
    ): void {

        if ($id <= 0) {

            throw new RuntimeException(
                'ID inválido.'
            );
        }


        $this->repository->delete(
            $id
        );
    }


    /**
     * =========================================================
     * KPIS
     * =========================================================
     */
    public function obtenerKpis(): array
    {
        return array_merge(
            [
                'total' =>
                    0,

                'pendientes' =>
                    0,

                'en_proceso' =>
                    0,

                'en_reparacion' =>
                    0,

                'finalizados' =>
                    0,
            ],
            $this->repository->obtenerKpis()
        );
    }


    /**
     * =========================================================
     * CLIENTES
     * =========================================================
     */
    public function obtenerClientes(): array
    {
        if (
            $this->clienteService !== null
            &&
            method_exists(
                $this->clienteService,
                'listar'
            )
        ) {

            $data =
                $this->clienteService
                    ->listar([]);


            if (is_array($data)) {
                return $data;
            }
        }


        return $this->repository
            ->obtenerClientes();
    }


    /**
     * =========================================================
     * CLIENTE
     * =========================================================
     */
    public function obtenerCliente(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }


        return $this->repository
            ->obtenerCliente(
                $id
            );
    }


    /**
     * =========================================================
     * CREAR CLIENTE
     * =========================================================
     */
    public function crearCliente(
        array $data
    ): int {

        $nombre =
            trim(
                (string)(
                    $data['nombre']
                    ?? ''
                )
            );


        if ($nombre === '') {

            throw new RuntimeException(
                'El nombre del cliente es obligatorio.'
            );
        }


        return $this->repository
            ->crearCliente(
                $data
            );
    }


    /**
     * =========================================================
     * MODELOS
     * =========================================================
     */
    public function obtenerModelos(): array
    {
        if (
            $this->equipoService !== null
            &&
            method_exists(
                $this->equipoService,
                'obtenerModelos'
            )
        ) {

            $data =
                $this->equipoService
                    ->obtenerModelos();


            if (is_array($data)) {
                return $data;
            }
        }


        return $this->repository
            ->obtenerModelos();
    }


    /**
     * =========================================================
     * MODELO
     * =========================================================
     */
    public function obtenerModelo(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }


        return $this->repository
            ->obtenerModelo(
                $id
            );
    }


    /**
     * =========================================================
     * CREAR MODELO
     * =========================================================
     */
    public function crearModelo(
        array $data
    ): int {

        $marca =
            trim(
                (string)(
                    $data['marca']
                    ?? ''
                )
            );


        $modelo =
            trim(
                (string)(
                    $data['nombre_modelo']
                    ?? ''
                )
            );


        if ($marca === '') {

            throw new RuntimeException(
                'La marca es obligatoria.'
            );
        }


        if ($modelo === '') {

            throw new RuntimeException(
                'El modelo es obligatorio.'
            );
        }


        return $this->repository
            ->crearModelo(
                $data
            );
    }


    /**
     * =========================================================
     * EQUIPOS
     * =========================================================
     */
    public function obtenerEquipos(
        int $clienteId = 0
    ): array {

        return $this->repository
            ->obtenerEquipos(
                $clienteId
            );
    }


    /**
     * =========================================================
     * HISTORIAL
     * =========================================================
     */
    public function historial(
        string $texto = ''
    ): array {

        return $this->repository
            ->historial(
                $texto
            );
    }


    /**
     * =========================================================
     * INDEX
     * =========================================================
     */
    public function index(
        array $filtros = []
    ): array {

        return [

            'servicios' =>
                $this->listar(
                    $filtros
                ),

            'kpis' =>
                $this->obtenerKpis(),
        ];
    }


    /**
     * =========================================================
     * DASHBOARD
     * =========================================================
     */
    public function dashboard(): array
    {
        return [

            'kpis' =>
                $this->obtenerKpis(),

            'servicios' =>
                $this->listar(),
        ];
    }


    /**
     * =========================================================
     * ESTADÍSTICAS
     * =========================================================
     */
    public function estadisticas(): array
    {
        return [

            'kpis' =>
                $this->obtenerKpis(),

            'total' =>
                $this->count(),
        ];
    }


    /**
     * =========================================================
     * EXPORTAR EXCEL
     * =========================================================
     */
    public function exportarExcel(): void
    {
        throw new RuntimeException(
            'La exportación Excel todavía no está conectada.'
        );
    }


    /**
     * =========================================================
     * PDF INDIVIDUAL
     * =========================================================
     */
    public function pdf(
        int $id
    ): void {
        if ($id <= 0) {
            throw new RuntimeException('ID de servicio inválido.');
        }

        $servicio = $this->find($id);

        if (!$servicio) {
            throw new RuntimeException('El servicio solicitado no existe.');
        }

        $pdf = $this->pdfService ?? new PdfService();
        $pdf->emitirServicio($servicio);
    }


    /**
     * =========================================================
     * EXPORTAR PDF
     * =========================================================
     */
    public function exportarPdf(): void
    {
        $servicios = $this->listar();
        $pdf = $this->pdfService ?? new PdfService();
        $pdf->emitirListado($servicios);
    }
}