<?php
declare(strict_types=1);

$servicio = is_array($servicio ?? null) ? $servicio : [];
$csrf = (string)($csrf ?? '');

if (!function_exists('e')) {
    function e(mixed $value): string {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

// Variables base
$id = (int)($servicio['id'] ?? 0);
$estadoActual = trim((string)($servicio['estado'] ?? 'Pendiente'));

?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2><i class="fa-solid fa-file-lines text-primary me-2"></i>Orden de Servicio #<?= e($id) ?></h2>
            <p class="text-muted mb-0">Detalle técnico e historial del equipo en taller.</p>
        </div>
        <div class="btn-group">
            <a href="/servicios/exportar-pdf/<?= e($id) ?>" target="_blank" class="btn btn-danger">
                <i class="fa-solid fa-print me-1"></i> Imprimir Parte
            </a>
            <a href="/servicios" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver
            </a>
        </div>
    </div>

    <?php if ($id <= 0): ?>
        <div class="alert alert-warning shadow-sm border-0">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> El servicio solicitado no es válido o no existe.
        </div>
    <?php else: ?>
        <div class="row g-4">
            
            <!-- COLUMNA PRINCIPAL -->
            <div class="col-md-8">
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-primary text-white fw-bold border-0">
                        Información General del Equipo
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <strong>Cliente:</strong> 
                                <span class="text-secondary"><?= e($servicio['cliente_nombre'] ?? 'Taller General') ?></span>
                            </div>
                            <div class="col-md-6">
                                <strong>Modelo:</strong> 
                                <span class="text-secondary"><?= e($servicio['modelo_oficial'] ?? '-') ?></span>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <strong>Nro de Serie:</strong> 
                                <span class="text-secondary"><?= e($servicio['serie'] ?? 'Sin especificar') ?></span>
                            </div>
                            <div class="col-md-6">
                                <strong>Estado Actual:</strong> 
                                <span class="badge bg-info text-dark"><?= e($estadoActual) ?></span>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <strong>Contador Monocromático:</strong> 
                                <span class="text-secondary"><?= e($servicio['contador_mono'] ?? 0) ?></span>
                            </div>
                            <div class="col-md-6">
                                <strong>Contador Color:</strong> 
                                <span class="text-secondary"><?= e($servicio['contador_color'] ?? 0) ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm border-0">
                    <div class="card-header bg-dark text-white fw-bold border-0">
                        Diagnóstico y Trabajos Realizados
                    </div>
                    <div class="card-body">
                        <p class="fw-bold mb-1">Problema Reportado:</p>
                        <p class="p-3 bg-light rounded text-secondary border">
                            <?= nl2br(e($servicio['problema'] ?? 'Sin descripción')) ?>
                        </p>

                        <p class="fw-bold mb-1 mt-3">Observaciones Internas:</p>
                        <p class="p-3 bg-light rounded text-secondary border">
                            <?= nl2br(e($servicio['observaciones'] ?? 'Ninguna')) ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- COLUMNA SECUNDARIA (Acciones Rápidas) -->
            <div class="col-md-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-secondary text-white fw-bold border-0">
                        Acciones Rápidas
                    </div>
                    <div class="card-body">
                        <form method="POST" action="/servicios/actualizar">
                            
                            <!-- Token CSRF -->
                            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                            
                            <!-- Campos ocultos para evitar pérdida de datos en el Controller -->
                            <input type="hidden" name="id" value="<?= e($id) ?>">
                            <input type="hidden" name="cliente_id" value="<?= e($servicio['cliente_id'] ?? 0) ?>">
                            <input type="hidden" name="modelo_id" value="<?= e($servicio['modelo_id'] ?? 0) ?>">
                            <input type="hidden" name="equipo_id" value="<?= e($servicio['equipo_id'] ?? 0) ?>">
                            <input type="hidden" name="serie" value="<?= e($servicio['serie'] ?? '') ?>">
                            <input type="hidden" name="contador_mono" value="<?= e($servicio['contador_mono'] ?? 0) ?>">
                            <input type="hidden" name="contador_color" value="<?= e($servicio['contador_color'] ?? 0) ?>">
                            <input type="hidden" name="problema" value="<?= e($servicio['problema'] ?? '') ?>">
                            <input type="hidden" name="observaciones" value="<?= e($servicio['observaciones'] ?? '') ?>">
                            <input type="hidden" name="cables" value="<?= e($servicio['cables'] ?? 0) ?>">
                            <input type="hidden" name="fuente" value="<?= e($servicio['fuente'] ?? 0) ?>">
                            
                            <!-- Selector de Estado -->
                            <div class="mb-3">
                                <label class="form-label fw-bold">Cambiar Estado</label>
                                <select name="estado" class="form-select">
                                    <option value="Pendiente" <?= $estadoActual === 'Pendiente' ? 'selected' : '' ?>>Pendiente</option>
                                    <option value="En Proceso" <?= $estadoActual === 'En Proceso' ? 'selected' : '' ?>>En Diagnóstico</option>
                                    <option value="En Reparacion" <?= $estadoActual === 'En Reparacion' ? 'selected' : '' ?>>En Reparación</option>
                                    <option value="Finalizado" <?= $estadoActual === 'Finalizado' ? 'selected' : '' ?>>Finalizado</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-success w-100">
                                <i class="fa-solid fa-save me-1"></i> Actualizar Orden
                            </button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    <?php endif; ?>
</div>