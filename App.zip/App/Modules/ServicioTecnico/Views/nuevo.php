<?php

declare(strict_types=1);

$clientes = is_array($clientes ?? null) ? $clientes : [];
$modelos  = is_array($modelos ?? null) ? $modelos : [];
$csrf     = (string)($csrf ?? '');

if (!function_exists('e')) {
    function e(mixed $value): string {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}
?>

<div 
    class="container-fluid py-4 servicio-tecnico-container" 
    data-servicio-tecnico 
    data-csrf="<?= e($csrf) ?>"
>

    <!-- =====================================================
         HEADER
         ===================================================== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <div class="d-flex align-items-center gap-2">
                <div class="st-title-icon">
                    <i class="bi bi-tools"></i>
                </div>
                <div>
                    <h1 class="h3 fw-bold mb-0">Nuevo ingreso a Servicio Técnico</h1>
                    <p class="text-muted mb-0">Registrar equipo, falla y estado inicial del servicio.</p>
                </div>
            </div>
        </div>
        <a href="/servicios" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Volver al taller
        </a>
    </div>

    <!-- =====================================================
         FORMULARIO
         ===================================================== -->
    <form method="post" action="/servicios" id="formNuevoServicio">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

        <div class="row g-4">
            
            <!-- =================================================
                 COLUMNA PRINCIPAL
                 ================================================= -->
            <div class="col-12 col-xl-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3">
                        <div class="d-flex align-items-center gap-2">
                            <i class="bi bi-person text-primary"></i>
                            <strong>Cliente y equipo</strong>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row g-3">

                            <!-- CLIENTE -->
                            <div class="col-12">
                                <label for="cliente_id" class="form-label fw-semibold">Cliente propietario</label>
                                <div class="input-group">
                                    <select name="cliente_id" id="cliente_id" class="form-select">
                                        <option value="0">Taller General — sin cliente</option>
                                        <?php foreach ($clientes as $cliente): ?>
                                            <?php
                                            $clienteId = (int)($cliente['id'] ?? 0);
                                            if ($clienteId <= 0) continue;
                                            
                                            $clienteNombre = trim((string)($cliente['nombre'] ?? ''));
                                            if ($clienteNombre === '') $clienteNombre = 'Cliente #' . $clienteId;
                                            ?>
                                            <option value="<?= e($clienteId) ?>"><?= e($clienteNombre) ?></option>
                                        <?php endforeach; ?>
                                    </select>

                                    <a href="/admin/clientes/crear" class="btn btn-outline-primary" title="Crear cliente en Base de datos">
                                        <i class="bi bi-plus-lg"></i>
                                    </a>
                                    <button type="button" class="btn btn-outline-secondary" id="btnInfoCliente" title="Información del cliente" disabled>
                                        <i class="bi bi-info-circle"></i>
                                    </button>
                                </div>
                                <div class="form-text">
                                    Los clientes se administran desde <a href="/admin/clientes" class="text-decoration-none">Base de datos → Clientes</a>.
                                </div>
                            </div>

                            <!-- MODELO -->
                            <div class="col-12 col-md-8">
                                <label class="form-label fw-semibold">Modelo de equipo <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <select name="modelo_id" id="modelo_id" class="form-select" required>
                                        <option value="">Seleccione un modelo...</option>
                                        <?php foreach ($modelos as $modelo): ?>
                                            <option 
                                                value="<?= (int)($modelo['id'] ?? 0) ?>" 
                                                data-tipo="<?= e($modelo['tipo'] ?? 'Mono') ?>"
                                            >
                                                <?= e($modelo['marca'] ?? 'General') ?> — <?= e($modelo['nombre_modelo'] ?? '') ?> · <?= e($modelo['tipo'] ?? 'Mono') ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalNuevoModelo" title="Nuevo modelo">
                                        <i class="bi bi-plus-lg"></i>
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary" id="btnInfoModelo" title="Información del modelo" disabled>
                                        <i class="bi bi-info-circle"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- SERIE -->
                            <div class="col-12 col-md-4">
                                <label class="form-label fw-semibold">Número de serie</label>
                                <input type="text" name="serie" id="serie" class="form-control" placeholder="Ej. C12345678">
                            </div>

                            <!-- ESTADO -->
                            <div class="col-12 col-md-6">
                                <label class="form-label fw-semibold">Estado inicial</label>
                                <select name="estado" class="form-select">
                                    <option value="Pendiente" selected>Ingresado</option>
                                    <option value="En Proceso">En Diagnóstico</option>
                                    <option value="En Reparacion">En Reparación</option>
                                    <option value="Finalizado">Finalizado</option>
                                </select>
                            </div>

                            <!-- ESTADO DE RECEPCIÓN -->
                            <div class="col-12">
                                <div class="st-section-title mb-3">
                                    <i class="bi bi-box-seam"></i> Estado de recepción
                                </div>
                                <div class="row g-3">
                                    
                                    <!-- CABLES -->
                                    <div class="col-12 col-md-6">
                                        <div class="st-check-card" id="cardCables">
                                            <div class="form-check form-switch m-0">
                                                <input class="form-check-input" type="checkbox" role="switch" id="cables" name="cables" value="1">
                                                <label class="form-check-label fw-semibold ms-2" for="cables">
                                                    <i class="bi bi-plug me-1"></i> Cables
                                                </label>
                                            </div>
                                            <small class="text-muted">¿Ingresa con sus cables?</small>
                                        </div>
                                    </div>

                                    <!-- FUENTE -->
                                    <div class="col-12 col-md-6">
                                        <div class="st-check-card" id="cardFuente">
                                            <div class="form-check form-switch m-0">
                                                <input class="form-check-input" type="checkbox" role="switch" id="fuente" name="fuente" value="1">
                                                <label class="form-check-label fw-semibold ms-2" for="fuente">
                                                    <i class="bi bi-lightning-charge me-1"></i> Fuente
                                                </label>
                                            </div>
                                            <small class="text-muted">¿Ingresa con su fuente?</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- CONTADORES -->
                            <div class="col-12">
                                <div class="st-section-title">
                                    <i class="bi bi-speedometer2"></i> Contadores
                                </div>
                            </div>

                            <div class="col-12 col-md-6" id="bloque_contador_mono">
                                <label class="form-label">Contador monocromático</label>
                                <input type="number" name="contador_mono" class="form-control" min="0" value="0" required>
                            </div>

                            <div class="col-12 col-md-6 d-none" id="bloque_contador_color">
                                <label class="form-label text-primary">Contador color</label>
                                <input type="number" name="contador_color" class="form-control" min="0" value="0" required>
                            </div>

                            <!-- PROBLEMA -->
                            <div class="col-12">
                                <label class="form-label fw-semibold">Descripción del problema / falla <span class="text-danger">*</span></label>
                                <textarea name="problema" class="form-control" rows="4" placeholder="Detalle la falla reportada por el cliente..." required></textarea>
                            </div>

                            <!-- OBSERVACIONES -->
                            <div class="col-12">
                                <label class="form-label fw-semibold">Observaciones internas</label>
                                <textarea name="observaciones" class="form-control" rows="3" placeholder="Accesorios, estado estético, golpes, cables, fuente, etc."></textarea>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- =================================================
                 RESUMEN LATERAl
                 ================================================= -->
            <div class="col-12 col-xl-4">
                <div class="card border-0 shadow-sm sticky-xl-top st-summary-card">
                    <div class="card-header bg-white py-3">
                        <strong><i class="bi bi-clipboard-check me-1"></i> Resumen del ingreso</strong>
                    </div>

                    <div class="card-body">
                        <div class="st-summary-row">
                            <span>Cliente</span>
                            <strong id="resumenCliente">Taller General</strong>
                        </div>
                        <div class="st-summary-row">
                            <span>Equipo</span>
                            <strong id="resumenModelo">Sin seleccionar</strong>
                        </div>
                        <div class="st-summary-row">
                            <span>Serie</span>
                            <strong id="resumenSerie">—</strong>
                        </div>
                        <div class="st-summary-row">
                            <span>Cables</span>
                            <strong id="resumenCables">No</strong>
                        </div>
                        <div class="st-summary-row">
                            <span>Fuente</span>
                            <strong id="resumenFuente">No</strong>
                        </div>
                        <hr>
                        <div class="alert alert-info small mb-0">
                            <i class="bi bi-info-circle me-1"></i>
                            El equipo quedará vinculado al cliente y al modelo seleccionado al registrar el ingreso.
                        </div>
                    </div>

                    <div class="card-footer bg-white border-0 p-3">
                        <button type="submit" class="btn btn-primary w-100 btn-lg">
                            <i class="bi bi-save me-2"></i> Registrar ingreso
                        </button>
                    </div>
                </div>
            </div>

        </div>
    </form>
</div>

<!-- =========================================================
     MODAL NUEVO CLIENTE
     ========================================================= -->
<div class="modal fade" id="modalNuevoCliente" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i> Nuevo cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            
            <form id="formNuevoCliente">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nombre / Razón social *</label>
                        <input type="text" name="nombre" class="form-control" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Tipo documento</label>
                            <select name="tipo_doc" class="form-select">
                                <option value="">Sin especificar</option>
                                <option value="DNI">DNI</option>
                                <option value="CUIT">CUIT</option>
                                <option value="CUIL">CUIL</option>
                            </select>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Número de documento</label>
                            <input type="text" name="nro_doc" class="form-control">
                        </div>
                    </div>
                    <div class="row g-3 mt-1">
                        <div class="col-md-6">
                            <label class="form-label">Teléfono</label>
                            <input type="text" name="telefono" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                    </div>
                    <div class="alert alert-danger d-none mt-3" data-form-error></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" id="btnGuardarCliente" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> Guardar cliente
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- =========================================================
     MODAL NUEVO MODELO
     ========================================================= -->
<div class="modal fade" id="modalNuevoModelo" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-printer me-2"></i> Nuevo modelo de equipo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            
            <form id="formNuevoModelo">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Marca *</label>
                        <input type="text" name="marca" class="form-control" placeholder="Ricoh, Kyocera, HP..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Modelo *</label>
                        <input type="text" name="nombre_modelo" class="form-control" placeholder="M 2040dn..." required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tipo</label>
                        <select name="tipo" class="form-select">
                            <option value="Mono">Monocromático</option>
                            <option value="Color">Color</option>
                        </select>
                    </div>
                    <div class="alert alert-danger d-none" data-form-error></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> Guardar modelo
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- =========================================================
     MODAL INFORMACIÓN
     ========================================================= -->
<div class="modal fade" id="modalInformacion" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalInformacionTitulo">Información</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalInformacionBody">
                <div class="text-center text-muted py-3">
                    <div class="spinner-border spinner-border-sm"></div> Cargando...
                </div>
            </div>
        </div>
    </div>
</div>