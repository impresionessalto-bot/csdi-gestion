<?php
declare(strict_types=1);

$servicio = $servicio ?? [];
if (!function_exists('e')) {
    function e(mixed $value): string {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$fecha = $servicio['fecha_solicitud'] ?? $servicio['fecha'] ?? '';
$cliente = $servicio['cliente_nombre_fantasia'] ?? $servicio['cliente_nombre'] ?? 'Taller General';
$modelo = $servicio['modelo_oficial'] ?? '-';
$serie = $servicio['equipo_serie'] ?? $servicio['serie'] ?? 'Sin especificar';
$problema = $servicio['descripcion_problema'] ?? $servicio['problema'] ?? 'Sin descripción';
$observaciones = $servicio['observaciones'] ?? 'Ninguna';
$solucion = $servicio['solucion_aplicada'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Orden de Servicio #<?= e($servicio['id'] ?? '') ?></title>
    <style>
        body { font-family: Arial, sans-serif; background:#fff; color:#111; font-size:14px; margin:0; }
        .page { max-width:900px; margin:30px auto; padding:0 25px; }
        .header { display:flex; justify-content:space-between; gap:20px; border-bottom:2px solid #111; padding-bottom:14px; margin-bottom:22px; }
        .title { font-size:22px; font-weight:700; margin:0 0 4px; }
        .subtitle { color:#666; }
        .os { text-align:right; font-size:20px; font-weight:700; }
        .grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }
        .section { border:1px solid #ccc; border-radius:6px; padding:14px; margin-bottom:18px; }
        .section h3 { font-size:13px; text-transform:uppercase; margin:0 0 12px; }
        .row { margin:5px 0; }
        .label { font-weight:700; }
        .box { white-space:pre-wrap; line-height:1.5; min-height:45px; }
        .signatures { display:grid; grid-template-columns:1fr 1fr; gap:70px; margin-top:70px; text-align:center; }
        .signature { border-top:1px solid #111; padding-top:8px; }
        .actions { text-align:center; margin-top:30px; }
        button, a { padding:9px 16px; border:0; text-decoration:none; margin:3px; cursor:pointer; }

        .report-qr-wrap { display:flex; align-items:center; justify-content:flex-end; gap:10px; margin-bottom:6px; font-size:10px; color:#555; }
        .report-qr { width:78px; height:78px; background:#fff; }
        .report-qr img, .report-qr canvas { width:78px !important; height:78px !important; }
        @media print { .report-qr-wrap small { font-size:8px; } }
        @media print { .no-print { display:none!important; } .page { margin:0; max-width:none; } }
        @media(max-width:700px) { .grid,.signatures { grid-template-columns:1fr; gap:15px; } .header { flex-direction:column; } .os { text-align:left; } }
    </style>
</head>
<body>
<div class="page">
    <div class="header">
        <div>
            <div class="title">CSDI ERP Pro - Servicio Técnico</div>
            <div class="subtitle">Comprobante de ingreso de equipo</div>
        </div>
        <div class="os">
            <div class="report-qr-wrap">
                <div id="servicio-report-qr" class="report-qr"></div>
                <small>Escanear para consultar la orden</small>
            </div>
            OS #<?= e($servicio['id'] ?? '') ?><br>
            <small>Fecha: <?= e($fecha) ?></small>
        </div>
    </div>

    <div class="grid">
        <div class="section">
            <h3>Datos del cliente</h3>
            <div class="row"><span class="label">Cliente:</span> <?= e($cliente) ?></div>
            <div class="row"><span class="label">Teléfono:</span> <?= e($servicio['cliente_telefono'] ?? '-') ?></div>
            <div class="row"><span class="label">Email:</span> <?= e($servicio['cliente_email'] ?? '-') ?></div>
            <div class="row"><span class="label">Dirección:</span> <?= e($servicio['cliente_direccion'] ?? '-') ?></div>
        </div>
        <div class="section">
            <h3>Datos del equipo</h3>
            <div class="row"><span class="label">Marca:</span> <?= e($servicio['marca'] ?? '-') ?></div>
            <div class="row"><span class="label">Modelo:</span> <?= e($modelo) ?></div>
            <div class="row"><span class="label">Nro. de serie:</span> <?= e($serie) ?></div>
            <div class="row"><span class="label">Código interno:</span> <?= e($servicio['equipo_codigo'] ?? '-') ?></div>
            <div class="row"><span class="label">Estado:</span> <?= e($servicio['estado'] ?? 'Pendiente') ?></div>
        </div>
    </div>

    <div class="section">
        <h3>Contadores y accesorios</h3>
        <div class="grid" style="margin:0">
            <div><span class="label">Contador B/N:</span> <?= e($servicio['contador_mono'] ?? 0) ?></div>
            <div><span class="label">Contador color:</span> <?= e($servicio['contador_color'] ?? 0) ?></div>
            <div><span class="label">Cables:</span> <?= ((int)($servicio['cables'] ?? 0)) ? 'Sí' : 'No' ?></div>
            <div><span class="label">Fuente:</span> <?= ((int)($servicio['fuente'] ?? 0)) ? 'Sí' : 'No' ?></div>
        </div>
    </div>

    <div class="section">
        <h3>Reporte de falla</h3>
        <div class="box"><?= nl2br(e($problema)) ?></div>
    </div>

    <?php if ($solucion !== ''): ?>
    <div class="section">
        <h3>Solución / trabajo realizado</h3>
        <div class="box"><?= nl2br(e($solucion)) ?></div>
    </div>
    <?php endif; ?>

    <div class="section">
        <h3>Observaciones / accesorios</h3>
        <div class="box"><?= nl2br(e($observaciones)) ?></div>
    </div>

    <div class="signatures">
        <div class="signature">Firma del cliente</div>
        <div class="signature">Firma / sello taller</div>
    </div>

    <div class="actions no-print">
        <button type="button" onclick="window.print()">Imprimir</button>
        <a href="/servicios/ver/<?= e($servicio['id'] ?? 0) ?>">Volver al sistema</a>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
(function () {
    if (typeof QRCode === 'undefined') return;
    var el = document.getElementById('servicio-report-qr');
    if (!el) return;
    new QRCode(el, {
        text: new URL('/servicios/ver/<?= e((int)($servicio['id'] ?? 0)) ?>', window.location.origin).href,
        width: 78,
        height: 78,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
    });
})();
</script>
</body>
</html>
