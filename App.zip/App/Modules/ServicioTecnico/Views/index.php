<?php

/*
|--------------------------------------------------------------------------
| ERP CSDI PRO
| MÓDULO SERVICIO TÉCNICO
| VISTA PRINCIPAL
|--------------------------------------------------------------------------
|
| Esta vista NO utiliza declare(strict_types=1).
|
*/

$servicios = is_array($servicios ?? null)
    ? $servicios
    : [];

$kpis = is_array($kpis ?? null)
    ? $kpis
    : [];

$filtros = is_array($filtros ?? null)
    ? $filtros
    : [];

$csrf = (string)($csrf ?? '');

$texto = trim(
    (string)($filtros['texto'] ?? '')
);

$estadoFiltro = trim(
    (string)($filtros['estado'] ?? '')
);


/*
|--------------------------------------------------------------------------
| ESCAPE
|--------------------------------------------------------------------------
*/

if (!function_exists('e')) {

    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}


/*
|--------------------------------------------------------------------------
| COLUMNAS DEL WORKFLOW
|--------------------------------------------------------------------------
*/

$columnas = [

    'Pendiente' => [

        'titulo' =>
            'Ingresados',

        'icono' =>
            'bi-inbox',

        'descripcion' =>
            'Equipos recibidos pendientes de diagnóstico',

        'accent' =>
            'st-column-pendiente',

    ],


    'En Proceso' => [

        'titulo' =>
            'En diagnóstico',

        'icono' =>
            'bi-search',

        'descripcion' =>
            'Equipos en revisión técnica',

        'accent' =>
            'st-column-proceso',

    ],


    'En Reparacion' => [

        'titulo' =>
            'En reparación',

        'icono' =>
            'bi-tools',

        'descripcion' =>
            'Reparaciones actualmente en taller',

        'accent' =>
            'st-column-reparacion',

    ],


    'Finalizado' => [

        'titulo' =>
            'Finalizados',

        'icono' =>
            'bi-check2-circle',

        'descripcion' =>
            'Reparaciones terminadas',

        'accent' =>
            'st-column-finalizado',

    ],
];


/*
|--------------------------------------------------------------------------
| AGRUPAR SERVICIOS POR ESTADO
|--------------------------------------------------------------------------
*/

$serviciosPorEstado = [];

foreach (
    $columnas
    as $estado => $config
) {

    $serviciosPorEstado[$estado] = [];
}


foreach (
    $servicios
    as $servicio
) {

    if (!is_array($servicio)) {
        continue;
    }


    $estadoServicio = trim(
        (string)(
            $servicio['estado']
            ?? 'Pendiente'
        )
    );


    if (
        $estadoServicio === ''
        ||
        !array_key_exists(
            $estadoServicio,
            $serviciosPorEstado
        )
    ) {

        $estadoServicio = 'Pendiente';
    }


    $serviciosPorEstado[
        $estadoServicio
    ][] = $servicio;
}


/*
|--------------------------------------------------------------------------
| CANTIDADES
|--------------------------------------------------------------------------
*/

$totalServicios =
    count($servicios);


$totalPendientes =
    count(
        $serviciosPorEstado[
            'Pendiente'
        ]
    );


$totalProceso =
    count(
        $serviciosPorEstado[
            'En Proceso'
        ]
    );


$totalReparacion =
    count(
        $serviciosPorEstado[
            'En Reparacion'
        ]
    );


$totalFinalizados =
    count(
        $serviciosPorEstado[
            'Finalizado'
        ]
    );


/*
|--------------------------------------------------------------------------
| KPIS
|--------------------------------------------------------------------------
*/

$totalKpi =
    array_key_exists(
        'total',
        $kpis
    )
        ? (int)$kpis['total']
        : $totalServicios;


$pendientesKpi =
    array_key_exists(
        'pendientes',
        $kpis
    )
        ? (int)$kpis['pendientes']
        : $totalPendientes;


$procesoKpi =
    array_key_exists(
        'en_proceso',
        $kpis
    )
        ? (int)$kpis['en_proceso']
        : $totalProceso;


$reparacionKpi =
    array_key_exists(
        'en_reparacion',
        $kpis
    )
        ? (int)$kpis['en_reparacion']
        : $totalReparacion;


$finalizadosKpi =
    array_key_exists(
        'finalizados',
        $kpis
    )
        ? (int)$kpis['finalizados']
        : $totalFinalizados;

?>


<style>

/*
|--------------------------------------------------------------------------
| CONTENEDOR
|--------------------------------------------------------------------------
*/

.servicio-tecnico-container {
    width: 100%;
}


/*
|--------------------------------------------------------------------------
| TITULO
|--------------------------------------------------------------------------
*/

.st-title-icon {

    width: 46px;
    height: 46px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background:
        rgba(
            13,
            110,
            253,
            .10
        );

    color:
        #0d6efd;

    font-size:
        1.35rem;
}


/*
|--------------------------------------------------------------------------
| KPI
|--------------------------------------------------------------------------
*/

.st-kpi-card {

    min-height:
        110px;

    border:
        1px solid
        #e3e7ec !important;

    border-radius:
        14px;

    background:
        #ffffff;
}


.st-kpi-icon {

    font-size:
        1.7rem;

    color:
        #6c757d;

    opacity:
        .65;
}


/*
|--------------------------------------------------------------------------
| WRAPPER KANBAN
|--------------------------------------------------------------------------
*/

.st-kanban-wrapper {

    width:
        100%;

    overflow-x:
        auto;

    overflow-y:
        hidden;

    padding:
        5px
        3px
        18px;
}


/*
|--------------------------------------------------------------------------
| BOARD
|--------------------------------------------------------------------------
*/

.st-kanban-board {

    display:
        grid;

    grid-template-columns:
        repeat(
            4,
            minmax(
                300px,
                1fr
            )
        );

    gap:
        16px;

    width:
        100%;

    min-width:
        1240px;

    align-items:
        stretch;
}


/*
|--------------------------------------------------------------------------
| COLUMNA
|--------------------------------------------------------------------------
*/

.st-kanban-column {

    display:
        flex;

    flex-direction:
        column;

    min-width:
        300px;

    min-height:
        560px;

    background:
        #f8f9fb;

    border:
        1px solid
        #d9dee5;

    border-radius:
        14px;

    overflow:
        hidden;

    box-shadow:
        0 2px 8px
        rgba(
            0,
            0,
            0,
            .06
        );

    transition:
        border-color .18s ease,
        box-shadow .18s ease,
        background-color .18s ease;
}


/*
|--------------------------------------------------------------------------
| ACENTOS
|--------------------------------------------------------------------------
*/

.st-column-pendiente {

    border-top:
        4px solid
        #6c757d;
}


.st-column-proceso {

    border-top:
        4px solid
        #0dcaf0;
}


.st-column-reparacion {

    border-top:
        4px solid
        #0d6efd;
}


.st-column-finalizado {

    border-top:
        4px solid
        #198754;
}


/*
|--------------------------------------------------------------------------
| COLUMNA DESTINO DURANTE DRAG
|--------------------------------------------------------------------------
*/

.st-kanban-column.dnd-column-over {

    border-color:
        #0d6efd;

    background:
        #f3f8ff;

    box-shadow:
        0 0 0 3px
        rgba(
            13,
            110,
            253,
            .12
        );
}


.st-kanban-column.dnd-column-over
.st-kanban-dropzone {

    background:
        rgba(
            13,
            110,
            253,
            .07
        );
}


/*
|--------------------------------------------------------------------------
| DROPZONE
|--------------------------------------------------------------------------
*/

.st-kanban-dropzone {

    position:
        relative;

    display:
        flex;

    flex-direction:
        column;

    flex:
        1;

    min-height:
        470px;

    padding:
        12px;

    background:
        #f8f9fb;

    transition:
        background-color .18s ease;
}


.st-kanban-dropzone.dnd-zone-over {

    background:
        rgba(
            13,
            110,
            253,
            .07
        );
}


/*
|--------------------------------------------------------------------------
| HEADER COLUMNA
|--------------------------------------------------------------------------
*/

.st-kanban-column-header {

    display:
        flex;

    align-items:
        flex-start;

    justify-content:
        space-between;

    gap:
        12px;

    min-height:
        86px;

    padding:
        14px
        15px;

    background:
        #ffffff;

    border-bottom:
        1px solid
        #dfe3e8;
}


/*
|--------------------------------------------------------------------------
| TITULO COLUMNA
|--------------------------------------------------------------------------
*/

.st-kanban-column-title {

    display:
        flex;

    align-items:
        flex-start;

    gap:
        10px;

    min-width:
        0;
}


/*
|--------------------------------------------------------------------------
| ICONO
|--------------------------------------------------------------------------
*/

.st-kanban-column-icon {

    width:
        36px;

    height:
        36px;

    flex:
        0 0 36px;

    display:
        inline-flex;

    align-items:
        center;

    justify-content:
        center;

    border-radius:
        9px;

    background:
        #f1f3f5;

    color:
        #495057;
}


.st-column-proceso
.st-kanban-column-icon {

    color:
        #0dcaf0;
}


.st-column-reparacion
.st-kanban-column-icon {

    color:
        #0d6efd;
}


.st-column-finalizado
.st-kanban-column-icon {

    color:
        #198754;
}


/*
|--------------------------------------------------------------------------
| NOMBRE COLUMNA
|--------------------------------------------------------------------------
*/

.st-kanban-column-name {

    margin:
        0;

    font-size:
        .95rem;

    font-weight:
        700;

    line-height:
        1.25;
}


/*
|--------------------------------------------------------------------------
| DESCRIPCION COLUMNA
|--------------------------------------------------------------------------
*/

.st-kanban-column-description {

    margin-top:
        4px;

    color:
        #8a94a3;

    font-size:
        .70rem;

    line-height:
        1.3;
}


/*
|--------------------------------------------------------------------------
| CONTADOR
|--------------------------------------------------------------------------
*/

.st-kanban-count {

    min-width:
        30px;

    height:
        28px;

    display:
        inline-flex;

    align-items:
        center;

    justify-content:
        center;

    padding:
        0 8px;

    border:
        1px solid
        #dee2e6;

    border-radius:
        999px;

    background:
        #f8f9fa;

    color:
        #495057;

    font-size:
        .78rem;

    font-weight:
        700;
}


/*
|--------------------------------------------------------------------------
| VACIO
|--------------------------------------------------------------------------
*/

.st-kanban-empty {

    min-height:
        180px;

    display:
        flex;

    flex-direction:
        column;

    align-items:
        center;

    justify-content:
        center;

    text-align:
        center;

    color:
        #adb5bd;

    border:
        1px dashed
        #d8dde3;

    border-radius:
        10px;

    margin:
        2px;

    pointer-events:
        none;
}


.st-kanban-empty i {

    margin-bottom:
        8px;

    font-size:
        1.8rem;

    opacity:
        .65;
}


.st-kanban-empty span {

    font-size:
        .84rem;

    font-weight:
        600;
}


.st-kanban-empty small {

    margin-top:
        4px;

    font-size:
        .72rem;
}


/*
|--------------------------------------------------------------------------
| TARJETA
|--------------------------------------------------------------------------
*/

.st-service-card {

    position:
        relative;

    display:
        block;

    width:
        100%;

    flex:
        0 0 auto;

    margin-bottom:
        12px;

    padding:
        13px;

    background:
        #ffffff;

    border:
        1px solid
        #dfe3e8;

    border-radius:
        11px;

    box-shadow:
        0 2px 5px
        rgba(
            0,
            0,
            0,
            .05
        );

    cursor:
        grab;

    user-select:
        none;

    -webkit-user-select:
        none;

    transition:
        transform .15s ease,
        box-shadow .15s ease,
        border-color .15s ease,
        opacity .15s ease;
}


.st-service-card:last-child {

    margin-bottom:
        0;
}


.st-service-card:hover {

    transform:
        translateY(
            -2px
        );

    box-shadow:
        0 5px 14px
        rgba(
            0,
            0,
            0,
            .09
        );
}


.st-service-card.dnd-dragging {

    opacity:
        .45;

    transform:
        rotate(
            1deg
        );

    box-shadow:
        0 10px 24px
        rgba(
            0,
            0,
            0,
            .12
        );
}


.st-service-card.dnd-saving {

    opacity:
        .65;

    pointer-events:
        none;
}


.st-service-card.dnd-saved {

    border-color:
        #198754;

    box-shadow:
        0 0 0 2px
        rgba(
            25,
            135,
            84,
            .08
        );
}


.st-service-card.dnd-error {

    border-color:
        #dc3545;

    box-shadow:
        0 0 0 2px
        rgba(
            220,
            53,
            69,
            .08
        );
}


/*
|--------------------------------------------------------------------------
| HEADER TARJETA
|--------------------------------------------------------------------------
*/

.st-service-card-header {

    display:
        flex;

    align-items:
        center;

    justify-content:
        space-between;

    gap:
        8px;

    margin-bottom:
        10px;
}


/*
|--------------------------------------------------------------------------
| NUMERO
|--------------------------------------------------------------------------
*/

.st-service-number {

    display:
        flex;

    flex-direction:
        column;
}


.st-service-number-label {

    color:
        #9aa2ad;

    font-size:
        .65rem;

    text-transform:
        uppercase;

    letter-spacing:
        .03em;
}


.st-service-number strong {

    font-size:
        .82rem;
}


/*
|--------------------------------------------------------------------------
| HANDLE
|--------------------------------------------------------------------------
*/

.st-drag-handle {

    width:
        30px;

    height:
        30px;

    display:
        inline-flex;

    align-items:
        center;

    justify-content:
        center;

    border:
        1px solid
        #e1e5ea;

    border-radius:
        7px;

    background:
        #ffffff;

    color:
        #8b949e;

    cursor:
        grab;
}


.st-drag-handle:hover {

    background:
        #f8f9fa;

    color:
        #495057;
}


.st-service-card.dnd-dragging
.st-drag-handle {

    cursor:
        grabbing;
}


/*
|--------------------------------------------------------------------------
| CLIENTE
|--------------------------------------------------------------------------
*/

.st-service-client {

    display:
        flex;

    align-items:
        center;

    gap:
        7px;

    margin-bottom:
        11px;

    font-size:
        .82rem;

    min-width:
        0;

    overflow:
        hidden;

    text-overflow:
        ellipsis;
}


.st-service-client i {

    color:
        #6c757d;
}


/*
|--------------------------------------------------------------------------
| EQUIPO
|--------------------------------------------------------------------------
*/

.st-service-equipment {

    display:
        flex;

    align-items:
        center;

    gap:
        10px;

    margin-bottom:
        10px;

    padding:
        9px;

    border-radius:
        9px;

    background:
        #f8f9fa;
}


.st-service-equipment-icon {

    width:
        34px;

    height:
        34px;

    flex:
        0 0 34px;

    display:
        inline-flex;

    align-items:
        center;

    justify-content:
        center;

    border:
        1px solid
        #e9ecef;

    border-radius:
        8px;

    background:
        #ffffff;

    color:
        #495057;
}


.st-service-equipment-name {

    font-size:
        .80rem;

    font-weight:
        700;

    line-height:
        1.25;
}


.st-service-serie {

    margin-top:
        2px;

    color:
        #868e96;

    font-size:
        .70rem;
}


/*
|--------------------------------------------------------------------------
| PROBLEMA
|--------------------------------------------------------------------------
*/

.st-service-problem {

    margin-bottom:
        10px;

    padding:
        8px 9px;

    border:
        1px solid
        #ffe69c;

    border-radius:
        8px;

    background:
        #fff8e6;
}


.st-service-problem-title {

    margin-bottom:
        3px;

    color:
        #8a6500;

    font-size:
        .68rem;

    font-weight:
        700;
}


.st-service-problem-text {

    color:
        #5f6368;

    font-size:
        .73rem;

    line-height:
        1.35;

    display:
        -webkit-box;

    -webkit-line-clamp:
        3;

    -webkit-box-orient:
        vertical;

    overflow:
        hidden;
}


/*
|--------------------------------------------------------------------------
| META
|--------------------------------------------------------------------------
*/

.st-service-meta {

    display:
        flex;

    flex-wrap:
        wrap;

    gap:
        8px;

    margin-bottom:
        10px;

    color:
        #8a94a3;

    font-size:
        .68rem;
}


.st-service-meta span {

    display:
        inline-flex;

    align-items:
        center;

    gap:
        4px;
}


/*
|--------------------------------------------------------------------------
| FOOTER TARJETA
|--------------------------------------------------------------------------
*/

.st-service-card-footer {

    display:
        flex;

    justify-content:
        flex-end;

    gap:
        5px;

    padding-top:
        9px;

    border-top:
        1px solid
        #f0f2f4;
}


.st-service-card-footer .btn {

    padding:
        .25rem .55rem;

    font-size:
        .70rem;
}


/*
|--------------------------------------------------------------------------
| UTILIDADES
|--------------------------------------------------------------------------
*/

.min-width-0 {
    min-width: 0;
}


/*
|--------------------------------------------------------------------------
| DRAG ACTIVO
|--------------------------------------------------------------------------
*/

.st-kanban-wrapper.dnd-active {

    cursor:
        grabbing;
}


.st-kanban-wrapper.dnd-active
.st-service-card:not(.dnd-dragging) {

    transition:
        box-shadow .12s ease,
        transform .12s ease;
}


/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media (max-width: 1399.98px) {

    .st-kanban-board {

        min-width:
            1240px;
    }
}


@media (max-width: 767.98px) {

    .st-kanban-board {

        min-width:
            1160px;

        grid-template-columns:
            repeat(
                4,
                minmax(
                    285px,
                    1fr
                )
            );
    }


    .st-kanban-column {

        min-width:
            285px;
    }


    .st-kanban-dropzone {

        min-height:
            420px;
    }
}


.st-service-qr-mini {
    width: 46px;
    height: 46px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #fff;
    border: 1px solid #dee2e6;
    border-radius: 7px;
    overflow: hidden;
}
.st-service-qr-mini img,
.st-service-qr-mini canvas {
    width: 40px !important;
    height: 40px !important;
}

</style>


<div
    class="
        container-fluid
        py-4
        servicio-tecnico-container
    "
>


    <!-- =========================================================
         HEADER
         ========================================================= -->

    <div
        class="
            d-flex
            flex-wrap
            justify-content-between
            align-items-center
            gap-3
            mb-4
        "
    >

        <div
            class="
                d-flex
                align-items-center
                gap-3
            "
        >

            <div class="st-title-icon">

                <i class="bi bi-tools"></i>

            </div>


            <div>

                <h1 class="h3 fw-bold mb-1">
                    Servicio Técnico
                </h1>


                <p class="text-muted mb-0">
                    Flujo de trabajo del taller
                </p>

            </div>

        </div>


        <div
            class="
                d-flex
                flex-wrap
                gap-2
            "
        >

            <a
                href="/servicios/historial"
                class="
                    btn
                    btn-outline-secondary
                "
            >

                <i
                    class="
                        bi
                        bi-clock-history
                        me-1
                    "
                ></i>

                Historial

            </a>


            <a
                href="/servicios/nuevo"
                class="
                    btn
                    btn-primary
                "
            >

                <i
                    class="
                        bi
                        bi-plus-lg
                        me-1
                    "
                ></i>

                Nuevo ingreso

            </a>

        </div>

    </div>


    <!-- =========================================================
         KPIS
         ========================================================= -->

    <div class="row g-3 mb-4">


        <div class="col-6 col-xl">

            <div
                class="
                    card
                    border-0
                    shadow-sm
                    h-100
                    st-kpi-card
                "
            >

                <div class="card-body">

                    <div
                        class="
                            d-flex
                            justify-content-between
                            align-items-start
                        "
                    >

                        <div>

                            <small class="text-muted">
                                Total
                            </small>


                            <div class="fs-3 fw-bold">
                                <?= e($totalKpi) ?>
                            </div>

                        </div>


                        <div class="st-kpi-icon">

                            <i
                                class="
                                    bi
                                    bi-clipboard2-data
                                "
                            ></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl">

            <div
                class="
                    card
                    border-0
                    shadow-sm
                    h-100
                    st-kpi-card
                "
            >

                <div class="card-body">

                    <div
                        class="
                            d-flex
                            justify-content-between
                            align-items-start
                        "
                    >

                        <div>

                            <small class="text-muted">
                                Ingresados
                            </small>


                            <div class="fs-3 fw-bold">
                                <?= e($pendientesKpi) ?>
                            </div>

                        </div>


                        <div class="st-kpi-icon">

                            <i
                                class="
                                    bi
                                    bi-inbox
                                "
                            ></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl">

            <div
                class="
                    card
                    border-0
                    shadow-sm
                    h-100
                    st-kpi-card
                "
            >

                <div class="card-body">

                    <div
                        class="
                            d-flex
                            justify-content-between
                            align-items-start
                        "
                    >

                        <div>

                            <small class="text-muted">
                                Diagnóstico
                            </small>


                            <div class="fs-3 fw-bold">
                                <?= e($procesoKpi) ?>
                            </div>

                        </div>


                        <div class="st-kpi-icon">

                            <i
                                class="
                                    bi
                                    bi-search
                                "
                            ></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl">

            <div
                class="
                    card
                    border-0
                    shadow-sm
                    h-100
                    st-kpi-card
                "
            >

                <div class="card-body">

                    <div
                        class="
                            d-flex
                            justify-content-between
                            align-items-start
                        "
                    >

                        <div>

                            <small class="text-muted">
                                En reparación
                            </small>


                            <div class="fs-3 fw-bold">
                                <?= e($reparacionKpi) ?>
                            </div>

                        </div>


                        <div class="st-kpi-icon">

                            <i
                                class="
                                    bi
                                    bi-tools
                                "
                            ></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-6 col-xl">

            <div
                class="
                    card
                    border-0
                    shadow-sm
                    h-100
                    st-kpi-card
                "
            >

                <div class="card-body">

                    <div
                        class="
                            d-flex
                            justify-content-between
                            align-items-start
                        "
                    >

                        <div>

                            <small class="text-muted">
                                Finalizados
                            </small>


                            <div class="fs-3 fw-bold">
                                <?= e($finalizadosKpi) ?>
                            </div>

                        </div>


                        <div class="st-kpi-icon">

                            <i
                                class="
                                    bi
                                    bi-check2-circle
                                "
                            ></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =========================================================
         BUSCADOR
         ========================================================= -->

    <div
        class="
            card
            border-0
            shadow-sm
            mb-4
        "
    >

        <div class="card-body">

            <form
                method="get"
                action="/servicios"
                class="
                    row
                    g-3
                    align-items-end
                "
            >

                <div class="col-12 col-lg-7">

                    <label
                        class="
                            form-label
                            fw-semibold
                        "
                    >
                        Buscar reparación
                    </label>


                    <div class="input-group">

                        <span
                            class="
                                input-group-text
                                bg-white
                            "
                        >

                            <i class="bi bi-search"></i>

                        </span>


                        <input
                            type="search"
                            name="texto"
                            value="<?= e($texto) ?>"
                            class="form-control"
                            placeholder="Cliente, equipo, serie, falla..."
                            autocomplete="off"
                            id="servicio-busqueda-texto"
                        >

                        <button
                            type="button"
                            class="btn btn-outline-dark"
                            id="btn-escanear-servicio"
                            title="Buscar servicio mediante QR"
                        >
                            <i class="bi bi-qr-code-scan"></i>
                        </button>

                    </div>

                    <div class="form-text">
                        También podés escanear el QR de una orden para abrirla directamente.
                    </div>

                </div>


                <div class="col-12 col-md-5 col-lg-3">

                    <label
                        class="
                            form-label
                            fw-semibold
                        "
                    >
                        Estado
                    </label>


                    <select
                        name="estado"
                        class="form-select"
                    >

                        <option value="">
                            Todos los estados
                        </option>


                        <?php foreach (
                            $columnas
                            as $estado => $config
                        ): ?>

                            <option
                                value="<?= e($estado) ?>"
                                <?= $estadoFiltro === $estado
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= e($config['titulo']) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div
                    class="
                        col-12
                        col-md-7
                        col-lg-2
                    "
                >

                    <div class="d-flex gap-2">

                        <button
                            type="submit"
                            class="
                                btn
                                btn-primary
                                flex-grow-1
                            "
                        >

                            <i
                                class="
                                    bi
                                    bi-search
                                    me-1
                                "
                            ></i>

                            Buscar

                        </button>


                        <a
                            href="/servicios"
                            class="
                                btn
                                btn-outline-secondary
                            "
                            title="Limpiar filtros"
                        >

                            <i
                                class="
                                    bi
                                    bi-x-lg
                                "
                            ></i>

                        </a>

                    </div>

                </div>

            </form>

        </div>

    </div>


    <!-- =========================================================
         KANBAN
         ========================================================= -->

    <div
        class="st-kanban-wrapper"
        data-dnd-board
        data-endpoint="/servicios/api/cambiar-estado"
        data-csrf="<?= e($csrf) ?>"
    >

        <div class="st-kanban-board">


            <?php foreach (
                $columnas
                as $estado => $config
            ): ?>


                <?php

                $items =
                    $serviciosPorEstado[
                        $estado
                    ]
                    ?? [];


                $cantidad =
                    count(
                        $items
                    );

                ?>


                <!-- =================================================
                     COLUMNA
                     ================================================= -->

                <section
                    class="
                        st-kanban-column
                        <?= e(
                            $config['accent']
                        ) ?>
                    "
                    data-dnd-column
                    data-status="<?= e($estado) ?>"
                >


                    <!-- =================================================
                         HEADER
                         ================================================= -->

                    <div
                        class="
                            st-kanban-column-header
                        "
                    >

                        <div
                            class="
                                st-kanban-column-title
                            "
                        >

                            <div
                                class="
                                    st-kanban-column-icon
                                "
                            >

                                <i
                                    class="
                                        bi
                                        <?= e(
                                            $config['icono']
                                        ) ?>
                                    "
                                ></i>

                            </div>


                            <div>

                                <h2
                                    class="
                                        st-kanban-column-name
                                    "
                                >

                                    <?= e(
                                        $config['titulo']
                                    ) ?>

                                </h2>


                                <div
                                    class="
                                        st-kanban-column-description
                                    "
                                >

                                    <?= e(
                                        $config['descripcion']
                                    ) ?>

                                </div>

                            </div>

                        </div>


                        <span
                            class="
                                st-kanban-count
                            "
                            data-dnd-count
                        >
                            <?= e($cantidad) ?>
                        </span>

                    </div>


                    <!-- =================================================
                         DROPZONE
                         ================================================= -->

                    <div
                        class="
                            st-kanban-dropzone
                        "
                        data-dnd-zone
                        data-status="<?= e($estado) ?>"
                    >


                        <?php if (
                            empty($items)
                        ): ?>

                            <div
                                class="
                                    st-kanban-empty
                                "
                                data-dnd-empty
                            >

                                <i
                                    class="
                                        bi
                                        bi-inbox
                                    "
                                ></i>


                                <span>
                                    Sin reparaciones
                                </span>


                                <small>
                                    Arrastrá una tarjeta aquí
                                </small>

                            </div>

                        <?php endif; ?>


                        <?php foreach (
                            $items
                            as $servicio
                        ): ?>


                            <?php

                            $id =
                                (int)(
                                    $servicio['id']
                                    ?? 0
                                );


                            if (
                                $id <= 0
                            ) {
                                continue;
                            }


                            /*
                             * CLIENTE
                             */

                            $clienteNombre =
                                trim(
                                    (string)(
                                        $servicio[
                                            'cliente_nombre'
                                        ]
                                        ?? ''
                                    )
                                );


                            if (
                                $clienteNombre === ''
                            ) {

                                $clienteNombre =
                                    'Taller General';
                            }


                            /*
                             * MARCA
                             */

                            $marca =
                                trim(
                                    (string)(
                                        $servicio[
                                            'marca'
                                        ]
                                        ?? ''
                                    )
                                );


                            /*
                             * MODELO
                             */

                            $modelo =
                                trim(
                                    (string)(
                                        $servicio[
                                            'modelo_oficial'
                                        ]
                                        ?? ''
                                    )
                                );


                            /*
                             * SERIE
                             */

                            $serie =
                                trim(
                                    (string)(
                                        $servicio[
                                            'equipo_serie'
                                        ]
                                        ?? ''
                                    )
                                );


                            /*
                             * CODIGO INTERNO
                             */

                            $codigo =
                                trim(
                                    (string)(
                                        $servicio[
                                            'equipo_codigo'
                                        ]
                                        ?? ''
                                    )
                                );


                            /*
                             * PROBLEMA
                             */

                            $problema =
                                trim(
                                    (string)(
                                        $servicio[
                                            'problema'
                                        ]
                                        ??
                                        $servicio[
                                            'descripcion_problema'
                                        ]
                                        ??
                                        ''
                                    )
                                );


                            /*
                             * FECHA
                             */

                            $fecha =
                                trim(
                                    (string)(
                                        $servicio[
                                            'fecha_solicitud'
                                        ]
                                        ?? ''
                                    )
                                );


                            /*
                             * EQUIPO
                             */

                            $equipo =
                                trim(
                                    $marca
                                    .
                                    (
                                        $marca !== ''
                                        &&
                                        $modelo !== ''
                                            ? ' '
                                            : ''
                                    )
                                    .
                                    $modelo
                                );


                            if (
                                $equipo === ''
                            ) {

                                $equipo =
                                    'Equipo sin modelo';
                            }

                            ?>


                            <!-- =================================================
                                 TARJETA
                                 ================================================= -->

                            <article
                                class="
                                    st-service-card
                                "
                                data-dnd-item
                                data-id="<?= e($id) ?>"
                                data-servicio-id="<?= e($id) ?>"
                                data-status="<?= e($estado) ?>"
                                draggable="true"
                            >


                                <!-- HEADER TARJETA -->

                                <div
                                    class="
                                        st-service-card-header
                                    "
                                >

                                    <div
                                        class="
                                            st-service-number
                                        "
                                    >

                                        <span
                                            class="
                                                st-service-number-label
                                            "
                                        >
                                            Orden de servicio
                                        </span>


                                        <strong>
                                            #<?= e($id) ?>
                                        </strong>

                                        <div
                                            class="st-service-qr-mini"
                                            data-service-qr="<?= e('/servicios/ver/' . $id) ?>"
                                            title="QR de la orden #<?= e($id) ?>"
                                        ></div>

                                    </div>


                                    <div
                                        class="
                                            d-flex
                                            align-items-center
                                            gap-1
                                        "
                                    >

                                        <!--
                                         * IMPORTANTE:
                                         * No es draggable por sí mismo.
                                         * El drag lo controla la tarjeta.
                                         -->

                                        <span
                                            class="
                                                st-drag-handle
                                            "
                                            data-dnd-handle
                                            title="Arrastrar reparación"
                                        >

                                            <i
                                                class="
                                                    bi
                                                    bi-grip-vertical
                                                "
                                            ></i>

                                        </span>


                                        <a
                                            href="/servicios/ver/<?= e($id) ?>"
                                            class="
                                                btn
                                                btn-sm
                                                btn-light
                                            "
                                            title="Ver servicio"
                                        >

                                            <i
                                                class="
                                                    bi
                                                    bi-eye
                                                "
                                            ></i>

                                        </a>

                                    </div>

                                </div>


                                <!-- CLIENTE -->

                                <div
                                    class="
                                        st-service-client
                                    "
                                >

                                    <i
                                        class="
                                            bi
                                            bi-person
                                        "
                                    ></i>


                                    <strong>
                                        <?= e(
                                            $clienteNombre
                                        ) ?>
                                    </strong>

                                </div>


                                <!-- EQUIPO -->

                                <div
                                    class="
                                        st-service-equipment
                                    "
                                >

                                    <div
                                        class="
                                            st-service-equipment-icon
                                        "
                                    >

                                        <i
                                            class="
                                                bi
                                                bi-printer
                                            "
                                        ></i>

                                    </div>


                                    <div
                                        class="
                                            min-width-0
                                        "
                                    >

                                        <div
                                            class="
                                                st-service-equipment-name
                                            "
                                        >

                                            <?= e(
                                                $equipo
                                            ) ?>

                                        </div>


                                        <?php if (
                                            $serie !== ''
                                        ): ?>

                                            <div
                                                class="
                                                    st-service-serie
                                                "
                                            >

                                                <i
                                                    class="
                                                        bi
                                                        bi-upc-scan
                                                        me-1
                                                    "
                                                ></i>

                                                Serie:
                                                <?= e(
                                                    $serie
                                                ) ?>

                                            </div>

                                        <?php endif; ?>


                                        <?php if (
                                            $codigo !== ''
                                        ): ?>

                                            <div
                                                class="
                                                    st-service-serie
                                                "
                                            >

                                                <i
                                                    class="
                                                        bi
                                                        bi-hash
                                                        me-1
                                                    "
                                                ></i>

                                                Equipo:
                                                <?= e(
                                                    $codigo
                                                ) ?>

                                            </div>

                                        <?php endif; ?>

                                    </div>

                                </div>


                                <!-- PROBLEMA -->

                                <?php if (
                                    $problema !== ''
                                ): ?>

                                    <div
                                        class="
                                            st-service-problem
                                        "
                                    >

                                        <div
                                            class="
                                                st-service-problem-title
                                            "
                                        >

                                            <i
                                                class="
                                                    bi
                                                    bi-exclamation-triangle
                                                "
                                            ></i>

                                            Falla reportada

                                        </div>


                                        <div
                                            class="
                                                st-service-problem-text
                                            "
                                        >

                                            <?= e(
                                                $problema
                                            ) ?>

                                        </div>

                                    </div>

                                <?php endif; ?>


                                <!-- META -->

                                <div
                                    class="
                                        st-service-meta
                                    "
                                >

                                    <?php if (
                                        $fecha !== ''
                                    ): ?>

                                        <span>

                                            <i
                                                class="
                                                    bi
                                                    bi-calendar3
                                                "
                                            ></i>

                                            <?= e(
                                                $fecha
                                            ) ?>

                                        </span>

                                    <?php endif; ?>


                                    <span>

                                        <i
                                            class="
                                                bi
                                                bi-arrows-move
                                            "
                                        ></i>

                                        Arrastrar

                                    </span>

                                </div>


                                <!-- ACCIONES -->

                                <div
                                    class="
                                        st-service-card-footer
                                    "
                                >

                                    <a
                                        href="/servicios/ver/<?= e($id) ?>"
                                        class="
                                            btn
                                            btn-sm
                                            btn-outline-primary
                                        "
                                    >

                                        <i
                                            class="
                                                bi
                                                bi-eye
                                                me-1
                                            "
                                        ></i>

                                        Ver

                                    </a>


                                    <a
                                        href="/servicios/editar/<?= e($id) ?>"
                                        class="
                                            btn
                                            btn-sm
                                            btn-outline-secondary
                                        "
                                    >

                                        <i
                                            class="
                                                bi
                                                bi-pencil
                                                me-1
                                            "
                                        ></i>

                                        Editar

                                    </a>

                                </div>

                            </article>


                        <?php endforeach; ?>


                    </div>

                </section>


            <?php endforeach; ?>


        </div>

    </div>


    <!-- =========================================================
         AYUDA
         ========================================================= -->

    <div class="mt-3">

        <div
            class="
                alert
                alert-light
                border
                small
                mb-0
            "
        >

            <i
                class="
                    bi
                    bi-arrows-move
                    me-1
                "
            ></i>


            <strong>
                Flujo de trabajo:
            </strong>


            arrastrá una reparación de una columna a otra
            para actualizar su estado.

        </div>

    </div>


</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://unpkg.com/html5-qrcode" defer></script>

<div class="modal fade" id="modalScannerServicio" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-qr-code-scan me-2"></i>Buscar servicio por QR</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <div id="servicio-qr-reader" style="width:100%;"></div>
                <div id="servicio-qr-error" class="alert alert-warning mt-3 d-none mb-0"></div>
                <div class="small text-muted mt-2">Apuntá la cámara al QR de la orden de servicio.</div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    function initServiceQRCodes() {
        if (typeof QRCode === 'undefined') return;
        document.querySelectorAll('[data-service-qr]').forEach(function (el) {
            if (el.dataset.qrReady === '1') return;
            el.dataset.qrReady = '1';
            el.innerHTML = '';
            new QRCode(el, {
                text: new URL(el.dataset.serviceQr, window.location.origin).href,
                width: 40,
                height: 40,
                colorDark: '#000000',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.M
            });
        });
    }

    function extractServiceId(value) {
        var text = String(value || '').trim();
        var match = text.match(/\/servicios\/ver\/(\d+)(?:[?#].*)?$/);
        if (match) return parseInt(match[1], 10);
        match = text.match(/(?:^|[?&])(?:servicio|id)=(\d+)/i);
        if (match) return parseInt(match[1], 10);
        match = text.match(/^SERVICIO\s*[:#-]?\s*(\d+)$/i);
        if (match) return parseInt(match[1], 10);
        return 0;
    }

    var scanButton = document.getElementById('btn-escanear-servicio');
    var modalEl = document.getElementById('modalScannerServicio');
    var readerEl = document.getElementById('servicio-qr-reader');
    var errorEl = document.getElementById('servicio-qr-error');
    var scanner = null;
    var modal = null;

    function showError(message) {
        if (!errorEl) return;
        errorEl.textContent = message;
        errorEl.classList.remove('d-none');
    }

    function stopScanner() {
        if (!scanner) return Promise.resolve();
        var current = scanner;
        scanner = null;
        return current.stop().catch(function () {}).then(function () {
            try { current.clear(); } catch (e) {}
        });
    }

    function startScanner() {
        if (typeof Html5Qrcode === 'undefined') {
            showError('No se pudo cargar el lector QR. Verificá la conexión y volvé a intentar.');
            return;
        }
        errorEl.classList.add('d-none');
        readerEl.innerHTML = '';
        scanner = new Html5Qrcode('servicio-qr-reader');
        scanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: { width: 230, height: 230 } },
            function (decodedText) {
                var id = extractServiceId(decodedText);
                if (!id) {
                    showError('El QR no corresponde a una orden de Servicio Técnico.');
                    return;
                }
                stopScanner().finally(function () {
                    if (modal) modal.hide();
                    window.location.href = '/servicios/ver/' + id;
                });
            },
            function () {}
        ).catch(function (error) {
            showError('No se pudo acceder a la cámara. Revisá el permiso del navegador.');
        });
    }

    if (scanButton && modalEl) {
        modal = new bootstrap.Modal(modalEl);
        scanButton.addEventListener('click', function () {
            modal.show();
        });
        modalEl.addEventListener('shown.bs.modal', startScanner);
        modalEl.addEventListener('hidden.bs.modal', stopScanner);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initServiceQRCodes);
    } else {
        initServiceQRCodes();
    }
})();
</script>