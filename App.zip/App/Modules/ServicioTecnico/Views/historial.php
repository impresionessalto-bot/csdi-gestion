<?php

declare(strict_types=1);

$servicios =
    is_array($servicios ?? null)
        ? $servicios
        : [];

$csrf =
    (string)($csrf ?? '');

$title =
    (string)($title ?? 'Historial de Servicio T�cnico');
?>

<div
    class="container-fluid py-4 servicio-tecnico-container"
    data-servicio-tecnico
    data-csrf="<?= htmlspecialchars(
        $csrf,
        ENT_QUOTES,
        'UTF-8'
    ) ?>"
>

<!-- =====================================================
     HEADER
     ===================================================== -->

<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

    <div class="d-flex align-items-center gap-3">

        <div class="st-title-icon">
            <i class="bi bi-clock-history"></i>
        </div>

        <div>

            <h1 class="h3 fw-bold mb-0">
                <?= htmlspecialchars(
                    $title,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h1>

            <p class="text-muted mb-0">
                Historial de servicios t�cnicos finalizados.
            </p>

        </div>

    </div>


    <div class="d-flex gap-2">

        <a
            href="/servicios"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Volver al taller
        </a>

        <a
            href="/servicios/nuevo"
            class="btn btn-primary"
        >
            <i class="bi bi-plus-lg me-1"></i>
            Nuevo servicio
        </a>

    </div>

</div>


<!-- =====================================================
     FILTRO
     ===================================================== -->

<div class="card border-0 shadow-sm mb-4">

    <div class="card-body">

        <form
            method="get"
            action="/servicios/historial"
            class="row g-3 align-items-end"
        >

            <div class="col-12 col-lg-8">

                <label
                    for="texto"
                    class="form-label fw-semibold"
                >
                    Buscar
                </label>

                <div class="input-group">

                    <span class="input-group-text bg-white">
                        <i class="bi bi-search"></i>
                    </span>

                    <input
                        type="text"
                        name="texto"
                        id="texto"
                        class="form-control"
                        value="<?= htmlspecialchars(
                            (string)($texto ?? ''),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        placeholder="Cliente, marca, modelo, serie o problema..."
                    >

                </div>

            </div>


            <div class="col-12 col-lg-4">

                <div class="d-flex gap-2">

                    <button
                        type="submit"
                        class="btn btn-primary flex-grow-1"
                    >
                        <i class="bi bi-search me-1"></i>
                        Buscar
                    </button>

                    <a
                        href="/servicios/historial"
                        class="btn btn-outline-secondary"
                        title="Limpiar filtros"
                    >
                        <i class="bi bi-x-lg"></i>
                    </a>

                </div>

            </div>

        </form>

    </div>

</div>


<!-- =====================================================
     CONTENIDO
     ===================================================== -->

<div class="card border-0 shadow-sm">

    <div class="card-header bg-white py-3">

        <div class="d-flex justify-content-between align-items-center">

            <div>

                <strong>
                    <i class="bi bi-archive me-1"></i>
                    Servicios finalizados
                </strong>

                <span class="badge bg-secondary ms-2">
                    <?= count($servicios) ?>
                </span>

            </div>

        </div>

    </div>


    <div class="card-body p-0">

        <?php if (empty($servicios)): ?>

            <!-- =================================================
                 SIN RESULTADOS
                 ================================================= -->

            <div class="text-center py-5">

                <div class="text-muted mb-3">

                    <i
                        class="bi bi-clock-history"
                        style="font-size: 3rem;"
                    ></i>

                </div>

                <h5 class="fw-semibold">
                    No hay servicios en el historial
                </h5>

                <p class="text-muted mb-3">
                    No se encontraron servicios t�cnicos finalizados
                    con los filtros seleccionados.
                </p>

                <a
                    href="/servicios"
                    class="btn btn-outline-primary"
                >
                    <i class="bi bi-tools me-1"></i>
                    Ver servicios actuales
                </a>

            </div>

        <?php else: ?>

            <!-- =================================================
                 TABLA
                 ================================================= -->

            <div class="table-responsive">

                <table class="table table-hover align-middle mb-0">

                    <thead class="table-light">

                        <tr>

                            <th class="ps-3">
                                Servicio
                            </th>

                            <th>
                                Fecha
                            </th>

                            <th>
                                Cliente
                            </th>

                            <th>
                                Equipo
                            </th>

                            <th>
                                Serie
                            </th>

                            <th>
                                Problema
                            </th>

                            <th class="text-center">
                                Estado
                            </th>

                            <th class="text-end pe-3">
                                Acciones
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php foreach ($servicios as $servicio): ?>

                        <?php

                        $id =
                            (int)(
                                $servicio['id']
                                ?? 0
                            );

                        $cliente =
                            trim(
                                (string)(
                                    $servicio['cliente_nombre']
                                    ?? 'Taller General'
                                )
                            );

                        if ($cliente === '') {
                            $cliente = 'Taller General';
                        }

                        $marca =
                            trim(
                                (string)(
                                    $servicio['marca']
                                    ?? ''
                                )
                            );

                        $modelo =
                            trim(
                                (string)(
                                    $servicio['modelo_oficial']
                                    ?? $servicio['nombre_modelo']
                                    ?? ''
                                )
                            );

                        $serie =
                            trim(
                                (string)(
                                    $servicio['equipo_serie']
                                    ?? $servicio['serie']
                                    ?? ''
                                )
                            );

                        $problema =
                            trim(
                                (string)(
                                    $servicio['descripcion_problema']
                                    ?? $servicio['problema']
                                    ?? ''
                                )
                            );

                        $estado =
                            trim(
                                (string)(
                                    $servicio['estado']
                                    ?? 'Finalizado'
                                )
                            );

                        $fecha =
                            (string)(
                                $servicio['fecha_solicitud']
                                ?? $servicio['created_at']
                                ?? ''
                            );


                        /*
                         * Fecha amigable
                         */
                        $fechaFormateada = '�';

                        if ($fecha !== '') {

                            try {

                                $fechaFormateada =
                                    (new DateTime($fecha))
                                        ->format('d/m/Y H:i');

                            } catch (Throwable) {

                                $fechaFormateada =
                                    $fecha;
                            }
                        }


                        /*
                         * Estado
                         */
                        $badgeEstado =
                            match ($estado) {

                                'Finalizado' =>
                                    'bg-success',

                                'En Proceso' =>
                                    'bg-warning text-dark',

                                'En Reparacion' =>
                                    'bg-warning text-dark',

                                'Pendiente' =>
                                    'bg-secondary',

                                default =>
                                    'bg-secondary',
                            };


                        /*
                         * Equipo
                         */
                        $equipo =
                            trim(
                                $marca .
                                (
                                    $marca !== ''
                                    && $modelo !== ''
                                        ? ' '
                                        : ''
                                ) .
                                $modelo
                            );

                        if ($equipo === '') {
                            $equipo = 'Sin modelo';
                        }

                        ?>

                        <tr>

                            <!-- SERVICIO -->

                            <td class="ps-3">

                                <div class="fw-bold">
                                    #<?= $id ?>
                                </div>

                            </td>


                            <!-- FECHA -->

                            <td>

                                <span class="small text-muted">
                                    <?= htmlspecialchars(
                                        $fechaFormateada,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>

                            </td>


                            <!-- CLIENTE -->

                            <td>

                                <div class="fw-semibold">

                                    <?= htmlspecialchars(
                                        $cliente,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </div>

                                <?php if (
                                    !empty(
                                        $servicio['cliente_telefono']
                                    )
                                ): ?>

                                    <div class="small text-muted">

                                        <i class="bi bi-telephone me-1"></i>

                                        <?= htmlspecialchars(
                                            (string)$servicio[
                                                'cliente_telefono'
                                            ],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    </div>

                                <?php endif; ?>

                            </td>


                            <!-- EQUIPO -->

                            <td>

                                <div class="fw-semibold">

                                    <?= htmlspecialchars(
                                        $equipo,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </div>

                                <?php if (
                                    !empty(
                                        $servicio['modelo_tipo']
                                    )
                                ): ?>

                                    <span class="small text-muted">

                                        <?= htmlspecialchars(
                                            (string)$servicio[
                                                'modelo_tipo'
                                            ],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- SERIE -->

                            <td>

                                <?php if ($serie !== ''): ?>

                                    <code>
                                        <?= htmlspecialchars(
                                            $serie,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </code>

                                <?php else: ?>

                                    <span class="text-muted">
                                        �
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- PROBLEMA -->

                            <td style="min-width: 220px; max-width: 320px;">

                                <?php if ($problema !== ''): ?>

                                    <div
                                        class="small"
                                        title="<?= htmlspecialchars(
                                            $problema,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        style="
                                            display: -webkit-box;
                                            -webkit-line-clamp: 2;
                                            -webkit-box-orient: vertical;
                                            overflow: hidden;
                                        "
                                    >
                                        <?= htmlspecialchars(
                                            $problema,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </div>

                                <?php else: ?>

                                    <span class="text-muted">
                                        Sin descripci�n
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- ESTADO -->

                            <td class="text-center">

                                <span
                                    class="badge <?= $badgeEstado ?>"
                                >
                                    <?= htmlspecialchars(
                                        $estado,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>

                            </td>


                            <!-- ACCIONES -->

                            <td class="text-end pe-3">

                                <div
                                    class="btn-group btn-group-sm"
                                    role="group"
                                >

                                    <!-- VER -->

                                    <a
                                        href="/servicios/ver/<?= $id ?>"
                                        class="btn btn-outline-secondary"
                                        title="Ver servicio"
                                    >
                                        <i class="bi bi-eye"></i>
                                    </a>


                                    <!-- EDITAR -->

                                    <a
                                        href="/servicios/editar/<?= $id ?>"
                                        class="btn btn-outline-primary"
                                        title="Editar servicio"
                                    >
                                        <i class="bi bi-pencil"></i>
                                    </a>


                                    <!-- BORRAR -->

                                    <button
                                        type="button"
                                        class="btn btn-outline-danger"
                                        title="Borrar servicio"
                                        data-accion="eliminar-servicio"
                                        data-id="<?= $id ?>"
                                    >
                                        <i class="bi bi-trash"></i>
                                    </button>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

</div>

</div>

<!-- =========================================================
     CONFIRMACI�N ELIMINAR
     ========================================================= -->

<div
    class="modal fade"
    id="modalEliminarServicio"
    tabindex="-1"
    aria-hidden="true"
>

<div class="modal-dialog modal-dialog-centered">

    <div class="modal-content">

        <div class="modal-header">

            <h5 class="modal-title text-danger">

                <i class="bi bi-exclamation-triangle me-2"></i>

                Eliminar servicio

            </h5>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
            ></button>

        </div>


        <div class="modal-body">

            <p class="mb-2">
                �Est� seguro de eliminar este servicio t�cnico?
            </p>

            <p class="text-muted small mb-0">
                Esta acci�n no se puede deshacer.
            </p>

        </div>


        <div class="modal-footer">

            <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
            >
                Cancelar
            </button>

            <button
                type="button"
                class="btn btn-danger"
                id="btnConfirmarEliminarServicio"
            >
                <i class="bi bi-trash me-1"></i>
                Eliminar
            </button>

        </div>

    </div>

</div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    let servicioAEliminar = 0;

    const contenedor =
        document.querySelector(
            '[data-servicio-tecnico]'
        );

    const csrf =
        contenedor
            ? (
                contenedor.dataset.csrf || ''
            )
            : '';


    const modalElement =
        document.getElementById(
            'modalEliminarServicio'
        );


    let modal = null;

    if (
        modalElement &&
        typeof bootstrap !== 'undefined'
    ) {

        modal =
            bootstrap.Modal.getOrCreateInstance(
                modalElement
            );
    }


    /*
     * Abrir confirmaci�n
     */
    document.addEventListener(
        'click',
        function (event) {

            const boton =
                event.target.closest(
                    '[data-accion="eliminar-servicio"]'
                );

            if (!boton) {
                return;
            }

            servicioAEliminar =
                parseInt(
                    boton.dataset.id || '0',
                    10
                );

            if (
                servicioAEliminar <= 0
            ) {
                return;
            }


            if (modal) {

                modal.show();

            } else {

                /*
                 * Fallback si Bootstrap JS no est� cargado.
                 */
                if (
                    confirm(
                        '�Est� seguro de eliminar este servicio t�cnico?'
                    )
                ) {

                    eliminarServicio(
                        servicioAEliminar
                    );
                }
            }
        }
    );


    /*
     * Confirmar eliminaci�n
     */
    const botonConfirmar =
        document.getElementById(
            'btnConfirmarEliminarServicio'
        );


    if (botonConfirmar) {

        botonConfirmar.addEventListener(
            'click',
            function () {

                if (
                    servicioAEliminar <= 0
                ) {
                    return;
                }

                eliminarServicio(
                    servicioAEliminar
                );
            }
        );
    }


    /*
     * Eliminar
     */
    function eliminarServicio(id) {

        const form =
            document.createElement(
                'form'
            );

        form.method = 'POST';
        form.action = '/servicios/eliminar';


        const inputCsrf =
            document.createElement(
                'input'
            );

        inputCsrf.type = 'hidden';
        inputCsrf.name = 'csrf';
        inputCsrf.value = csrf;


        const inputId =
            document.createElement(
                'input'
            );

        inputId.type = 'hidden';
        inputId.name = 'id';
        inputId.value = id;


        form.appendChild(
            inputCsrf
        );

        form.appendChild(
            inputId
        );


        document.body.appendChild(
            form
        );


        form.submit();
    }

});
</script>