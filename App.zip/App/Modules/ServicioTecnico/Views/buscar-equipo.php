<?php

declare(strict_types=1);

$texto = trim((string)($texto ?? ''));
$equipos = is_array($equipos ?? null) ? $equipos : [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}
?>

<div class="container-fluid py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <div class="d-flex align-items-center gap-2">
                <div class="st-title-icon">
                    <i class="bi bi-search"></i>
                </div>
                <div>
                    <h1 class="h3 fw-bold mb-0">Buscar equipo</h1>
                    <p class="text-muted mb-0">Buscá por código, serie, modelo, marca o cliente.</p>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-dark" id="btn-escanear-equipo">
                <i class="bi bi-qr-code-scan me-1"></i>
                Escanear QR
            </button>
            <a href="/servicios/nuevo" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i>
                Nuevo servicio
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="get" action="/servicios/buscar-equipo" class="row g-2">
                <div class="col-12 col-lg-10">
                    <label for="buscarEquipoTexto" class="form-label fw-semibold">Equipo</label>
                    <input
                        type="search"
                        class="form-control form-control-lg"
                        id="buscarEquipoTexto"
                        name="texto"
                        value="<?= e($texto) ?>"
                        placeholder="Ej.: serie, código interno, Ricoh, cliente..."
                        autofocus
                    >
                </div>
                <div class="col-12 col-lg-2 d-flex align-items-end">
                    <button class="btn btn-primary btn-lg w-100" type="submit">
                        <i class="bi bi-search me-1"></i>
                        Buscar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($texto === ''): ?>
        <div class="alert alert-info border-0 shadow-sm">
            <i class="bi bi-info-circle me-2"></i>
            Ingresá una serie, código, modelo o cliente. También podés escanear el QR del equipo.
        </div>
    <?php elseif (!$equipos): ?>
        <div class="alert alert-warning border-0 shadow-sm">
            <i class="bi bi-exclamation-triangle me-2"></i>
            No encontramos equipos para <strong><?= e($texto) ?></strong>.
        </div>
    <?php else: ?>
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <strong><?= count($equipos) ?></strong> equipo(s) encontrado(s)
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Equipo</th>
                            <th>Serie</th>
                            <th>Cliente</th>
                            <th>Estado</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($equipos as $equipo): ?>
                        <?php $id = (int)($equipo['id'] ?? 0); ?>
                        <?php if ($id <= 0) continue; ?>
                        <tr>
                            <td class="fw-semibold"><?= e($equipo['codigo_interno'] ?? '-') ?></td>
                            <td>
                                <div class="fw-semibold">
                                    <?= e($equipo['marca'] ?? '') ?> <?= e($equipo['modelo_oficial'] ?? '') ?>
                                </div>
                                <small class="text-muted">ID #<?= $id ?></small>
                            </td>
                            <td><?= e($equipo['serie'] ?? 'S/N') ?></td>
                            <td><?= e($equipo['cliente_nombre'] ?? 'Sin cliente') ?></td>
                            <td><?= e($equipo['estado'] ?? '-') ?></td>
                            <td class="text-end">
                                <div class="btn-group">
                                    <a href="/equipos/<?= $id ?>" class="btn btn-sm btn-outline-primary" title="Ficha del equipo">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="/servicios/nuevo?equipo_id=<?= $id ?>" class="btn btn-sm btn-outline-success" title="Nuevo servicio para este equipo">
                                        <i class="bi bi-tools"></i>
                                    </a>
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-dark btn-qr-equipo"
                                        data-equipo-id="<?= $id ?>"
                                        data-equipo-url="<?= e('/equipos/' . $id) ?>"
                                        title="Mostrar QR"
                                    >
                                        <i class="bi bi-qr-code"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://unpkg.com/html5-qrcode" defer></script>

<div class="modal fade" id="modalQrEquipo" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-qr-code me-2"></i>QR del equipo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body text-center">
                <div id="qr-equipo-preview" class="d-inline-block"></div>
                <div id="qr-equipo-label" class="small text-muted mt-3"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalScannerEquipo" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-qr-code-scan me-2"></i>Buscar equipo por QR</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <div id="equipo-qr-reader" style="width:100%;"></div>
                <div id="equipo-qr-error" class="alert alert-warning mt-3 d-none mb-0"></div>
                <div class="small text-muted mt-2">Apuntá la cámara al QR del equipo.</div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    function equipoIdFromQr(value) {
        var text = String(value || '').trim();
        var match = text.match(/\/equipos\/(\d+)(?:[?#].*)?$/);
        if (match) return parseInt(match[1], 10);
        match = text.match(/(?:^|[?&])(?:equipo|id)=(\d+)/i);
        if (match) return parseInt(match[1], 10);
        match = text.match(/^EQUIPO\s*[:#-]?\s*(\d+)$/i);
        if (match) return parseInt(match[1], 10);
        return 0;
    }

    document.querySelectorAll('.btn-qr-equipo').forEach(function (button) {
        button.addEventListener('click', function () {
            var target = document.getElementById('qr-equipo-preview');
            var label = document.getElementById('qr-equipo-label');
            if (!target || typeof QRCode === 'undefined') return;
            target.innerHTML = '';
            var url = new URL(button.dataset.equipoUrl || '', window.location.origin).href;
            new QRCode(target, {
                text: url,
                width: 220,
                height: 220,
                correctLevel: QRCode.CorrectLevel.M
            });
            label.textContent = 'Equipo #' + (button.dataset.equipoId || '') + ' · ' + url;
            bootstrap.Modal.getOrCreateInstance(document.getElementById('modalQrEquipo')).show();
        });
    });

    var scanButton = document.getElementById('btn-escanear-equipo');
    var modalEl = document.getElementById('modalScannerEquipo');
    var readerEl = document.getElementById('equipo-qr-reader');
    var errorEl = document.getElementById('equipo-qr-error');
    var scanner = null;

    function showError(message) {
        if (!errorEl) return;
        errorEl.textContent = message;
        errorEl.classList.remove('d-none');
    }

    function stopScanner() {
        if (!scanner) return Promise.resolve();
        var current = scanner;
        scanner = null;
        return current.stop().catch(function () {}).then(function () {
            try { current.clear(); } catch (e) {}
        });
    }

    function startScanner() {
        if (typeof Html5Qrcode === 'undefined') {
            showError('No se pudo cargar el lector QR. Verificá la conexión.');
            return;
        }
        errorEl.classList.add('d-none');
        readerEl.innerHTML = '';
        scanner = new Html5Qrcode('equipo-qr-reader');
        scanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: { width: 230, height: 230 } },
            function (decodedText) {
                var id = equipoIdFromQr(decodedText);
                if (!id) {
                    showError('El QR no corresponde a un equipo de CSDI.');
                    return;
                }
                stopScanner().finally(function () {
                    bootstrap.Modal.getOrCreateInstance(modalEl).hide();
                    window.location.href = '/equipos/' + id;
                });
            },
            function () {}
        ).catch(function () {
            showError('No se pudo acceder a la cámara. Revisá el permiso del navegador.');
        });
    }

    if (scanButton && modalEl) {
        scanButton.addEventListener('click', function () {
            bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });
        modalEl.addEventListener('shown.bs.modal', startScanner);
        modalEl.addEventListener('hidden.bs.modal', stopScanner);
    }
})();
</script>
