<?php

declare(strict_types=1);

namespace App\Modules\ListasPrecios\Repositories;

use PDO;
use RuntimeException;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAS
    |--------------------------------------------------------------------------
    */

    public function listar(
        bool $soloActivas = false
    ): array {

        $sql = "
            SELECT
                lp.id,
                lp.nombre,
                lp.descripcion,
                lp.moneda,
                lp.es_predeterminada,
                lp.activo,
                lp.created_at,
                lp.updated_at,

                COUNT(
                    CASE
                        WHEN lpd.activo = 1
                        THEN lpd.id
                    END
                ) AS cantidad_articulos

            FROM listas_precios lp

            LEFT JOIN lista_precios_detalle lpd
                ON lpd.lista_precio_id = lp.id

        ";

        if ($soloActivas) {
            $sql .= "
                WHERE lp.activo = 1
            ";
        }

        $sql .= "
            GROUP BY lp.id
            ORDER BY
                lp.es_predeterminada DESC,
                lp.nombre ASC
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtener(
        int $id
    ): ?array {

        $stmt = $this->db->prepare("
            SELECT
                lp.id,
                lp.nombre,
                lp.descripcion,
                lp.moneda,
                lp.es_predeterminada,
                lp.activo,
                lp.created_at,
                lp.updated_at,

                COUNT(
                    CASE
                        WHEN lpd.activo = 1
                        THEN lpd.id
                    END
                ) AS cantidad_articulos

            FROM listas_precios lp

            LEFT JOIN lista_precios_detalle lpd
                ON lpd.lista_precio_id = lp.id

            WHERE lp.id = :id

            GROUP BY lp.id

            LIMIT 1
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    public function existeNombre(
        string $nombre,
        ?int $exceptoId = null
    ): bool {

        $sql = "
            SELECT COUNT(*)
            FROM listas_precios
            WHERE nombre = :nombre
        ";

        $params = [
            'nombre' => $nombre,
        ];

        if ($exceptoId !== null) {

            $sql .= "
                AND id <> :excepto_id
            ";

            $params['excepto_id'] = $exceptoId;
        }

        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return (int) $stmt->fetchColumn() > 0;
    }

    public function crear(
        array $data
    ): int {

        $stmt = $this->db->prepare("
            INSERT INTO listas_precios
            (
                nombre,
                descripcion,
                moneda,
                es_predeterminada,
                activo
            )
            VALUES
            (
                :nombre,
                :descripcion,
                :moneda,
                0,
                :activo
            )
        ");

        $stmt->execute([
            'nombre' =>
                $data['nombre'],

            'descripcion' =>
                $data['descripcion'] ?? null,

            'moneda' =>
                $data['moneda'] ?? 'ARS',

            'activo' =>
                !empty($data['activo']) ? 1 : 0,
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function actualizar(
        int $id,
        array $data
    ): bool {

        $stmt = $this->db->prepare("
            UPDATE listas_precios
            SET
                nombre = :nombre,
                descripcion = :descripcion,
                moneda = :moneda,
                activo = :activo
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            'id' =>
                $id,

            'nombre' =>
                $data['nombre'],

            'descripcion' =>
                $data['descripcion'] ?? null,

            'moneda' =>
                $data['moneda'] ?? 'ARS',

            'activo' =>
                !empty($data['activo']) ? 1 : 0,
        ]);

        return $stmt->rowCount() > 0;
    }

    public function eliminar(
        int $id
    ): bool {

        /*
         * No eliminamos físicamente.
         */

        $stmt = $this->db->prepare("
            UPDATE listas_precios
            SET activo = 0
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        return $stmt->rowCount() > 0;
    }

    public function establecerPredeterminada(
        int $id
    ): bool {

        $this->db->beginTransaction();

        try {

            $this->db->exec("
                UPDATE listas_precios
                SET es_predeterminada = 0
                WHERE es_predeterminada = 1
            ");

            $stmt = $this->db->prepare("
                UPDATE listas_precios
                SET
                    es_predeterminada = 1,
                    activo = 1
                WHERE id = :id
                LIMIT 1
            ");

            $stmt->execute([
                'id' => $id,
            ]);

            $this->db->commit();

            return $stmt->rowCount() > 0;

        } catch (\Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    public function predeterminada(): ?array
    {
        $stmt = $this->db->query("
            SELECT
                id,
                nombre,
                descripcion,
                moneda,
                es_predeterminada,
                activo
            FROM listas_precios
            WHERE
                activo = 1
                AND es_predeterminada = 1
            ORDER BY id ASC
            LIMIT 1
        ");

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            return $row;
        }

        /*
         * Fallback:
         * primera lista activa.
         */

        $stmt = $this->db->query("
            SELECT
                id,
                nombre,
                descripcion,
                moneda,
                es_predeterminada,
                activo
            FROM listas_precios
            WHERE activo = 1
            ORDER BY id ASC
            LIMIT 1
        ");

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | ARTÍCULOS
    |--------------------------------------------------------------------------
    */

    public function articulos(
        int $listaId,
        array $filtros = []
    ): array {

        $params = [
            'lista_id' => $listaId,
        ];

        $sql = "
            SELECT

                i.id,
                i.nombre_insumo,
                i.codigo_parte,
                i.codigo_barras,
                i.marca,
                i.modelo,
                i.precio_costo,
                i.precio_venta,
                i.stock_actual,
                i.activo,

                COALESCE(
                    lpd.precio,
                    i.precio_venta,
                    0
                ) AS precio_lista,

                lpd.id AS precio_id,
                lpd.activo AS precio_activo

            FROM insumos i

            LEFT JOIN lista_precios_detalle lpd
                ON lpd.insumo_id = i.id
                AND lpd.lista_precio_id = :lista_id

            WHERE i.activo = 1
        ";

        if (!empty($filtros['q'])) {

            $sql .= "
                AND (
                    i.nombre_insumo LIKE :q
                    OR i.codigo_parte LIKE :q
                    OR i.codigo_barras LIKE :q
                    OR i.marca LIKE :q
                    OR i.modelo LIKE :q
                )
            ";

            $params['q'] =
                '%' .
                trim((string) $filtros['q']) .
                '%';
        }

        $sql .= "
            ORDER BY i.nombre_insumo ASC
        ";

        $limit = isset($filtros['limit'])
            ? max(
                1,
                min(
                    200,
                    (int) $filtros['limit']
                )
            )
            : 100;

        $sql .= "
            LIMIT {$limit}
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarArticulos(
        int $listaId,
        string $termino,
        int $limit = 20
    ): array {

        return $this->articulos(
            $listaId,
            [
                'q' => $termino,
                'limit' => $limit,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PRECIO
    |--------------------------------------------------------------------------
    */

    public function obtenerPrecio(
        int $listaId,
        int $insumoId
    ): ?array {

        $stmt = $this->db->prepare("
            SELECT

                i.id AS insumo_id,

                i.nombre_insumo,

                i.codigo_parte,

                i.precio_venta AS precio_base,

                COALESCE(
                    lpd.precio,
                    i.precio_venta,
                    0
                ) AS precio,

                lp.id AS lista_id,

                lp.nombre AS lista_nombre,

                lpd.id AS detalle_id

            FROM insumos i

            INNER JOIN listas_precios lp
                ON lp.id = :lista_id
                AND lp.activo = 1

            LEFT JOIN lista_precios_detalle lpd
                ON lpd.lista_precio_id = lp.id
                AND lpd.insumo_id = i.id
                AND lpd.activo = 1

            WHERE i.id = :insumo_id
            AND i.activo = 1

            LIMIT 1
        ");

        $stmt->execute([
            'lista_id' =>
                $listaId,

            'insumo_id' =>
                $insumoId,
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    public function guardarPrecio(
        int $listaId,
        int $insumoId,
        float $precio
    ): bool {

        $stmt = $this->db->prepare("
            INSERT INTO lista_precios_detalle
            (
                lista_precio_id,
                insumo_id,
                precio,
                activo
            )
            VALUES
            (
                :lista_id,
                :insumo_id,
                :precio,
                1
            )
            ON DUPLICATE KEY UPDATE
                precio = VALUES(precio),
                activo = 1
        ");

        $stmt->execute([
            'lista_id' =>
                $listaId,

            'insumo_id' =>
                $insumoId,

            'precio' =>
                $precio,
        ]);

        return true;
    }

    public function guardarPrecios(
        int $listaId,
        array $precios
    ): int {

        $this->db->beginTransaction();

        try {

            $cantidad = 0;

            $stmt = $this->db->prepare("
                INSERT INTO lista_precios_detalle
                (
                    lista_precio_id,
                    insumo_id,
                    precio,
                    activo
                )
                VALUES
                (
                    :lista_id,
                    :insumo_id,
                    :precio,
                    1
                )
                ON DUPLICATE KEY UPDATE
                    precio = VALUES(precio),
                    activo = 1
            ");

            foreach ($precios as $item) {

                $insumoId =
                    (int) (
                        $item['insumo_id']
                        ?? 0
                    );

                $precio =
                    (float) (
                        $item['precio']
                        ?? 0
                    );

                if ($insumoId <= 0) {
                    continue;
                }

                if ($precio < 0) {
                    continue;
                }

                $stmt->execute([
                    'lista_id' =>
                        $listaId,

                    'insumo_id' =>
                        $insumoId,

                    'precio' =>
                        $precio,
                ]);

                $cantidad++;
            }

            $this->db->commit();

            return $cantidad;

        } catch (\Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | COPIAR LISTA
    |--------------------------------------------------------------------------
    */

    public function copiarLista(
        int $origenId,
        string $nuevoNombre
    ): int {

        $this->db->beginTransaction();

        try {

            $stmt = $this->db->prepare("
                INSERT INTO listas_precios
                (
                    nombre,
                    descripcion,
                    moneda,
                    es_predeterminada,
                    activo
                )

                SELECT
                    :nuevo_nombre,
                    CONCAT(
                        'Copia de ',
                        descripcion
                    ),
                    moneda,
                    0,
                    1

                FROM listas_precios

                WHERE id = :origen_id

                LIMIT 1
            ");

            $stmt->execute([
                'nuevo_nombre' =>
                    $nuevoNombre,

                'origen_id' =>
                    $origenId,
            ]);

            $nuevoId =
                (int) $this->db->lastInsertId();

            if ($nuevoId <= 0) {
                throw new RuntimeException(
                    'No se pudo crear la nueva lista.'
                );
            }

            $stmt = $this->db->prepare("
                INSERT INTO lista_precios_detalle
                (
                    lista_precio_id,
                    insumo_id,
                    precio,
                    activo
                )

                SELECT
                    :nuevo_id,
                    insumo_id,
                    precio,
                    activo

                FROM lista_precios_detalle

                WHERE lista_precio_id = :origen_id
            ");

            $stmt->execute([
                'nuevo_id' =>
                    $nuevoId,

                'origen_id' =>
                    $origenId,
            ]);

            $this->db->commit();

            return $nuevoId;

        } catch (\Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }
}