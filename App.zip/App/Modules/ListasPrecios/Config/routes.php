<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\ListasPrecios\Controllers\Controller;

Router::group(
    '/listas-precios',
    ['auth'],
    function (): void {

        /*
        |--------------------------------------------------------------------------
        | VISTA PRINCIPAL
        |--------------------------------------------------------------------------
        */

        Router::get(
            '',
            [
                Controller::class,
                'index'
            ]
        );

        Router::get(
            '/',
            [
                Controller::class,
                'index'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | CREAR
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/crear',
            [
                Controller::class,
                'crear'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | EDITAR
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/{id}/editar',
            [
                Controller::class,
                'editar'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | API - LISTAS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/listar',
            [
                Controller::class,
                'listar'
            ]
        );

        Router::get(
            '/api/obtener/{id}',
            [
                Controller::class,
                'obtener'
            ]
        );

        Router::post(
            '/api/crear',
            [
                Controller::class,
                'guardar'
            ]
        );

        Router::post(
            '/api/actualizar/{id}',
            [
                Controller::class,
                'actualizar'
            ]
        );

        Router::post(
            '/api/eliminar/{id}',
            [
                Controller::class,
                'eliminar'
            ]
        );

        Router::post(
            '/api/predeterminada/{id}',
            [
                Controller::class,
                'predeterminada'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | API - ARTÍCULOS / PRECIOS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/{listaId}/articulos',
            [
                Controller::class,
                'articulos'
            ]
        );

        Router::get(
            '/api/{listaId}/buscar-articulos',
            [
                Controller::class,
                'buscarArticulos'
            ]
        );

        Router::post(
            '/api/{listaId}/precio',
            [
                Controller::class,
                'guardarPrecio'
            ]
        );

        Router::post(
            '/api/{listaId}/precios',
            [
                Controller::class,
                'guardarPrecios'
            ]
        );

        Router::post(
            '/api/{listaId}/copiar',
            [
                Controller::class,
                'copiarLista'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | API TRANSVERSAL
        |--------------------------------------------------------------------------
        |
        | Estas rutas serán utilizadas por Ventas.
        |
        */

        Router::get(
            '/api/precio',
            [
                Controller::class,
                'precio'
            ]
        );

        Router::get(
            '/api/predeterminada',
            [
                Controller::class,
                'obtenerPredeterminada'
            ]
        );
    }
);