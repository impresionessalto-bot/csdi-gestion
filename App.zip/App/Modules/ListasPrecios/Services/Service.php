<?php

declare(strict_types=1);

namespace App\Modules\ListasPrecios\Services;

use App\Modules\ListasPrecios\Repositories\Repository;
use InvalidArgumentException;

final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | LISTAS
    |--------------------------------------------------------------------------
    */

    public function listar(
        bool $soloActivas = false
    ): array {

        return $this->repository->listar(
            $soloActivas
        );
    }

    public function obtener(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }

        return $this->repository->obtener($id);
    }

    public function crear(
        array $data
    ): int {

        $nombre = trim(
            (string) (
                $data['nombre'] ?? ''
            )
        );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El nombre de la lista es obligatorio.'
            );
        }

        if (
            $this->repository->existeNombre(
                $nombre
            )
        ) {
            throw new InvalidArgumentException(
                'Ya existe una lista con ese nombre.'
            );
        }

        $moneda = strtoupper(
            trim(
                (string) (
                    $data['moneda']
                    ?? 'ARS'
                )
            )
        );

        if ($moneda === '') {
            $moneda = 'ARS';
        }

        $data['nombre'] = $nombre;
        $data['moneda'] = $moneda;

        return $this->repository->crear(
            $data
        );
    }

    public function actualizar(
        int $id,
        array $data
    ): bool {

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'Lista de precios inválida.'
            );
        }

        if (!$this->repository->obtener($id)) {
            throw new InvalidArgumentException(
                'La lista de precios no existe.'
            );
        }

        $nombre = trim(
            (string) (
                $data['nombre'] ?? ''
            )
        );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El nombre de la lista es obligatorio.'
            );
        }

        if (
            $this->repository->existeNombre(
                $nombre,
                $id
            )
        ) {
            throw new InvalidArgumentException(
                'Ya existe otra lista con ese nombre.'
            );
        }

        $data['nombre'] = $nombre;

        return $this->repository->actualizar(
            $id,
            $data
        );
    }

    public function eliminar(
        int $id
    ): bool {

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'Lista de precios inválida.'
            );
        }

        $lista =
            $this->repository->obtener($id);

        if (!$lista) {
            throw new InvalidArgumentException(
                'La lista no existe.'
            );
        }

        if (
            (int) $lista['es_predeterminada'] === 1
        ) {
            throw new InvalidArgumentException(
                'No se puede desactivar la lista predeterminada. Seleccione otra lista primero.'
            );
        }

        return $this->repository->eliminar(
            $id
        );
    }

    public function predeterminada(
        int $id
    ): bool {

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'Lista de precios inválida.'
            );
        }

        if (!$this->repository->obtener($id)) {
            throw new InvalidArgumentException(
                'La lista no existe.'
            );
        }

        return $this->repository
            ->establecerPredeterminada($id);
    }

    public function obtenerPredeterminada(): ?array
    {
        return $this->repository
            ->predeterminada();
    }

    /*
    |--------------------------------------------------------------------------
    | ARTÍCULOS
    |--------------------------------------------------------------------------
    */

    public function articulos(
        int $listaId,
        array $filtros = []
    ): array {

        $this->validarLista(
            $listaId
        );

        return $this->repository->articulos(
            $listaId,
            $filtros
        );
    }

    public function buscarArticulos(
        int $listaId,
        string $termino,
        int $limit = 20
    ): array {

        $this->validarLista(
            $listaId
        );

        $termino =
            trim($termino);

        if ($termino === '') {
            return [];
        }

        $limit = max(
            1,
            min(
                50,
                $limit
            )
        );

        return $this->repository
            ->buscarArticulos(
                $listaId,
                $termino,
                $limit
            );
    }

    /*
    |--------------------------------------------------------------------------
    | PRECIO
    |--------------------------------------------------------------------------
    */

    public function precio(
        int $listaId,
        int $insumoId
    ): ?array {

        $this->validarLista(
            $listaId
        );

        if ($insumoId <= 0) {
            throw new InvalidArgumentException(
                'Artículo inválido.'
            );
        }

        return $this->repository
            ->obtenerPrecio(
                $listaId,
                $insumoId
            );
    }

    public function guardarPrecio(
        int $listaId,
        int $insumoId,
        float $precio
    ): bool {

        $this->validarLista(
            $listaId
        );

        if ($insumoId <= 0) {
            throw new InvalidArgumentException(
                'Artículo inválido.'
            );
        }

        if ($precio < 0) {
            throw new InvalidArgumentException(
                'El precio no puede ser negativo.'
            );
        }

        return $this->repository
            ->guardarPrecio(
                $listaId,
                $insumoId,
                $precio
            );
    }

    public function guardarPrecios(
        int $listaId,
        array $precios
    ): int {

        $this->validarLista(
            $listaId
        );

        return $this->repository
            ->guardarPrecios(
                $listaId,
                $precios
            );
    }

    /*
    |--------------------------------------------------------------------------
    | COPIAR
    |--------------------------------------------------------------------------
    */

    public function copiarLista(
        int $origenId,
        string $nuevoNombre
    ): int {

        $this->validarLista(
            $origenId
        );

        $nuevoNombre =
            trim($nuevoNombre);

        if ($nuevoNombre === '') {
            throw new InvalidArgumentException(
                'Debe indicar el nombre de la nueva lista.'
            );
        }

        return $this->repository
            ->copiarLista(
                $origenId,
                $nuevoNombre
            );
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDACIÓN
    |--------------------------------------------------------------------------
    */

    private function validarLista(
        int $listaId
    ): void {

        if ($listaId <= 0) {
            throw new InvalidArgumentException(
                'Lista de precios inválida.'
            );
        }

        if (!$this->repository->obtener($listaId)) {
            throw new InvalidArgumentException(
                'La lista de precios no existe.'
            );
        }
    }
}