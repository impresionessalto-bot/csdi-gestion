<?php

declare(strict_types=1);

namespace App\Modules\ListasPrecios\Controllers;

use App\Core\BaseController;
use App\Modules\ListasPrecios\Services\Service;
use InvalidArgumentException;
use Throwable;

final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {

            $this->assets()
                ->addModule('ListasPrecios');

            $listas =
                $this->service->listar();

            $predeterminada =
                $this->service
                    ->obtenerPredeterminada();

            $this->moduleView(
                'ListasPrecios',
                'index',
                [
                    'titulo' =>
                        'Listas de precios',

                    'csrf' =>
                        $this->csrf(),

                    'listas' =>
                        $listas,

                    'predeterminada' =>
                        $predeterminada,

                    'error' =>
                        null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(): void
    {
        $this->requireAuth();

        try {

            $this->assets()
                ->addModule('ListasPrecios');

            $this->moduleView(
                'ListasPrecios',
                'form',
                [
                    'titulo' =>
                        'Nueva lista de precios',

                    'csrf' =>
                        $this->csrf(),

                    'lista' =>
                        null,

                    'error' =>
                        null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR
    |--------------------------------------------------------------------------
    */

    public function editar(
        int $id
    ): void {

        $this->requireAuth();

        try {

            if ($id <= 0) {
                $this->notFound(
                    'Lista inválida.'
                );
            }

            $lista =
                $this->service->obtener($id);

            if (!$lista) {
                $this->notFound(
                    'Lista de precios no encontrada.'
                );
            }

            $this->assets()
                ->addModule('ListasPrecios');

            $this->moduleView(
                'ListasPrecios',
                'form',
                [
                    'titulo' =>
                        'Editar lista de precios',

                    'csrf' =>
                        $this->csrf(),

                    'lista' =>
                        $lista,

                    'error' =>
                        null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - LISTAR
    |--------------------------------------------------------------------------
    */

    public function listar(): void
    {
        $this->requireAuth();

        try {

            $soloActivas =
                !empty(
                    $_GET['activas']
                );

            $data =
                $this->service
                    ->listar(
                        $soloActivas
                    );

            $this->json([
                'success' =>
                    true,

                'data' =>
                    $data,

                'total' =>
                    count($data),
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - OBTENER
    |--------------------------------------------------------------------------
    */

    public function obtener(
        int $id
    ): void {

        $this->requireAuth();

        try {

            $data =
                $this->service
                    ->obtener($id);

            if (!$data) {
                $this->notFound(
                    'Lista de precios no encontrada.'
                );
            }

            $this->json([
                'success' =>
                    true,

                'data' =>
                    $data,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - CREAR
    |--------------------------------------------------------------------------
    */

    public function guardar(): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data =
                $this->requestData();

            $id =
                $this->service
                    ->crear($data);

            $this->created(
                [
                    'id' => $id,
                ],
                'Lista de precios creada correctamente.'
            );

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(
        int $id
    ): void {

        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data =
                $this->requestData();

            $ok =
                $this->service
                    ->actualizar(
                        $id,
                        $data
                    );

            $this->json([
                'success' =>
                    $ok,

                'message' =>
                    $ok
                        ? 'Lista actualizada correctamente.'
                        : 'No se realizaron cambios.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(
        int $id
    ): void {

        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $ok =
                $this->service
                    ->eliminar($id);

            $this->json([
                'success' =>
                    $ok,

                'message' =>
                    $ok
                        ? 'Lista desactivada correctamente.'
                        : 'No se pudo desactivar la lista.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - PREDETERMINADA
    |--------------------------------------------------------------------------
    */

    public function predeterminada(
        int $id
    ): void {

        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $ok =
                $this->service
                    ->predeterminada($id);

            $this->json([
                'success' =>
                    $ok,

                'message' =>
                    'Lista predeterminada actualizada correctamente.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    public function obtenerPredeterminada(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service
                    ->obtenerPredeterminada();

            $this->json([
                'success' =>
                    true,

                'data' =>
                    $data,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ARTÍCULOS
    |--------------------------------------------------------------------------
    */

    public function articulos(
        int $listaId
    ): void {

        $this->requireAuth();

        try {

            $data =
                $this->service
                    ->articulos(
                        $listaId,
                        $_GET
                    );

            $this->json([
                'success' =>
                    true,

                'data' =>
                    $data,

                'total' =>
                    count($data),
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    public function buscarArticulos(
        int $listaId
    ): void {

        $this->requireAuth();

        try {

            $termino =
                trim(
                    (string) (
                        $_GET['q'] ?? ''
                    )
                );

            $limit =
                max(
                    1,
                    min(
                        50,
                        (int) (
                            $_GET['limit'] ?? 20
                        )
                    )
                );

            $data =
                $this->service
                    ->buscarArticulos(
                        $listaId,
                        $termino,
                        $limit
                    );

            $this->json([
                'success' =>
                    true,

                'data' =>
                    $data,

                'total' =>
                    count($data),
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - PRECIO
    |--------------------------------------------------------------------------
    */

    public function precio(): void
    {
        $this->requireAuth();

        try {

            $listaId =
                (int) (
                    $_GET['lista_id']
                    ?? 0
                );

            $insumoId =
                (int) (
                    $_GET['insumo_id']
                    ?? 0
                );

            $data =
                $this->service
                    ->precio(
                        $listaId,
                        $insumoId
                    );

            if (!$data) {
                $this->notFound(
                    'No se encontró el artículo.'
                );
            }

            $this->json([
                'success' =>
                    true,

                'data' =>
                    $data,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    public function guardarPrecio(
        int $listaId
    ): void {

        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data =
                $this->requestData();

            $ok =
                $this->service
                    ->guardarPrecio(
                        $listaId,
                        (int) (
                            $data['insumo_id']
                            ?? 0
                        ),
                        (float) (
                            $data['precio']
                            ?? 0
                        )
                    );

            $this->json([
                'success' =>
                    $ok,

                'message' =>
                    'Precio actualizado correctamente.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    public function guardarPrecios(
        int $listaId
    ): void {

        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data =
                $this->requestData();

            $cantidad =
                $this->service
                    ->guardarPrecios(
                        $listaId,
                        is_array(
                            $data['precios']
                                ?? null
                        )
                            ? $data['precios']
                            : []
                    );

            $this->json([
                'success' =>
                    true,

                'message' =>
                    'Precios guardados correctamente.',

                'actualizados' =>
                    $cantidad,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - COPIAR
    |--------------------------------------------------------------------------
    */

    public function copiarLista(
        int $listaId
    ): void {

        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data =
                $this->requestData();

            $nombre =
                trim(
                    (string) (
                        $data['nombre']
                        ?? ''
                    )
                );

            $id =
                $this->service
                    ->copiarLista(
                        $listaId,
                        $nombre
                    );

            $this->created(
                [
                    'id' =>
                        $id,
                ],
                'Lista copiada correctamente.'
            );

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REQUEST
    |--------------------------------------------------------------------------
    */

    private function requestData(): array
    {
        $contentType =
            $_SERVER['CONTENT_TYPE'] ?? '';

        if (
            str_contains(
                strtolower($contentType),
                'application/json'
            )
        ) {

            $raw =
                file_get_contents(
                    'php://input'
                );

            if (
                $raw === false
                ||
                trim($raw) === ''
            ) {
                return [];
            }

            $data =
                json_decode(
                    $raw,
                    true
                );

            return is_array($data)
                ? $data
                : [];
        }

        return $_POST;
    }

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    private function requireCsrfForMutation(): void
    {
        if (!$this->validateCsrf()) {
            throw new InvalidArgumentException(
                'Token CSRF inválido o ausente.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ERRORES
    |--------------------------------------------------------------------------
    */

    private function jsonError(
        Throwable $e
    ): never {

        $status = 400;

        if (
            $e instanceof InvalidArgumentException
        ) {
            $status = 422;
        }

        $errors = [];

        if (
            defined('APP_DEBUG')
            &&
            APP_DEBUG
        ) {

            $errors = [
                'exception' =>
                    get_class($e),

                'file' =>
                    $e->getFile(),

                'line' =>
                    $e->getLine(),
            ];
        }

        $this->json(
            [
                'success' =>
                    false,

                'message' =>
                    $e->getMessage(),

                'errors' =>
                    $errors,
            ],
            $status
        );
    }
}