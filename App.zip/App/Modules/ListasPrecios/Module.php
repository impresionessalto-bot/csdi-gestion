<?php

declare(strict_types=1);

namespace App\Modules\ListasPrecios;

use App\Core\Module as BaseModule;

final class Module extends BaseModule
{
    /**
     * Nombre interno del módulo.
     */
    public function name(): string
    {
        return 'ListasPrecios';
    }

    /**
     * Prioridad de carga.
     *
     * Se carga después de Inventario porque
     * utiliza los insumos como fuente de artículos.
     */
    public function priority(): int
    {
        return 65;
    }

    /**
     * Archivo de rutas.
     */
    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    /**
     * Menú ERP.
     */
    public function menu(): array
    {
        return [
            [
                'title'      => 'Listas de precios',
                'url'        => '/listas-precios',
                'icon'       => 'fa-solid fa-tags',
                'permission' => 'listas_precios.view',
                'order'      => 65,
            ],
        ];
    }

    /**
     * Permisos.
     */
    public function permissions(): array
    {
        return [
            'listas_precios.view',
            'listas_precios.create',
            'listas_precios.edit',
            'listas_precios.delete',
            'listas_precios.prices',
        ];
    }

    /**
     * Bootstrap.
     *
     * No se requiere inicialización adicional.
     */
    public function boot(): void
    {
        // Sin bootstrap adicional.
    }
}
