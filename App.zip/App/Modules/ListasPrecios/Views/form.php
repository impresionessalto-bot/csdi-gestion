<?php

declare(strict_types=1);

$lista =
    $lista ?? null;

$csrf =
    $csrf ?? '';

$editar =
    is_array($lista);

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-tags me-2"></i>

                <?= $editar
                    ? 'Editar lista de precios'
                    : 'Nueva lista de precios'
                ?>

            </h1>

            <p class="text-muted mb-0">
                Configuración general de la lista.
            </p>

        </div>

        <a
            href="/listas-precios"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Volver
        </a>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <form id="listaPrecioForm">

                <div class="row g-3">

                    <div class="col-12 col-md-6">

                        <label class="form-label fw-semibold">
                            Nombre
                        </label>

                        <input
                            type="text"
                            name="nombre"
                            class="form-control"
                            required
                            maxlength="100"
                            value="<?= e(
                                $lista['nombre'] ?? ''
                            ) ?>"
                        >

                    </div>


                    <div class="col-12 col-md-3">

                        <label class="form-label fw-semibold">
                            Moneda
                        </label>

                        <input
                            type="text"
                            name="moneda"
                            class="form-control"
                            maxlength="10"
                            value="<?= e(
                                $lista['moneda'] ?? 'ARS'
                            ) ?>"
                        >

                    </div>


                    <div class="col-12 col-md-3">

                        <label class="form-label fw-semibold">
                            Estado
                        </label>

                        <select
                            name="activo"
                            class="form-select"
                        >

                            <option
                                value="1"
                                <?= (
                                    !isset($lista['activo'])
                                    ||
                                    (int) $lista['activo'] === 1
                                )
                                    ? 'selected'
                                    : ''
                                ?>
                            >
                                Activa
                            </option>

                            <option
                                value="0"
                                <?= (
                                    isset($lista['activo'])
                                    &&
                                    (int) $lista['activo'] === 0
                                )
                                    ? 'selected'
                                    : ''
                                ?>
                            >
                                Inactiva
                            </option>

                        </select>

                    </div>


                    <div class="col-12">

                        <label class="form-label fw-semibold">
                            Descripción
                        </label>

                        <textarea
                            name="descripcion"
                            class="form-control"
                            rows="3"
                            maxlength="255"
                        ><?= e(
                            $lista['descripcion'] ?? ''
                        ) ?></textarea>

                    </div>

                </div>


                <hr class="my-4">


                <div class="alert alert-info mb-0">

                    <i class="bi bi-info-circle me-2"></i>

                    Los precios de los artículos se administran desde
                    la lista. El precio utilizado en una venta queda
                    almacenado en el detalle de esa venta y no cambia
                    aunque posteriormente modifiques la lista.

                </div>


                <div class="d-flex justify-content-end gap-2 mt-4">

                    <a
                        href="/listas-precios"
                        class="btn btn-outline-secondary"
                    >
                        Cancelar
                    </a>

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        <i class="bi bi-check-lg me-1"></i>

                        <?= $editar
                            ? 'Guardar cambios'
                            : 'Crear lista'
                        ?>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script>
document.addEventListener(
    'DOMContentLoaded',
    function () {

        const form =
            document.getElementById(
                'listaPrecioForm'
            );

        form.addEventListener(
            'submit',
            async function (event) {

                event.preventDefault();

                const data =
                    Object.fromEntries(
                        new FormData(form)
                    );

                data._csrf =
                    <?= json_encode($csrf) ?>;

                data.activo =
                    Number(
                        data.activo
                        ?? 1
                    );

                const editar =
                    <?= $editar ? 'true' : 'false' ?>;

                const id =
                    <?= $editar
                        ? (int) $lista['id']
                        : 0
                    ?>;

                const url =
                    editar
                        ? '/listas-precios/api/actualizar/' + id
                        : '/listas-precios/api/crear';

                try {

                    const response =
                        await fetch(
                            url,
                            {
                                method: 'POST',

                                headers: {
                                    'Content-Type':
                                        'application/json',

                                    'X-CSRF-TOKEN':
                                        <?= json_encode($csrf) ?>
                                },

                                body:
                                    JSON.stringify(data)
                            }
                        );

                    const result =
                        await response.json();

                    if (!result.success) {
                        throw new Error(
                            result.message
                            || 'No se pudo guardar.'
                        );
                    }

                    window.location.href =
                        '/listas-precios';

                } catch (error) {

                    alert(
                        error.message
                        || 'Ocurrió un error.'
                    );
                }
            }
        );
    }
);
</script>