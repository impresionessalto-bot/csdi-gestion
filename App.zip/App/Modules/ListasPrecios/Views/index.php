<?php

declare(strict_types=1);

$listas =
    $listas ?? [];

$predeterminada =
    $predeterminada ?? null;

$csrf =
    $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-tags me-2"></i>

                Listas de precios

            </h1>

            <p class="text-muted mb-0">
                Administrá los precios de venta utilizados por el ERP.
            </p>

        </div>

        <a
            href="/listas-precios/crear"
            class="btn btn-primary"
        >
            <i class="bi bi-plus-lg me-1"></i>
            Nueva lista
        </a>

    </div>


    <?php if (!$listas): ?>

        <div class="card border-0 shadow-sm">

            <div class="card-body text-center py-5">

                <i class="bi bi-tags fs-1 text-muted"></i>

                <h5 class="mt-3">
                    No hay listas de precios
                </h5>

                <p class="text-muted">
                    Creá la primera lista para comenzar.
                </p>

                <a
                    href="/listas-precios/crear"
                    class="btn btn-primary"
                >
                    Crear lista
                </a>

            </div>

        </div>

    <?php else: ?>

        <div class="row g-4">

            <?php foreach ($listas as $lista): ?>

                <?php
                $esPredeterminada =
                    (int) (
                        $lista['es_predeterminada']
                        ?? 0
                    ) === 1;

                $activo =
                    (int) (
                        $lista['activo']
                        ?? 0
                    ) === 1;
                ?>

                <div class="col-12 col-md-6 col-xl-4">

                    <div class="card border-0 shadow-sm h-100">

                        <div class="card-body">

                            <div class="d-flex justify-content-between align-items-start">

                                <div>

                                    <h5 class="fw-bold mb-1">

                                        <?= e(
                                            $lista['nombre']
                                        ) ?>

                                    </h5>

                                    <?php if ($esPredeterminada): ?>

                                        <span class="badge text-bg-primary">
                                            Predeterminada
                                        </span>

                                    <?php endif; ?>

                                </div>

                                <?php if ($activo): ?>

                                    <span class="badge text-bg-success">
                                        Activa
                                    </span>

                                <?php else: ?>

                                    <span class="badge text-bg-secondary">
                                        Inactiva
                                    </span>

                                <?php endif; ?>

                            </div>


                            <p class="text-muted small mt-3 mb-3">

                                <?= e(
                                    $lista['descripcion']
                                    ?? 'Sin descripción.'
                                ) ?>

                            </p>


                            <div class="d-flex justify-content-between">

                                <span class="text-muted">
                                    Moneda
                                </span>

                                <strong>
                                    <?= e(
                                        $lista['moneda']
                                        ?? 'ARS'
                                    ) ?>
                                </strong>

                            </div>


                            <div class="d-flex justify-content-between mt-2">

                                <span class="text-muted">
                                    Artículos
                                </span>

                                <strong>
                                    <?= number_format(
                                        (int) (
                                            $lista['cantidad_articulos']
                                            ?? 0
                                        ),
                                        0,
                                        ',',
                                        '.'
                                    ) ?>
                                </strong>

                            </div>

                        </div>


                        <div class="card-footer bg-white border-0 pt-0 pb-3">

                            <div class="d-flex flex-wrap gap-2">

                                <a
                                    href="/listas-precios/<?= (int) $lista['id'] ?>/editar"
                                    class="btn btn-sm btn-outline-primary"
                                >
                                    <i class="bi bi-pencil me-1"></i>
                                    Editar
                                </a>

                                <?php if (!$esPredeterminada && $activo): ?>

                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-success js-predeterminada"
                                        data-id="<?= (int) $lista['id'] ?>"
                                    >
                                        <i class="bi bi-star me-1"></i>
                                        Usar por defecto
                                    </button>

                                <?php endif; ?>

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-danger js-eliminar"
                                    data-id="<?= (int) $lista['id'] ?>"
                                >
                                    <i class="bi bi-x-circle me-1"></i>
                                    Desactivar
                                </button>

                            </div>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>


<script>
window.ListasPrecios = {
    csrf: <?= json_encode($csrf) ?>,

    predeterminadaUrl:
        '/listas-precios/api/predeterminada/',

    eliminarUrl:
        '/listas-precios/api/eliminar/'
};

document.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('.js-predeterminada')
        .forEach(function (button) {

            button.addEventListener('click', async function () {

                const id =
                    this.dataset.id;

                if (!confirm(
                    '¿Establecer esta lista como predeterminada?'
                )) {
                    return;
                }

                try {

                    const response =
                        await fetch(
                            window.ListasPrecios.predeterminadaUrl + id,
                            {
                                method: 'POST',

                                headers: {
                                    'Content-Type':
                                        'application/json',

                                    'X-CSRF-TOKEN':
                                        window.ListasPrecios.csrf
                                },

                                body: JSON.stringify({
                                    _csrf:
                                        window.ListasPrecios.csrf
                                })
                            }
                        );

                    const result =
                        await response.json();

                    if (!result.success) {
                        throw new Error(
                            result.message
                            || 'No se pudo actualizar.'
                        );
                    }

                    window.location.reload();

                } catch (error) {

                    alert(
                        error.message
                        || 'Ocurrió un error.'
                    );
                }
            });
        });


    document.querySelectorAll('.js-eliminar')
        .forEach(function (button) {

            button.addEventListener('click', async function () {

                const id =
                    this.dataset.id;

                if (!confirm(
                    '¿Desactivar esta lista de precios?'
                )) {
                    return;
                }

                try {

                    const response =
                        await fetch(
                            window.ListasPrecios.eliminarUrl + id,
                            {
                                method: 'POST',

                                headers: {
                                    'Content-Type':
                                        'application/json',

                                    'X-CSRF-TOKEN':
                                        window.ListasPrecios.csrf
                                },

                                body: JSON.stringify({
                                    _csrf:
                                        window.ListasPrecios.csrf
                                })
                            }
                        );

                    const result =
                        await response.json();

                    if (!result.success) {
                        throw new Error(
                            result.message
                            || 'No se pudo desactivar.'
                        );
                    }

                    window.location.reload();

                } catch (error) {

                    alert(
                        error.message
                        || 'Ocurrió un error.'
                    );
                }
            });
        });

});
</script>