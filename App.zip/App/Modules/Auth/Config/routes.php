<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Auth\Controllers\AuthController;
use App\Modules\Auth\Controllers\UserController;
use App\Modules\Auth\Controllers\UserPermissionController;

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| MODULE ROUTES: AUTH (Sincronizado al 100% con tu estándar de Router)
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| LOGIN / LOGOUT GLOBALES
|--------------------------------------------------------------------------
*/
Router::get(
    '/login',
    [AuthController::class, 'showLogin']
);

Router::post(
    '/login',
    [AuthController::class, 'login']
);

Router::get(
    '/logout',
    [AuthController::class, 'logout']
);

/*
|--------------------------------------------------------------------------
| ADMIN USUARIOS (Rutas modularizadas de administración)
|--------------------------------------------------------------------------
| CORRECCIÓN CLAVE: Prefijo sin barra inclinada inicial 'admin/usuarios' y 
| middleware simplificado a 'auth' para evitar conflictos con tu Router core.
*/
Router::group(
    'admin/usuarios',
    [
        'auth'
    ],
    function () {

        // Index con barra inclinada
        Router::get(
            '/',
            [UserController::class, 'index']
        );

        // Index de respaldo sin barra inclinada
        Router::get(
            '',
            [UserController::class, 'index']
        );

        // Formulario de creación de usuario
        Router::get(
            '/crear',
            [UserController::class, 'create']
        );

        // Guardar nuevo usuario (POST)
        Router::post(
            '/guardar',
            [UserController::class, 'store']
        );

        // Formulario de edición de usuario
        Router::get(
            '/editar/{id}',
            [UserController::class, 'edit']
        );

        // Actualizar información del usuario (POST)
        Router::post(
            '/actualizar/{id}',
            [UserController::class, 'update']
        );

        // Pantalla de administración de permisos individuales
        Router::get(
            '/permisos/{id}',
            [UserPermissionController::class, 'index']
        );

        // Guardar cambios de permisos individuales (POST)
        Router::post(
            '/permisos/guardar',
            [UserPermissionController::class, 'save']
        );
    }
);