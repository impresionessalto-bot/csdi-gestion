<?php
declare(strict_types=1);

namespace App\Modules\Clientes\Reports;


final class ExcelReport
{


    public function download(
        array $clientes
    ): void
    {


        header(
            'Content-Type: text/csv; charset=utf-8'
        );


        header(
            'Content-Disposition: attachment; filename=clientes.csv'
        );



        $output =
            fopen(
                'php://output',
                'w'
            );



        fputcsv(
            $output,
            [

                'ID',
                'Nombre',
                'Fantasia',
                'Tipo',
                'Localidad',
                'Tarifa',
                'Telefono',
                'Email',
                'Estado'

            ]
        );




        foreach($clientes as $cliente){


            fputcsv(

                $output,

                [

                    $cliente['id'],

                    $cliente['nombre'],

                    $cliente['nombre_fantasia'],

                    $cliente['tipo_cliente'],

                    $cliente['localidad'],

                    $cliente['nombre_tarifa'],

                    $cliente['telefono'],

                    $cliente['email'],

                    $cliente['activo']
                        ? 'Activo'
                        : 'Inactivo'

                ]

            );


        }



        fclose($output);

        exit;

    }


}