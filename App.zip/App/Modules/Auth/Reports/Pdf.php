<?php
declare(strict_types=1);

namespace App\Modules\Clientes\Reports;


use FPDF;



final class PdfReport
{


    public function download(
        array $clientes
    ): void
    {


        $pdf =
            new FPDF(
                'L',
                'mm',
                'A4'
            );



        $pdf->AddPage();



        $pdf->SetFont(
            'Arial',
            'B',
            14
        );


        $pdf->Cell(
            0,
            10,
            'Listado de Clientes CSDI ERP',
            0,
            1,
            'C'
        );



        $pdf->Ln(5);



        $pdf->SetFont(
            'Arial',
            '',
            8
        );



        $pdf->Cell(
            10,
            8,
            'ID',
            1
        );


        $pdf->Cell(
            60,
            8,
            'Cliente',
            1
        );


        $pdf->Cell(
            40,
            8,
            'Localidad',
            1
        );


        $pdf->Cell(
            50,
            8,
            'Tarifa',
            1
        );


        $pdf->Cell(
            40,
            8,
            'Telefono',
            1
        );


        $pdf->Ln();




        foreach($clientes as $cliente){



            $pdf->Cell(
                10,
                8,
                $cliente['id'],
                1
            );



            $pdf->Cell(
                60,
                8,
                mb_substr(
                    $cliente['nombre'],
                    0,
                    30
                ),
                1
            );



            $pdf->Cell(
                40,
                8,
                $cliente['localidad'] ?? '',
                1
            );



            $pdf->Cell(
                50,
                8,
                $cliente['nombre_tarifa'] ?? '',
                1
            );



            $pdf->Cell(
                40,
                8,
                $cliente['telefono'] ?? '',
                1
            );



            $pdf->Ln();


        }




        $pdf->Output(
            'D',
            'clientes.pdf'
        );


        exit;


    }


}