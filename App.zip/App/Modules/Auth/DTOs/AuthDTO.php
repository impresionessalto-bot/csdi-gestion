<?php
declare(strict_types=1);

namespace App\Modules\Auth\DTOs;

use InvalidArgumentException;

final readonly class AuthDTO
{
    public function __construct(
        public string $usuario,
        public string $password
    ) {

        $this->validate();

    }

    /**
     * Crear desde POST
     */
    public static function fromArray(array $data): self
    {
        return new self(
            trim((string)($data['usuario'] ?? '')),
            (string)($data['password'] ?? '')
        );
    }

    /**
     * Validaciones
     */
    private function validate(): void
    {
        if ($this->usuario === '') {
            throw new InvalidArgumentException(
                'Debe ingresar el usuario.'
            );
        }

        if ($this->password === '') {
            throw new InvalidArgumentException(
                'Debe ingresar la contraseña.'
            );
        }

        if (strlen($this->usuario) > 100) {
            throw new InvalidArgumentException(
                'Usuario inválido.'
            );
        }

        if (strlen($this->password) > 255) {
            throw new InvalidArgumentException(
                'Contraseña inválida.'
            );
        }
    }

    /**
     * Exportar
     */
    public function toArray(): array
    {
        return [
            'usuario' => $this->usuario,
            'password' => $this->password
        ];
    }
}