<?php

declare(strict_types=1);

namespace App\Modules\Auth\Controllers;

use App\Core\BaseController;
use App\Services\AuthService;
use RuntimeException;
use Throwable;

final class AuthController extends BaseController
{
    public function __construct(
        private readonly AuthService $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | MOSTRAR LOGIN
    |--------------------------------------------------------------------------
    */
    public function showLogin(): void
    {
        if (
            !empty($_SESSION['user'])
        ) {
            $this->redirect('/dashboard');
        }

        $csrf = $this->csrf();

        /*
        |--------------------------------------------------------------------------
        | DEBUG TEMPORAL CSRF
        |--------------------------------------------------------------------------
        */
        error_log(
            'LOGIN SHOW SESSION ID: '
            . session_id()
        );

        error_log(
            'LOGIN SHOW CSRF: '
            . ($_SESSION['_csrf'] ?? 'VACIO')
        );

        $this->view(
            'login',
            [
                'csrf'  => $csrf,
                'error' => $_GET['error'] ?? null
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PROCESAR LOGIN
    |--------------------------------------------------------------------------
    */
    public function login(): void
    {
        try {
            /*
            |--------------------------------------------------------------------------
            | DEBUG CSRF
            |--------------------------------------------------------------------------
            */
            error_log(
                'LOGIN POST SESSION ID: '
                . session_id()
            );

            error_log(
                'LOGIN POST TOKEN: '
                . ($_POST['_csrf'] ?? 'VACIO')
            );

            error_log(
                'LOGIN POST SESSION CSRF: '
                . ($_SESSION['_csrf'] ?? 'VACIO')
            );

            /*
            |--------------------------------------------------------------------------
            | VALIDAR CSRF (CON DIAGNÓSTICO VISUAL BLINDADO)
            |--------------------------------------------------------------------------
            */
            $postToken = $_POST['_csrf'] ?? $_POST['csrf'] ?? '';
            $sessionToken = $_SESSION['_csrf'] ?? '';

            if (empty($sessionToken) || empty($postToken) || !hash_equals((string)$sessionToken, (string)$postToken)) {
                echo "<div style='background:#111; color:#ff5555; padding:20px; font-family:monospace; margin:20px; border:2px solid #ff5555;'>";
                echo "<h2>🚨 FALLO DE VALIDACIÓN CSRF</h2>";
                echo "<strong>SESSION ID:</strong> " . session_id() . "<br>";
                echo "<strong>Token POST recibido:</strong> " . htmlspecialchars($postToken) . "<br>";
                echo "<strong>Token SESSION esperado:</strong> " . htmlspecialchars($sessionToken) . "<br>";
                echo "<hr>";
                echo "<p>Si el SESSION ID cambia entre la vista y el POST, o si el token POST está vacío, ahí está el origen del problema en tu servidor Ferozo.</p>";
                echo "</div>";
                exit;
            }

            /*
            |--------------------------------------------------------------------------
            | DATOS LOGIN
            |--------------------------------------------------------------------------
            */
            $data = $_POST;

            if (
                empty($data['usuario'])
                &&
                !empty($data['username'])
            ) {
                $data['usuario'] = $data['username'];
            }

            /*
            |--------------------------------------------------------------------------
            | AUTENTICAR
            |--------------------------------------------------------------------------
            */
            $user = $this->service->login(
                $data
            );

            if (
                empty($user)
            ) {
                throw new RuntimeException(
                    'auth'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CREAR SESION ERP (Normalización estricta a minúsculas)
            |--------------------------------------------------------------------------
            */
            $rol = strtolower(
                (string)(
                    $user['rol']
                    ?? $user['role']
                    ?? 'admin'
                )
            );

            $_SESSION['user'] = [
                'id' => (int)(
                    $user['id']
                    ?? 0
                ),
                'usuario' => $user['usuario'] ?? '',
                'nombre'  => $user['nombre'] ?? $user['usuario'] ?? '',
                'rol'     => $rol,
                'role'    => $rol
            ];

            $_SESSION['role'] = $rol;

            error_log(
                'LOGIN OK SESSION: '
                . print_r($_SESSION, true)
            );

            /*
            |--------------------------------------------------------------------------
            | REDIRECCIÓN DINÁMICA DE ACCESOS (Role-Based Dispatcher)
            |--------------------------------------------------------------------------
            | Redirige de forma segura al usuario a su portal según su rol de acceso.
            */
            switch ($rol) {
                case 'admin':
                case 'administrador':
                    // Los administradores entran al dashboard general de operaciones
                    $this->redirect('/dashboard');
                    break;

                case 'tng_viewer':
                    // Los visualizadores entran de forma directa a su Portal TNG
                    $this->redirect('/portal-tng');
                    break;

                case 'cliente':
                case 'portal_cliente':
                    // Los clientes finales ingresan a su portal de autogestión
                    $this->redirect('/portal-cliente');
                    break;

                default:
                    // Redirección segura por defecto para cualquier otro rol
                    $this->redirect('/dashboard');
                    break;
            }

        } catch (Throwable $e) {
            if (
                $e->getMessage()
                ===
                'auth'
            ) {
                $this->redirect(
                    '/login?error=auth'
                );
            }

            echo "<pre>";
            echo "ERROR LOGIN\n\n";
            echo $e->getMessage();
            echo "\n\nArchivo:\n";
            echo $e->getFile();
            echo "\nLinea:\n";
            echo $e->getLine();
            echo "</pre>";
            exit;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | LOGOUT
    |--------------------------------------------------------------------------
    */
    public function logout(): void
    {
        $_SESSION = [];

        if (
            ini_get('session.use_cookies')
        ) {
            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();

        header(
            'Location: /login'
        );
        exit;
    }
}