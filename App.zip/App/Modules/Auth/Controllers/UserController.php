<?php

declare(strict_types=1);

namespace App\Modules\Auth\Controllers;

use App\Core\BaseController;
use App\Modules\Auth\Services\UserService;
use App\Modules\Auth\Services\UserPermissionService;
use App\Services\Permissions\PermissionService;
use Throwable;
use InvalidArgumentException;

/**
 * Controlador de Usuarios de CSDI PRO.
 * Corregido, blindado y sincronizado con el gestor de excepciones BaseController->fail().
 */
final class UserController extends BaseController
{
    /**
     * El constructor recibe las dependencias e inicializa el BaseController.
     */
    public function __construct(
        private readonly UserService $userService,
        private readonly UserPermissionService $permissionService,
        private readonly PermissionService $permissions
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO USUARIOS (Corregido con $this->fail() para revelar fallos reales)
    |--------------------------------------------------------------------------
    */
    public function index(): void
    {
        try {
            $this->permissions->authorize('menu_administracion');

            $usuarios = $this->userService->listarUsuarios();

            $this->moduleView(
                'Auth',
                'index',
                [
                    'titulo'   => 'Gestión de Usuarios',
                    'usuarios' => $usuarios,
                    'csrf'     => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            // CORRECCIÓN CLAVE: Delegamos el fallo al gestor del BaseController
            // Esto revelará inmediatamente en pantalla cuál es el error real (si es de base de datos o de permisos)
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR USUARIO
    |--------------------------------------------------------------------------
    */
    public function create(): void
    {
        $this->permissions->authorize('menu_administracion');

        $this->moduleView(
            'Auth',
            'create',
            [
                'titulo' => 'Nuevo Usuario',
                'csrf'   => $this->csrf()
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR USUARIO
    |--------------------------------------------------------------------------
    */
    public function store(): void
    {
        try {
            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $id = $this->userService->crearUsuario($_POST);

            /*
            |--------------------------------------------------------------------------
            | Guardar permisos iniciales
            |--------------------------------------------------------------------------
            */
            if (
                isset($_POST['permisos'])
                ||
                isset($_POST['individuales'])
            ) {
                $this->permissionService->save((int)$id, $_POST);
            }

            header('Location: /admin/usuarios?success=created');
            exit;
        } catch (Throwable $e) {
            header('Location: /admin/usuarios/crear?error=store_failed');
            exit;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR USUARIO
    |--------------------------------------------------------------------------
    */
    public function edit(mixed $id): void
    {
        try {
            $userId = $this->getId($id);

            $usuario = $this->userService->obtenerPorId($userId);

            if (!$usuario) {
                throw new InvalidArgumentException('Usuario inexistente');
            }

            $permisos = $this->permissionService->edit($userId);

            $this->moduleView(
                'Auth',
                'edit',
                [
                    'titulo'   => 'Editar Usuario',
                    'usuario'  => $usuario,
                    'permisos' => $permisos,
                    'csrf'     => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            header('Location: /admin/usuarios?error=not_found');
            exit;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR USUARIO
    |--------------------------------------------------------------------------
    */
    public function update(mixed $id): void
    {
        try {
            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $userId = $this->getId($id);

            $this->userService->actualizarUsuario($userId, $_POST);

            $this->permissionService->save($userId, $_POST);

            header('Location: /admin/usuarios?success=updated');
            exit;
        } catch (Throwable $e) {
            header('Location: /admin/usuarios?error=update_failed');
            exit;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PANTALLA PERMISOS
    |--------------------------------------------------------------------------
    */
    public function permissions(mixed $id): void
    {
        $userId = $this->getId($id);

        $usuario = $this->userService->obtenerPorId($userId);

        $data = $this->permissionService->edit($userId);

        $this->moduleView(
            'Auth',
            'permissions',
            [
                'usuario'      => $usuario,
                'permisos'     => $data['permisos'],
                'asignados'    => $data['asignados'],
                'individuales' => $data['individuales'],
                'csrf'         => $this->csrf()
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR PERMISOS
    |--------------------------------------------------------------------------
    */
    public function savePermissions(mixed $id): void
    {
        try {
            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $userId = $this->getId($id);

            $this->permissionService->save($userId, $_POST);

            header('Location: /admin/usuarios?success=permissions');
            exit;
        } catch (Throwable $e) {
            header('Location: /admin/usuarios?error=permissions');
            exit;
        }
    }

    /**
     * Obtiene ID desde el router
     */
    private function getId(mixed $id): int
    {
        $value = is_array($id) ? ($id['id'] ?? 0) : $id;
        $id = (int)$value;

        if ($id <= 0) {
            throw new InvalidArgumentException('ID inválido');
        }

        return $id;
    }
}