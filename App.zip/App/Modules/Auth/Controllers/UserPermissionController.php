<?php

declare(strict_types=1);

namespace App\Modules\Auth\Controllers;


use App\Core\BaseController;
use App\Modules\Auth\Services\UserPermissionService;
use Throwable;



final class UserPermissionController extends BaseController
{


    public function __construct(
        private readonly UserPermissionService $service
    )
    {
        parent::__construct();
    }






    /**
     * Pantalla administrar permisos usuario
     */
    public function index(mixed $id):void
    {

        try {


            $usuarioId =
                is_array($id)
                ?
                (int)($id['id'] ?? 0)
                :
                (int)$id;



            if($usuarioId <= 0){

                throw new \RuntimeException(
                    'Usuario inválido'
                );

            }





            $usuario =
                $this->service
                    ->usuario(
                        $usuarioId
                    );




            if(!$usuario){

                throw new \RuntimeException(
                    'Usuario no encontrado'
                );

            }







            $permisos =
                $this->service
                    ->listarPermisos();



            $asignados =
                $this->service
                    ->permisosUsuario(
                        $usuarioId
                    );






            $this->view(
                'permissions',
                [

                    'titulo'=>
                        'Permisos de Usuario',


                    'usuario'=>
                        $usuario,


                    'permisos'=>
                        $permisos,


                    'asignados'=>
                        $asignados,


                    'csrf'=>
                        $this->csrf()

                ]
            );




        }
        catch(Throwable $e)
        {

            $this->view(
                'errors.500',
                [
                    'error'=>
                        $e->getMessage()
                ]
            );

        }


    }









    /**
     * Guardar permisos
     */
    public function save():void
    {


        try {


            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );



            $usuarioId =
                (int)(
                    $_POST['usuario_id']
                    ??
                    0
                );



            $permisos =
                $_POST['permisos']
                ??
                [];





            $this->service
                ->guardar(
                    $usuarioId,
                    $permisos
                );





            header(
                'Location: /admin/usuarios/permisos/'.$usuarioId.'?success=saved'
            );

            exit;



        }
        catch(Throwable $e)
        {

            header(
                'Location: /admin/usuarios?error=permissions'
            );

            exit;

        }


    }




}