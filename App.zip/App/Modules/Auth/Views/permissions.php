<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| AUTH MODULE - PERMISSIONS VIEW (Configurar Permisos de Usuario - Sólido)
|--------------------------------------------------------------------------
*/

$usuario = $usuario ?? [];
$permisos = $permisos ?? [];
$permisosAsignados = $permisosAsignados ?? [];

$usuarioId = (int)($usuario['id'] ?? 0);
$username  = (string)($usuario['usuario'] ?? '');

$permisosMarcados = [];

foreach ($permisosAsignados as $p) {
    if (is_array($p)) {
        if (isset($p['nombre_permiso'])) {
            $permisosMarcados[] = (string)$p['nombre_permiso'];
        }
        if (isset($p['permiso'])) {
            $permisosMarcados[] = (string)$p['permiso'];
        }
    } else {
        $permisosMarcados[] = (string)$p;
    }
}
?>

<div class="container-fluid px-4 py-4 animate-fade-in">

    <!-- =====================================================
         HEADER DE LA SECCIÓN
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">
        <div>
            <h2 class="h4 text-white fw-bold mb-1">
                <i class="fa-solid fa-user-shield text-warning me-2"></i> Configurar Permisos
            </h2>
            <p class="text-muted-erp small mb-0">
                Usuario activo: <strong class="text-white"><?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8') ?></strong>
            </p>
        </div>

        <div>
            <a href="/admin/usuarios" class="btn-erp btn-erp-primary btn-sm text-decoration-none px-3 py-2 fw-semibold shadow-sm">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver al Listado
            </a>
        </div>
    </div>

    <!-- Alerta de éxito controlada -->
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert" style="border-left: 4px solid #198754 !important;">
            <i class="bi bi-check-circle-fill text-success me-2 fs-5"></i> <strong>Éxito:</strong> Permisos de usuario actualizados correctamente en CSDI PRO.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Tarjeta de Configuración de Permisos (Estilo card-erp oscuro) -->
    <div class="card-erp p-4">
        <form method="POST" action="/admin/usuarios/permisos/guardar">
            
            <!-- Tokens de seguridad del controlador -->
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf ?? '', ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf ?? '', ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="usuario_id" value="<?= $usuarioId ?>">

            <div class="row g-3">
                <?php if (empty($permisos)): ?>
                    <div class="col-12 text-center text-muted-erp py-5 fs-6">
                        <i class="fa-solid fa-shield-slash d-block fs-3 mb-2"></i>
                        No hay permisos registrados en el sistema CSDI PRO.
                    </div>
                <?php else: ?>
                    <?php foreach ($permisos as $permiso): ?>
                        <?php
                        // Normalización defensiva de cada permiso (Evita fallos de tipado)
                        $pId    = (int)(is_array($permiso) ? ($permiso['id'] ?? 0) : $permiso);
                        $codigo = (string)(is_array($permiso) ? ($permiso['nombre_permiso'] ?? $permiso['permiso'] ?? '') : $permiso);
                        $desc   = (string)(is_array($permiso) ? ($permiso['descripcion'] ?? '') : '');

                        $checked = in_array($codigo, $permisosMarcados, true);
                        ?>
                        <div class="col-md-6">
                            <div class="card bg-black border-secondary rounded-3">
                                <div class="card-body py-3">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" 
                                               type="checkbox" 
                                               name="permisos[]" 
                                               value="<?= htmlspecialchars($codigo, ENT_QUOTES, 'UTF-8') ?>" 
                                               id="permiso<?= $pId ?>"
                                               <?= $checked ? 'checked' : '' ?>>

                                        <label class="form-check-label text-white fw-bold small ms-2" for="permiso<?= $pId ?>">
                                            <?= htmlspecialchars(strtoupper($codigo), ENT_QUOTES, 'UTF-8') ?>
                                            
                                            <?php if ($desc !== ''): ?>
                                                <br>
                                                <small class="text-muted-erp fw-normal">
                                                    <?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>
                                                </small>
                                            <?php endif; ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Botones de Acción de Envío -->
            <div class="mt-4 pt-3 border-top border-secondary text-end">
                <button type="submit" class="btn btn-warning px-4 fw-bold shadow-sm">
                    <i class="fa-solid fa-save me-1"></i> Guardar Permisos
                </button>
            </div>

        </form>
    </div>
</div>