<div class="col-md-6">

<label for="rol"
class="form-label text-white small fw-semibold">
Rol / Perfil de acceso
</label>


<select
class="form-select form-select-sm bg-dark border-secondary text-white"
id="rol"
name="rol"
>


<option value="admin">
Administrador (Acceso Total)
</option>


<option value="tecnico" selected>
Técnico
</option>


<option value="tng_viewer">
TNG Viewer (Consulta Portal)
</option>


<option value="cliente">
Cliente Portal
</option>


<option value="user">
Usuario Básico
</option>


</select>

</div>