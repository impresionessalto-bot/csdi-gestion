<?php

declare(strict_types=1);

$usuario = is_array($usuario ?? null)
    ? $usuario
    : [];

$nombre = trim(
    (string) (
        $usuario['nombre']
        ?? ''
    )
);

$usuarioLogin = trim(
    (string) (
        $usuario['usuario']
        ?? ''
    )
);

$email = trim(
    (string) (
        $usuario['email']
        ?? ''
    )
);

$rol = trim(
    (string) (
        $usuario['rol']
        ?? ''
    )
);

$activo = (int) (
    $usuario['activo']
    ?? 0
);

$initial = strtoupper(
    substr(
        $nombre !== ''
            ? $nombre
            : $usuarioLogin,
        0,
        1
    )
);

?>

<div class="container-fluid py-4">

    <!-- HEADER -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold mb-1">
                <i class="bi bi-person-circle me-2 text-primary"></i>
                Mi perfil
            </h2>

            <p class="text-muted mb-0">
                Información personal, acceso y seguridad.
            </p>

        </div>

        <a
            href="/admin/usuarios"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Usuarios
        </a>

    </div>


    <div class="row g-4">

        <!-- =================================================
             PERFIL
        ================================================== -->

        <div class="col-lg-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body text-center py-4">

                    <div
                        class="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle bg-primary text-white"
                        style="width:90px;height:90px;font-size:38px;font-weight:700;"
                    >
                        <?= htmlspecialchars(
                            $initial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </div>

                    <h4 class="fw-bold mb-1">

                        <?= htmlspecialchars(
                            $nombre !== ''
                                ? $nombre
                                : $usuarioLogin,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    </h4>

                    <div class="text-muted mb-3">

                        @<?= htmlspecialchars(
                            $usuarioLogin,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    </div>

                    <?php if ($rol !== ''): ?>

                        <span class="badge bg-primary mb-3">

                            <?= htmlspecialchars(
                                strtoupper($rol),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>

                        </span>

                    <?php endif; ?>

                    <div>

                        <?php if ($activo === 1): ?>

                            <span class="badge bg-success-subtle text-success">
                                <i class="bi bi-check-circle me-1"></i>
                                Usuario activo
                            </span>

                        <?php else: ?>

                            <span class="badge bg-danger-subtle text-danger">
                                <i class="bi bi-x-circle me-1"></i>
                                Usuario inactivo
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             INFORMACION
        ================================================== -->

        <div class="col-lg-8">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white py-3">

                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-person-vcard me-2"></i>
                        Información de la cuenta
                    </h5>

                </div>

                <div class="card-body">

                    <div class="row g-4">

                        <div class="col-md-6">

                            <label class="form-label text-muted">
                                Nombre
                            </label>

                            <div class="form-control bg-light">

                                <?= htmlspecialchars(
                                    $nombre,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <label class="form-label text-muted">
                                Usuario
                            </label>

                            <div class="form-control bg-light">

                                <?= htmlspecialchars(
                                    $usuarioLogin,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <label class="form-label text-muted">
                                Email
                            </label>

                            <div class="form-control bg-light">

                                <?= htmlspecialchars(
                                    $email !== ''
                                        ? $email
                                        : 'No informado',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <label class="form-label text-muted">
                                Rol actual
                            </label>

                            <div class="form-control bg-light">

                                <?= htmlspecialchars(
                                    $rol !== ''
                                        ? strtoupper($rol)
                                        : 'Sin rol',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </div>

                        </div>

                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-end">

                        <a
                            href="/admin/usuarios/editar/<?= (int)($usuario['id'] ?? 0) ?>"
                            class="btn btn-primary"
                        >
                            <i class="bi bi-pencil me-1"></i>
                            Editar mi usuario
                        </a>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 SEGURIDAD
            ================================================== -->

            <div class="card border-0 shadow-sm mt-4">

                <div class="card-header bg-white py-3">

                    <h5 class="mb-0 fw-bold">

                        <i class="bi bi-shield-check me-2 text-success"></i>

                        Seguridad

                    </h5>

                </div>

                <div class="card-body">

                    <div class="d-flex align-items-center gap-3">

                        <div
                            class="rounded-circle bg-success-subtle text-success d-flex align-items-center justify-content-center"
                            style="width:45px;height:45px;"
                        >
                            <i class="bi bi-key"></i>
                        </div>

                        <div class="flex-grow-1">

                            <strong class="d-block">
                                Contraseña
                            </strong>

                            <small class="text-muted">
                                Administrada desde la configuración del usuario.
                            </small>

                        </div>

                        <a
                            href="/admin/usuarios/editar/<?= (int)($usuario['id'] ?? 0) ?>"
                            class="btn btn-outline-primary btn-sm"
                        >
                            Administrar
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>