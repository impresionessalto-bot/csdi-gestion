<?php
declare(strict_types=1);

use App\Components\Cards\StandardCard;

// Garantizamos de forma defensiva la existencia de la variable de datos
$usuarios = $usuarios ?? [];

// Instanciamos el componente de tarjeta del CSDI UI Framework
$card = new StandardCard();
?>
<div class="container-fluid px-4 py-4">
    <!-- Alertas de éxito de operaciones -->
    <?php if (isset($_GET['success']) && $_GET['success'] === 'created'): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> Usuario creado correctamente.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success']) && $_GET['success'] === 'updated'): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> Usuario actualizado correctamente.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Header de la sección y botón Nuevo Usuario -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h4 text-white fw-bold mb-1">
                <i class="fa-solid fa-user-shield me-2"></i> Gestión de Usuarios
            </h2>
            <small class="text-muted-erp">Administración de accesos y roles del sistema CSDI ERP</small>
        </div>
        <div>
            <a href="/admin/usuarios/crear" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                <i class="fa-solid fa-plus me-1"></i> Nuevo Usuario
            </a>
        </div>
    </div>

    <?php 
    // Capturamos el contenido de la tabla en un búfer de salida para inyectarlo en el componente
    ob_start(); 
    ?>
    <div class="table-responsive">
        <table class="table-erp align-middle">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario / Nombre</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th width="150">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($usuarios)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted-erp py-4">No hay usuarios registrados.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($usuarios as $user): ?>
                        <?php 
                        // Normalización defensiva para prevenir TypeErrors por inconsistencias de base de datos
                        $userId      = (int)(is_array($user) ? ($user['id'] ?? 0) : $user);
                        $userUsuario = (string)(is_array($user) ? ($user['usuario'] ?? '') : $user);
                        $userNombre  = (string)(is_array($user) ? ($user['nombre'] ?? '-') : $user);
                        $userEmail   = (string)(is_array($user) ? ($user['email'] ?? '-') : $user);
                        $userRol     = (string)(is_array($user) ? ($user['rol'] ?? '') : $user);
                        $userActivo  = !empty(is_array($user) ? ($user['activo'] ?? false) : false);
                        ?>
                        <tr>
                            <td><?= htmlspecialchars((string)$userId, ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <strong><?= htmlspecialchars($userUsuario, ENT_QUOTES, 'UTF-8') ?></strong><br>
                                <small class="text-muted-erp"><?= htmlspecialchars($userNombre, ENT_QUOTES, 'UTF-8') ?></small>
                            </td>
                            <td><?= htmlspecialchars($userEmail, ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <span class="badge-erp badge-info">
                                    <?= htmlspecialchars(strtoupper($userRol), ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($userActivo): ?>
                                    <span class="badge-erp badge-success">Activo</span>
                                <?php else: ?>
                                    <span class="badge-erp badge-danger">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="/admin/usuarios/editar/<?= $userId ?>" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                                    <i class="fa-solid fa-pen me-1"></i> Editar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php 
    $tablaHtml = ob_get_clean(); 

    // Renderizado e inyección dinámica del componente de tarjeta
    echo $card->with([
        'title'   => '', // Omitimos el título interno porque ya lo dibuja el Header de la sección
        'content' => $tablaHtml
    ])->render(); 
    ?>
</div>