<?php

declare(strict_types=1);


$usuario =
    $usuario
    ??
    [];


$rolActual =
    strtolower(
        $usuario['rol']
        ??
        'tecnico'
    );


?>



<div class="container-fluid px-4 py-4">



<div class="d-flex justify-content-between align-items-center mb-4">


<div>

<h2 class="h4 text-white fw-bold">

<i class="bi bi-pencil-square text-warning me-2"></i>

Editar Usuario

</h2>


<p class="text-muted">

<?= htmlspecialchars($usuario['usuario'] ?? '') ?>

</p>


</div>


<a href="/admin/usuarios"
class="btn btn-outline-secondary btn-sm">

Volver

</a>


</div>







<div class="card bg-dark border-secondary">


<div class="card-body">



<form method="POST"
action="/admin/usuarios/actualizar/<?= (int)$usuario['id'] ?>">



<input type="hidden"
name="_csrf"
value="<?= htmlspecialchars($csrf ?? '') ?>">






<div class="row g-3">






<div class="col-md-6">

<label class="text-white small">

Usuario

</label>


<input class="form-control bg-dark text-white"
value="<?= htmlspecialchars($usuario['usuario'] ?? '') ?>"
disabled>


</div>







<div class="col-md-6">


<label class="text-white small">

Nombre

</label>


<input class="form-control bg-dark text-white"
name="nombre"
value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>">


</div>







<div class="col-md-6">


<label class="text-white small">

Email

</label>


<input class="form-control bg-dark text-white"
name="email"
value="<?= htmlspecialchars($usuario['email'] ?? '') ?>">


</div>







<div class="col-md-6">


<label class="text-white small">

Nueva contraseña

</label>


<input type="password"
name="password"
class="form-control bg-dark text-white"
placeholder="Dejar vacío mantiene actual">


</div>









<div class="col-md-6">


<label class="text-white small">

Rol

</label>



<select name="rol"
class="form-select bg-dark text-white">


<option value="admin"
<?= $rolActual==='admin'?'selected':'' ?>>

Administrador

</option>



<option value="tecnico"
<?= $rolActual==='tecnico'?'selected':'' ?>>

Técnico

</option>




<option value="tng_viewer"
<?= $rolActual==='tng_viewer'?'selected':'' ?>>

TNG Viewer

</option>




<option value="cliente"
<?= $rolActual==='cliente'?'selected':'' ?>>

Cliente Portal

</option>



</select>



</div>









<div class="col-md-6">


<label class="text-white small">

Cliente TNG asociado

</label>


<input type="number"
name="linked_cliente_id"
class="form-control bg-dark text-white"
value="<?= htmlspecialchars((string)($usuario['linked_cliente_id'] ?? '')) ?>">


</div>








<div class="col-md-6">


<div class="form-check form-switch mt-4">


<input class="form-check-input"
type="checkbox"
name="activo"
value="1"
<?= (($usuario['activo'] ?? 1)==1)
?'checked'
:''
?>>


<label class="text-white">

Activo

</label>


</div>


</div>






</div>








<div class="text-end border-top border-secondary mt-4 pt-3">


<a href="/admin/usuarios"
class="btn btn-secondary">

Cancelar

</a>



<button class="btn btn-warning">

Actualizar

</button>


</div>






</form>


</div>


</div>


</div>