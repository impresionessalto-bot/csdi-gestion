<?php

declare(strict_types=1);


$error = $error ?? null;

$csrf = $csrf ?? '';

$oldUsuario =
    $_POST['usuario']
    ?? '';



if (!function_exists('e')) {

    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }

}


?>
<!doctype html>

<html lang="es">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        CSDI ERP PRO
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>


<body class="bg-dark">


<div class="container vh-100 d-flex justify-content-center align-items-center">


    <div
        class="card shadow"
        style="width:430px"
    >


        <div class="card-body p-4">



            <div class="text-center mb-4">

                <h3 class="fw-bold">
                    CSDI ERP PRO
                </h3>


                <small class="text-muted">
                    Sistema de Gestión Empresarial
                </small>

            </div>




            <?php if($error): ?>


                <div class="alert alert-danger">

                    <?php

                    switch($error){

                        case 'auth':

                            echo 'Usuario o contraseña incorrectos.';

                        break;


                        case 'csrf':

                            echo 'La sesión expiró. Recargue e intente nuevamente.';

                        break;


                        case 'system':

                            echo 'Error interno del sistema.';

                        break;


                        default:

                            echo e($error);

                    }

                    ?>

                </div>


            <?php endif; ?>






            <form
                method="post"
                action="<?= e(base_url('/login')) ?>"
            >



                <input
                    type="hidden"
                    name="_csrf"
                    value="<?= e($csrf) ?>"
                >




                <div class="mb-3">


                    <label class="form-label">
                        Usuario
                    </label>


                    <input
                        type="text"
                        name="usuario"
                        class="form-control"
                        value="<?= e($oldUsuario) ?>"
                        required
                        autofocus
                        autocomplete="username"
                    >


                </div>





                <div class="mb-4">


                    <label class="form-label">
                        Contraseña
                    </label>


                    <input
                        type="password"
                        name="password"
                        class="form-control"
                        required
                        autocomplete="current-password"
                    >


                </div>





                <button
                    type="submit"
                    class="btn btn-primary w-100"
                >

                    Ingresar

                </button>


            </form>






            <hr>




            <div class="text-center">


                <small class="text-muted">
                    ¿Cliente nuevo?
                </small>


                <br>


                <a
                    href="<?= e(base_url('/registro-cliente')) ?>"
                    class="text-decoration-none fw-semibold"
                >

                    Crear cuenta institucional

                </a>


            </div>





        </div>


    </div>


</div>




<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>


</body>

</html>