<?php

declare(strict_types=1);

namespace App\Modules\Auth\Services;

use App\Core\BaseService;
use App\Modules\Auth\Repositories\AuthRepository;
use RuntimeException;


final class AuthService extends BaseService
{


    public function __construct(
        private AuthRepository $repository
    ){}





    /**
     * Login completo
     */
    public function login(
        array $data
    ): array
    {


        $usuario =
            trim(
                (string)($data['usuario'] ?? '')
            );


        $password =
            (string)($data['password'] ?? '');




        $user =
            $this->authenticate(
                $usuario,
                $password
            );




        if(!$user){

            throw new RuntimeException(
                'Usuario o contraseña incorrectos'
            );

        }




        if(
            session_status()
            !==
            PHP_SESSION_ACTIVE
        ){

            session_start();

        }




        session_regenerate_id(true);





        $_SESSION['user'] = [

            'id'=>
                $user['id']
                ??
                null,


            'usuario'=>
                $user['usuario']
                ??
                '',


            'nombre'=>
                $user['nombre']
                ??
                '',


            'email'=>
                $user['email']
                ??
                '',


            'rol'=>
                $user['rol']
                ??
                'usuario',


            'role'=>
                $user['rol']
                ??
                'usuario',



            'es_superadmin'=>
                (int)
                (
                    $user['es_superadmin']
                    ??
                    0
                ),



            /*
            |--------------------------------------------------------------------------
            | Portal Cliente TNG
            |--------------------------------------------------------------------------
            */

            'linked_cliente_id'=>
                $user['linked_cliente_id']
                ??
                null


        ];




        return $_SESSION['user'];

    }









    /**
     * Validar usuario y contraseña
     */
    public function authenticate(
        string $usuario,
        string $password
    ): ?array
    {


        $usuario =
            trim($usuario);




        if(
            $usuario === ''
            ||
            $password === ''
        ){

            return null;

        }




        $user =
            $this->repository
                ->findByUsername(
                    $usuario
                );




        if(!$user){

            return null;

        }




        if(
            isset($user['activo'])
            &&
            (int)$user['activo'] !== 1
        ){

            return null;

        }




        $storedPassword =
            $user['password']
            ??
            '';





        /*
        |--------------------------------------------------------------------------
        | Password HASH
        |--------------------------------------------------------------------------
        */


        if(
            $storedPassword !== ''
            &&
            password_verify(
                $password,
                $storedPassword
            )
        ){

            unset(
                $user['password']
            );


            return $user;

        }





        /*
        |--------------------------------------------------------------------------
        | Password texto plano legacy
        |--------------------------------------------------------------------------
        */


        if(
            $storedPassword !== ''
            &&
            hash_equals(
                $storedPassword,
                $password
            )
        ){

            unset(
                $user['password']
            );


            return $user;

        }




        return null;


    }









    public function find(
        int $id
    ): ?array
    {

        return $this->repository
            ->findById(
                $id
            );

    }









    public function changePassword(
        int $id,
        string $password
    ): bool
    {


        $hash =
            password_hash(
                $password,
                PASSWORD_DEFAULT
            );



        return $this->repository
            ->updatePassword(
                $id,
                $hash
            );


    }



}