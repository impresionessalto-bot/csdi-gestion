<?php

declare(strict_types=1);

namespace App\Modules\Auth\Services;


use App\Modules\Auth\Repositories\UserPermissionRepository;
use RuntimeException;
use Throwable;



final class UserPermissionService
{


    public function __construct(
        private readonly UserPermissionRepository $repository
    )
    {

    }







    /**
     * Usuario
     */
    public function usuario(
        int $id
    ): ?array
    {

        return $this->repository
            ->findUser(
                $id
            );

    }








    /**
     * Todos los permisos disponibles
     */
    public function listarPermisos(): array
    {

        return $this->repository
            ->allPermissions();

    }








    /**
     * Permisos actuales del usuario
     */
    public function permisosUsuario(
        int $usuarioId
    ): array
    {


        return $this->repository
            ->getByUser(
                $usuarioId
            );


    }









    /**
     * Guardar permisos
     *
     * permisos[]
     *
     * contiene códigos:
     *
     * menu_clientes
     * menu_equipos
     *
     */
    public function guardar(
        int $usuarioId,
        array $permisos
    ): bool
    {

        try {


            $this->repository
                ->removeAll(
                    $usuarioId
                );




            foreach($permisos as $permiso)
            {


                if(
                    trim((string)$permiso)===''
                ){
                    continue;
                }



                $this->repository
                    ->assignByCode(
                        $usuarioId,
                        (string)$permiso
                    );


            }



            return true;


        }
        catch(Throwable $e)
        {

            throw new RuntimeException(

                'Error guardando permisos: '
                .
                $e->getMessage()

            );

        }


    }









    /**
     * Guardar permisos internos
     *
     * clientes_ver
     * servicios_crear
     *
     */
    public function guardarInternos(
        int $usuarioId,
        array $permisos
    ):bool
    {


        try {


            foreach($permisos as $codigo=>$valor)
            {


                $this->repository
                    ->savePermission(

                        $usuarioId,

                        (string)$codigo,

                        (int)$valor

                    );


            }



            return true;


        }
        catch(Throwable $e)
        {

            throw new RuntimeException(

                'Error permisos internos: '
                .
                $e->getMessage()

            );


        }


    }









    /**
     * Datos completos para editar
     */
    public function editar(
        int $usuarioId
    ):array
    {


        return [

            'usuario'=>
                $this->usuario(
                    $usuarioId
                ),


            'permisos'=>
                $this->listarPermisos(),


            'asignados'=>
                $this->permisosUsuario(
                    $usuarioId
                )

        ];


    }









    /**
     * Super administrador
     */
    public function puedeAdministrar():bool
    {


        $user =
            $_SESSION['user']
            ??
            [];



        return

            !empty(
                $user['es_superadmin']
            )

            &&

            (int)$user['es_superadmin']===1;


    }



}