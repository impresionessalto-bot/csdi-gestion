<?php

declare(strict_types=1);

namespace App\Modules\Auth\Services;


use App\Modules\Auth\Repositories\UserRepository;
use RuntimeException;
use Throwable;



final class UserService
{


    private UserRepository $userRepository;


    private UserPermissionService $permissionService;





    public function __construct(
        UserRepository $userRepository,
        UserPermissionService $permissionService
    )
    {

        $this->userRepository =
            $userRepository;


        $this->permissionService =
            $permissionService;

    }









    /**
     * Lista usuarios
     */
    public function listarUsuarios(): array
    {

        return
            $this->userRepository
                ->getAll();

    }









    /**
     * Obtener usuario
     */
    public function obtenerPorId(
        int $id
    ): ?array
    {

        return
            $this->userRepository
                ->findById(
                    $id
                );

    }









    /**
     * Crear usuario
     */
    public function crearUsuario(
        array $data
    ): bool
    {


        try {


            $rol =
                $this->normalizarRol(
                    $data['rol'] ?? 'cliente'
                );




            /*
            |--------------------------------------------------------------------------
            | Solo superadmin crea administradores
            |--------------------------------------------------------------------------
            */


            if(
                $rol === 'admin'
                &&
                !$this->esSuperAdmin()
            ){

                $rol = 'cliente';

            }







            $password =
                (string)(
                    $data['password']
                    ??
                    ''
                );



            if($password === '')
            {

                throw new RuntimeException(
                    'Debe ingresar contraseña'
                );

            }







            $payload = [


                'usuario'=>
                    trim(
                        $data['usuario']
                        ??
                        ''
                    ),


                'nombre'=>
                    trim(
                        $data['nombre']
                        ??
                        ''
                    ),


                'email'=>
                    $data['email']
                    ??
                    null,


                'password'=>
                    password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    ),


                'rol'=>
                    $rol,


                'activo'=>
                    isset($data['activo'])
                    ?
                    1
                    :
                    0


            ];







            $resultado =
                $this->userRepository
                    ->create(
                        $payload
                    );







            if($resultado)
            {


                $id =
                    $this->userRepository
                        ->lastInsertId();



                if(!empty($data['permisos']))
                {

                    $this->permissionService
                        ->guardarPermisos(

                            (int)$id,

                            $data['permisos']

                        );

                }


            }






            return $resultado;



        }
        catch(Throwable $e)
        {

            throw new RuntimeException(

                $e->getMessage()

            );

        }


    }









    /**
     * Actualizar usuario
     */
    public function actualizarUsuario(
        int $id,
        array $data
    ): bool
    {


        try {



            $rol =
                $this->normalizarRol(
                    $data['rol']
                    ??
                    'cliente'
                );





            if(
                $rol === 'admin'
                &&
                !$this->esSuperAdmin()
            )
            {

                $rol='cliente';

            }







            $payload=[



                'nombre'=>
                    trim(
                        $data['nombre']
                        ??
                        ''
                    ),



                'email'=>
                    $data['email']
                    ??
                    null,



                'rol'=>
                    $rol,



                'activo'=>
                    isset($data['activo'])
                    ?
                    1
                    :
                    0



            ];







            if(
                !empty(
                    $data['password']
                )
            )
            {


                $payload['password'] =

                    password_hash(

                        $data['password'],

                        PASSWORD_DEFAULT

                    );


            }







            $resultado =
                $this->userRepository
                    ->update(
                        $id,
                        $payload
                    );








            if(
                !empty(
                    $data['permisos']
                )
            )
            {

                $this->permissionService
                    ->guardarPermisos(

                        $id,

                        $data['permisos']

                    );


            }








            return $resultado;



        }
        catch(Throwable $e)
        {

            throw new RuntimeException(

                $e->getMessage()

            );

        }


    }









    /**
     * Roles permitidos ERP
     */
    public function roles():array
    {

        return [

            'admin'=>
                'Administrador',


            'tecnico'=>
                'Técnico',


            'tng_viewer'=>
                'Visor Portal TNG',


            'cliente'=>
                'Cliente'


        ];

    }









    /**
     * Normalizar roles
     */
    private function normalizarRol(
        string $rol
    ):string
    {

        $rol =
            strtolower(
                trim($rol)
            );



        if(
            !array_key_exists(
                $rol,
                $this->roles()
            )
        ){

            return 'cliente';

        }


        return $rol;


    }









    /**
     * Usuario superadmin
     */
    private function esSuperAdmin():bool
    {

        return

            !empty(
                $_SESSION['user']['es_superadmin']
            )

            &&

            (int)
            $_SESSION['user']['es_superadmin']
            ===
            1;


    }



}