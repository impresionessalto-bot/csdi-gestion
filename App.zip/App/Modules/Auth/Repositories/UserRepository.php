<?php

declare(strict_types=1);

namespace App\Modules\Auth\Repositories;


use PDO;
use RuntimeException;



final class UserRepository
{


    private PDO $db;





    public function __construct(
        PDO $db
    )
    {

        $this->db = $db;

    }









    /**
     * Listado usuarios
     */
    public function getAll():array
    {


        $sql = "

            SELECT

                id,
                usuario,
                nombre,
                email,
                rol,
                activo,
                linked_cliente_id,
                es_superadmin


            FROM usuarios


            ORDER BY id DESC

        ";




        $stmt =
            $this->db->query(
                $sql
            );



        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );


    }









    /**
     * Buscar usuario por ID
     */
    public function findById(
        int $id
    ):?array
    {


        $sql = "

            SELECT

                id,
                usuario,
                nombre,
                email,
                rol,
                activo,
                linked_cliente_id,
                es_superadmin


            FROM usuarios


            WHERE id = ?


            LIMIT 1

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        $stmt->execute([
            $id
        ]);




        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );



        return
            $data !== false
            ?
            $data
            :
            null;


    }









    /**
     * Crear usuario
     */
    public function create(
        array $data
    ):bool
    {


        $sql = "

            INSERT INTO usuarios
            (

                usuario,
                nombre,
                email,
                password,
                rol,
                activo

            )

            VALUES
            (

                ?,
                ?,
                ?,
                ?,
                ?,
                ?

            )

        ";




        $stmt =
            $this->db->prepare(
                $sql
            );



        return
            $stmt->execute([


                $data['usuario'],

                $data['nombre'],

                $data['email'],

                $data['password'],

                $data['rol'],

                $data['activo']


            ]);


    }









    /**
     * Ultimo ID insertado
     */
    public function lastInsertId():int
    {

        return
            (int)
            $this->db
                ->lastInsertId();

    }









    /**
     * Actualizar usuario
     */
    public function update(
        int $id,
        array $data
    ):bool
    {



        $fields=[];

        $values=[];






        /*
        |--------------------------------------------------------------------------
        | Campos editables
        |--------------------------------------------------------------------------
        */


        $allowed=[

            'nombre',

            'email',

            'rol',

            'activo',

            'linked_cliente_id',

            'password'

        ];






        foreach($allowed as $field)
        {


            if(
                array_key_exists(
                    $field,
                    $data
                )
            )
            {


                if(
                    $field === 'password'
                    &&
                    $data[$field] === ''
                ){

                    continue;

                }




                $fields[] =
                    "{$field} = ?";


                $values[] =
                    $data[$field];


            }


        }








        if(empty($fields))
        {

            return false;

        }








        $values[] =
            $id;






        $sql = "

            UPDATE usuarios

            SET

                "
                .
                implode(
                    ', ',
                    $fields
                )
                .

            "

            WHERE id = ?

            LIMIT 1

        ";








        $stmt =
            $this->db->prepare(
                $sql
            );





        return
            $stmt->execute(
                $values
            );


    }









    /**
     * Eliminar usuario
     */
    public function delete(
        int $id
    ):bool
    {


        $stmt =
            $this->db->prepare(
                "
                DELETE FROM usuarios
                WHERE id = ?
                LIMIT 1
                "
            );



        return
            $stmt->execute([
                $id
            ]);


    }




}