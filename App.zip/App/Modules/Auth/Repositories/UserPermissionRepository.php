<?php

declare(strict_types=1);

namespace App\Modules\Auth\Repositories;

use App\Core\BaseRepository;
use PDO;


final class UserPermissionRepository extends BaseRepository
{
    protected string $table = 'usuario_permisos';



    /**
     * Obtener permisos del usuario
     */
    public function getByUser(
        int $usuarioId
    ): array
    {

        $sql = "

            SELECT

                p.id,
                p.nombre_permiso,
                p.descripcion

            FROM usuario_permisos up

            INNER JOIN permisos p
                ON p.id = up.permiso_id

            WHERE up.usuario_id = :usuario

            ORDER BY p.id

        ";


        $stmt =
            $this->db->prepare($sql);


        $stmt->execute([

            'usuario'=>$usuarioId

        ]);


        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Obtener todos los permisos disponibles
     */
    public function all(): array
    {

        $sql = "

            SELECT *

            FROM permisos

            ORDER BY id

        ";


        return
            $this->db
                ->query($sql)
                ->fetchAll(
                    PDO::FETCH_ASSOC
                );

    }





    /**
     * Asignar permiso menu
     */
    public function assign(
        int $usuarioId,
        int $permisoId
    ): bool
    {


        $sql = "

            INSERT INTO usuario_permisos

            (
                usuario_id,
                permiso_id
            )

            VALUES

            (
                :usuario,
                :permiso
            )

            ON DUPLICATE KEY UPDATE
                permiso_id = VALUES(permiso_id)

        ";


        $stmt =
            $this->db->prepare($sql);


        return $stmt->execute([

            'usuario'=>$usuarioId,

            'permiso'=>$permisoId

        ]);

    }





    /**
     * Quitar todos los permisos
     */
    public function removeAll(
        int $usuarioId
    ): bool
    {


        $sql = "

            DELETE FROM usuario_permisos

            WHERE usuario_id=:usuario

        ";


        $stmt =
            $this->db->prepare($sql);


        return $stmt->execute([

            'usuario'=>$usuarioId

        ]);

    }






    /**
     * Permisos internos
     * tabla permisos_usuarios
     */
    public function savePermission(
        int $usuarioId,
        string $permiso,
        int $valor = 1
    ): bool
    {


        $sql = "

            INSERT INTO permisos_usuarios

            (
                usuario_id,
                permiso,
                valor
            )

            VALUES

            (
                :usuario,
                :permiso,
                :valor
            )


            ON DUPLICATE KEY UPDATE

                valor = VALUES(valor)

        ";


        $stmt =
            $this->db->prepare($sql);



        return $stmt->execute([


            'usuario'=>$usuarioId,

            'permiso'=>$permiso,

            'valor'=>$valor


        ]);

    }






    /**
     * Eliminar permisos internos
     */
    public function deleteUserPermissions(
        int $usuarioId
    ): bool
    {

        $sql = "

            DELETE FROM permisos_usuarios

            WHERE usuario_id=:usuario

        ";


        $stmt =
            $this->db->prepare($sql);



        return $stmt->execute([

            'usuario'=>$usuarioId

        ]);

    }



}