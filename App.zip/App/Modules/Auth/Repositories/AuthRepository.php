<?php

declare(strict_types=1);

namespace App\Modules\Auth\Repositories;

use App\Core\BaseRepository;
use PDO;


final class AuthRepository extends BaseRepository
{

    protected string $table = 'usuarios';





    /**
     * Buscar usuario por nombre
     */
    public function findByUsername(
        string $usuario
    ): ?array
    {

        $sql = "
            SELECT *
            FROM {$this->table}
            WHERE usuario = :usuario
            LIMIT 1
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            'usuario'=>$usuario

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $this->normalizeUser(
            $data ?: null
        );

    }







    /**
     * Buscar por ID
     */
    public function findById(
        int $id
    ): ?array
    {


        $sql = "
            SELECT *
            FROM {$this->table}
            WHERE id=:id
            LIMIT 1
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            'id'=>$id

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $this->normalizeUser(
            $data ?: null
        );

    }









    /**
     * Normalización única usuario ERP
     */
    private function normalizeUser(
        ?array $data
    ): ?array
    {


        if(!$data){

            return null;

        }






        /*
        |--------------------------------------------------------------------------
        | Rol
        |--------------------------------------------------------------------------
        */


        if(empty($data['rol'])){


            $data['rol'] =

                $data['role']
                ??
                $data['tipo']
                ??
                'cliente';


        }







        /*
        |--------------------------------------------------------------------------
        | Estado
        |--------------------------------------------------------------------------
        */


        $data['activo'] =

            isset($data['activo'])

            ?

            (int)$data['activo']

            :

            1;








        /*
        |--------------------------------------------------------------------------
        | Superadmin real BD
        |--------------------------------------------------------------------------
        */


        $data['es_superadmin'] =

            isset($data['es_superadmin'])

            ?

            (int)$data['es_superadmin']

            :

            0;








        /*
        |--------------------------------------------------------------------------
        | Portal Cliente TNG
        |--------------------------------------------------------------------------
        */


        $data['linked_cliente_id'] =

            $data['linked_cliente_id']
            ??
            null;







        return $data;

    }









    /**
     * Cambiar contraseña
     */
    public function updatePassword(
        int $id,
        string $password
    ): bool
    {


        $sql = "
            UPDATE {$this->table}

            SET password=:password

            WHERE id=:id

            LIMIT 1
        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        return $stmt->execute([

            'password'=>$password,

            'id'=>$id

        ]);


    }




}