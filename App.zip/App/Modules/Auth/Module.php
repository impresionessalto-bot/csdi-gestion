<?php

declare(strict_types=1);

namespace App\Modules\Auth;

use App\Core\Module as CoreModule;

/**
 * Definición del módulo Auth para el núcleo de CSDI PRO.
 */
final class Module extends CoreModule
{
    public function name(): string
    {
        return 'Auth';
    }

    public function description(): string
    {
        return 'Gestión integral de sesiones, roles, seguridad y cuentas de usuario';
    }

    public function version(): string
    {
        return '1.0.0';
    }

    /**
     * Retorna la ruta física del archivo de enrutamiento del módulo.
     */
    public function routes(): string
    {
        // CORRECCIÓN: Apuntamos exactamente a la carpeta /Config/routes.php
        return __DIR__ . '/Config/routes.php';
    }

    public function priority(): int
    {
        return 5; // Carga prioritaria de seguridad
    }

    public function menu(): array
    {
        return [
            [
                'title'      => 'Usuarios',
                'icon'       => 'fa-solid fa-users-gear',
                'url'        => '/admin/usuarios',
                'group'      => 'Administración',
                'order'      => 12, // Posición ordenada entre Clientes y Base de Datos
                'permission' => 'menu_administracion',
                'visible'    => true,
                'children'   => []
            ]
        ];
    }

    public function icon(): string
    {
        return 'fa-solid fa-users-gear';
    }

    public function url(): string
    {
        return '/admin/usuarios';
    }

    public function group(): string
    {
        return 'Administración';
    }

    public function order(): int
    {
        return 12;
    }

    public function permissions(): array
    {
        return [
            'menu_administracion',
            'usuarios.ver',
            'usuarios.crear',
            'usuarios.editar',
            'usuarios.permisos'
        ];
    }

    public function dependencies(): array
    {
        return [];
    }

    public function widgets(): array
    {
        return [];
    }

    public function kpis(): array
    {
        return [];
    }

    public function enabled(): bool
    {
        return true;
    }

    public function boot(): void
    {
    }
}