<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Repositories;

use PDO;
use Throwable;
use RuntimeException;

/**
 * ============================================================================
 * CSDI PRO
 * FINANZAS - REPOSITORY
 * ============================================================================
 *
 * Responsabilidad exclusiva:
 *
 * - SQL.
 * - Lectura de créditos.
 * - Escritura de créditos.
 * - Planes de cuotas.
 * - Cheques.
 * - Estadísticas.
 *
 * No contiene reglas de presentación.
 * No calcula cuotas.
 */
final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function resumen(): array
    {
        return [
            'creditos' =>
                $this->cantidadCreditosActivos(),

            'saldo' =>
                $this->saldoPendiente(),

            'cuotas' =>
                $this->cuotasPendientes(),

            'cheques' =>
                $this->totalCheques(),
        ];
    }

    public function vencidas(): array
    {
        $sql = "
            SELECT
                cp.*,
                c.banco,
                c.datos_credito
            FROM creditos_plan cp
            INNER JOIN creditos c
                ON c.id = cp.credito_id
            WHERE cp.estado = 'Pendiente'
              AND cp.fecha_vencimiento < CURDATE()
              AND c.estado = 'Activo'
            ORDER BY cp.fecha_vencimiento ASC
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function proximas(): array
    {
        $sql = "
            SELECT
                cp.*,
                c.banco,
                c.datos_credito
            FROM creditos_plan cp
            INNER JOIN creditos c
                ON c.id = cp.credito_id
            WHERE cp.estado = 'Pendiente'
              AND cp.fecha_vencimiento >= CURDATE()
              AND cp.fecha_vencimiento <= DATE_ADD(
                    CURDATE(),
                    INTERVAL 30 DAY
              )
              AND c.estado = 'Activo'
            ORDER BY cp.fecha_vencimiento ASC
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function vencimientos(): array
    {
        $sql = "
            SELECT
                DATE_FORMAT(
                    cp.fecha_vencimiento,
                    '%Y-%m'
                ) AS periodo,

                SUM(cp.monto_total) AS total,

                COUNT(*) AS cantidad

            FROM creditos_plan cp

            INNER JOIN creditos c
                ON c.id = cp.credito_id

            WHERE cp.estado = 'Pendiente'
              AND c.estado = 'Activo'

            GROUP BY
                DATE_FORMAT(
                    cp.fecha_vencimiento,
                    '%Y-%m'
                )

            ORDER BY periodo ASC
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function graficoVencimientos(): array
    {
        return $this->vencimientos();
    }

    /*
    |--------------------------------------------------------------------------
    | CRÉDITOS
    |--------------------------------------------------------------------------
    */

    public function creditos(): array
    {
        $sql = "
            SELECT
                c.*,

                (
                    SELECT COUNT(*)
                    FROM creditos_plan cp
                    WHERE cp.credito_id = c.id
                      AND cp.estado = 'Pendiente'
                ) AS cuotas_pendientes,

                (
                    SELECT COALESCE(
                        SUM(cp.monto_total),
                        0
                    )
                    FROM creditos_plan cp
                    WHERE cp.credito_id = c.id
                      AND cp.estado = 'Pendiente'
                ) AS saldo_plan

            FROM creditos c

            ORDER BY c.id DESC
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function credito(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM creditos
            WHERE id = :id
            LIMIT 1
        ");

        $stmt->execute([
            'id' => $id,
        ]);

        $credito =
            $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$credito) {
            return null;
        }

        /*
        |--------------------------------------------------------------------------
        | INFORMACIÓN CALCULADA
        |--------------------------------------------------------------------------
        */

        $stmtSaldo = $this->db->prepare("
            SELECT
                COALESCE(
                    SUM(
                        CASE
                            WHEN estado = 'Pendiente'
                            THEN monto_total
                            ELSE 0
                        END
                    ),
                    0
                ) AS saldo_pendiente,

                COALESCE(
                    SUM(
                        CASE
                            WHEN estado = 'Pagado'
                            THEN monto_total
                            ELSE 0
                        END
                    ),
                    0
                ) AS total_pagado,

                COUNT(
                    CASE
                        WHEN estado = 'Pendiente'
                        THEN 1
                    END
                ) AS cuotas_pendientes,

                COUNT(
                    CASE
                        WHEN estado = 'Pagado'
                        THEN 1
                    END
                ) AS cuotas_pagadas

            FROM creditos_plan
            WHERE credito_id = :credito_id
        ");

        $stmtSaldo->execute([
            'credito_id' => $id,
        ]);

        $datos =
            $stmtSaldo->fetch(PDO::FETCH_ASSOC)
            ?: [];

        $credito['saldo_pendiente'] =
            (float)($datos['saldo_pendiente'] ?? 0);

        $credito['total_pagado'] =
            (float)($datos['total_pagado'] ?? 0);

        $credito['cuotas_pendientes'] =
            (int)($datos['cuotas_pendientes'] ?? 0);

        $credito['cuotas_pagadas_reales'] =
            (int)($datos['cuotas_pagadas'] ?? 0);

        return $credito;
    }

    public function plan(int $creditoId): array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM creditos_plan
            WHERE credito_id = :id
            ORDER BY nro_cuota ASC
        ");

        $stmt->execute([
            'id' => $creditoId,
        ]);

        return $stmt
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR CRÉDITO + PLAN
    |--------------------------------------------------------------------------
    */

    public function guardarCreditoCompleto(
        array $credito,
        array $plan
    ): int {
        if ($plan === []) {
            throw new RuntimeException(
                'No se puede guardar un crédito sin plan de cuotas.'
            );
        }

        try {
            $this->db->beginTransaction();

            $sql = "
                INSERT INTO creditos
                (
                    fecha,
                    datos_credito,
                    banco,
                    importe_original,
                    valor_cuota,
                    tasa_interes,
                    cuotas_totales,
                    cuotas_pagadas,
                    interes_tasa,
                    cap_cuota,
                    int_cuota,
                    gas_cuota,
                    estado
                )
                VALUES
                (
                    :fecha,
                    :datos_credito,
                    :banco,
                    :importe_original,
                    :valor_cuota,
                    :tasa_interes,
                    :cuotas_totales,
                    0,
                    :interes_tasa,
                    :cap_cuota,
                    :int_cuota,
                    :gas_cuota,
                    'Activo'
                )
            ";

            $stmt =
                $this->db->prepare($sql);

            $stmt->execute([
                'fecha' =>
                    $credito['fecha'] ?? date('Y-m-d'),

                'datos_credito' =>
                    $credito['datos_credito'] ?? '',

                'banco' =>
                    $credito['banco'] ?? '',

                'importe_original' =>
                    (float)($credito['importe_original'] ?? 0),

                'valor_cuota' =>
                    (float)($credito['valor_cuota'] ?? 0),

                'tasa_interes' =>
                    (float)($credito['tasa_interes'] ?? 0),

                'cuotas_totales' =>
                    (int)($credito['cuotas_totales'] ?? 1),

                'interes_tasa' =>
                    (float)($credito['interes_tasa'] ?? 0),

                'cap_cuota' =>
                    (float)($credito['cap_cuota'] ?? 0),

                'int_cuota' =>
                    (float)($credito['int_cuota'] ?? 0),

                'gas_cuota' =>
                    (float)($credito['gas_cuota'] ?? 0),
            ]);

            $creditoId =
                (int)$this->db->lastInsertId();

            $sqlPlan = "
                INSERT INTO creditos_plan
                (
                    credito_id,
                    nro_cuota,
                    fecha_vencimiento,
                    capital,
                    interes_nominal,
                    iva_interes,
                    percepcion_iva,
                    otros_gastos,
                    monto_total,
                    estado
                )
                VALUES
                (
                    :credito_id,
                    :nro_cuota,
                    :fecha_vencimiento,
                    :capital,
                    :interes_nominal,
                    :iva_interes,
                    :percepcion_iva,
                    :otros_gastos,
                    :monto_total,
                    :estado
                )
            ";

            $stmtPlan =
                $this->db->prepare($sqlPlan);

            foreach ($plan as $cuota) {

                $stmtPlan->execute([
                    'credito_id' =>
                        $creditoId,

                    'nro_cuota' =>
                        (int)($cuota['nro_cuota'] ?? 0),

                    'fecha_vencimiento' =>
                        $cuota['fecha_vencimiento'] ?? null,

                    'capital' =>
                        (float)($cuota['capital'] ?? 0),

                    'interes_nominal' =>
                        (float)($cuota['interes_nominal'] ?? 0),

                    'iva_interes' =>
                        (float)($cuota['iva_interes'] ?? 0),

                    'percepcion_iva' =>
                        (float)($cuota['percepcion_iva'] ?? 0),

                    'otros_gastos' =>
                        (float)($cuota['otros_gastos'] ?? 0),

                    'monto_total' =>
                        (float)($cuota['monto_total'] ?? 0),

                    'estado' =>
                        $cuota['estado'] ?? 'Pendiente',
                ]);
            }

            $this->db->commit();

            return $creditoId;

        } catch (Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizarCredito(
        int $id,
        array $data
    ): bool {
        $sql = "
            UPDATE creditos
            SET
                fecha = :fecha,
                banco = :banco,
                datos_credito = :datos_credito,
                importe_original = :importe_original,
                tasa_interes = :tasa_interes,
                cuotas_totales = :cuotas_totales
            WHERE id = :id
        ";

        $stmt =
            $this->db->prepare($sql);

        return $stmt->execute([
            'id' =>
                $id,

            'fecha' =>
                $data['fecha'] ?? date('Y-m-d'),

            'banco' =>
                $data['banco'] ?? '',

            'datos_credito' =>
                $data['datos_credito'] ?? '',

            'importe_original' =>
                (float)($data['importe_original'] ?? 0),

            'tasa_interes' =>
                (float)($data['tasa_interes'] ?? 0),

            'cuotas_totales' =>
                (int)($data['cuotas_totales'] ?? 1),
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminarCredito(int $id): bool
    {
        try {
            $this->db->beginTransaction();

            $stmt =
                $this->db->prepare("
                    DELETE FROM creditos_plan
                    WHERE credito_id = :id
                ");

            $stmt->execute([
                'id' => $id,
            ]);

            $stmt =
                $this->db->prepare("
                    DELETE FROM creditos
                    WHERE id = :id
                ");

            $stmt->execute([
                'id' => $id,
            ]);

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PAGAR CUOTA
    |--------------------------------------------------------------------------
    */

    public function pagarCuota(int $id): bool
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("
                SELECT
                    id,
                    credito_id,
                    estado
                FROM creditos_plan
                WHERE id = :id
                LIMIT 1
                FOR UPDATE
            ");

            $stmt->execute([
                'id' => $id,
            ]);

            $cuota =
                $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$cuota) {
                throw new RuntimeException(
                    'La cuota no existe.'
                );
            }

            if (($cuota['estado'] ?? '') !== 'Pendiente') {
                throw new RuntimeException(
                    'La cuota no está pendiente.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | MARCAR CUOTA
            |--------------------------------------------------------------------------
            */

            $stmt = $this->db->prepare("
                UPDATE creditos_plan
                SET
                    estado = 'Pagado',
                    fecha_pago = NOW()
                WHERE id = :id
            ");

            $stmt->execute([
                'id' => $id,
            ]);

            /*
            |--------------------------------------------------------------------------
            | ACTUALIZAR CONTADOR
            |--------------------------------------------------------------------------
            */

            $stmt = $this->db->prepare("
                UPDATE creditos
                SET
                    cuotas_pagadas =
                        cuotas_pagadas + 1
                WHERE id = :credito_id
            ");

            $stmt->execute([
                'credito_id' =>
                    (int)$cuota['credito_id'],
            ]);

            /*
            |--------------------------------------------------------------------------
            | ¿QUEDAN CUOTAS?
            |--------------------------------------------------------------------------
            */

            $stmt = $this->db->prepare("
                SELECT COUNT(*)
                FROM creditos_plan
                WHERE credito_id = :credito_id
                  AND estado = 'Pendiente'
            ");

            $stmt->execute([
                'credito_id' =>
                    (int)$cuota['credito_id'],
            ]);

            $pendientes =
                (int)$stmt->fetchColumn();

            if ($pendientes === 0) {

                $stmt = $this->db->prepare("
                    UPDATE creditos
                    SET estado = 'Finalizado'
                    WHERE id = :credito_id
                ");

                $stmt->execute([
                    'credito_id' =>
                        (int)$cuota['credito_id'],
                ]);
            }

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | FINALIZAR ANTICIPADAMENTE
    |--------------------------------------------------------------------------
    */

    public function finalizarCredito(int $id): bool
    {
        try {
            $this->db->beginTransaction();

            $stmt =
                $this->db->prepare("
                    SELECT id
                    FROM creditos
                    WHERE id = :id
                    LIMIT 1
                    FOR UPDATE
                ");

            $stmt->execute([
                'id' => $id,
            ]);

            if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
                throw new RuntimeException(
                    'El crédito no existe.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CANCELAR CUOTAS PENDIENTES
            |--------------------------------------------------------------------------
            */

            $stmt =
                $this->db->prepare("
                    UPDATE creditos_plan
                    SET estado = 'Cancelado'
                    WHERE credito_id = :id
                      AND estado = 'Pendiente'
                ");

            $stmt->execute([
                'id' => $id,
            ]);

            /*
            |--------------------------------------------------------------------------
            | FINALIZAR CRÉDITO
            |--------------------------------------------------------------------------
            */

            $stmt =
                $this->db->prepare("
                    UPDATE creditos
                    SET estado = 'Finalizado'
                    WHERE id = :id
                ");

            $stmt->execute([
                'id' => $id,
            ]);

            $this->db->commit();

            return true;

        } catch (Throwable $e) {

            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CUOTAS
    |--------------------------------------------------------------------------
    */

    public function cuotasPendientes(): int
    {
        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM creditos_plan cp
                INNER JOIN creditos c
                    ON c.id = cp.credito_id
                WHERE cp.estado = 'Pendiente'
                  AND c.estado = 'Activo'
            ")
            ->fetchColumn();
    }

    public function cuotasVencidas(): int
    {
        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM creditos_plan cp
                INNER JOIN creditos c
                    ON c.id = cp.credito_id
                WHERE cp.estado = 'Pendiente'
                  AND c.estado = 'Activo'
                  AND cp.fecha_vencimiento < CURDATE()
            ")
            ->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | CRÉDITOS
    |--------------------------------------------------------------------------
    */

    public function cantidadCreditos(): int
    {
        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM creditos
            ")
            ->fetchColumn();
    }

    public function cantidadCreditosActivos(): int
    {
        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM creditos
                WHERE estado = 'Activo'
            ")
            ->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | SALDO ORIGINAL
    |--------------------------------------------------------------------------
    */

    public function saldoTotal(): float
    {
        return (float)$this->db
            ->query("
                SELECT COALESCE(
                    SUM(importe_original),
                    0
                )
                FROM creditos
            ")
            ->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | SALDO PENDIENTE REAL
    |--------------------------------------------------------------------------
    */

    public function saldoPendiente(): float
    {
        return (float)$this->db
            ->query("
                SELECT COALESCE(
                    SUM(cp.monto_total),
                    0
                )
                FROM creditos_plan cp
                INNER JOIN creditos c
                    ON c.id = cp.credito_id
                WHERE cp.estado = 'Pendiente'
                  AND c.estado = 'Activo'
            ")
            ->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | INTERESES
    |--------------------------------------------------------------------------
    */

    public function totalIntereses(): float
    {
        return (float)$this->db
            ->query("
                SELECT COALESCE(
                    SUM(interes_nominal),
                    0
                )
                FROM creditos_plan
            ")
            ->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | GRÁFICO CRÉDITOS
    |--------------------------------------------------------------------------
    */

    public function graficoCreditos(): array
    {
        $sql = "
            SELECT
                DATE_FORMAT(
                    fecha,
                    '%m/%Y'
                ) AS periodo,

                SUM(
                    importe_original
                ) AS total

            FROM creditos

            GROUP BY
                YEAR(fecha),
                MONTH(fecha)

            ORDER BY
                YEAR(fecha),
                MONTH(fecha)
        ";

        return $this->db
            ->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    /*
    |--------------------------------------------------------------------------
    | CHEQUES
    |--------------------------------------------------------------------------
    */

    public function cheques(): array
    {
        return $this->db
            ->query("
                SELECT *
                FROM cheques
                ORDER BY id DESC
            ")
            ->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function crearCheque(array $data): bool
    {
        $sql = "
            INSERT INTO cheques
            (
                numero,
                banco,
                importe,
                estado
            )
            VALUES
            (
                :numero,
                :banco,
                :importe,
                :estado
            )
        ";

        $stmt =
            $this->db->prepare($sql);

        return $stmt->execute([
            'numero' =>
                $data['numero'] ?? '',

            'banco' =>
                $data['banco'] ?? '',

            'importe' =>
                (float)($data['importe'] ?? 0),

            'estado' =>
                $data['estado'] ?? 'Pendiente',
        ]);
    }

    public function estadoCheque(
        int $id,
        string $estado
    ): bool {
        return $this->db
            ->prepare("
                UPDATE cheques
                SET estado = :estado
                WHERE id = :id
            ")
            ->execute([
                'estado' => $estado,
                'id'     => $id,
            ]);
    }

    public function totalCheques(): float
    {
        return (float)$this->db
            ->query("
                SELECT COALESCE(
                    SUM(importe),
                    0
                )
                FROM cheques
                WHERE estado = 'Pendiente'
            ")
            ->fetchColumn();
    }

    /*
    |--------------------------------------------------------------------------
    | API
    |--------------------------------------------------------------------------
    */

    public function creditoApi(int $id): array
    {
        $credito =
            $this->credito($id);

        if (!$credito) {
            return [];
        }

        $credito['plan'] =
            $this->plan($id);

        return $credito;
    }

    public function chequesApi(): array
    {
        return $this->cheques();
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS
    |--------------------------------------------------------------------------
    */

    public function estadisticas(): array
    {
        return [
            'creditos' =>
                $this->cantidadCreditos(),

            'creditos_activos' =>
                $this->cantidadCreditosActivos(),

            'saldo' =>
                $this->saldoTotal(),

            'saldo_pendiente' =>
                $this->saldoPendiente(),

            'cuotas_pendientes' =>
                $this->cuotasPendientes(),

            'cuotas_vencidas' =>
                $this->cuotasVencidas(),

            'intereses' =>
                $this->totalIntereses(),

            'cheques' =>
                $this->totalCheques(),
        ];
    }
}