<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Services;

use App\Modules\Finanzas\Repositories\Repository;
use RuntimeException;

/**
 * ============================================================================
 * CSDI PRO
 * FINANZAS - SERVICE
 * ============================================================================
 *
 * Responsabilidad:
 *
 * - Reglas de negocio.
 * - Validaciones.
 * - Coordinación Repository + Calculadora.
 * - Normalización de datos.
 *
 * NO contiene SQL.
 */
final class Service
{
    public function __construct(
        private readonly Repository $repository,
        private readonly CalculadoraCredito $calculadora
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | CRÉDITOS
    |--------------------------------------------------------------------------
    */

    public function creditos(): array
    {
        return $this->repository->creditos();
    }

    public function credito(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->credito($id);
    }

    public function plan(int $creditoId): array
    {
        if ($creditoId <= 0) {
            return [];
        }

        return $this->repository->plan(
            $creditoId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR CRÉDITO
    |--------------------------------------------------------------------------
    */

    public function crearCredito(array $data): int
    {
        $monto =
            $this->numero(
                $data['importe_original']
                ?? $data['importe']
                ?? 0
            );

        $tasaAnual =
            $this->numero(
                $data['tasa_interes'] ?? 0
            );

        $cuotas =
            (int)(
                $data['cuotas_totales']
                ?? 0
            );

        $fecha =
            trim(
                (string)(
                    $data['fecha']
                    ?? date('Y-m-d')
                )
            );

        $iva =
            $this->numero(
                $data['iva'] ?? 21
            );

        $gastos =
            $this->numero(
                $data['gastos_cuota']
                ?? $data['gas_cuota']
                ?? 0
            );

        /*
        |--------------------------------------------------------------------------
        | VALIDACIONES
        |--------------------------------------------------------------------------
        */

        if ($monto <= 0) {
            throw new RuntimeException(
                'El importe del crédito debe ser mayor a cero.'
            );
        }

        if ($cuotas <= 0) {
            throw new RuntimeException(
                'La cantidad de cuotas debe ser mayor a cero.'
            );
        }

        if ($tasaAnual < 0) {
            throw new RuntimeException(
                'La tasa de interés no puede ser negativa.'
            );
        }

        if ($fecha === '') {
            $fecha = date('Y-m-d');
        }

        /*
        |--------------------------------------------------------------------------
        | GENERAR PLAN
        |--------------------------------------------------------------------------
        */

        $plan =
            $this->calculadora->generarPlan(
                monto: $monto,
                tasaAnual: $tasaAnual,
                cuotas: $cuotas,
                iva: $iva,
                gastos: $gastos,
                fechaInicio: $fecha
            );

        if ($plan === []) {
            throw new RuntimeException(
                'No fue posible generar el plan de cuotas.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CALCULAR DATOS RESUMIDOS
        |--------------------------------------------------------------------------
        */

        $capitalCuota =
            $monto / $cuotas;

        $interesTotal = 0.0;

        foreach ($plan as $cuota) {
            $interesTotal +=
                (float)(
                    $cuota['interes_nominal']
                    ?? 0
                );
        }

        /*
        |--------------------------------------------------------------------------
        | DATOS PARA REPOSITORY
        |--------------------------------------------------------------------------
        */

        $credito = [
            'fecha' =>
                $fecha,

            'datos_credito' =>
                trim(
                    (string)(
                        $data['datos_credito']
                        ?? ''
                    )
                ),

            'banco' =>
                trim(
                    (string)(
                        $data['banco']
                        ?? ''
                    )
                ),

            'importe_original' =>
                $monto,

            'valor_cuota' =>
                (float)(
                    $data['valor_cuota']
                    ?? (
                        $plan[0]['monto_total']
                        ?? 0
                    )
                ),

            'tasa_interes' =>
                $tasaAnual,

            'cuotas_totales' =>
                $cuotas,

            'interes_tasa' =>
                $interesTotal,

            'cap_cuota' =>
                $capitalCuota,

            'int_cuota' =>
                $interesTotal / $cuotas,

            'gas_cuota' =>
                $gastos,
        ];

        /*
        |--------------------------------------------------------------------------
        | GUARDAR TODO
        |--------------------------------------------------------------------------
        */

        return $this->repository
            ->guardarCreditoCompleto(
                $credito,
                $plan
            );
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizarCredito(
        int $id,
        array $data
    ): void {
        $credito =
            $this->repository->credito($id);

        if (!$credito) {
            throw new RuntimeException(
                'El crédito no existe.'
            );
        }

        if (
            isset($credito['estado'])
            &&
            $credito['estado'] === 'Finalizado'
        ) {
            throw new RuntimeException(
                'No se puede modificar un crédito finalizado.'
            );
        }

        $monto =
            $this->numero(
                $data['importe_original']
                ?? $credito['importe_original']
                ?? 0
            );

        $tasa =
            $this->numero(
                $data['tasa_interes']
                ?? $credito['tasa_interes']
                ?? 0
            );

        $cuotas =
            (int)(
                $data['cuotas_totales']
                ?? $credito['cuotas_totales']
                ?? 1
            );

        if ($monto <= 0) {
            throw new RuntimeException(
                'El importe debe ser mayor a cero.'
            );
        }

        if ($cuotas <= 0) {
            throw new RuntimeException(
                'La cantidad de cuotas debe ser mayor a cero.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | IMPORTANTE
        |--------------------------------------------------------------------------
        |
        | No regeneramos el plan automáticamente.
        |
        | Si el usuario cambia tasa, monto o cuotas,
        | el plan existente representa el historial original.
        |
        | Para recalcularlo conviene crear posteriormente
        | una operación explícita "Regenerar plan".
        |
        */

        $ok =
            $this->repository->actualizarCredito(
                $id,
                [
                    'fecha' =>
                        $data['fecha']
                        ?? $credito['fecha']
                        ?? date('Y-m-d'),

                    'banco' =>
                        $data['banco']
                        ?? $credito['banco']
                        ?? '',

                    'datos_credito' =>
                        $data['datos_credito']
                        ?? $credito['datos_credito']
                        ?? '',

                    'importe_original' =>
                        $monto,

                    'tasa_interes' =>
                        $tasa,

                    'cuotas_totales' =>
                        $cuotas,
                ]
            );

        if (!$ok) {
            throw new RuntimeException(
                'No fue posible actualizar el crédito.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PAGAR CUOTA
    |--------------------------------------------------------------------------
    */

    public function pagarCuota(int $cuotaId): void
    {
        if ($cuotaId <= 0) {
            throw new RuntimeException(
                'ID de cuota inválido.'
            );
        }

        $this->repository
            ->pagarCuota($cuotaId);
    }

    /*
    |--------------------------------------------------------------------------
    | FINALIZAR
    |--------------------------------------------------------------------------
    */

    public function finalizarCredito(int $id): void
    {
        if ($id <= 0) {
            throw new RuntimeException(
                'ID de crédito inválido.'
            );
        }

        $credito =
            $this->repository->credito($id);

        if (!$credito) {
            throw new RuntimeException(
                'El crédito no existe.'
            );
        }

        if (
            isset($credito['estado'])
            &&
            $credito['estado'] === 'Finalizado'
        ) {
            throw new RuntimeException(
                'El crédito ya se encuentra finalizado.'
            );
        }

        $this->repository
            ->finalizarCredito($id);
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminarCredito(int $id): void
    {
        if ($id <= 0) {
            throw new RuntimeException(
                'ID de crédito inválido.'
            );
        }

        $credito =
            $this->repository->credito($id);

        if (!$credito) {
            throw new RuntimeException(
                'El crédito no existe.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | PROTECCIÓN DE HISTORIAL
        |--------------------------------------------------------------------------
        |
        | Un crédito con cuotas pagadas no debería eliminarse.
        |
        */

        $plan =
            $this->repository->plan($id);

        foreach ($plan as $cuota) {
            if (
                ($cuota['estado'] ?? '')
                === 'Pagado'
            ) {
                throw new RuntimeException(
                    'No se puede eliminar un crédito que ya posee cuotas pagadas.'
                );
            }
        }

        $this->repository
            ->eliminarCredito($id);
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        return [
            'resumen' =>
                $this->repository->resumen(),

            'vencidas' =>
                $this->repository->vencidas(),

            'proximas' =>
                $this->repository->proximas(),

            'vencimientos' =>
                $this->repository->vencimientos(),

            'grafico_creditos' =>
                $this->repository->graficoCreditos(),

            'grafico_vencimientos' =>
                $this->repository->graficoVencimientos(),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | WIDGETS
    |--------------------------------------------------------------------------
    */

    public function widgets(): array
    {
        $resumen =
            $this->repository->resumen();

        return [
            [
                'titulo' =>
                    'Créditos Activos',

                'valor' =>
                    $resumen['creditos'] ?? 0,

                'color' =>
                    'primary',

                'icono' =>
                    'fa-solid fa-file-invoice-dollar',
            ],

            [
                'titulo' =>
                    'Saldo Pendiente',

                'valor' =>
                    (float)(
                        $resumen['saldo']
                        ?? 0
                    ),

                'color' =>
                    'success',

                'icono' =>
                    'fa-solid fa-wallet',
            ],

            [
                'titulo' =>
                    'Cuotas Pendientes',

                'valor' =>
                    $resumen['cuotas'] ?? 0,

                'color' =>
                    'warning',

                'icono' =>
                    'fa-solid fa-calendar-days',
            ],

            [
                'titulo' =>
                    'Cheques en Cartera',

                'valor' =>
                    (float)(
                        $resumen['cheques']
                        ?? 0
                    ),

                'color' =>
                    'info',

                'icono' =>
                    'fa-solid fa-money-check',
            ],
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | KPIs
    |--------------------------------------------------------------------------
    */

    public function kpis(): array
    {
        return $this->repository
            ->estadisticas();
    }

    /*
    |--------------------------------------------------------------------------
    | GRÁFICOS
    |--------------------------------------------------------------------------
    */

    public function graficoCreditos(): array
    {
        return $this->repository
            ->graficoCreditos();
    }

    public function graficoVencimientos(): array
    {
        return $this->repository
            ->graficoVencimientos();
    }

    /*
    |--------------------------------------------------------------------------
    | VENCIMIENTOS
    |--------------------------------------------------------------------------
    */

    public function obtenerAlertasVencimientos(): array
    {
        $vencidas =
            $this->repository->vencidas();

        $proximas =
            $this->repository->proximas();

        $totalVencidas = 0.0;

        foreach ($vencidas as $cuota) {
            $totalVencidas +=
                (float)(
                    $cuota['monto_total']
                    ?? 0
                );
        }

        $totalProximas = 0.0;

        foreach ($proximas as $cuota) {
            $totalProximas +=
                (float)(
                    $cuota['monto_total']
                    ?? 0
                );
        }

        return [
            'vencidas' => [
                'cantidad' =>
                    count($vencidas),

                'total' =>
                    $totalVencidas,
            ],

            'proximas' => [
                'cantidad' =>
                    count($proximas),

                'total' =>
                    $totalProximas,
            ],
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | CHEQUES
    |--------------------------------------------------------------------------
    */

    public function cheques(): array
    {
        return $this->repository
            ->cheques();
    }

    public function crearCheque(array $data): void
    {
        $importe =
            $this->numero(
                $data['importe'] ?? 0
            );

        if ($importe <= 0) {
            throw new RuntimeException(
                'El importe del cheque debe ser mayor a cero.'
            );
        }

        $ok =
            $this->repository->crearCheque([
                'numero' =>
                    trim(
                        (string)(
                            $data['numero'] ?? ''
                        )
                    ),

                'banco' =>
                    trim(
                        (string)(
                            $data['banco'] ?? ''
                        )
                    ),

                'importe' =>
                    $importe,

                'estado' =>
                    $data['estado']
                    ?? 'Pendiente',
            ]);

        if (!$ok) {
            throw new RuntimeException(
                'No fue posible registrar el cheque.'
            );
        }
    }

    public function estadoCheque(
        int $id,
        string $estado
    ): void {
        if ($id <= 0) {
            throw new RuntimeException(
                'ID de cheque inválido.'
            );
        }

        $estadosPermitidos = [
            'Pendiente',
            'Cobrado',
            'Rechazado',
            'Anulado',
        ];

        if (!in_array(
            $estado,
            $estadosPermitidos,
            true
        )) {
            throw new RuntimeException(
                'Estado de cheque inválido.'
            );
        }

        $ok =
            $this->repository->estadoCheque(
                $id,
                $estado
            );

        if (!$ok) {
            throw new RuntimeException(
                'No fue posible actualizar el estado del cheque.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API
    |--------------------------------------------------------------------------
    */

    public function creditoApi(int $id): array
    {
        return $this->repository
            ->creditoApi($id);
    }

    public function chequesApi(): array
    {
        return $this->repository
            ->chequesApi();
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS
    |--------------------------------------------------------------------------
    */

    public function estadisticas(): array
    {
        return $this->repository
            ->estadisticas();
    }

    /*
    |--------------------------------------------------------------------------
    | NORMALIZACIÓN NUMÉRICA
    |--------------------------------------------------------------------------
    */

    private function numero(mixed $valor): float
    {
        if ($valor === null || $valor === '') {
            return 0.0;
        }

        if (is_string($valor)) {
            $valor = trim($valor);

            /*
            |--------------------------------------------------------------------------
            | Soporta:
            |
            | 1234.56
            | 1234,56
            | 1.234,56
            |--------------------------------------------------------------------------
            */

            if (
                str_contains($valor, '.')
                &&
                str_contains($valor, ',')
            ) {
                $valor =
                    str_replace(
                        '.',
                        '',
                        $valor
                    );

                $valor =
                    str_replace(
                        ',',
                        '.',
                        $valor
                    );
            } elseif (
                str_contains($valor, ',')
            ) {
                $valor =
                    str_replace(
                        ',',
                        '.',
                        $valor
                    );
            }
        }

        return (float)$valor;
    }
}