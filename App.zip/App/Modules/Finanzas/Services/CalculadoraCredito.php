<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Services;

use InvalidArgumentException;

/**
 * ============================================================================
 * CSDI PRO
 * FINANZAS - CALCULADORA DE CRÉDITOS
 * ============================================================================
 *
 * No accede a la base de datos.
 *
 * Responsabilidad:
 *
 * - Calcular amortizaciones.
 * - Calcular intereses.
 * - Calcular IVA.
 * - Calcular gastos.
 * - Calcular vencimientos.
 * - Calcular saldo de capital.
 *
 * Sistemas soportados:
 *
 * - CAPITAL_CONSTANTE
 * - FRANCES
 * ============================================================================
 */
final class CalculadoraCredito
{
    public const SISTEMA_CAPITAL_CONSTANTE = 'CAPITAL_CONSTANTE';

    public const SISTEMA_FRANCES = 'FRANCES';

    /**
     * Genera un plan completo de amortización.
     */
    public function calcular(
        float $monto,
        float $tasaAnual,
        int $cuotas,
        float $iva = 21.0,
        float $gastos = 0.0,
        string $fechaInicio = '',
        string $sistema = self::SISTEMA_CAPITAL_CONSTANTE,
        int $periodicidadMeses = 1
    ): array {
        $this->validarParametros(
            $monto,
            $tasaAnual,
            $cuotas,
            $iva,
            $gastos,
            $sistema,
            $periodicidadMeses
        );

        $fechaInicio = $fechaInicio !== ''
            ? $fechaInicio
            : date('Y-m-d');

        $tasaMensual = ($tasaAnual / 100) / 12;

        return match ($sistema) {
            self::SISTEMA_FRANCES => $this->calcularFrances(
                $monto,
                $tasaMensual,
                $cuotas,
                $iva,
                $gastos,
                $fechaInicio,
                $periodicidadMeses
            ),

            self::SISTEMA_CAPITAL_CONSTANTE => $this->calcularCapitalConstante(
                $monto,
                $tasaMensual,
                $cuotas,
                $iva,
                $gastos,
                $fechaInicio,
                $periodicidadMeses
            ),

            default => throw new InvalidArgumentException(
                'Sistema de amortización no soportado: ' . $sistema
            ),
        };
    }

    /**
     * Compatibilidad con código anterior.
     */
    public function generarPlan(
        float $monto,
        float $tasaAnual,
        int $cuotas,
        float $iva = 21.0,
        float $gastos = 0.0,
        string $fechaInicio = '',
        string $sistema = self::SISTEMA_CAPITAL_CONSTANTE,
        int $periodicidadMeses = 1
    ): array {
        return $this->calcular(
            monto: $monto,
            tasaAnual: $tasaAnual,
            cuotas: $cuotas,
            iva: $iva,
            gastos: $gastos,
            fechaInicio: $fechaInicio,
            sistema: $sistema,
            periodicidadMeses: $periodicidadMeses
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CAPITAL CONSTANTE
    |--------------------------------------------------------------------------
    */

    private function calcularCapitalConstante(
        float $monto,
        float $tasaMensual,
        int $cuotas,
        float $iva,
        float $gastos,
        string $fechaInicio,
        int $periodicidadMeses
    ): array {
        $plan = [];

        $saldo = round($monto, 2);

        $capitalBase = round(
            $monto / $cuotas,
            2
        );

        for ($i = 1; $i <= $cuotas; $i++) {
            $capital = $i === $cuotas
                ? round($saldo, 2)
                : $capitalBase;

            $interes = round(
                $saldo * $tasaMensual,
                2
            );

            $ivaInteres = round(
                $interes * ($iva / 100),
                2
            );

            $otrosGastos = round(
                $gastos,
                2
            );

            $montoTotal = round(
                $capital
                + $interes
                + $ivaInteres
                + $otrosGastos,
                2
            );

            $saldo = round(
                max(0, $saldo - $capital),
                2
            );

            $plan[] = [
                'nro_cuota'        => $i,
                'fecha_vencimiento'=> $this->fechaVencimiento(
                    $fechaInicio,
                    $i,
                    $periodicidadMeses
                ),
                'capital'          => $capital,
                'interes_nominal'  => $interes,
                'iva_interes'      => $ivaInteres,
                'percepcion_iva'   => 0.00,
                'otros_gastos'     => $otrosGastos,
                'monto_total'      => $montoTotal,
                'saldo_capital'    => $saldo,
                'estado'           => 'Pendiente',
            ];
        }

        return $plan;
    }

    /*
    |--------------------------------------------------------------------------
    | SISTEMA FRANCÉS
    |--------------------------------------------------------------------------
    */

    private function calcularFrances(
        float $monto,
        float $tasaMensual,
        int $cuotas,
        float $iva,
        float $gastos,
        string $fechaInicio,
        int $periodicidadMeses
    ): array {
        $plan = [];

        $saldo = round($monto, 2);

        if ($tasaMensual > 0) {
            $cuotaBase =
                $monto
                * (
                    $tasaMensual
                    / (
                        1 - pow(
                            1 + $tasaMensual,
                            -$cuotas
                        )
                    )
                );
        } else {
            $cuotaBase = $monto / $cuotas;
        }

        $cuotaBase = round(
            $cuotaBase,
            2
        );

        for ($i = 1; $i <= $cuotas; $i++) {
            $interes = round(
                $saldo * $tasaMensual,
                2
            );

            $capital = round(
                $cuotaBase - $interes,
                2
            );

            if ($i === $cuotas) {
                $capital = round(
                    $saldo,
                    2
                );
            }

            $ivaInteres = round(
                $interes * ($iva / 100),
                2
            );

            $otrosGastos = round(
                $gastos,
                2
            );

            $montoTotal = round(
                $capital
                + $interes
                + $ivaInteres
                + $otrosGastos,
                2
            );

            $saldo = round(
                max(0, $saldo - $capital),
                2
            );

            $plan[] = [
                'nro_cuota'         => $i,
                'fecha_vencimiento' => $this->fechaVencimiento(
                    $fechaInicio,
                    $i,
                    $periodicidadMeses
                ),
                'capital'           => $capital,
                'interes_nominal'   => $interes,
                'iva_interes'       => $ivaInteres,
                'percepcion_iva'    => 0.00,
                'otros_gastos'      => $otrosGastos,
                'monto_total'       => $montoTotal,
                'saldo_capital'     => $saldo,
                'estado'            => 'Pendiente',
            ];
        }

        return $plan;
    }

    /*
    |--------------------------------------------------------------------------
    | FECHAS
    |--------------------------------------------------------------------------
    */

    private function fechaVencimiento(
        string $fechaInicio,
        int $numeroCuota,
        int $periodicidadMeses
    ): string {
        $fecha = new \DateTimeImmutable(
            $fechaInicio
        );

        $meses = $numeroCuota * $periodicidadMeses;

        return $fecha
            ->modify('+' . $meses . ' month')
            ->format('Y-m-d');
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDACIÓN
    |--------------------------------------------------------------------------
    */

    private function validarParametros(
        float $monto,
        float $tasaAnual,
        int $cuotas,
        float $iva,
        float $gastos,
        string $sistema,
        int $periodicidadMeses
    ): void {
        if ($monto <= 0) {
            throw new InvalidArgumentException(
                'El importe del crédito debe ser mayor a cero.'
            );
        }

        if ($tasaAnual < 0) {
            throw new InvalidArgumentException(
                'La tasa de interés no puede ser negativa.'
            );
        }

        if ($cuotas <= 0) {
            throw new InvalidArgumentException(
                'La cantidad de cuotas debe ser mayor a cero.'
            );
        }

        if ($iva < 0) {
            throw new InvalidArgumentException(
                'El IVA no puede ser negativo.'
            );
        }

        if ($gastos < 0) {
            throw new InvalidArgumentException(
                'Los gastos no pueden ser negativos.'
            );
        }

        if ($periodicidadMeses <= 0) {
            throw new InvalidArgumentException(
                'La periodicidad debe ser mayor a cero.'
            );
        }

        if (!in_array(
            $sistema,
            [
                self::SISTEMA_CAPITAL_CONSTANTE,
                self::SISTEMA_FRANCES,
            ],
            true
        )) {
            throw new InvalidArgumentException(
                'Sistema de amortización inválido.'
            );
        }
    }
}