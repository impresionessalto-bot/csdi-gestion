<?php

declare(strict_types=1);


namespace App\Modules\Finanzas\Controllers;


use App\Core\BaseController;
use App\Modules\Finanzas\Services\Service;
use Throwable;



final class Api extends BaseController
{


    public function __construct(
        private readonly Service $service
    )
    {
        parent::__construct();
    }







    /*
    |--------------------------------------------------------------------------
    | OBTENER CREDITO
    |--------------------------------------------------------------------------
    */


    public function credito(
        int $id
    ): void
    {

        $this->requireAuth();


        try {


            $credito =
                $this->service
                    ->credito($id);



            if(!$credito)
            {

                $this->json(
                    [
                        'success'=>false,
                        'message'=>'Crédito inexistente'
                    ]
                );

                return;

            }



            $this->json(
                [
                    'success'=>true,
                    'data'=>$credito
                ]
            );


        }
        catch(Throwable $e)
        {

            $this->json(
                [
                    'success'=>false,
                    'message'=>$e->getMessage()
                ]
            );

        }

    }









    /*
    |--------------------------------------------------------------------------
    | LISTADO CHEQUES
    |--------------------------------------------------------------------------
    */


    public function cheques(): void
    {

        $this->requireAuth();


        try {


            $this->json(
                [
                    'success'=>true,

                    'data'=>
                        $this->service
                            ->cheques()
                ]
            );


        }
        catch(Throwable $e)
        {

            $this->json(
                [
                    'success'=>false,
                    'message'=>$e->getMessage()
                ]
            );

        }


    }









    /*
    |--------------------------------------------------------------------------
    | KPIS FINANZAS
    |--------------------------------------------------------------------------
    */


    public function kpis():void
    {

        $this->requireAuth();


        try {


            $this->json(
                [
                    'success'=>true,

                    'data'=>
                        $this->service
                            ->kpis()
                ]
            );


        }
        catch(Throwable $e)
        {

            $this->json(
                [
                    'success'=>false,
                    'message'=>$e->getMessage()
                ]
            );

        }

    }









    /*
    |--------------------------------------------------------------------------
    | DASHBOARD WIDGETS
    |--------------------------------------------------------------------------
    */


    public function widgets():void
    {

        $this->requireAuth();


        try {


            $this->json(
                [
                    'success'=>true,

                    'data'=>
                        $this->service
                            ->widgets()
                ]
            );


        }
        catch(Throwable $e)
        {

            $this->json(
                [
                    'success'=>false,
                    'message'=>$e->getMessage()
                ]
            );

        }

    }



}