<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Controllers;


use App\Core\BaseController;
use App\Modules\Finanzas\Services\Service;
use Throwable;



final class Cheques extends BaseController
{


    public function __construct(
        private readonly Service $service
    )
    {
        /*
         * ERP CSDI PRO
         *
         * No llamar:
         *
         * parent::__construct()
         *
         * El Container resuelve las dependencias.
         */
    }







    /*
    |--------------------------------------------------------------------------
    | LISTADO CHEQUES
    |--------------------------------------------------------------------------
    */


    public function index(): void
    {

        $this->requireAuth();


        try {


            $this->view(
                'cheques',
                [

                    'titulo'=>
                        'Gestión de Cheques',


                    'cheques'=>
                        $this->service
                            ->cheques()
                            ??
                            [],


                    'csrf'=>
                        $this->csrf()

                ]
            );



        }
        catch(Throwable $e)
        {

            $this->fail($e);

        }


    }










    /*
    |--------------------------------------------------------------------------
    | GUARDAR CHEQUE
    |--------------------------------------------------------------------------
    */


    public function guardar(): void
    {

        $this->requireAuth();


        try {


            $this->validateCsrf(
                $_POST['_csrf']
                ??
                null
            );



            $this->service
                ->crearCheque(
                    $_POST
                );



            $this->redirect(
                '/finanzas/cheques'
            );


        }
        catch(Throwable $e)
        {

            $this->fail($e);

        }


    }









    /*
    |--------------------------------------------------------------------------
    | CAMBIAR ESTADO CHEQUE
    |--------------------------------------------------------------------------
    */


    public function estado(
        int $id
    ): void
    {

        $this->requireAuth();


        try {


            $this->validateCsrf(
                $_POST['_csrf']
                ??
                null
            );



            $estado =
                $_POST['estado']
                ??
                'Pendiente';




            $this->service
                ->cambiarEstadoCheque(
                    $id,
                    $estado
                );



            $this->redirect(
                '/finanzas/cheques'
            );



        }
        catch(Throwable $e)
        {

            $this->fail($e);

        }


    }










    /*
    |--------------------------------------------------------------------------
    | ELIMINAR CHEQUE
    |--------------------------------------------------------------------------
    */


    public function eliminar(
        int $id
    ): void
    {

        $this->requireAuth();


        try {


            $this->validateCsrf(
                $_POST['_csrf']
                ??
                null
            );



            $this->service
                ->eliminarCheque(
                    $id
                );



            $this->redirect(
                '/finanzas/cheques'
            );



        }
        catch(Throwable $e)
        {

            $this->fail($e);

        }


    }





}