<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Controllers;

use App\Core\BaseController;
use App\Modules\Finanzas\Services\Service;
use RuntimeException;
use Throwable;

/**
 * ============================================================================
 * CSDI PRO
 * FINANZAS - CONTROLADOR DE CRÉDITOS
 * ============================================================================
 *
 * Responsabilidad exclusiva:
 *
 * - Autenticación.
 * - Validación CSRF.
 * - Recepción de parámetros HTTP.
 * - Invocación del Service.
 * - Renderizado de vistas.
 * - Redirecciones.
 *
 * NO contiene:
 *
 * - SQL.
 * - Cálculos financieros.
 * - Reglas de amortización.
 * - Lógica de saldos.
 * ============================================================================
 */
final class Creditos extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {
            $creditos = $this->service->creditos();

            $this->moduleView(
                'Finanzas',
                'creditos',
                [
                    'titulo'   => 'Créditos Financieros',
                    'creditos' => $creditos,
                    'csrf'     => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | NUEVO
    |--------------------------------------------------------------------------
    */

    public function nuevo(): void
    {
        $this->requireAuth();

        try {
            $this->moduleView(
                'Finanzas',
                'nuevo_credito',
                [
                    'titulo' => 'Nuevo Crédito',
                    'csrf'   => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR
    |--------------------------------------------------------------------------
    */

    public function guardar(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $id = $this->service->crearCredito(
                $_POST
            );

            $this->redirect(
                '/finanzas/credito/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VER FICHA 360°
    |--------------------------------------------------------------------------
    */

    public function ver(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de crédito inválido.'
                );
            }

            $credito = $this->service->credito($id);

            if (!$credito) {
                throw new RuntimeException(
                    'Crédito no encontrado.'
                );
            }

            $plan = $this->service->plan($id);

            $this->moduleView(
                'Finanzas',
                'ver_credito',
                [
                    'titulo'  => 'Detalle del Crédito',
                    'credito' => $credito,
                    'plan'    => $plan,
                    'csrf'    => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR
    |--------------------------------------------------------------------------
    */

    public function editar(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de crédito inválido.'
                );
            }

            $credito = $this->service->credito($id);

            if (!$credito) {
                throw new RuntimeException(
                    'Crédito inexistente.'
                );
            }

            $this->moduleView(
                'Finanzas',
                'editar_credito',
                [
                    'titulo'  => 'Editar Crédito',
                    'credito' => $credito,
                    'csrf'    => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(int $id): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $this->service->actualizarCredito(
                $id,
                $_POST
            );

            $this->redirect(
                '/finanzas/credito/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REGENERAR PLAN
    |--------------------------------------------------------------------------
    */

    public function regenerarPlan(int $id): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $this->service->regenerarPlan(
                $id
            );

            $this->redirect(
                '/finanzas/credito/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PAGAR CUOTA
    |--------------------------------------------------------------------------
    */

    public function pagar(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de cuota inválido.'
                );
            }

            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $this->service->pagarCuota(
                $id
            );

            $this->redirect(
                $_SERVER['HTTP_REFERER']
                ?? '/finanzas/creditos'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CANCELACIÓN ANTICIPADA
    |--------------------------------------------------------------------------
    */

    public function cancelarAnticipadamente(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de crédito inválido.'
                );
            }

            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $this->service->cancelarAnticipadamente(
                $id
            );

            $this->redirect(
                '/finanzas/credito/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | FINALIZAR
    |--------------------------------------------------------------------------
    */

    public function finalizar(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de crédito inválido.'
                );
            }

            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $this->service->finalizarCredito(
                $id
            );

            $this->redirect(
                '/finanzas/credito/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ANULAR
    |--------------------------------------------------------------------------
    */

    public function anular(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de crédito inválido.'
                );
            }

            $this->validateCsrf(
                $_POST['_csrf'] ?? null
            );

            $this->service->anularCredito(
                $id
            );

            $this->redirect(
                '/finanzas/creditos'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }
}