<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Controllers;

use App\Core\BaseController;
use App\Modules\Finanzas\Services\Service;
use Throwable;

/**
 * Controlador de producción para el módulo de Finanzas de CSDI PRO.
 * Implementa la carga automática de assets mediante el servicio global de Assets.
 */
final class Controller extends BaseController
{
    /**
     * El constructor recibe tu Servicio de Finanzas e inicializa el BaseController.
     */
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX - DASHBOARD DE FINANZAS COMPLETO (Carga Automática de Assets)
    |--------------------------------------------------------------------------
    */
    public function index(): void
    {
        $this->requireAuth();

        try {
            $dashboard = $this->service->dashboard() ?: [];
            $widgets   = $this->service->widgets() ?: [];

            // SOLUCIÓN AUTOMÁTICA (Opción 1): 
            // Registra automáticamente 'assets/css/finanzas.css' y 'assets/js/finanzas.js' si existen en el servidor
            $this->assets()->addModule('Finanzas');

            $this->moduleView(
                'Finanzas',
                'index', // Carga App/Modules/Finanzas/Views/index.php
                [
                    'titulo'       => 'Dashboard Finanzas',
                    'csrf'         => $this->csrf(),
                    'widgets'      => $widgets,
                    'resumen'      => $dashboard['resumen'] ?? [],
                    'vencidas'     => $dashboard['vencidas'] ?? [],
                    'proximas'     => $dashboard['proximas'] ?? [],
                    'detalle'      => $dashboard['detalle'] ?? [],
                    'vencimientos' => $dashboard['vencimientos'] ?? [],
                ]
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }
}