<?php

declare(strict_types=1);

$credito = $credito ?? [];
$csrf = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $valor): string
    {
        return htmlspecialchars(
            (string)($valor ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Crédito #<?= e($credito['id'] ?? '') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container-fluid py-4">

    <!-- ENCABEZADO -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">
                <i class="fa-solid fa-pen-to-square text-primary"></i> Editar Crédito #<?= e($credito['id'] ?? '') ?>
            </h2>
            <p class="text-muted">Modifique los campos necesarios y guarde los cambios</p>
        </div>
        <div>
            <a href="<?= base_url('/finanzas/credito/' . ($credito['id'] ?? 0)) ?>" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <!-- FORMULARIO -->
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body p-4">
            <form action="<?= base_url('/finanzas/credito/' . ($credito['id'] ?? 0) . '/actualizar') ?>" method="POST">
                
                <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">

                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold small text-muted">Fecha</label>
                        <input type="date" name="fecha" class="form-control" value="<?= e($credito['fecha'] ?? '') ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold small text-muted">Banco</label>
                        <input type="text" name="banco" class="form-control" value="<?= e($credito['banco'] ?? '') ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold small text-muted">Descripción / Referencia</label>
                        <input type="text" name="datos_credito" class="form-control" value="<?= e($credito['datos_credito'] ?? '') ?>">
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-3">
                        <label class="form-label fw-bold small text-muted">Importe</label>
                        <input type="text" name="importe" class="form-control" value="<?= e($credito['importe'] ?? '') ?>">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-bold small text-muted">Importe original</label>
                        <input type="text" name="importe_original" class="form-control" value="<?= e($credito['importe_original'] ?? '') ?>">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-bold small text-muted">Valor cuota</label>
                        <input type="text" name="valor_cuota" class="form-control" value="<?= e($credito['valor_cuota'] ?? '') ?>">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-bold small text-muted">Tasa interés %</label>
                        <input type="text" name="tasa_interes" class="form-control" value="<?= e($credito['tasa_interes'] ?? '') ?>">
                    </div>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <label class="form-label fw-bold small text-muted">Cuotas totales</label>
                        <input type="number" name="cuotas_totales" class="form-control" value="<?= e($credito['cuotas_totales'] ?? '') ?>">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-bold small text-muted">Cuotas pagadas</label>
                        <input type="number" name="cuotas_pagadas" class="form-control" value="<?= e($credito['cuotas_pagadas'] ?? '') ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label fw-bold small text-muted">Capital cuota</label>
                        <input type="text" name="capital_cuota" class="form-control" value="<?= e($credito['capital_cuota'] ?? '') ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label fw-bold small text-muted">Interés cuota</label>
                        <input type="text" name="interes_cuota" class="form-control" value="<?= e($credito['interes_cuota'] ?? '') ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label fw-bold small text-muted">Gastos cuota</label>
                        <input type="text" name="gastos_cuota" class="form-control" value="<?= e($credito['gastos_cuota'] ?? '') ?>">
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2">
                    <a href="<?= base_url('/finanzas/credito/' . ($credito['id'] ?? 0)) ?>" class="btn btn-outline-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i> Guardar cambios
                    </button>
                </div>

            </form>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>