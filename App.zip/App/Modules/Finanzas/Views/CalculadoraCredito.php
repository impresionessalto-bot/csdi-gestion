<?php

declare(strict_types=1);

namespace App\Modules\Finanzas\Services;


use DateTime;
use Throwable;



final class CalculadoraCredito
{


    /*
    |--------------------------------------------------------------------------
    | GENERAR PLAN DE CUOTAS
    |--------------------------------------------------------------------------
    |
    | Sistema francés:
    |
    | Cuota fija
    | Capital variable
    | Interés decreciente
    | IVA sobre interés
    | Gastos incluidos
    |
    |--------------------------------------------------------------------------
    */


    public function generarPlan(

        float $monto,

        float $tasaAnual,

        int $cantidadCuotas,

        float $iva = 21,

        float $gastoCuota = 0

    ): array
    {


        try {


            if($monto <= 0)
            {
                return [];
            }


            if($cantidadCuotas <= 0)
            {
                $cantidadCuotas = 1;
            }




            /*
            |--------------------------------------------------------------------------
            | TASA MENSUAL
            |--------------------------------------------------------------------------
            */


            $tasaMensual =
                ($tasaAnual / 100) / 12;





            /*
            |--------------------------------------------------------------------------
            | CUOTA FRANCESA
            |--------------------------------------------------------------------------
            */


            if($tasaMensual > 0)
            {

                $cuotaBase =
                    $monto *
                    (
                        $tasaMensual /
                        (
                            1 -
                            pow(
                                1+$tasaMensual,
                                -$cantidadCuotas
                            )
                        )
                    );

            }
            else
            {

                $cuotaBase =
                    $monto /
                    $cantidadCuotas;

            }








            $saldo =
                $monto;



            $plan=[];





            for(
                $i=1;
                $i <= $cantidadCuotas;
                $i++
            )
            {


                /*
                |--------------------------------------------------------------------------
                | INTERES
                |--------------------------------------------------------------------------
                */


                $interes =
                    $saldo *
                    $tasaMensual;





                /*
                |--------------------------------------------------------------------------
                | CAPITAL
                |--------------------------------------------------------------------------
                */


                $capital =
                    $cuotaBase -
                    $interes;



                if($capital > $saldo)
                {
                    $capital=$saldo;
                }






                /*
                |--------------------------------------------------------------------------
                | IVA INTERES
                |--------------------------------------------------------------------------
                */


                $ivaInteres =
                    $interes *
                    ($iva / 100);







                /*
                |--------------------------------------------------------------------------
                | TOTAL CUOTA
                |--------------------------------------------------------------------------
                */


                $total =

                    $capital

                    +

                    $interes

                    +

                    $ivaInteres

                    +

                    $gastoCuota;







                $fecha =
                    new DateTime();


                $fecha->modify(
                    "+{$i} month"
                );







                $plan[]=[


                    'nro_cuota'
                        =>
                        $i,


                    'fecha_vencimiento'
                        =>
                        $fecha
                            ->format('Y-m-d'),



                    'capital'
                        =>
                        round(
                            $capital,
                            2
                        ),



                    'interes_nominal'
                        =>
                        round(
                            $interes,
                            2
                        ),



                    'iva_interes'
                        =>
                        round(
                            $ivaInteres,
                            2
                        ),



                    'percepcion_iva'
                        =>
                        0,



                    'otros_gastos'
                        =>
                        round(
                            $gastoCuota,
                            2
                        ),



                    'monto_total'
                        =>
                        round(
                            $total,
                            2
                        )

                ];






                $saldo -= $capital;



                if($saldo < 0)
                {
                    $saldo=0;
                }



            }




            return $plan;



        }
        catch(Throwable)
        {

            return [];

        }



    }



}