<?php

declare(strict_types=1);


if(!function_exists('e'))
{

    function e(mixed $v):string
    {
        return htmlspecialchars(
            (string)($v ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }

}



$csrf =
    $csrf
    ??
    '';

?>


<div class="container-fluid">


<div class="card shadow">


<div class="card-header bg-primary text-white">

<h5 class="mb-0">

<i class="fa-solid fa-file-invoice-dollar"></i>

Nuevo Crédito

</h5>

</div>





<div class="card-body">


<form method="POST"
action="<?= base_url('/finanzas/credito/guardar') ?>">



<input type="hidden"
name="_csrf"
value="<?= e($csrf) ?>">





<div class="row">


<div class="col-md-4 mb-3">

<label class="form-label">
Banco
</label>

<input
type="text"
name="banco"
class="form-control"
required>

</div>




<div class="col-md-4 mb-3">

<label class="form-label">
Fecha
</label>

<input
type="date"
name="fecha"
class="form-control"
value="<?= date('Y-m-d') ?>">

</div>




<div class="col-md-4 mb-3">

<label class="form-label">
Descripción
</label>

<input
type="text"
name="datos_credito"
class="form-control">

</div>


</div>







<div class="row">


<div class="col-md-3 mb-3">

<label>
Monto crédito ($)
</label>

<input
type="number"
step="0.01"
id="importe"
name="importe_original"
class="form-control"
value="0">

</div>




<div class="col-md-3 mb-3">

<label>
Tasa anual %
</label>

<input
type="number"
step="0.01"
id="tasa"
name="tasa_interes"
class="form-control"
value="0">

</div>




<div class="col-md-3 mb-3">

<label>
Cantidad cuotas
</label>

<input
type="number"
id="cuotas"
name="cuotas_totales"
class="form-control"
value="12">

</div>




<div class="col-md-3 mb-3">

<label>
IVA interés %
</label>

<input
type="number"
step="0.01"
id="iva"
name="iva"
class="form-control"
value="21">

</div>


</div>






<div class="row">


<div class="col-md-3 mb-3">


<label>
Gastos cuota
</label>


<input
type="number"
step="0.01"
id="gastos"
name="gastos"
class="form-control"
value="0">


</div>


</div>







<hr>


<h5>
Simulación
</h5>



<div class="row">


<div class="col-md-3">


<div class="card bg-light">

<div class="card-body">


<p>
Cuota estimada
</p>


<h4 id="cuota">
$ 0
</h4>


</div>

</div>


</div>





<div class="col-md-3">


<div class="card bg-light">

<div class="card-body">


<p>
Total devolución
</p>


<h4 id="total">
$ 0
</h4>


</div>

</div>


</div>



</div>





<br>



<button
class="btn btn-success">


<i class="fa fa-save"></i>

Guardar Crédito


</button>




<a href="<?= base_url('/finanzas/creditos') ?>"
class="btn btn-secondary">

Cancelar

</a>




</form>


</div>

</div>


</div>







<script>


function calcularCredito()
{


let monto =
parseFloat(
document.getElementById('importe').value
)
||0;



let tasa =
parseFloat(
document.getElementById('tasa').value
)
||0;



let cuotas =
parseInt(
document.getElementById('cuotas').value
)
||1;



let iva =
parseFloat(
document.getElementById('iva').value
)
||0;



let gastos =
parseFloat(
document.getElementById('gastos').value
)
||0;



let tasaMensual =
(tasa / 100) / 12;



let cuota = 0;



if(tasaMensual > 0)
{


cuota =
monto *
(
(tasaMensual *
Math.pow(
1+tasaMensual,
cuotas
))
/
(
Math.pow(
1+tasaMensual,
cuotas
)-1
)
);


}
else
{

cuota =
monto/cuotas;

}



let interes =
(cuota*cuotas)-monto;



let ivaInteres =
interes*
(iva/100);



let total =
(cuota*cuotas)
+
ivaInteres
+
(gastos*cuotas);





document.getElementById('cuota')
.innerHTML =
'$ '+
cuota.toLocaleString(
'es-AR',
{
minimumFractionDigits:2
}
);



document.getElementById('total')
.innerHTML =
'$ '+
total.toLocaleString(
'es-AR',
{
minimumFractionDigits:2
}
);



}





document.querySelectorAll('input')
.forEach(
function(input)
{

input.addEventListener(
'keyup',
calcularCredito
);


input.addEventListener(
'change',
calcularCredito
);


}
);


</script>