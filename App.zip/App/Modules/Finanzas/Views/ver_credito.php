<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP - Ficha de Detalle de Crédito 360° (Con Liquidación y Pagos)
|--------------------------------------------------------------------------
*/

$credito = $credito ?? [];
$plan    = $plan ?? [];
$titulo  = $titulo ?? 'Detalle Crédito';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('dineroARS')) {
    function dineroARS(mixed $valor): string
    {
        return '$ ' . number_format((float)($valor ?? 0), 2, ',', '.');
    }
}

$id      = (int)($credito['id'] ?? 0);
$banco   = (string)($credito['banco'] ?? 'Desconocido');
$importe = (float)($credito['importe'] ?? 0.0);
$original = (float)($credito['importe_original'] ?? 0.0);
$estado  = (string)($credito['estado'] ?? 'Activo');
?>

<div class="container-fluid py-4">

    <!-- =====================================================
         1) CABECERA DE PERFIL 360° (Con Acciones Financieras)
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">
        <div class="d-flex align-items-center">
            <div class="bg-primary text-white rounded-3 p-3 me-3 shadow-sm">
                <i class="fa-solid fa-file-invoice-dollar fs-3"></i>
            </div>
            <div>
                <h2 class="fw-bold text-white mb-1 d-flex align-items-center">
                    Crédito #<?= $id ?> - <?= htmlspecialchars($banco, ENT_QUOTES, 'UTF-8') ?>
                    <?php if ($estado === 'Activo'): ?>
                        <span class="badge bg-success fs-8 ms-2 rounded-pill px-2.5 py-1">Activo</span>
                    <?php else: ?>
                        <span class="badge bg-danger fs-8 ms-2 rounded-pill px-2.5 py-1">Finalizado</span>
                    <?php endif; ?>
                </h2>
                <span class="text-muted-erp small fw-semibold">Detalle del financiamiento bancario y amortizaciones de cuotas</span>
            </div>
        </div>
        
        <!-- Botones de Acción de la Ficha -->
        <div class="d-flex gap-2">
            <a href="/finanzas/creditos" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver
            </a>
            
            <!-- NUEVO BOTÓN: Finalización Anticipada del Crédito -->
            <?php if ($estado === 'Activo'): ?>
                <a href="<?= base_url('/finanzas/credito/' . $id . '/finalizar') ?>" 
                   class="btn btn-outline-danger btn-sm fw-bold px-3" 
                   onclick="return confirm('¿Seguro que desea finalizar este crédito de forma anticipada? Se cancelarán de forma permanente todas las cuotas pendientes restantes en su plan de pagos.');">
                    <i class="fa-solid fa-ban me-1"></i> Finalizar Crédito
                </a>
            <?php endif; ?>

            <a href="<?= base_url('/finanzas/credito/' . $id . '/editar') ?>" class="btn btn-warning btn-sm text-decoration-none fw-bold px-3">
                <i class="fa-solid fa-pen me-1"></i> Editar Crédito
            </a>
        </div>
    </div>

    <!-- =====================================================
         2) TIRA DE KPIS / METRICAS RÁPIDAS DEL CRÉDITO
         ===================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-md-4 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-primary) !important;">
                <div class="card-body p-3">
                    <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Monto Original</span>
                    <strong class="fs-4 text-dark"><?= dineroARS($original) ?></strong>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-danger) !important;">
                <div class="card-body p-3">
                    <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Saldo de Deuda Actual</span>
                    <strong class="fs-4 text-danger"><?= dineroARS($importe) ?></strong>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-success) !important;">
                <div class="card-body p-3">
                    <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Cuotas Amortizadas</span>
                    <strong class="fs-4 text-success"><?= (int)($credito['cuotas_pagadas'] ?? 0) ?>ª / <?= (int)($credito['cuotas_totales'] ?? 1) ?>ª</strong>
                </div>
            </div>
        </div>
    </div>

    <!-- =====================================================
         3) TABLA DE AMORTIZACIÓN (Con Botón de Pago de Cuotas)
         ===================================================== -->
    <div class="card-erp">
        <div class="table-responsive">
            <table class="table-erp align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4 py-3">Cuota</th>
                        <th>Vencimiento</th>
                        <th>Capital</th>
                        <th>Interés</th>
                        <th>IVA Int.</th>
                        <th>Otros Gastos</th>
                        <th class="fw-bold">Monto Total</th>
                        <th>Estado</th>
                        <th class="text-end pe-4" width="160">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($plan)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted-erp py-5">No hay un plan de cuotas autogenerado para este crédito.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($plan as $cuota): ?>
                            <?php
                            $cId     = (int)($cuota['id'] ?? 0);
                            $cNro    = (int)($cuota['nro_cuota'] ?? 0);
                            $cVenc   = (string)($cuota['fecha_vencimiento'] ?? '');
                            $cCap    = (float)($cuota['capital'] ?? 0.0);
                            $cInt    = (float)($cuota['interes_nominal'] ?? 0.0);
                            $cIva    = (float)($cuota['iva_interes'] ?? 0.0);
                            $cGast   = (float)($cuota['otros_gastos'] ?? 0.0);
                            $cTot    = (float)($cuota['monto_total'] ?? 0.0);
                            $cEstado = (string)($cuota['estado'] ?? 'Pendiente');
                            ?>
                            <tr>
                                <td class="ps-4 fw-bold text-white"><?= $cNro ?>ª Cuota</td>
                                <td><?= $cVenc !== '' ? date('d/m/Y', strtotime($cVenc)) : '-' ?></td>
                                <td><?= dineroARS($cCap) ?></td>
                                <td><?= dineroARS($cInt) ?></td>
                                <td><?= dineroARS($cIva) ?></td>
                                <td><?= dineroARS($cGast) ?></td>
                                <td class="text-white fw-bold"><strong><?= dineroARS($cTot) ?></strong></td>
                                <td>
                                    <?php if ($cEstado === 'Pagada'): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle px-2.5 py-1">Pagada</span>
                                    <?php elseif ($cEstado === 'Pendiente'): ?>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-2.5 py-1">Pendiente</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-2.5 py-1">Cancelada</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-4">
                                    <!-- NUEVO BOTÓN: Registrar pago de cuota individual -->
                                    <?php if ($cEstado === 'Pendiente' && $estado === 'Activo'): ?>
                                        <a href="<?= base_url('/finanzas/cuota/' . $cId . '/pagar') ?>" 
                                           class="btn btn-success btn-sm px-3 fw-bold text-decoration-none"
                                           onclick="return confirm('¿Confirmar el pago y amortización de la cuota <?= $cNro ?>ª por un total de <?= dineroARS($cTot) ?>?');">
                                            <i class="fa-solid fa-check me-1"></i> Pagar
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>