<?php

declare(strict_types=1);


/*
|--------------------------------------------------------------------------
| VARIABLES SEGURAS
|--------------------------------------------------------------------------
*/


$cheques =
    $cheques ?? [];


$titulo =
    $titulo ?? 'Gestión de Cheques';




if(!function_exists('e')){

    function e($v): string
    {
        return htmlspecialchars(
            (string)$v,
            ENT_QUOTES,
            'UTF-8'
        );
    }

}




if(!function_exists('dineroARS')){

    function dineroARS($valor): string
    {

        return '$ ' .
            number_format(
                (float)$valor,
                2,
                ',',
                '.'
            );

    }

}


?>



<div class="container-fluid">





<div class="d-flex justify-content-between align-items-center mb-4">



<div>

<h3 class="mb-0">


<i class="fa-solid fa-money-check-dollar"></i>


<?= e($titulo) ?>


</h3>


<p class="text-muted">

Administración de cheques financieros

</p>


</div>





<div>


<a href="/finanzas"
class="btn btn-secondary">


<i class="fa-solid fa-arrow-left"></i>


Volver


</a>





<a href="/finanzas/cheque/nuevo"
class="btn btn-success">


<i class="fa-solid fa-plus"></i>


Nuevo Cheque


</a>



</div>




</div>










<div class="card shadow-sm">



<div class="card-header bg-primary text-white">


<h5 class="mb-0">


<i class="fa-solid fa-money-check"></i>


Cheques registrados


</h5>


</div>





<div class="card-body">



<div class="table-responsive">



<table class="table table-hover align-middle">





<thead class="table-dark">


<tr>


<th>
Fecha
</th>


<th>
Banco
</th>


<th>
Número
</th>


<th>
Importe
</th>


<th>
Vencimiento
</th>


<th>
Estado
</th>


<th>
Acciones
</th>


</tr>


</thead>







<tbody>





<?php if(empty($cheques)): ?>



<tr>


<td colspan="7"
class="text-center text-muted">


No existen cheques cargados


</td>


</tr>





<?php else: ?>







<?php foreach($cheques as $cheque): ?>



<tr>





<td>


<?=

!empty($cheque['fecha'])

?

date(
'd/m/Y',
strtotime(
$cheque['fecha']
)
)

:

'-'

?>


</td>







<td>


<strong>

<?=

e(
$cheque['banco']
??
''
)

?>


</strong>


</td>








<td>


<?=

e(
$cheque['numero']
??
''
)

?>


</td>








<td>


<span class="fw-bold">


<?=

dineroARS(
$cheque['importe']
??
0
)

?>


</span>


</td>







<td>


<?=

!empty($cheque['fecha_vencimiento'])

?

date(
'd/m/Y',
strtotime(
$cheque['fecha_vencimiento']
)
)

:

'-'

?>


</td>








<td>



<?php

$estado =
$cheque['estado']
??
'Pendiente';


?>



<?php if($estado === 'Pagado'): ?>


<span class="badge bg-success">

Pagado

</span>



<?php elseif($estado === 'Rechazado'): ?>


<span class="badge bg-danger">

Rechazado

</span>



<?php else: ?>


<span class="badge bg-warning text-dark">

Pendiente

</span>



<?php endif; ?>




</td>









<td>


<div class="btn-group">






<form method="POST"
action="/finanzas/cheque/<?= (int)$cheque['id'] ?>/estado">


<input type="hidden"
name="_csrf"
value="<?= e($csrf ?? '') ?>">





<input type="hidden"
name="estado"
value="Pagado">





<button
class="btn btn-sm btn-success"
title="Marcar pagado">


<i class="fa-solid fa-check"></i>


</button>


</form>







<form method="POST"
action="/finanzas/cheque/<?= (int)$cheque['id'] ?>/eliminar"
onsubmit="return confirm('¿Eliminar cheque?');">


<input type="hidden"
name="_csrf"
value="<?= e($csrf ?? '') ?>">





<button
class="btn btn-sm btn-danger"
title="Eliminar">


<i class="fa-solid fa-trash"></i>


</button>



</form>







</div>



</td>







</tr>





<?php endforeach; ?>





<?php endif; ?>






</tbody>




</table>




</div>




</div>




</div>





</div>