<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| FINANZAS - LISTADO DE CRÉDITOS (Fórmula de Cuotas Transcurridas xx/xx Integrada)
|--------------------------------------------------------------------------
*/

$creditos = $creditos ?? [];

if (!function_exists('e')) {
    function e(mixed $valor): string
    {
        return htmlspecialchars(
            (string)($valor ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('dineroARS')) {
    function dineroARS(mixed $valor): string
    {
        return '$ ' .
            number_format(
                (float)($valor ?? 0),
                2,
                ',',
                '.'
            );
    }
}
?>

<div class="container-fluid py-4">

    <!-- =====================================================
         HEADER DE LA SECCIÓN (Con botón de Alta)
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h2 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-file-invoice-dollar text-primary me-2"></i> Créditos Financieros
            </h2>
            <p class="text-muted small mb-0">Listado general de créditos bancarios registrados en el sistema</p>
        </div>
        <div>
            <a href="<?= base_url('/finanzas/credito/nuevo') ?>" class="btn btn-primary px-3 shadow-sm fw-semibold">
                <i class="fa-solid fa-plus me-1"></i> Nuevo Crédito
            </a>
        </div>
    </div>

    <!-- =====================================================
         TARJETA Y TABLA DE LISTADO
         ===================================================== -->
    <div class="card border border-light-subtle shadow-sm rounded-3 overflow-hidden">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4 py-3 text-secondary">#ID</th>
                            <th class="text-secondary">Fecha</th>
                            <th class="text-secondary">Banco</th>
                            <th class="text-secondary">Descripción</th>
                            <th class="text-secondary">Importe Original</th>
                            <th class="text-secondary">Cuotas (Trans./Tot.)</th>
                            <th class="text-secondary">Estado</th>
                            <th class="text-end pe-4 text-secondary" width="120">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($creditos)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-5 fs-6">
                                    <i class="fa-solid fa-folder-open d-block fs-3 mb-2 text-secondary"></i>
                                    No existen créditos registrados en la base de datos de CSDI PRO.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($creditos as $c): ?>
                                <?php
                                $cId    = (int)($c['id'] ?? 0);
                                $cFecha = (string)($c['fecha'] ?? '');
                                $cBanco = (string)($c['banco'] ?? '');
                                $cDesc  = (string)($c['datos_credito'] ?? '');
                                $cImp   = (float)($c['importe_original'] ?? 0.0);
                                $cCuot  = (int)($c['cuotas_totales'] ?? 0);
                                $cEst   = (string)($c['estado'] ?? 'Activo');

                                /*
                                |--------------------------------------------------------------------------
                                | CÁLCULO DINÁMICO DE CUOTAS TRANSCURRIDAS (xx/xx)
                                |--------------------------------------------------------------------------
                                */
                                $transcurridas = 0;
                                if ($cFecha !== '') {
                                    try {
                                        $inicio = new DateTime($cFecha);
                                        $hoy = new DateTime(); // Toma la fecha actual del sistema

                                        // Diferencia absoluta en años y meses
                                        $diff = $inicio->diff($hoy);
                                        $mesesTranscurridos = ($diff->y * 12) + $diff->m;

                                        // Si el día actual es mayor o igual al día de inicio, contamos el mes en curso como transcurrido
                                        if ((int)$hoy->format('d') >= (int)$inicio->format('d')) {
                                            $mesesTranscurridos++;
                                        }

                                        // Limitamos las cuotas transcurridas entre 0 y el total de cuotas del crédito
                                        $transcurridas = max(0, min($mesesTranscurridos, $cCuot));
                                    } catch (Throwable) {
                                        $transcurridas = (int)($c['cuotas_pagadas'] ?? 0); // Fallback seguro
                                    }
                                } else {
                                    $transcurridas = (int)($c['cuotas_pagadas'] ?? 0);
                                }

                                // Formateamos estéticamente a dos dígitos (ej: 01/12, 12/60)
                                $formatoCuotas = sprintf('%02d/%02d', $transcurridas, $cCuot);
                                ?>
                                <tr>
                                    <td class="ps-4 fw-semibold text-secondary">#<?= $cId ?></td>
                                    <td><?= $cFecha !== '' ? date('d/m/Y', strtotime($cFecha)) : '-' ?></td>
                                    <td class="text-dark fw-bold"><?= e($cBanco) ?></td>
                                    <td class="text-secondary"><?= e($cDesc) ?></td>
                                    <td class="text-dark fw-bold"><strong><?= dineroARS($cImp) ?></strong></td>
                                    <!-- Celda formateada a xx/xx de forma segura y legible -->
                                    <td class="text-dark fw-bold font-monospace"><?= $formatoCuotas ?></td>
                                    <td>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle px-2.5 py-1">
                                            <?= e($cEst) ?>
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= base_url('/finanzas/credito/' . $cId) ?>" class="btn btn-outline-info px-2" title="Ver Detalle">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            <a href="<?= base_url('/finanzas/credito/' . $cId . '/editar') ?>" class="btn btn-outline-warning px-2" title="Editar">
                                                <i class="fa-solid fa-pen"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>