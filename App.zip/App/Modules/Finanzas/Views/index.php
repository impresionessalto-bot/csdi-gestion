<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP - DASHBOARD DE FINANZAS GENERAL (Con Alertas Temporales Integradas)
|--------------------------------------------------------------------------
*/

$resumen      = $resumen ?? [];
$vencidas     = $vencidas ?? [];
$proximas     = $proximas ?? [];
$detalle      = $detalle ?? [];
$vencimientos = $vencimientos ?? [];
$widgets      = $widgets ?? [];

if (!function_exists('e')) {
    function e($v): string
    {
        return htmlspecialchars(
            (string)$v,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <!-- Encabezado del Módulo -->
    <h2 class="fw-bold text-dark mb-4">
        💰 Dashboard Finanzas
    </h2>

    <!-- =====================================================
         1) TARJETAS DE KPIs (Widgets de Balance General)
         ====================================================== -->
    <div class="row mb-4">
        <?php foreach ($widgets as $widget): ?>
            <div class="col-md-3 mb-3">
                <div class="card border-<?= e($widget['color'] ?? 'secondary') ?> shadow-sm h-100 rounded-3" style="border-left: 4px solid var(--bs-<?= e($widget['color'] ?? 'secondary') ?>) !important;">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted small text-uppercase fw-semibold mb-1">
                                    <?= e($widget['titulo'] ?? '') ?>
                                </h6>
                                <h3 class="fw-bold text-dark mb-0">
                                    <?php
                                    $valor = $widget['valor'] ?? 0;
                                    if (is_numeric($valor)) {
                                        echo '$ ' . number_format((float)$valor, 0, ',', '.');
                                    } else {
                                        echo e($valor);
                                    }
                                    ?>
                                </h3>
                            </div>
                            <div class="fs-2 text-<?= e($widget['color'] ?? 'secondary') ?> p-2">
                                <i class="<?= e($widget['icono'] ?? '') ?>"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- =====================================================
         2) ACCIONES RÁPIDAS
         ====================================================== -->
    <div class="d-flex gap-2 mb-4">
        <a href="/finanzas/creditos" class="btn btn-primary px-3 shadow-sm fw-semibold">
            <i class="fa-solid fa-file-invoice-dollar me-1"></i> Créditos
        </a>
        <a href="/finanzas/cheques" class="btn btn-success px-3 shadow-sm fw-semibold">
            <i class="fa-solid fa-money-check me-1"></i> Cheques
        </a>
    </div>

    <!-- =====================================================
         3) RESUMEN FINANCIERO Y DEUDA POR BANCO
         ====================================================== -->
    <div class="row g-4">
        
        <!-- Bloque Izquierdo: Resumen financiero (Con Alertas Temporales) -->
        <div class="col-md-6">
            <div class="card border border-light-subtle shadow-sm rounded-3 overflow-hidden">
                <div class="card-header bg-light fw-bold text-dark py-3">
                    Resumen financiero
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover align-middle mb-0">
                        <tbody>
                            <tr>
                                <td class="ps-4 py-3 text-secondary">Créditos activos</td>
                                <td class="text-end pe-4 fw-bold text-dark">
                                    <?= number_format((int)($resumen['cantidad_creditos'] ?? 0)) ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="ps-4 py-3 text-secondary">Saldo total</td>
                                <td class="text-end pe-4 fw-bold text-dark">
                                    $ <?= number_format((float)($resumen['saldo_total'] ?? 0.0), 0, ',', '.') ?>
                                </td>
                            </tr>
                            <!-- Alerta Semanal Integrada -->
                            <tr>
                                <td class="ps-4 py-3 text-secondary">
                                    Vencimientos esta Semana 
                                    <small class="text-muted ms-1">(<?= (int)($vencidas['cantidad'] ?? 0) ?> cuotas)</small>
                                </td>
                                <td class="text-danger text-end pe-4 fw-bold">
                                    $ <?= number_format((float)($vencidas['importe'] ?? 0.0), 0, ',', '.') ?>
                                </td>
                            </tr>
                            <!-- Alerta Mensual Integrada -->
                            <tr>
                                <td class="ps-4 py-3 text-secondary">
                                    Próximos 30 días (Mes) 
                                    <small class="text-muted ms-1">(<?= (int)($proximas['cantidad'] ?? 0) ?> cuotas)</small>
                                </td>
                                <td class="text-success text-end pe-4 fw-bold">
                                    $ <?= number_format((float)($proximas['importe'] ?? 0.0), 0, ',', '.') ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Bloque Derecho: Deuda por banco -->
        <div class="col-md-6">
            <div class="card border border-light-subtle shadow-sm rounded-3 overflow-hidden">
                <div class="card-header bg-light fw-bold text-dark py-3">
                    Deuda por banco
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4 py-2 text-secondary">Banco</th>
                                <th class="text-secondary">Créditos</th>
                                <th class="text-end pe-4 text-secondary">Saldo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($detalle)): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-4">No hay deudas por bancos registradas.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($detalle as $row): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold text-dark"><?= e($row['banco'] ?? '') ?></td>
                                        <td class="text-secondary"><?= (int)($row['creditos'] ?? 0) ?></td>
                                        <td class="text-end pe-4 fw-bold text-dark">
                                            $ <?= number_format((float)($row['saldo'] ?? 0.0), 0, ',', '.') ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <!-- =====================================================
         4) TABLA: PRÓXIMOS VENCIMIENTOS DE CUOTAS
         ====================================================== -->
    <div class="card mt-4 border border-light-subtle shadow-sm rounded-3 overflow-hidden">
        <div class="card-header bg-light fw-bold text-dark py-3">
            Próximos vencimientos
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4 text-secondary">Fecha</th>
                            <th class="text-secondary">Banco</th>
                            <th class="text-secondary">Cuota</th>
                            <th class="text-end pe-4 text-secondary">Importe</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($vencimientos)): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">No hay vencimientos pendientes.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($vencimientos as $v): ?>
                                <tr>
                                    <td class="ps-4">
                                        <?= !empty($v['fecha_vencimiento']) ? date('d/m/Y', strtotime((string)$v['fecha_vencimiento'])) : '-' ?>
                                    </td>
                                    <td class="fw-bold text-dark"><?= e($v['banco'] ?? '') ?></td>
                                    <td class="text-secondary"><?= (int)($v['nro_cuota'] ?? 0) ?>ª cuota</td>
                                    <td class="text-end pe-4 fw-bold text-dark">
                                        $ <?= number_format((float)($v['monto_total'] ?? 0.0), 0, ',', '.') ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>