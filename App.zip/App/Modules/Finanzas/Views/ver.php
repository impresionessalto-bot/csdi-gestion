<?php

$credito=$credito??[];
$plan=$plan??[];

?>

<div class="container-fluid">


<h2>
Crédito <?=e($credito['banco']??'')?>
</h2>


<div class="card shadow mb-4">

<div class="card-body">


<div class="row">


<div class="col-md-4">

<strong>Importe</strong>

<br>

€
<?=number_format(
(float)$credito['importe'],
2,
',',
'.'
)?>

</div>



<div class="col-md-4">

<strong>Tasa</strong>

<br>

<?=e($credito['tasa_interes']??0)?> %

</div>



<div class="col-md-4">

<strong>Cuotas</strong>

<br>

<?=e($credito['cuotas_totales']??0)?>

</div>


</div>


</div>

</div>




<div class="card">


<div class="card-header">
Plan de cuotas
</div>


<table class="table">


<thead>

<tr>

<th>N°</th>
<th>Vencimiento</th>
<th>Capital</th>
<th>Total</th>
<th>Estado</th>

</tr>

</thead>



<tbody>


<?php foreach($plan as $p): ?>

<tr>


<td>
<?=$p['nro_cuota']?>
</td>


<td>
<?=date(
'd/m/Y',
strtotime($p['fecha_vencimiento'])
)?>
</td>


<td>
€ <?=number_format($p['capital'],2,',','.')?>
</td>


<td>
€ <?=number_format($p['monto_total'],2,',','.')?>
</td>


<td>
<?=$p['estado']?>
</td>


</tr>


<?php endforeach; ?>


</tbody>

</table>


</div>


</div>