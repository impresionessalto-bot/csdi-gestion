<div class="container-fluid">


<h2>

<i class="fa-solid fa-plus"></i>

Nuevo Cheque

</h2>



<form method="POST"
action="/finanzas/cheques/guardar">


<input type="hidden"
name="_csrf"
value="<?=e($csrf ?? '')?>">



<div class="card">

<div class="card-body">


<div class="row g-3">


<div class="col-md-4">

<label>Fecha</label>

<input type="date"
class="form-control"
name="fecha">

</div>



<div class="col-md-4">

<label>Banco</label>

<input class="form-control"
name="banco">

</div>



<div class="col-md-4">

<label>Emisor</label>

<input class="form-control"
name="emisor">

</div>



<div class="col-md-4">

<label>Importe</label>

<input class="form-control"
name="importe">

</div>


</div>


</div>

</div>



<button class="btn btn-success mt-3">

Guardar cheque

</button>



</form>


</div>