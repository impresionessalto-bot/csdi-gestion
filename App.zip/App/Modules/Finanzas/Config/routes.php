<?php

declare(strict_types=1);

use App\Core\Router;

/*
|--------------------------------------------------------------------------
| FINANZAS ERP (routes.php Modular)
|--------------------------------------------------------------------------
*/
Router::group(
    '/finanzas',
    [
        'auth'
    ],
    function () {

        /*
        |--------------------------------------------------------------------------
        | DASHBOARD
        |--------------------------------------------------------------------------
        */
        Router::get(
            '',
            [
                \App\Modules\Finanzas\Controllers\Controller::class,
                'index'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | CREDITOS
        |--------------------------------------------------------------------------
        */

        // LISTADO
        Router::get(
            '/creditos',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'index'
            ]
        );

        // NUEVO CREDITO
        Router::get(
            '/credito/nuevo',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'nuevo'
            ]
        );

        // GUARDAR CREDITO
        Router::post(
            '/credito/guardar',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'guardar'
            ]
        );

        // VER CREDITO
        Router::get(
            '/credito/{id}',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'ver'
            ]
        );

        // NUEVA RUTA CORREGIDA: Finalización Anticipada de un Crédito
        Router::get(
            '/credito/{id}/finalizar',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'finalizar'
            ]
        );

        // EDITAR CREDITO
        Router::get(
            '/credito/{id}/editar',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'editar'
            ]
        );

        // ACTUALIZAR CREDITO
        Router::post(
            '/credito/{id}/actualizar',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'actualizar'
            ]
        );

        // ELIMINAR CREDITO
        Router::post(
            '/credito/{id}/eliminar',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'eliminar'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | CUOTAS INDIVIDUALES
        |--------------------------------------------------------------------------
        */

        // NUEVA RUTA CORREGIDA: Registrar pago de cuota individual
        Router::get(
            '/cuota/{id}/pagar',
            [
                \App\Modules\Finanzas\Controllers\Creditos::class,
                'pagar'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | CHEQUES
        |--------------------------------------------------------------------------
        */
        Router::get(
            '/cheques',
            [
                \App\Modules\Finanzas\Controllers\Cheques::class,
                'index'
            ]
        );

        Router::post(
            '/cheque/guardar',
            [
                \App\Modules\Finanzas\Controllers\Cheques::class,
                'guardar'
            ]
        );

        Router::post(
            '/cheque/{id}/estado',
            [
                \App\Modules\Finanzas\Controllers\Cheques::class,
                'estado'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | API FINANZAS
        |--------------------------------------------------------------------------
        */
        Router::get(
            '/api/credito/{id}',
            [
                \App\Modules\Finanzas\Controllers\Api::class,
                'credito'
            ]
        );

        Router::get(
            '/api/cheques',
            [
                \App\Modules\Finanzas\Controllers\Api::class,
                'cheques'
            ]
        );
    }
);