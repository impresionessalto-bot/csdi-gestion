<?php

declare(strict_types=1);

namespace App\Modules\Finanzas;

use App\Core\Module as BaseModule;

final class Module extends BaseModule
{
    public function name(): string
    {
        return 'Finanzas';
    }

    public function priority(): int
    {
        return 50;
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function menu(): array
    {
        return [
            [
                'title'      => 'Finanzas',
                'url'        => '/finanzas',
                'icon'       => 'fa-solid fa-coins',
                'permission' => 'finanzas.view',
                'order'      => 50,
            ],
        ];
    }

    public function permissions(): array
    {
        return [
            'finanzas.view',
            'finanzas.create',
            'finanzas.edit',
            'finanzas.delete',
        ];
    }

    public function boot(): void
    {
    }
}