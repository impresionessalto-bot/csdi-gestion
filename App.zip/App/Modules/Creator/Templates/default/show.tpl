<?php
/**
 * Vista de detalle / visualización individual para <?= $MODULE ?>
 */
?>
<div class="container-fluid px-4 py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi <?= $ICON ?? 'bi-eye' ?>"></i> Detalle de <?= $MODULE ?></h2>
        <a href="/<?= strtolower($MODULE) ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Volver al Listado
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-info-circle"></i> Información del Registro #<?= htmlspecialchars((string)($data['id'] ?? '')) ?></h5>
        </div>
        <div class="card-body">
            <?php if (!empty($data)): ?>
                <dl class="row">
                    <?php foreach ($data as $key => $value): ?>
                        <dt class="col-sm-3 text-muted text-uppercase small"><?= htmlspecialchars((string)$key) ?></dt>
                        <dd class="col-sm-9"><?= htmlspecialchars((string)($value ?? '')) ?></dd>
                    <?php endforeach; ?>
                </dl>
            <?php else: ?>
                <p class="text-muted text-center py-4">No se encontraron datos para este registro.</p>
            <?php endif; ?>
        </div>
        <div class="card-footer text-end">
            <a href="/<?= strtolower($MODULE) ?>/edit?id=<?= $data['id'] ?? '' ?>" class="btn btn-warning">
                <i class="bi bi-pencil"></i> Editar
            </a>
        </div>
    </div>
</div>