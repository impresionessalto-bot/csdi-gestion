<?php
declare(strict_types=1);

namespace App\Modules\<?= $MODULE ?>;

use App\Core\Module as CoreModule;

final class Module extends CoreModule
{
    public function name(): string
    {
        return '<?= $MODULE ?>';
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function menu(): array
    {
        return [
            'titulo' => '<?= $MODULE ?>'
        ];
    }

    public function icon(): string
    {
        return '<?= $ICON ?>';
    }

    public function url(): string
    {
        return '/<?= strtolower($MODULE) ?>';
    }

    public function order(): int
    {
        return 50;
    }

    public function permissions(): array
    {
        return [
            '<?= strtolower($MODULE) ?>.ver',
            '<?= strtolower($MODULE) ?>.crear',
            '<?= strtolower($MODULE) ?>.editar',
            '<?= strtolower($MODULE) ?>.eliminar'
        ];
    }

    public function dependencies(): array
    {
        return [];
    }
}