<?php
declare(strict_types=1);

use App\Core\Router;

Router::group('<?= strtolower($MODULE) ?>', ['auth'], function () {
    Router::get('/', '<?= $MODULE ?>\Controllers\<?= $MODULE ?>Controller@index');
});