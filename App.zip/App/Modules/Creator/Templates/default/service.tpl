<?php
declare(strict_types=1);

namespace App\Modules\<?= $MODULE ?>\Services;

use App\Modules\<?= $MODULE ?>\Repositories\<?= $MODULE ?>Repository;

final class <?= $CLASS ?>Service
{
    public function __construct(
        private <?= $MODULE ?>Repository $repository
    ) {}

    public function getAll(): array
    {
        return $this->repository->all();
    }
}