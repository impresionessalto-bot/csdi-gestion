<?php
/**
 * Template de configuración y metadatos para el Builder Enterprise del módulo <?= $MODULE ?> (C-SDI PRO ERP)
 */
return [
    'module' => '<?= $MODULE ?>',
    'version' => '2.0.0-enterprise',
    'author' => 'CSDI PRO ERP Core Engine',
    'stack' => [
        'php' => '8.3',
        'database' => 'MySQL',
        'framework' => 'MVC Custom Architecture',
        'frontend' => 'Bootstrap 5 + Fetch API'
    ],
    'structure' => [
        'controllers' => 'Controllers/Controller.php',
        'services' => [
            'Service' => 'Services/Service.php',
            'AiService' => 'Services/AiService.php'
        ],
        'repositories' => 'Repositories/Repository.php',
        'views' => [
            'index' => 'Views/index.tpl',
            'form' => 'Views/form.tpl',
            'show' => 'Views/show.tpl'
        ],
        'config' => 'Config/routes.php'
    ],
    'options' => [
        'soft_deletes' => true,
        'timestamps' => true,
        'audit_logs' => true,
        'csrf_protection' => true
    ]
];