<?php
declare(strict_types=1);

namespace App\Modules\<?= $MODULE ?>\Controllers;

use App\Core\BaseController;
use App\Modules\<?= $MODULE ?>\Services\<?= $MODULE ?>Service;

final class <?= $CLASS ?> extends BaseController
{
    public function __construct(
        private <?= $MODULE ?>Service $service
    ) {}

    public function index(): void
    {
        $this->view('index', [
            'titulo' => 'Gestión de <?= $MODULE ?>',
            'data' => $this->service->getAll()
        ]);
    }
}