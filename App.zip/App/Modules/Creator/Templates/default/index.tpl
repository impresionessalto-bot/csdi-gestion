<?php
/**
 * Vista principal de listado mejorada para <?= $MODULE ?> (Nivel Enterprise - Bootstrap 5)
 */
$items = $items ?? $data ?? [];
$stats = $stats ?? [];
?>
<div class="container-fluid px-4 py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2><i class="fa-solid <?= $ICON ?? 'fa-layer-group' ?> me-2"></i><?= $titulo ?? $MODULE ?></h2>
            <p class="text-muted mb-0">Gestión y control general del módulo <?= $MODULE ?>.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="/<?= strtolower($MODULE) ?>/crear" class="btn btn-primary">
                <i class="fa-solid fa-plus me-1"></i> Nuevo Registro
            </a>
        </div>
    </div>

    <!-- FILTROS DE BÚSQUEDA -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body">
            <form method="GET" action="/<?= strtolower($MODULE) ?>">
                <div class="row g-3">
                    <div class="col-md-10">
                        <label class="form-label fw-bold">Buscar</label>
                        <input type="text" name="texto" class="form-control" value="<?= htmlspecialchars((string)($_GET['texto'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="Buscar por código, serie o descripción...">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-dark w-100"><i class="fa-solid fa-search me-1"></i> Filtrar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- TABLA DE RESULTADOS -->
    <div class="card shadow-sm border-0">
        <div class="card-body table-responsive p-0">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th width="70">ID</th>
                        <th>Código / Serie</th>
                        <th>Estado</th>
                        <th>Fecha Creación</th>
                        <th width="140" class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($items)): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted p-5">
                            <i class="fa-solid fa-folder-open fa-3x mb-3"></i>
                            <h5>No se encontraron registros disponibles.</h5>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($items as $row): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars((string)($row['id'] ?? '')) ?></strong></td>
                            <td>
                                <div><strong><?= htmlspecialchars((string)($row['codigo_interno'] ?? 'S/C')) ?></strong></div>
                                <code><?= htmlspecialchars((string)($row['serie'] ?? 'S/N')) ?></code>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?= htmlspecialchars((string)($row['estado'] ?? 'Activo')) ?></span>
                            </td>
                            <td><?= htmlspecialchars((string)($row['created_at'] ?? '')) ?></td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="/<?= strtolower($MODULE) ?>/<?= htmlspecialchars((string)($row['id'] ?? '')) ?>/editar" class="btn btn-outline-warning" title="Modificar">
                                        <i class="fa-solid fa-pen"></i>
                                    </a>
                                    <form method="POST" action="/<?= strtolower($MODULE) ?>/<?= htmlspecialchars((string)($row['id'] ?? '')) ?>/eliminar" class="d-inline" onsubmit="return confirm('¿Confirma la baja lógica de este registro?');">
                                        <button type="submit" class="btn btn-outline-danger rounded-0 rounded-end" title="Eliminar">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>