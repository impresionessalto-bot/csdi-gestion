<?php
declare(strict_types=1);

/**
 * Script SQL para la tabla del módulo <?= $MODULE ?>
 */
return "
CREATE TABLE IF NOT EXISTS `{$TABLE}` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
";