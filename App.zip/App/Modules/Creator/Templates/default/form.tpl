<?php
/**
 * Vista parcial de formulario mejorada para <?= $MODULE ?> (Nivel Enterprise - Bootstrap 5)
 */
$item = $item ?? [];
$isEdit = !empty($item['id']);
$actionUrl = $isEdit ? '/' . strtolower($MODULE) . '/' . $item['id'] : '/' . strtolower($MODULE) . '/crear';
?>
<form action="<?= $actionUrl ?>" method="POST" class="needs-validation" novalidate>
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars((string)$item['id'], ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>
    
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fa-solid fa-pen-to-square me-2"></i><?= $isEdit ? 'Modificar' : 'Nuevo registro de' ?> <?= $MODULE ?></h5>
            <span class="badge bg-secondary">Enterprise Module</span>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <!-- Código Interno -->
                <div class="col-md-6">
                    <label for="codigo_interno" class="form-label fw-bold">Código Interno</label>
                    <input type="text" class="form-control" id="codigo_interno" name="codigo_interno" value="<?= htmlspecialchars((string)($item['codigo_interno'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="Ej: CSDI-001">
                    <div class="invalid-feedback">Por favor ingrese un código válido.</div>
                </div>

                <!-- Serie / Identificador Principal -->
                <div class="col-md-6">
                    <label for="serie" class="form-label fw-bold">Número de Serie <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="serie" name="serie" value="<?= htmlspecialchars((string)($item['serie'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" required>
                    <div class="invalid-feedback">El número de serie es obligatorio.</div>
                </div>

                <!-- Estado -->
                <div class="col-md-6">
                    <label for="estado" class="form-label fw-bold">Estado</label>
                    <select class="form-select" id="estado" name="estado">
                        <option value="Activo" <?= (($item['estado'] ?? 'Activo') === 'Activo') ? 'selected' : '' ?>>Activo</option>
                        <option value="Disponible" <?= (($item['estado'] ?? '') === 'Disponible') ? 'selected' : '' ?>>Disponible</option>
                        <option value="En reparación" <?= (($item['estado'] ?? '') === 'En reparación') ? 'selected' : '' ?>>En reparación</option>
                        <option value="Baja" <?= (($item['estado'] ?? '') === 'Baja') ? 'selected' : '' ?>>Baja</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="card-footer bg-light text-end py-3">
            <a href="/<?= strtolower($MODULE) ?>" class="btn btn-secondary px-4"><i class="fa-solid fa-arrow-left me-1"></i> Cancelar</a>
            <button type="submit" class="btn btn-success px-4 fw-bold"><i class="fa-solid fa-save me-1"></i> Guardar</button>
        </div>
    </div>
</form>