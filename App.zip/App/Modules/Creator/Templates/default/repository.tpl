<?php
declare(strict_types=1);

namespace App\Modules\<?= $MODULE ?>\Repositories;

use App\Core\BaseRepository;
use PDO;

final class <?= $CLASS ?> extends BaseRepository
{
    protected string $table = '<?= $TABLE ?>';

    /**
     * Obtiene todos los registros activos de la tabla <?= $TABLE ?> (con soporte para borrado lógico)
     */
    public function listar(array $filtros = []): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE (deleted_at IS NULL OR deleted_at = '0000-00-00 00:00:00')";
        $params = [];

        if (!empty($filtros['texto'])) {
            $sql .= " AND (codigo_interno LIKE ? OR serie LIKE ? OR ubicacion_actual LIKE ?)";
            $params[] = "%{$filtros['texto']}%";
            $params[] = "%{$filtros['texto']}%";
            $params[] = "%{$filtros['texto']}%";
        }

        $sql .= " ORDER BY id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Busca un registro por su ID en <?= $TABLE ?> evitando eliminados
     */
    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table} 
            WHERE id = ? AND (deleted_at IS NULL OR deleted_at = '0000-00-00 00:00:00') 
            LIMIT 1
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row !== false ? $row : null;
    }

    /**
     * Crea un nuevo registro en <?= $TABLE ?>
     */
    public function crear(array $data): void
    {
        $stmt = $this->db->prepare("
            INSERT INTO {$this->table} (codigo_interno, serie, estado, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([
            trim($data['codigo_interno'] ?? '') ?: null,
            trim($data['serie'] ?? ''),
            trim($data['estado'] ?? 'Activo')
        ]);
    }

    /**
     * Actualiza un registro existente en <?= $TABLE ?>
     */
    public function actualizar(int $id, array $data): void
    {
        $stmt = $this->db->prepare("
            UPDATE {$this->table} 
            SET codigo_interno = ?, serie = ?, estado = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([
            trim($data['codigo_interno'] ?? '') ?: null,
            trim($data['serie'] ?? ''),
            trim($data['estado'] ?? 'Activo'),
            $id
        ]);
    }

    /**
     * Realiza un borrado lógico en <?= $TABLE ?>
     */
    public function delete(int $id): void
    {
        $stmt = $this->db->prepare("UPDATE {$this->table} SET deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
    }
}