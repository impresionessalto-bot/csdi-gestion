<?php
declare(strict_types=1);

namespace <?= $NAMESPACE ?>;

use App\Core\BaseApiController;
use App\Modules\<?= $MODULE ?>\Services\<?= $MODULE ?>Service;

final class <?= $MODULE ?>ApiController extends BaseApiController
{
    public function __construct(
        private <?= $MODULE ?>Service $service
    ) {}

    public function index(): void
    {
        $data = $this->service->getAll();
        $this->json(['success' => true, 'data' => $data]);
    }

    public function show(int $id): void
    {
        $data = $this->service->getById($id);
        if (!$data) {
            $this->json(['success' => false, 'message' => 'Recurso no encontrado'], 404);
            return;
        }
        $this->json(['success' => true, 'data' => $data]);
    }
}