<?php
declare(strict_types=1);

use App\Core\Router;

Router::group('api/v1/<?= $LOWER ?>', ['api.auth'], function () {
    Router::get('/', '<?= $MODULE ?>\Api\<?= $MODULE ?>ApiController@index');
    Router::get('/{id}', '<?= $MODULE ?>\Api\<?= $MODULE ?>ApiController@show');
});