<?php
declare(strict_types=1);

namespace <?= $NAMESPACE ?>;

final class <?= $MODULE ?>ApiResponse
{
    public static function format(mixed $data, string $message = 'Éxito', int $status = 200): array
    {
        return [
            'status'  => $status,
            'message' => $message,
            'data'    => $data
        ];
    }
}