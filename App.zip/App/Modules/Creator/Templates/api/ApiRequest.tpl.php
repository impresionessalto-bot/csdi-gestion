<?php
declare(strict_types=1);

namespace <?= $NAMESPACE ?>;

final class <?= $MODULE ?>ApiRequest
{
    public function validate(array $data): array
    {
        // Reglas de validación para la API de <?= $MODULE ?>
        return $data;
    }
}