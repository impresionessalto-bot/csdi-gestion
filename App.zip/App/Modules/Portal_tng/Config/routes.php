<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Portal_tng\Controllers\Controller;

/*
|--------------------------------------------------------------------------
| PORTAL TNG ROUTES
|--------------------------------------------------------------------------
|
| Portal cliente TNG
|
| Consulta:
|
| - contrato
| - equipos
| - visitas
| - informes
|
*/

Router::group(
    'portal-tng',
    [
        'auth'
    ],
    function(): void {

        /*
        |--------------------------------------------------------------------------
        | Inicio portal
        |--------------------------------------------------------------------------
        */
        Router::get(
            '/',
            [
                Controller::class,
                'index'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | Visitas
        |--------------------------------------------------------------------------
        */
        Router::get(
            '/visitas',
            [
                Controller::class,
                'visitas'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | Informes
        |--------------------------------------------------------------------------
        */
        Router::get(
            '/informes',
            [
                Controller::class,
                'informes'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | Descargar / Ver informe PDF
        |--------------------------------------------------------------------------
        */
        Router::get(
            '/informe/{id}',
            [
                Controller::class,
                'verInforme'
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | NUEVO: Aprobación de Conformidad Digital (Envia a Facturación)
        |--------------------------------------------------------------------------
        | Resuelve la URL '/portal-tng/informe/{id}/aprobar' llamando de forma 
        | segura a la acción aprobar() en tu controlador.
        */
        Router::get(
            '/informe/{id}/aprobar',
            [
                Controller::class,
                'aprobar'
            ]
        );
    }
);