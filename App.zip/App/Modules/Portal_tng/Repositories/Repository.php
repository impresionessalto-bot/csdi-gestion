<?php

declare(strict_types=1);

namespace App\Modules\Portal_tng\Repositories;

use PDO;



final class Repository
{


    public function __construct(
        private readonly PDO $db
    ){
    }







    public function cliente(
        int $id
    ):array
    {


        $stmt=$this->db->prepare("

            SELECT
                id,
                nombre

            FROM clientes

            WHERE id=:id

            LIMIT 1

        ");


        $stmt->execute([
            'id'=>$id
        ]);


        return
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?:[];


    }








    public function informesCliente(
        int $clienteId
    ):array
    {


        $stmt=$this->db->prepare("


            SELECT

                id,
                nro_informe,
                fecha,
                archivo_path,
                observaciones


            FROM historial_informes


            WHERE cliente_id=:cliente

            AND propiedad='TNG'


            ORDER BY fecha DESC


        ");



        $stmt->execute([

            'cliente'=>$clienteId

        ]);



        return
            $stmt->fetchAll(PDO::FETCH_ASSOC);


    }








    public function informesPeriodo(
        int $clienteId,
        int $anio,
        int $mes
    ):array
    {


        $stmt=$this->db->prepare("


            SELECT

                id,
                nro_informe,
                fecha,
                archivo_path


            FROM historial_informes


            WHERE cliente_id=:cliente


            AND propiedad='TNG'


            AND YEAR(fecha)=:anio


            AND MONTH(fecha)=:mes



            ORDER BY fecha DESC



        ");



        $stmt->execute([


            'cliente'=>$clienteId,

            'anio'=>$anio,

            'mes'=>$mes


        ]);



        return
            $stmt->fetchAll(PDO::FETCH_ASSOC);



    }








    public function archivo(
        int $id,
        int $clienteId
    ):?string
    {


        $stmt=$this->db->prepare("


            SELECT archivo_path


            FROM historial_informes


            WHERE id=:id


            AND cliente_id=:cliente


            AND propiedad='TNG'


            LIMIT 1


        ");



        $stmt->execute([


            'id'=>$id,

            'cliente'=>$clienteId


        ]);



        $data =
            $stmt->fetch(PDO::FETCH_ASSOC);



        return
            $data['archivo_path']
            ??
            null;


    }





}