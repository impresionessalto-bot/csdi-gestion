<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\ContratoRepository;
use App\Modules\TNG\Repositories\VisitaRepository;
use App\Modules\TNG\Repositories\InformeTngRepository;
use RuntimeException;


final class PortalTngService
{


    public function __construct(

        private readonly ContratoRepository $contratoRepository,

        private readonly VisitaRepository $visitaRepository,

        private readonly InformeTngRepository $informeRepository

    ){
    }





    /**
     * Resumen principal portal
     */
    public function resumen(
        int $clienteId
    ): array
    {


        $this->validarCliente(
            $clienteId
        );


        return [

            'contrato' =>

                $this->contratoRepository
                    ->activoCliente(
                        $clienteId
                    ),



            'visitas' =>

                $this->visitaRepository
                    ->cliente(
                        $clienteId
                    ),



            'informes' =>

                $this->informes(
                    $clienteId
                )

        ];

    }





    /**
     * Contrato activo
     */
    public function contrato(
        int $clienteId
    ): ?array
    {


        $this->validarCliente(
            $clienteId
        );


        return $this->contratoRepository
            ->activoCliente(
                $clienteId
            );

    }





    /**
     * Visitas cliente
     */
    public function visitas(
        int $clienteId
    ): array
    {


        $this->validarCliente(
            $clienteId
        );


        return $this->visitaRepository
            ->cliente(
                $clienteId
            );

    }





    /**
     * Informes técnicos cliente
     *
     * No muestra anulados
     */
    public function informes(
        int $clienteId
    ): array
    {


        $this->validarCliente(
            $clienteId
        );


        return $this->informeRepository
            ->clientePortal(
                $clienteId
            );

    }





    /**
     * Informe individual
     */
    public function informe(
        int $id
    ): ?array
    {


        $informe =

            $this->informeRepository
                ->buscar(
                    $id
                );


        if(!$informe){

            return null;

        }



        /*
         |
         | Seguridad:
         | nunca devolver anulados
         |
         */


        if(
            ($informe['estado'] ?? '')
            ===
            'ANULADO'
        ){

            return null;

        }



        return $informe;

    }





    /**
     * Estado general
     */
    public function estado(
        int $clienteId
    ): array
    {


        $visitas =
            $this->visitas(
                $clienteId
            );



        $pendientes = 0;

        $cerradas = 0;



        foreach($visitas as $visita){


            switch(
                $visita['estado']
            ){


                case 'PENDIENTE':

                case 'ASIGNADA':

                case 'EN_PROCESO':

                    $pendientes++;

                break;



                case 'CERRADA':

                    $cerradas++;

                break;


            }

        }



        return [

            'pendientes'=>
                $pendientes,


            'finalizadas'=>
                $cerradas

        ];

    }





    /**
     * Validación cliente
     */
    private function validarCliente(
        int $clienteId
    ): void
    {


        if($clienteId <= 0){

            throw new RuntimeException(
                'Cliente TNG inválido.'
            );

        }

    }





}