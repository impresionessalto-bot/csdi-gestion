<?php

declare(strict_types=1);

namespace App\Modules\Portal_tng;

use App\Core\Module as BaseModule;


final class Module extends BaseModule
{


    public function name(): string
    {
        return 'Portal TNG';
    }





    public function description(): string
    {
        return 'Portal de clientes TNG';
    }





    public function version(): string
    {
        return '1.0.0';
    }





    public function routes(): string
    {
        return __DIR__
            .'/Config/routes.php';
    }





    public function menu(): array
    {

        return [

            [

                'title'=>'Portal TNG',

                'url'=>'/portal-tng',

                'icon'=>'bi bi-person-circle',

                'permission'=>'cliente'

            ]

        ];

    }





    public function permissions(): array
    {

        return [

            'portal_tng.ver',

            'portal_tng.visitas',

            'portal_tng.informes'

        ];

    }





    public function boot(): void
    {

        // Inicialización futura del módulo

    }


}