<?php

declare(strict_types=1);


/*
|--------------------------------------------------------------------------
| PORTAL TNG
| LISTADO GENERAL
|--------------------------------------------------------------------------
*/


$cliente =
    $cliente ?? [];


$informes =
    $informes ?? [];



if(!function_exists('h'))
{

    function h(mixed $v):string
    {

        return htmlspecialchars(
            (string)($v ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );

    }

}


?>


<div class="container-fluid px-4">



<div class="d-flex justify-content-between align-items-center mb-4">


<div>


<h2 class="fw-bold">

<i class="fa-solid fa-file-pdf text-danger"></i>

Portal TNG


</h2>


<p class="text-muted">

Consulta de informes técnicos

</p>


</div>



<div>


<span class="badge bg-primary fs-6">


<?=h(
    $cliente['nombre'] ?? 'Cliente'
)?>


</span>


</div>


</div>









<div class="card shadow-sm mb-4">


<div class="card-header bg-primary text-white">


<i class="fa-solid fa-building"></i>

Cliente


</div>


<div class="card-body">


<h4>

<?=h(
    $cliente['nombre'] ?? ''
)?>

</h4>


</div>


</div>









<div class="card shadow-sm">


<div class="card-header">


<ul class="nav nav-tabs card-header-tabs">


<li class="nav-item">


<a

class="nav-link active"

href="<?=base_url(
    'portal-tng'
)?>">


<i class="fa-solid fa-list"></i>

Todos los informes


</a>


</li>





<li class="nav-item">


<a

class="nav-link"

href="<?=base_url(
    'portal-tng/periodo'
)?>">


<i class="fa-solid fa-calendar"></i>

Por período


</a>


</li>


</ul>


</div>






<div class="table-responsive">


<table class="table table-hover mb-0">


<thead class="table-light">


<tr>

<th>
Nº Informe
</th>


<th>
Fecha
</th>


<th>
Observaciones
</th>


<th width="120">
PDF
</th>


</tr>


</thead>





<tbody>



<?php if(empty($informes)): ?>

<tr>

<td

colspan="4"

class="text-center text-muted py-4">


No hay informes disponibles


</td>

</tr>



<?php else: ?>



<?php foreach($informes as $i): ?>

<tr>



<td>

<strong>

<?=h(
    $i['nro_informe'] ?? ''
)?>

</strong>

</td>






<td>


<?=

!empty($i['fecha'])

?

h(
date(
'd/m/Y',
strtotime(
$i['fecha']
)
)
)

:

''

?>


</td>






<td>

<?=h(
    $i['observaciones'] ?? ''
)?>

</td>







<td>


<a

target="_blank"

class="btn btn-danger btn-sm"

href="<?=base_url(

'portal-tng/pdf/'.

(int)(
$i['id'] ?? 0

)

)?>">


<i class="fa-solid fa-file-pdf"></i>

Ver


</a>


</td>




</tr>



<?php endforeach; ?>



<?php endif; ?>



</tbody>



</table>


</div>


</div>




</div>