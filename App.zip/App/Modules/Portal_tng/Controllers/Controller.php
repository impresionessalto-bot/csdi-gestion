<?php

declare(strict_types=1);

namespace App\Modules\Portal_tng\Controllers;

use App\Core\BaseController;
use App\Modules\TNG\Services\PortalTngService;
use App\Services\Audit\AuditService; // Inyección de tu servicio de auditoría global
use RuntimeException;
use Throwable;
use PDO;

/**
 * Controlador de producción para el Portal Autogestionable TNG de Clientes.
 * Incorpora un Bypass de Superusuario y el Workflow de Aprobación de Facturación Directa.
 */
final class Controller extends BaseController
{
    /**
     * El constructor recibe el servicio e inicializa la seguridad del BaseController.
     */
    public function __construct(
        private readonly PortalTngService $service,
        private readonly AuditService $auditService // Inyectado automáticamente por el Container
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX - PORTAL TNG
    |--------------------------------------------------------------------------
    */
    public function index(): void
    {
        $this->requireAuth();

        try {
            $clienteId = $this->clienteActual();

            $stmt = $this->db->prepare("SELECT id, nombre FROM clientes WHERE id = ? LIMIT 1");
            $stmt->execute([$clienteId]);
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $this->moduleView(
                'Portal_tng',
                'index',
                [
                    'titulo'  => 'Portal TNG - Inicio',
                    'cliente' => $cliente,
                    'resumen' => $this->service->resumen($clienteId) ?: [],
                    'csrf'    => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VISITAS DEL CLIENTE
    |--------------------------------------------------------------------------
    */
    public function visitas(): void
    {
        $this->requireAuth();

        try {
            $clienteId = $this->clienteActual();

            $stmt = $this->db->prepare("SELECT id, nombre FROM clientes WHERE id = ? LIMIT 1");
            $stmt->execute([$clienteId]);
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $this->moduleView(
                'Portal_tng',
                'visitas',
                [
                    'titulo'  => 'Mis Visitas Técnicas',
                    'cliente' => $cliente,
                    'visitas' => $this->service->visitas($clienteId) ?: [],
                    'csrf'    => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO DE INFORMES TÉCNICOS
    |--------------------------------------------------------------------------
    */
    public function informes(): void
    {
        $this->requireAuth();

        try {
            $clienteId = $this->clienteActual();

            $stmt = $this->db->prepare("SELECT id, nombre FROM clientes WHERE id = ? LIMIT 1");
            $stmt->execute([$clienteId]);
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $this->moduleView(
                'Portal_tng',
                'informes',
                [
                    'titulo'   => 'Mis Informes Técnicos',
                    'cliente'  => $cliente,
                    'informes' => $this->service->informes($clienteId) ?: [],
                    'csrf'     => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VER INFORME INDIVIDUAL
    |--------------------------------------------------------------------------
    */
    public function verInforme(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException('ID de informe inválido.');
            }

            $informe = $this->service->informe($id);

            if (!$informe) {
                throw new RuntimeException('El informe solicitado no existe.');
            }

            $clienteId = $this->clienteActual();
            $informeClienteId = (int)($informe['cliente_id'] ?? 0);

            $esAdmin = (strtoupper((string)($_SESSION['user']['rol'] ?? '')) === 'ADMIN' || strtoupper((string)($_SESSION['user']['rol'] ?? '')) === 'ADMINISTRADOR');

            if (!$esAdmin && $informeClienteId !== $clienteId) {
                throw new RuntimeException('Acceso denegado.');
            }

            $this->moduleView(
                'Portal_tng',
                'informe', // Carga App/Modules/Portal_tng/Views/informe.php
                [
                    'titulo'  => 'Informe Técnico #' . ($informe['nro_informe'] ?? $id),
                    'informe' => $informe,
                    'csrf'    => $this->csrf(),
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACCIÓN WORKFLOW: APROBACIÓN DE CONFORME DIGITAL (Envia a Facturación)
    |--------------------------------------------------------------------------
    */
    public function aprobar(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException('ID de informe inválido.');
            }

            $clienteId = $this->clienteActual();

            // 1. Validación de pertenencia física de la orden para evitar hackeos URL
            $stmtCheck = $this->db->prepare("SELECT cliente_id, estado, nro_informe FROM registros_tng WHERE id = ? LIMIT 1");
            $stmtCheck->execute([$id]);
            $informe = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if (!$informe) {
                throw new RuntimeException('El informe solicitado no existe.');
            }

            $informeClienteId = (int)$informe['cliente_id'];
            $esAdmin = (strtoupper((string)($_SESSION['user']['rol'] ?? '')) === 'ADMIN' || strtoupper((string)($_SESSION['user']['rol'] ?? '')) === 'ADMINISTRADOR');

            if (!$esAdmin && $informeClienteId !== $clienteId) {
                throw new RuntimeException('Acceso denegado: No tienes permisos para firmar este documento.');
            }

            // 2. Ejecutar la actualización en MySQL cambiando el estado a 'FACTURAR'
            $stmtUpdate = $this->db->prepare("UPDATE registros_tng SET estado = 'FACTURAR' WHERE id = ?");
            $stmtUpdate->execute([$id]);

            // 3. AUDITORÍA AUTOMÁTICA: Registramos la aprobación digital en la bitácora central
            if ($this->auditService) {
                $this->auditService->log(
                    'Portal_tng',
                    'APROBAR',
                    'registros_tng',
                    $id,
                    "El cliente #{$clienteId} aprobó de conformidad el informe técnico #{$informe['nro_informe']}, enviado a facturación directa."
                );
            }

            // Redirigimos de vuelta a la ficha del informe con bandera de éxito
            $this->redirect('/portal-tng/informe/' . $id . '?success=approved');

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | HELPER DE SEGURIDAD (Obtiene el ID del Cliente logueado con Bypass de Admin)
    |--------------------------------------------------------------------------
    */
    private function clienteActual(): int
    {
        $user = $_SESSION['user'] ?? [];
        $rol = strtoupper((string)($user['rol'] ?? ''));

        if ($rol === 'ADMIN' || $rol === 'ADMINISTRADOR') {
            try {
                $stmt = $this->db->query("SELECT cliente_id FROM registros_tng WHERE propiedad = 'TNG' LIMIT 1");
                $idPrimerCliente = $stmt->fetchColumn();
                
                if ($idPrimerCliente) {
                    return (int)$idPrimerCliente;
                }

                $stmtFallback = $this->db->query("SELECT id FROM clientes WHERE activo = 1 LIMIT 1");
                $idFallback = $stmtFallback->fetchColumn();

                return $idFallback ? (int)$idFallback : 1;
            } catch (Throwable) {
                return 1;
            }
        }

        $clienteId = (int)(
            $user['linked_cliente_id']
            ?? $user['cliente_id']
            ?? $user['id_cliente']
            ?? $user['portal_cliente_id']
            ?? 0
        );

        if ($clienteId <= 0) {
            throw new RuntimeException(
                'Tu usuario no tiene un cliente corporativo asociado en el sistema.'
            );
        }

        return $clienteId;
    }
}