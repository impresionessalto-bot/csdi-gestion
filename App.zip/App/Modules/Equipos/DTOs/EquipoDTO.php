<?php
declare(strict_types=1);

namespace App\Modules\Equipos\DTOs;

use App\Core\BaseDTO;
use InvalidArgumentException;


final class EquipoDTO extends BaseDTO
{

    public function __construct(

        public readonly ?string $codigo_interno = null,

        public readonly ?int $cliente_id = null,

        public readonly ?string $cod_item_dux = null,

        public readonly ?int $modelo_id = null,

        public readonly string $serie,

        public readonly ?string $identificador_externo = null,

        public readonly int $activo = 1,

        public readonly string $propiedad = 'CSDI',

        public readonly string $estado = 'Activo',

        public readonly ?string $ubicacion_actual = null,

        public readonly ?string $observaciones = null,

        public readonly ?string $direccion_equipo = null,

        public readonly int $es_alquilado = 0,

        public readonly int $abono_minimo_mono = 0,

        public readonly int $abono_minimo_color = 0,

        public readonly ?string $voltaje = '220V',

        public readonly float $valor_activo = 0,

        public readonly int $init_k = 100,

        public readonly int $init_c = 100,

        public readonly int $init_m = 100,

        public readonly int $init_y = 100

    ){

        if(trim($this->serie)===''){

            throw new InvalidArgumentException(
                'La serie del equipo es obligatoria.'
            );

        }



        if(
            !in_array(
                $this->propiedad,
                [
                    'CSDI',
                    'Cliente',
                    'TNG'
                ]
            )
        ){

            throw new InvalidArgumentException(
                'Propiedad inválida.'
            );

        }



        if(
            !in_array(
                $this->estado,
                [
                    'Activo',
                    'Disponible',
                    'En reparación',
                    'Baja'
                ]
            )
        ){

            throw new InvalidArgumentException(
                'Estado inválido.'
            );

        }

    }

}