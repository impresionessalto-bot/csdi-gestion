<?php

declare(strict_types=1);

namespace App\Modules\Equipos\Services;

use App\Modules\Equipos\Repositories\Repository;
use RuntimeException;

final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    public function listar(array $filtros = []): array
    {
        return $this->repository->listar($filtros);
    }

    public function find(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->find($id);
    }

    public function crear(array $data): int
    {
        $data = $this->normalizarDatos($data);
        $this->validarDatos($data);

        return $this->repository->crear($data);
    }

    public function actualizar(int $id, array $data): void
    {
        if ($id <= 0) {
            throw new RuntimeException('El ID del equipo no es válido.');
        }

        $equipo = $this->repository->find($id);
        if ($equipo === null) {
            throw new RuntimeException('No se encontró el equipo solicitado.');
        }

        $data = $this->normalizarDatos($data);
        $this->validarDatos($data);

        $this->repository->actualizar($id, $data);
    }

    public function delete(int $id): void
    {
        if ($id <= 0) {
            throw new RuntimeException('El ID del equipo no es válido.');
        }

        $equipo = $this->repository->find($id);
        if ($equipo === null) {
            throw new RuntimeException('No se encontró el equipo solicitado.');
        }

        $this->repository->delete($id);
    }

    public function obtenerClientes(): array
    {
        return $this->repository->obtenerClientes();
    }

    public function obtenerModelos(): array
    {
        return $this->repository->obtenerModelos();
    }

    public function obtenerLocalidades(): array
    {
        return $this->repository->obtenerLocalidades();
    }

    public function obtenerEstadisticas(): array
    {
        return $this->repository->obtenerEstadisticas();
    }

    public function metricas(int $id): array
    {
        if ($id <= 0) {
            return [];
        }

        return $this->repository->metricas($id);
    }

    public function widgets(int $id): array
    {
        if ($id <= 0) {
            return [];
        }

        return $this->repository->widgets($id);
    }

    /*
    |--------------------------------------------------------------------------
    | NORMALIZAR DATOS
    |--------------------------------------------------------------------------
    */
    private function normalizarDatos(array $data): array
    {
        $serie = $data['serie'] ?? $data['nro_serie'] ?? '';

        $estadoInput = trim((string)($data['estado'] ?? 'Activo'));
        $estadosPermitidos = ['Activo', 'Disponible', 'En reparación', 'Baja'];
        $estado = in_array($estadoInput, $estadosPermitidos, true) ? $estadoInput : 'Activo';

        $propiedadInput = trim((string)($data['propiedad'] ?? 'CSDI'));
        $propiedadesPermitidas = ['CSDI', 'Cliente', 'TNG'];
        $propiedad = in_array($propiedadInput, $propiedadesPermitidas, true) ? $propiedadInput : 'CSDI';

        return [
            'cliente_id'       => $this->normalizarId($data['cliente_id'] ?? null),
            'modelo_id'        => $this->normalizarId($data['modelo_id'] ?? null),
            'codigo_interno'   => trim((string)($data['codigo_interno'] ?? '')),
            'serie'            => trim((string)$serie),
            'propiedad'        => $propiedad,
            'localidad_id'     => $this->normalizarId($data['localidad_id'] ?? null),
            'direccion_equipo' => trim((string)($data['direccion_equipo'] ?? '')), // <-- Soporta dirección
            'estado'           => $estado,
            'observaciones'    => trim((string)($data['observaciones'] ?? '')),
        ];
    }

    private function normalizarId(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        $id = (int)$value;
        return $id > 0 ? $id : null;
    }

    private function validarDatos(array $data): void
    {
        if (empty($data['serie'])) {
            throw new RuntimeException('El número de serie del equipo es obligatorio.');
        }
    }
}