<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Equipos\Controllers\Controller;

Router::group(
    '/equipos',
    function (): void {

        /*
        |--------------------------------------------------------------------------
        | LISTADO PRINCIPAL
        |--------------------------------------------------------------------------
        */

        Router::get(
            '',
            [Controller::class, 'index']
        );

        Router::get(
            '/',
            [Controller::class, 'index']
        );


        /*
        |--------------------------------------------------------------------------
        | CREAR
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/crear',
            [Controller::class, 'create']
        );

        Router::post(
            '/',
            [Controller::class, 'store']
        );


        /*
        |--------------------------------------------------------------------------
        | REPORTES
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/reportes/excel',
            [Controller::class, 'exportarExcel']
        );

        Router::get(
            '/reportes/pdf',
            [Controller::class, 'exportarPdf']
        );

        Router::get(
            '/reportes/csv',
            [Controller::class, 'exportarCsv']
        );


        /*
        |--------------------------------------------------------------------------
        | FICHA 360°
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/{id}',
            [Controller::class, 'show']
        );


        /*
        |--------------------------------------------------------------------------
        | EDITAR
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/{id}/editar',
            [Controller::class, 'edit']
        );

        Router::post(
            '/{id}',
            [Controller::class, 'update']
        );


        /*
        |--------------------------------------------------------------------------
        | ELIMINAR
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/{id}/eliminar',
            [Controller::class, 'destroy']
        );

    }
);