<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| VISTA PARQUE DE EQUIPOS (Index de producción unificado - Edición Limpia)
|--------------------------------------------------------------------------
*/

$equipos     = is_array($equipos ?? null) ? $equipos : [];
$clientes    = is_array($clientes ?? null) ? $clientes : [];
$localidades = is_array($localidades ?? null) ? $localidades : [];

$stats = array_merge(
    [
        'total'   => 0,
        'activos' => 0,
        'tng'     => 0,
        'taller'  => 0
    ],
    is_array($stats ?? null) ? $stats : []
);
$filtros = is_array($filtros ?? null) ? $filtros : ['texto' => '', 'estado' => ''];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4 animate-fade-in">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h2 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-print text-primary me-2"></i> Gestión de Equipos
            </h2>
            <p class="text-muted small mb-0">Control integral del parque instalado CSDI / TNG / Clientes</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= base_url('/equipos/crear') ?>" class="btn btn-csdi btn-sm px-3 fw-semibold shadow-sm">
                <i class="fa-solid fa-plus me-1"></i> Nuevo Equipo
            </a>
            <button class="btn btn-dark btn-sm px-3 fw-semibold shadow-sm" onclick="abrirModalReportes()">
                <i class="fa-solid fa-file-export me-1"></i> Exportar
            </button>
        </div>
    </div>

    <!-- KPIS -->
    <div class="erp-grid mb-4">
        <div class="erp-card kpi-filter-card position-relative overflow-hidden" 
             data-filter-target="estado" 
             data-filter-value=""
             title="Ver todos los equipos">
            <div class="erp-kpi">
                <div>
                    <small class="text-uppercase fw-bold d-block mb-1">Total Equipos</small>
                    <h2><?= e((string)$stats['total']) ?></h2>
                </div>
                <div class="text-muted opacity-50">
                    <i class="fa-solid fa-circle-notch fa-spin fa-lg"></i>
                </div>
            </div>
        </div>

        <div class="erp-card kpi-filter-card position-relative overflow-hidden" 
             data-filter-target="estado" 
             data-filter-value="Activo"
             style="border-left: 4px solid var(--bs-success) !important;"
             title="Filtrar por Equipos Activos">
            <div class="erp-kpi">
                <div>
                    <small class="text-uppercase fw-bold d-block mb-1">Activos</small>
                    <h2><?= e((string)$stats['activos']) ?></h2>
                </div>
                <div class="text-muted opacity-50">
                    <i class="fa-solid fa-circle-check fa-lg"></i>
                </div>
            </div>
        </div>

        <div class="erp-card kpi-filter-card position-relative overflow-hidden" 
             data-filter-target="propiedad" 
             data-filter-value="TNG"
             style="border-left: 4px solid var(--bs-info) !important;"
             title="Filtrar por propiedad TNG">
            <div class="erp-kpi">
                <div>
                    <small class="text-uppercase fw-bold d-block mb-1">Equipos TNG</small>
                    <h2><?= e((string)$stats['tng']) ?></h2>
                </div>
                <div class="text-muted opacity-50">
                    <i class="fa-solid fa-building fa-lg"></i>
                </div>
            </div>
        </div>

        <div class="erp-card kpi-filter-card position-relative overflow-hidden" 
             data-filter-target="estado" 
             data-filter-value="Taller"
             style="border-left: 4px solid var(--bs-warning) !important;"
             title="Filtrar por Equipos en Taller">
            <div class="erp-kpi">
                <div>
                    <small class="text-uppercase fw-bold d-block mb-1">Taller General</small>
                    <h2><?= e((string)$stats['taller']) ?></h2>
                </div>
                <div class="text-muted opacity-50">
                    <i class="fa-solid fa-screwdriver-wrench fa-lg"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- SMART SEARCH -->
    <div class="row mb-3">
        <div class="col-12 col-md-4 ms-auto">
            <form method="GET" action="<?= base_url('/equipos') ?>" class="mb-0">
                <div class="input-group shadow-sm">
                    <span class="input-group-text bg-white border-end-0 text-muted">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </span>
                    <input type="text" 
                           name="texto" 
                           id="smartSearchEquipos" 
                           class="form-control border-start-0 ps-0 fw-semibold csdi-smart-search" 
                           data-target-table="tablaEquiposList" 
                           placeholder="Buscar por modelo, serie, código o cliente..." 
                           value="<?= e($filtros['texto'] ?? '') ?>">
                    
                    <?php if (!empty($filtros['texto'])): ?>
                        <a href="<?= base_url('/equipos') ?>" class="btn btn-outline-secondary border-start-0 bg-white text-muted" id="btnLimpiarBusqueda" title="Limpiar búsqueda">
                            <i class="fa-solid fa-xmark"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- TABLA DE EQUIPOS -->
    <div class="erp-table table-responsive shadow-sm">
        <table class="table table-hover align-middle mb-0" id="tablaEquiposList">
            <thead>
                <tr>
                    <th class="ps-4 py-3"><span class="sort-trigger text-secondary" data-col="0">ID <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="1">Código <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="2">Modelo <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="3">Cliente <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="4">Localidad <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="5">Serie <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="6">Propiedad <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="7">Estado <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th><span class="sort-trigger text-secondary" data-col="8">Dirección <i class="fa-solid fa-sort ms-1 small"></i></span></th>
                    <th class="text-end pe-4" width="160">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($equipos)): ?>
                    <tr>
                        <td colspan="10" class="text-center p-5 text-muted fs-6">No hay equipos registrados en la base de datos de CSDI PRO.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($equipos as $eq): ?>
                        <?php
                        $eqId        = (int)($eq['id'] ?? 0);
                        $eqCod       = (string)($eq['codigo_interno'] ?? '-');
                        $eqMod       = (string)($eq['modelo_oficial'] ?? '-');
                        $eqCli       = (string)($eq['cliente_nombre'] ?? 'Taller General');
                        $eqLoc       = (string)($eq['localidad_nombre'] ?? 'Sin asignar');
                        $eqSerie     = (string)($eq['serie'] ?? $eq['nro_serie'] ?? 'S/N');
                        $eqProp      = (string)($eq['propiedad'] ?? 'CSDI');
                        $eqEstado    = (string)($eq['estado'] ?? 'Activo');
                        $eqDireccion = (string)($eq['direccion_equipo'] ?? '-');
                        ?>
                        <tr class="fila-tabla fila-filtrable" 
                            data-estado="<?= e($eqEstado) ?>" 
                            data-propiedad="<?= e(strtoupper($eqProp)) ?>">
                            <td class="ps-4 text-secondary fw-semibold">#<?= $eqId ?></td>
                            <td><strong class="text-dark"><?= htmlspecialchars($eqCod, ENT_QUOTES, 'UTF-8') ?></strong></td>
                            <td class="text-dark fw-bold"><?= htmlspecialchars($eqMod, ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($eqCli, ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <span class="text-secondary small fw-semibold">
                                    <i class="fa-solid fa-location-dot text-danger me-1"></i><?= htmlspecialchars($eqLoc, ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </td>
                            <td class="font-monospace text-secondary"><?= htmlspecialchars($eqSerie, ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <span class="badge bg-light text-dark border px-2 py-1 fs-8 fw-semibold">
                                    <?= htmlspecialchars(strtoupper($eqProp), ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($eqEstado === 'Activo' || $eqEstado === 'ALQUILADO'): ?>
                                    <span class="erp-badge badge-success">Activo</span>
                                <?php elseif ($eqEstado === 'Taller'): ?>
                                    <span class="erp-badge badge-warning">Taller</span>
                                <?php else: ?>
                                    <span class="erp-badge badge-danger"><?= htmlspecialchars(strtoupper($eqEstado), ENT_QUOTES, 'UTF-8') ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="text-muted small">
                                    <?= htmlspecialchars($eqDireccion !== '' ? $eqDireccion : '-', ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <div class="btn-group btn-group-sm">
                                    <a class="btn btn-outline-info px-2" href="<?= base_url('/equipos/' . $eqId) ?>" title="Ver Ficha 360°">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    
                                    <a class="btn btn-outline-warning px-2" href="<?= base_url('/equipos/' . $eqId . '/editar') ?>" title="Editar">
                                        <i class="fa-solid fa-pen"></i>
                                    </a>
                                    
                                    <button class="btn btn-outline-danger px-2" onclick="abrirModalSwap(<?= $eqId ?>, '<?= e($eqMod) ?>', '<?= e($eqSerie) ?>')" title="Realizar Swap / Intercambio">
                                        <i class="fa-solid fa-arrows-rotate"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- =====================================================
         5) MODAL DE EXPORTACIONES CON FILTROS AVANZADOS
         ===================================================== -->
    <div class="modal fade" id="modalReportesEquipos" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content erp-modal border-0 shadow-lg" style="overflow: hidden;">
                <div class="modal-header bg-dark text-white py-3">
                    <h5 class="modal-title fw-bold">
                        <i class="fa-solid fa-file-export me-2 text-primary"></i> Exportar Parque de Equipos
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                
                <form method="GET" action="<?= base_url('/equipos/reportes/excel') ?>" id="formExportacion">
                    <div class="modal-body p-4 bg-white">
                        <p class="text-muted small mb-3">
                            Puedes aplicar filtros específicos o dejar en blanco para exportar todos los equipos:
                        </p>

                        <div class="row g-3">
                            <!-- FILTRO CLIENTE -->
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted text-uppercase mb-1">Cliente:</label>
                                <select name="cliente_id" class="form-select form-select-sm">
                                    <option value="">Todos los clientes</option>
                                    <?php foreach ($clientes as $cli): ?>
                                        <option value="<?= e($cli['id']) ?>"><?= e($cli['nombre']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- FILTRO LOCALIDAD -->
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted text-uppercase mb-1">Localidad:</label>
                                <select name="localidad_id" class="form-select form-select-sm">
                                    <option value="">Todas las localidades</option>
                                    <?php foreach ($localidades as $loc): ?>
                                        <option value="<?= e($loc['id']) ?>"><?= e($loc['nombre']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- FILTRO PROPIEDAD -->
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted text-uppercase mb-1">Propiedad:</label>
                                <select name="propiedad" class="form-select form-select-sm">
                                    <option value="">Todas</option>
                                    <option value="CSDI">CSDI</option>
                                    <option value="TNG">TNG</option>
                                    <option value="Cliente">Cliente</option>
                                </select>
                            </div>

                            <!-- FILTRO ESTADO -->
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted text-uppercase mb-1">Estado:</label>
                                <select name="estado" class="form-select form-select-sm">
                                    <option value="">Todos los estados</option>
                                    <option value="Activo">Activo</option>
                                    <option value="Disponible">Disponible</option>
                                    <option value="En reparación">En reparación</option>
                                    <option value="Baja">Baja</option>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex gap-2 justify-content-center mt-4">
                            <!-- Botón Excel -->
                            <button type="submit" 
                                    formaction="<?= base_url('/equipos/reportes/excel') ?>" 
                                    class="btn btn-success px-4 fw-bold">
                                <i class="fa-solid fa-file-excel me-1"></i> Descargar EXCEL
                            </button>

                            <!-- Botón PDF (Abre en nueva pestaña) -->
                            <button type="submit" 
                                    formaction="<?= base_url('/equipos/reportes/pdf') ?>" 
                                    formtarget="_blank" 
                                    class="btn btn-danger px-4 fw-bold">
                                <i class="fa-solid fa-file-pdf me-1"></i> Descargar PDF
                            </button>
                        </div>
                    </div>
                </form>

                <div class="modal-footer bg-light py-2">
                    <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL SWAP -->
    <div class="modal fade" id="modalSwapEquipo" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form id="formSwapEquipo" method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?= e($csrf ?? '') ?>">
                <input type="hidden" name="_csrf" value="<?= e($csrf ?? '') ?>">
                
                <div class="modal-content erp-modal border-0 shadow-lg" style="overflow: hidden;">
                    <div class="modal-header bg-danger text-white py-3">
                        <h5 class="modal-title fw-bold">
                            <i class="fa-solid fa-arrows-rotate me-2"></i> Solicitar Swap de Equipo
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body p-4 bg-white">
                        <div class="erp-alert erp-alert-danger small mb-3">
                            <strong>Atención:</strong> Esta operación retirará el equipo seleccionado y lo enviará al estado correspondiente para registrar su reemplazo.
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted text-uppercase mb-1">Equipo a retirar:</label>
                            <div class="p-2.5 bg-light rounded border fw-bold text-dark" id="swapInfoEquipo">-</div>
                        </div>

                        <div class="mb-3">
                            <label for="swapTipo" class="form-label small fw-bold text-muted text-uppercase mb-1">Tipo de Operación / Destino:</label>
                            <select class="form-select fw-semibold" id="swapTipo" name="tipo_swap" required>
                                <option value="CSDI">Intercambio Interno CSDI</option>
                                <option value="TNG">Reemplazo TNG</option>
                                <option value="TALLER">Retirar a Taller General</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="swapMotivo" class="form-label small fw-bold text-muted text-uppercase mb-1">Motivo o Descripción del Cambio:</label>
                            <textarea class="form-control" id="swapMotivo" name="motivo" rows="3" placeholder="Indicar la falla, cambio contractual o requerimiento técnico..." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-csdi btn-sm px-3 fw-bold">Confirmar Intercambio</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
let modalEquipos = null;
let modalSwap = null;

document.addEventListener('DOMContentLoaded', () => {
    const elementoReportes = document.getElementById('modalReportesEquipos');
    if (elementoReportes && typeof bootstrap !== 'undefined') {
        modalEquipos = new bootstrap.Modal(elementoReportes);
    }

    const elementoSwap = document.getElementById('modalSwapEquipo');
    if (elementoSwap && typeof bootstrap !== 'undefined') {
        modalSwap = new bootstrap.Modal(elementoSwap);
    }

    const inputSearch = document.getElementById('smartSearchEquipos');
    const tableList = document.getElementById('tablaEquiposList');
    const kpiCards = document.querySelectorAll('.kpi-filter-card');

    if (inputSearch && tableList) {
        inputSearch.addEventListener('input', function() {
            const term = this.value.toLowerCase().trim();
            const rows = tableList.querySelectorAll('tbody tr.fila-tabla');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(term)) {
                    row.style.setProperty('display', '', 'important');
                } else {
                    row.style.setProperty('display', 'none', 'important');
                }
            });
        });
    }

    kpiCards.forEach(card => {
        card.style.cursor = 'pointer';
        card.addEventListener('click', function() {
            const targetField = this.getAttribute('data-filter-target');
            const filterValue = this.getAttribute('data-filter-value');
            
            const isActive = this.classList.contains('border-primary');
            
            kpiCards.forEach(c => {
                c.classList.remove('border-primary', 'shadow-sm');
                c.style.transform = '';
            });
            
            const rows = tableList.querySelectorAll('tbody tr.fila-filtrable');
            
            if (isActive || !filterValue) {
                rows.forEach(row => row.style.setProperty('display', '', 'important'));
                if (inputSearch) inputSearch.value = '';
                return;
            }
            
            this.classList.add('border-primary', 'shadow-sm');
            this.style.transform = 'scale(1.02)';
            
            rows.forEach(row => {
                const rowValue = row.getAttribute(`data-${targetField}`);
                if (rowValue === filterValue) {
                    row.style.setProperty('display', '', 'important');
                } else {
                    row.style.setProperty('display', 'none', 'important');
                }
            });
        });
    });
});

function abrirModalReportes() {
    if (modalEquipos) {
        modalEquipos.show();
    }
}

function abrirModalSwap(id, modelo, serie) {
    if (modalSwap) {
        const form = document.getElementById('formSwapEquipo');
        if (form) {
            form.action = "<?= base_url('/equipos') ?>/" + id + "/swap";
        }

        const infoText = document.getElementById('swapInfoEquipo');
        if (infoText) {
            infoText.innerHTML = `<i class="fa-solid fa-print text-secondary me-1"></i> ${modelo} <span class="text-muted small ms-2">(${serie})</span>`;
        }

        modalSwap.show();
    }
}
</script>