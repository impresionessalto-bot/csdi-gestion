<?php
declare(strict_types=1);

/**
 * ============================================================================
 * CSDI ERP PRO - FICHA 360° (Vista Secundaria Optimizada)
 * ============================================================================
 */

$equipoId = (int)($equipo['id'] ?? 0);
$baseEquipoUrl = '/equipos';

// Clases de estado dinámicas resumidas
$estadoLower = strtolower((string)($equipo['estado'] ?? ''));
$estadoClass = match (true) {
    str_contains($estadoLower, 'activo')  => 'badge-success',
    str_contains($estadoLower, 'taller')  => 'badge-warning',
    str_contains($estadoLower, 'inactivo')=> 'badge-danger',
    default                               => 'bg-secondary'
};
?>

<div class="container-fluid py-3 animate-fade-in">

    <!-- ================================================================
         CABECERA
         ================================================================ -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <div class="d-flex align-items-center gap-2 mb-1">
                <a href="<?= e($baseEquipoUrl) ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Equipos
                </a>
                <span class="text-muted">/ Ficha 360°</span>
            </div>
            <h1 class="h3 fw-bold mb-1">
                <i class="fa-solid fa-print text-danger me-2"></i>
                <?= e($equipo['nombre_modelo'] ?? $equipo['modelo'] ?? 'Equipo') ?>
            </h1>
            <div class="text-muted small">
                Serie: <strong><?= e($equipo['serie'] ?? $equipo['nro_serie'] ?? 'S/N') ?></strong>
                <span class="mx-2">•</span>
                Código: <strong><?= e($equipo['codigo_interno'] ?? '—') ?></strong>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2">
            <a href="<?= e($baseEquipoUrl . '/' . $equipoId . '/editar') ?>" class="btn btn-outline-primary">
                <i class="fa-solid fa-pen-to-square me-1"></i> Editar
            </a>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalSwap">
                <i class="fa-solid fa-right-left me-1"></i> Swap
            </button>
        </div>
    </div>

    <!-- ================================================================
         TARJETAS KPI RESUMIDAS
         ================================================================ -->
    <div class="row g-3 mb-4">
        <div class="col-12 col-md-6 col-xl-3">
            <div class="erp-card h-100">
                <div class="text-muted small mb-1">MARCA / MODELO</div>
                <div class="fw-bold fs-5"><?= e($equipo['nombre_modelo'] ?? $equipo['modelo'] ?? '—') ?></div>
                <div class="text-muted small"><?= e($equipo['marca'] ?? '—') ?></div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="erp-card h-100">
                <div class="text-muted small mb-1">CLIENTE ASOCIADO</div>
                <div class="fw-bold fs-5"><?= e($equipo['cliente_nombre'] ?? 'Taller General') ?></div>
                <div class="text-muted small"><i class="fa-solid fa-location-dot me-1"></i> <?= e($equipo['localidad'] ?? '—') ?></div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="erp-card h-100">
                <div class="text-muted small mb-1">ESTADO OPERATIVO</div>
                <div><span class="erp-badge <?= $estadoClass ?>"><?= e($equipo['estado'] ?? 'Sin estado') ?></span></div>
                <div class="text-muted small mt-2">Propiedad: <strong><?= e($equipo['propiedad'] ?? 'CSDI') ?></strong></div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="erp-card h-100">
                <div class="text-muted small mb-1">CONTADORES ACTUALES</div>
                <div class="d-flex justify-content-between">
                    <div><span class="text-muted small d-block">Mono:</span><strong><?= number_format((int)($equipo['contador_mono'] ?? 0), 0, ',', '.') ?></strong></div>
                    <div><span class="text-muted small d-block">Color:</span><strong><?= number_format((int)($equipo['contador_color'] ?? 0), 0, ',', '.') ?></strong></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ================================================================
         VISTA DE PESTAÑAS (TABS CSDI / TNG)
         ================================================================ -->
    <div class="erp-card p-0">
        <ul class="nav nav-tabs px-3 pt-3" id="equipoTabs" role="tablist">
            <li class="nav-item"><button class="nav-link active fw-bold" id="csdi-tab" data-bs-toggle="tab" data-bs-target="#tabCsdi" type="button" role="tab"><i class="fa-solid fa-building me-1"></i> CSDI</button></li>
            <li class="nav-item"><button class="nav-link fw-bold" id="tng-tab" data-bs-toggle="tab" data-bs-target="#tabTng" type="button" role="tab"><i class="fa-solid fa-file-lines me-1"></i> TNG</button></li>
        </ul>

        <div class="tab-content p-4">
            <!-- TAB CSDI -->
            <div class="tab-pane fade show active" id="tabCsdi" role="tabpanel">
                <div class="row g-4">
                    <div class="col-12 col-xl-6">
                        <div class="border rounded p-3 h-100">
                            <h5 class="fw-bold mb-3"><i class="fa-solid fa-building text-danger me-2"></i> Información CSDI</h5>
                            <div class="row g-3">
                                <div class="col-md-6"><label class="text-muted small">Cliente</label><div class="fw-semibold"><?= e($equipo['cliente_nombre'] ?? 'Sin cliente') ?></div></div>
                                <div class="col-md-6"><label class="text-muted small">Localidad</label><div class="fw-semibold"><?= e($equipo['localidad'] ?? 'Sin localidad') ?></div></div>
                                <div class="col-md-6"><label class="text-muted small">Código Interno</label><div class="fw-semibold"><?= e($equipo['codigo_interno'] ?? '—') ?></div></div>
                                <div class="col-md-6"><label class="text-muted small">Identificador Externo</label><div class="fw-semibold"><?= e($equipo['identificador_externo'] ?? '—') ?></div></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-xl-6">
                        <div class="border rounded p-3 h-100">
                            <h5 class="fw-bold mb-3"><i class="fa-solid fa-gauge-high text-danger me-2"></i> Lecturas Rápidas</h5>
                            <div class="row g-2">
                                <div class="col-6"><div class="erp-card text-center"><small class="text-muted">MONO</small><h4 class="fw-bold m-0"><?= number_format((int)($equipo['contador_mono'] ?? 0), 0, ',', '.') ?></h4></div></div>
                                <div class="col-6"><div class="erp-card text-center"><small class="text-muted">COLOR</small><h4 class="fw-bold m-0"><?= number_format((int)($equipo['contador_color'] ?? 0), 0, ',', '.') ?></h4></div></div>
                            </div>
                            <a href="/counter?equipo_id=<?= $equipoId ?>" class="btn btn-outline-danger w-100 btn-sm mt-3"><i class="fa-solid fa-gauge me-1"></i> Ver Historial de Contadores</a>
                        </div>
                    </div>

                    <!-- HISTORIAL DE SERVICIOS -->
                    <div class="col-12">
                        <div class="border rounded">
                            <div class="p-3 border-bottom"><h5 class="fw-bold mb-0"><i class="fa-solid fa-clock-rotate-left text-danger me-2"></i> Historial de Servicios</h5></div>
                            <?php if (!empty($historial)): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead><tr><th>Fecha</th><th>Servicio</th><th>Estado</th><th>Técnico</th><th>Observaciones</th></tr></thead>
                                        <tbody>
                                            <?php foreach ($historial as $item): ?>
                                                <tr>
                                                    <td><?= e($item['fecha'] ?? $item['created_at'] ?? '—') ?></td>
                                                    <td><?= e($item['tipo'] ?? $item['servicio'] ?? '—') ?></td>
                                                    <td><span class="badge bg-secondary"><?= e($item['estado'] ?? '—') ?></span></td>
                                                    <td><?= e($item['tecnico'] ?? $item['tecnico_nombre'] ?? '—') ?></td>
                                                    <td><?= e($item['observaciones'] ?? '—') ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="p-4 text-center text-muted"><i class="fa-solid fa-wrench fa-2x mb-2"></i><div>No hay servicios registrados.</div></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB TNG -->
            <div class="tab-pane fade" id="tabTng" role="tabpanel">
                <div class="row g-4">
                    <div class="col-12 col-xl-6">
                        <div class="border rounded p-3 h-100">
                            <h5 class="fw-bold mb-3"><i class="fa-solid fa-file-lines text-danger me-2"></i> Identificación TNG</h5>
                            <div class="row g-3">
                                <div class="col-md-6"><label class="text-muted small">Código TNG</label><div class="fw-bold"><?= e($equipo['codigo_tng'] ?? '—') ?></div></div>
                                <div class="col-md-6"><label class="text-muted small">Número Informe</label><div class="fw-bold"><?= e($equipo['numero_informe'] ?? '—') ?></div></div>
                                <div class="col-md-6"><label class="text-muted small">Fecha TNG</label><div><?= e($equipo['fecha_tng'] ?? '—') ?></div></div>
                                <div class="col-md-6"><label class="text-muted small">Estado TNG</label><div><?= e($equipo['estado_tng'] ?? '—') ?></div></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-xl-6">
                        <div class="border rounded p-3 h-100">
                            <h5 class="fw-bold mb-3"><i class="fa-solid fa-link text-danger me-2"></i> Vinculación</h5>
                            <div class="alert alert-light border mb-0">
                                <small class="text-muted d-block">REGISTRO OPERATIVO TNG</small>
                                <strong>Informe: <?= e($equipo['numero_informe'] ?? 'Sin asociar') ?></strong>
                                <span class="d-block small text-muted">Código: <?= e($equipo['codigo_tng'] ?? '—') ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- BOTONERA DE ACCIÓN -->
    <div class="row g-3 mt-3">
        <div class="col-12 col-md-4"><a href="<?= e($baseEquipoUrl . '/' . $equipoId . '/editar') ?>" class="btn btn-outline-primary w-100"><i class="fa-solid fa-pen-to-square me-1"></i> Editar Equipo</a></div>
        <div class="col-12 col-md-4"><button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#modalSwap"><i class="fa-solid fa-right-left me-1"></i> Realizar Swap</button></div>
        <div class="col-12 col-md-4"><a href="<?= e($baseEquipoUrl) ?>" class="btn btn-outline-secondary w-100"><i class="fa-solid fa-list me-1"></i> Volver a Equipos</a></div>
    </div>
</div>

<!-- ====================================================================
     MODAL SWAP
     ==================================================================== -->
<div class="modal fade" id="modalSwap" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content erp-modal border-0 shadow-lg" style="overflow: hidden;">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-right-left text-danger me-2"></i> Intercambio de Equipo</h5>
                    <div class="small text-muted">Saliendo: <strong><?= e($equipo['serie'] ?? $equipo['nro_serie'] ?? '#' . $equipoId) ?></strong></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>

            <form method="POST" action="<?= e($baseEquipoUrl . '/' . $equipoId . '/swap') ?>">
                <!-- Doble Token de Seguridad -->
                <input type="hidden" name="csrf_token" value="<?= e($csrf ?? '') ?>">
                <input type="hidden" name="_csrf" value="<?= e($csrf ?? '') ?>">

                <input type="hidden" name="saliente_id" value="<?= $equipoId ?>">
                <input type="hidden" name="cliente_id" value="<?= (int)($equipo['cliente_id'] ?? 0) ?>">

                <div class="modal-body">
                    <div class="alert alert-warning small mb-4"><i class="fa-solid fa-triangle-exclamation me-2"></i> El Swap cierra el contador del equipo saliente, lo desvincula del cliente y vincula el equipo entrante con sus contadores de apertura.</div>
                    
                    <div class="row g-4">
                        <div class="col-12 col-lg-6">
                            <div class="border rounded p-3 h-100 bg-light-subtle">
                                <h6 class="fw-bold mb-3 text-danger"><i class="fa-solid fa-arrow-right-from-bracket me-1"></i> Equipo Saliente</h6>
                                <div class="mb-3">
                                    <label class="form-label small">Modelo / Serie</label>
                                    <input type="text" class="form-control" value="<?= e(($equipo['marca'] ?? '') . ' ' . ($equipo['modelo'] ?? '') . ' - ' . ($equipo['serie'] ?? $equipo['nro_serie'] ?? 'S/N')) ?>" readonly>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-6"><label class="form-label small">Mono Final</label><input type="number" name="saliente_actual" class="form-control" value="<?= $contadorMono ?>" required></div>
                                    <div class="col-md-6"><label class="form-label small">Color Final</label><input type="number" name="saliente_actual_color" class="form-control" value="<?= $contadorColor ?>"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-lg-6">
                            <div class="border rounded p-3 h-100">
                                <h6 class="fw-bold mb-3 text-success"><i class="fa-solid fa-arrow-right-to-bracket me-1"></i> Equipo Entrante</h6>
                                <div class="mb-3">
                                    <label for="entrante_id" class="form-label small">Equipo de Reemplazo Disponible</label>
                                    <!-- Selector dinámico acoplado con botón "+" de redirección rápida -->
                                    <div class="input-group shadow-sm">
                                        <select name="entrante_id" id="entrante_id" class="form-select" required>
                                            <option value="">Seleccionar equipo de reemplazo...</option>
                                            <?php foreach (($equiposDisponibles ?? []) as $disponible): ?>
                                                <?php 
                                                $dispId = (int)($disponible['id'] ?? 0); 
                                                if ($dispId <= 0 || $dispId === $equipoId) {
                                                    continue; 
                                                }

                                                // Recuperar el modelo de forma defensiva contemplando su columna de base de datos
                                                $disponibleModelo = $disponible['nombre_modelo'] 
                                                    ?? $disponible['modelo_oficial'] 
                                                    ?? $disponible['modelo'] 
                                                    ?? '';
                                                ?>
                                                <option value="<?= $dispId ?>">
                                                    <?= e(trim(($disponible['marca'] ?? '') . ' ' . $disponibleModelo . ' - ' . ($disponible['serie'] ?? $disponible['nro_serie'] ?? 'S/N'))) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <a href="<?= base_url('/equipos/crear') ?>" 
                                           target="_blank" 
                                           class="btn btn-outline-secondary" 
                                           title="Registrar nuevo equipo en el taller (Nueva pestaña)">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-6"><label class="form-label small">Contador Mono Inicial</label><input type="number" name="entrante_actual" class="form-control" value="0" required></div>
                                    <div class="col-md-6"><label class="form-label small">Contador Color Inicial</label><input type="number" name="entrante_actual_color" class="form-control" value="0"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="motivo" class="form-label fw-semibold small">Motivo Técnico del Swap</label>
                            <textarea name="motivo" id="motivo" class="form-control" rows="3" required placeholder="Describa el motivo del cambio (Falla técnica, actualización de parque, fin de contrato, etc.)..."></textarea>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-right-left me-1"></i> Ejecutar Swap</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const swapForm = document.querySelector('#modalSwap form');
    if (swapForm) {
        swapForm.addEventListener('submit', function (event) {
            const entrante = document.querySelector('#entrante_id');
            const motivo = document.querySelector('#motivo');

            if (!entrante || !entrante.value) {
                event.preventDefault();
                alert('Seleccione el equipo entrante.');
                return;
            }

            if (!motivo || !motivo.value.trim()) {
                event.preventDefault();
                alert('Escriba el motivo técnico del Swap.');
                return;
            }

            const confirmar = window.confirm('¿Confirmar el intercambio? Esta operación desvinculará al equipo actual e instalará el nuevo equipo.');
            if (!confirmar) {
                event.preventDefault();
            }
        });
    }
});
</script>