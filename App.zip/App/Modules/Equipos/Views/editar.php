<?php
declare(strict_types=1);

$equipo      = $equipo ?? [];
$clientes    = $clientes ?? [];
$modelos     = $modelos ?? [];
$localidades = $localidades ?? [];
$csrf        = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2>
                <i class="fa-solid fa-pen-to-square text-warning me-2"></i>
                Editar Equipo #<?=e($equipo['id'] ?? '')?>
            </h2>
            <p class="text-muted mb-0">Actualización del parque instalado.</p>
        </div>
        <div>
            <a href="/equipos" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST" action="/equipos/<?=e($equipo['id'] ?? '')?>">

                <input type="hidden" name="csrf" value="<?=e($csrf)?>">

                <div class="row g-3">

                    <!-- CLIENTE -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Cliente asignado</label>
                        <select name="cliente_id" class="form-select">
                            <option value="">Taller General</option>
                            <?php foreach($clientes as $cli): ?>
                                <option value="<?=e($cli['id'] ?? '')?>" <?=($equipo['cliente_id'] ?? null) == ($cli['id'] ?? '') ? 'selected' : ''?>>
                                    <?=e($cli['nombre'] ?? '')?>
                                </option>
                            <?php endforeach;?>
                        </select>
                    </div>

                    <!-- MODELO -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Modelo</label>
                        <select name="modelo_id" class="form-select">
                            <option value="">Seleccione modelo</option>
                            <?php foreach($modelos as $modelo): ?>
                                <option value="<?=e($modelo['id'] ?? '')?>" <?=($equipo['modelo_id'] ?? null) == ($modelo['id'] ?? '') ? 'selected' : ''?>>
                                    <?=e($modelo['marca'] ?? '')?> - <?=e($modelo['nombre_modelo'] ?? '')?>
                                </option>
                            <?php endforeach;?>
                        </select>
                    </div>

                    <!-- CODIGO INTERNO -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Código interno</label>
                        <input type="text" name="codigo_interno" class="form-control" value="<?=e($equipo['codigo_interno'] ?? '')?>">
                    </div>

                    <!-- SERIE -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Número de Serie</label>
                        <input type="text" name="serie" class="form-control" required value="<?=e($equipo['serie'] ?? $equipo['nro_serie'] ?? '')?>">
                    </div>

                    <!-- PROPIEDAD -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Propiedad</label>
                        <?php $propiedad = (string)($equipo['propiedad'] ?? 'CSDI'); ?>
                        <select name="propiedad" class="form-select">
                            <option value="CSDI" <?=$propiedad === 'CSDI' ? 'selected' : ''?>>CSDI</option>
                            <option value="TNG" <?=$propiedad === 'TNG' ? 'selected' : ''?>>TNG</option>
                            <option value="Cliente" <?=$propiedad === 'Cliente' ? 'selected' : ''?>>Cliente</option>
                        </select>
                    </div>

                    <!-- LOCALIDAD -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Localidad</label>
                        <select name="localidad_id" class="form-select">
                            <option value="">Seleccione localidad</option>
                            <?php foreach($localidades as $loc): ?>
                                <option value="<?=e($loc['id'] ?? '')?>" <?=($equipo['localidad_id'] ?? null) == ($loc['id'] ?? '') ? 'selected' : ''?>>
                                    <?=e($loc['nombre'] ?? '')?>
                                </option>
                            <?php endforeach;?>
                        </select>
                    </div>

                    <!-- DIRECCIÓN DEL EQUIPO -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Dirección del Equipo</label>
                        <input type="text" name="direccion_equipo" class="form-control" placeholder="Calle, número, piso, sector..." value="<?=e($equipo['direccion_equipo'] ?? '')?>">
                    </div>

                    <!-- ESTADO -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Estado</label>
                        <?php $estado = (string)($equipo['estado'] ?? 'Activo'); ?>
                        <select name="estado" class="form-select">
                            <option value="Activo" <?=$estado === 'Activo' ? 'selected' : ''?>>Activo</option>
                            <option value="Disponible" <?=$estado === 'Disponible' ? 'selected' : ''?>>Disponible</option>
                            <option value="En reparación" <?=$estado === 'En reparación' ? 'selected' : ''?>>En reparación</option>
                            <option value="Baja" <?=$estado === 'Baja' ? 'selected' : ''?>>Baja</option>
                        </select>
                    </div>

                    <!-- OBSERVACIONES -->
                    <div class="col-12">
                        <label class="form-label fw-bold">Observaciones</label>
                        <textarea name="observaciones" class="form-control" rows="4"><?=e($equipo['observaciones'] ?? '')?></textarea>
                    </div>

                    <div class="col-12 text-end mt-4">
                        <button type="submit" class="btn btn-warning px-4">
                            <i class="fa-solid fa-save me-1"></i> Actualizar Equipo
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>