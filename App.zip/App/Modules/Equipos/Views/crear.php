<?php
declare(strict_types=1);

$clientes = $clientes ?? [];
$modelos  = $modelos ?? [];
$csrf     = $csrf ?? '';

if (!function_exists('e')) {

    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }

}

?>


<div class="container-fluid">


<div class="d-flex justify-content-between align-items-center mb-4">


<div>

<h2>

<i class="fa-solid fa-print text-primary me-2"></i>

Nuevo Equipo

</h2>


<p class="text-muted mb-0">

Alta de equipo en parque CSDI ERP.

</p>


</div>


<a href="/equipos"
class="btn btn-secondary">

<i class="fa-solid fa-arrow-left"></i>

Volver

</a>


</div>





<div class="card shadow-sm">


<div class="card-body">


<form method="POST"
action="/equipos/guardar">



<input type="hidden"
name="csrf"
value="<?=e($csrf)?>">





<div class="row g-3">





<!-- CLIENTE -->

<div class="col-md-6">


<label class="form-label fw-bold">

Cliente asignado

</label>


<select name="cliente_id"
class="form-select">


<option value="">

Taller General

</option>


<?php foreach($clientes as $cli): ?>


<option value="<?=e($cli['id'])?>">

<?=e($cli['nombre'])?>

</option>


<?php endforeach;?>


</select>


</div>








<!-- MODELO -->

<div class="col-md-6">


<label class="form-label fw-bold">

Modelo

</label>


<select name="modelo_id"
class="form-select"
required>


<option value="">

Seleccione modelo

</option>



<?php foreach($modelos as $modelo): ?>


<option value="<?=e($modelo['id'])?>">


<?=e($modelo['marca'] ?? '')?>

-

<?=e($modelo['nombre_modelo'])?>


</option>


<?php endforeach;?>


</select>


</div>








<!-- CODIGO -->

<div class="col-md-4">


<label class="form-label fw-bold">

Código interno

</label>


<input type="text"

name="codigo_interno"

class="form-control"

placeholder="Ej: EQ-0001">


</div>








<!-- SERIE -->

<div class="col-md-4">


<label class="form-label fw-bold">

Número de Serie

</label>


<input type="text"

name="serie"

class="form-control"

placeholder="Serie del fabricante">


</div>








<!-- PROPIEDAD -->

<div class="col-md-4">


<label class="form-label fw-bold">

Propiedad

</label>



<select name="propiedad"

class="form-select">


<option value="CSDI">

CSDI

</option>


<option value="TNG">

TNG

</option>


<option value="Cliente">

Cliente

</option>



</select>


</div>








<!-- UBICACION -->

<div class="col-md-6">


<label class="form-label fw-bold">

Ubicación

</label>


<input type="text"

name="ubicacion"

class="form-control"

placeholder="Sucursal / sector">


</div>








<!-- ESTADO -->

<div class="col-md-6">


<label class="form-label fw-bold">

Estado

</label>


<select name="estado"

class="form-select">


<option value="Activo">

Activo

</option>


<option value="En reparación">

En reparación

</option>


<option value="Baja">

Baja

</option>


</select>


</div>








<!-- OBSERVACIONES -->

<div class="col-12">


<label class="form-label fw-bold">

Observaciones

</label>


<textarea

name="observaciones"

class="form-control"

rows="4"></textarea>


</div>








<div class="col-12 text-end mt-4">


<button class="btn btn-primary px-4">


<i class="fa-solid fa-save"></i>

Guardar Equipo


</button>


</div>



</div>



</form>



</div>


</div>


</div>