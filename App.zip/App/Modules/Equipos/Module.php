<?php

declare(strict_types=1);

namespace App\Modules\Equipos;

use App\Core\Module as CoreModule;


final class Module extends CoreModule
{


    public function name(): string
    {
        return 'Equipos';
    }



    public function priority(): int
    {
        return 20;
    }



    public function routes(): string
    {
        return __DIR__.'/Config/routes.php';
    }





    public function menu(): array
    {
        return [

            [

                'title'=>'Equipos',

                'icon'=>'fa-solid fa-print',

                'url'=>'/equipos',

                'order'=>20

            ]

        ];
    }





    public function permissions(): array
    {
        return [

            'equipos.view',

            'equipos.create',

            'equipos.edit',

            'equipos.delete'

        ];
    }





    public function boot(): void
    {

    }


}