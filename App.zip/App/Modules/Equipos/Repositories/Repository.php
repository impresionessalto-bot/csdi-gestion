<?php

declare(strict_types=1);

namespace App\Modules\Equipos\Repositories;

use PDO;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    public function listar(array $filtros = []): array
    {
        $sql = "
            SELECT
                e.*,
                c.nombre AS cliente_nombre,
                m.nombre_modelo AS modelo_oficial,
                m.marca,
                m.tipo AS modelo_tipo,
                l.nombre AS localidad_nombre

            FROM equipos e

            LEFT JOIN clientes c
                ON c.id = e.cliente_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            LEFT JOIN localidades l
                ON l.id = e.localidad_id

            WHERE e.deleted_at IS NULL
        ";

        $params = [];

        $texto = trim((string)($filtros['texto'] ?? ''));
        if ($texto !== '') {
            $sql .= "
                AND (
                    m.nombre_modelo LIKE ?
                    OR m.marca LIKE ?
                    OR e.codigo_interno LIKE ?
                    OR e.serie LIKE ?
                    OR l.nombre LIKE ?
                    OR e.direccion_equipo LIKE ?
                    OR c.nombre LIKE ?
                )
            ";
            $buscar = '%' . $texto . '%';
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
        }

        $clienteId = (int)($filtros['cliente_id'] ?? 0);
        if ($clienteId > 0) {
            $sql .= " AND e.cliente_id = ? ";
            $params[] = $clienteId;
        }

        // Filtro por Localidad
        $localidadId = (int)($filtros['localidad_id'] ?? 0);
        if ($localidadId > 0) {
            $sql .= " AND e.localidad_id = ? ";
            $params[] = $localidadId;
        }

        $propiedad = trim((string)($filtros['propiedad'] ?? ''));
        if ($propiedad !== '') {
            $sql .= " AND e.propiedad = ? ";
            $params[] = $propiedad;
        }

        $estado = trim((string)($filtros['estado'] ?? ''));
        if ($estado !== '') {
            $sql .= " AND e.estado = ? ";
            $params[] = $estado;
        }

        $sql .= " ORDER BY e.id DESC ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function find(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        $stmt = $this->db->prepare("
            SELECT
                e.*,
                c.nombre AS cliente_nombre,
                m.nombre_modelo AS modelo_oficial,
                m.marca,
                m.tipo AS modelo_tipo,
                l.nombre AS localidad_nombre

            FROM equipos e

            LEFT JOIN clientes c
                ON c.id = e.cliente_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            LEFT JOIN localidades l
                ON l.id = e.localidad_id

            WHERE e.id = ?
              AND e.deleted_at IS NULL

            LIMIT 1
        ");

        $stmt->execute([$id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

        return $resultado ?: null;
    }

    public function crear(array $data): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO equipos
            (
                cliente_id,
                modelo_id,
                codigo_interno,
                serie,
                propiedad,
                localidad_id,
                direccion_equipo,
                estado,
                observaciones
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        ");

        $stmt->execute([
            $data['cliente_id'] ?? null,
            $data['modelo_id'] ?? null,
            $data['codigo_interno'] ?? '',
            $data['serie'] ?? '',
            $data['propiedad'] ?? 'CSDI',
            $data['localidad_id'] ?? null,
            $data['direccion_equipo'] ?? null,
            $data['estado'] ?? 'Activo',
            $data['observaciones'] ?? '',
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function actualizar(int $id, array $data): void
    {
        if ($id <= 0) {
            return;
        }

        $stmt = $this->db->prepare("
            UPDATE equipos
            SET
                cliente_id = ?,
                modelo_id = ?,
                codigo_interno = ?,
                serie = ?,
                propiedad = ?,
                localidad_id = ?,
                direccion_equipo = ?,
                estado = ?,
                observaciones = ?

            WHERE id = ?
        ");

        $stmt->execute([
            $data['cliente_id'] ?? null,
            $data['modelo_id'] ?? null,
            $data['codigo_interno'] ?? '',
            $data['serie'] ?? '',
            $data['propiedad'] ?? 'CSDI',
            $data['localidad_id'] ?? null,
            $data['direccion_equipo'] ?? null,
            $data['estado'] ?? 'Activo',
            $data['observaciones'] ?? '',
            $id,
        ]);
    }

    public function delete(int $id): void
    {
        if ($id <= 0) {
            return;
        }

        $stmt = $this->db->prepare("
            UPDATE equipos
            SET deleted_at = NOW()
            WHERE id = ?
        ");

        $stmt->execute([$id]);
    }

    public function obtenerClientes(): array
    {
        $stmt = $this->db->query("
            SELECT id, nombre
            FROM clientes
            WHERE activo = 1
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function obtenerLocalidades(): array
    {
        $stmt = $this->db->query("
            SELECT id, nombre
            FROM localidades
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function obtenerModelos(): array
    {
        $stmt = $this->db->query("
            SELECT id, nombre_modelo, marca, tipo
            FROM modelos_equipos
            WHERE activo = 1
            ORDER BY nombre_modelo ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function obtenerEstadisticas(): array
    {
        $stmt = $this->db->query("
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN estado = 'Activo' THEN 1 ELSE 0 END) AS activos,
                SUM(CASE WHEN propiedad = 'TNG' THEN 1 ELSE 0 END) AS tng,
                SUM(CASE WHEN estado = 'En reparación' THEN 1 ELSE 0 END) AS taller
            FROM equipos
            WHERE deleted_at IS NULL
        ");

        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        return [
            'total'   => (int)($row['total'] ?? 0),
            'activos' => (int)($row['activos'] ?? 0),
            'tng'     => (int)($row['tng'] ?? 0),
            'taller'  => (int)($row['taller'] ?? 0),
        ];
    }

    public function exportar(array $filtros = []): array
    {
        $sql = "
            SELECT
                COALESCE(l.nombre, 'Sin localidad') AS localidad,
                c.nombre AS cliente,
                e.id AS equipo_id,
                e.codigo_interno,
                e.serie,
                e.propiedad,
                e.direccion_equipo,
                e.estado,
                m.marca,
                m.nombre_modelo,
                m.tipo AS modelo_tipo,
                r.periodo_mes,
                r.periodo_anio,
                r.fecha,
                COALESCE(r.contador_anterior, 0) AS contador_anterior,
                COALESCE(r.contador_actual, 0) AS contador_actual,
                COALESCE(r.copias, 0) AS copias,
                COALESCE(r.contador_anterior_color, 0) AS contador_anterior_color,
                COALESCE(r.contador_actual_color, 0) AS contador_actual_color,
                COALESCE(r.copias_color, 0) AS copias_color

            FROM equipos e

            LEFT JOIN clientes c
                ON c.id = e.cliente_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            LEFT JOIN localidades l
                ON l.id = e.localidad_id

            LEFT JOIN registros r
                ON r.id = (
                    SELECT r2.id
                    FROM registros r2
                    WHERE r2.equipo_id = e.id
        ";

        $params = [];

        $periodoMes = (int)($filtros['periodo_mes'] ?? 0);
        $periodoAnio = (int)($filtros['periodo_anio'] ?? 0);

        if ($periodoMes > 0 && $periodoAnio > 0) {
            $sql .= " AND r2.periodo_mes = ? AND r2.periodo_anio = ? ";
            $params[] = $periodoMes;
            $params[] = $periodoAnio;
        }

        $sql .= "
                    ORDER BY r2.fecha DESC, r2.id DESC
                    LIMIT 1
                )

            WHERE e.deleted_at IS NULL
        ";

        $texto = trim((string)($filtros['texto'] ?? ''));
        if ($texto !== '') {
            $sql .= "
                AND (
                    c.nombre LIKE ?
                    OR l.nombre LIKE ?
                    OR e.codigo_interno LIKE ?
                    OR e.serie LIKE ?
                    OR e.direccion_equipo LIKE ?
                    OR m.nombre_modelo LIKE ?
                    OR m.marca LIKE ?
                )
            ";
            $buscar = '%' . $texto . '%';
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
            $params[] = $buscar;
        }

        $clienteId = (int)($filtros['cliente_id'] ?? 0);
        if ($clienteId > 0) {
            $sql .= " AND e.cliente_id = ? ";
            $params[] = $clienteId;
        }

        $localidadId = (int)($filtros['localidad_id'] ?? 0);
        if ($localidadId > 0) {
            $sql .= " AND e.localidad_id = ? ";
            $params[] = $localidadId;
        }

        $propiedad = trim((string)($filtros['propiedad'] ?? ''));
        if ($propiedad !== '') {
            $sql .= " AND e.propiedad = ? ";
            $params[] = $propiedad;
        }

        $estado = trim((string)($filtros['estado'] ?? ''));
        if ($estado !== '') {
            $sql .= " AND e.estado = ? ";
            $params[] = $estado;
        }

        $sql .= "
            ORDER BY
                l.nombre ASC,
                c.nombre ASC,
                e.codigo_interno ASC
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function datosExportacion(array $filtros = []): array
    {
        $equipos = $this->exportar($filtros);
        $datos = [];

        foreach ($equipos as $equipo) {
            $periodoMes = $equipo['periodo_mes'] ?? '';
            $periodoAnio = $equipo['periodo_anio'] ?? '';
            $periodo = '';

            if ($periodoMes !== '' || $periodoAnio !== '') {
                $periodo = str_pad((string)$periodoMes, 2, '0', STR_PAD_LEFT) . '/' . $periodoAnio;
            }

            $datos[] = [
                'Localidad'               => $equipo['localidad'] ?? '',
                'Cliente'                 => $equipo['cliente'] ?? '',
                'Dirección'               => $equipo['direccion_equipo'] ?? '',
                'Código'                  => $equipo['codigo_interno'] ?? '',
                'Marca'                   => $equipo['marca'] ?? '',
                'Modelo'                  => $equipo['nombre_modelo'] ?? '',
                'Tipo'                    => $equipo['modelo_tipo'] ?? '',
                'Serie'                   => $equipo['serie'] ?? '',
                'Propiedad'               => $equipo['propiedad'] ?? '',
                'Estado'                  => $equipo['estado'] ?? '',
                'Período'                 => $periodo,
                'Contador mono anterior'  => (int)($equipo['contador_anterior'] ?? 0),
                'Contador mono actual'    => (int)($equipo['contador_actual'] ?? 0),
                'Copias mono'             => (int)($equipo['copias'] ?? 0),
                'Contador color anterior' => (int)($equipo['contador_anterior_color'] ?? 0),
                'Contador color actual'   => (int)($equipo['contador_actual_color'] ?? 0),
                'Copias color'            => (int)($equipo['copias_color'] ?? 0),
            ];
        }

        return $datos;
    }

    public function resumenExportacion(array $filtros = []): array
    {
        $datos = $this->exportar($filtros);
        $resumen = [];

        foreach ($datos as $equipo) {
            $localidad = (string)($equipo['localidad'] ?? 'SIN LOCALIDAD');
            $cliente   = (string)($equipo['cliente'] ?? 'SIN CLIENTE');
            $clave     = $localidad . '|' . $cliente;

            if (!isset($resumen[$clave])) {
                $resumen[$clave] = [
                    'Localidad'    => $localidad,
                    'Cliente'      => $cliente,
                    'Equipos'      => 0,
                    'Copias mono'  => 0,
                    'Copias color' => 0,
                    'Total copias' => 0,
                ];
            }

            $copiasMono = (int)($equipo['copias'] ?? 0);
            $copiasColor = (int)($equipo['copias_color'] ?? 0);

            $resumen[$clave]['Equipos']++;
            $resumen[$clave]['Copias mono']  += $copiasMono;
            $resumen[$clave]['Copias color'] += $copiasColor;
            $resumen[$clave]['Total copias'] += $copiasMono + $copiasColor;
        }

        return array_values($resumen);
    }

    public function metricas(int $id): array
    {
        if ($id <= 0) {
            return [];
        }

        return [
            'copias_totales' => 0,
            'copias_mes'     => 0,
            'fallas'         => 0,
            'mantenimientos' => 0,
            'rentabilidad'   => 0,
            'disponibilidad' => 100,
        ];
    }

    public function widgets(int $id): array
    {
        if ($id <= 0) {
            return [];
        }

        return [
            'contador' => [
                'actual'   => 0,
                'anterior' => 0,
                'consumo'  => 0,
            ],
            'consumo' => [
                'toner'     => 0,
                'repuestos' => 0,
            ],
            'fallas' => [
                'cantidad' => 0,
                'ultima'   => null,
            ],
            'rentabilidad' => [
                'ingresos' => 0,
                'costos'   => 0,
                'margen'   => 0,
            ],
            'historial' => [],
        ];
    }
}