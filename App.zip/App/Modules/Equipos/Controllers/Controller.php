<?php

declare(strict_types=1);

namespace App\Modules\Equipos\Controllers;

use App\Core\BaseController;
use App\Modules\Equipos\Services\Service;
use App\Services\Export\ExcelService;
use App\Services\Export\PdfService;
use App\Services\Swap\SwapService;
use RuntimeException;
use Throwable;

final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service,
        private readonly SwapService $swapService
    ) {
        parent::__construct();
    }

    private function loadAssets(): void
    {
        $this->assets()->addModule('Equipos');
    }

    private function obtenerFiltros(): array
    {
        return [
            'texto'        => trim((string)($_GET['texto'] ?? '')),
            'estado'       => trim((string)($_GET['estado'] ?? '')),
            'propiedad'    => trim((string)($_GET['propiedad'] ?? '')),
            'cliente_id'   => (int)($_GET['cliente_id'] ?? 0),
            'localidad_id' => (int)($_GET['localidad_id'] ?? 0),
        ];
    }

    public function index(): void
    {
        $this->requireAuth();

        try {
            $this->loadAssets();
            $filtros = $this->obtenerFiltros();

            $this->moduleView('Equipos', 'index', [
                'titulo'      => 'Gestión de Equipos',
                'equipos'     => $this->service->listar($filtros),
                'stats'       => $this->service->obtenerEstadisticas(),
                'filtros'     => $filtros,
                'clientes'    => $this->service->obtenerClientes(),
                'localidades' => $this->service->obtenerLocalidades(),
                'csrf'        => $this->csrf(),
            ]);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function exportarPdf(): void
    {
        $this->requireAuth();

        try {
            $filtros = $this->obtenerFiltros();
            $equipos = $this->service->listar($filtros);

            $datosPdf = [];
            foreach ($equipos as $row) {
                $datosPdf[] = [
                    'ID'        => (int)($row['id'] ?? 0),
                    'Código'    => (string)($row['codigo_interno'] ?? ''),
                    'Modelo'    => (string)($row['modelo_oficial'] ?? 'Sin modelo'),
                    'Marca'     => (string)($row['marca'] ?? ''),
                    'Cliente'   => (string)($row['cliente_nombre'] ?? 'Taller General'),
                    'Localidad' => (string)($row['localidad_nombre'] ?? 'Sin localidad'),
                    'Dirección' => (string)($row['direccion_equipo'] ?? '-'),
                    'Serie'     => (string)($row['serie'] ?? 'S/N'),
                    'Propiedad' => (string)($row['propiedad'] ?? 'CSDI'),
                    'Estado'    => (string)($row['estado'] ?? ''),
                ];
            }

            $pdf = new PdfService();
            $archivo = $pdf->generar('Reporte de Equipos', $datosPdf);
            $pdf->descargar($archivo);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function exportarExcel(): void
    {
        $this->requireAuth();

        try {
            $filtros = $this->obtenerFiltros();
            $equipos = $this->service->listar($filtros);

            $datosExcel = [];
            foreach ($equipos as $row) {
                $datosExcel[] = [
                    'ID'        => (int)($row['id'] ?? 0),
                    'Código'    => (string)($row['codigo_interno'] ?? ''),
                    'Modelo'    => (string)($row['modelo_oficial'] ?? 'Sin modelo'),
                    'Marca'     => (string)($row['marca'] ?? ''),
                    'Cliente'   => (string)($row['cliente_nombre'] ?? 'Taller General'),
                    'Localidad' => (string)($row['localidad_nombre'] ?? 'Sin localidad'),
                    'Dirección' => (string)($row['direccion_equipo'] ?? '-'),
                    'Serie'     => (string)($row['serie'] ?? 'S/N'),
                    'Propiedad' => (string)($row['propiedad'] ?? 'CSDI'),
                    'Estado'    => (string)($row['estado'] ?? ''),
                ];
            }

            $excel = new ExcelService();
            $excel->download(
                $datosExcel,
                'reporte_equipos_' . date('Ymd_His') . '.csv'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function create(): void
    {
        $this->requireAuth();

        try {
            $this->loadAssets();

            $this->moduleView('Equipos', 'nuevo', [
                'titulo'      => 'Registrar Nuevo Equipo',
                'clientes'    => $this->service->obtenerClientes(),
                'modelos'     => $this->service->obtenerModelos(),
                'localidades' => $this->service->obtenerLocalidades(),
                'csrf'        => $this->csrf(),
            ]);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function store(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf();

            $id = $this->service->crear($_POST);

            if ($id <= 0) {
                throw new RuntimeException('No se pudo obtener el ID del equipo creado.');
            }

            $this->redirect('/equipos/' . $id);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function show(mixed $id = null): void
    {
        $this->requireAuth();

        $idInt = is_numeric($id) ? (int)$id : 0;
        if ($idInt <= 0) {
            $this->redirect('/equipos');
            return;
        }

        try {
            $this->loadAssets();

            $equipo = $this->service->find($idInt);
            if ($equipo === null) {
                throw new RuntimeException('Equipo inexistente.');
            }

            $equiposDisponibles = $this->service->listar([
                'estado' => 'Disponible',
            ]);

            $this->moduleView('Equipos', 'ver', [
                'titulo'             => 'Detalle de Equipo',
                'equipo'             => $equipo,
                'equiposDisponibles' => $equiposDisponibles,
                'metricas'           => $this->service->metricas($idInt),
                'widgets'            => $this->service->widgets($idInt),
                'csrf'               => $this->csrf(),
            ]);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function edit(mixed $id = null): void
    {
        $this->requireAuth();

        $idInt = is_numeric($id) ? (int)$id : 0;
        if ($idInt <= 0) {
            $this->redirect('/equipos');
            return;
        }

        try {
            $this->loadAssets();

            $equipo = $this->service->find($idInt);
            if ($equipo === null) {
                throw new RuntimeException('Equipo inexistente.');
            }

            $this->moduleView('Equipos', 'editar', [
                'titulo'      => 'Editar Equipo #' . $idInt,
                'equipo'      => $equipo,
                'clientes'    => $this->service->obtenerClientes(),
                'modelos'     => $this->service->obtenerModelos(),
                'localidades' => $this->service->obtenerLocalidades(),
                'csrf'        => $this->csrf(),
            ]);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function update(mixed $id = null): void
    {
        $this->requireAuth();

        $idInt = is_numeric($id) ? (int)$id : 0;
        if ($idInt <= 0) {
            $this->redirect('/equipos');
            return;
        }

        try {
            $this->validateCsrf();

            $this->service->actualizar($idInt, $_POST);

            $this->redirect('/equipos/' . $idInt);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function swap(mixed $id = null): void
    {
        $this->requireAuth();

        $idInt = is_numeric($id) ? (int)$id : 0;
        if ($idInt <= 0) {
            $this->redirect('/equipos');
            return;
        }

        try {
            $this->validateCsrf();

            $nuevoId = $this->swapService->ejecutar($idInt, $_POST);
            $redireccionId = $nuevoId > 0 ? $nuevoId : $idInt;

            $this->redirect('/equipos/' . $redireccionId);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function destroy(mixed $id = null): void
    {
        $this->requireAuth();

        $idInt = is_numeric($id) ? (int)$id : 0;
        if ($idInt <= 0) {
            $this->redirect('/equipos');
            return;
        }

        try {
            $this->validateCsrf();

            $this->service->delete($idInt);

            $this->redirect('/equipos');
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }
}