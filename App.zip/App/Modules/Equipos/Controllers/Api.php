<?php

declare(strict_types=1);

namespace App\Modules\Equipos\Controllers;

use App\Core\BaseController;
use App\Modules\Equipos\Services\Service;
use Throwable;
use RuntimeException;

/**
 * ============================================================================
 * CSDI ERP PRO
 *
 * EQUIPOS - API CONTROLLER
 *
 * API central del módulo Equipos.
 *
 * Responsabilidades:
 *
 * - Listado AJAX
 * - Búsqueda
 * - Obtener equipo
 * - Crear
 * - Actualizar
 * - Eliminar
 * - Clientes
 * - Modelos
 * - Equipos TNG
 * - Estadísticas
 * - Dashboard
 * - KPIs
 * - Métricas individuales
 * - Widgets individuales
 *
 * IMPORTANTE:
 *
 * CSDI y TNG se mantienen conceptualmente separados.
 *
 * CSDI:
 *   cliente_id
 *   localidad
 *   equipo
 *   serie
 *
 * TNG:
 *   codigo_tng
 *   numero_informe
 *
 * La integración completa de la ficha 360° se realizará
 * en el Service/Repository sin mezclar las claves de ambos sistemas.
 *
 * ============================================================================
 */
final class Api extends BaseController
{
    /**
     * =========================================================================
     * CONSTRUCTOR
     * =========================================================================
     */
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }


    /**
     * =========================================================================
     * LISTADO
     *
     * GET /equipos/api/listado
     *
     * Parámetros:
     *
     * texto
     * marca
     * estado
     * cliente_id
     *
     * =========================================================================
     */
    public function listado(): void
    {
        $this->requireAuth();

        try {

            $filtros = [
                'texto' => trim(
                    (string)($_GET['texto'] ?? '')
                ),

                'marca' => trim(
                    (string)($_GET['marca'] ?? '')
                ),

                'estado' => trim(
                    (string)($_GET['estado'] ?? '')
                ),

                'cliente_id' => isset($_GET['cliente_id'])
                    ? (int)$_GET['cliente_id']
                    : 0,
            ];


            $equipos =
                $this->service->listar(
                    $filtros
                );


            $this->success(
                $equipos,
                'Equipos obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * BUSCAR
     *
     * Endpoint pensado para el buscador AJAX.
     *
     * GET /equipos/api/buscar?q=ricoh
     *
     * =========================================================================
     */
    public function buscar(): void
    {
        $this->requireAuth();

        try {

            $texto =
                trim(
                    (string)(
                        $_GET['q']
                        ??
                        $_GET['texto']
                        ??
                        ''
                    )
                );


            $filtros = [
                'texto' => $texto,

                'marca' => trim(
                    (string)(
                        $_GET['marca']
                        ??
                        ''
                    )
                ),

                'estado' => trim(
                    (string)(
                        $_GET['estado']
                        ??
                        ''
                    )
                ),

                'cliente_id' => isset(
                    $_GET['cliente_id']
                )
                    ? (int)$_GET['cliente_id']
                    : 0,
            ];


            $equipos =
                $this->service->listar(
                    $filtros
                );


            $this->success(
                $equipos,
                'Búsqueda realizada correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * OBTENER EQUIPO
     *
     * GET /equipos/api/{id}
     *
     * =========================================================================
     */
    public function obtener(
        int $id
    ): void {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Equipo inválido'
                );
            }


            $equipo =
                $this->service->find(
                    $id
                );


            if (!$equipo) {

                $this->notFound(
                    'Equipo no encontrado'
                );
            }


            $this->success(
                $equipo,
                'Equipo obtenido correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * CREAR EQUIPO
     *
     * POST /equipos/api
     *
     * =========================================================================
     */
    public function guardar(): void
    {
        $this->requireAuth();

        try {

            if (!$this->validateCsrf()) {

                $this->forbidden(
                    'Token CSRF inválido o ausente.'
                );
            }


            $data =
                $this->request->body();


            if (!is_array($data)) {

                $data = [];
            }


            /*
             * Compatibilidad defensiva con formularios
             * tradicionales.
             */
            if (!$data) {

                $data = $_POST;
            }


            $numeroSerie =
                trim(
                    (string)(
                        $data['numero_serie']
                        ??
                        $data['serie']
                        ??
                        ''
                    )
                );


            if ($numeroSerie === '') {

                $this->validation([
                    'numero_serie' =>
                        'El número de serie del equipo es obligatorio.'
                ]);
            }


            $id =
                $this->service->crear(
                    $data
                );


            /*
             * El Service actual que me pasaste
             * todavía declara crear() como void.
             *
             * Por eso intentamos utilizar el ID si
             * el método posteriormente es actualizado
             * para devolverlo.
             */
            if (
                is_int($id)
                ||
                ctype_digit((string)$id)
            ) {

                $id = (int)$id;

            } else {

                $id = 0;
            }


            $this->created(
                [
                    'id' => $id
                ],
                'Equipo creado correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * ACTUALIZAR EQUIPO
     *
     * PUT/PATCH /equipos/api/{id}
     *
     * =========================================================================
     */
    public function actualizar(
        int $id
    ): void {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Equipo inválido'
                );
            }


            if (!$this->validateCsrf()) {

                $this->forbidden(
                    'Token CSRF inválido o ausente.'
                );
            }


            $equipo =
                $this->service->find(
                    $id
                );


            if (!$equipo) {

                $this->notFound(
                    'Equipo no encontrado'
                );
            }


            $data =
                $this->request->body();


            if (!is_array($data)) {

                $data = [];
            }


            if (!$data) {

                $data = $_POST;
            }


            $this->service->actualizar(
                $id,
                $data
            );


            $actualizado =
                $this->service->find(
                    $id
                );


            $this->success(
                $actualizado,
                'Equipo actualizado correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * ELIMINAR
     *
     * DELETE /equipos/api/{id}
     *
     * =========================================================================
     */
    public function eliminar(
        int $id
    ): void {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Equipo inválido'
                );
            }


            if (!$this->validateCsrf()) {

                $this->forbidden(
                    'Token CSRF inválido o ausente.'
                );
            }


            $equipo =
                $this->service->find(
                    $id
                );


            if (!$equipo) {

                $this->notFound(
                    'Equipo no encontrado'
                );
            }


            $this->service->delete(
                $id
            );


            $this->success(
                [
                    'id' => $id
                ],
                'Equipo eliminado correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * CLIENTES
     *
     * Para selects y filtros CSDI.
     *
     * =========================================================================
     */
    public function clientes(): void
    {
        $this->requireAuth();

        try {

            $clientes =
                $this->service->obtenerClientes();


            $this->success(
                $clientes,
                'Clientes obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * MODELOS
     *
     * Para selects de equipos.
     *
     * =========================================================================
     */
    public function modelos(): void
    {
        $this->requireAuth();

        try {

            $modelos =
                $this->service->obtenerModelos();


            $this->success(
                $modelos,
                'Modelos obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * EQUIPOS TNG
     *
     * Mantiene separado el universo TNG.
     *
     * El Repository/Service debe devolver:
     *
     * - codigo TNG
     * - numero informe
     * - demás información propia de TNG
     *
     * =========================================================================
     */
    public function tng(): void
    {
        $this->requireAuth();

        try {

            $equipos =
                $this->service->listarEquiposTng();


            $this->success(
                $equipos,
                'Equipos TNG obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * ESTADÍSTICAS
     *
     * =========================================================================
     */
    public function estadisticas(): void
    {
        $this->requireAuth();

        try {

            $stats =
                $this->service->obtenerEstadisticas();


            $this->success(
                $stats,
                'Estadísticas obtenidas correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * DASHBOARD
     *
     * =========================================================================
     */
    public function dashboard(): void
    {
        $this->requireAuth();

        try {

            $dashboard =
                $this->service->dashboard();


            $this->success(
                $dashboard,
                'Dashboard obtenido correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * KPI - ACTIVOS
     * =========================================================================
     */
    public function activos(): void
    {
        $this->requireAuth();

        try {

            $total =
                $this->service->activos();


            $this->success(
                [
                    'total' => $total
                ],
                'Equipos activos obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * KPI - EN SERVICIO
     * =========================================================================
    */
    public function enServicio(): void
    {
        $this->requireAuth();

        try {

            $total =
                $this->service->enServicio();


            $this->success(
                [
                    'total' => $total
                ],
                'Equipos en servicio obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * KPI - FUERA DE SERVICIO
     * =========================================================================
     */
    public function fueraServicio(): void
    {
        $this->requireAuth();

        try {

            $total =
                $this->service->fueraServicio();


            $this->success(
                [
                    'total' => $total
                ],
                'Equipos fuera de servicio obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * KPI - PENDIENTES
     * =========================================================================
     */
    public function pendientes(): void
    {
        $this->requireAuth();

        try {

            $total =
                $this->service->pendientes();


            $this->success(
                [
                    'total' => $total
                ],
                'Equipos pendientes obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * MÉTRICAS DE UN EQUIPO
     *
     * =========================================================================
     */
    public function metricas(
        int $id
    ): void {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Equipo inválido'
                );
            }


            $equipo =
                $this->service->find(
                    $id
                );


            if (!$equipo) {

                $this->notFound(
                    'Equipo no encontrado'
                );
            }


            $metricas =
                $this->service->metricas(
                    $id
                );


            $this->success(
                $metricas,
                'Métricas obtenidas correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * WIDGETS DE UN EQUIPO
     *
     * =========================================================================
     */
    public function widgets(
        int $id
    ): void {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Equipo inválido'
                );
            }


            $equipo =
                $this->service->find(
                    $id
                );


            if (!$equipo) {

                $this->notFound(
                    'Equipo no encontrado'
                );
            }


            $widgets =
                $this->service->widgets(
                    $id
                );


            $this->success(
                $widgets,
                'Widgets obtenidos correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * FICHA 360°
     *
     * =========================================================================
     *
     * Este endpoint deja preparado el contrato para integrar
     * posteriormente CSDI + TNG en una misma respuesta.
     *
     * Actualmente utiliza los métodos existentes del Service.
     *
     * =========================================================================
     */
    public function ficha(
        int $id
    ): void {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Equipo inválido'
                );
            }


            $equipo =
                $this->service->find(
                    $id
                );


            if (!$equipo) {

                $this->notFound(
                    'Equipo no encontrado'
                );
            }


            $metricas =
                $this->service->metricas(
                    $id
                );


            $widgets =
                $this->service->widgets(
                    $id
                );


            $this->success(
                [
                    'equipo'   => $equipo,

                    'metricas' => $metricas,

                    'widgets'  => $widgets,
                ],
                'Ficha 360° obtenida correctamente'
            );

        } catch (Throwable $e) {

            $this->fail(
                $e
            );
        }
    }


    /**
     * =========================================================================
     * HEALTH CHECK
     *
     * Endpoint sencillo para comprobar que la API está viva.
     *
     * =========================================================================
     */
    public function health(): void
    {
        $this->requireAuth();

        $this->success(
            [
                'module' => 'Equipos',
                'status' => 'ok',
                'time'   => date('Y-m-d H:i:s'),
            ],
            'API Equipos funcionando correctamente'
        );
    }
}