<?php
declare(strict_types=1);

/**
 * Vista de Listado y Gestión de Clientes (Con Filtro Combinado HOT y Protección CSS)
 * 
 * @var array $clientes
 * @var array $localidades
 * @var array $tarifas
 * @var array $stats
 */

// Normalización y valores por defecto seguros
$clientes    = is_array($clientes ?? null) ? $clientes : [];
$localidades = is_array($localidades ?? null) ? $localidades : [];
$tarifas     = is_array($tarifas ?? null) ? $tarifas : [];

$stats = array_merge([
    'total'     => 0,
    'activos'   => 0,
    'inactivos' => 0
], is_array($stats ?? null) ? $stats : []);

// Sanitización de parámetros GET
$textoFiltro     = trim((string)($_GET['texto'] ?? ''));
$localidadFiltro = (int)($_GET['localidad_id'] ?? 0);
$tarifaFiltro    = (int)($_GET['tarifa_id'] ?? 0);
$activoFiltro    = (string)($_GET['activo'] ?? '');

// Helper de escape HTML seguro blindado contra arrays
if (!function_exists('e')) {
    function e(mixed $value): string {
        if (is_array($value)) {
            return htmlspecialchars(implode(', ', array_filter($value, 'is_scalar')), ENT_QUOTES, 'UTF-8');
        }
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

// Preparación segura de datos para Chart.js
$chartLocalidadesNombres = json_encode(array_column($localidades, 'nombre'), JSON_UNESCAPED_UNICODE);
$chartLocalidadesValores = json_encode(array_fill(0, count($localidades), 0));
?>

<!-- Estilos específicos del módulo Clientes -->
<link rel="stylesheet" href="/assets/css/clientes.css">

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="container-fluid clientes-module py-4">

    <!-- =====================================================
         HEADER
    ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-users text-primary me-2"></i> Gestión de Clientes
            </h2>
            <p class="text-muted mb-0">
                Administración comercial, contratos y cartera CSDI ERP
            </p>
        </div>

        <div class="d-flex gap-2">
            <a href="/clientes/crear" class="btn btn-primary fw-semibold">
                <i class="fa-solid fa-user-plus me-1"></i> Nuevo Cliente
            </a>

            <!-- Menú desplegable conectado a los servicios transversales de exportación -->
            <div class="dropdown">
                <button class="btn btn-dark dropdown-toggle fw-semibold" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-solid fa-file-export me-1"></i> Reportes
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                    <li>
                        <a class="dropdown-item py-2" href="/clientes/exportar/pdf" target="_blank">
                            <i class="fa-solid fa-file-pdf text-danger me-2"></i> Exportar a PDF
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item py-2" href="/clientes/exportar/excel" target="_blank">
                            <i class="fa-solid fa-file-excel text-success me-2"></i> Exportar a Excel
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- =====================================================
         KPI CARDS
    ===================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card shadow-sm border-0 rounded-3 bg-white">
                <div class="card-body p-3">
                    <div class="text-muted small fw-bold text-uppercase">TOTAL CLIENTES</div>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <h2 class="fw-bold text-dark mb-0"><?= e($stats['total']) ?></h2>
                        <i class="fa-solid fa-users fa-2x text-primary opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card shadow-sm border-0 rounded-3 bg-white">
                <div class="card-body p-3">
                    <div class="text-muted small fw-bold text-uppercase">CLIENTES ACTIVOS</div>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <h2 class="fw-bold text-success mb-0"><?= e($stats['activos']) ?></h2>
                        <i class="fa-solid fa-circle-check fa-2x text-success opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card shadow-sm border-0 rounded-3 bg-white">
                <div class="card-body p-3">
                    <div class="text-muted small fw-bold text-uppercase">CLIENTES INACTIVOS</div>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <h2 class="fw-bold text-danger mb-0"><?= e($stats['inactivos']) ?></h2>
                        <i class="fa-solid fa-user-slash fa-2x text-danger opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card shadow-sm border-0 rounded-3 bg-white">
                <div class="card-body p-3">
                    <div class="text-muted small fw-bold text-uppercase">LOCALIDADES</div>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <h2 class="fw-bold text-info mb-0"><?= count($localidades) ?></h2>
                        <i class="fa-solid fa-location-dot fa-2x text-info opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- =====================================================
         TABS
    ===================================================== -->
    <ul class="nav nav-tabs mb-4 border-secondary" id="clientesTabs" role="tablist">
        <li class="nav-item">
            <button class="nav-link active" id="resumen-tab" data-bs-toggle="tab" data-bs-target="#resumen" type="button" role="tab">
                <i class="fa-solid fa-chart-line me-1"></i> Resumen
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link" id="listado-tab" data-bs-toggle="tab" data-bs-target="#listado" type="button" role="tab">
                <i class="fa-solid fa-table me-1"></i> Clientes
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link" id="analisis-tab" data-bs-toggle="tab" data-bs-target="#analisis" type="button" role="tab">
                <i class="fa-solid fa-chart-pie me-1"></i> Análisis
            </button>
        </li>
    </ul>

    <div class="tab-content" id="clientesTabsContent">

        <!-- =====================================================
             TAB 1: RESUMEN
        ===================================================== -->
        <div class="tab-pane fade show active" id="resumen" role="tabpanel">
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-header bg-dark text-white fw-bold py-3">Estado de cartera</div>
                        <div class="card-body">
                            <canvas id="clientesEstadoChart"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-header bg-dark text-white fw-bold py-3">Distribución geográfica</div>
                        <div class="card-body">
                            <canvas id="clientesLocalidadChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- =====================================================
             TAB 2: LISTADO DE CLIENTES (FILTROS COMBINADOS EN TIEMPO REAL SIN 404)
        ===================================================== -->
        <div class="tab-pane fade" id="listado" role="tabpanel">
            <div class="card shadow-sm border-0 rounded-3 mb-4">
                <div class="card-body p-3">
                    <form id="formFiltrosClientes" action="" onsubmit="return false;">
                        <div class="row g-3">
                            <!-- 1. BUSCADOR TEXTO HOT -->
                            <div class="col-md-3">
                                <label class="form-label fw-bold small text-muted">Buscador Hot (Tiempo Real)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-end-0">
                                        <i class="fa-solid fa-magnifying-glass text-secondary"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        id="buscarClienteHot" 
                                        name="texto" 
                                        value="<?= e($textoFiltro) ?>" 
                                        class="form-control border-start-0 ps-0 fw-semibold" 
                                        placeholder="Escriba para filtrar al instante..." 
                                        autocomplete="off"
                                    >
                                </div>
                            </div>

                            <!-- 2. FILTRO LOCALIDAD -->
                            <div class="col-md-3">
                                <label class="form-label fw-bold small text-muted">Localidad</label>
                                <select id="filtroLocalidadHot" name="localidad_id" class="form-select fw-bold">
                                    <option value="">Todas las localidades</option>
                                    <?php foreach ($localidades as $loc): ?>
                                        <?php $locNombre = (string)($loc['nombre'] ?? ''); ?>
                                        <option value="<?= e($locNombre) ?>">
                                            <?= e($locNombre) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- 3. FILTRO TARIFA -->
                            <div class="col-md-3">
                                <label class="form-label fw-bold small text-muted">Tarifa</label>
                                <select id="filtroTarifaHot" name="tarifa_id" class="form-select fw-bold">
                                    <option value="">Todas las tarifas</option>
                                    <?php foreach ($tarifas as $tarifa): ?>
                                        <?php $tarNombre = (string)($tarifa['nombre_tarifa'] ?? $tarifa['nombre'] ?? ''); ?>
                                        <option value="<?= e($tarNombre) ?>">
                                            <?= e($tarNombre) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- 4. FILTRO ESTADO -->
                            <div class="col-md-2">
                                <label class="form-label fw-bold small text-muted">Estado</label>
                                <select id="filtroEstadoHot" name="activo" class="form-select fw-bold">
                                    <option value="">Todos</option>
                                    <option value="activo">Activos</option>
                                    <option value="inactivo">Inactivos</option>
                                </select>
                            </div>

                            <!-- BOTÓN REINICIAR FILTROS -->
                            <div class="col-md-1 d-flex align-items-end">
                                <button type="button" id="btnResetFiltros" class="btn btn-dark w-100 fw-bold" title="Limpiar Filtros">
                                    <i class="fa-solid fa-filter-circle-xmark"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- TABLA DE CLIENTES -->
            <div class="card shadow-sm border-0 rounded-3 overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tablaClientes">
                        <thead class="table-dark">
                            <tr>
                                <th class="ps-4">
                                    <span class="sort-trigger" data-col="0">
                                        Cliente <i class="fa-solid fa-sort ms-1 small"></i>
                                    </span>
                                </th>
                                <th>
                                    <span class="sort-trigger" data-col="1">
                                        Contacto <i class="fa-solid fa-sort ms-1 small"></i>
                                    </span>
                                </th>
                                <th>
                                    <span class="sort-trigger" data-col="2">
                                        Localidad <i class="fa-solid fa-sort ms-1 small"></i>
                                    </span>
                                </th>
                                <th>
                                    <span class="sort-trigger" data-col="3">
                                        Tarifa <i class="fa-solid fa-sort ms-1 small"></i>
                                    </span>
                                </th>
                                <th>Estado</th>
                                <th width="160" class="text-end pe-4">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($clientes)): ?>
                                <tr>
                                    <td colspan="6" class="text-center p-5">
                                        <h5 class="text-muted mb-0">No existen clientes registrados</h5>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($clientes as $cliente): ?>
                                    <?php 
                                        $cId       = (int)($cliente['id'] ?? 0);
                                        $nombre    = (string)($cliente['nombre'] ?? '-');
                                        $inicial   = strtoupper(substr($nombre, 0, 1));
                                        $activo    = !empty($cliente['activo']);
                                        $locTexto  = (string)($cliente['localidad'] ?? $cliente['localidad_nombre'] ?? '-');
                                        $tarifaTex = (string)($cliente['nombre_tarifa'] ?? $cliente['tarifa'] ?? '-');
                                    ?>
                                    <tr class="fila-tabla fila-cliente" 
                                        data-nombre="<?= e(strtolower($nombre)) ?>"
                                        data-localidad="<?= e(strtolower($locTexto)) ?>"
                                        data-tarifa="<?= e(strtolower($tarifaTex)) ?>"
                                        data-estado="<?= $activo ? 'activo' : 'inactivo' ?>">
                                        
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="rounded-circle bg-primary text-white p-2 d-flex align-items-center justify-content-center flex-shrink-0" style="width: 35px; height: 35px; font-weight: bold;">
                                                    <?= e($inicial) ?>
                                                </div>
                                                <div>
                                                    <strong class="text-dark d-block celda-nombre"><?= e($nombre) ?></strong>
                                                    <small class="text-muted celda-email"><?= e($cliente['email'] ?? '') ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="font-monospace small celda-telefono"><?= e($cliente['telefono'] ?? '-') ?></td>
                                        <td class="celda-localidad"><?= e($locTexto) ?></td>
                                        <td class="celda-tarifa"><?= e($tarifaTex) ?></td>
                                        <td class="celda-estado">
                                            <?php if ($activo): ?>
                                                <span class="badge bg-success">Activo</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inactivo</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end pe-4">
                                            <div class="btn-group btn-group-sm">
                                                <a class="btn btn-outline-info px-2" href="/clientes/ver/<?= $cId ?>" title="Ver Ficha 360°">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a class="btn btn-outline-warning px-2" href="/clientes/editar/<?= $cId ?>" title="Editar Cliente">
                                                    <i class="fa-solid fa-pen text-dark"></i>
                                                </a>
                                                <a class="btn btn-outline-danger px-2" onclick="return confirm('¿Seguro que desea eliminar este cliente?');" href="/clientes/eliminar/<?= $cId ?>" title="Eliminar">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- =====================================================
             TAB 3: ANALISIS
        ===================================================== -->
        <div class="tab-pane fade" id="analisis" role="tabpanel">
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-chart-pie text-primary me-2"></i> Resumen Comercial de Cartera</h5>
                    <ul class="list-group list-group-flush border rounded-3">
                        <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                            <span>Clientes registrados en sistema:</span>
                            <span class="badge bg-primary rounded-pill fs-6 px-3"><?= e($stats['total']) ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                            <span>Clientes activos en cartera:</span>
                            <span class="badge bg-success rounded-pill fs-6 px-3"><?= e($stats['activos']) ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                            <span>Porcentaje de operatividad:</span>
                            <span class="fw-bold fs-6 text-dark">
                                <?= $stats['total'] > 0 ? round(($stats['activos'] / $stats['total']) * 100, 1) : 0 ?>%
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- =====================================================
     MOTOR DE FILTROS EN TIEMPO REAL & GRAFICOS
===================================================== -->
<script>
document.addEventListener('DOMContentLoaded', function() {

    // --- MOTOR DE FILTROS COMBINADOS EN TIEMPO REAL (Client-Side) ---
    const txtBuscar = document.getElementById('buscarClienteHot');
    const selLocalidad = document.getElementById('filtroLocalidadHot');
    const selTarifa = document.getElementById('filtroTarifaHot');
    const selEstado = document.getElementById('filtroEstadoHot');
    const btnReset = document.getElementById('btnResetFiltros');
    const filasClientes = document.querySelectorAll('.fila-cliente');

    function aplicarFiltrosCombinados() {
        const queryText = (txtBuscar?.value || '').toLowerCase().trim();
        const filterLoc = (selLocalidad?.value || '').toLowerCase().trim();
        const filterTar = (selTarifa?.value || '').toLowerCase().trim();
        const filterEst = (selEstado?.value || '').toLowerCase().trim();

        filasClientes.forEach(fila => {
            const rowText = fila.textContent.toLowerCase();
            const rowLoc = (fila.getAttribute('data-localidad') || '').toLowerCase();
            const rowTar = (fila.getAttribute('data-tarifa') || '').toLowerCase();
            const rowEst = (fila.getAttribute('data-estado') || '').toLowerCase();

            const matchTexto = !queryText || rowText.includes(queryText);
            const matchLoc = !filterLoc || rowLoc.includes(filterLoc);
            const matchTar = !filterTar || rowTar.includes(filterTar);
            const matchEst = !filterEst || rowEst === filterEst;

            if (matchTexto && matchLoc && matchTar && matchEst) {
                fila.style.setProperty('display', '', 'important');
            } else {
                fila.style.setProperty('display', 'none', 'important');
            }
        });
    }

    if (txtBuscar) txtBuscar.addEventListener('keyup', aplicarFiltrosCombinados);
    if (selLocalidad) selLocalidad.addEventListener('change', aplicarFiltrosCombinados);
    if (selTarifa) selTarifa.addEventListener('change', aplicarFiltrosCombinados);
    if (selEstado) selEstado.addEventListener('change', aplicarFiltrosCombinados);

    if (btnReset) {
        btnReset.addEventListener('click', () => {
            if (txtBuscar) txtBuscar.value = '';
            if (selLocalidad) selLocalidad.value = '';
            if (selTarifa) selTarifa.value = '';
            if (selEstado) selEstado.value = '';
            aplicarFiltrosCombinados();
        });
    }

    // Gráfico Estado de Clientes
    const ctxEstado = document.getElementById('clientesEstadoChart');
    if (ctxEstado && typeof Chart !== 'undefined') {
        new Chart(ctxEstado, {
            type: 'doughnut',
            data: {
                labels: ['Activos', 'Inactivos'],
                datasets: [{
                    data: [
                        <?= (int)($stats['activos'] ?? 0) ?>,
                        <?= (int)($stats['inactivos'] ?? 0) ?>
                    ],
                    backgroundColor: ['#198754', '#dc3545']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }

    // Gráfico Distribución por Localidad
    const ctxLocalidad = document.getElementById('clientesLocalidadChart');
    if (ctxLocalidad && typeof Chart !== 'undefined') {
        new Chart(ctxLocalidad, {
            type: 'bar',
            data: {
                labels: <?= $chartLocalidadesNombres ?>,
                datasets: [{
                    label: 'Clientes',
                    data: <?= $chartLocalidadesValores ?>,
                    backgroundColor: '#0d6efd'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { stepSize: 1 } }
                }
            }
        });
    }
});
</script>