<?php
declare(strict_types=1);

$cliente = $cliente ?? [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ficha de Cliente #<?= e($cliente['id'] ?? '') ?></title>
    <style>
        body { font-family: Helvetica, Arial, sans-serif; color: #333; font-size: 14px; margin: 0; padding: 20px; }
        .header { border-bottom: 2px solid #0056b3; padding-bottom: 10px; margin-bottom: 20px; }
        .header h2 { color: #0056b3; margin: 0; }
        .meta { font-size: 12px; color: #777; float: right; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f8f9fa; width: 30%; }
        .badge { padding: 5px 10px; font-size: 11px; font-weight: bold; border-radius: 4px; display: inline-block; }
        .badge-success { background-color: #28a745; color: #fff; }
        .badge-danger { background-color: #dc3545; color: #fff; }
    </style>
</head>
<body>
    <div class="header">
        <div class="meta">Fecha de emisión: <?= date('d/m/Y H:i') ?></div>
        <h2>CSDI ERP - Ficha Técnica de Cliente</h2>
    </div>

    <table>
        <tr>
            <th>ID Interno</th>
            <td><strong>#<?= e($cliente['id'] ?? '') ?></strong></td>
        </tr>
        <tr>
            <th>Razón Social / Nombre</th>
            <td><strong><?= e($cliente['nombre'] ?? '') ?></strong></td>
        </tr>
        <tr>
            <th>Correo Electrónico</th>
            <td><?= e($cliente['email'] ?: 'No registrado') ?></td>
        </tr>
        <tr>
            <th>Teléfono de Contacto</th>
            <td><?= e($cliente['telefono'] ?: 'No registrado') ?></td>
        </tr>
        <tr>
            <th>Localidad / Zona</th>
            <td><?= e($cliente['localidad'] ?? 'Sin localidad') ?></td>
        </tr>
        <tr>
            <th>Esquema Tarifario</th>
            <td><?= e($cliente['nombre_tarifa'] ?? 'Tarifa Base') ?></td>
        </tr>
        <tr>
            <th>Estado Operativo</th>
            <td>
                <?php if(!empty($cliente['activo'])): ?>
                    <span class="badge badge-success">ACTIVO</span>
                <?php else: ?>
                    <span class="badge badge-danger">INACTIVO</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>
</body>
</html>