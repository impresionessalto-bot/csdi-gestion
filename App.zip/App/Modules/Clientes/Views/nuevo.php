<?php
declare(strict_types=1);

$localidades = $localidades ?? [];
$tarifas = $tarifas ?? [];
$csrf = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2>
                <i class="fa-solid fa-user-plus text-success me-2"></i>
                Alta de Nuevo Cliente
            </h2>
            <p class="text-muted mb-0">Complete la información corporativa para la gestión de equipos y facturación.</p>
        </div>
        <div>
            <a href="/clientes" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Volver
            </a>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST" action="/clientes">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">

                <div class="row g-3">
                    <!-- NOMBRE / RAZON SOCIAL -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Razón Social / Nombre <span class="text-danger">*</span></label>
                        <input type="text" name="nombre" class="form-control" required placeholder="Ej: CSDI Copiadoras SRL">
                    </div>

                    <!-- NOMBRE FANTASIA -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Nombre de Fantasía (Comercial)</label>
                        <input type="text" name="nombre_fantasia" class="form-control" placeholder="Ej: Sucursal Centro">
                    </div>

                    <!-- PERSONA DE CONTACTO -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Persona de Contacto</label>
                        <input type="text" name="persona_contacto" class="form-control" placeholder="Ej: Juan Pérez">
                    </div>

                    <!-- TELEFONO -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Teléfono / Celular</label>
                        <input type="text" name="telefono" class="form-control" placeholder="Ej: 341XXXXXXX">
                    </div>

                    <!-- EMAIL -->
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Email de Contacto</label>
                        <input type="email" name="email" class="form-control" placeholder="Ej: administracion@cliente.com">
                    </div>

                    <!-- DIRECCION -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Dirección / Domicilio</label>
                        <input type="text" name="direccion" class="form-control" placeholder="Calle, Número y Localidad">
                    </div>

                    <!-- LOCALIDAD -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Localidad / Zona</label>
                        <select name="localidad_id" class="form-select">
                            <option value="">Seleccione Localidad</option>
                            <?php foreach ($localidades as $loc): ?>
                                <option value="<?= e($loc['id']) ?>">
                                    <?= e($loc['nombre']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- TARIFA ASIGNADA -->
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Esquema Tarifario</label>
                        <select name="tarifa_id" class="form-select">
                            <option value="">Seleccione Tarifa</option>
                            <?php foreach ($tarifas as $tarifa): ?>
                                <option value="<?= e($tarifa['id']) ?>">
                                    <?= e($tarifa['nombre_tarifa']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- CATEGORIA FISCAL -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Categoría Fiscal</label>
                        <select name="categoria_fiscal" class="form-select">
                            <option value="CONSUMIDOR_FINAL">Consumidor Final</option>
                            <option value="RESPONSABLE_INSCRIPTO">Responsable Inscripto</option>
                            <option value="MONOTRIBUTISTA">Monotributista</option>
                            <option value="EXENTO">Exento</option>
                        </select>
                    </div>

                    <!-- ESTADO OPERATIVO -->
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Estado Inicial de la Cuenta</label>
                        <select name="activo" class="form-select">
                            <option value="1" selected>Activo / Habilitado</option>
                            <option value="0">Inactivo / Suspendido</option>
                        </select>
                    </div>

                    <!-- BOTON DE PERSISTENCIA -->
                    <div class="col-12 text-end mt-4">
                        <button type="submit" class="btn btn-success px-4">
                            <i class="fa-solid fa-save me-2"></i>Registrar Cliente
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>