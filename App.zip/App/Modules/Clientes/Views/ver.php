<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| CLIENTES - FICHA 360° DEL CLIENTE (Con Buscador Smart e Iconografía Sincronizada)
|--------------------------------------------------------------------------
*/

$cliente      = $cliente ?? [];
$equipos      = $equipos ?? [];
$servicios    = $servicios ?? [];
$documentos   = $documentos ?? [];
$estadisticas = $estadisticas ?? [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

$totalEquipos    = $estadisticas['equipos'] ?? count($equipos);
$totalServicios  = $estadisticas['servicios'] ?? count($servicios);
$totalDocumentos = $estadisticas['documentos'] ?? count($documentos);

$id     = (int)($cliente['id'] ?? 0);
$nombre = (string)($cliente['nombre'] ?? 'Cliente');
?>

<div class="container-fluid py-4 animate-fade-in">

    <!-- =====================================================
         1) CABECERA DE PERFIL 360° (Con Enlaces de Admin Sincronizados)
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">
        <div class="d-flex align-items-center">
            <div class="bg-primary text-white rounded-3 p-3 me-3 shadow-sm">
                <i class="fa-solid fa-building-user fs-3"></i>
            </div>
            <div>
                <h2 class="fw-bold text-white mb-1">
                    <?= e($nombre) ?>
                </h2>
                <span class="text-muted-erp small fw-semibold">Ficha integral comercial, técnica y documental</span>
            </div>
        </div>
        
        <!-- Botones de Acción de la Ficha -->
        <div class="d-flex gap-2">
            <a href="<?= base_url('/admin/clientes') ?>" class="btn-erp btn-erp-primary btn-sm text-decoration-none">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver al Listado
            </a>
            <a href="<?= base_url('/admin/clientes/editar/' . $id) ?>" class="btn btn-warning btn-sm text-decoration-none fw-bold px-3">
                <i class="fa-solid fa-pen me-1"></i> Editar Ficha
            </a>
            <a href="<?= base_url('/admin/clientes/reportes/pdf?id=' . $id) ?>" class="btn btn-danger btn-sm text-decoration-none px-3" target="_blank">
                <i class="fa-solid fa-file-pdf me-1"></i> Exportar PDF
            </a>
        </div>
    </div>

    <!-- =====================================================
         2) TIRA DE KPIS / METRICAS RÁPIDAS
         ===================================================== -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-primary) !important;">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Equipos</span>
                        <strong class="fs-4 text-dark"><?= $totalEquipos ?></strong>
                    </div>
                    <div class="text-primary p-2">
                        <i class="fa-solid fa-print fs-3"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-success) !important;">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Servicios</span>
                        <strong class="fs-4 text-dark"><?= $totalServicios ?></strong>
                    </div>
                    <div class="text-success p-2">
                        <i class="fa-solid fa-screwdriver-wrench fs-3"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-warning) !important;">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Documentos</span>
                        <strong class="fs-4 text-dark"><?= $totalDocumentos ?></strong>
                    </div>
                    <div class="text-warning p-2">
                        <i class="fa-solid fa-folder fs-3"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm border-0 rounded-3" style="background-color: #ffffff; border-left: 4px solid var(--bs-info) !important;">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small text-uppercase fw-semibold d-block mb-1">Estado</span>
                        <strong class="fs-4 d-block">
                            <?php if (!empty($cliente['activo'])): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle py-1 fs-8">ACTIVO</span>
                            <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger border border-danger-subtle py-1 fs-8">INACTIVO</span>
                            <?php endif; ?>
                        </strong>
                    </div>
                    <div class="text-info p-2">
                        <i class="fa-solid fa-circle-check fs-3"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- =====================================================
         3) SISTEMA DE PESTAÑAS (Ficha 360° de Clientes)
         ===================================================== -->
    <div class="card shadow-sm border-0 rounded-3 overflow-hidden">
        <div class="card-header bg-dark py-1">
            <ul class="nav nav-tabs card-header-tabs border-bottom-0" id="ficha360Tab" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active text-white fw-bold bg-transparent border-0 px-3 py-2" id="datos-tab" data-bs-toggle="tab" data-bs-target="#datos" type="button" role="tab">
                        <i class="fa-solid fa-user me-1 text-primary"></i> Datos
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2" id="equipos-tab" data-bs-toggle="tab" data-bs-target="#equipos" type="button" role="tab">
                        <i class="fa-solid fa-print me-1 text-success"></i> Equipos (<?= count($equipos) ?>)
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2" id="servicios-tab" data-bs-toggle="tab" data-bs-target="#servicios" type="button" role="tab">
                        <i class="fa-solid fa-screwdriver-wrench me-1 text-warning"></i> Servicios (<?= count($servicios) ?>)
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2" id="documentos-tab" data-bs-toggle="tab" data-bs-target="#documentos" type="button" role="tab">
                        <i class="fa-solid fa-folder me-1 text-info"></i> Documentos (<?= count($documentos) ?>)
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2" id="kpis-tab" data-bs-toggle="tab" data-bs-target="#kpis" type="button" role="tab">
                        <i class="fa-solid fa-chart-line me-1 text-danger"></i> KPIs
                    </button>
                </li>
            </ul>
        </div>

        <div class="card-body p-4 bg-white">
            
            <!-- =====================================================
                 NUEVA MEJORA UX: SMART SEARCH DE LA FICHA 360°
                 Filtra instantáneamente en caliente los registros de la pestaña abierta.
                 ===================================================== -->
            <div class="row mb-3">
                <div class="col-12 col-md-4 ms-auto">
                    <div class="input-group shadow-sm">
                        <span class="input-group-text bg-white border-end-0 text-muted">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </span>
                        <!-- Apunta dinámicamente al contenedor de las pestañas -->
                        <input type="text" id="smartSearchFicha" class="form-control border-start-0 ps-0 fw-semibold csdi-smart-search" data-target-table="ficha360TabContent" placeholder="Buscar en esta pestaña...">
                    </div>
                </div>
            </div>

            <div class="tab-content" id="ficha360TabContent">

                <!-- PESTAÑA A: DATOS GENERALES -->
                <div class="tab-pane fade show active" id="datos" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <table class="table table-striped table-hover align-middle mb-0">
                                <tbody>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">ID</th>
                                        <td class="text-dark fw-bold">#<?= e($cliente['id'] ?? '') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Nombre / Razón Social</th>
                                        <td class="text-dark fw-bold"><?= e($cliente['nombre'] ?? '') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Fantasía</th>
                                        <td><?= e($cliente['nombre_fantasia'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Persona de Contacto</th>
                                        <td><?= e($cliente['persona_contacto'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Teléfono de Sede</th>
                                        <td><?= e($cliente['telefono'] ?? '-') ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="col-md-6">
                            <table class="table table-striped table-hover align-middle mb-0">
                                <tbody>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Email institucional</th>
                                        <td><?= e($cliente['email'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Dirección de Despacho</th>
                                        <td><?= e($cliente['direccion'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Localidad</th>
                                        <td><?= e($cliente['localidad'] ?? '-') ?></td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Tarifa Asignada</th>
                                        <td>
                                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
                                                <?= e($cliente['nombre_tarifa'] ?? '-') ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="text-secondary small fw-semibold">Categoría fiscal</th>
                                        <td><?= e($cliente['categoria_fiscal'] ?? '-') ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- PESTAÑA B: EQUIPOS INSTALADOS -->
                <div class="tab-pane fade" id="equipos" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="tablaEquiposFicha">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">ID</th>
                                    <th>Modelo</th>
                                    <th>Número de Serie</th>
                                    <th class="pe-4 text-end">Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($equipos)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">No hay equipos asignados a este cliente.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($equipos as $eq): ?>
                                        <?php
                                        $eqId    = (int)($eq['id'] ?? 0);
                                        $eqMod   = (string)($eq['modelo_oficial'] ?? '-');
                                        $eqSerie = (string)($eq['serie'] ?? $eq['nro_serie'] ?? '-');
                                        $eqEst   = (string)($eq['estado'] ?? '-');
                                        ?>
                                        <!-- CORRECCIÓN: Se inyectó la clase .fila-tabla para habilitar la búsqueda -->
                                        <tr class="fila-tabla">
                                            <td class="ps-4 text-secondary fw-semibold">#<?= $eqId ?></td>
                                            <td class="fw-bold text-dark"><?= htmlspecialchars($eqMod, ENT_QUOTES, 'UTF-8') ?></td>
                                            <td class="font-monospace"><?= htmlspecialchars($eqSerie, ENT_QUOTES, 'UTF-8') ?></td>
                                            <td class="pe-4 text-end">
                                                <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">
                                                    <?= htmlspecialchars(strtoupper($eqEst), ENT_QUOTES, 'UTF-8') ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- PESTAÑA C: HISTORIAL DE SERVICIOS -->
                <div class="tab-pane fade" id="servicios" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="tablaServiciosFicha">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Fecha Solicitud</th>
                                    <th>Descripción de la Incidencia</th>
                                    <th class="pe-4 text-end">Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($servicios)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-4">No hay registros de soporte técnico para este cliente.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($servicios as $s): ?>
                                        <?php
                                        $sFecha = (string)($s['fecha_solicitud'] ?? '-');
                                        $sDesc  = (string)($s['descripcion_problema'] ?? '-');
                                        $sEst   = (string)($s['estado'] ?? '-');
                                        ?>
                                        <!-- CORRECCIÓN: Se inyectó la clase .fila-tabla para habilitar la búsqueda -->
                                        <tr class="fila-tabla">
                                            <td class="ps-4 font-monospace"><?= htmlspecialchars($sFecha !== '-' ? date('d/m/Y', strtotime($sFecha)) : '-', ENT_QUOTES, 'UTF-8') ?></td>
                                            <td class="text-truncate" style="max-width: 350px;"><?= htmlspecialchars($sDesc, ENT_QUOTES, 'UTF-8') ?></td>
                                            <td class="pe-4 text-end">
                                                <span class="badge bg-warning-subtle text-warning border border-warning-subtle"><?= htmlspecialchars(strtoupper($sEst), ENT_QUOTES, 'UTF-8') ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- PESTAÑA D: DOCUMENTACIÓN -->
                <div class="tab-pane fade" id="documentos" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="tablaDocumentosFicha">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Nombre de Archivo</th>
                                    <th>Tipo de Documento</th>
                                    <th class="pe-4 text-end">Fecha de Subida</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($documentos)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-4">No hay documentos cargados para este cliente.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($documentos as $d): ?>
                                        <?php
                                        $dNom   = (string)($d['nombre'] ?? '-');
                                        $dTipo  = (string)($d['tipo'] ?? '-');
                                        $dFecha = (string)($d['created_at'] ?? '-');
                                        ?>
                                        <!-- CORRECCIÓN: Se inyectó la clase .fila-tabla para habilitar la búsqueda -->
                                        <tr class="fila-tabla">
                                            <td class="ps-4 text-dark fw-bold">
                                                <i class="fa-solid fa-file-pdf text-danger me-2"></i>
                                                <?= htmlspecialchars($dNom, ENT_QUOTES, 'UTF-8') ?>
                                            </td>
                                            <td><span class="badge bg-secondary"><?= htmlspecialchars($dTipo, ENT_QUOTES, 'UTF-8') ?></span></td>
                                            <td class="pe-4 text-end font-monospace"><?= htmlspecialchars($dFecha !== '-' ? date('d/m/Y', strtotime($dFecha)) : '-', ENT_QUOTES, 'UTF-8') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- PESTAÑA E: KPIS RESUMEN -->
                <div class="tab-pane fade" id="kpis" role="tabpanel">
                    <div class="row text-center py-4 g-3">
                        <div class="col-md-4">
                            <div class="p-3 border rounded-3 bg-light">
                                <h2 class="fw-bold text-primary mb-1"><?= $totalEquipos ?></h2>
                                <p class="text-muted small mb-0">Equipos instalados en campo</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded-3 bg-light">
                                <h2 class="fw-bold text-success mb-1"><?= $totalServicios ?></h2>
                                <p class="text-muted small mb-0">Servicios técnicos realizados</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded-3 bg-light">
                                <h2 class="fw-bold text-warning mb-1"><?= $totalDocumentos ?></h2>
                                <p class="text-muted small mb-0">Documentos legalizados cargados</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>