<?php
declare(strict_types=1);

$cliente = $cliente ?? [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2><i class="fa-solid fa-user-tag text-info me-2"></i>Ficha de Cliente</h2>
            <p class="text-muted mb-0">Detalle comercial e historial de la cuenta asignada.</p>
        </div>
        <div>
            <a href="/clientes" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Volver al Listado
            </a>
            <a href="/clientes/editar/<?= e($cliente['id']) ?>" class="btn btn-warning">
                <i class="fa-solid fa-pen"></i> Editar Datos
            </a>
        </div>
    </div>

    <div class="row">
        <!-- Panel de Datos -->
        <div class="col-lg-5 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-dark text-white fw-bold">
                    <i class="fa-solid fa-address-card me-2"></i>Información General
                </div>
                <div class="card-body">
                    <table class="table table-profile mb-0">
                        <tbody>
                            <tr>
                                <td class="fw-bold text-muted" width="130">ID de Sistema:</td>
                                <td><strong><?= e($cliente['id']) ?></strong></td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-muted">Razón Social:</td>
                                <td><span class="fs-5 fw-bold text-dark"><?= e($cliente['nombre']) ?></span></td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-muted">Email corporativo:</td>
                                <td><?= e($cliente['email'] ?: 'No registrado') ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-muted">Teléfono de contacto:</td>
                                <td><?= e($cliente['telefono'] ?: 'No registrado') ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-muted">Ubicación / Región:</td>
                                <td><?= e($cliente['localidad'] ?? '-') ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-muted">Tarifa Asignada:</td>
                                <td>
                                    <span class="badge bg-light text-dark border border-secondary px-2">
                                        <?= e($cliente['nombre_tarifa'] ?? 'Tarifa Base') ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-muted">Estado operativo:</td>
                                <td>
                                    <?php if($cliente['activo']): ?>
                                        <span class="badge bg-success">Cuenta Activa</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Cuenta Inactiva / Suspendida</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Historiales Relacionados -->
        <div class="col-lg-7 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light fw-bold d-flex justify-content-between align-items-center">
                    <span><i class="fa-solid fa-print text-secondary me-2"></i>Equipos en Contrato</span>
                </div>
                <div class="card-body text-center p-4">
                    <p class="text-muted">La vinculación dinámica se gestiona desde el panel transversal de Equipos o aperturas directas en Servicio Técnico.</p>
                </div>
            </div>
        </div>
    </div>
</div>