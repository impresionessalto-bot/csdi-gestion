<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| CLIENTES - EDITAR CLIENTE (Vista de producción unificada con ruta corregida)
|--------------------------------------------------------------------------
*/

$cliente = $cliente ?? [];
$localidades = $localidades ?? [];
$tarifas = $tarifas ?? [];
$csrf = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4 animate-fade-in">

    <!-- =====================================================
         1) HEADER DE LA SECCIÓN (Con enlace de Volver corregido)
         ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h2 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-user-pen text-warning me-2"></i> Editar Cliente
            </h2>
            <p class="text-muted small mb-0">Actualización de datos comerciales, fiscales y administrativos del cliente</p>
        </div>
        <div>
            <!-- Enlace Volver corregido para retornar a la Ficha 360 del Cliente de forma consistente -->
            <a href="<?= base_url('/admin/clientes/ver/' . (int)($cliente['id'] ?? 0)) ?>" class="btn btn-secondary btn-sm px-3 fw-semibold">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver a la Ficha
            </a>
        </div>
    </div>

    <!-- =====================================================
         2) CONTENEDOR PRINCIPAL CON PESTAÑAS DE EDICIÓN
         ===================================================== -->
    <div class="card border border-light-subtle shadow-sm rounded-3 overflow-hidden">
        <div class="card-header bg-dark py-1">
            <ul class="nav nav-tabs card-header-tabs border-bottom-0" id="editarClienteTab" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active text-white fw-bold bg-transparent border-0 px-3 py-2" id="datos-tab" data-bs-toggle="tab" data-bs-target="#datos" type="button" role="tab">
                        <i class="fa-solid fa-user me-1 text-primary"></i> Datos Generales
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2" id="facturacion-tab" data-bs-toggle="tab" data-bs-target="#facturacion" type="button" role="tab">
                        <i class="fa-solid fa-file-invoice me-1 text-success"></i> Facturación
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link text-white-50 bg-transparent border-0 px-3 py-2" id="configuracion-tab" data-bs-toggle="tab" data-bs-target="#configuracion" type="button" role="tab">
                        <i class="fa-solid fa-gears me-1 text-warning"></i> Configuración
                    </button>
                </li>
            </ul>
        </div>

        <div class="card-body p-4 bg-white">
            <!-- CORRECCIÓN CLAVE: Apunta a tu ruta real del Router '/admin/clientes/actualizar/{id}' -->
            <form method="POST" action="<?= base_url('/admin/clientes/actualizar/' . (int)($cliente['id'] ?? 0)) ?>">
                
                <!-- Token CSRF inyectado por el controlador -->
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">

                <div class="tab-content" id="editarClienteTabContent">

                    <!-- PESTAÑA A: DATOS GENERALES -->
                    <div class="tab-pane fade show active" id="datos" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label text-dark fw-semibold small">Razón Social</label>
                                <input type="text" class="form-control" name="nombre" required value="<?= e($cliente['nombre'] ?? '') ?>">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label text-dark fw-semibold small">Nombre Fantasía</label>
                                <input type="text" class="form-control" name="nombre_fantasia" value="<?= e($cliente['nombre_fantasia'] ?? '') ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Contacto de Referencia</label>
                                <input type="text" class="form-control" name="persona_contacto" value="<?= e($cliente['persona_contacto'] ?? '') ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Teléfono</label>
                                <input type="text" class="form-control" name="telefono" value="<?= e($cliente['telefono'] ?? '') ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Email Comercial</label>
                                <input type="email" class="form-control" name="email" value="<?= e($cliente['email'] ?? '') ?>">
                            </div>

                            <div class="col-md-8">
                                <label class="form-label text-dark fw-semibold small">Dirección Fiscal / Despacho</label>
                                <input type="text" class="form-control" name="direccion" value="<?= e($cliente['direccion'] ?? '') ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Tipo de Cliente</label>
                                <select name="tipo_cliente" class="form-select">
                                    <option value="Externo" <?= ($cliente['tipo_cliente'] ?? '') === 'Externo' ? 'selected' : '' ?>>Externo</option>
                                    <option value="Alquiler" <?= ($cliente['tipo_cliente'] ?? '') === 'Alquiler' ? 'selected' : '' ?>>Alquiler</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label text-dark fw-semibold small">Localidad</label>
                                <select name="localidad_id" class="form-select">
                                    <option value="">Seleccione localidad</option>
                                    <?php foreach ($localidades as $loc): ?>
                                        <option value="<?= e($loc['id']) ?>" <?= ($cliente['localidad_id'] ?? 0) == $loc['id'] ? 'selected' : '' ?>>
                                            <?= e($loc['nombre']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label text-dark fw-semibold small">Tarifa del Abono</label>
                                <select name="tarifa_id" class="form-select">
                                    <option value="">Seleccione tarifa</option>
                                    <?php foreach ($tarifas as $tarifa): ?>
                                        <option value="<?= e($tarifa['id']) ?>" <?= ($cliente['tarifa_id'] ?? 0) == $tarifa['id'] ? 'selected' : '' ?>>
                                            <?= e($tarifa['nombre_tarifa']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- PESTAÑA B: DATOS DE FACTURACIÓN -->
                    <div class="tab-pane fade" id="facturacion" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Categoría Fiscal (IVA)</label>
                                <select name="categoria_fiscal" class="form-select">
                                    <?php $categoria = $cliente['categoria_fiscal'] ?? 'CONSUMIDOR_FINAL'; ?>
                                    <option value="CONSUMIDOR_FINAL" <?= $categoria === 'CONSUMIDOR_FINAL' ? 'selected' : '' ?>>Consumidor Final</option>
                                    <option value="RESPONSABLE_INSCRIPTO" <?= $categoria === 'RESPONSABLE_INSCRIPTO' ? 'selected' : '' ?>>Responsable Inscripto</option>
                                    <option value="MONOTRIBUTISTA" <?= $categoria === 'MONOTRIBUTISTA' ? 'selected' : '' ?>>Monotributista</option>
                                    <option value="EXENTO" <?= $categoria === 'EXENTO' ? 'selected' : '' ?>>Exento</option>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Tipo de Documento</label>
                                <input type="text" class="form-control" name="tipo_doc" value="<?= e($cliente['tipo_doc'] ?? '') ?>" placeholder="CUIT / CUIL / DNI">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Número de Documento / CUIT</label>
                                <input type="text" class="form-control" name="nro_doc" value="<?= e($cliente['nro_doc'] ?? '') ?>" placeholder="00-00000000-0">
                            </div>
                        </div>
                    </div>

                    <!-- PESTAÑA C: CONFIGURACIÓN OPERATIVA -->
                    <div class="tab-pane fade" id="configuracion" role="tabpanel">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Estado Operativo</label>
                                <select name="activo" class="form-select">
                                    <option value="1" <?= !empty($cliente['activo']) ? 'selected' : '' ?>>Activo</option>
                                    <option value="0" <?= empty($cliente['activo']) ? 'selected' : '' ?>>Inactivo</option>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Frecuencia de Visita Técnica</label>
                                <input type="text" class="form-control" name="frecuencia_visita" value="<?= e($cliente['frecuencia_visita'] ?? 'A demanda') ?>">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label text-dark fw-semibold small">Día de Facturación Mensual</label>
                                <input type="number" class="form-control" name="dia_facturacion" value="<?= e($cliente['dia_facturacion'] ?? 11) ?>" min="1" max="31">
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Botón de Envío Único -->
                <div class="text-end mt-4 pt-3 border-top border-secondary">
                    <button type="submit" class="btn btn-primary btn-lg shadow-sm">
                        <i class="fa-solid fa-save me-1"></i> Guardar Cambios
                    </button>
                </div>

            </form>
        </div>
    </div>

</div>