<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Clientes\Controllers\Controller;

// Alias público utilizado por el menú principal del ERP.
// El módulo maestro continúa viviendo bajo /admin/clientes.
Router::get('/clientes', [Controller::class, 'index']);
Router::get('/clientes/', [Controller::class, 'index']);

/*
|--------------------------------------------------------------------------
| CSDI ERP PRO
| MODULE ROUTES: CLIENTES (Unificado bajo el prefijo 'admin/clientes')
|--------------------------------------------------------------------------
*/

Router::group(
    'admin/clientes', // CORRECCIÓN DEFINITIVA: Prefijo unificado sin barra inclinada inicial
    function() {

        // Index con barra inclinada
        Router::get(
            '/',
            [Controller::class, 'index']
        );

        // Index de respaldo sin barra inclinada para evitar errores 404
        Router::get(
            '',
            [Controller::class, 'index']
        );

        Router::get(
            '/crear',
            [Controller::class, 'create']
        );

        Router::post(
            '/',
            [Controller::class, 'store']
        );

        Router::get(
            '/depurar',
            [Controller::class, 'depurarRepetidos']
        );

        Router::get(
            '/reportes/excel',
            [Controller::class, 'exportarExcel']
        );

        Router::get(
            '/reportes/pdf',
            [Controller::class, 'exportarPdf']
        );

        Router::get(
            '/reportes/csv',
            [Controller::class, 'exportarCsv']
        );

        // Rutas dinámicas con parámetros de ID
        Router::get(
            '/ver/{id}',
            [Controller::class, 'show']
        );

        Router::get(
            '/editar/{id}',
            [Controller::class, 'edit']
        );

        Router::post(
            '/actualizar/{id}',
            [Controller::class, 'update']
        );

        Router::get(
            '/eliminar/{id}',
            [Controller::class, 'destroy']
        );
    }
);