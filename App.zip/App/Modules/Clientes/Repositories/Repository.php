<?php

declare(strict_types=1);

namespace App\Modules\Clientes\Repositories;

use PDO;
use Throwable;


final class Repository
{

    public function __construct(
        private readonly PDO $db
    ){
    }




    /*
    |--------------------------------------------------------------------------
    | LISTADO CLIENTES
    |--------------------------------------------------------------------------
    */

    public function listar(
        array $filtros = []
    ): array
    {

        $sql = "

            SELECT

                c.*,

                l.nombre AS localidad,

                t.nombre_tarifa


            FROM clientes c


            LEFT JOIN localidades l
                ON c.localidad_id = l.id


            LEFT JOIN tarifas t
                ON c.tarifa_id = t.id


            WHERE 1=1

        ";


        $params = [];




        /*
        |----------------------------------------------------------------------
        | TEXTO
        |----------------------------------------------------------------------
        */


        if(
            !empty($filtros['texto'])
        ){

            $sql .= "

                AND (

                    c.nombre LIKE ?

                    OR c.nombre_fantasia LIKE ?

                    OR c.email LIKE ?

                    OR c.telefono LIKE ?

                )

            ";


            $texto =
                '%'
                .
                $filtros['texto']
                .
                '%';


            $params[]=$texto;
            $params[]=$texto;
            $params[]=$texto;
            $params[]=$texto;

        }




        /*
        |----------------------------------------------------------------------
        | LOCALIDAD
        |----------------------------------------------------------------------
        */

        if(
            !empty($filtros['localidad_id'])
        ){

            $sql .= "
                AND c.localidad_id = ?
            ";


            $params[] =
                (int)$filtros['localidad_id'];

        }




        /*
        |----------------------------------------------------------------------
        | TARIFA
        |----------------------------------------------------------------------
        */

        if(
            !empty($filtros['tarifa_id'])
        ){

            $sql .= "
                AND c.tarifa_id = ?
            ";


            $params[] =
                (int)$filtros['tarifa_id'];

        }




        /*
        |----------------------------------------------------------------------
        | ACTIVO (Corregido para evitar colapsos en PHP 8 por orden de evaluación)
        |----------------------------------------------------------------------
        */

        if(
            isset($filtros['activo'])
            &&
            $filtros['activo'] !== ''
        ){

            $sql .= "
                AND c.activo = ?
            ";


            $params[] =
                (int)$filtros['activo'];

        }




        $sql .= "

            ORDER BY

            c.nombre ASC

        ";




        $stmt =
            $this->db->prepare($sql);



        $stmt->execute($params);



        return
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

    }







    /*
    |--------------------------------------------------------------------------
    | BUSCAR CLIENTE
    |--------------------------------------------------------------------------
    */

    public function find(
        int $id
    ): ?array
    {


        $stmt =
            $this->db->prepare("

                SELECT

                    c.*,

                    l.nombre AS localidad,

                    t.nombre_tarifa


                FROM clientes c


                LEFT JOIN localidades l
                    ON c.localidad_id=l.id


                LEFT JOIN tarifas t
                    ON c.tarifa_id=t.id


                WHERE c.id=?


                LIMIT 1

            ");



        $stmt->execute([$id]);



        return
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?:null;

    }







    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(
        array $data
    ): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO clientes
            (
                nombre,
                nombre_fantasia,
                tipo_cliente,
                persona_contacto,
                telefono,
                email,
                direccion,
                localidad_id,
                tarifa_id,
                categoria_fiscal,
                tipo_doc,
                nro_doc,
                activo
            )
            VALUES
            (
                :nombre,
                :nombre_fantasia,
                :tipo_cliente,
                :persona_contacto,
                :telefono,
                :email,
                :direccion,
                :localidad_id,
                :tarifa_id,
                :categoria_fiscal,
                :tipo_doc,
                :nro_doc,
                :activo
            )
        ");

        $stmt->execute([
            'nombre' => trim((string)($data['nombre'] ?? '')),
            'nombre_fantasia' => trim((string)($data['nombre_fantasia'] ?? '')) ?: null,
            'tipo_cliente' => trim((string)($data['tipo_cliente'] ?? 'Externo')),
            'persona_contacto' => trim((string)($data['persona_contacto'] ?? '')) ?: null,
            'telefono' => trim((string)($data['telefono'] ?? '')) ?: null,
            'email' => trim((string)($data['email'] ?? '')) ?: null,
            'direccion' => trim((string)($data['direccion'] ?? '')) ?: null,
            'localidad_id' => !empty($data['localidad_id']) ? (int)$data['localidad_id'] : null,
            'tarifa_id' => !empty($data['tarifa_id']) ? (int)$data['tarifa_id'] : null,
            'categoria_fiscal' => trim((string)($data['categoria_fiscal'] ?? 'Consumidor Final')) ?: 'Consumidor Final',
            'tipo_doc' => trim((string)($data['tipo_doc'] ?? '')) ?: null,
            'nro_doc' => trim((string)($data['nro_doc'] ?? '')) ?: null,
            'activo' => (int)($data['activo'] ?? 1),
        ]);

        return (int)$this->db->lastInsertId();
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(
        int $id,
        array $data
    ): bool
    {


        $stmt =
            $this->db->prepare("

                UPDATE clientes SET


                    nombre=?,

                    nombre_fantasia=?,

                    persona_contacto=?,

                    telefono=?,

                    email=?,

                    direccion=?,

                    localidad_id=?,

                    tarifa_id=?,

                    categoria_fiscal=?,

                    activo=?


                WHERE id=?

            ");



        return $stmt->execute([


            trim($data['nombre'] ?? ''),

            trim($data['nombre_fantasia'] ?? ''),

            trim($data['persona_contacto'] ?? ''),

            trim($data['telefono'] ?? ''),

            trim($data['email'] ?? ''),

            trim($data['direccion'] ?? ''),


            !empty($data['localidad_id'])
                ?
                (int)$data['localidad_id']
                :
                null,


            !empty($data['tarifa_id'])
                ?
                (int)$data['tarifa_id']
                :
                null,


            $data['categoria_fiscal']
                ??
                'CONSUMIDOR_FINAL',


            (int)($data['activo'] ?? 1),


            $id

        ]);

    }







    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function delete(
        int $id
    ): bool
    {

        $stmt =
            $this->db->prepare(
                "DELETE FROM clientes WHERE id=?"
            );


        return $stmt->execute([$id]);

    }







    /*
    |--------------------------------------------------------------------------
    | LOCALIDADES
    |--------------------------------------------------------------------------
    */

    public function obtenerLocalidades(): array
    {

        return $this->db
            ->query("

                SELECT

                    id,

                    nombre

                FROM localidades

                ORDER BY nombre

            ")
            ->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

    }







    /*
    |--------------------------------------------------------------------------
    | TARIFAS
    |--------------------------------------------------------------------------
    */

    public function obtenerTarifas(): array
    {

        return $this->db
            ->query("

                SELECT

                    id,

                    nombre_tarifa

                FROM tarifas

                ORDER BY nombre_tarifa

            ")
            ->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

    }







    /*
    |--------------------------------------------------------------------------
    | ESTADISTICAS
    |--------------------------------------------------------------------------
    */

    public function obtenerEstadisticas(): array
    {

        return [

            'total'=>
                $this->cantidadTotal(),


            'activos'=>
                (int)$this->db
                ->query(
                    "SELECT COUNT(*) FROM clientes WHERE activo=1"
                )
                ->fetchColumn(),


            'inactivos'=>
                (int)$this->db
                ->query(
                    "SELECT COUNT(*) FROM clientes WHERE activo=0"
                )
                ->fetchColumn()

        ];

    }







    /*
    |--------------------------------------------------------------------------
    | DASHBOARD COMPATIBILIDAD
    |--------------------------------------------------------------------------
    */

    public function cantidadTotal(): int
    {

        return (int)$this->db
            ->query(
                "SELECT COUNT(*) FROM clientes"
            )
            ->fetchColumn();

    }







    /*
    |--------------------------------------------------------------------------
    | EQUIPOS CLIENTE
    |--------------------------------------------------------------------------
    */

    public function obtenerEquipos(
        int $clienteId
    ): array
    {

        try {


            $stmt =
                $this->db->prepare("

                    SELECT

                        e.*,

                        m.nombre_modelo,

                        m.marca,

                        m.tipo


                    FROM equipos e


                    LEFT JOIN modelos_equipos m

                    ON e.modelo_id=m.id


                    WHERE e.cliente_id=?


                    ORDER BY e.id DESC

                ");



            $stmt->execute([$clienteId]);


            return
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?:[];


        }
        catch(Throwable)
        {

            return [];

        }

    }







    /*
    |--------------------------------------------------------------------------
    | SERVICIOS
    |--------------------------------------------------------------------------
    */

    public function obtenerServicios(
        int $clienteId
    ): array
    {

        try {

            $stmt =
                $this->db->prepare(
                    "
                    SELECT *

                    FROM servicios

                    WHERE cliente_id=?

                    ORDER BY id DESC
                    "
                );


            $stmt->execute([$clienteId]);


            return
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?:[];

        }
        catch(Throwable)
        {

            return [];

        }

    }







    /*
    |--------------------------------------------------------------------------
    | DOCUMENTOS
    |--------------------------------------------------------------------------
    */

    public function obtenerDocumentos(
        int $clienteId
    ): array
    {

        try {


            $stmt =
                $this->db->prepare("

                    SELECT *

                    FROM documentos

                    WHERE cliente_id=?

                    ORDER BY id DESC

                ");



            $stmt->execute([$clienteId]);


            return
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?:[];


        }
        catch(Throwable)
        {

            return [];

        }

    }


}