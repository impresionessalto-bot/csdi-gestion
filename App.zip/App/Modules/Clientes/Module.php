<?php

declare(strict_types=1);

namespace App\Modules\Clientes;

use App\Core\Module as CoreModule;

/**
 * Definición del módulo Clientes para el núcleo de CSDI PRO.
 */
final class Module extends CoreModule
{
    /**
     * Nombre del módulo
     */
    public function name(): string
    {
        return 'Clientes';
    }

    /**
     * Descripción
     */
    public function description(): string
    {
        return 'Gestión integral de clientes del ERP CSDI PRO';
    }

    /**
     * Versión
     */
    public function version(): string
    {
        return '1.0.0';
    }

    /**
     * Archivo de rutas
     */
    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    /**
     * Prioridad de carga
     *
     * Clientes debe cargar antes que módulos
     * que dependen de él.
     */
    public function priority(): int
    {
        return 10;
    }

    /**
     * Menú lateral ERP
     */
    public function menu(): array
    {
        return [
            [
                'title' =>
                    'Clientes',

                'icon' =>
                    'fa-solid fa-users',

                'url' =>
                    '/admin/clientes', // Sincronizado correctamente

                'group' =>
                    'Administración',

                'order' =>
                    10,

                'permission' =>
                    'clientes.ver',

                'visible' =>
                    true,

                'children' =>
                    []
            ]
        ];
    }

    /**
     * Icono
     */
    public function icon(): string
    {
        return 'fa-solid fa-users';
    }

    /**
     * URL principal (Unificada bajo el prefijo 'admin')
     */
    public function url(): string
    {
        return '/admin/clientes'; // CORRECCIÓN: Sincronizado a /admin/clientes
    }

    /**
     * Grupo menú
     */
    public function group(): string
    {
        return 'Administración';
    }

    /**
     * Orden menú
     */
    public function order(): int
    {
        return 10;
    }

    /**
     * Permisos
     */
    public function permissions(): array
    {
        return [
            'clientes.ver',
            'clientes.crear',
            'clientes.editar',
            'clientes.eliminar'
        ];
    }

    /**
     * Dependencias
     */
    public function dependencies(): array
    {
        return [
            // Futuro:
            // 'Localidades'
        ];
    }

    /**
     * Widgets Dashboard
     */
    public function widgets(): array
    {
        return [];
    }

    /**
     * KPIs Dashboard
     */
    public function kpis(): array
    {
        return [];
    }

    /**
     * Módulo activo
     */
    public function enabled(): bool
    {
        return true;
    }

    /**
     * Inicialización
     */
    public function boot(): void
    {
        /*
         * Registrar eventos,
         * listeners o integraciones futuras.
         */
    }
}