<?php
declare(strict_types=1);

namespace App\Modules\Clientes\Services;


use App\Modules\Clientes\Repositories\Repository;
use Throwable;


final class Service
{


    public function __construct(
        private readonly Repository $repository
    ) {
    }






    /**
     * LISTADO CLIENTES
     */
    public function listar(
        array $filtros = []
    ): array
    {

        return $this->repository->listar($filtros);

    }








    /**
     * BUSCAR CLIENTE
     */
    public function find(
        int $id
    ): ?array
    {

        return $this->repository->find($id);

    }








    /**
     * CREAR CLIENTE
     */
    public function crear(
        array $data
    ): int
    {
        $nombre = trim(
            (string)($data['nombre'] ?? '')
        );

        if ($nombre === '') {
            throw new \InvalidArgumentException(
                'El nombre del cliente es obligatorio.'
            );
        }

        $tipoCliente = trim(
            (string)($data['tipo_cliente'] ?? 'Externo')
        );

        if (!in_array($tipoCliente, ['Alquiler', 'Externo'], true)) {
            $tipoCliente = 'Externo';
        }

        $data['nombre'] = mb_substr($nombre, 0, 255);
        $data['tipo_cliente'] = $tipoCliente;
        $data['nombre_fantasia'] = trim((string)($data['nombre_fantasia'] ?? ''));
        $data['persona_contacto'] = trim((string)($data['persona_contacto'] ?? ''));
        $data['telefono'] = trim((string)($data['telefono'] ?? ''));
        $data['email'] = trim((string)($data['email'] ?? ''));
        $data['direccion'] = trim((string)($data['direccion'] ?? ''));
        $data['tipo_doc'] = trim((string)($data['tipo_doc'] ?? ''));
        $data['nro_doc'] = trim((string)($data['nro_doc'] ?? ''));
        $data['categoria_fiscal'] = trim(
            (string)($data['categoria_fiscal'] ?? 'Consumidor Final')
        );

        $data['localidad_id'] =
            !empty($data['localidad_id'])
                ? (int)$data['localidad_id']
                : null;

        $data['tarifa_id'] =
            !empty($data['tarifa_id'])
                ? (int)$data['tarifa_id']
                : null;

        return $this->repository->crear($data);
    }








    /**
     * ACTUALIZAR CLIENTE
     */
    public function actualizar(
        int $id,
        array $data
    ): void
    {

        $this->repository->actualizar(
            $id,
            $data
        );

    }








    /**
     * ELIMINAR
     */
    public function delete(
        int $id
    ): void
    {

        $this->repository->delete($id);

    }









    /**
     * LOCALIDADES
     */
    public function obtenerLocalidades(): array
    {

        try {

            return $this->repository->obtenerLocalidades();

        } catch (Throwable) {

            return [];

        }

    }








    /**
     * TARIFAS
     */
    public function obtenerTarifas(): array
    {

        try {

            return $this->repository->obtenerTarifas();

        } catch (Throwable) {

            return [];

        }

    }









    /**
     * ESTADISTICAS GENERALES
     */
    public function obtenerEstadisticas(): array
    {

        try {

            return $this->repository->obtenerEstadisticas();

        } catch (Throwable) {

            return [

                'total' => 0,

                'activos' => 0,

                'inactivos' => 0

            ];

        }

    }









    /**
     * CONTEO TOTAL DE CLIENTES (COMPATIBILIDAD DASHBOARD)
     */
    public function count(): int
    {
        try {
            return $this->repository->cantidadTotal();
        } catch (Throwable) {
            return 0;
        }
    }









    /**
     * EQUIPOS DEL CLIENTE
     */
    public function obtenerEquipos(
        int $clienteId
    ): array
    {

        try {


            return $this->repository
                ->obtenerEquipos($clienteId);



        } catch (Throwable) {


            return [];


        }

    }









    /**
     * SERVICIOS DEL CLIENTE
     */
    public function obtenerServicios(
        int $clienteId
    ): array
    {

        try {


            return $this->repository
                ->obtenerServicios($clienteId);



        } catch (Throwable) {


            return [];


        }


    }









    /**
     * DOCUMENTOS CLIENTE
     */
    public function obtenerDocumentos(
        int $clienteId
    ): array
    {

        try {


            return $this->repository
                ->obtenerDocumentos($clienteId);



        } catch (Throwable) {


            return [];


        }


    }









    /**
     * KPIS DE CLIENTE
     */
    public function obtenerEstadisticasCliente(
        int $clienteId
    ): array
    {


        $equipos =
            $this->obtenerEquipos($clienteId);



        $servicios =
            $this->obtenerServicios($clienteId);



        $documentos =
            $this->obtenerDocumentos($clienteId);




        return [


            'equipos' =>
                count($equipos),


            'servicios' =>
                count($servicios),


            'documentos' =>
                count($documentos)


        ];


    }


}