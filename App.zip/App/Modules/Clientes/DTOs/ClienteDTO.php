<?php
declare(strict_types=1);

namespace App\Modules\Clientes\DTOs;

use App\Core\BaseDTO;
use InvalidArgumentException;



final class ClienteDTO extends BaseDTO
{


    public function __construct(


        public readonly string $nombre,


        public readonly ?string $nombre_fantasia = null,


        public readonly string $tipo_cliente = 'Externo',


        public readonly ?int $localidad_id = null,


        public readonly ?int $tarifa_id = null,


        public readonly ?int $usuario_asignado_id = null,


        public readonly ?string $direccion = null,


        public readonly ?float $lat = null,


        public readonly ?float $lng = null,


        public readonly ?string $persona_contacto = null,


        public readonly ?string $telefono = null,


        public readonly ?string $email = null,


        public readonly ?string $categoria_fiscal = null,


        public readonly ?string $tipo_doc = null,


        public readonly ?string $nro_doc = null,


        public readonly string $frecuencia_visita = 'A demanda',


        public readonly int $abono_minimo_mono = 0,


        public readonly int $abono_minimo_color = 0,


        public readonly float $valor_abono = 0,


        public readonly string $politica_facturacion = 'ABONO',


        public readonly int $dia_facturacion = 11,


        public readonly int $activo = 1


    ){



        $this->validate();



    }







    /*
    |--------------------------------------------------------------------------
    | VALIDACIONES
    |--------------------------------------------------------------------------
    */


    private function validate(): void
    {


        if(
            trim($this->nombre)===''
        ){

            throw new InvalidArgumentException(

                'El nombre del cliente es obligatorio.'

            );

        }





        if(
            !in_array(
                $this->tipo_cliente,
                [
                    'Alquiler',
                    'Externo'
                ],
                true
            )
        ){

            throw new InvalidArgumentException(

                'Tipo de cliente inválido.'

            );

        }





        if(
            !in_array(
                $this->politica_facturacion,
                [
                    'ABONO',
                    'PROMEDIO_3',
                    'PROMEDIO_6',
                    'ULTIMO_CONSUMO'
                ],
                true
            )
        ){

            throw new InvalidArgumentException(

                'Política de facturación inválida.'

            );

        }


    }








    /*
    |--------------------------------------------------------------------------
    | CREAR DESDE ARRAY API
    |--------------------------------------------------------------------------
    */


    public static function fromArray(
        array $data
    ): self
    {


        return new self(



            nombre:
                trim(
                    (string)(
                        $data['nombre'] ?? ''
                    )
                ),



            nombre_fantasia:
                $data['nombre_fantasia']
                ?? null,



            tipo_cliente:
                $data['tipo_cliente']
                ?? 'Externo',



            localidad_id:
                isset($data['localidad_id'])
                ? (int)$data['localidad_id']
                : null,



            tarifa_id:
                isset($data['tarifa_id'])
                ? (int)$data['tarifa_id']
                : null,



            usuario_asignado_id:
                isset($data['usuario_asignado_id'])
                ? (int)$data['usuario_asignado_id']
                : null,



            direccion:
                $data['direccion']
                ?? null,



            lat:
                isset($data['lat'])
                ? (float)$data['lat']
                : null,



            lng:
                isset($data['lng'])
                ? (float)$data['lng']
                : null,



            persona_contacto:
                $data['persona_contacto']
                ?? null,



            telefono:
                $data['telefono']
                ?? null,



            email:
                $data['email']
                ?? null,



            categoria_fiscal:
                $data['categoria_fiscal']
                ?? null,



            tipo_doc:
                $data['tipo_doc']
                ?? null,



            nro_doc:
                $data['nro_doc']
                ?? null,



            frecuencia_visita:
                $data['frecuencia_visita']
                ?? 'A demanda',



            abono_minimo_mono:
                (int)(
                    $data['abono_minimo_mono']
                    ?? 0
                ),



            abono_minimo_color:
                (int)(
                    $data['abono_minimo_color']
                    ?? 0
                ),



            valor_abono:
                (float)(
                    $data['valor_abono']
                    ?? 0
                ),



            politica_facturacion:
                $data['politica_facturacion']
                ?? 'ABONO',



            dia_facturacion:
                (int)(
                    $data['dia_facturacion']
                    ?? 11
                ),



            activo:
                isset($data['activo'])
                ? (int)$data['activo']
                : 1



        );

    }



}