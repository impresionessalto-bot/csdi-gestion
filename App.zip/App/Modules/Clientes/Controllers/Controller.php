<?php

declare(strict_types=1);

namespace App\Modules\Clientes\Controllers;

use App\Core\BaseController;
use App\Modules\Clientes\Services\Service;
use App\Services\Export\PdfService;
use App\Services\Export\ExcelService;
use RuntimeException;
use Throwable;

/**
 * Controlador de producción para el módulo Clientes.
 * Sincronizado, blindado e integrado con tu gestor de excepciones unificado.
 */
final class Controller extends BaseController
{
    /**
     * El constructor recibe tu Servicio modular e inicializa la clase BaseController.
     */
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /**
     * Assets propios del módulo Clientes.
     */
    private function loadAssets(): void
    {
        $this->assets()->addModule('Clientes');
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO GENERAL
    |--------------------------------------------------------------------------
    */
    public function index(): void
    {
        $this->requireAuth();

        try {
            $this->loadAssets();

            $filtros = [
                'texto'        => trim($_GET['texto'] ?? ''),
                'localidad_id' => (int)($_GET['localidad_id'] ?? 0),
                'tarifa_id'    => (int)($_GET['tarifa_id'] ?? 0),
                'activo'       => $_GET['activo'] ?? '',
            ];

            $this->moduleView(
                'Clientes',
                'index',
                [
                    'titulo'      => 'Clientes',
                    'clientes'    => $this->service->listar($filtros) ?: [],
                    'localidades' => $this->service->obtenerLocalidades() ?: [],
                    'tarifas'     => $this->service->obtenerTarifas() ?: [],
                    'stats'       => $this->service->obtenerEstadisticas() ?: [],
                    'filtros'     => $filtros,
                    'csrf'        => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR PDF
    |--------------------------------------------------------------------------
    */
    public function exportarPdf(): void
    {
        $this->requireAuth();

        try {
            $filtros = [
                'texto'        => trim($_GET['texto'] ?? ''),
                'localidad_id' => (int)($_GET['localidad_id'] ?? 0),
                'tarifa_id'    => (int)($_GET['tarifa_id'] ?? 0),
                'activo'       => $_GET['activo'] ?? '',
            ];
            
            $datosRaw = $this->service->listar($filtros) ?: [];
            $datosPdf = [];

            foreach ($datosRaw as $row) {
                $datosPdf[] = [
                    'ID'        => (int)($row['id'] ?? 0),
                    'Cliente'   => (string)($row['nombre'] ?? 'Sin nombre'),
                    'CUIT'      => (string)($row['cuit'] ?? 'N/A'),
                    'Email'     => (string)($row['email'] ?? 'N/A'),
                    'Localidad' => (string)($row['localidad_nombre'] ?? 'Desconocida')
                ];
            }

            $pdf = new PdfService();
            $archivo = $pdf->generar('Reporte de Clientes', $datosPdf);
            $pdf->descargar($archivo);

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR EXCEL
    |--------------------------------------------------------------------------
    */
    public function exportarExcel(): void
    {
        $this->requireAuth();

        try {
            $filtros = [
                'texto'        => trim($_GET['texto'] ?? ''),
                'localidad_id' => (int)($_GET['localidad_id'] ?? 0),
                'tarifa_id'    => (int)($_GET['tarifa_id'] ?? 0),
                'activo'       => $_GET['activo'] ?? '',
            ];
            
            $datosRaw = $this->service->listar($filtros) ?: [];
            $datosExcel = [];

            foreach ($datosRaw as $row) {
                $datosExcel[] = [
                    'ID Cliente'   => (int)($row['id'] ?? 0),
                    'Razón Social' => (string)($row['nombre'] ?? 'Sin nombre'),
                    'CUIT'         => (string)($row['cuit'] ?? 'N/A'),
                    'Email'        => (string)($row['email'] ?? 'N/A'),
                    'Teléfono'     => (string)($row['telefono'] ?? 'N/A'),
                    'Dirección'    => (string)($row['direccion'] ?? 'N/A'),
                    'Localidad'    => (string)($row['localidad_nombre'] ?? 'Desconocida'),
                    'Estado'       => !empty($row['activo']) ? 'Activo' : 'Inactivo'
                ];
            }

            $excel = new ExcelService();
            $excel->download($datosExcel, 'reporte_clientes_' . date('Ymd_His') . '.csv');

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR NUEVO REGISTRO
    |--------------------------------------------------------------------------
    */
    public function create(): void
    {
        $this->requireAuth();

        try {
            $this->loadAssets();

            $this->moduleView(
                'Clientes',
                'nuevo',
                [
                    'titulo'      => 'Nuevo Cliente',
                    'localidades' => $this->service->obtenerLocalidades() ?: [],
                    'tarifas'     => $this->service->obtenerTarifas() ?: [],
                    'csrf'        => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR EN BASE DE DATOS
    |--------------------------------------------------------------------------
    */
    public function store(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf();

            $nombre = trim((string)($_POST['nombre'] ?? ''));

            if ($nombre === '') {
                throw new RuntimeException(
                    'El nombre del cliente es obligatorio'
                );
            }

            $id = $this->service->crear($_POST);

            $this->redirect(
                '/admin/clientes/ver/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VER FICHA 360° DEL CLIENTE
    |--------------------------------------------------------------------------
    */
    public function show(int $id): void
    {
        $this->requireAuth();

        try {
            $this->loadAssets();

            if ($id <= 0) {
                throw new RuntimeException('Cliente inválido');
            }

            $cliente = $this->service->find($id);

            if (!$cliente) {
                throw new RuntimeException('Cliente inexistente');
            }

            $this->moduleView(
                'Clientes',
                'ver',
                [
                    'titulo'       => 'Ficha Cliente',
                    'cliente'      => $cliente,
                    'equipos'      => $this->service->obtenerEquipos($id) ?: [],
                    'servicios'    => $this->service->obtenerServicios($id) ?: [],
                    'documentos'   => $this->service->obtenerDocumentos($id) ?: [],
                    'estadisticas' => $this->service->obtenerEstadisticasCliente($id) ?: [],
                    'csrf'         => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR
    |--------------------------------------------------------------------------
    */
    public function edit(int $id): void
    {
        $this->requireAuth();

        try {
            $this->loadAssets();

            $cliente = $this->service->find($id);

            if (!$cliente) {
                throw new RuntimeException('Cliente inexistente');
            }

            $this->moduleView(
                'Clientes',
                'editar',
                [
                    'titulo'      => 'Editar Cliente',
                    'cliente'     => $cliente,
                    'localidades' => $this->service->obtenerLocalidades() ?: [],
                    'tarifas'     => $this->service->obtenerTarifas() ?: [],
                    'csrf'        => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR CAMBIOS (Bypass de validación booleana estricta integrado)
    |--------------------------------------------------------------------------
    */
    public function update(int $id): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf();

            if ($id <= 0) {
                throw new RuntimeException('Cliente inválido');
            }

            // CORRECCIÓN CLAVE: Ejecuta la actualización. Si hay un fallo real de SQL, PDO lanzará
            // una excepción y se capturará en el catch. Si no falla, asumimos éxito (incluso si no hubo cambios).
            $this->service->actualizar($id, $_POST);

            $this->redirect(
                '/admin/clientes/ver/' . $id
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR REGISTRO
    |--------------------------------------------------------------------------
    */
    public function destroy(int $id): void
    {
        $this->requireAuth();

        try {
            if ($id <= 0) {
                throw new RuntimeException('Cliente inválido');
            }

            $this->service->delete($id);

            $this->redirect(
                '/admin/clientes'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }
}