<?php
declare(strict_types=1);

namespace App\Modules\Clientes\Controllers;


use App\Core\BaseController;
use App\Modules\Clientes\Services\Service;
use App\Modules\Clientes\Reports\ExcelReport;
use App\Modules\Clientes\Reports\PdfReport;



final class ReportController extends BaseController
{


    public function __construct(
        private Service $service
    ){}



    public function excel(): void
    {


        $clientes =
            $this->service->filter(
                $_GET
            );


        (new ExcelReport())
            ->download(
                $clientes
            );


    }




    public function pdf(): void
    {


        $clientes =
            $this->service->filter(
                $_GET
            );


        (new PdfReport())
            ->download(
                $clientes
            );


    }



}