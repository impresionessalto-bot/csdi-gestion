<?php

declare(strict_types=1);

namespace App\Modules\Clientes\Controllers;

use App\Core\BaseController;
use App\Modules\Clientes\DTOs\ClienteDTO;
use App\Modules\Clientes\Services\Service;
use Throwable;

final class Api extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    public function listado(): void
    {
        try {
            $this->success(
                $this->service->filter($_GET)
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function buscar(): void
    {
        try {
            $texto = trim((string)($_GET['q'] ?? ''));

            $this->success(
                $this->service->search($texto)
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function obtener(int $id): void
    {
        try {
            $this->success(
                $this->service->find($id)
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function guardar(): void
    {
        try {
            $dto = ClienteDTO::fromArray(
                $this->body()
            );

            $id = $this->service->create($dto);

            $this->success(
                [
                    'id' => $id
                ],
                'Cliente creado correctamente'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function actualizar(int $id): void
    {
        try {
            $dto = ClienteDTO::fromArray(
                $this->body()
            );

            $this->success(
                $this->service->update($id, $dto)
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function eliminar(int $id): void
    {
        try {
            $this->success(
                $this->service->disable($id)
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function restaurar(int $id): void
    {
        try {
            $this->success(
                $this->service->restore($id)
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function tarifas(): void
    {
        $this->success(
            $this->service->tarifas()
        );
    }

    public function localidades(): void
    {
        $this->success(
            $this->service->localidades()
        );
    }

    public function activos(): void
    {
        $this->success(
            $this->service->activos()
        );
    }

    public function stats(): void
    {
        $this->success(
            $this->service->dashboard()
        );
    }
}