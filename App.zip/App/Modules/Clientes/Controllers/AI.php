<?php
declare(strict_types=1);

namespace App\Modules\Clientes\Controllers;


use App\Core\BaseController;
use App\Modules\Clientes\Services\Service;
use Throwable;



final class AI extends BaseController
{


    public function __construct(
        private Service $service
    ){}




    /*
    |--------------------------------------------------------------------------
    | DASHBOARD IA
    |--------------------------------------------------------------------------
    */

    public function dashboard(): void
    {

        try {


            $data =
                $this->service->dashboard();


            $this->json(

                [

                    'success'=>true,

                    'data'=>$data

                ]

            );


        }catch(Throwable $e){


            $this->json(

                [

                    'success'=>false,

                    'message'=>$e->getMessage()

                ],

                400

            );

        }

    }





    /*
    |--------------------------------------------------------------------------
    | ANALISIS CLIENTES
    |--------------------------------------------------------------------------
    */

    public function analyze(): void
    {

        try {


            $stats =
                $this->service->dashboard();



            $this->json(

                [

                    'success'=>true,

                    'analysis'=>[

                        'clientes_total'=>
                            $stats['total'] ?? 0,


                        'clientes_activos'=>
                            $stats['activos'] ?? 0,


                        'clientes_inactivos'=>
                            $stats['inactivos'] ?? 0

                    ]

                ]

            );


        }catch(Throwable $e){


            $this->json(

                [

                    'success'=>false,

                    'message'=>$e->getMessage()

                ],

                400

            );

        }

    }





    /*
    |--------------------------------------------------------------------------
    | CLIENTES IA
    |--------------------------------------------------------------------------
    */

    public function clientes(): void
    {

        try {


            $clientes =
                $this->service->filter([]);



            $this->json(

                [

                    'success'=>true,

                    'data'=>$clientes

                ]

            );


        }catch(Throwable $e){


            $this->json(

                [

                    'success'=>false,

                    'message'=>$e->getMessage()

                ],

                400

            );

        }

    }





    /*
    |--------------------------------------------------------------------------
    | RECOMENDACIONES
    |--------------------------------------------------------------------------
    */

    public function recommendations(): void
    {

        $this->json(

            [

                'success'=>true,

                'data'=>[

                    'mensaje'=>
                    'Módulo IA Clientes preparado.'

                ]

            ]

        );

    }


}