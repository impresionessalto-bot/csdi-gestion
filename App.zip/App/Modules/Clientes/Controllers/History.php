<?php
declare(strict_types=1);

namespace App\Modules\Clientes\Controllers;


use App\Core\BaseController;
use App\Modules\Clientes\Services\Service;
use Throwable;



final class History extends BaseController
{


    public function __construct(
        private Service $service
    ){}




    /*
    |--------------------------------------------------------------------------
    | PANTALLA HISTORIAL
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {

        try {


            $this->view(

                'clientes/historial',

                [

                    'titulo'=>'Historial de Clientes'

                ]

            );


        }catch(Throwable $e){


            $this->error(
                $e->getMessage()
            );

        }

    }





    /*
    |--------------------------------------------------------------------------
    | LISTADO HISTORIAL AJAX
    |--------------------------------------------------------------------------
    */

    public function listado(): void
    {

        try {


            $id =
                (int)(
                    $_GET['cliente_id'] ?? 0
                );



            $historial =
                $this->service->history(
                    $id
                );



            $this->json(

                [

                    'success'=>true,

                    'data'=>$historial

                ]

            );


        }catch(Throwable $e){


            $this->json(

                [

                    'success'=>false,

                    'message'=>$e->getMessage()

                ],

                400

            );

        }

    }



}