<?php

declare(strict_types=1);

namespace App\Modules\Ventas;

use App\Core\Module as CoreModule;

/**
 * =========================================================
 *
 * ERP CSDI PRO
 *
 * MÓDULO VENTAS
 *
 * =========================================================
 */
final class Module extends CoreModule
{
    /**
     * Nombre del módulo
     */
    public function name(): string
    {
        return 'Ventas';
    }

    /**
     * Descripción
     */
    public function description(): string
    {
        return 'Gestión de ventas, clientes, productos y operaciones comerciales.';
    }

    /**
     * Versión
     */
    public function version(): string
    {
        return '1.0.0';
    }

    /**
     * Archivo de rutas
     */
    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    /**
     * Prioridad de carga
     */
    public function priority(): int
    {
        return 40;
    }

    /**
     * Menú lateral
     */
    public function menu(): array
    {
        return [
            [
                'title' =>
                    'Ventas',

                'icon' =>
                    'fa-solid fa-cart-shopping',

                'url' =>
                    '/ventas',

                'group' =>
                    'Comercial',

                'order' =>
                    10,

                'permission' =>
                    'ventas.ver',

                'visible' =>
                    true,

                'children' =>
                    []
            ]
        ];
    }

    /**
     * Icono
     */
    public function icon(): string
    {
        return 'fa-solid fa-cart-shopping';
    }

    /**
     * URL principal
     */
    public function url(): string
    {
        return '/ventas';
    }

    /**
     * Grupo del menú
     */
    public function group(): string
    {
        return 'Comercial';
    }

    /**
     * Orden del menú
     */
    public function order(): int
    {
        return 10;
    }

    /**
     * Permisos
     */
    public function permissions(): array
    {
        return [
            'ventas.ver',
            'ventas.crear',
            'ventas.editar',
            'ventas.eliminar',
        ];
    }

    /**
     * Dependencias
     */
    public function dependencies(): array
    {
        return [
            'Clientes',
        ];
    }

    /**
     * Widgets
     */
    public function widgets(): array
    {
        return [];
    }

    /**
     * KPIs
     */
    public function kpis(): array
    {
        return [];
    }

    /**
     * Módulo activo
     */
    public function enabled(): bool
    {
        return true;
    }

    /**
     * Inicialización
     */
    public function boot(): void
    {
        /*
         * Eventos e integraciones futuras.
         */
    }
}