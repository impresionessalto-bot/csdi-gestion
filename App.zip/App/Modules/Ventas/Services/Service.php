<?php

declare(strict_types=1);

namespace App\Modules\Ventas\Services;

use App\Modules\Ventas\Repositories\Repository;
use App\Modules\Clientes\Services\Service as ClienteService;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class Service
{
    public function __construct(
        private readonly Repository $repository,
        private readonly ?ClienteService $clienteService = null
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        return [
            'resumen' => $this->repository->dashboard(),
            'ventas'  => $this->repository->ultimasVentas(10),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTE CONSUMIDOR FINAL
    |--------------------------------------------------------------------------
    */

    public function clienteConsumidorFinal(): array
    {
        return [
            'id'               => null,
            'nombre'           => 'Consumidor Final',
            'nombre_fantasia'  => '',
            'categoria_fiscal' => 'Consumidor Final',
            'tipo_doc'         => '',
            'nro_doc'          => '',
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | USUARIO
    |--------------------------------------------------------------------------
    */

    public function usuarioActual(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->usuario($id);
    }

    public function vendedores(): array
    {
        return $this->repository->vendedores();
    }

    /*
    |--------------------------------------------------------------------------
    | ARTICULOS
    |--------------------------------------------------------------------------
    */

    public function buscarArticulos(
        string $termino,
        int $limit = 20,
        int $listaPrecioId = 0
    ): array {
        $termino = trim($termino);

        if ($termino === '') {
            return [];
        }

        $limit = min(50, max(1, $limit));

        return $this->repository->buscarArticulos(
            $termino,
            $limit,
            max(0, $listaPrecioId)
        );
    }

    public function obtenerArticulo(
        int $id,
        int $listaPrecioId = 0
    ): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->obtenerArticulo(
            $id,
            max(0, $listaPrecioId)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function buscarClientes(
        string $termino,
        int $limit = 20
    ): array {
        $termino = trim($termino);

        if ($termino === '') {
            return [];
        }

        $limit = min(50, max(1, $limit));

        return $this->repository->buscarClientes(
            $termino,
            $limit
        );
    }

    public function obtenerCliente(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->obtenerCliente($id);
    }

    public function crearCliente(array $data): array
    {
        $nombre = trim(
            (string)($data['nombre'] ?? '')
        );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El nombre del cliente es obligatorio.'
            );
        }

        if ($this->clienteService === null) {
            throw new RuntimeException(
                'El servicio maestro de Clientes no está disponible.'
            );
        }

        $id = $this->clienteService->crear([
            'nombre' => mb_substr($nombre, 0, 255),
            'nombre_fantasia' => trim((string)($data['nombre_fantasia'] ?? '')),
            'tipo_cliente' => trim((string)($data['tipo_cliente'] ?? 'Externo')),
            'direccion' => trim((string)($data['direccion'] ?? '')),
            'telefono' => trim((string)($data['telefono'] ?? '')),
            'email' => trim((string)($data['email'] ?? '')),
            'categoria_fiscal' => trim((string)($data['categoria_fiscal'] ?? 'Consumidor Final')),
            'tipo_doc' => trim((string)($data['tipo_doc'] ?? '')),
            'nro_doc' => trim((string)($data['nro_doc'] ?? '')),
            'localidad_id' => !empty($data['localidad_id']) ? (int)$data['localidad_id'] : null,
            'persona_contacto' => trim((string)($data['persona_contacto'] ?? '')),
        ]);

        $cliente = $this->clienteService->find($id);

        if (!$cliente) {
            throw new RuntimeException(
                'El cliente fue creado pero no pudo ser recuperado.'
            );
        }

        return $cliente;
    }

    /*
    |--------------------------------------------------------------------------
    | COMPROBANTES
    |--------------------------------------------------------------------------
    */

    public function siguienteComprobante(
        string $tipo = 'COMPROBANTE',
        int $puntoVenta = 1
    ): array {
        $tipo = strtoupper(
            trim($tipo)
        );

        /*
         * Por ahora Ventas administra solamente
         * el comprobante interno.
         *
         * FACTURA_A será manejada posteriormente
         * por el módulo de Facturación/Dux.
         */

        if ($tipo !== 'COMPROBANTE') {
            throw new InvalidArgumentException(
                'El tipo de comprobante seleccionado todavía no está habilitado para Ventas.'
            );
        }

        if (
            $puntoVenta < 1
            ||
            $puntoVenta > 99999
        ) {
            throw new InvalidArgumentException(
                'Punto de venta inválido.'
            );
        }

        return $this->repository->siguienteComprobante(
            $tipo,
            $puntoVenta
        );
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function listarVentas(
        array $filtros
    ): array {
        return $this->repository->listarVentas(
            $filtros
        );
    }

    public function obtenerVenta(
        int $id
    ): ?array {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->obtenerVenta(
            $id
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CONFIRMAR VENTA
    |--------------------------------------------------------------------------
    */

    public function confirmar(
        array $data,
        int $usuarioId
    ): array {
        if ($usuarioId <= 0) {
            throw new InvalidArgumentException(
                'No se pudo identificar al usuario actual.'
            );
        }

        if (
            !$this->repository->usuarioActivo(
                $usuarioId
            )
        ) {
            throw new InvalidArgumentException(
                'El usuario actual no está habilitado.'
            );
        }

        $tipo = strtoupper(
            trim(
                (string)(
                    $data['tipo_comprobante']
                    ?? 'COMPROBANTE'
                )
            )
        );

        /*
         * Ventas actualmente registra el
         * comprobante interno.
         */

        if ($tipo !== 'COMPROBANTE') {
            throw new InvalidArgumentException(
                'Para esta pantalla debe utilizarse el comprobante interno. Presupuestos, pedidos, remitos y facturas tienen circuitos propios.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | ITEMS
        |--------------------------------------------------------------------------
        */

        $items =
            $data['items']
            ?? [];

        if (
            !is_array($items)
            ||
            count($items) === 0
        ) {
            throw new InvalidArgumentException(
                'La venta debe contener al menos un artículo.'
            );
        }

        if (count($items) > 500) {
            throw new InvalidArgumentException(
                'La venta supera la cantidad máxima de líneas permitidas.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CLIENTE
        |--------------------------------------------------------------------------
        */

        $clienteId =
            $this->normalizarId(
                $data['cliente_id']
                ?? null
            );

        $cliente = null;

        if ($clienteId !== null) {
            $cliente =
                $this->repository->obtenerCliente(
                    $clienteId
                );

            if (!$cliente) {
                throw new InvalidArgumentException(
                    'El cliente seleccionado no existe o está inactivo.'
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | VENDEDOR
        |--------------------------------------------------------------------------
        */

        $vendedorId =
            $this->normalizarId(
                $data['vendedor_id']
                ?? null
            );

        if ($vendedorId === null) {
            $vendedorId = $usuarioId;
        }

        if (
            !$this->repository->usuarioActivo(
                $vendedorId
            )
        ) {
            throw new InvalidArgumentException(
                'El vendedor seleccionado no está habilitado.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | PUNTO DE VENTA
        |--------------------------------------------------------------------------
        */

        $puntoVenta =
            $this->normalizarEntero(
                $data['punto_venta']
                ?? 1
            );

        if (
            $puntoVenta < 1
            ||
            $puntoVenta > 99999
        ) {
            throw new InvalidArgumentException(
                'Punto de venta inválido.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | NUMERO
        |--------------------------------------------------------------------------
        */

        $numero =
            $this->normalizarEntero(
                $data['numero_comprobante']
                ?? 0
            );

        if ($numero < 0) {
            $numero = 0;
        }

        /*
        |--------------------------------------------------------------------------
        | FECHA
        |--------------------------------------------------------------------------
        */

        $fecha =
            trim(
                (string)(
                    $data['fecha']
                    ?? ''
                )
            );

        if ($fecha !== '') {
            $timestamp =
                strtotime($fecha);

            if ($timestamp === false) {
                throw new InvalidArgumentException(
                    'La fecha indicada no es válida.'
                );
            }

            $fecha =
                date(
                    'Y-m-d H:i:s',
                    $timestamp
                );
        } else {
            $fecha =
                date(
                    'Y-m-d H:i:s'
                );
        }

        /*
        |--------------------------------------------------------------------------
        | TOTALES
        |--------------------------------------------------------------------------
        */

        $itemsNormalizados = [];

        $subtotalVenta = 0.0;
        $descuentoTotal = 0.0;
        $impuestoTotal = 0.0;
        $totalVenta = 0.0;

        foreach (
            $items as $index => $item
        ) {
            $numeroLinea =
                (int)$index + 1;

            if (!is_array($item)) {
                throw new InvalidArgumentException(
                    "Artículo inválido en la línea {$numeroLinea}."
                );
            }

            $tipoItem =
                strtoupper(
                    trim(
                        (string)(
                            $item['tipo']
                            ?? 'INSUMO'
                        )
                    )
                );

            if ($tipoItem !== 'INSUMO') {
                throw new InvalidArgumentException(
                    "La línea {$numeroLinea} contiene un tipo de artículo no permitido."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | INSUMO
            |--------------------------------------------------------------------------
            */

            $insumoId =
                $this->normalizarId(
                    $item['insumo_id']
                    ?? null
                );

            if ($insumoId === null) {
                throw new InvalidArgumentException(
                    "La línea {$numeroLinea} no tiene un artículo válido."
                );
            }

            /*
             * IMPORTANTE:
             * volvemos a consultar el artículo
             * directamente en la base.
             */

            $articulo =
                $this->repository->obtenerArticulo(
                    $insumoId
                );

            if (!$articulo) {
                throw new InvalidArgumentException(
                    "El artículo #{$insumoId} no existe o está inactivo."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CANTIDAD
            |--------------------------------------------------------------------------
            */

            $cantidad =
                $this->decimal(
                    $item['cantidad']
                    ?? 0
                );

            if (
                $cantidad <= 0
            ) {
                throw new InvalidArgumentException(
                    "La cantidad de la línea {$numeroLinea} debe ser mayor a cero."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | PRECIO
            |--------------------------------------------------------------------------
            */

            $precio =
                $this->decimal(
                    $item['precio_unitario']
                    ??
                    $item['precio']
                    ??
                    $articulo['precio_venta']
                    ??
                    0
                );

            if ($precio < 0) {
                throw new InvalidArgumentException(
                    "El precio de la línea {$numeroLinea} no puede ser negativo."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | DESCUENTO
            |--------------------------------------------------------------------------
            */

            $descuento =
                $this->decimal(
                    $item['descuento']
                    ?? 0
                );

            if ($descuento < 0) {
                $descuento = 0;
            }

            /*
            |--------------------------------------------------------------------------
            | IVA
            |--------------------------------------------------------------------------
            */

            $impuestoPorcentaje =
                $this->decimal(
                    $item['impuesto_porcentaje']
                    ??
                    $item['iva']
                    ??
                    21
                );

            if (
                $impuestoPorcentaje < 0
                ||
                $impuestoPorcentaje > 100
            ) {
                throw new InvalidArgumentException(
                    "El IVA de la línea {$numeroLinea} debe estar entre 0 y 100."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CALCULOS
            |--------------------------------------------------------------------------
            */

            $bruto =
                round(
                    $cantidad * $precio,
                    2
                );

            if (
                $descuento > $bruto
            ) {
                $descuento = $bruto;
            }

            $neto =
                round(
                    $bruto - $descuento,
                    2
                );

            $impuestoImporte =
                round(
                    $neto
                    *
                    (
                        $impuestoPorcentaje
                        / 100
                    ),
                    2
                );

            $subtotal =
                round(
                    $neto
                    +
                    $impuestoImporte,
                    2
                );

            /*
            |--------------------------------------------------------------------------
            | STOCK
            |--------------------------------------------------------------------------
            */

            $stock =
                (float)(
                    $articulo['stock_actual']
                    ?? 0
                );

            if (
                $cantidad > $stock
            ) {
                throw new InvalidArgumentException(
                    'Stock insuficiente para "' .
                    (
                        $articulo['nombre_insumo']
                        ?? 'Artículo'
                    ) .
                    '". Disponible: ' .
                    $this->formatearNumero(
                        $stock
                    ) .
                    '.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | DESCRIPCION
            |--------------------------------------------------------------------------
            */

            $descripcion =
                trim(
                    (string)(
                        $item['descripcion']
                        ??
                        $articulo['nombre_insumo']
                        ??
                        ''
                    )
                );

            if ($descripcion === '') {
                $descripcion =
                    'Artículo #' .
                    $insumoId;
            }

            $descripcion =
                mb_substr(
                    $descripcion,
                    0,
                    255
                );

            /*
            |--------------------------------------------------------------------------
            | ITEM NORMALIZADO
            |--------------------------------------------------------------------------
            */

            $itemsNormalizados[] = [
                'tipo' =>
                    'INSUMO',

                'insumo_id' =>
                    $insumoId,

                'servicio_id' =>
                    null,

                'descripcion' =>
                    $descripcion,

                'cantidad' =>
                    $cantidad,

                'precio_unitario' =>
                    $precio,

                'descuento' =>
                    $descuento,

                'neto' =>
                    $neto,

                'impuesto_tipo' =>
                    'IVA',

                'impuesto_porcentaje' =>
                    $impuestoPorcentaje,

                'impuesto_importe' =>
                    $impuestoImporte,

                'subtotal' =>
                    $subtotal,
            ];

            $subtotalVenta +=
                $neto;

            $descuentoTotal +=
                $descuento;

            $impuestoTotal +=
                $impuestoImporte;

            $totalVenta +=
                $subtotal;
        }

        $subtotalVenta =
            round(
                $subtotalVenta,
                2
            );

        $descuentoTotal =
            round(
                $descuentoTotal,
                2
            );

        $impuestoTotal =
            round(
                $impuestoTotal,
                2
            );

        $totalVenta =
            round(
                $totalVenta,
                2
            );

        /*
        |--------------------------------------------------------------------------
        | NOMBRES
        |--------------------------------------------------------------------------
        */

        $vendedor =
            $this->repository->usuario(
                $vendedorId
            );

        $clienteNombre =
            $cliente
                ? trim(
                    (string)(
                        $cliente['nombre']
                        ??
                        $cliente['razon_social']
                        ??
                        ''
                    )
                )
                : 'Consumidor Final';

        if ($clienteNombre === '') {
            $clienteNombre =
                'Consumidor Final';
        }

        $vendedorNombre =
            $vendedor
                ? trim(
                    (string)(
                        $vendedor['nombre']
                        ??
                        $vendedor['usuario']
                        ??
                        ''
                    )
                )
                : '';

        /*
        |--------------------------------------------------------------------------
        | REGISTRAR
        |--------------------------------------------------------------------------
        */

        return $this->repository->registrarVenta([
            'fecha' =>
                $fecha,

            'cliente_id' =>
                $clienteId,

            'cliente_nombre' =>
                $clienteNombre,

            'tipo_comprobante' =>
                $tipo,

            'punto_venta' =>
                $puntoVenta,

            'numero_comprobante' =>
                $numero,

            'vendedor_id' =>
                $vendedorId,

            'vendedor_nombre' =>
                $vendedorNombre,

            'subtotal' =>
                $subtotalVenta,

            'descuento_total' =>
                $descuentoTotal,

            'impuesto_total' =>
                $impuestoTotal,

            'total_venta' =>
                $totalVenta,

            'items' =>
                $itemsNormalizados,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS
    |--------------------------------------------------------------------------
    */

    private function normalizarId(
        mixed $value
    ): ?int {
        if (
            $value === null
            ||
            $value === ''
        ) {
            return null;
        }

        $id =
            filter_var(
                $value,
                FILTER_VALIDATE_INT
            );

        if (
            $id === false
            ||
            $id <= 0
        ) {
            return null;
        }

        return (int)$id;
    }

    private function normalizarEntero(
        mixed $value
    ): int {
        if (
            $value === null
            ||
            $value === ''
        ) {
            return 0;
        }

        return (int)$value;
    }

    private function decimal(
        mixed $value
    ): float {
        if (
            $value === null
            ||
            $value === ''
        ) {
            return 0.0;
        }

        if (is_string($value)) {
            $value =
                trim($value);

            if (
                str_contains(
                    $value,
                    ','
                )
                &&
                str_contains(
                    $value,
                    '.'
                )
            ) {
                $value =
                    str_replace(
                        '.',
                        '',
                        $value
                    );

                $value =
                    str_replace(
                        ',',
                        '.',
                        $value
                    );
            } elseif (
                str_contains(
                    $value,
                    ','
                )
            ) {
                $value =
                    str_replace(
                        ',',
                        '.',
                        $value
                    );
            }
        }

        if (!is_numeric($value)) {
            return 0.0;
        }

        return (float)$value;
    }

    private function formatearNumero(
        float $value
    ): string {
        return number_format(
            $value,
            3,
            ',',
            '.'
        );
    }
}