<?php

declare(strict_types=1);

namespace App\Modules\Ventas\Controllers;

use App\Core\BaseController;
use App\Modules\Ventas\Services\Service;
use InvalidArgumentException;
use Throwable;

/**
 * =========================================================
 *
 * ERP CSDI PRO
 *
 * VENTAS - CONTROLLER
 *
 * Flujo:
 *
 * Controller
 *     ↓
 * Service
 *     ↓
 * Repository
 *
 * Las vistas pertenecen al módulo:
 *
 * App/Modules/Ventas/Views/
 *
 * Por eso se utiliza:
 *
 * $this->moduleView('Ventas', 'vista', $data);
 *
 * =========================================================
 */
final class Controller extends BaseController
{
    /*
    |--------------------------------------------------------------------------
    | CONSTRUCTOR
    |--------------------------------------------------------------------------
    */

    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }


    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->dashboard();

            $this->moduleView(
                'Ventas',
                'index',
                $data
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | NUEVA VENTA
    |--------------------------------------------------------------------------
    */

    public function nueva(): void
    {
        $this->requireAuth();

        try {

            $usuario =
                $this->usuarioActual();


            $cliente =
                $this->service
                    ->clienteConsumidorFinal();


            $vendedores =
                $this->service
                    ->vendedores();


            $comprobante =
                $this->service
                    ->siguienteComprobante();


            $data = [

                'usuario' =>
                    $usuario,

                'cliente' =>
                    $cliente,

                'vendedores' =>
                    $vendedores,

                'comprobante' =>
                    $comprobante,

                'csrf' =>
                    $this->csrf(),

            ];


            /*
             * IMPORTANTE:
             *
             * Las vistas de Ventas están en:
             *
             * App/Modules/Ventas/Views/
             *
             */

            $this->moduleView(
                'Ventas',
                'nueva',
                $data
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | LISTADO
    |--------------------------------------------------------------------------
    */

    public function listado(): void
    {
        $this->requireAuth();

        try {

            $filtros = [

                'buscar' =>
                    trim(
                        (string) (
                            $_GET['buscar']
                            ?? ''
                        )
                    ),

                'cliente_id' =>
                    $this->nullableInt(
                        $_GET['cliente_id']
                        ?? null
                    ),

                'vendedor_id' =>
                    $this->nullableInt(
                        $_GET['vendedor_id']
                        ?? null
                    ),

                'estado' =>
                    trim(
                        (string) (
                            $_GET['estado']
                            ?? ''
                        )
                    ),

                'desde' =>
                    trim(
                        (string) (
                            $_GET['desde']
                            ?? ''
                        )
                    ),

                'hasta' =>
                    trim(
                        (string) (
                            $_GET['hasta']
                            ?? ''
                        )
                    ),

                'limit' =>
                    $this->limit(
                        $_GET['limit']
                        ?? 100
                    ),

            ];


            $ventas =
                $this->service
                    ->listarVentas(
                        $filtros
                    );


            $data = [

                'ventas' =>
                    $ventas,

                'filtros' =>
                    $filtros,

            ];


            $this->moduleView(
                'Ventas',
                'listado',
                $data
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | VER VENTA
    |--------------------------------------------------------------------------
    */

    public function ver(
        int|string $id
    ): void {
        $this->requireAuth();

        try {

            $id =
                $this->positiveId(
                    $id
                );


            $venta =
                $this->service
                    ->obtenerVenta(
                        $id
                    );


            if (!$venta) {

                $this->notFound(
                    'Venta no encontrada.'
                );
            }


            $data = [

                'venta' =>
                    $venta,

            ];


            $this->moduleView(
                'Ventas',
                'ver',
                $data
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | EDITAR VENTA
    |--------------------------------------------------------------------------
    */

    public function editar(
        int|string $id
    ): void {
        $this->requireAuth();

        try {

            $id =
                $this->positiveId(
                    $id
                );


            $venta =
                $this->service
                    ->obtenerVenta(
                        $id
                    );


            if (!$venta) {

                $this->notFound(
                    'Venta no encontrada.'
                );
            }


            $data = [

                'venta' =>
                    $venta,

            ];


            $this->moduleView(
                'Ventas',
                'editar',
                $data
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    |
    | Se mantiene preparado para la segunda etapa.
    |
    */

    public function actualizar(
        int|string $id
    ): never {
        $this->requireAuth();

        try {

            $id =
                $this->positiveId(
                    $id
                );


            /*
             * Todavía no habilitamos edición
             * porque modificar una venta confirmada
             * implica revertir correctamente:
             *
             * - stock
             * - impuestos
             * - totales
             * - comprobante
             * - trazabilidad
             *
             * El Service será el encargado cuando
             * implementemos esta operación.
             */

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        'La edición de ventas todavía no está habilitada.',
                    'id' =>
                        $id,
                ],
                501
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | ANULAR
    |--------------------------------------------------------------------------
    */

    public function anular(
        int|string $id
    ): never {
        $this->requireAuth();

        try {

            $id =
                $this->positiveId(
                    $id
                );


            /*
             * La anulación se implementará
             * conjuntamente con la devolución
             * del stock y la trazabilidad.
             */

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        'La anulación de ventas todavía no está habilitada.',
                    'id' =>
                        $id,
                ],
                501
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PRESUPUESTOS
    |--------------------------------------------------------------------------
    */

    public function presupuestos(): void
    {
        $this->requireAuth();

        try {

            $this->moduleView(
                'Ventas',
                'presupuestos',
                []
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PEDIDOS
    |--------------------------------------------------------------------------
    */

    public function pedidos(): void
    {
        $this->requireAuth();

        try {

            $this->moduleView(
                'Ventas',
                'pedidos',
                []
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | REMITOS
    |--------------------------------------------------------------------------
    */

    public function remitos(): void
    {
        $this->requireAuth();

        try {

            $this->moduleView(
                'Ventas',
                'remitos',
                []
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | FACTURACIÓN
    |--------------------------------------------------------------------------
    */

    public function facturacion(): void
    {
        $this->requireAuth();

        try {

            $this->moduleView(
                'Ventas',
                'facturacion',
                []
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - BUSCAR ARTÍCULOS
    |--------------------------------------------------------------------------
    |
    | GET /ventas/api/articulos?q=toner
    |
    */

    public function buscarArticulos(): never
    {
        $this->requireAuth();

        try {

            $termino =
                trim(
                    (string) (
                        $_GET['q']
                        ??
                        $_GET['buscar']
                        ??
                        ''
                    )
                );


            $limit =
                $this->limit(
                    $_GET['limit']
                    ?? 20
                );

            $listaPrecioId =
                max(
                    0,
                    (int)(
                        $_GET['lista_precio_id']
                        ?? 0
                    )
                );


            $articulos =
                $this->service
                    ->buscarArticulos(
                        $termino,
                        $limit,
                        $listaPrecioId
                    );


            $this->json(
                [
                    'success' => true,
                    'data' =>
                        $articulos,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - OBTENER ARTÍCULO
    |--------------------------------------------------------------------------
    |
    | GET /ventas/api/articulos/{id}
    |
    */

    public function obtenerArticulo(
        int|string $id
    ): never {
        $this->requireAuth();

        try {

            $id =
                $this->positiveId(
                    $id
                );


            $listaPrecioId =
                max(
                    0,
                    (int)(
                        $_GET['lista_precio_id']
                        ?? 0
                    )
                );

            $articulo =
                $this->service
                    ->obtenerArticulo(
                        $id,
                        $listaPrecioId
                    );


            if (!$articulo) {

                $this->json(
                    [
                        'success' => false,
                        'message' =>
                            'Artículo no encontrado.',
                    ],
                    404
                );
            }


            $this->json(
                [
                    'success' => true,
                    'data' =>
                        $articulo,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - BUSCAR CLIENTES
    |--------------------------------------------------------------------------
    |
    | GET /ventas/api/clientes?q=cliente
    |
    */

    public function buscarClientes(): never
    {
        $this->requireAuth();

        try {

            $termino =
                trim(
                    (string) (
                        $_GET['q']
                        ??
                        $_GET['buscar']
                        ??
                        ''
                    )
                );


            $limit =
                $this->limit(
                    $_GET['limit']
                    ?? 20
                );


            $clientes =
                $this->service
                    ->buscarClientes(
                        $termino,
                        $limit
                    );


            $this->json(
                [
                    'success' => true,
                    'data' =>
                        $clientes,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - OBTENER CLIENTE
    |--------------------------------------------------------------------------
    |
    | GET /ventas/api/clientes/{id}
    |
    */

    public function obtenerCliente(
        int|string $id
    ): never {
        $this->requireAuth();

        try {

            $id =
                $this->positiveId(
                    $id
                );


            $cliente =
                $this->service
                    ->obtenerCliente(
                        $id
                    );


            if (!$cliente) {

                $this->json(
                    [
                        'success' => false,
                        'message' =>
                            'Cliente no encontrado.',
                    ],
                    404
                );
            }


            $this->json(
                [
                    'success' => true,
                    'data' =>
                        $cliente,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - CREAR CLIENTE
    |--------------------------------------------------------------------------
    |
    | POST /ventas/api/clientes
    |
    */

    public function crearCliente(): never
    {
        $this->requireAuth();

        try {

            if (!$this->validateCsrf()) {
                $this->json(
                    [
                        'success' => false,
                        'message' => 'Token de seguridad inválido o expirado.',
                    ],
                    403
                );
            }

            $data =
                $this->requestData();


            /*
             * El Service valida y normaliza
             * los datos antes de persistir.
             */

            $cliente =
                $this->service
                    ->crearCliente(
                        $data
                    );


            $this->created(
                $cliente,
                'Cliente creado correctamente.'
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - VENDEDORES
    |--------------------------------------------------------------------------
    |
    | GET /ventas/api/vendedores
    |
    */

    public function vendedores(): never
    {
        $this->requireAuth();

        try {

            $vendedores =
                $this->service
                    ->vendedores();


            $this->json(
                [
                    'success' => true,
                    'data' =>
                        $vendedores,
                ]
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - SIGUIENTE COMPROBANTE
    |--------------------------------------------------------------------------
    |
    | GET /ventas/api/siguiente-comprobante
    |
    */

    public function siguienteComprobante(): never
    {
        $this->requireAuth();

        try {

            $tipo =
                strtoupper(
                    trim(
                        (string) (
                            $_GET['tipo']
                            ??
                            'COMPROBANTE'
                        )
                    )
                );


            $puntoVenta =
                $this->positiveInt(
                    $_GET['punto_venta']
                    ?? 1
                );


            $comprobante =
                $this->service
                    ->siguienteComprobante(
                        $tipo,
                        $puntoVenta
                    );


            $this->json(
                [
                    'success' => true,
                    'data' =>
                        $comprobante,
                ]
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | API - CONFIRMAR VENTA
    |--------------------------------------------------------------------------
    |
    | POST /ventas/api/confirmar
    |
    */

    public function confirmar(): never
    {
        $this->requireAuth();

        try {

            if (!$this->validateCsrf()) {
                $this->json(
                    [
                        'success' => false,
                        'message' => 'Token de seguridad inválido o expirado.',
                    ],
                    403
                );
            }

            /*
             * El usuario autenticado es siempre
             * obtenido del sistema de autenticación.
             *
             * Nunca confiamos en un usuario enviado
             * desde JavaScript.
             */

            $usuarioId =
                $this->userId();


            if (!$usuarioId) {

                $this->unauthorized(
                    'No se pudo identificar al usuario actual.'
                );
            }


            $data =
                $this->requestData();


            /*
             * El Service realiza:
             *
             * - validación de comprobante
             * - validación de cliente
             * - validación de vendedor
             * - validación de artículos
             * - validación de cantidades
             * - validación de precios
             * - validación de descuentos
             * - validación de impuestos
             * - cálculo de totales
             * - control de stock
             */

            $venta =
                $this->service
                    ->confirmar(
                        $data,
                        (int) $usuarioId
                    );


            $this->created(
                $venta,
                'Venta registrada correctamente.'
            );

        } catch (InvalidArgumentException $e) {

            $this->json(
                [
                    'success' => false,
                    'message' =>
                        $e->getMessage(),
                ],
                422
            );

        } catch (Throwable $e) {

            /*
             * En modo desarrollo se conserva
             * la información completa mediante
             * BaseController::exception().
             *
             * En producción se devuelve el error
             * controlado correspondiente.
             */

            $this->exception($e);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | USUARIO ACTUAL
    |--------------------------------------------------------------------------
    */

    private function usuarioActual(): array
    {
        $usuarioId =
            $this->userId();


        if (!$usuarioId) {
            return $this->user();
        }


        try {

            $usuario =
                $this->service
                    ->usuarioActual(
                        (int) $usuarioId
                    );


            if (is_array($usuario)) {
                return $usuario;
            }

        } catch (Throwable) {
            /*
             * Si por algún motivo el Service
             * no puede recuperar los datos,
             * usamos Auth::user().
             */
        }


        return $this->user();
    }


    /*
    |--------------------------------------------------------------------------
    | REQUEST DATA
    |--------------------------------------------------------------------------
    |
    | Acepta:
    |
    | application/json
    |
    | o
    |
    | application/x-www-form-urlencoded
    | multipart/form-data
    |
    */

    private function requestData(): array
    {
        $contentType =
            strtolower(
                (string) (
                    $_SERVER['CONTENT_TYPE']
                    ??
                    ''
                )
            );


        /*
         * JSON
         */

        if (
            str_contains(
                $contentType,
                'application/json'
            )
        ) {

            $raw =
                file_get_contents(
                    'php://input'
                );


            if (
                $raw === false
                ||
                trim($raw) === ''
            ) {
                return [];
            }


            $decoded =
                json_decode(
                    $raw,
                    true
                );


            if (
                !is_array($decoded)
                ||
                json_last_error()
                    !== JSON_ERROR_NONE
            ) {

                throw new InvalidArgumentException(
                    'El cuerpo JSON de la solicitud no es válido.'
                );
            }


            return $decoded;
        }


        /*
         * Form POST
         */

        if (
            !empty($_POST)
        ) {

            return $_POST;
        }


        /*
         * Último intento:
         *
         * algunas peticiones pueden llegar
         * sin Content-Type correctamente definido.
         */

        $raw =
            file_get_contents(
                'php://input'
            );


        if (
            $raw !== false
            &&
            trim($raw) !== ''
        ) {

            $decoded =
                json_decode(
                    $raw,
                    true
                );


            if (
                is_array($decoded)
                &&
                json_last_error()
                    === JSON_ERROR_NONE
            ) {
                return $decoded;
            }
        }


        return [];
    }


    /*
    |--------------------------------------------------------------------------
    | INTEGER OPCIONAL
    |--------------------------------------------------------------------------
    */

    private function nullableInt(
        mixed $value
    ): ?int {

        if (
            $value === null
            ||
            $value === ''
        ) {
            return null;
        }


        if (
            !is_numeric($value)
        ) {
            return null;
        }


        $value =
            (int) $value;


        return $value > 0
            ? $value
            : null;
    }


    /*
    |--------------------------------------------------------------------------
    | INTEGER POSITIVO
    |--------------------------------------------------------------------------
    */

    private function positiveId(
        int|string $id
    ): int {

        if (
            !is_numeric($id)
        ) {

            throw new InvalidArgumentException(
                'Identificador inválido.'
            );
        }


        $id =
            (int) $id;


        if ($id <= 0) {

            throw new InvalidArgumentException(
                'Identificador inválido.'
            );
        }


        return $id;
    }


    /*
    |--------------------------------------------------------------------------
    | INTEGER POSITIVO
    |--------------------------------------------------------------------------
    */

    private function positiveInt(
        mixed $value
    ): int {

        if (
            !is_numeric($value)
        ) {

            throw new InvalidArgumentException(
                'El valor debe ser un número entero positivo.'
            );
        }


        $value =
            (int) $value;


        if ($value <= 0) {

            throw new InvalidArgumentException(
                'El valor debe ser un número entero positivo.'
            );
        }


        return $value;
    }


    /*
    |--------------------------------------------------------------------------
    | LIMIT
    |--------------------------------------------------------------------------
    */

    private function limit(
        mixed $value
    ): int {

        if (
            !is_numeric($value)
        ) {
            return 100;
        }


        $limit =
            (int) $value;


        if ($limit < 1) {
            $limit = 1;
        }


        if ($limit > 500) {
            $limit = 500;
        }


        return $limit;
    }
}