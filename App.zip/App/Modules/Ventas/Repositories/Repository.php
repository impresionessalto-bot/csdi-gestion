<?php

declare(strict_types=1);

namespace App\Modules\Ventas\Repositories;

use PDO;
use RuntimeException;
use Throwable;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        $sql = "
            SELECT
                COUNT(*) AS cantidad_ventas,

                COALESCE(
                    SUM(total_venta),
                    0
                ) AS total_vendido,

                SUM(
                    CASE
                        WHEN DATE(fecha) = CURDATE()
                        THEN 1
                        ELSE 0
                    END
                ) AS ventas_hoy,

                COALESCE(
                    SUM(
                        CASE
                            WHEN DATE(fecha) = CURDATE()
                            THEN total_venta
                            ELSE 0
                        END
                    ),
                    0
                ) AS total_hoy

            FROM ventas

            WHERE estado <> 'ANULADA'
        ";

        $stmt =
            $this->db->query($sql);

        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            )
            ?: [];
    }

    public function ultimasVentas(
        int $limit = 10
    ): array {
        $limit =
            min(
                100,
                max(
                    1,
                    $limit
                )
            );

        $sql = "
            SELECT
                v.id,
                v.fecha,
                v.cliente_id,
                v.cliente_nombre,
                v.tipo_comprobante,
                v.punto_venta,
                v.numero_comprobante,
                v.vendedor_id,
                v.vendedor_nombre,
                v.subtotal,
                v.descuento_total,
                v.impuesto_total,
                v.total_venta,
                v.estado

            FROM ventas v

            WHERE v.estado <> 'ANULADA'

            ORDER BY
                v.fecha DESC,
                v.id DESC

            LIMIT {$limit}
        ";

        $stmt =
            $this->db->query($sql);

        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );
    }

    /*
    |--------------------------------------------------------------------------
    | USUARIOS
    |--------------------------------------------------------------------------
    */

    public function usuario(
        int $id
    ): ?array {
        $stmt =
            $this->db->prepare("
                SELECT
                    id,
                    usuario,
                    nombre,
                    email,
                    rol,
                    activo

                FROM usuarios

                WHERE id = :id

                LIMIT 1
            ");

        $stmt->execute([
            'id' => $id,
        ]);

        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        return $row ?: null;
    }

    public function usuarioActivo(
        int $id
    ): bool {
        $stmt =
            $this->db->prepare("
                SELECT id

                FROM usuarios

                WHERE
                    id = :id
                    AND activo = 1

                LIMIT 1
            ");

        $stmt->execute([
            'id' => $id,
        ]);

        return
            (bool)$stmt->fetchColumn();
    }

    public function vendedores(): array
    {
        $sql = "
            SELECT
                id,
                usuario,
                nombre,
                email,
                rol

            FROM usuarios

            WHERE activo = 1

            AND rol IN (
                'admin',
                'tecnico'
            )

            ORDER BY
                CASE
                    WHEN nombre IS NULL
                         OR nombre = ''
                    THEN usuario
                    ELSE nombre
                END ASC
        ";

        $stmt =
            $this->db->query($sql);

        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );
    }

    /*
    |--------------------------------------------------------------------------
    | ARTICULOS
    |--------------------------------------------------------------------------
    */

    public function buscarArticulos(
        string $termino,
        int $limit = 20,
        int $listaPrecioId = 0
    ): array {
        $termino =
            trim($termino);

        if ($termino === '') {
            return [];
        }

        $limit =
            min(
                50,
                max(
                    1,
                    $limit
                )
            );

        $like =
            '%' . $termino . '%';

        $sql = "
            SELECT
                i.id,
                i.empresa_id,
                i.nombre_insumo,
                i.marca,
                i.modelo,
                i.codigo_parte,
                i.codigo_barras,
                i.stock_actual,
                i.stock_minimo,
                i.stock_maximo,
                i.unidad_medida_id,
                i.precio_venta,
                i.precio_costo,
                i.activo,
                COALESCE(lpd.precio, i.precio_venta, 0) AS precio_lista,
                CASE WHEN lpd.id IS NULL THEN 0 ELSE 1 END AS tiene_precio_lista

            FROM insumos i

            LEFT JOIN lista_precios_detalle lpd
                ON lpd.insumo_id = i.id
                AND lpd.activo = 1
                AND lpd.lista_precio_id = :lista_precio_id

            WHERE i.activo = 1

            AND (
                i.nombre_insumo LIKE :like_nombre
                OR i.codigo_parte LIKE :like_parte
                OR i.codigo_barras LIKE :like_barras
                OR i.marca LIKE :like_marca
                OR i.modelo LIKE :like_modelo
            )

            ORDER BY

                CASE
                    WHEN i.codigo_barras = :exact_barras
                    THEN 0

                    WHEN i.codigo_parte = :exact_parte
                    THEN 1

                    WHEN i.nombre_insumo LIKE :prefix_nombre
                    THEN 2

                    ELSE 3
                END,

                i.nombre_insumo ASC

            LIMIT {$limit}
        ";

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute([
            'lista_precio_id' => $listaPrecioId > 0 ? $listaPrecioId : 0,

            'like_nombre' =>
                $like,

            'like_parte' =>
                $like,

            'like_barras' =>
                $like,

            'like_marca' =>
                $like,

            'like_modelo' =>
                $like,

            'exact_barras' =>
                $termino,

            'exact_parte' =>
                $termino,

            'prefix_nombre' =>
                $termino . '%',
        ]);

        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );
    }

    public function obtenerArticulo(
        int $id,
        int $listaPrecioId = 0
    ): ?array {
        $stmt =
            $this->db->prepare("
                SELECT
                    id,
                    empresa_id,
                    nombre_insumo,
                    marca,
                    modelo,
                    codigo_parte,
                    codigo_barras,
                    stock_actual,
                    stock_minimo,
                    stock_maximo,
                    unidad_medida_id,
                    precio_venta,
                    precio_costo,
                    costo_compra,
                    activo,
                    COALESCE(lpd.precio, i.precio_venta, 0) AS precio_lista,
                    CASE WHEN lpd.id IS NULL THEN 0 ELSE 1 END AS tiene_precio_lista

                FROM insumos i

                LEFT JOIN lista_precios_detalle lpd
                    ON lpd.insumo_id = i.id
                    AND lpd.activo = 1
                    AND lpd.lista_precio_id = :lista_precio_id

                WHERE
                    i.id = :id
                    AND i.activo = 1

                LIMIT 1
            ");

        $stmt->execute([
            'lista_precio_id' => $listaPrecioId > 0 ? $listaPrecioId : 0,
            'id' => $id,
        ]);

        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        return $row ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function buscarClientes(
        string $termino,
        int $limit = 20
    ): array {
        $limit =
            min(
                50,
                max(
                    1,
                    $limit
                )
            );

        $like =
            '%' . $termino . '%';

        $stmt =
            $this->db->prepare("
                SELECT
                    id,
                    nombre,
                    nombre_fantasia,
                    tipo_cliente,
                    categoria_fiscal,
                    tipo_doc,
                    nro_doc,
                    telefono,
                    email,
                    direccion,
                    activo

                FROM clientes

                WHERE activo = 1

                AND (
                    nombre LIKE :like1
                    OR nombre_fantasia LIKE :like2
                    OR nro_doc LIKE :like3
                    OR telefono LIKE :like4
                )

                ORDER BY
                    CASE
                        WHEN nombre LIKE :prefix
                        THEN 0
                        ELSE 1
                    END,

                    nombre ASC

                LIMIT {$limit}
            ");

        $stmt->execute([
            'like1' =>
                $like,

            'like2' =>
                $like,

            'like3' =>
                $like,

            'like4' =>
                $like,

            'prefix' =>
                $termino . '%',
        ]);

        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );
    }

    public function obtenerCliente(
        int $id
    ): ?array {
        $stmt =
            $this->db->prepare("
                SELECT
                    id,
                    nombre,
                    nombre_fantasia,
                    tipo_cliente,
                    categoria_fiscal,
                    tipo_doc,
                    nro_doc,
                    telefono,
                    email,
                    direccion,
                    activo

                FROM clientes

                WHERE
                    id = :id
                    AND activo = 1

                LIMIT 1
            ");

        $stmt->execute([
            'id' => $id,
        ]);

        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        return $row ?: null;
    }

    public function crearCliente(
        array $data
    ): int {
        $stmt =
            $this->db->prepare("
                INSERT INTO clientes (
                    nombre,
                    nombre_fantasia,
                    tipo_cliente,
                    direccion,
                    telefono,
                    email,
                    categoria_fiscal,
                    tipo_doc,
                    nro_doc,
                    activo
                )

                VALUES (
                    :nombre,
                    :nombre_fantasia,
                    :tipo_cliente,
                    :direccion,
                    :telefono,
                    :email,
                    :categoria_fiscal,
                    :tipo_doc,
                    :nro_doc,
                    1
                )
            ");

        $stmt->execute([
            'nombre' =>
                $data['nombre']
                ?? '',

            'nombre_fantasia' =>
                $data['nombre_fantasia']
                ?? null,

            'tipo_cliente' =>
                $data['tipo_cliente']
                ?? 'Externo',

            'direccion' =>
                $data['direccion']
                ?? null,

            'telefono' =>
                $data['telefono']
                ?? null,

            'email' =>
                $data['email']
                ?? null,

            'categoria_fiscal' =>
                $data['categoria_fiscal']
                ?? null,

            'tipo_doc' =>
                $data['tipo_doc']
                ?? null,

            'nro_doc' =>
                $data['nro_doc']
                ?? null,
        ]);

        return
            (int)$this->db->lastInsertId();
    }

    /*
    |--------------------------------------------------------------------------
    | NUMERO DE COMPROBANTE
    |--------------------------------------------------------------------------
    */

    public function siguienteComprobante(
        string $tipo = 'COMPROBANTE',
        int $puntoVenta = 1
    ): array {
        $stmt =
            $this->db->prepare("
                SELECT
                    COALESCE(
                        MAX(numero_comprobante),
                        0
                    ) + 1 AS siguiente

                FROM ventas

                WHERE
                    tipo_comprobante = :tipo
                    AND punto_venta = :punto_venta
            ");

        $stmt->execute([
            'tipo' =>
                $tipo,

            'punto_venta' =>
                $puntoVenta,
        ]);

        $numero =
            (int)(
                $stmt->fetchColumn()
                ?: 1
            );

        return [
            'tipo' =>
                $tipo,

            'punto_venta' =>
                str_pad(
                    (string)$puntoVenta,
                    4,
                    '0',
                    STR_PAD_LEFT
                ),

            'numero' =>
                $numero,

            'numero_comprobante' =>
                $numero,
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO DE VENTAS
    |--------------------------------------------------------------------------
    */

    public function listarVentas(
        array $filtros
    ): array {
        $where = [];
        $params = [];

        $buscar =
            trim(
                (string)(
                    $filtros['buscar']
                    ?? ''
                )
            );

        if ($buscar !== '') {
            $where[] = "
                (
                    v.cliente_nombre LIKE :buscar

                    OR CAST(
                        v.numero_comprobante
                        AS CHAR
                    ) LIKE :buscar_numero

                    OR CONCAT(
                        LPAD(
                            COALESCE(
                                v.punto_venta,
                                0
                            ),
                            4,
                            '0'
                        ),
                        '-',
                        LPAD(
                            COALESCE(
                                v.numero_comprobante,
                                0
                            ),
                            8,
                            '0'
                        )
                    ) LIKE :buscar_comprobante
                )
            ";

            $params['buscar'] =
                '%' . $buscar . '%';

            $params['buscar_numero'] =
                '%' . $buscar . '%';

            $params['buscar_comprobante'] =
                '%' . $buscar . '%';
        }

        if (
            !empty(
                $filtros['cliente_id']
            )
        ) {
            $where[] =
                'v.cliente_id = :cliente_id';

            $params['cliente_id'] =
                (int)$filtros['cliente_id'];
        }

        if (
            !empty(
                $filtros['vendedor_id']
            )
        ) {
            $where[] =
                'v.vendedor_id = :vendedor_id';

            $params['vendedor_id'] =
                (int)$filtros['vendedor_id'];
        }

        if (
            isset($filtros['estado'])
            &&
            $filtros['estado'] !== ''
        ) {
            $where[] =
                'v.estado = :estado';

            $params['estado'] =
                $filtros['estado'];
        }

        if (
            isset($filtros['desde'])
            &&
            $filtros['desde'] !== ''
        ) {
            $where[] =
                'DATE(v.fecha) >= :desde';

            $params['desde'] =
                $filtros['desde'];
        }

        if (
            isset($filtros['hasta'])
            &&
            $filtros['hasta'] !== ''
        ) {
            $where[] =
                'DATE(v.fecha) <= :hasta';

            $params['hasta'] =
                $filtros['hasta'];
        }

        $sql =
            "SELECT v.* FROM ventas v";

        if ($where) {
            $sql .=
                "\nWHERE "
                .
                implode(
                    "\nAND ",
                    $where
                );
        }

        $sql .= "
            ORDER BY
                v.fecha DESC,
                v.id DESC

            LIMIT :limit
        ";

        $stmt =
            $this->db->prepare($sql);

        foreach (
            $params as $key => $value
        ) {
            $stmt->bindValue(
                ':' . $key,
                $value
            );
        }

        $limit =
            min(
                500,
                max(
                    1,
                    (int)(
                        $filtros['limit']
                        ?? 100
                    )
                )
            );

        $stmt->bindValue(
            ':limit',
            $limit,
            PDO::PARAM_INT
        );

        $stmt->execute();

        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );
    }

    /*
    |--------------------------------------------------------------------------
    | OBTENER VENTA
    |--------------------------------------------------------------------------
    */

    public function obtenerVenta(
        int $id
    ): ?array {
        $stmt =
            $this->db->prepare("
                SELECT
                    v.*

                FROM ventas v

                WHERE v.id = :id

                LIMIT 1
            ");

        $stmt->execute([
            'id' => $id,
        ]);

        $venta =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$venta) {
            return null;
        }

        $stmt =
            $this->db->prepare("
                SELECT
                    vd.id,
                    vd.venta_id,
                    vd.tipo,
                    vd.insumo_id,
                    vd.servicio_id,
                    vd.descripcion,
                    vd.cantidad,
                    vd.precio_unitario,
                    vd.descuento,
                    vd.neto,
                    vd.impuesto_tipo,
                    vd.impuesto_porcentaje,
                    vd.impuesto_importe,
                    vd.subtotal,

                    i.codigo_parte,
                    i.codigo_barras,
                    i.marca,
                    i.modelo

                FROM ventas_detalle vd

                LEFT JOIN insumos i
                    ON i.id = vd.insumo_id

                WHERE
                    vd.venta_id = :venta_id

                ORDER BY
                    vd.id ASC
            ");

        $stmt->execute([
            'venta_id' => $id,
        ]);

        $venta['items'] =
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );

        return $venta;
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTRAR VENTA
    |--------------------------------------------------------------------------
    */

    public function registrarVenta(
        array $venta
    ): array {
        $this->db->beginTransaction();

        try {
            $tipo =
                (string)(
                    $venta['tipo_comprobante']
                    ?? 'COMPROBANTE'
                );

            $puntoVenta =
                (int)(
                    $venta['punto_venta']
                    ?? 1
                );

            $numero =
                (int)(
                    $venta['numero_comprobante']
                    ?? 0
                );

            /*
            |--------------------------------------------------------------------------
            | NUMERO SEGURO
            |--------------------------------------------------------------------------
            */

            if ($numero <= 0) {
                $stmt =
                    $this->db->prepare("
                        SELECT
                            COALESCE(
                                MAX(numero_comprobante),
                                0
                            ) + 1

                        FROM ventas

                        WHERE
                            tipo_comprobante = :tipo
                            AND punto_venta = :punto_venta

                        FOR UPDATE
                    ");

                $stmt->execute([
                    'tipo' =>
                        $tipo,

                    'punto_venta' =>
                        $puntoVenta,
                ]);

                $numero =
                    (int)(
                        $stmt->fetchColumn()
                        ?: 1
                    );
            }

            /*
            |--------------------------------------------------------------------------
            | CABECERA
            |--------------------------------------------------------------------------
            */

            $stmt =
                $this->db->prepare("
                    INSERT INTO ventas (
                        fecha,
                        subtotal,
                        descuento_total,
                        impuesto_total,
                        total_venta,
                        cliente_nombre,
                        cliente_id,
                        tipo_comprobante,
                        punto_venta,
                        numero_comprobante,
                        vendedor_id,
                        vendedor_nombre,
                        estado
                    )

                    VALUES (
                        :fecha,
                        :subtotal,
                        :descuento_total,
                        :impuesto_total,
                        :total_venta,
                        :cliente_nombre,
                        :cliente_id,
                        :tipo_comprobante,
                        :punto_venta,
                        :numero_comprobante,
                        :vendedor_id,
                        :vendedor_nombre,
                        'CONFIRMADA'
                    )
                ");

            $stmt->execute([
                'fecha' =>
                    $venta['fecha'],

                'subtotal' =>
                    $venta['subtotal'],

                'descuento_total' =>
                    $venta['descuento_total'],

                'impuesto_total' =>
                    $venta['impuesto_total'],

                'total_venta' =>
                    $venta['total_venta'],

                'cliente_nombre' =>
                    $venta['cliente_nombre'],

                'cliente_id' =>
                    $venta['cliente_id'],

                'tipo_comprobante' =>
                    $tipo,

                'punto_venta' =>
                    $puntoVenta,

                'numero_comprobante' =>
                    $numero,

                'vendedor_id' =>
                    $venta['vendedor_id'],

                'vendedor_nombre' =>
                    $venta['vendedor_nombre'],
            ]);

            $ventaId =
                (int)$this->db->lastInsertId();

            /*
            |--------------------------------------------------------------------------
            | DETALLE + STOCK
            |--------------------------------------------------------------------------
            */

            foreach (
                $venta['items']
                as $item
            ) {
                $this->insertarDetalle(
                    $ventaId,
                    $item
                );

                $this->salidaInventario(
                    $item,
                    $ventaId,
                    $puntoVenta,
                    $numero,
                    (int)$venta['vendedor_id'],
                    $venta['cliente_id']
                );
            }

            $this->db->commit();

            return [
                'id' =>
                    $ventaId,

                'tipo_comprobante' =>
                    $tipo,

                'punto_venta' =>
                    $puntoVenta,

                'numero_comprobante' =>
                    $numero,

                'total' =>
                    (float)$venta['total_venta'],
            ];
        } catch (Throwable $e) {
            if (
                $this->db->inTransaction()
            ) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | INSERTAR DETALLE
    |--------------------------------------------------------------------------
    */

    private function insertarDetalle(
        int $ventaId,
        array $item
    ): void {
        $stmt =
            $this->db->prepare("
                INSERT INTO ventas_detalle (
                    venta_id,
                    tipo,
                    insumo_id,
                    servicio_id,
                    descripcion,
                    cantidad,
                    precio_unitario,
                    descuento,
                    neto,
                    impuesto_tipo,
                    impuesto_porcentaje,
                    impuesto_importe,
                    subtotal
                )

                VALUES (
                    :venta_id,
                    :tipo,
                    :insumo_id,
                    :servicio_id,
                    :descripcion,
                    :cantidad,
                    :precio_unitario,
                    :descuento,
                    :neto,
                    :impuesto_tipo,
                    :impuesto_porcentaje,
                    :impuesto_importe,
                    :subtotal
                )
            ");

        $stmt->execute([
            'venta_id' =>
                $ventaId,

            'tipo' =>
                $item['tipo'],

            'insumo_id' =>
                $item['insumo_id'],

            'servicio_id' =>
                $item['servicio_id'],

            'descripcion' =>
                $item['descripcion'],

            'cantidad' =>
                $item['cantidad'],

            'precio_unitario' =>
                $item['precio_unitario'],

            'descuento' =>
                $item['descuento'],

            'neto' =>
                $item['neto'],

            'impuesto_tipo' =>
                $item['impuesto_tipo']
                ?? 'IVA',

            'impuesto_porcentaje' =>
                $item['impuesto_porcentaje'],

            'impuesto_importe' =>
                $item['impuesto_importe'],

            'subtotal' =>
                $item['subtotal'],
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | SALIDA INVENTARIO
    |--------------------------------------------------------------------------
    */

    private function salidaInventario(
        array $item,
        int $ventaId,
        int $puntoVenta,
        int $numero,
        int $usuarioId,
        ?int $clienteId
    ): void {
        if (
            ($item['tipo'] ?? 'INSUMO')
            !== 'INSUMO'
        ) {
            return;
        }

        $insumoId =
            (int)(
                $item['insumo_id']
                ?? 0
            );

        $cantidad =
            (float)(
                $item['cantidad']
                ?? 0
            );

        if (
            $insumoId <= 0
            ||
            $cantidad <= 0
        ) {
            throw new RuntimeException(
                'Artículo inválido para salida de stock.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | BLOQUEAR STOCK
        |--------------------------------------------------------------------------
        */

        $stmt =
            $this->db->prepare("
                SELECT
                    id,
                    nombre_insumo,
                    stock_actual,
                    precio_costo,
                    costo_compra,
                    activo

                FROM insumos

                WHERE id = :id

                FOR UPDATE
            ");

        $stmt->execute([
            'id' =>
                $insumoId,
        ]);

        $articulo =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$articulo) {
            throw new RuntimeException(
                'El artículo ya no existe.'
            );
        }

        if (
            (int)$articulo['activo']
            !== 1
        ) {
            throw new RuntimeException(
                'El artículo está inactivo.'
            );
        }

        $stock =
            (float)(
                $articulo['stock_actual']
                ?? 0
            );

        /*
        |--------------------------------------------------------------------------
        | STOCK INSUFICIENTE
        |--------------------------------------------------------------------------
        */

        if (
            $cantidad > $stock
        ) {
            throw new RuntimeException(
                'Stock insuficiente para "' .
                (
                    $articulo['nombre_insumo']
                    ?? 'Artículo'
                ) .
                '". Disponible: ' .
                number_format(
                    $stock,
                    3,
                    ',',
                    '.'
                ) .
                '.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | NUEVO STOCK
        |--------------------------------------------------------------------------
        */

        $nuevoStock =
            $stock - $cantidad;

        $stmt =
            $this->db->prepare("
                UPDATE insumos

                SET stock_actual = :stock

                WHERE id = :id
            ");

        $stmt->execute([
            'stock' =>
                $nuevoStock,

            'id' =>
                $insumoId,
        ]);

        /*
        |--------------------------------------------------------------------------
        | COSTO
        |--------------------------------------------------------------------------
        */

        $costo =
            (float)(
                $articulo['precio_costo']
                ??
                $articulo['costo_compra']
                ??
                0
            );

        /*
        |--------------------------------------------------------------------------
        | OBSERVACION
        |--------------------------------------------------------------------------
        */

        $comprobante =
            str_pad(
                (string)$puntoVenta,
                4,
                '0',
                STR_PAD_LEFT
            )
            .
            '-'
            .
            str_pad(
                (string)$numero,
                8,
                '0',
                STR_PAD_LEFT
            );

        $observacion =
            'Venta #' .
            $ventaId .
            ' PV ' .
            $comprobante;

        /*
        |--------------------------------------------------------------------------
        | MOVIMIENTO STOCK
        |--------------------------------------------------------------------------
        */

        $stmt =
            $this->db->prepare("
                INSERT INTO stock_movimientos (
                    insumo_id,
                    tipo_movimiento,
                    cantidad,
                    costo_unitario,
                    usuario_id,
                    cliente_id,
                    observacion,
                    nro_comprobante
                )

                VALUES (
                    :insumo_id,
                    'SALIDA',
                    :cantidad,
                    :costo_unitario,
                    :usuario_id,
                    :cliente_id,
                    :observacion,
                    :nro_comprobante
                )
            ");

        $stmt->execute([
            'insumo_id' =>
                $insumoId,

            'cantidad' =>
                $cantidad,

            'costo_unitario' =>
                $costo,

            'usuario_id' =>
                $usuarioId,

            'cliente_id' =>
                $clienteId,

            'observacion' =>
                $observacion,

            'nro_comprobante' =>
                $comprobante,
        ]);
    }
}