<?php

/*
|--------------------------------------------------------------------------
| ERP CSDI PRO
| MÓDULO VENTAS
| DASHBOARD
|--------------------------------------------------------------------------
*/

$ventas  = $ventas ?? [];
$resumen = $resumen ?? [];


/*
|--------------------------------------------------------------------------
| INDICADORES
|--------------------------------------------------------------------------
*/

$totalVentas = (int) (
    $resumen['total_ventas']
    ?? $resumen['cantidad']
    ?? count($ventas)
);

$totalFacturado = (float) (
    $resumen['total_facturado']
    ?? $resumen['importe_total']
    ?? $resumen['total']
    ?? 0
);

$ventasHoy = (int) (
    $resumen['ventas_hoy']
    ?? 0
);

$totalHoy = (float) (
    $resumen['total_hoy']
    ?? 0
);

$pendientes = (int) (
    $resumen['pendientes']
    ?? $resumen['ventas_pendientes']
    ?? 0
);


/*
|--------------------------------------------------------------------------
| HELPERS LOCALES
|--------------------------------------------------------------------------
|
| NO declaramos e(), porque BaseController ya dispone de ese helper.
|
*/

$money = static function (mixed $value): string {

    return '$ ' . number_format(
        (float) ($value ?? 0),
        2,
        ',',
        '.'
    );
};

$numero = static function (mixed $value): string {

    return number_format(
        (float) ($value ?? 0),
        0,
        ',',
        '.'
    );
};

$fechaVenta = static function (mixed $value): string {

    if (!$value) {
        return '-';
    }

    $timestamp = strtotime(
        (string) $value
    );

    if ($timestamp === false) {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }

    return date(
        'd/m/Y H:i',
        $timestamp
    );
};

?>


<div class="container-fluid py-4">


    <!-- ================================================================
         HEADER
    ================================================================= -->

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>

            <div class="d-flex align-items-center gap-2 mb-1">

                <span class="text-primary fs-4">
                    <i class="bi bi-cart3"></i>
                </span>

                <h1 class="h3 fw-bold mb-0">
                    Ventas
                </h1>

            </div>

            <p class="text-muted mb-0">
                Gestión comercial, presupuestos, pedidos, remitos y facturación.
            </p>

        </div>


        <div class="d-flex flex-wrap gap-2">

            <a
                href="/ventas/listado"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-search me-1"></i>
                Consultar
            </a>

            <a
                href="/ventas/nueva"
                class="btn btn-primary"
            >
                <i class="bi bi-plus-lg me-1"></i>
                Nueva venta
            </a>

        </div>

    </div>


    <!-- ================================================================
         INDICADORES PRINCIPALES
    ================================================================= -->

    <div class="row g-3 mb-4">


        <!-- VENTAS -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="text-muted small">
                                Ventas
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= $numero($totalVentas) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                Operaciones registradas
                            </div>

                        </div>

                        <div class="text-primary fs-2">
                            <i class="bi bi-cart-check"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- FACTURADO -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="text-muted small">
                                Facturado
                            </div>

                            <div class="fs-4 fw-bold mt-1">
                                <?= $money($totalFacturado) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                Importe acumulado
                            </div>

                        </div>

                        <div class="text-success fs-2">
                            <i class="bi bi-cash-stack"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- HOY -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="text-muted small">
                                Ventas de hoy
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= $numero($ventasHoy) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                <?= $money($totalHoy) ?>
                                vendidos hoy
                            </div>

                        </div>

                        <div class="text-info fs-2">
                            <i class="bi bi-calendar-day"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- PENDIENTES -->

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="text-muted small">
                                Pendientes
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= $numero($pendientes) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                Operaciones pendientes
                            </div>

                        </div>

                        <div class="text-warning fs-2">
                            <i class="bi bi-hourglass-split"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================
         ACCIONES COMERCIALES
    ================================================================= -->

    <div class="mb-3">

        <h5 class="fw-bold mb-1">
            Gestión comercial
        </h5>

        <p class="text-muted small mb-0">
            Accesos rápidos a las principales operaciones de ventas.
        </p>

    </div>


    <div class="row g-3 mb-4">


        <!-- NUEVA VENTA -->

        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/ventas/nueva"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="d-flex align-items-start gap-3">

                            <div class="text-primary fs-2">
                                <i class="bi bi-cart-plus"></i>
                            </div>

                            <div>

                                <h6 class="fw-bold text-dark mb-1">
                                    Nueva venta
                                </h6>

                                <p class="text-muted small mb-0">
                                    Registrar una operación comercial.
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <!-- PRESUPUESTOS -->

        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/ventas/presupuestos"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="d-flex align-items-start gap-3">

                            <div class="text-info fs-2">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>

                            <div>

                                <h6 class="fw-bold text-dark mb-1">
                                    Presupuestos
                                </h6>

                                <p class="text-muted small mb-0">
                                    Crear y consultar presupuestos.
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <!-- PEDIDOS -->

        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/ventas/pedidos"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="d-flex align-items-start gap-3">

                            <div class="text-success fs-2">
                                <i class="bi bi-clipboard-check"></i>
                            </div>

                            <div>

                                <h6 class="fw-bold text-dark mb-1">
                                    Pedidos
                                </h6>

                                <p class="text-muted small mb-0">
                                    Gestionar pedidos de clientes.
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <!-- REMITOS -->

        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/ventas/remitos"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="d-flex align-items-start gap-3">

                            <div class="text-warning fs-2">
                                <i class="bi bi-truck"></i>
                            </div>

                            <div>

                                <h6 class="fw-bold text-dark mb-1">
                                    Remitos
                                </h6>

                                <p class="text-muted small mb-0">
                                    Entregas y movimientos de mercadería.
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>

    </div>


    <!-- ================================================================
         SEGUNDA FILA
    ================================================================= -->

    <div class="row g-3 mb-4">


        <!-- LISTADO -->

        <div class="col-12 col-md-4">

            <a
                href="/ventas/listado"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center gap-3">

                            <div class="text-primary fs-3">
                                <i class="bi bi-list-ul"></i>
                            </div>

                            <div>

                                <div class="fw-bold text-dark">
                                    Listado de ventas
                                </div>

                                <div class="text-muted small">
                                    Consultar y filtrar operaciones.
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <!-- FACTURACIÓN -->

        <div class="col-12 col-md-4">

            <a
                href="/ventas/facturacion"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center gap-3">

                            <div class="text-success fs-3">
                                <i class="bi bi-receipt"></i>
                            </div>

                            <div>

                                <div class="fw-bold text-dark">
                                    Facturación
                                </div>

                                <div class="text-muted small">
                                    Ventas pendientes de facturar.
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <!-- BUSCADOR -->

        <div class="col-12 col-md-4">

            <a
                href="/ventas/listado"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex align-items-center gap-3">

                            <div class="text-info fs-3">
                                <i class="bi bi-search"></i>
                            </div>

                            <div>

                                <div class="fw-bold text-dark">
                                    Buscar operación
                                </div>

                                <div class="text-muted small">
                                    Cliente, comprobante o fecha.
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>

    </div>


    <!-- ================================================================
         ÚLTIMAS VENTAS
    ================================================================= -->

    <div class="card border-0 shadow-sm">


        <div class="card-header bg-white border-0 py-3">

            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">

                <div>

                    <h5 class="fw-bold mb-1">
                        <i class="bi bi-clock-history me-2"></i>
                        Últimas ventas
                    </h5>

                    <div class="text-muted small">
                        Operaciones comerciales más recientes.
                    </div>

                </div>


                <a
                    href="/ventas/listado"
                    class="btn btn-sm btn-outline-primary"
                >

                    <i class="bi bi-list-ul me-1"></i>

                    Ver todas

                </a>

            </div>

        </div>


        <div class="card-body p-0">


            <?php if (empty($ventas)): ?>


                <div class="text-center py-5 text-muted">

                    <i class="bi bi-cart-x fs-1 d-block mb-3"></i>

                    <div class="fw-semibold">
                        No hay ventas registradas.
                    </div>

                    <div class="small mt-1">
                        Cuando registres una venta aparecerá aquí.
                    </div>

                    <a
                        href="/ventas/nueva"
                        class="btn btn-primary btn-sm mt-3"
                    >

                        <i class="bi bi-plus-lg me-1"></i>

                        Registrar primera venta

                    </a>

                </div>


            <?php else: ?>


                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">


                        <thead class="table-light">

                            <tr>

                                <th class="ps-4">
                                    Comprobante
                                </th>

                                <th>
                                    Fecha
                                </th>

                                <th>
                                    Cliente
                                </th>

                                <th>
                                    Estado
                                </th>

                                <th class="text-end">
                                    Total
                                </th>

                                <th class="text-end pe-4">
                                    Acción
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php foreach (
                            array_slice($ventas, 0, 10)
                            as $venta
                        ): ?>


                            <?php

                            $id = (int) (
                                $venta['id']
                                ?? 0
                            );

                            $cliente =
                                $venta['cliente_nombre']
                                ?? $venta['cliente']
                                ?? 'Consumidor Final';

                            $total =
                                $venta['total_venta']
                                ?? $venta['total']
                                ?? 0;

                            $estado =
                                strtoupper(
                                    trim(
                                        (string) (
                                            $venta['estado']
                                            ?? 'CONFIRMADA'
                                        )
                                    )
                                );

                            $badgeClass = match ($estado) {

                                'ANULADA',
                                'ANULADO'
                                    => 'bg-danger-subtle text-danger',

                                'PENDIENTE'
                                    => 'bg-warning-subtle text-warning-emphasis',

                                'FACTURADA',
                                'FACTURADO'
                                    => 'bg-success-subtle text-success',

                                default
                                    => 'bg-primary-subtle text-primary',
                            };

                            ?>


                            <tr>


                                <td class="ps-4">

                                    <div class="fw-semibold">
                                        #<?= $id ?>
                                    </div>

                                    <?php if (!empty($venta['tipo_comprobante'])): ?>

                                        <div class="text-muted small">

                                            <?= $this->e(
                                                $venta['tipo_comprobante']
                                            ) ?>

                                        </div>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?= $fechaVenta(
                                        $venta['fecha']
                                        ?? $venta['created_at']
                                        ?? null
                                    ) ?>

                                </td>


                                <td>

                                    <div class="fw-semibold">

                                        <?= $this->e(
                                            $cliente
                                        ) ?>

                                    </div>

                                    <?php if (!empty($venta['cliente_id'])): ?>

                                        <div class="text-muted small">

                                            Cliente #<?= (int) $venta['cliente_id'] ?>

                                        </div>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <span
                                        class="badge <?= $badgeClass ?>"
                                    >

                                        <?= $this->e(
                                            ucfirst(
                                                strtolower($estado)
                                            )
                                        ) ?>

                                    </span>

                                </td>


                                <td class="text-end fw-bold">

                                    <?= $money($total) ?>

                                </td>


                                <td class="text-end pe-4">

                                    <?php if ($id > 0): ?>

                                        <a
                                            href="/ventas/<?= $id ?>"
                                            class="btn btn-sm btn-outline-primary"
                                            title="Ver venta"
                                        >

                                            <i class="bi bi-eye"></i>

                                        </a>

                                    <?php endif; ?>

                                </td>


                            </tr>


                        <?php endforeach; ?>


                        </tbody>

                    </table>

                </div>


            <?php endif; ?>


        </div>

    </div>


</div>