<?php

declare(strict_types=1);
?>

<div class="container-fluid py-4">

```
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

    <div>

        <h1 class="h3 fw-bold mb-1">
            <i class="bi bi-truck me-2"></i>
            Remitos
        </h1>

        <p class="text-muted mb-0">
            Gestión de entregas y movimientos de mercadería.
        </p>

    </div>

    <a
        href="/ventas/nueva"
        class="btn btn-primary"
    >
        <i class="bi bi-plus-lg me-1"></i>
        Nuevo remito
    </a>

</div>


<div class="card border-0 shadow-sm">

    <div class="card-body text-center py-5">

        <i class="bi bi-truck fs-1 text-muted d-block mb-3"></i>

        <h5 class="fw-bold">
            Remitos
        </h5>

        <p class="text-muted mb-4">
            Administración de remitos y entregas
            asociadas a las ventas.
        </p>

        <a
            href="/ventas/nueva"
            class="btn btn-outline-primary"
        >
            <i class="bi bi-plus-lg me-1"></i>
            Crear remito
        </a>

    </div>

</div>
```

</div>
