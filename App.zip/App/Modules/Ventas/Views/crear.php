<?php

declare(strict_types=1);

$csrf = $csrf ?? '';

$usuario = $usuario ?? [];

$vendedores = $vendedores ?? [];

$comprobante = $comprobante ?? [
    'tipo' => 'COMPROBANTE',
    'punto_venta' => 1,
    'numero' => 1,
];

$clienteDefault = $clienteDefault ?? [
    'id' => null,
    'nombre' => 'Consumidor Final',
];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

$clienteJson = json_encode(
    $clienteDefault,
    JSON_UNESCAPED_UNICODE
    | JSON_UNESCAPED_SLASHES
    | JSON_HEX_TAG
    | JSON_HEX_AMP
    | JSON_HEX_APOS
    | JSON_HEX_QUOT
);
?>

<div
    class="container-fluid py-4"
    id="ventasApp"
    data-csrf="<?= e($csrf) ?>"
>

    <!-- ================================================================
         HEADER
    ================================================================= -->

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-cart3 me-2"></i>

                Nueva venta

            </h1>

            <p class="text-muted mb-0">
                Registrá una nueva venta.
            </p>

        </div>

        <a
            href="/ventas"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Volver
        </a>

    </div>


    <!-- ================================================================
         DATOS DE LA VENTA
    ================================================================= -->

    <div class="card border-0 shadow-sm mb-4">

        <div class="card-header bg-white py-3">

            <strong>
                <i class="bi bi-file-earmark-text me-2"></i>
                Datos de la venta
            </strong>

        </div>

        <div class="card-body">

            <div class="row g-3">

                <!-- CLIENTE -->

                <div class="col-12">

                    <label
                        for="clienteSelect"
                        class="form-label fw-semibold"
                    >
                        Cliente
                    </label>

                    <div class="input-group">

                        <select
                            class="form-select"
                            id="clienteSelect"
                        >

                            <option value="">
                                Consumidor Final
                            </option>

                        </select>

                        <button
                            type="button"
                            class="btn btn-primary"
                            id="btnNuevoCliente"
                            title="Nuevo cliente"
                        >
                            <i class="bi bi-plus-lg"></i>
                        </button>

                        <button
                            type="button"
                            class="btn btn-outline-secondary"
                            id="btnInfoCliente"
                            title="Información del cliente"
                        >
                            <i class="bi bi-info-lg"></i>
                        </button>

                    </div>

                    <input
                        type="hidden"
                        id="clienteId"
                        value=""
                    >

                    <div
                        id="clienteInfo"
                        class="small text-muted mt-2"
                    >
                        Consumidor Final
                    </div>

                </div>


                <!-- FECHA -->

                <div class="col-12 col-md-3">

                    <label
                        for="fecha"
                        class="form-label fw-semibold"
                    >
                        Fecha
                    </label>

                    <input
                        type="datetime-local"
                        class="form-control"
                        id="fecha"
                        value="<?= e(
                            date('Y-m-d\TH:i')
                        ) ?>"
                    >

                </div>


                <!-- COMPROBANTE -->

                <div class="col-12 col-md-3">

                    <label
                        for="tipoComprobante"
                        class="form-label fw-semibold"
                    >
                        Comprobante
                    </label>

                    <select
                        class="form-select"
                        id="tipoComprobante"
                    >

                        <option
                            value="COMPROBANTE"
                            selected
                        >
                            Venta / Comprobante
                        </option>

                        <option
                            value="FACTURA_A"
                            disabled
                        >
                            Factura A — próximamente
                        </option>

                    </select>

                </div>


                <!-- PUNTO DE VENTA -->

                <div class="col-6 col-md-3">

                    <label
                        for="puntoVenta"
                        class="form-label fw-semibold"
                    >
                        Punto de venta
                    </label>

                    <input
                        type="number"
                        min="1"
                        class="form-control"
                        id="puntoVenta"
                        value="<?= (int) (
                            $comprobante['punto_venta']
                            ?? 1
                        ) ?>"
                    >

                </div>


                <!-- NUMERO -->

                <div class="col-6 col-md-3">

                    <label
                        for="numeroComprobante"
                        class="form-label fw-semibold"
                    >
                        Número
                    </label>

                    <input
                        type="number"
                        min="1"
                        class="form-control"
                        id="numeroComprobante"
                        value="<?= (int) (
                            $comprobante['numero']
                            ?? 1
                        ) ?>"
                    >

                </div>


                <!-- VENDEDOR -->

                <div class="col-12 col-md-6">

                    <label
                        for="vendedorId"
                        class="form-label fw-semibold"
                    >
                        Vendedor / atendió
                    </label>

                    <select
                        class="form-select"
                        id="vendedorId"
                    >

                        <?php foreach (
                            $vendedores
                            as $vendedor
                        ): ?>

                            <?php

                            $vendedorId =
                                (int) (
                                    $vendedor['id']
                                    ?? 0
                                );

                            $usuarioId =
                                (int) (
                                    $usuario['id']
                                    ?? 0
                                );

                            $selected =
                                $vendedorId > 0
                                && $vendedorId === $usuarioId;

                            ?>

                            <option
                                value="<?= $vendedorId ?>"
                                <?= $selected
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= e(
                                    $vendedor['nombre']
                                    ?? $vendedor['usuario']
                                    ?? 'Vendedor'
                                ) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================
         BUSCADOR
    ================================================================= -->

    <div class="card border-0 shadow-sm mb-4">

        <div class="card-body">

            <label
                for="buscadorArticulo"
                class="form-label fw-semibold"
            >
                Buscar artículo
            </label>

            <div class="input-group input-group-lg">

                <span class="input-group-text">
                    <i class="bi bi-search"></i>
                </span>

                <input
                    type="search"
                    class="form-control"
                    id="buscadorArticulo"
                    autocomplete="off"
                    placeholder="Nombre, código, código de barras, marca o modelo..."
                >

            </div>

            <div
                id="resultadosRapidos"
                class="list-group mt-2 d-none"
            ></div>

        </div>

    </div>


    <!-- ================================================================
         DETALLE
    ================================================================= -->

    <div class="card border-0 shadow-sm mb-4">

        <div class="card-header bg-white py-3">

            <strong>
                <i class="bi bi-list-check me-2"></i>
                Detalle de la venta
            </strong>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table align-middle mb-0">

                    <thead class="table-light">

                        <tr>

                            <th class="ps-3">
                                Artículo
                            </th>

                            <th
                                class="text-center"
                                style="width:130px"
                            >
                                Cantidad
                            </th>

                            <th
                                class="text-end"
                                style="width:160px"
                            >
                                Precio
                            </th>

                            <th
                                class="text-end"
                                style="width:150px"
                            >
                                Descuento
                            </th>

                            <th
                                class="text-end"
                                style="width:170px"
                            >
                                Subtotal
                            </th>

                            <th style="width:60px"></th>

                        </tr>

                    </thead>

                    <tbody id="detalleVenta">

                        <tr id="sinItems">

                            <td
                                colspan="6"
                                class="text-center text-muted py-5"
                            >

                                <i class="bi bi-cart-x fs-1 d-block mb-3"></i>

                                No hay artículos agregados.

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>


    <!-- ================================================================
         TOTALES
    ================================================================= -->

    <div class="row justify-content-end mb-4">

        <div class="col-12 col-md-5 col-lg-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="d-flex justify-content-between mb-2">

                        <span class="text-muted">
                            Subtotal
                        </span>

                        <strong id="totalSubtotal">
                            $ 0,00
                        </strong>

                    </div>

                    <div class="d-flex justify-content-between mb-3">

                        <span class="text-muted">
                            Descuentos
                        </span>

                        <strong id="totalDescuento">
                            $ 0,00
                        </strong>

                    </div>

                    <hr>

                    <div class="d-flex justify-content-between align-items-center">

                        <span class="fs-5 fw-semibold">
                            TOTAL
                        </span>

                        <strong
                            class="fs-3 fw-bold"
                            id="totalVenta"
                        >
                            $ 0,00
                        </strong>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ================================================================
         ACCIONES
    ================================================================= -->

    <div class="d-flex justify-content-end gap-2">

        <button
            type="button"
            class="btn btn-outline-secondary btn-lg"
            id="btnCancelar"
        >
            Cancelar
        </button>

        <button
            type="button"
            class="btn btn-success btn-lg"
            id="btnConfirmarVenta"
        >
            <i class="bi bi-check-lg me-1"></i>
            Confirmar venta
        </button>

    </div>

</div>


<!-- ================================================================
     MODAL ARTICULOS
================================================================ -->

<div
    class="modal fade"
    id="modalArticulos"
    tabindex="-1"
>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">
                    <i class="bi bi-search me-2"></i>
                    Seleccionar artículo
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>

            <div
                class="modal-body"
                id="modalArticulosBody"
            ></div>

        </div>

    </div>

</div>


<!-- ================================================================
     MODAL CLIENTE
================================================================ -->

<div
    class="modal fade"
    id="modalCliente"
    tabindex="-1"
>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">

                    <i class="bi bi-person-plus me-2"></i>

                    Nuevo cliente

                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>

            <div class="modal-body">

                <form id="formCliente">

                    <div class="row g-3">

                        <div class="col-12">

                            <label class="form-label">
                                Nombre / Razón social *
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="nombre"
                                required
                            >

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Nombre fantasía
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="nombre_fantasia"
                            >

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Tipo documento
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="tipo_doc"
                                placeholder="DNI / CUIT"
                            >

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Número
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="nro_doc"
                            >

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Categoría fiscal
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="categoria_fiscal"
                            >

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Teléfono
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="telefono"
                            >

                        </div>

                        <div class="col-12">

                            <label class="form-label">
                                Dirección
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                name="direccion"
                            >

                        </div>

                        <div class="col-12">

                            <label class="form-label">
                                Email
                            </label>

                            <input
                                type="email"
                                class="form-control"
                                name="email"
                            >

                        </div>

                    </div>

                </form>

            </div>

            <div class="modal-footer">

                <button
                    type="button"
                    class="btn btn-outline-secondary"
                    data-bs-dismiss="modal"
                >
                    Cancelar
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    id="btnGuardarCliente"
                >
                    <i class="bi bi-check-lg me-1"></i>
                    Guardar cliente
                </button>

            </div>

        </div>

    </div>

</div>


<!-- ================================================================
     MODAL INFO CLIENTE
================================================================ -->

<div
    class="modal fade"
    id="modalInfoCliente"
    tabindex="-1"
>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">

                    <i class="bi bi-person-vcard me-2"></i>

                    Información del cliente

                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>

            <div
                class="modal-body"
                id="modalInfoClienteBody"
            ></div>

        </div>

    </div>

</div>


<script>

document.addEventListener(
    'DOMContentLoaded',
    function () {

        'use strict';

        const app =
            document.getElementById(
                'ventasApp'
            );

        if (!app) {
            return;
        }


        const csrf =
            app.dataset.csrf || '';


        const state = {

            clienteId: null,

            clienteNombre:
                'Consumidor Final',

            items: [],

            buscando: false,

            timeout: null
        };


        /*
        |--------------------------------------------------------------------------
        | ELEMENTOS
        |--------------------------------------------------------------------------
        */

        const search =
            document.getElementById(
                'buscadorArticulo'
            );

        const resultados =
            document.getElementById(
                'resultadosRapidos'
            );

        const detalle =
            document.getElementById(
                'detalleVenta'
            );

        const totalSubtotal =
            document.getElementById(
                'totalSubtotal'
            );

        const totalDescuento =
            document.getElementById(
                'totalDescuento'
            );

        const totalVenta =
            document.getElementById(
                'totalVenta'
            );

        const clienteId =
            document.getElementById(
                'clienteId'
            );

        const clienteInfo =
            document.getElementById(
                'clienteInfo'
            );


        /*
        |--------------------------------------------------------------------------
        | MODALES
        |--------------------------------------------------------------------------
        */

        const modalArticulos =
            new bootstrap.Modal(
                document.getElementById(
                    'modalArticulos'
                )
            );

        const modalCliente =
            new bootstrap.Modal(
                document.getElementById(
                    'modalCliente'
                )
            );

        const modalInfoCliente =
            new bootstrap.Modal(
                document.getElementById(
                    'modalInfoCliente'
                )
            );


        /*
        |--------------------------------------------------------------------------
        | HELPERS
        |--------------------------------------------------------------------------
        */

        function money(value) {

            return '$ ' +
                Number(value || 0)
                    .toLocaleString(
                        'es-AR',
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }
                    );
        }


        function escapeHtml(value) {

            const div =
                document.createElement(
                    'div'
                );

            div.textContent =
                String(value ?? '');

            return div.innerHTML;
        }


        async function request(
            url,
            options = {}
        ) {

            const config = {
                ...options,
                headers: {
                    'Accept':
                        'application/json',

                    ...(options.headers || {})
                }
            };


            if (
                config.method
                &&
                config.method.toUpperCase()
                    !== 'GET'
            ) {

                config.headers[
                    'Content-Type'
                ] =
                    'application/json';

                config.headers[
                    'X-CSRF-TOKEN'
                ] = csrf;
            }


            const response =
                await fetch(
                    url,
                    config
                );


            const data =
                await response
                    .json()
                    .catch(
                        () => ({
                            success: false,
                            message:
                                'Respuesta inválida del servidor.'
                        })
                    );


            if (
                !response.ok
                ||
                data.success === false
            ) {

                throw new Error(
                    data.message
                    ||
                    'No se pudo completar la operación.'
                );
            }


            return data;
        }


        function mostrarError(
            mensaje
        ) {

            alert(
                String(
                    mensaje
                    ||
                    'Ocurrió un error.'
                )
            );
        }


        /*
        |--------------------------------------------------------------------------
        | BUSCADOR
        |--------------------------------------------------------------------------
        */

        search.addEventListener(
            'input',
            function () {

                clearTimeout(
                    state.timeout
                );


                const q =
                    search.value.trim();


                if (q.length < 2) {

                    resultados.classList.add(
                        'd-none'
                    );

                    resultados.innerHTML =
                        '';

                    return;
                }


                state.timeout =
                    setTimeout(
                        () => buscarArticulos(q),
                        300
                    );
            }
        );


        search.addEventListener(
            'keydown',
            function (event) {

                if (
                    event.key === 'Escape'
                ) {

                    resultados.classList.add(
                        'd-none'
                    );
                }
            }
        );


        async function buscarArticulos(
            q
        ) {

            if (state.buscando) {
                return;
            }


            state.buscando = true;


            try {

                const response =
                    await request(
                        '/ventas/api/articulos/buscar?q='
                        +
                        encodeURIComponent(q)
                    );


                const items =
                    response.data || [];


                if (!items.length) {

                    resultados.innerHTML =
                        `
                        <div class="list-group-item text-muted">
                            No se encontraron artículos.
                        </div>
                        `;

                    resultados.classList.remove(
                        'd-none'
                    );

                    return;
                }


                if (items.length === 1) {

                    agregarArticulo(
                        items[0]
                    );

                    search.value = '';

                    resultados.classList.add(
                        'd-none'
                    );

                    return;
                }


                mostrarResultados(
                    items,
                    q
                );

            } catch (error) {

                mostrarError(
                    error.message
                );

            } finally {

                state.buscando = false;
            }
        }


        function mostrarResultados(
            items,
            termino
        ) {

            const body =
                document.getElementById(
                    'modalArticulosBody'
                );


            body.innerHTML =
                `
                <div class="mb-3">
                    Resultados para
                    <strong>
                        ${escapeHtml(termino)}
                    </strong>
                </div>

                <div class="list-group">

                    ${items.map(
                        item => `
                            <button
                                type="button"
                                class="list-group-item list-group-item-action articuloResultado"
                                data-id="${Number(item.id)}"
                            >

                                <div class="d-flex justify-content-between gap-3">

                                    <div>

                                        <strong>
                                            ${escapeHtml(
                                                item.nombre_insumo
                                                ?? item.nombre
                                                ?? ''
                                            )}
                                        </strong>

                                        <div class="small text-muted">

                                            ${escapeHtml(
                                                item.codigo_parte
                                                ?? item.codigo
                                                ?? ''
                                            )}

                                            ${
                                                item.marca
                                                    ? ' · ' +
                                                      escapeHtml(
                                                          item.marca
                                                      )
                                                    : ''
                                            }

                                        </div>

                                    </div>

                                    <div class="text-end">

                                        <strong>
                                            ${money(
                                                item.precio_venta
                                                ?? 0
                                            )}
                                        </strong>

                                        <div class="small">

                                            Stock:
                                            ${Number(
                                                item.stock_actual
                                                ?? 0
                                            )}

                                        </div>

                                    </div>

                                </div>

                            </button>
                        `
                    ).join('')}

                </div>
                `;


            body
                .querySelectorAll(
                    '.articuloResultado'
                )
                .forEach(
                    button => {

                        button.addEventListener(
                            'click',
                            async function () {

                                const id =
                                    Number(
                                        this.dataset.id
                                    );


                                try {

                                    const response =
                                        await request(
                                            '/ventas/api/articulos/'
                                            +
                                            id
                                        );


                                    agregarArticulo(
                                        response.data
                                    );


                                    modalArticulos.hide();

                                    search.value = '';

                                } catch (error) {

                                    mostrarError(
                                        error.message
                                    );
                                }
                            }
                        );
                    }
                );


            modalArticulos.show();
        }


        /*
        |--------------------------------------------------------------------------
        | ARTÍCULOS
        |--------------------------------------------------------------------------
        */

        function agregarArticulo(
            articulo
        ) {

            const id =
                Number(
                    articulo.id
                );


            if (id <= 0) {
                return;
            }


            const stock =
                Number(
                    articulo.stock_actual
                    ?? 0
                );


            if (stock <= 0) {

                mostrarError(
                    'El artículo no tiene stock disponible.'
                );

                return;
            }


            const existente =
                state.items.find(
                    item =>
                        Number(
                            item.insumo_id
                        ) === id
                );


            if (existente) {

                const nuevo =
                    Number(
                        existente.cantidad
                    ) + 1;


                if (
                    nuevo > stock
                ) {

                    mostrarError(
                        'No hay suficiente stock disponible.'
                    );

                    return;
                }


                existente.cantidad =
                    nuevo;

            } else {

                state.items.push({

                    insumo_id:
                        id,

                    tipo:
                        'INSUMO',

                    descripcion:
                        articulo.nombre_insumo
                        ??
                        articulo.nombre
                        ??
                        '',

                    cantidad:
                        1,

                    precio_unitario:
                        Number(
                            articulo.precio_venta
                            ?? 0
                        ),

                    descuento:
                        0,

                    stock_actual:
                        stock
                });
            }


            renderDetalle();
        }


        /*
        |--------------------------------------------------------------------------
        | DETALLE
        |--------------------------------------------------------------------------
        */

        function renderDetalle() {

            if (!state.items.length) {

                detalle.innerHTML =
                    `
                    <tr id="sinItems">

                        <td
                            colspan="6"
                            class="text-center text-muted py-5"
                        >

                            <i class="bi bi-cart-x fs-1 d-block mb-3"></i>

                            No hay artículos agregados.

                        </td>

                    </tr>
                    `;

                actualizarTotales();

                return;
            }


            detalle.innerHTML =
                state.items.map(
                    (
                        item,
                        index
                    ) => {

                        const cantidad =
                            Number(
                                item.cantidad
                            );


                        const precio =
                            Number(
                                item.precio_unitario
                            );


                        const descuento =
                            Number(
                                item.descuento
                            );


                        const bruto =
                            cantidad * precio;


                        const subtotal =
                            Math.max(
                                0,
                                bruto - descuento
                            );


                        return `
                        <tr>

                            <td class="ps-3">

                                <strong>
                                    ${escapeHtml(
                                        item.descripcion
                                    )}
                                </strong>

                                <div class="small text-muted">

                                    Stock:
                                    ${Number(
                                        item.stock_actual
                                        ?? 0
                                    )}

                                </div>

                            </td>


                            <td>

                                <input
                                    type="number"
                                    min="0.001"
                                    step="0.001"
                                    class="form-control form-control-sm text-center itemCantidad"
                                    data-index="${index}"
                                    value="${cantidad}"
                                >

                            </td>


                            <td>

                                <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    class="form-control form-control-sm text-end itemPrecio"
                                    data-index="${index}"
                                    value="${precio.toFixed(2)}"
                                >

                            </td>


                            <td>

                                <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    class="form-control form-control-sm text-end itemDescuento"
                                    data-index="${index}"
                                    value="${descuento.toFixed(2)}"
                                >

                            </td>


                            <td class="text-end fw-semibold">

                                ${money(
                                    subtotal
                                )}

                            </td>


                            <td>

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-danger btnEliminarItem"
                                    data-index="${index}"
                                    title="Eliminar"
                                >

                                    <i class="bi bi-trash"></i>

                                </button>

                            </td>

                        </tr>
                        `;
                    }
                ).join('');


            bindDetalle();

            actualizarTotales();
        }


        function bindDetalle() {

            detalle
                .querySelectorAll(
                    '.itemCantidad'
                )
                .forEach(
                    input => {

                        input.addEventListener(
                            'change',
                            function () {

                                const index =
                                    Number(
                                        this.dataset.index
                                    );


                                if (
                                    !state.items[index]
                                ) {
                                    return;
                                }


                                let value =
                                    Number(
                                        this.value
                                    );


                                const stock =
                                    Number(
                                        state.items[index]
                                            .stock_actual
                                        ?? 0
                                    );


                                if (
                                    !Number.isFinite(
                                        value
                                    )
                                    ||
                                    value <= 0
                                ) {

                                    value = 1;
                                }


                                if (
                                    value > stock
                                ) {

                                    value =
                                        stock;

                                    mostrarError(
                                        'La cantidad supera el stock disponible.'
                                    );
                                }


                                state.items[index]
                                    .cantidad =
                                    value;


                                renderDetalle();
                            }
                        );
                    }
                );


            detalle
                .querySelectorAll(
                    '.itemPrecio'
                )
                .forEach(
                    input => {

                        input.addEventListener(
                            'change',
                            function () {

                                const index =
                                    Number(
                                        this.dataset.index
                                    );


                                if (
                                    !state.items[index]
                                ) {
                                    return;
                                }


                                let value =
                                    Number(
                                        this.value
                                    );


                                if (
                                    !Number.isFinite(
                                        value
                                    )
                                    ||
                                    value < 0
                                ) {

                                    value = 0;
                                }


                                state.items[index]
                                    .precio_unitario =
                                    value;


                                renderDetalle();
                            }
                        );
                    }
                );


            detalle
                .querySelectorAll(
                    '.itemDescuento'
                )
                .forEach(
                    input => {

                        input.addEventListener(
                            'change',
                            function () {

                                const index =
                                    Number(
                                        this.dataset.index
                                    );


                                if (
                                    !state.items[index]
                                ) {
                                    return;
                                }


                                let value =
                                    Number(
                                        this.value
                                    );


                                if (
                                    !Number.isFinite(
                                        value
                                    )
                                    ||
                                    value < 0
                                ) {

                                    value = 0;
                                }


                                const bruto =
                                    Number(
                                        state.items[index]
                                            .cantidad
                                    )
                                    *
                                    Number(
                                        state.items[index]
                                            .precio_unitario
                                    );


                                if (
                                    value > bruto
                                ) {

                                    value = bruto;
                                }


                                state.items[index]
                                    .descuento =
                                    value;


                                renderDetalle();
                            }
                        );
                    }
                );


            detalle
                .querySelectorAll(
                    '.btnEliminarItem'
                )
                .forEach(
                    button => {

                        button.addEventListener(
                            'click',
                            function () {

                                const index =
                                    Number(
                                        this.dataset.index
                                    );


                                state.items.splice(
                                    index,
                                    1
                                );


                                renderDetalle();
                            }
                        );
                    }
                );
        }


        function actualizarTotales() {

            let subtotal = 0;

            let descuentos = 0;


            state.items.forEach(
                item => {

                    const bruto =
                        Number(
                            item.cantidad
                        )
                        *
                        Number(
                            item.precio_unitario
                        );


                    subtotal +=
                        bruto;


                    descuentos +=
                        Number(
                            item.descuento
                            ?? 0
                        );
                }
            );


            const total =
                Math.max(
                    0,
                    subtotal - descuentos
                );


            totalSubtotal.textContent =
                money(subtotal);


            totalDescuento.textContent =
                money(descuentos);


            totalVenta.textContent =
                money(total);
        }


        /*
        |--------------------------------------------------------------------------
        | CLIENTE
        |--------------------------------------------------------------------------
        */

        document
            .getElementById(
                'btnNuevoCliente'
            )
            .addEventListener(
                'click',
                function () {

                    document
                        .getElementById(
                            'formCliente'
                        )
                        .reset();

                    modalCliente.show();
                }
            );


        document
            .getElementById(
                'btnGuardarCliente'
            )
            .addEventListener(
                'click',
                async function () {

                    const form =
                        document.getElementById(
                            'formCliente'
                        );


                    if (
                        !form.reportValidity()
                    ) {
                        return;
                    }


                    const data =
                        Object.fromEntries(
                            new FormData(form)
                        );


                    try {

                        const response =
                            await request(
                                '/ventas/api/clientes',
                                {
                                    method:
                                        'POST',

                                    body:
                                        JSON.stringify(
                                            data
                                        )
                                }
                            );


                        const cliente =
                            response.data.cliente;


                        seleccionarCliente(
                            cliente
                        );


                        modalCliente.hide();

                    } catch (error) {

                        mostrarError(
                            error.message
                        );
                    }
                }
            );


        function seleccionarCliente(
            cliente
        ) {

            state.clienteId =
                cliente.id
                    ? Number(
                        cliente.id
                    )
                    : null;


            state.clienteNombre =
                cliente.nombre
                ||
                'Consumidor Final';


            clienteId.value =
                state.clienteId
                || '';


            clienteInfo.textContent =
                state.clienteNombre;


            const select =
                document.getElementById(
                    'clienteSelect'
                );


            select.innerHTML =
                '';


            const option =
                document.createElement(
                    'option'
                );


            option.value =
                state.clienteId
                || '';


            option.textContent =
                state.clienteNombre;


            option.selected =
                true;


            select.appendChild(
                option
            );
        }


        document
            .getElementById(
                'btnInfoCliente'
            )
            .addEventListener(
                'click',
                async function () {

                    if (
                        !state.clienteId
                    ) {

                        document
                            .getElementById(
                                'modalInfoClienteBody'
                            )
                            .innerHTML =
                            `
                            <div class="text-center py-4 text-muted">

                                <i class="bi bi-person fs-1 d-block mb-3"></i>

                                Consumidor Final

                                <div class="small mt-2">
                                    No existe una ficha de cliente asociada.
                                </div>

                            </div>
                            `;


                        modalInfoCliente.show();

                        return;
                    }


                    try {

                        const response =
                            await request(
                                '/ventas/api/clientes/'
                                +
                                state.clienteId
                            );


                        mostrarInfoCliente(
                            response.data
                        );


                        modalInfoCliente.show();

                    } catch (error) {

                        mostrarError(
                            error.message
                        );
                    }
                }
            );


        function mostrarInfoCliente(
            cliente
        ) {

            document
                .getElementById(
                    'modalInfoClienteBody'
                )
                .innerHTML =
                `
                <div class="row g-3">

                    <div class="col-12">

                        <h4 class="mb-1">

                            ${escapeHtml(
                                cliente.nombre
                                || ''
                            )}

                        </h4>

                        ${
                            cliente.nombre_fantasia
                                ? `
                                    <div class="text-muted">
                                        ${escapeHtml(
                                            cliente.nombre_fantasia
                                        )}
                                    </div>
                                  `
                                : ''
                        }

                    </div>

                    <div class="col-md-6">

                        <strong>
                            Documento
                        </strong>

                        <div>
                            ${escapeHtml(
                                cliente.tipo_doc
                                || '-'
                            )}

                            ${escapeHtml(
                                cliente.nro_doc
                                || ''
                            )}
                        </div>

                    </div>

                    <div class="col-md-6">

                        <strong>
                            Condición fiscal
                        </strong>

                        <div>
                            ${escapeHtml(
                                cliente.categoria_fiscal
                                || '-'
                            )}
                        </div>

                    </div>

                    <div class="col-md-6">

                        <strong>
                            Teléfono
                        </strong>

                        <div>
                            ${escapeHtml(
                                cliente.telefono
                                || '-'
                            )}
                        </div>

                    </div>

                    <div class="col-md-6">

                        <strong>
                            Email
                        </strong>

                        <div>
                            ${escapeHtml(
                                cliente.email
                                || '-'
                            )}
                        </div>

                    </div>

                    <div class="col-12">

                        <strong>
                            Dirección
                        </strong>

                        <div>
                            ${escapeHtml(
                                cliente.direccion
                                || '-'
                            )}
                        </div>

                    </div>

                </div>
                `;
        }


        /*
        |--------------------------------------------------------------------------
        | CONFIRMAR
        |--------------------------------------------------------------------------
        */

        document
            .getElementById(
                'btnConfirmarVenta'
            )
            .addEventListener(
                'click',
                confirmarVenta
            );


        async function confirmarVenta() {

            if (
                !state.items.length
            ) {

                mostrarError(
                    'Agregá al menos un artículo.'
                );

                return;
            }


            const boton =
                document.getElementById(
                    'btnConfirmarVenta'
                );


            boton.disabled =
                true;


            const original =
                boton.innerHTML;


            boton.innerHTML =
                `
                <span
                    class="spinner-border spinner-border-sm me-1"
                ></span>

                Guardando...
                `;


            try {

                const payload = {

                    fecha:
                        document.getElementById(
                            'fecha'
                        ).value,

                    cliente_id:
                        state.clienteId,

                    cliente_nombre:
                        state.clienteNombre,

                    tipo_comprobante:
                        document.getElementById(
                            'tipoComprobante'
                        ).value,

                    punto_venta:
                        Number(
                            document.getElementById(
                                'puntoVenta'
                            ).value
                        ),

                    numero_comprobante:
                        Number(
                            document.getElementById(
                                'numeroComprobante'
                            ).value
                        ),

                    vendedor_id:
                        Number(
                            document.getElementById(
                                'vendedorId'
                            ).value
                        ),

                    items:
                        state.items.map(
                            item => ({

                                tipo:
                                    item.tipo
                                    || 'INSUMO',

                                insumo_id:
                                    Number(
                                        item.insumo_id
                                    ),

                                descripcion:
                                    item.descripcion,

                                cantidad:
                                    Number(
                                        item.cantidad
                                    ),

                                precio_unitario:
                                    Number(
                                        item.precio_unitario
                                    ),

                                descuento:
                                    Number(
                                        item.descuento
                                    )
                            })
                        )
                };


                const response =
                    await request(
                        '/ventas/api/confirmar',
                        {
                            method:
                                'POST',

                            body:
                                JSON.stringify(
                                    payload
                                )
                        }
                    );


                const data =
                    response.data
                    || {};


                alert(
                    (
                        response.message
                        ||
                        'Venta registrada correctamente.'
                    )
                    +
                    '\n\nComprobante: '
                    +
                    String(
                        data.punto_venta
                        ?? payload.punto_venta
                    ).padStart(
                        4,
                        '0'
                    )
                    +
                    '-'
                    +
                    String(
                        data.numero
                        ?? payload.numero_comprobante
                    ).padStart(
                        8,
                        '0'
                    )
                    +
                    '\nTotal: '
                    +
                    money(
                        data.total
                        ?? 0
                    )
                );


                const id =
                    Number(
                        data.id
                        ?? data.venta_id
                        ?? 0
                    );


                if (id > 0) {

                    window.location.href =
                        '/ventas/ver/' + id;

                    return;
                }


                window.location.href =
                    '/ventas';

            } catch (error) {

                mostrarError(
                    error.message
                );


                boton.disabled =
                    false;


                boton.innerHTML =
                    original;
            }
        }


        /*
        |--------------------------------------------------------------------------
        | CANCELAR
        |--------------------------------------------------------------------------
        */

        document
            .getElementById(
                'btnCancelar'
            )
            .addEventListener(
                'click',
                function () {

                    if (
                        state.items.length
                        &&
                        !confirm(
                            'Hay artículos cargados. ¿Cancelar la venta?'
                        )
                    ) {

                        return;
                    }


                    window.location.href =
                        '/ventas';
                }
            );


        /*
        |--------------------------------------------------------------------------
        | INICIO
        |--------------------------------------------------------------------------
        */

        seleccionarCliente(
            <?= $clienteJson ?: '{}' ?>
        );


        renderDetalle();

    }
);

</script>