<?php

declare(strict_types=1);

$usuario =
    is_array($usuario ?? null)
        ? $usuario
        : [];

$cliente =
    is_array($cliente ?? null)
        ? $cliente
        : [];

$vendedores =
    is_array($vendedores ?? null)
        ? $vendedores
        : [];

$comprobante =
    is_array($comprobante ?? null)
        ? $comprobante
        : [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                <i class="bi bi-cart-plus me-2"></i>
                Nueva venta
            </h1>

            <p class="text-muted mb-0">
                Registrar una nueva operación comercial.
            </p>
        </div>

        <a
            href="/ventas"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Volver
        </a>

    </div>

    <form
        id="formVenta"
        autocomplete="off"
    >

        <input type="hidden" name="csrf" value="<?= e($csrf ?? '') ?>">

        <div class="row g-4">

            <div class="col-12 col-xl-8">

                <!-- DATOS VENTA -->

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-white py-3">
                        <strong>
                            <i class="bi bi-file-earmark-text me-2"></i>
                            Datos de la venta
                        </strong>
                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-md-4">

                                <label
                                    for="tipoComprobante"
                                    class="form-label"
                                >
                                    Tipo de comprobante
                                </label>

                                <select
                                    name="tipo_comprobante"
                                    id="tipoComprobante"
                                    class="form-select"
                                >

                                    <option value="COMPROBANTE">
                                        Comprobante
                                    </option>

                                </select>

                            </div>

                            <div class="col-md-4">

                                <label
                                    for="puntoVenta"
                                    class="form-label"
                                >
                                    Punto de venta
                                </label>

                                <input
                                    type="number"
                                    name="punto_venta"
                                    id="puntoVenta"
                                    class="form-control"
                                    min="1"
                                    max="99999"
                                    step="1"
                                    value="<?= e(
                                        $comprobante['punto_venta']
                                        ?? 1
                                    ) ?>"
                                >

                            </div>

                            <div class="col-md-4">

                                <label
                                    for="numeroComprobante"
                                    class="form-label"
                                >
                                    Número
                                </label>

                                <input
                                    type="text"
                                    name="numero_comprobante"
                                    id="numeroComprobante"
                                    class="form-control"
                                    value="<?= e(
                                        $comprobante['numero']
                                        ?? $comprobante['numero_comprobante']
                                        ?? ''
                                    ) ?>"
                                    readonly
                                >

                            </div>

                            <div class="col-md-4">

                                <label
                                    for="fechaVenta"
                                    class="form-label"
                                >
                                    Fecha
                                </label>

                                <input
                                    type="datetime-local"
                                    name="fecha"
                                    id="fechaVenta"
                                    class="form-control"
                                    value="<?= date('Y-m-d\TH:i') ?>"
                                >

                            </div>

                        </div>

                    </div>

                </div>

                <!-- CLIENTE -->

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-person me-2"></i>
                            Cliente
                        </strong>

                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-md-8">

                                <label
                                    for="clienteBuscar"
                                    class="form-label"
                                >
                                    Cliente
                                </label>

                                <div class="input-group">

                                    <input
                                        type="text"
                                        id="clienteBuscar"
                                        class="form-control"
                                        value="<?= e(
                                            $cliente['nombre']
                                            ?? 'Consumidor Final'
                                        ) ?>"
                                        placeholder="Buscar por nombre, DNI, CUIT, teléfono..."
                                    >

                                    <button
                                        type="button"
                                        class="btn btn-outline-primary"
                                        id="btnBuscarCliente"
                                    >
                                        <i class="bi bi-search"></i>
                                    </button>

                                </div>

                                <input
                                    type="hidden"
                                    name="cliente_id"
                                    id="clienteId"
                                    value="<?= e(
                                        $cliente['id']
                                        ?? ''
                                    ) ?>"
                                >

                                <div
                                    id="resultadosClientes"
                                    class="list-group position-absolute shadow-sm"
                                    style="
                                        z-index:1050;
                                        max-height:280px;
                                        overflow-y:auto;
                                        display:none;
                                        width:calc(100% - 2rem);
                                    "
                                ></div>

                            </div>

                            <div class="col-md-4">

                                <label
                                    for="clienteDocumento"
                                    class="form-label"
                                >
                                    CUIT / DNI
                                </label>

                                <input
                                    type="text"
                                    id="clienteDocumento"
                                    class="form-control"
                                    value="<?= e(
                                        $cliente['nro_doc']
                                        ?? ''
                                    ) ?>"
                                    readonly
                                >

                            </div>

                            <div class="col-12">

                                <div
                                    id="clienteInfo"
                                    class="small text-muted"
                                >
                                    <?= e(
                                        $cliente['categoria_fiscal']
                                        ?? 'Consumidor Final'
                                    ) ?>
                                </div>

                            </div>

                            <div class="col-12">

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-success"
                                    id="btnNuevoCliente"
                                >
                                    <i class="bi bi-person-plus me-1"></i>
                                    Nuevo cliente
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-secondary"
                                    id="btnConsumidorFinal"
                                >
                                    <i class="bi bi-person-check me-1"></i>
                                    Consumidor Final
                                </button>

                            </div>

                        </div>

                    </div>

                </div>

                <!-- ARTICULOS -->

                <div class="card border-0 shadow-sm">

                    <div class="card-header bg-white py-3">

                        <div class="d-flex justify-content-between align-items-center">

                            <strong>
                                <i class="bi bi-box-seam me-2"></i>
                                Artículos
                            </strong>

                            <button
                                type="button"
                                class="btn btn-sm btn-primary"
                                id="btnAgregarArticulo"
                            >
                                <i class="bi bi-plus-lg me-1"></i>
                                Agregar artículo
                            </button>

                        </div>

                    </div>

                    <div class="card-body p-0">

                        <div class="table-responsive">

                            <table
                                class="table align-middle mb-0"
                                id="tablaItems"
                            >

                                <thead class="table-light">

                                    <tr>

                                        <th style="min-width:250px;">
                                            Artículo
                                        </th>

                                        <th style="width:100px;">
                                            Cant.
                                        </th>

                                        <th style="width:140px;">
                                            Precio
                                        </th>

                                        <th style="width:130px;">
                                            Desc.
                                        </th>

                                        <th style="width:130px;">
                                            IVA %
                                        </th>

                                        <th
                                            style="width:150px;"
                                            class="text-end"
                                        >
                                            Total
                                        </th>

                                        <th style="width:60px;"></th>

                                    </tr>

                                </thead>

                                <tbody id="itemsVenta">

                                    <tr id="filaVacia">

                                        <td
                                            colspan="7"
                                            class="text-center text-muted py-5"
                                        >

                                            <i class="bi bi-box-seam fs-2 d-block mb-2"></i>

                                            No hay artículos agregados.

                                        </td>

                                    </tr>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>

            <!-- COLUMNA DERECHA -->

            <div class="col-12 col-xl-4">

                <!-- VENDEDOR -->

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-person-badge me-2"></i>
                            Vendedor
                        </strong>

                    </div>

                    <div class="card-body">

                        <select
                            name="vendedor_id"
                            id="vendedorId"
                            class="form-select"
                        >

                            <option value="">
                                Usar usuario actual
                            </option>

                            <?php foreach ($vendedores as $vendedor): ?>

                                <option
                                    value="<?= (int)(
                                        $vendedor['id'] ?? 0
                                    ) ?>"
                                    <?= (
                                        (int)(
                                            $vendedor['id']
                                            ?? 0
                                        )
                                        ===
                                        (int)(
                                            $usuario['id']
                                            ?? 0
                                        )
                                    )
                                        ? 'selected'
                                        : ''
                                    ?>
                                >
                                    <?= e(
                                        $vendedor['nombre']
                                        ?? $vendedor['usuario']
                                        ?? 'Usuario'
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                </div>

                <!-- RESUMEN -->

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-calculator me-2"></i>
                            Resumen
                        </strong>

                    </div>

                    <div class="card-body">

                        <div class="d-flex justify-content-between mb-2">

                            <span class="text-muted">
                                Neto
                            </span>

                            <strong id="subtotalVenta">
                                $ 0,00
                            </strong>

                        </div>

                        <div class="d-flex justify-content-between mb-2">

                            <span class="text-muted">
                                Descuento
                            </span>

                            <strong id="descuentoVenta">
                                $ 0,00
                            </strong>

                        </div>

                        <div class="d-flex justify-content-between mb-2">

                            <span class="text-muted">
                                Impuestos
                            </span>

                            <strong id="impuestoVenta">
                                $ 0,00
                            </strong>

                        </div>

                        <hr>

                        <div class="d-flex justify-content-between align-items-center">

                            <span class="fs-5 fw-bold">
                                Total
                            </span>

                            <span
                                class="fs-4 fw-bold text-primary"
                                id="totalVenta"
                            >
                                $ 0,00
                            </span>

                        </div>

                    </div>

                </div>

                <!-- ACCIONES -->

                <div class="card border-0 shadow-sm">

                    <div class="card-body">

                        <button
                            type="submit"
                            class="btn btn-primary btn-lg w-100"
                            id="btnConfirmarVenta"
                        >
                            <i class="bi bi-check2-circle me-2"></i>
                            Confirmar venta
                        </button>

                        <a
                            href="/ventas"
                            class="btn btn-outline-secondary w-100 mt-2"
                        >
                            Cancelar
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </form>

</div>

<!-- ============================================================
     MODAL ARTICULO
============================================================= -->

<div
    class="modal fade"
    id="modalArticulo"
    tabindex="-1"
    aria-hidden="true"
>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">
                    <i class="bi bi-box-seam me-2"></i>
                    Buscar artículo
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>

            <div class="modal-body">

                <div class="mb-3">
                    <label for="listaPrecioVenta" class="form-label fw-semibold">
                        Lista de precios
                    </label>
                    <select id="listaPrecioVenta" class="form-select">
                        <option value="0">Precio de venta del artículo</option>
                    </select>
                    <div class="form-text">La lista se aplica a los artículos que agregues a partir de ahora.</div>
                </div>

                <input
                    type="search"
                    id="buscarArticulo"
                    class="form-control form-control-lg mb-3"
                    placeholder="Buscar por nombre, código, código de barras, marca..."
                    autocomplete="off"
                >

                <div
                    id="resultadosArticulos"
                    class="list-group"
                >

                    <div class="text-center text-muted py-4">
                        Escriba para buscar artículos.
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- ============================================================
     MODAL NUEVO CLIENTE
============================================================= -->

<div
    class="modal fade"
    id="modalCliente"
    tabindex="-1"
    aria-hidden="true"
>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">
                    <i class="bi bi-person-plus me-2"></i>
                    Nuevo cliente
                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>

            <form id="formNuevoCliente">

                <input type="hidden" name="csrf" value="<?= e($csrf ?? '') ?>">

                <div class="modal-body">

                    <div class="row g-3">

                        <div class="col-md-8">

                            <label class="form-label">
                                Nombre / Razón social
                            </label>

                            <input
                                type="text"
                                name="nombre"
                                class="form-control"
                                maxlength="255"
                                required
                            >

                        </div>

                        <div class="col-md-4">

                            <label class="form-label">
                                Tipo
                            </label>

                            <select
                                name="tipo_cliente"
                                class="form-select"
                            >

                                <option value="Externo">
                                    Externo
                                </option>

                                <option value="Alquiler">
                                    Alquiler
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Nombre de fantasía
                            </label>

                            <input
                                type="text"
                                name="nombre_fantasia"
                                class="form-control"
                            >

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Tipo documento
                            </label>

                            <input
                                type="text"
                                name="tipo_doc"
                                class="form-control"
                                placeholder="DNI / CUIT"
                            >

                        </div>

                        <div class="col-md-3">

                            <label class="form-label">
                                Nro. documento
                            </label>

                            <input
                                type="text"
                                name="nro_doc"
                                class="form-control"
                            >

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Categoría fiscal
                            </label>

                            <select
                                name="categoria_fiscal"
                                class="form-select"
                            >

                                <option value="Consumidor Final">
                                    Consumidor Final
                                </option>

                                <option value="Responsable Inscripto">
                                    Responsable Inscripto
                                </option>

                                <option value="Monotributista">
                                    Monotributista
                                </option>

                                <option value="Exento">
                                    Exento
                                </option>

                            </select>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Teléfono
                            </label>

                            <input
                                type="text"
                                name="telefono"
                                class="form-control"
                            >

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Email
                            </label>

                            <input
                                type="email"
                                name="email"
                                class="form-control"
                            >

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Dirección
                            </label>

                            <input
                                type="text"
                                name="direccion"
                                class="form-control"
                            >

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal"
                    >
                        Cancelar
                    </button>

                    <button
                        type="submit"
                        class="btn btn-success"
                        id="btnGuardarCliente"
                    >
                        <i class="bi bi-check2-circle me-1"></i>
                        Crear cliente
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<script>

document.addEventListener(
    'DOMContentLoaded',
    () => {

        'use strict';

        /*
        |--------------------------------------------------------------------------
        | ELEMENTOS
        |--------------------------------------------------------------------------
        */

        const form =
            document.getElementById('formVenta');

        const tabla =
            document.getElementById('itemsVenta');

        const modalArticuloElement =
            document.getElementById('modalArticulo');

        const modalClienteElement =
            document.getElementById('modalCliente');

        const modalArticulo =
            modalArticuloElement
                ? bootstrap.Modal.getOrCreateInstance(
                    modalArticuloElement
                )
                : null;

        const modalCliente =
            modalClienteElement
                ? bootstrap.Modal.getOrCreateInstance(
                    modalClienteElement
                )
                : null;

        const buscarArticulo =
            document.getElementById(
                'buscarArticulo'
            );

        const resultadosArticulos =
            document.getElementById(
                'resultadosArticulos'
            );

        const listaPrecioVenta =
            document.getElementById(
                'listaPrecioVenta'
            );

        const clienteBuscar =
            document.getElementById(
                'clienteBuscar'
            );

        const clienteId =
            document.getElementById(
                'clienteId'
            );

        const clienteDocumento =
            document.getElementById(
                'clienteDocumento'
            );

        const clienteInfo =
            document.getElementById(
                'clienteInfo'
            );

        const resultadosClientes =
            document.getElementById(
                'resultadosClientes'
            );

        const tipoComprobante =
            document.getElementById(
                'tipoComprobante'
            );

        const puntoVenta =
            document.getElementById(
                'puntoVenta'
            );

        const numeroComprobante =
            document.getElementById(
                'numeroComprobante'
            );

        const btnConfirmar =
            document.getElementById(
                'btnConfirmarVenta'
            );

        /*
        |--------------------------------------------------------------------------
        | ESTADO
        |--------------------------------------------------------------------------
        */

        let items = [];

        let busquedaArticuloTimer = null;

        let busquedaClienteTimer = null;

        /*
        |--------------------------------------------------------------------------
        | HELPERS
        |--------------------------------------------------------------------------
        */

        const money =
            value => {

                const number =
                    Number(value) || 0;

                return new Intl.NumberFormat(
                    'es-AR',
                    {
                        style: 'currency',
                        currency: 'ARS',
                        minimumFractionDigits: 2
                    }
                ).format(number);
            };

        const escapeHtml =
            value => {

                return String(value ?? '')
                    .replaceAll('&', '&amp;')
                    .replaceAll('<', '&lt;')
                    .replaceAll('>', '&gt;')
                    .replaceAll('"', '&quot;')
                    .replaceAll("'", '&#039;');
            };

        async function getJson(url, options = {}) {

            const response =
                await fetch(
                    url,
                    {
                        ...options,
                        headers: {
                            Accept:
                                'application/json',

                            ...(options.headers || {})
                        }
                    }
                );

            const text =
                await response.text();

            let json = {};

            try {
                json =
                    text
                        ? JSON.parse(text)
                        : {};
            } catch (error) {

                throw new Error(
                    response.ok
                        ? 'El servidor devolvió una respuesta inválida.'
                        : 'El servidor devolvió un error.'
                );
            }

            if (!response.ok) {

                throw new Error(
                    json.message
                    ||
                    json.error
                    ||
                    `Error HTTP ${response.status}.`
                );
            }

            if (
                json.success === false
            ) {
                throw new Error(
                    json.message
                    ||
                    'La operación no pudo realizarse.'
                );
            }

            return json;
        }

        /*
        |--------------------------------------------------------------------------
        | LISTAS DE PRECIOS
        |--------------------------------------------------------------------------
        */

        async function cargarListasPrecios() {
            if (!listaPrecioVenta) return;

            try {
                const json = await getJson('/listas-precios/api/listar?activas=1');
                const listas = Array.isArray(json.data) ? json.data : [];

                listaPrecioVenta.innerHTML =
                    '<option value="0">Precio de venta del artículo</option>' +
                    listas.map(lista => `
                        <option value="${Number(lista.id)}">
                            ${escapeHtml(lista.nombre || ('Lista #' + lista.id))}${Number(lista.es_predeterminada) === 1 ? ' · Predeterminada' : ''}
                        </option>
                    `).join('');

                const predeterminada = listas.find(
                    lista => Number(lista.es_predeterminada) === 1
                );

                if (predeterminada) {
                    listaPrecioVenta.value = String(predeterminada.id);
                }
            } catch (error) {
                console.warn('[Ventas listas de precios]', error.message);
            }
        }

        listaPrecioVenta?.addEventListener('change', () => {
            if (buscarArticulo?.value.trim().length >= 2) {
                buscarArticulos();
            }
        });

        /*
        |--------------------------------------------------------------------------
        | COMPROBANTE
        |--------------------------------------------------------------------------
        */

        async function actualizarNumero() {

            if (
                !tipoComprobante
                ||
                !puntoVenta
                ||
                !numeroComprobante
            ) {
                return;
            }

            const pv =
                Number(
                    puntoVenta.value
                );

            if (
                !Number.isInteger(pv)
                ||
                pv < 1
            ) {
                return;
            }

            try {

                const url =
                    '/ventas/api/siguiente-comprobante'
                    +
                    '?tipo='
                    +
                    encodeURIComponent(
                        tipoComprobante.value
                    )
                    +
                    '&punto_venta='
                    +
                    encodeURIComponent(
                        pv
                    );

                const json =
                    await getJson(url);

                numeroComprobante.value =
                    json.data?.numero
                    ??
                    json.data?.numero_comprobante
                    ??
                    '';

            } catch (error) {

                console.warn(
                    '[Ventas comprobante]',
                    error.message
                );
            }
        }

        tipoComprobante?.addEventListener(
            'change',
            actualizarNumero
        );

        puntoVenta?.addEventListener(
            'change',
            actualizarNumero
        );

        /*
        |--------------------------------------------------------------------------
        | MODAL ARTICULOS
        |--------------------------------------------------------------------------
        */

        document
            .getElementById(
                'btnAgregarArticulo'
            )
            ?.addEventListener(
                'click',
                () => {

                    if (!modalArticulo) {
                        return;
                    }

                    if (buscarArticulo) {
                        buscarArticulo.value = '';
                    }

                    if (resultadosArticulos) {

                        resultadosArticulos.innerHTML = `
                            <div class="text-center text-muted py-4">
                                Escriba para buscar artículos.
                            </div>
                        `;
                    }

                    modalArticulo.show();

                    setTimeout(
                        () => {
                            buscarArticulo?.focus();
                        },
                        250
                    );
                }
            );

        /*
        |--------------------------------------------------------------------------
        | BUSCAR ARTICULOS
        |--------------------------------------------------------------------------
        */

        async function buscarArticulos() {

            if (
                !buscarArticulo
                ||
                !resultadosArticulos
            ) {
                return;
            }

            const termino =
                buscarArticulo.value.trim();

            if (termino.length < 2) {

                resultadosArticulos.innerHTML = `
                    <div class="text-center text-muted py-4">
                        Escriba al menos 2 caracteres.
                    </div>
                `;

                return;
            }

            resultadosArticulos.innerHTML = `
                <div class="text-center py-4">
                    <div class="spinner-border spinner-border-sm"></div>
                    <span class="ms-2">
                        Buscando artículos...
                    </span>
                </div>
            `;

            try {

                console.debug(
                    '[Ventas] buscando artículos:',
                    termino
                );

                const json =
                    await getJson(
                        '/ventas/api/articulos/buscar?q='
                        +
                        encodeURIComponent(
                            termino
                        )
                        +
                        '&limit=30&lista_precio_id='
                        +
                        encodeURIComponent(
                            Number(listaPrecioVenta?.value || 0)
                        )
                    );

                const articulos =
                    Array.isArray(
                        json.data
                    )
                        ? json.data
                        : [];

                if (!articulos.length) {

                    resultadosArticulos.innerHTML = `
                        <div class="text-center text-muted py-4">
                            No se encontraron artículos.
                        </div>
                    `;

                    return;
                }

                resultadosArticulos.innerHTML =
                    articulos
                        .map(
                            articulo => {

                                const stock =
                                    Number(
                                        articulo.stock_actual
                                    )
                                    || 0;

                                const precio =
                                    Number(
                                        articulo.precio_lista
                                        ?? articulo.precio_venta
                                    )
                                    || 0;

                                const codigo =
                                    articulo.codigo_parte
                                    ||
                                    articulo.codigo_barras
                                    ||
                                    '-';

                                return `
                                    <button
                                        type="button"
                                        class="list-group-item list-group-item-action"
                                        data-articulo-id="${Number(articulo.id)}"
                                    >

                                        <div class="d-flex justify-content-between align-items-start gap-3">

                                            <div>

                                                <div class="fw-semibold">

                                                    ${escapeHtml(
                                                        articulo.nombre_insumo
                                                    )}

                                                </div>

                                                <div class="small text-muted">

                                                    ${
                                                        escapeHtml(
                                                            articulo.marca
                                                            || ''
                                                        )
                                                    }

                                                    ${
                                                        articulo.modelo
                                                            ? ' · '
                                                            +
                                                            escapeHtml(
                                                                articulo.modelo
                                                            )
                                                            : ''
                                                    }

                                                </div>

                                                <div class="small text-muted">

                                                    Código:
                                                    ${escapeHtml(codigo)}

                                                </div>

                                            </div>

                                            <div class="text-end">

                                                <div class="fw-bold">
                                                    ${money(precio)}
                                                </div>

                                                <div class="small ${
                                                    stock > 0
                                                        ? 'text-success'
                                                        : 'text-danger'
                                                }">

                                                    Stock:
                                                    ${stock}

                                                </div>

                                            </div>

                                        </div>

                                    </button>
                                `;
                            }
                        )
                        .join('');

            } catch (error) {

                console.error(
                    '[Ventas artículos]',
                    error
                );

                resultadosArticulos.innerHTML = `
                    <div class="alert alert-danger mb-0">
                        <strong>Error:</strong>
                        ${escapeHtml(error.message)}
                    </div>
                `;
            }
        }

        buscarArticulo?.addEventListener(
            'input',
            () => {

                clearTimeout(
                    busquedaArticuloTimer
                );

                busquedaArticuloTimer =
                    setTimeout(
                        buscarArticulos,
                        300
                    );
            }
        );

        /*
        |--------------------------------------------------------------------------
        | SELECCIONAR ARTICULO
        |--------------------------------------------------------------------------
        */

        resultadosArticulos
            ?.addEventListener(
                'click',
                async event => {

                    const button =
                        event.target.closest(
                            '[data-articulo-id]'
                        );

                    if (!button) {
                        return;
                    }

                    const id =
                        Number(
                            button.dataset.articuloId
                        );

                    if (
                        !Number.isInteger(id)
                        ||
                        id <= 0
                    ) {
                        return;
                    }

                    button.disabled = true;

                    try {

                        const json =
                            await getJson(
                                '/ventas/api/articulos/'
                                +
                                id
                                +
                                '?lista_precio_id='
                                +
                                encodeURIComponent(
                                    Number(listaPrecioVenta?.value || 0)
                                )
                            );

                        if (
                            !json.data
                        ) {
                            throw new Error(
                                'El servidor no devolvió los datos del artículo.'
                            );
                        }

                        agregarArticulo(
                            json.data
                        );

                        modalArticulo?.hide();

                    } catch (error) {

                        console.error(
                            '[Ventas artículo]',
                            error
                        );

                        alert(
                            error.message
                        );

                    } finally {

                        button.disabled =
                            false;
                    }
                }
            );

        /*
        |--------------------------------------------------------------------------
        | AGREGAR ARTICULO
        |--------------------------------------------------------------------------
        */

        function agregarArticulo(
            articulo
        ) {

            const id =
                Number(
                    articulo.id
                );

            if (
                !Number.isInteger(id)
                ||
                id <= 0
            ) {
                return;
            }

            const existente =
                items.find(
                    item =>
                        Number(
                            item.insumo_id
                        )
                        ===
                        id
                );

            if (existente) {

                const nuevaCantidad =
                    Number(
                        existente.cantidad
                    )
                    + 1;

                if (
                    nuevaCantidad
                    <=
                    Number(
                        existente.stock_actual
                    )
                ) {
                    existente.cantidad =
                        nuevaCantidad;
                }

            } else {

                items.push({

                    insumo_id:
                        id,

                    descripcion:
                        articulo.nombre_insumo
                        ||
                        'Artículo',

                    cantidad:
                        1,

                    precio_unitario:
                        Number(
                            articulo.precio_lista
                            ?? articulo.precio_venta
                        )
                        || 0,

                    descuento:
                        0,

                    impuesto_tipo:
                        'IVA',

                    impuesto_porcentaje:
                        21,

                    stock_actual:
                        Number(
                            articulo.stock_actual
                        )
                        || 0
                });
            }

            renderItems();
        }

        /*
        |--------------------------------------------------------------------------
        | RENDER ITEMS
        |--------------------------------------------------------------------------
        */

        function renderItems() {

            if (!tabla) {
                return;
            }

            if (!items.length) {

                tabla.innerHTML = `
                    <tr id="filaVacia">

                        <td
                            colspan="7"
                            class="text-center text-muted py-5"
                        >

                            <i class="bi bi-box-seam fs-2 d-block mb-2"></i>

                            No hay artículos agregados.

                        </td>

                    </tr>
                `;

                calcularTotales();

                return;
            }

            tabla.innerHTML =
                items
                    .map(
                        (item, index) => {

                            const cantidad =
                                Number(
                                    item.cantidad
                                )
                                || 0;

                            const precio =
                                Number(
                                    item.precio_unitario
                                )
                                || 0;

                            const descuento =
                                Number(
                                    item.descuento
                                )
                                || 0;

                            const porcentaje =
                                Number(
                                    item.impuesto_porcentaje
                                )
                                || 0;

                            const bruto =
                                cantidad
                                * precio;

                            const descuentoAplicado =
                                Math.min(
                                    Math.max(
                                        descuento,
                                        0
                                    ),
                                    bruto
                                );

                            const neto =
                                Math.max(
                                    bruto
                                    -
                                    descuentoAplicado,
                                    0
                                );

                            const impuesto =
                                neto
                                *
                                porcentaje
                                / 100;

                            const total =
                                neto
                                +
                                impuesto;

                            return `
                                <tr data-index="${index}">

                                    <td>

                                        <div class="fw-semibold">
                                            ${escapeHtml(
                                                item.descripcion
                                            )}
                                        </div>

                                        <div class="small text-muted">
                                            Stock:
                                            ${Number(
                                                item.stock_actual
                                            )}
                                        </div>

                                    </td>

                                    <td>

                                        <input
                                            type="number"
                                            class="form-control form-control-sm item-cantidad"
                                            min="0.001"
                                            step="0.001"
                                            value="${cantidad}"
                                        >

                                    </td>

                                    <td>

                                        <input
                                            type="number"
                                            class="form-control form-control-sm item-precio text-end"
                                            min="0"
                                            step="0.01"
                                            value="${precio.toFixed(2)}"
                                        >

                                    </td>

                                    <td>

                                        <input
                                            type="number"
                                            class="form-control form-control-sm item-descuento text-end"
                                            min="0"
                                            step="0.01"
                                            value="${descuento.toFixed(2)}"
                                        >

                                    </td>

                                    <td>

                                        <input
                                            type="number"
                                            class="form-control form-control-sm item-iva text-end"
                                            min="0"
                                            max="100"
                                            step="0.01"
                                            value="${porcentaje.toFixed(2)}"
                                        >

                                    </td>

                                    <td class="text-end fw-semibold">

                                        ${money(total)}

                                    </td>

                                    <td class="text-end">

                                        <button
                                            type="button"
                                            class="btn btn-sm btn-outline-danger item-eliminar"
                                            title="Eliminar"
                                        >

                                            <i class="bi bi-trash"></i>

                                        </button>

                                    </td>

                                </tr>
                            `;
                        }
                    )
                    .join('');

            calcularTotales();
        }

        /*
        |--------------------------------------------------------------------------
        | CAMBIOS ITEMS
        |--------------------------------------------------------------------------
        */

        tabla?.addEventListener(
            'input',
            event => {

                const row =
                    event.target.closest(
                        'tr[data-index]'
                    );

                if (!row) {
                    return;
                }

                const index =
                    Number(
                        row.dataset.index
                    );

                const item =
                    items[index];

                if (!item) {
                    return;
                }

                if (
                    event.target.classList.contains(
                        'item-cantidad'
                    )
                ) {

                    item.cantidad =
                        Number(
                            event.target.value
                        )
                        || 0;
                }

                if (
                    event.target.classList.contains(
                        'item-precio'
                    )
                ) {

                    item.precio_unitario =
                        Number(
                            event.target.value
                        )
                        || 0;
                }

                if (
                    event.target.classList.contains(
                        'item-descuento'
                    )
                ) {

                    item.descuento =
                        Number(
                            event.target.value
                        )
                        || 0;
                }

                if (
                    event.target.classList.contains(
                        'item-iva'
                    )
                ) {

                    item.impuesto_porcentaje =
                        Number(
                            event.target.value
                        )
                        || 0;
                }

                actualizarTotalFila(
                    row,
                    item
                );

                calcularTotales();
            }
        );

        function actualizarTotalFila(
            row,
            item
        ) {

            const cantidad =
                Number(
                    item.cantidad
                )
                || 0;

            const precio =
                Number(
                    item.precio_unitario
                )
                || 0;

            const descuento =
                Math.max(
                    Number(
                        item.descuento
                    )
                    || 0,
                    0
                );

            const porcentaje =
                Math.max(
                    Number(
                        item.impuesto_porcentaje
                    )
                    || 0,
                    0
                );

            const bruto =
                cantidad
                * precio;

            const descuentoAplicado =
                Math.min(
                    descuento,
                    bruto
                );

            const neto =
                Math.max(
                    bruto
                    -
                    descuentoAplicado,
                    0
                );

            const impuesto =
                neto
                *
                porcentaje
                / 100;

            const total =
                neto
                +
                impuesto;

            const celda =
                row.querySelector(
                    'td:nth-child(6)'
                );

            if (celda) {
                celda.textContent =
                    money(total);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | ELIMINAR
        |--------------------------------------------------------------------------
        */

        tabla?.addEventListener(
            'click',
            event => {

                const button =
                    event.target.closest(
                        '.item-eliminar'
                    );

                if (!button) {
                    return;
                }

                const row =
                    button.closest(
                        'tr[data-index]'
                    );

                if (!row) {
                    return;
                }

                const index =
                    Number(
                        row.dataset.index
                    );

                items.splice(
                    index,
                    1
                );

                renderItems();
            }
        );

        /*
        |--------------------------------------------------------------------------
        | TOTALES
        |--------------------------------------------------------------------------
        */

        function calcularTotales() {

            let netoTotal = 0;

            let descuentoTotal = 0;

            let impuestoTotal = 0;

            let total = 0;

            items.forEach(
                item => {

                    const cantidad =
                        Number(
                            item.cantidad
                        )
                        || 0;

                    const precio =
                        Number(
                            item.precio_unitario
                        )
                        || 0;

                    const descuento =
                        Math.max(
                            Number(
                                item.descuento
                            )
                            || 0,
                            0
                        );

                    const porcentaje =
                        Math.max(
                            Number(
                                item.impuesto_porcentaje
                            )
                            || 0,
                            0
                        );

                    const bruto =
                        cantidad
                        * precio;

                    const descuentoAplicado =
                        Math.min(
                            descuento,
                            bruto
                        );

                    const neto =
                        Math.max(
                            bruto
                            -
                            descuentoAplicado,
                            0
                        );

                    const impuesto =
                        neto
                        *
                        porcentaje
                        / 100;

                    netoTotal +=
                        neto;

                    descuentoTotal +=
                        descuentoAplicado;

                    impuestoTotal +=
                        impuesto;

                    total +=
                        neto
                        +
                        impuesto;
                }
            );

            const subtotal =
                document.getElementById(
                    'subtotalVenta'
                );

            const descuento =
                document.getElementById(
                    'descuentoVenta'
                );

            const impuesto =
                document.getElementById(
                    'impuestoVenta'
                );

            const totalElement =
                document.getElementById(
                    'totalVenta'
                );

            if (subtotal) {
                subtotal.textContent =
                    money(netoTotal);
            }

            if (descuento) {
                descuento.textContent =
                    money(descuentoTotal);
            }

            if (impuesto) {
                impuesto.textContent =
                    money(impuestoTotal);
            }

            if (totalElement) {
                totalElement.textContent =
                    money(total);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CLIENTES
        |--------------------------------------------------------------------------
        */

        async function buscarClientes() {

            if (
                !clienteBuscar
                ||
                !resultadosClientes
            ) {
                return;
            }

            const termino =
                clienteBuscar.value.trim();

            if (
                termino.length < 2
            ) {

                resultadosClientes.style.display =
                    'none';

                resultadosClientes.innerHTML =
                    '';

                return;
            }

            resultadosClientes.style.display =
                'block';

            resultadosClientes.innerHTML = `
                <div class="list-group-item text-center">

                    <span class="spinner-border spinner-border-sm"></span>

                    Buscando...

                </div>
            `;

            try {

                const json =
                    await getJson(
                        '/ventas/api/clientes?q='
                        +
                        encodeURIComponent(
                            termino
                        )
                    );

                const clientes =
                    Array.isArray(
                        json.data
                    )
                        ? json.data
                        : [];

                if (!clientes.length) {

                    resultadosClientes.innerHTML = `
                        <div class="list-group-item text-muted">
                            No se encontraron clientes.
                        </div>
                    `;

                    return;
                }

                resultadosClientes.innerHTML =
                    clientes
                        .map(
                            c => `
                                <button
                                    type="button"
                                    class="list-group-item list-group-item-action"
                                    data-cliente-id="${Number(c.id)}"
                                >

                                    <div class="fw-semibold">
                                        ${escapeHtml(
                                            c.nombre
                                        )}
                                    </div>

                                    <div class="small text-muted">

                                        ${
                                            escapeHtml(
                                                c.nro_doc
                                                ||
                                                c.telefono
                                                ||
                                                c.email
                                                ||
                                                ''
                                            )
                                        }

                                    </div>

                                </button>
                            `
                        )
                        .join('');

            } catch (error) {

                resultadosClientes.innerHTML = `
                    <div class="list-group-item text-danger">
                        ${escapeHtml(
                            error.message
                        )}
                    </div>
                `;
            }
        }

        clienteBuscar?.addEventListener(
            'input',
            () => {

                clearTimeout(
                    busquedaClienteTimer
                );

                busquedaClienteTimer =
                    setTimeout(
                        buscarClientes,
                        300
                    );
            }
        );

        document
            .getElementById(
                'btnBuscarCliente'
            )
            ?.addEventListener(
                'click',
                buscarClientes
            );

        resultadosClientes?.addEventListener(
            'click',
            async event => {

                const button =
                    event.target.closest(
                        '[data-cliente-id]'
                    );

                if (!button) {
                    return;
                }

                const id =
                    Number(
                        button.dataset.clienteId
                    );

                try {

                    const json =
                        await getJson(
                            '/ventas/api/clientes/'
                            +
                            id
                        );

                    seleccionarCliente(
                        json.data
                    );

                } catch (error) {

                    alert(
                        error.message
                    );
                }
            }
        );

        function seleccionarCliente(
            cliente
        ) {

            if (!cliente) {
                return;
            }

            if (clienteId) {
                clienteId.value =
                    cliente.id
                    ??
                    '';
            }

            if (clienteBuscar) {
                clienteBuscar.value =
                    cliente.nombre
                    ??
                    '';
            }

            if (clienteDocumento) {
                clienteDocumento.value =
                    cliente.nro_doc
                    ??
                    '';
            }

            if (clienteInfo) {
                clienteInfo.textContent =
                    cliente.categoria_fiscal
                    ??
                    '';
            }

            if (resultadosClientes) {

                resultadosClientes.style.display =
                    'none';

                resultadosClientes.innerHTML =
                    '';
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CONSUMIDOR FINAL
        |--------------------------------------------------------------------------
        */

        document
            .getElementById(
                'btnConsumidorFinal'
            )
            ?.addEventListener(
                'click',
                () => {

                    if (clienteId) {
                        clienteId.value =
                            '';
                    }

                    if (clienteBuscar) {
                        clienteBuscar.value =
                            'Consumidor Final';
                    }

                    if (clienteDocumento) {
                        clienteDocumento.value =
                            '';
                    }

                    if (clienteInfo) {
                        clienteInfo.textContent =
                            'Consumidor Final';
                    }

                    if (resultadosClientes) {
                        resultadosClientes.style.display =
                            'none';
                    }
                }
            );

        /*
        |--------------------------------------------------------------------------
        | NUEVO CLIENTE
        |--------------------------------------------------------------------------
        */

        document
            .getElementById(
                'btnNuevoCliente'
            )
            ?.addEventListener(
                'click',
                () => {

                    document
                        .getElementById(
                            'formNuevoCliente'
                        )
                        ?.reset();

                    modalCliente?.show();
                }
            );

        document
            .getElementById(
                'formNuevoCliente'
            )
            ?.addEventListener(
                'submit',
                async event => {

                    event.preventDefault();

                    const button =
                        document.getElementById(
                            'btnGuardarCliente'
                        );

                    if (!button) {
                        return;
                    }

                    button.disabled =
                        true;

                    button.innerHTML = `
                        <span class="spinner-border spinner-border-sm me-1"></span>
                        Guardando...
                    `;

                    try {

                        const data =
                            Object.fromEntries(
                                new FormData(
                                    event.target
                                ).entries()
                            );

                        const json =
                            await getJson(
                                '/ventas/api/clientes',
                                {
                                    method: 'POST',

                                    headers: {
                                        'Content-Type':
                                            'application/json',
                                        'X-CSRF-TOKEN':
                                            document.querySelector('[name="csrf"]')?.value || ''
                                    },

                                    body:
                                        JSON.stringify(
                                            data
                                        )
                                }
                            );

                        if (!json.data) {
                            throw new Error(
                                'El servidor no devolvió el cliente creado.'
                            );
                        }

                        seleccionarCliente(
                            json.data
                        );

                        modalCliente?.hide();

                    } catch (error) {

                        alert(
                            error.message
                        );

                    } finally {

                        button.disabled =
                            false;

                        button.innerHTML = `
                            <i class="bi bi-check2-circle me-1"></i>
                            Crear cliente
                        `;
                    }
                }
            );

        /*
        |--------------------------------------------------------------------------
        | CLICK FUERA CLIENTES
        |--------------------------------------------------------------------------
        */

        document.addEventListener(
            'click',
            event => {

                if (
                    !event.target.closest(
                        '#clienteBuscar'
                    )
                    &&
                    !event.target.closest(
                        '#resultadosClientes'
                    )
                    &&
                    !event.target.closest(
                        '#btnBuscarCliente'
                    )
                ) {

                    if (
                        resultadosClientes
                    ) {
                        resultadosClientes.style.display =
                            'none';
                    }
                }
            }
        );

        /*
        |--------------------------------------------------------------------------
        | CONFIRMAR
        |--------------------------------------------------------------------------
        */

        form?.addEventListener(
            'submit',
            async event => {

                event.preventDefault();

                if (!items.length) {

                    alert(
                        'Debe agregar al menos un artículo.'
                    );

                    return;
                }

                /*
                |--------------------------------------------------------------------------
                | VALIDACION FRONTEND
                |--------------------------------------------------------------------------
                */

                for (
                    const item of items
                ) {

                    const cantidad =
                        Number(
                            item.cantidad
                        );

                    const stock =
                        Number(
                            item.stock_actual
                        );

                    if (
                        !Number.isFinite(
                            cantidad
                        )
                        ||
                        cantidad <= 0
                    ) {

                        alert(
                            'Hay una cantidad inválida.'
                        );

                        return;
                    }

                    if (
                        cantidad > stock
                    ) {

                        alert(
                            'Stock insuficiente para '
                            +
                            item.descripcion
                            +
                            '. Disponible: '
                            +
                            stock
                        );

                        return;
                    }
                }

                const datos =
                    Object.fromEntries(
                        new FormData(
                            form
                        ).entries()
                    );

                datos.items =
                    items.map(
                        item => ({
                            tipo:
                                'INSUMO',

                            insumo_id:
                                Number(
                                    item.insumo_id
                                ),

                            descripcion:
                                item.descripcion,

                            cantidad:
                                Number(
                                    item.cantidad
                                ),

                            precio_unitario:
                                Number(
                                    item.precio_unitario
                                ),

                            descuento:
                                Number(
                                    item.descuento
                                ),

                            impuesto_tipo:
                                'IVA',

                            impuesto_porcentaje:
                                Number(
                                    item.impuesto_porcentaje
                                )
                        })
                    );

                if (btnConfirmar) {

                    btnConfirmar.disabled =
                        true;

                    btnConfirmar.innerHTML = `
                        <span class="spinner-border spinner-border-sm me-2"></span>
                        Registrando venta...
                    `;
                }

                try {

                    const json =
                        await getJson(
                            '/ventas/api/confirmar',
                            {
                                method: 'POST',

                                headers: {
                                    'Content-Type':
                                        'application/json',
                                    'X-CSRF-TOKEN':
                                        document.querySelector('[name="csrf"]')?.value || ''
                                },

                                body:
                                    JSON.stringify(
                                        datos
                                    )
                            }
                        );

                    const id =
                        json.data?.id
                        ??
                        json.id
                        ??
                        '';

                    if (!id) {

                        throw new Error(
                            'La venta fue registrada pero no se recibió su identificador.'
                        );
                    }

                    window.location.href =
                        '/ventas/'
                        +
                        id;

                } catch (error) {

                    alert(
                        error.message
                    );

                    if (btnConfirmar) {

                        btnConfirmar.disabled =
                            false;

                        btnConfirmar.innerHTML = `
                            <i class="bi bi-check2-circle me-2"></i>
                            Confirmar venta
                        `;
                    }
                }
            }
        );

        /*
        |--------------------------------------------------------------------------
        | INICIALIZACION
        |--------------------------------------------------------------------------
        */

        renderItems();

        /*
         * No dejamos que un problema de numeración
         * impida utilizar el buscador de artículos.
         */

        actualizarNumero().catch(
            error => {
                console.warn(
                    '[Ventas inicialización]',
                    error
                );
            }
        );

        cargarListasPrecios();

    }
);

</script>