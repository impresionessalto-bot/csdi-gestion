<?php

declare(strict_types=1);

$venta = $venta ?? [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('money')) {
    function money(float|int|string|null $value): string
    {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            2,
            ',',
            '.'
        );
    }
}

$id = (int) ($venta['id'] ?? 0);
?>

<div class="container-fluid py-4">

```
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

    <div>

        <h1 class="h3 fw-bold mb-1">
            <i class="bi bi-pencil-square me-2"></i>
            Editar venta
        </h1>

        <p class="text-muted mb-0">
            Venta #<?= $id ?>
        </p>

    </div>

    <div class="d-flex gap-2">

        <a
            href="/ventas/<?= $id ?>"
            class="btn btn-outline-primary"
        >
            <i class="bi bi-eye me-1"></i>
            Ver venta
        </a>

        <a
            href="/ventas"
            class="btn btn-outline-secondary"
        >
            Volver
        </a>

    </div>

</div>


<div class="alert alert-warning border-0 shadow-sm">

    <div class="d-flex gap-3">

        <i class="bi bi-exclamation-triangle fs-4"></i>

        <div>

            <strong>Edición de venta</strong>

            <div class="small mt-1">
                La estructura de edición está preparada,
                pero la modificación de ventas todavía no está
                habilitada en el servicio.
            </div>

        </div>

    </div>

</div>


<div class="row g-4">

    <div class="col-12 col-lg-8">

        <div class="card border-0 shadow-sm">

            <div class="card-header bg-white py-3">

                <strong>
                    Datos de la venta
                </strong>

            </div>

            <div class="card-body">

                <div class="row g-3">

                    <div class="col-md-6">

                        <label class="form-label">
                            Cliente
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= e(
                                $venta['cliente_nombre']
                                ?? $venta['cliente']
                                ?? 'Consumidor Final'
                            ) ?>"
                            readonly
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label">
                            Comprobante
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= e(
                                $venta['numero_comprobante']
                                ?? $venta['comprobante']
                                ?? '#' . $id
                            ) ?>"
                            readonly
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label">
                            Estado
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= e(
                                $venta['estado']
                                ?? 'Registrada'
                            ) ?>"
                            readonly
                        >

                    </div>

                    <div class="col-md-6">

                        <label class="form-label">
                            Total
                        </label>

                        <input
                            type="text"
                            class="form-control fw-bold"
                            value="<?= money(
                                $venta['total_venta']
                                ?? $venta['total']
                                ?? 0
                            ) ?>"
                            readonly
                        >

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="col-12 col-lg-4">

        <div class="card border-0 shadow-sm">

            <div class="card-body">

                <button
                    type="button"
                    class="btn btn-primary w-100 mb-2"
                    disabled
                >
                    <i class="bi bi-check-lg me-1"></i>
                    Guardar cambios
                </button>

                <a
                    href="/ventas/<?= $id ?>"
                    class="btn btn-outline-secondary w-100"
                >
                    Cancelar
                </a>

            </div>

        </div>

    </div>

</div>