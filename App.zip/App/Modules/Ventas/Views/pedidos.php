<?php

declare(strict_types=1);
?>

<div class="container-fluid py-4">

```
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

    <div>

        <h1 class="h3 fw-bold mb-1">
            <i class="bi bi-clipboard-check me-2"></i>
            Pedidos
        </h1>

        <p class="text-muted mb-0">
            Gestión y seguimiento de pedidos de clientes.
        </p>

    </div>

    <a
        href="/ventas/nueva"
        class="btn btn-primary"
    >
        <i class="bi bi-plus-lg me-1"></i>
        Nuevo pedido
    </a>

</div>


<div class="card border-0 shadow-sm">

    <div class="card-body text-center py-5">

        <i class="bi bi-clipboard-check fs-1 text-muted d-block mb-3"></i>

        <h5 class="fw-bold">
            Pedidos
        </h5>

        <p class="text-muted mb-4">
            Acá se mostrarán los pedidos pendientes,
            preparados y entregados.
        </p>

        <a
            href="/ventas/nueva"
            class="btn btn-outline-primary"
        >
            <i class="bi bi-plus-lg me-1"></i>
            Registrar pedido
        </a>

    </div>

</div>
```

</div>
