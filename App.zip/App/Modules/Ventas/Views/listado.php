<?php

declare(strict_types=1);

$ventas = $ventas ?? [];

$filtros = $filtros ?? [];

$pagina = max(
    1,
    (int) (
        $pagination['pagina']
        ?? $pagina
        ?? 1
    )
);

$porPagina = max(
    1,
    (int) (
        $pagination['por_pagina']
        ?? $porPagina
        ?? 20
    )
);

$total = max(
    0,
    (int) (
        $pagination['total']
        ?? $total
        ?? count($ventas)
    )
);

$totalPaginas = max(
    1,
    (int) ceil(
        $total / $porPagina
    )
);

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('money')) {
    function money(float|int|string|null $value): string
    {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            2,
            ',',
            '.'
        );
    }
}

if (!function_exists('ventaFecha')) {
    function ventaFecha(mixed $value): string
    {
        if (!$value) {
            return '-';
        }

        $timestamp = strtotime((string) $value);

        if ($timestamp === false) {
            return e($value);
        }

        return date('d/m/Y H:i', $timestamp);
    }
}

if (!function_exists('estadoVentaBadge')) {
    function estadoVentaBadge(mixed $estado): string
    {
        $estado = strtoupper(
            trim((string) $estado)
        );

        return match ($estado) {

            'CONFIRMADA',
            'CONFIRMADO',
            'ACTIVA' =>
                'text-bg-success',

            'BORRADOR' =>
                'text-bg-warning',

            'ANULADA',
            'ANULADO',
            'CANCELADA',
            'CANCELADO' =>
                'text-bg-danger',

            default =>
                'text-bg-secondary',
        };
    }
}

$query = [];

foreach (
    [
        'q',
        'cliente',
        'estado',
        'fecha_desde',
        'fecha_hasta',
    ] as $campo
) {

    $valor =
        $filtros[$campo]
        ?? $_GET[$campo]
        ?? '';

    if ($valor !== '') {
        $query[$campo] = $valor;
    }
}

function listadoUrl(
    array $extra = []
): string {

    global $query;

    $params =
        array_merge(
            $query,
            $extra
        );

    $params =
        array_filter(
            $params,
            static fn ($value) =>
                $value !== ''
                && $value !== null
        );

    return '/ventas/listado'
        . (
            $params
                ? '?' . http_build_query($params)
                : ''
        );
}
?>

<div class="container-fluid py-4">

    <!-- ================================================================
         HEADER
    ================================================================= -->

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-receipt me-2"></i>

                Listado de ventas

            </h1>

            <p class="text-muted mb-0">
                Consultá y administrá las ventas registradas.
            </p>

        </div>

        <div class="d-flex gap-2">

            <a
                href="/ventas"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Ventas
            </a>

            <a
                href="/ventas/nueva"
                class="btn btn-primary"
            >
                <i class="bi bi-plus-lg me-1"></i>
                Nueva venta
            </a>

        </div>

    </div>


    <!-- ================================================================
         FILTROS
    ================================================================= -->

    <div class="card border-0 shadow-sm mb-4">

        <div class="card-body">

            <form
                method="get"
                action="/ventas/listado"
            >

                <div class="row g-3">

                    <div class="col-12 col-lg-4">

                        <label
                            for="q"
                            class="form-label fw-semibold"
                        >
                            Buscar
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">
                                <i class="bi bi-search"></i>
                            </span>

                            <input
                                type="search"
                                id="q"
                                name="q"
                                class="form-control"
                                value="<?= e(
                                    $filtros['q']
                                    ?? $_GET['q']
                                    ?? ''
                                ) ?>"
                                placeholder="Número, cliente o comprobante..."
                            >

                        </div>

                    </div>


                    <div class="col-12 col-md-6 col-lg-2">

                        <label
                            for="estado"
                            class="form-label fw-semibold"
                        >
                            Estado
                        </label>

                        <select
                            id="estado"
                            name="estado"
                            class="form-select"
                        >

                            <?php
                            $estadoActual =
                                $filtros['estado']
                                ?? $_GET['estado']
                                ?? '';
                            ?>

                            <option value="">
                                Todos
                            </option>

                            <option
                                value="CONFIRMADA"
                                <?= $estadoActual === 'CONFIRMADA'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Confirmada
                            </option>

                            <option
                                value="BORRADOR"
                                <?= $estadoActual === 'BORRADOR'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Borrador
                            </option>

                            <option
                                value="ANULADA"
                                <?= $estadoActual === 'ANULADA'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Anulada
                            </option>

                        </select>

                    </div>


                    <div class="col-12 col-md-6 col-lg-2">

                        <label
                            for="fecha_desde"
                            class="form-label fw-semibold"
                        >
                            Desde
                        </label>

                        <input
                            type="date"
                            id="fecha_desde"
                            name="fecha_desde"
                            class="form-control"
                            value="<?= e(
                                $filtros['fecha_desde']
                                ?? $_GET['fecha_desde']
                                ?? ''
                            ) ?>"
                        >

                    </div>


                    <div class="col-12 col-md-6 col-lg-2">

                        <label
                            for="fecha_hasta"
                            class="form-label fw-semibold"
                        >
                            Hasta
                        </label>

                        <input
                            type="date"
                            id="fecha_hasta"
                            name="fecha_hasta"
                            class="form-control"
                            value="<?= e(
                                $filtros['fecha_hasta']
                                ?? $_GET['fecha_hasta']
                                ?? ''
                            ) ?>"
                        >

                    </div>


                    <div class="col-12 col-md-6 col-lg-2 d-flex align-items-end">

                        <div class="d-flex gap-2 w-100">

                            <button
                                type="submit"
                                class="btn btn-primary flex-grow-1"
                            >
                                <i class="bi bi-search me-1"></i>
                                Buscar
                            </button>

                            <a
                                href="/ventas/listado"
                                class="btn btn-outline-secondary"
                                title="Limpiar filtros"
                            >
                                <i class="bi bi-x-lg"></i>
                            </a>

                        </div>

                    </div>

                </div>

            </form>

        </div>

    </div>


    <!-- ================================================================
         RESULTADOS
    ================================================================= -->

    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white py-3">

            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">

                <strong>

                    <i class="bi bi-list-ul me-2"></i>

                    Ventas registradas

                </strong>

                <span class="text-muted small">

                    <?= number_format(
                        $total,
                        0,
                        ',',
                        '.'
                    ) ?>

                    resultado<?= $total === 1 ? '' : 's' ?>

                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (!$ventas): ?>

                <div class="text-center py-5 text-muted">

                    <i class="bi bi-search fs-1 d-block mb-3"></i>

                    <div class="fw-semibold mb-1">
                        No se encontraron ventas.
                    </div>

                    <div class="small">
                        Probá modificar los filtros de búsqueda.
                    </div>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-3">
                                    #
                                </th>

                                <th>
                                    Comprobante
                                </th>

                                <th>
                                    Fecha
                                </th>

                                <th>
                                    Cliente
                                </th>

                                <th>
                                    Vendedor
                                </th>

                                <th class="text-center">
                                    Estado
                                </th>

                                <th class="text-end">
                                    Total
                                </th>

                                <th
                                    class="text-end pe-3"
                                    style="width:110px"
                                >
                                    Acción
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php foreach ($ventas as $venta): ?>

                                <?php

                                $id =
                                    (int) (
                                        $venta['id']
                                        ?? 0
                                    );

                                $cliente =
                                    $venta['cliente_nombre']
                                    ?? $venta['cliente']
                                    ?? 'Consumidor Final';

                                $vendedor =
                                    $venta['vendedor_nombre']
                                    ?? $venta['vendedor']
                                    ?? '-';

                                $tipo =
                                    $venta['tipo_comprobante']
                                    ?? $venta['tipo']
                                    ?? 'COMPROBANTE';

                                $puntoVenta =
                                    (int) (
                                        $venta['punto_venta']
                                        ?? 0
                                    );

                                $numero =
                                    (int) (
                                        $venta['numero_comprobante']
                                        ?? $venta['numero']
                                        ?? 0
                                    );

                                $estado =
                                    $venta['estado']
                                    ?? 'CONFIRMADA';

                                $totalVenta =
                                    $venta['total_venta']
                                    ?? $venta['total']
                                    ?? 0;

                                ?>

                                <tr>

                                    <td class="ps-3 fw-semibold">
                                        <?= $id ?>
                                    </td>


                                    <td>

                                        <?php if (
                                            $puntoVenta > 0
                                            || $numero > 0
                                        ): ?>

                                            <div class="fw-semibold">

                                                <?= e($tipo) ?>

                                            </div>

                                            <div class="small text-muted">

                                                <?= str_pad(
                                                    (string) $puntoVenta,
                                                    4,
                                                    '0',
                                                    STR_PAD_LEFT
                                                ) ?>

                                                -

                                                <?= str_pad(
                                                    (string) $numero,
                                                    8,
                                                    '0',
                                                    STR_PAD_LEFT
                                                ) ?>

                                            </div>

                                        <?php else: ?>

                                            <span class="text-muted">
                                                -
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <?= ventaFecha(
                                            $venta['fecha']
                                            ?? $venta['created_at']
                                            ?? null
                                        ) ?>

                                    </td>


                                    <td>

                                        <div class="fw-semibold">

                                            <?= e(
                                                $cliente
                                            ) ?>

                                        </div>

                                    </td>


                                    <td>

                                        <?= e(
                                            $vendedor
                                        ) ?>

                                    </td>


                                    <td class="text-center">

                                        <span
                                            class="badge <?= estadoVentaBadge(
                                                $estado
                                            ) ?>"
                                        >
                                            <?= e(
                                                strtoupper(
                                                    (string) $estado
                                                )
                                            ) ?>
                                        </span>

                                    </td>


                                    <td class="text-end fw-semibold">

                                        <?= money(
                                            $totalVenta
                                        ) ?>

                                    </td>


                                    <td class="text-end pe-3">

                                        <a
                                            href="/ventas/ver/<?= $id ?>"
                                            class="btn btn-sm btn-outline-primary"
                                            title="Ver venta"
                                        >
                                            <i class="bi bi-eye"></i>
                                        </a>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>


        <!-- ============================================================
             PAGINACIÓN
        ============================================================= -->

        <?php if (
            $totalPaginas > 1
        ): ?>

            <div class="card-footer bg-white">

                <nav
                    aria-label="Paginación de ventas"
                >

                    <ul class="pagination justify-content-center mb-0">

                        <li
                            class="page-item <?= $pagina <= 1
                                ? 'disabled'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="<?= e(
                                    listadoUrl([
                                        'page' =>
                                            max(
                                                1,
                                                $pagina - 1
                                            )
                                    ])
                                ) ?>"
                            >
                                <i class="bi bi-chevron-left"></i>
                            </a>

                        </li>


                        <?php

                        $inicio =
                            max(
                                1,
                                $pagina - 2
                            );

                        $fin =
                            min(
                                $totalPaginas,
                                $pagina + 2
                            );

                        ?>

                        <?php for (
                            $i = $inicio;
                            $i <= $fin;
                            $i++
                        ): ?>

                            <li
                                class="page-item <?= $i === $pagina
                                    ? 'active'
                                    : '' ?>"
                            >

                                <a
                                    class="page-link"
                                    href="<?= e(
                                        listadoUrl([
                                            'page' => $i
                                        ])
                                    ) ?>"
                                >
                                    <?= $i ?>
                                </a>

                            </li>

                        <?php endfor; ?>


                        <li
                            class="page-item <?= $pagina >= $totalPaginas
                                ? 'disabled'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="<?= e(
                                    listadoUrl([
                                        'page' =>
                                            min(
                                                $totalPaginas,
                                                $pagina + 1
                                            )
                                    ])
                                ) ?>"
                            >
                                <i class="bi bi-chevron-right"></i>
                            </a>

                        </li>

                    </ul>

                </nav>

            </div>

        <?php endif; ?>

    </div>

</div>