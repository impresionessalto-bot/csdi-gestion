<?php

declare(strict_types=1);
?>

<div class="container-fluid py-4">

```
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

    <div>

        <h1 class="h3 fw-bold mb-1">
            <i class="bi bi-receipt me-2"></i>
            Facturación
        </h1>

        <p class="text-muted mb-0">
            Facturación de las operaciones comerciales.
        </p>

    </div>

    <a
        href="/ventas"
        class="btn btn-outline-secondary"
    >
        <i class="bi bi-arrow-left me-1"></i>
        Volver a ventas
    </a>

</div>


<div class="row g-4">

    <div class="col-12 col-md-4">

        <div class="card border-0 shadow-sm h-100">

            <div class="card-body">

                <div class="text-muted small mb-2">
                    Pendientes
                </div>

                <div class="fs-2 fw-bold">
                    0
                </div>

                <div class="small text-muted mt-2">
                    Operaciones pendientes de facturar.
                </div>

            </div>

        </div>

    </div>


    <div class="col-12 col-md-4">

        <div class="card border-0 shadow-sm h-100">

            <div class="card-body">

                <div class="text-muted small mb-2">
                    Facturadas
                </div>

                <div class="fs-2 fw-bold">
                    0
                </div>

                <div class="small text-muted mt-2">
                    Comprobantes emitidos.
                </div>

            </div>

        </div>

    </div>


    <div class="col-12 col-md-4">

        <div class="card border-0 shadow-sm h-100">

            <div class="card-body">

                <div class="text-muted small mb-2">
                    Total facturado
                </div>

                <div class="fs-4 fw-bold">
                    $ 0,00
                </div>

                <div class="small text-muted mt-2">
                    Importe acumulado.
                </div>

            </div>

        </div>

    </div>

</div>


<div class="card border-0 shadow-sm mt-4">

    <div class="card-body text-center py-5">

        <i class="bi bi-receipt fs-1 text-muted d-block mb-3"></i>

        <h5 class="fw-bold">
            Módulo de facturación
        </h5>

        <p class="text-muted mb-0">
            Esta sección queda preparada para integrarse
            con el módulo de Facturación y la emisión de
            comprobantes.
        </p>

    </div>

</div>
```

</div>
