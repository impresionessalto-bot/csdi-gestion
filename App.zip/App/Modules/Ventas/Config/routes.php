<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Ventas\Controllers\Controller;

/*
|--------------------------------------------------------------------------
| ERP CSDI PRO
| MÓDULO VENTAS
|--------------------------------------------------------------------------
*/

Router::group(
    '/ventas',
    ['auth'],
    function (): void {

        /*
        |--------------------------------------------------------------------------
        | DASHBOARD
        |--------------------------------------------------------------------------
        |
        | GET /ventas
        | GET /ventas/
        |
        */

        Router::get(
            '',
            [
                Controller::class,
                'index'
            ]
        );

        Router::get(
            '/',
            [
                Controller::class,
                'index'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | NUEVA VENTA
        |--------------------------------------------------------------------------
        |
        | GET /ventas/nueva
        |
        */

        Router::get(
            '/nueva',
            [
                Controller::class,
                'nueva'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | LISTADO DE VENTAS
        |--------------------------------------------------------------------------
        |
        | GET /ventas/listado
        |
        */

        Router::get(
            '/listado',
            [
                Controller::class,
                'listado'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | VER VENTA
        |--------------------------------------------------------------------------
        |
        | GET /ventas/{id}
        |
        | IMPORTANTE:
        | Esta ruta va después de las rutas estáticas.
        |
        */

        Router::get(
            '/{id}',
            [
                Controller::class,
                'ver'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | EDITAR VENTA
        |--------------------------------------------------------------------------
        |
        | GET /ventas/{id}/editar
        |
        */

        Router::get(
            '/{id}/editar',
            [
                Controller::class,
                'editar'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | ACTUALIZAR VENTA
        |--------------------------------------------------------------------------
        |
        | POST /ventas/{id}
        |
        */

        Router::post(
            '/{id}',
            [
                Controller::class,
                'actualizar'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | ANULAR VENTA
        |--------------------------------------------------------------------------
        |
        | POST /ventas/{id}/anular
        |
        */

        Router::post(
            '/{id}/anular',
            [
                Controller::class,
                'anular'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | PRESUPUESTOS
        |--------------------------------------------------------------------------
        |
        | GET /ventas/presupuestos
        |
        */

        Router::get(
            '/presupuestos',
            [
                Controller::class,
                'presupuestos'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | PEDIDOS
        |--------------------------------------------------------------------------
        |
        | GET /ventas/pedidos
        |
        */

        Router::get(
            '/pedidos',
            [
                Controller::class,
                'pedidos'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | REMITOS
        |--------------------------------------------------------------------------
        |
        | GET /ventas/remitos
        |
        */

        Router::get(
            '/remitos',
            [
                Controller::class,
                'remitos'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | FACTURACIÓN
        |--------------------------------------------------------------------------
        |
        | GET /ventas/facturacion
        |
        */

        Router::get(
            '/facturacion',
            [
                Controller::class,
                'facturacion'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - ARTÍCULOS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/articulos/buscar',
            [
                Controller::class,
                'buscarArticulos'
            ]
        );

        Router::get(
            '/api/articulos/{id}',
            [
                Controller::class,
                'obtenerArticulo'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - CLIENTES
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/clientes/buscar',
            [
                Controller::class,
                'buscarClientes'
            ]
        );

        Router::get(
            '/api/clientes/{id}',
            [
                Controller::class,
                'obtenerCliente'
            ]
        );

        Router::post(
            '/api/clientes',
            [
                Controller::class,
                'crearCliente'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - VENDEDORES
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/vendedores',
            [
                Controller::class,
                'vendedores'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - COMPROBANTE
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/comprobante/siguiente',
            [
                Controller::class,
                'siguienteComprobante'
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - CONFIRMAR VENTA
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/api/confirmar',
            [
                Controller::class,
                'confirmar'
            ]
        );
    }
);