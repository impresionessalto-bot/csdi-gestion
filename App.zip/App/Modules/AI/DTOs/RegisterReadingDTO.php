<?php
declare(strict_types=1);

namespace App\Modules\Counter\DTOs;

final class RegisterReadingDTO
{
    public function __construct(
        public readonly int $cliente_id,
        public readonly int $equipo_id,
        public readonly int $localidad_id,
        public readonly int $contador_actual,
        public readonly int $contador_actual_color,
        public readonly ?string $observaciones = null
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            cliente_id:            (int)($data['cliente_id'] ?? 0),
            equipo_id:             (int)($data['equipo_id'] ?? 0),
            localidad_id:          (int)($data['localidad_id'] ?? 0),
            contador_actual:       (int)($data['contador_actual'] ?? 0),
            contador_actual_color: (int)($data['contador_actual_color'] ?? 0),
            observaciones:         $data['observaciones'] ?? null
        );
    }
}