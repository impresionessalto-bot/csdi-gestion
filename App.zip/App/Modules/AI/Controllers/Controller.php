<?php

declare(strict_types=1);

namespace App\Modules\AI\Controllers;

use App\Core\BaseController;
use App\Modules\AI\Services\Service;
use Throwable;


final class Controller extends BaseController
{


    public function __construct(
        private readonly Service $service
    )
    {

    }





    /**
     * =========================================================
     * DASHBOARD IA
     *
     * GET /ai
     * =========================================================
     */
    public function index(): void
    {

        $this->requireAuth();


        try
        {

            $data =
                $this->service->index();



            $this->moduleView(

                'AI',

                'index',

                [

                    'titulo' =>
                        'Asistente IA ERP',

                    'data' =>
                        $data

                ],

                'app'

            );


        }
        catch(Throwable $e)
        {

            throw $e;

        }

    }





    /**
     * =========================================================
     * ANALIZAR TEXTO
     *
     * POST /ai/analizar
     * =========================================================
     */
    public function analizar(): void
    {

        $this->requireAuth();



        $input =
            file_get_contents(
                'php://input'
            );



        $json =
            json_decode(
                $input,
                true
            );



        $texto =
            $json['texto']
            ??
            $_POST['texto']
            ??
            '';



        $resultado =
            $this->service->analizar(
                trim($texto)
            );



        $this->json(
            $resultado
        );

    }





    /**
     * =========================================================
     * CHAT IA
     *
     * POST /ai/chat
     * =========================================================
     */
    public function chat(): void
    {

        $this->requireAuth();



        $input =
            file_get_contents(
                'php://input'
            );



        $json =
            json_decode(
                $input,
                true
            );



        if(is_array($json))
        {

            $mensajes =
                $json['mensajes']
                ??
                $json['message']
                ??
                [];


        }
        else
        {

            $mensajes =
                $_POST['mensajes']
                ??
                [];

        }





        if(is_string($mensajes) && trim($mensajes)!=='')
        {

            $mensajes =
            [
                [
                    'role'=>'user',
                    'content'=>$mensajes
                ]
            ];

        }





        $resultado =
            $this->service->chat(
                $mensajes
            );



        $this->json(
            $resultado
        );

    }





    /**
     * =========================================================
     * ESTADISTICAS
     *
     * GET /ai/estadisticas
     * =========================================================
     */
    public function estadisticas(): void
    {

        $this->requireAuth();



        $resultado =
            $this->service->estadisticas();



        $this->json(
            $resultado
        );

    }





    /**
     * =========================================================
     * STATUS IA
     *
     * GET /ai/status
     * =========================================================
     */
    public function status(): void
    {

        $this->requireAuth();



        $this->json(

            [

                'success'=>true,

                'status'=>'online',

                'module'=>'AI'

            ]

        );

    }


}