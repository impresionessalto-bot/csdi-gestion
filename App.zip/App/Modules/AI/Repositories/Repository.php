<?php
declare(strict_types=1);

namespace App\Modules\Informes_tng\Repositories;


use PDO;
use Throwable;
use RuntimeException;



final class Repository
{


    public function __construct(
        private readonly PDO $db
    ){
    }








/*
|--------------------------------------------------------------------------
| ESTADISTICAS
|--------------------------------------------------------------------------
*/


public function totalClientes():int
{

    try {


        return (int)$this->db
            ->query("
                SELECT COUNT(DISTINCT cliente_id)
                FROM equipos
                WHERE propiedad='TNG'
            ")
            ->fetchColumn();


    }catch(Throwable){

        return 0;

    }

}






public function totalEquipos():int
{

    try {


        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM equipos
                WHERE propiedad='TNG'
            ")
            ->fetchColumn();


    }catch(Throwable){

        return 0;

    }

}







public function totalInformes():int
{

    try {


        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM historial_informes
                WHERE propiedad='TNG'
            ")
            ->fetchColumn();


    }catch(Throwable){

        return 0;

    }

}










/*
|--------------------------------------------------------------------------
| CASCADA
|--------------------------------------------------------------------------
*/



public function localidades():array
{

    try {


        return $this->db
            ->query("
                SELECT 
                    id,
                    nombre
                FROM localidades
                ORDER BY nombre
            ")
            ->fetchAll(PDO::FETCH_ASSOC);



    }catch(Throwable){

        return [];

    }

}








public function clientes(
    int $localidad
):array
{

    try {


        $stmt=$this->db->prepare("

            SELECT DISTINCT

                c.id,
                c.nombre


            FROM clientes c


            INNER JOIN equipos e

            ON e.cliente_id=c.id



            WHERE e.localidad_id=:loc

            AND e.propiedad='TNG'


            ORDER BY c.nombre


        ");



        $stmt->execute([

            'loc'=>$localidad

        ]);



        return $stmt->fetchAll(PDO::FETCH_ASSOC);



    }catch(Throwable){

        return [];

    }


}









public function equipos(
    int $cliente
):array
{

    try {


        $stmt=$this->db->prepare("

            SELECT

                e.id,

                e.serie,

                e.codigo_interno,


                m.marca,

                m.nombre_modelo


            FROM equipos e


            LEFT JOIN modelos_equipos m

            ON m.id=e.modelo_id



            WHERE e.cliente_id=:cliente

            AND e.propiedad='TNG'


            ORDER BY e.codigo_interno


        ");



        $stmt->execute([

            'cliente'=>$cliente

        ]);



        return $stmt->fetchAll(PDO::FETCH_ASSOC);



    }catch(Throwable){

        return [];

    }

}









/*
|--------------------------------------------------------------------------
| INFORMES DISPONIBLES
|--------------------------------------------------------------------------
*/


public function informesDisponibles(
    int $limite=100
):array
{

    try {


        $usados=$this->db
            ->query("
                SELECT nro_informe
                FROM historial_informes
                WHERE propiedad='TNG'
            ")
            ->fetchAll(PDO::FETCH_COLUMN);



        $usados=array_map(
            'intval',
            $usados
        );





        $rangos=$this->db
            ->query("
                SELECT

                    num_desde,

                    num_hasta


                FROM talonarios


                WHERE propiedad='TNG'


                ORDER BY num_hasta DESC

            ")
            ->fetchAll(PDO::FETCH_ASSOC);




        $resultado=[];



        foreach($rangos as $r){


            for(
                $i=(int)$r['num_hasta'];
                $i >= (int)$r['num_desde'];
                $i--
            ){


                if(!in_array($i,$usados,true)){


                    $resultado[]=$i;


                }


                if(count($resultado)>=$limite){

                    return $resultado;

                }

            }

        }



        return $resultado;



    }catch(Throwable){

        return [];

    }

}











/*
|--------------------------------------------------------------------------
| TALONARIOS
|--------------------------------------------------------------------------
*/


public function talonarios():array
{

    try {


        return $this->db
            ->query("
                SELECT *
                FROM talonarios
                WHERE propiedad='TNG'
                ORDER BY num_hasta DESC
            ")
            ->fetchAll(PDO::FETCH_ASSOC);



    }catch(Throwable){

        return [];

    }

}








public function guardarTalonario(
    array $data
):bool
{

    try {


        $stmt=$this->db->prepare("

            INSERT INTO talonarios
            (
                num_desde,
                num_hasta,
                propiedad
            )

            VALUES
            (
                :desde,
                :hasta,
                'TNG'
            )

        ");



        return $stmt->execute([

            'desde'=>$data['desde'],

            'hasta'=>$data['hasta']

        ]);



    }catch(Throwable $e){


        throw new RuntimeException(
            $e->getMessage()
        );


    }

}









/*
|--------------------------------------------------------------------------
| LISTADO INFORMES
|--------------------------------------------------------------------------
*/


public function ultimos():array
{

    try {


        return $this->db
            ->query("

                SELECT

                    h.*,

                    c.nombre AS cliente,

                    e.codigo_interno,

                    e.serie



                FROM historial_informes h



                LEFT JOIN equipos e

                ON e.id=h.equipo_id



                LEFT JOIN clientes c

                ON c.id=e.cliente_id



                WHERE h.propiedad='TNG'


                ORDER BY h.id DESC


                LIMIT 50


            ")
            ->fetchAll(PDO::FETCH_ASSOC);



    }catch(Throwable){

        return [];

    }

}









/*
|--------------------------------------------------------------------------
| GUARDAR INFORME
|--------------------------------------------------------------------------
*/


public function guardarInforme(
    array $data
):bool
{

    try {


        $stmt=$this->db->prepare("

            INSERT INTO historial_informes
            (

                nro_informe,

                localidad,

                cliente,

                equipo_id,

                archivo_path,

                propiedad,

                fecha,

                observaciones


            )

            VALUES

            (

                :numero,

                :localidad,

                :cliente,

                :equipo,

                :archivo,

                'TNG',

                :fecha,

                :obs

            )


        ");



        return $stmt->execute([


            'numero'=>$data['nro_informe'],

            'localidad'=>$data['localidad'],

            'cliente'=>$data['cliente'],

            'equipo'=>$data['equipo_id'],

            'archivo'=>$data['archivo'],

            'fecha'=>$data['fecha'],

            'obs'=>$data['observaciones']


        ]);



    }catch(Throwable $e){


        throw new RuntimeException(
            $e->getMessage()
        );


    }

}










/*
|--------------------------------------------------------------------------
| EDITAR
|--------------------------------------------------------------------------
*/


public function buscar(
    int $id
):?array
{

    $stmt=$this->db->prepare("

        SELECT *

        FROM historial_informes

        WHERE id=:id


    ");



    $stmt->execute([

        'id'=>$id

    ]);



    $data=$stmt->fetch(PDO::FETCH_ASSOC);



    return $data ?: null;

}








public function actualizar(
    int $id,
    array $data
):bool
{

    $stmt=$this->db->prepare("

        UPDATE historial_informes

        SET

            fecha=:fecha,

            observaciones=:obs


        WHERE id=:id


    ");



    return $stmt->execute([


        'fecha'=>$data['fecha'],

        'obs'=>$data['observaciones'],

        'id'=>$id


    ]);

}









/*
|--------------------------------------------------------------------------
| ELIMINAR
|--------------------------------------------------------------------------
*/


public function eliminar(
    int $id
):bool
{

    $stmt=$this->db->prepare("

        DELETE FROM historial_informes

        WHERE id=:id


    ");



    return $stmt->execute([

        'id'=>$id

    ]);

}





}