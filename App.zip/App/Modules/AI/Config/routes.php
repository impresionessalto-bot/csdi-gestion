<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\AI\Controllers\Controller;


Router::group(
    '/ai',
    [
        'auth'
    ],
    function(){


        Router::get(
            '',
            [
                Controller::class,
                'index'
            ]
        );


        Router::post(
            '/analizar',
            [
                Controller::class,
                'analizar'
            ]
        );


        Router::post(
            '/chat',
            [
                Controller::class,
                'chat'
            ]
        );


        Router::get(
            '/estadisticas',
            [
                Controller::class,
                'estadisticas'
            ]
        );


        Router::get(
            '/status',
            [
                Controller::class,
                'status'
            ]
        );


    }
);