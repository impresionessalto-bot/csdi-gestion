<?php

declare(strict_types=1);

namespace App\Modules\AI\Services;

use App\Services\IaService;
use RuntimeException;


final class Service
{


    public function __construct(
        private readonly IaService $ia
    )
    {

    }



    /**
     * Dashboard IA
     */
    public function index(): array
    {

        return [

            'titulo'=>'Asistente IA ERP',

            'estado'=>true,

            'motor'=>'CSDI AI',

            'proveedor'=>$this->ia->provider(),

            'habilitado'=>$this->ia->enabled(),

            'version'=>'1.0.0'

        ];

    }





    /**
     * Analizar texto
     */
    public function analizar(
        string $texto
    ): array
    {

        if(trim($texto)==='')
        {
            throw new RuntimeException(
                'Debe ingresar un texto'
            );
        }


        return [

            'ok'=>true,

            'respuesta'=>
                $this->ia->ask(
                    $texto
                ),

            'texto'=>$texto

        ];

    }





    /**
     * Chat IA
     */
    public function chat(
        array $mensajes
    ): array
    {

        if(empty($mensajes))
        {
            throw new RuntimeException(
                'No hay mensajes para procesar'
            );
        }



        $texto = '';



        foreach($mensajes as $mensaje)
        {


            /*
            |-------------------------------------------------
            | Formato simple
            |-------------------------------------------------
            */

            if(is_string($mensaje))
            {

                $texto .= $mensaje."\n";

                continue;

            }



            /*
            |-------------------------------------------------
            | Formato ChatGPT
            |-------------------------------------------------
            */

            if(is_array($mensaje))
            {

                $contenido =
                    $mensaje['content']
                    ??
                    '';



                if($contenido !== '')
                {

                    $texto .=
                        $contenido
                        .
                        "\n";

                }

            }


        }



        if(trim($texto)==='')
        {
            throw new RuntimeException(
                'Mensaje vacío'
            );
        }




        return [

            'ok'=>true,


            'respuesta'=>
                $this->ia->asistente(
                    trim($texto)
                ),


            'mensajes'=>$mensajes

        ];

    }





    /**
     * Estadísticas
     */
    public function estadisticas(): array
    {

        return [

            'consultas'=>0,

            'documentos'=>0,

            'analisis'=>0,

            'estado'=>$this->ia->enabled()

        ];

    }



}