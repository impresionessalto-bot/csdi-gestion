<?php
declare(strict_types=1);

/**
 * Vista de Asistente IA ERP
 * 
 * @var string $titulo
 */

$titulo = $titulo ?? 'Asistente IA ERP';
?>

<div class="container-fluid ai-page">

    <!-- =====================================================
         HEADER
    ===================================================== -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold">
                <i class="fa-solid fa-robot text-primary me-2"></i> <?= htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') ?>
            </h2>
            <p class="text-muted mb-0">
                Panel de control y consultas inteligentes del ERP
            </p>
        </div>
    </div>

    <!-- =====================================================
         CONTENIDO PRINCIPAL IA
    ===================================================== -->
    <div class="row g-4">
        <div class="col-12 col-lg-8">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-primary text-white fw-bold">
                    <i class="fa-solid fa-comments me-2"></i> Chat con Asistente
                </div>
                <div class="card-body d-flex flex-column justify-content-between" style="min-height: 350px;">
                    <div id="aiChatContainer" class="mb-3 p-3 border rounded bg-light" style="flex-grow: 1; max-height: 300px; overflow-y: auto;">
                        <p class="text-muted text-center my-auto">Escribe un comando o consulta para comenzar...</p>
                    </div>
                    <form id="formAiChat" class="d-flex gap-2">
                        <input type="text" id="aiPromptInput" class="form-control" placeholder="Escribe tu consulta o prompt aquí..." required>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-paper-plane"></i> Enviar
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header fw-bold">
                    <i class="fa-solid fa-chart-pie me-2"></i> Estado del Motor
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2 d-flex justify-content-between">
                            <span class="text-muted">Motor:</span>
                            <strong>CSDI AI</strong>
                        </li>
                        <li class="mb-2 d-flex justify-content-between">
                            <span class="text-muted">Estado:</span>
                            <span class="badge bg-success">Activo</span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <span class="text-muted">Versión:</span>
                            <strong>1.0.0</strong>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header fw-bold">
                    <i class="fa-solid fa-bolt me-2"></i> Acciones rápidas
                </div>
                <div class="card-body d-grid gap-2">
                    <button class="btn btn-outline-secondary btn-sm text-start" type="button">
                        <i class="fa-solid fa-file-lines me-2"></i> Analizar últimos registros
                    </button>
                    <button class="btn btn-outline-secondary btn-sm text-start" type="button">
                        <i class="fa-solid fa-triangle-exclamation me-2"></i> Revisar alertas del sistema
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>