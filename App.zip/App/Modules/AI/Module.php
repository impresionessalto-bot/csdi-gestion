<?php

declare(strict_types=1);

namespace App\Modules\AI;

use App\Core\Module as BaseModule;

final class Module extends BaseModule
{
    /**
     * Nombre del módulo
     */
    public function name(): string
    {
        return 'AI';
    }

    /**
     * Archivo de rutas
     */
    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    /**
     * Prioridad de carga
     */
    public function priority(): int
    {
        return 70;
    }

    /**
     * Menú lateral
     */
    public function menu(): array
    {
        return [
            [
                'title'      => 'Inteligencia Artificial',
                'icon'       => 'fa-solid fa-robot',
                'url'        => '/ai',
                'group'      => 'Herramientas',
                'order'      => 70,
                'permission' => 'ai.view',
                'roles'      => [
                    'admin'
                ],
                'visible'    => true
            ]
        ];
    }

    /**
     * Icono
     */
    public function icon(): string
    {
        return 'fa-solid fa-robot';
    }

    /**
     * URL principal
     */
    public function url(): string
    {
        return '/ai';
    }

    /**
     * Grupo del menú
     */
    public function group(): string
    {
        return 'Herramientas';
    }

    /**
     * Orden
     */
    public function order(): int
    {
        return 70;
    }

    /**
     * Permisos
     */
    public function permissions(): array
    {
        return [
            'ai.view',
            'ai.analyze',
            'ai.upload'
        ];
    }

    /**
     * Dependencias
     */
    public function dependencies(): array
    {
        return [
            'Counter'
        ];
    }

    /**
     * Módulo habilitado
     */
    public function enabled(): bool
    {
        return true;
    }

    /**
     * Inicialización
     */
    public function boot(): void
    {
        // Registrar servicios, listeners o integraciones de IA.
    }
}