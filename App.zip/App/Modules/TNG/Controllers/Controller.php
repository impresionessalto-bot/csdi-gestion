<?php

declare(strict_types=1);

namespace App\Modules\TNG\Controllers;

use App\Core\BaseController;
use App\Modules\TNG\Services\ContratoTngService;
use App\Modules\TNG\Services\VisitaTngService;
use App\Modules\TNG\Services\TarifaTngService;
use App\Modules\TNG\Services\ReglaCobroTngService;
use Throwable;


final class Controller extends BaseController
{


    public function __construct(

        private readonly ContratoTngService $contratoService,

        private readonly VisitaTngService $visitaService,

        private readonly TarifaTngService $tarifaService,

        private readonly ReglaCobroTngService $reglaService

    ){

        parent::__construct();

    }





    /**
     * Dashboard TNG
     */
    public function index(): void
    {

        $this->view(

            'TNG/index',

            [

                'contratos' =>

                    $this->contratoService
                        ->activos(),



                'visitas' =>

                    $this->visitaService
                        ->pendientes(),



                'tarifas' =>

                    $this->tarifaService
                        ->listar()

            ]

        );

    }





    /**
     * Contratos activos
     */
    public function contratos(): void
    {

        $this->json(

            [

                'success'=>true,

                'data'=>

                    $this->contratoService
                        ->activos()

            ]

        );

    }





    /**
     * Visitas pendientes
     */
    public function visitas(): void
    {

        $this->json(

            [

                'success'=>true,

                'data'=>

                    $this->visitaService
                        ->pendientes()

            ]

        );

    }





    /**
     * Tarifas TNG
     */
    public function tarifas(): void
    {

        $this->json(

            [

                'success'=>true,

                'data'=>

                    $this->tarifaService
                        ->listar()

            ]

        );

    }





    /**
     * Calcular cobro visita TNG
     *
     * Regla:
     *
     * TNG factura por visita
     * NO por cantidad de copias
     */
    public function calcularCobro(): void
    {

        try {


            $resultado =

                $this->reglaService
                    ->calcular(

                        $_POST['visita'] ?? [],

                        $_POST['cliente'] ?? []

                    );



            $this->json(

                [

                    'success'=>true,

                    'cobro'=>$resultado

                ]

            );


        }catch(Throwable $e){


            $this->json(

                [

                    'success'=>false,

                    'message'=>$e->getMessage()

                ],

                400

            );


        }

    }





}