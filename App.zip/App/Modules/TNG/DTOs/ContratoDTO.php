<?php

declare(strict_types=1);

namespace App\Modules\TNG\DTOs;


final class ContratoDTO
{


    public function __construct(

        public readonly int $cliente_id,

        public readonly string $fecha_inicio,

        public readonly ?string $fecha_fin,

        public readonly string $modalidad,

        public readonly ?string $observaciones = null

    ){
    }





    /**
     * Convertir a array
     */
    public function toArray(): array
    {

        return [

            'cliente_id'=>
                $this->cliente_id,


            'fecha_inicio'=>
                $this->fecha_inicio,


            'fecha_fin'=>
                $this->fecha_fin,


            'modalidad'=>
                strtoupper(
                    $this->modalidad
                ),


            'observaciones'=>
                $this->observaciones

        ];

    }





}