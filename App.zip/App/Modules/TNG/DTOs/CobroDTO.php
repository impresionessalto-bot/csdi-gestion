<?php

declare(strict_types=1);

namespace App\Modules\TNG\DTOs;


final class CobroDTO
{


    public function __construct(

        public readonly string $tipo,

        public readonly string $concepto,

        public readonly float $importe,

        public readonly ?int $tarifa_id,

        public readonly int $visita_id,

        public readonly int $cliente_id

    ){
    }





    /**
     * Convertir a array
     */
    public function toArray(): array
    {

        return [

            'tipo'=>
                $this->tipo,


            'concepto'=>
                $this->concepto,


            'importe'=>
                $this->importe,


            'tarifa_id'=>
                $this->tarifa_id,


            'visita_id'=>
                $this->visita_id,


            'cliente_id'=>
                $this->cliente_id

        ];

    }





}