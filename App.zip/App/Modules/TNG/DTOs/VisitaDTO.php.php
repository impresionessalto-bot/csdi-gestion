<?php

declare(strict_types=1);

namespace App\Modules\TNG\DTOs;


final class VisitaDTO
{


    public function __construct(

        public readonly int $cliente_id,

        public readonly ?int $equipo_id,

        public readonly ?int $tecnico_id,

        public readonly string $tipo_visita,

        public readonly string $fecha,

        public readonly ?string $observaciones = null

    ){
    }





    /**
     * Convertir a array
     */
    public function toArray(): array
    {

        return [

            'cliente_id'=>
                $this->cliente_id,


            'equipo_id'=>
                $this->equipo_id,


            'tecnico_id'=>
                $this->tecnico_id,


            'tipo_visita'=>
                $this->tipo_visita,


            'fecha'=>
                $this->fecha,


            'observaciones'=>
                $this->observaciones

        ];

    }





}