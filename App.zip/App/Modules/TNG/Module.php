<?php

declare(strict_types=1);

namespace App\Modules\TNG;

use App\Core\Module as BaseModule;


final class Module extends BaseModule
{


    public function name(): string
    {
        return 'TNG';
    }


    public function description(): string
    {
        return 'Gestión central de contratos, visitas y facturación TNG';
    }


    public function version(): string
    {
        return '1.0.0';
    }


    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }


    public function menu(): array
    {
        return [];
    }


    public function permissions(): array
    {
        return [

            'tng.ver',

            'tng.contratos',

            'tng.visitas',

            'tng.tarifas',

            'tng.reglas_cobro',

        ];
    }


    public function boot(): void
    {

    }


}