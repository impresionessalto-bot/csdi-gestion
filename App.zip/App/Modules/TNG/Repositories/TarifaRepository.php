<?php

declare(strict_types=1);

namespace App\Modules\TNG\Repositories;

use PDO;


final class TarifaRepository
{


    public function __construct(
        private readonly PDO $db
    ){
    }





    /**
     * Buscar tarifa por ID
     */
    public function buscar(
        int $id
    ): ?array
    {


        $sql = "

            SELECT *

            FROM tarifas_tng

            WHERE id=:id

            LIMIT 1

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':id'=>$id

        ]);



        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );



        return $data ?: null;

    }





    /**
     * Tarifa vigente actual
     *
     * GENERAL
     * ARCA
     * SERVICIO
     * ESPECIAL
     */
    public function vigente(
        string $tipo
    ): ?array
    {


        $sql = "

            SELECT *

            FROM tarifas_tng


            WHERE tipo=:tipo


            AND activo=1


            AND
            (
                fecha_desde IS NULL

                OR fecha_desde <= CURDATE()
            )


            AND
            (
                fecha_hasta IS NULL

                OR fecha_hasta >= CURDATE()
            )


            ORDER BY id DESC


            LIMIT 1

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        $stmt->execute([


            ':tipo'=>
                strtoupper($tipo)


        ]);



        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );



        return $data ?: null;

    }





    /**
     * Alias usado por servicios
     */
    public function activaPorTipo(
        string $tipo
    ): ?array
    {

        return $this->vigente(
            $tipo
        );

    }





    /**
     * Listado activas
     */
    public function activas(): array
    {


        $sql = "

            SELECT *

            FROM tarifas_tng

            WHERE activo=1

            ORDER BY tipo,nombre

        ";



        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Todas las tarifas
     */
    public function todas(): array
    {


        $sql = "

            SELECT *

            FROM tarifas_tng

            ORDER BY id DESC

        ";



        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Crear tarifa
     */
    public function crear(
        array $data
    ): int
    {


        $sql = "

            INSERT INTO tarifas_tng
            (
                nombre,
                tipo,
                importe,
                fecha_desde,
                fecha_hasta,
                activo
            )

            VALUES
            (
                :nombre,
                :tipo,
                :importe,
                :desde,
                :hasta,
                1
            )

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        $stmt->execute([



            ':nombre'=>
                $data['nombre'],



            ':tipo'=>
                strtoupper(
                    $data['tipo']
                ),



            ':importe'=>
                $data['importe']
                ?? 0,



            ':desde'=>
                $data['fecha_desde']
                ?? null,



            ':hasta'=>
                $data['fecha_hasta']
                ?? null


        ]);



        return (int)
            $this->db->lastInsertId();

    }





    /**
     * Actualizar tarifa
     */
    public function actualizar(
        int $id,
        array $data
    ): bool
    {


        $sql = "

            UPDATE tarifas_tng

            SET

                nombre=:nombre,

                tipo=:tipo,

                importe=:importe,

                fecha_desde=:desde,

                fecha_hasta=:hasta


            WHERE id=:id

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        return $stmt->execute([



            ':nombre'=>
                $data['nombre'],



            ':tipo'=>
                strtoupper(
                    $data['tipo']
                ),



            ':importe'=>
                $data['importe']
                ?? 0,



            ':desde'=>
                $data['fecha_desde']
                ?? null,



            ':hasta'=>
                $data['fecha_hasta']
                ?? null,



            ':id'=>
                $id


        ]);

    }





    /**
     * Activar tarifa
     */
    public function activar(
        int $id
    ): bool
    {


        $sql = "

            UPDATE tarifas_tng

            SET activo=1

            WHERE id=:id

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        return $stmt->execute([

            ':id'=>$id

        ]);

    }





    /**
     * Desactivar tarifa
     */
    public function desactivar(
        int $id
    ): bool
    {


        $sql = "

            UPDATE tarifas_tng

            SET activo=0

            WHERE id=:id

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        return $stmt->execute([

            ':id'=>$id

        ]);

    }





}