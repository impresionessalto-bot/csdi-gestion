<?php

declare(strict_types=1);

namespace App\Modules\TNG\Repositories;

use PDO;


final class VisitaRepository
{


    public function __construct(
        private readonly PDO $db
    ){
    }





    /**
     * Buscar visita por ID
     */
    public function buscar(
        int $id
    ): ?array
    {


        $sql = "

            SELECT

                v.*,

                c.nombre AS cliente_nombre,

                e.codigo_interno,

                e.serie,

                u.nombre AS tecnico_nombre


            FROM visitas_tng v


            LEFT JOIN clientes c

                ON c.id=v.cliente_id


            LEFT JOIN equipos e

                ON e.id=v.equipo_id


            LEFT JOIN usuarios u

                ON u.id=v.tecnico_id


            WHERE v.id=:id


            LIMIT 1

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':id'=>$id

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }





    /**
     * Visitas de cliente
     */
    public function cliente(
        int $clienteId
    ): array
    {


        $sql = "

            SELECT

                v.*,

                e.codigo_interno,

                e.serie,

                u.nombre AS tecnico_nombre


            FROM visitas_tng v


            LEFT JOIN equipos e

                ON e.id=v.equipo_id


            LEFT JOIN usuarios u

                ON u.id=v.tecnico_id


            WHERE v.cliente_id=:cliente


            ORDER BY

                v.fecha DESC,

                v.id DESC

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':cliente'=>$clienteId

        ]);


        return $stmt
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Visitas pendientes
     */
    public function pendientes(): array
    {


        $sql = "

            SELECT

                v.*,

                c.nombre AS cliente_nombre


            FROM visitas_tng v


            INNER JOIN clientes c

                ON c.id=v.cliente_id


            WHERE v.estado IN
            (
                'PENDIENTE',
                'ASIGNADA',
                'EN_PROCESO'
            )


            ORDER BY v.fecha ASC

        ";


        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Crear visita
     */
    public function crear(
        array $data
    ): int
    {


        $sql = "

            INSERT INTO visitas_tng
            (
                cliente_id,
                equipo_id,
                tecnico_id,
                tipo_visita,
                fecha,
                estado,
                observaciones
            )

            VALUES
            (
                :cliente,
                :equipo,
                :tecnico,
                :tipo,
                :fecha,
                'PENDIENTE',
                :observaciones
            )

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([


            ':cliente'=>
                $data['cliente_id'],


            ':equipo'=>
                $data['equipo_id']
                ?? null,


            ':tecnico'=>
                $data['tecnico_id']
                ?? null,


            ':tipo'=>
                strtoupper(
                    $data['tipo_visita']
                ),


            ':fecha'=>
                $data['fecha'],


            ':observaciones'=>
                $data['observaciones']
                ?? null

        ]);



        return (int)
            $this->db->lastInsertId();

    }





    /**
     * Asignar técnico
     */
    public function asignarTecnico(
        int $visitaId,
        int $tecnicoId
    ): bool
    {


        $sql = "

            UPDATE visitas_tng

            SET

                tecnico_id=:tecnico,

                estado='ASIGNADA',

                updated_at=NOW()


            WHERE id=:id

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([


            ':tecnico'=>$tecnicoId,


            ':id'=>$visitaId


        ]);

    }





    /**
     * Cambiar estado
     */
    public function cambiarEstado(
        int $id,
        string $estado
    ): bool
    {


        $sql = "

            UPDATE visitas_tng

            SET

                estado=:estado,

                updated_at=NOW()


            WHERE id=:id

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([


            ':estado'=>
                strtoupper($estado),


            ':id'=>$id


        ]);

    }





    /**
     * Cerrar visita
     */
    public function cerrar(
        int $id
    ): bool
    {


        return $this->cambiarEstado(
            $id,
            'CERRADA'
        );

    }





    /**
     * Asociar informe técnico
     */
    public function asociarInforme(
        int $visitaId,
        int $informeId
    ): bool
    {


        $sql = "

            UPDATE visitas_tng

            SET

                informe_id=:informe,

                updated_at=NOW()


            WHERE id=:id

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([


            ':informe'=>$informeId,


            ':id'=>$visitaId


        ]);

    }





}