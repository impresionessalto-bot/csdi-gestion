<?php

declare(strict_types=1);

namespace App\Modules\TNG\Repositories;

use PDO;


final class EquipoTngRepository
{


    public function __construct(
        private readonly PDO $db
    ){
    }





    /**
     * Buscar equipo por ID
     */
    public function buscar(
        int $id
    ): ?array
    {


        $sql = "

            SELECT

                e.*,

                c.nombre AS cliente_nombre


            FROM equipos e


            LEFT JOIN clientes c

                ON c.id=e.cliente_id


            WHERE e.id=:id


            LIMIT 1

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        $stmt->execute([

            ':id'=>$id

        ]);



        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );



        return $data ?: null;

    }





    /**
     * Equipos del cliente
     */
    public function cliente(
        int $clienteId
    ): array
    {


        $sql = "

            SELECT

                e.*,

                me.nombre_modelo


            FROM equipos e


            LEFT JOIN modelos_equipos me

                ON me.id=e.modelo_id


            WHERE e.cliente_id=:cliente


            AND e.activo=1


            ORDER BY e.id DESC

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        $stmt->execute([

            ':cliente'=>$clienteId

        ]);



        return $stmt
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Equipos propiedad TNG
     */
    public function tng(): array
    {


        $sql = "

            SELECT

                e.*,

                c.nombre AS cliente_nombre


            FROM equipos e


            LEFT JOIN clientes c

                ON c.id=e.cliente_id


            WHERE e.propiedad='TNG'


            AND e.activo=1


            ORDER BY e.id DESC

        ";



        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Equipos disponibles
     */
    public function disponibles(): array
    {


        $sql = "

            SELECT *

            FROM equipos


            WHERE propiedad='TNG'


            AND estado='Disponible'


            AND activo=1


            ORDER BY id DESC

        ";



        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Equipos actualmente instalados
     */
    public function contratados(): array
    {


        $sql = "

            SELECT

                e.*,

                c.nombre AS cliente_nombre


            FROM equipos e


            INNER JOIN clientes c

                ON c.id=e.cliente_id


            WHERE e.propiedad='TNG'


            AND e.estado='Activo'


            AND e.activo=1


            ORDER BY e.id DESC

        ";



        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Actualizar ubicación
     */
    public function actualizarUbicacion(
        int $id,
        string $ubicacion
    ): bool
    {


        $sql = "

            UPDATE equipos

            SET

                ubicacion_actual=:ubicacion,

                fecha_ultimo_movimiento=NOW()


            WHERE id=:id

        ";



        $stmt =
            $this->db->prepare(
                $sql
            );



        return $stmt->execute([


            ':ubicacion'=>
                $ubicacion,


            ':id'=>
                $id


        ]);

    }





}