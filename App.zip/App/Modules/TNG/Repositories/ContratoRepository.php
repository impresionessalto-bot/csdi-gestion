<?php

declare(strict_types=1);

namespace App\Modules\TNG\Repositories;

use PDO;


final class ContratoRepository
{


    public function __construct(
        private readonly PDO $db
    ){
    }





    /**
     * Buscar contrato por ID
     */
    public function buscar(
        int $id
    ): ?array
    {

        $sql = "
            SELECT

                ct.*,

                c.nombre AS cliente_nombre


            FROM contratos_tng ct


            INNER JOIN clientes c

                ON c.id=ct.cliente_id


            WHERE ct.id=:id


            LIMIT 1
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':id'=>$id

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }





    /**
     * Contratos activos
     */
    public function activos(): array
    {

        $sql = "
            SELECT

                ct.*,

                c.nombre AS cliente_nombre


            FROM contratos_tng ct


            INNER JOIN clientes c

                ON c.id=ct.cliente_id


            WHERE ct.estado='ACTIVO'


            ORDER BY ct.id DESC
        ";


        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Contrato activo de cliente
     */
    public function activoCliente(
        int $clienteId
    ): ?array
    {


        $sql = "
            SELECT *

            FROM contratos_tng


            WHERE cliente_id=:cliente


            AND estado='ACTIVO'


            ORDER BY id DESC


            LIMIT 1
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':cliente'=>$clienteId

        ]);



        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }





    /**
     * Crear contrato
     */
    public function crear(
        array $data
    ): int
    {


        $sql = "
            INSERT INTO contratos_tng
            (
                cliente_id,
                fecha_inicio,
                fecha_fin,
                modalidad,
                estado,
                observaciones
            )

            VALUES
            (
                :cliente,
                :inicio,
                :fin,
                :modalidad,
                'ACTIVO',
                :observaciones
            )
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([


            ':cliente'=>
                $data['cliente_id'],


            ':inicio'=>
                $data['fecha_inicio'],


            ':fin'=>
                $data['fecha_fin']
                ?? null,


            ':modalidad'=>
                strtoupper(
                    $data['modalidad']
                ),


            ':observaciones'=>
                $data['observaciones']
                ?? null

        ]);



        return (int)
            $this->db->lastInsertId();

    }





    /**
     * Finalizar contrato
     */
    public function finalizar(
        int $id
    ): bool
    {


        $sql = "
            UPDATE contratos_tng

            SET

                estado='FINALIZADO',

                fecha_fin=COALESCE(
                    fecha_fin,
                    CURDATE()
                ),

                updated_at=NOW()


            WHERE id=:id
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([

            ':id'=>$id

        ]);

    }





    /**
     * Contratos de un cliente
     */
    public function cliente(
        int $clienteId
    ): array
    {


        $sql = "
            SELECT *

            FROM contratos_tng


            WHERE cliente_id=:cliente


            ORDER BY id DESC
        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':cliente'=>$clienteId

        ]);


        return $stmt
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





}