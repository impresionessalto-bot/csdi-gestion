<?php

declare(strict_types=1);

namespace App\Modules\TNG\Repositories;

use PDO;


final class ReglaCobroRepository
{


    public function __construct(
        private readonly PDO $db
    ){
    }





    /**
     * Buscar regla por ID
     */
    public function buscar(
        int $id
    ): ?array
    {


        $sql = "

            SELECT *

            FROM reglas_cobro_tng

            WHERE id=:id

            LIMIT 1

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':id'=>$id

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }





    /**
     * Buscar regla activa por tipo visita
     *
     * INSTALACION
     * RETIRO
     * SERVICIO_TECNICO
     */
    public function activaPorTipoVisita(
        string $tipo
    ): ?array
    {


        $sql = "

            SELECT *

            FROM reglas_cobro_tng

            WHERE tipo_visita=:tipo

            AND activo=1

            ORDER BY id DESC

            LIMIT 1

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([

            ':tipo'=>
                strtoupper($tipo)

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }





    /**
     * Alias usado por ReglaCobroTngService
     */
    public function buscarPorTipo(
        string $tipo
    ): ?array
    {

        return $this->activaPorTipoVisita(
            $tipo
        );

    }





    /**
     * Listado reglas activas
     */
    public function activas(): array
    {


        $sql = "

            SELECT *

            FROM reglas_cobro_tng

            WHERE activo=1

            ORDER BY tipo_visita, concepto

        ";


        return $this->db
            ->query($sql)
            ->fetchAll(
                PDO::FETCH_ASSOC
            );

    }





    /**
     * Crear regla
     */
    public function crear(
        array $data
    ): int
    {


        $sql = "

            INSERT INTO reglas_cobro_tng
            (
                tipo_visita,
                concepto,
                importe,
                activo
            )

            VALUES
            (
                :tipo,
                :concepto,
                :importe,
                1
            )

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        $stmt->execute([


            ':tipo'=>
                strtoupper(
                    $data['tipo_visita']
                ),


            ':concepto'=>
                $data['concepto'],


            ':importe'=>
                $data['importe']
                ?? 0

        ]);



        return (int)
            $this->db->lastInsertId();

    }





    /**
     * Actualizar regla
     */
    public function actualizar(
        int $id,
        array $data
    ): bool
    {


        $sql = "

            UPDATE reglas_cobro_tng

            SET

                tipo_visita=:tipo,

                concepto=:concepto,

                importe=:importe


            WHERE id=:id

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([


            ':tipo'=>
                strtoupper(
                    $data['tipo_visita']
                ),


            ':concepto'=>
                $data['concepto'],


            ':importe'=>
                $data['importe']
                ?? 0,


            ':id'=>
                $id

        ]);

    }





    /**
     * Activar regla
     */
    public function activar(
        int $id
    ): bool
    {


        $sql = "

            UPDATE reglas_cobro_tng

            SET activo=1

            WHERE id=:id

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([

            ':id'=>$id

        ]);

    }





    /**
     * Desactivar regla
     */
    public function desactivar(
        int $id
    ): bool
    {


        $sql = "

            UPDATE reglas_cobro_tng

            SET activo=0

            WHERE id=:id

        ";


        $stmt =
            $this->db->prepare(
                $sql
            );


        return $stmt->execute([

            ':id'=>$id

        ]);

    }





}