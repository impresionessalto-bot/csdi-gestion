<?php

declare(strict_types=1);

namespace App\Modules\TNG\Repositories;

use PDO;


final class InformeTngRepository
{

    public function __construct(
        private readonly PDO $db
    ){
    }





    /**
     * Buscar informe por ID
     */
    public function buscar(
        int $id
    ): ?array
    {

        $sql = "
            SELECT

                hi.*,

                c.nombre AS cliente_nombre

            FROM historial_informes hi

            LEFT JOIN clientes c

                ON c.id = hi.cliente_id

            WHERE hi.id = :id

            LIMIT 1
        ";


        $stmt =
            $this->db->prepare($sql);


        $stmt->execute([

            ':id'=>$id

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }






    /**
     * Buscar informe asociado a visita
     */
    public function buscarPorVisita(
        int $visitaId
    ): ?array
    {

        $sql = "
            SELECT *

            FROM historial_informes

            WHERE visita_tng_id = :visita

            LIMIT 1
        ";


        $stmt =
            $this->db->prepare($sql);


        $stmt->execute([

            ':visita'=>$visitaId

        ]);


        $data =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        return $data ?: null;

    }







    /**
     * Informes del cliente portal
     */
    public function clientePortal(
        int $clienteId
    ): array
    {

        $sql = "
            SELECT

                *

            FROM historial_informes

            WHERE cliente_id = :cliente

            ORDER BY fecha DESC
        ";


        $stmt =
            $this->db->prepare($sql);


        $stmt->execute([

            ':cliente'=>$clienteId

        ]);


        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

    }







    /**
     * Cambiar estado informe
     */
    public function cambiarEstado(
        int $id,
        string $estado
    ): bool
    {

        $sql = "
            UPDATE historial_informes

            SET

                estado=:estado

            WHERE id=:id
        ";


        $stmt =
            $this->db->prepare($sql);


        return $stmt->execute([

            ':estado'=>strtoupper($estado),

            ':id'=>$id

        ]);

    }







    /**
     * Anular informe
     */
    public function anular(
        int $id,
        int $usuarioId,
        string $motivo
    ): bool
    {

        $sql = "
            UPDATE historial_informes

            SET

                estado='ANULADO',

                anulado_por=:usuario,

                fecha_anulacion=NOW(),

                motivo_anulacion=:motivo

            WHERE id=:id
        ";


        $stmt =
            $this->db->prepare($sql);


        return $stmt->execute([

            ':usuario'=>$usuarioId,

            ':motivo'=>$motivo,

            ':id'=>$id

        ]);

    }



}