<?php

declare(strict_types=1);

use App\Core\Router;


/*
|--------------------------------------------------------------------------
| TNG MODULE ROUTES
|--------------------------------------------------------------------------
|
| Gestión técnica TNG
|
| - Visitas
| - Contratos
| - Tarifas
| - Reglas de cobro
| - Facturación
|
*/


Router::group(

    'tng',

    [

        'auth'

    ],

    function(): void {


        /*
        |--------------------------------------------------------------------------
        | Dashboard TNG
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/',

            'TNG\Controllers\Controller@index'

        );





        /*
        |--------------------------------------------------------------------------
        | VISITAS
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/visitas',

            'TNG\Controllers\Controller@visitas'

        );



        Router::get(

            '/visita/{id}',

            'TNG\Controllers\Controller@verVisita'

        );



        Router::post(

            '/visita/crear',

            'TNG\Controllers\Controller@crearVisita'

        );





        /*
        |--------------------------------------------------------------------------
        | INFORMES TNG
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/informes',

            'TNG\Controllers\Controller@informes'

        );



        Router::post(

            '/informe/finalizar/{id}',

            'TNG\Controllers\Controller@finalizarInforme'

        );





        /*
        |--------------------------------------------------------------------------
        | CONTRATOS
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/contratos',

            'TNG\Controllers\Controller@contratos'

        );



        Router::post(

            '/contrato/crear',

            'TNG\Controllers\Controller@crearContrato'

        );





        /*
        |--------------------------------------------------------------------------
        | TARIFAS
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/tarifas',

            'TNG\Controllers\Controller@tarifas'

        );



        Router::post(

            '/tarifa/crear',

            'TNG\Controllers\Controller@crearTarifa'

        );





        /*
        |--------------------------------------------------------------------------
        | REGLAS DE COBRO
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/reglas-cobro',

            'TNG\Controllers\Controller@reglasCobro'

        );



        Router::post(

            '/regla/crear',

            'TNG\Controllers\Controller@crearRegla'

        );





        /*
        |--------------------------------------------------------------------------
        | FACTURACION
        |--------------------------------------------------------------------------
        */


        Router::get(

            '/facturacion',

            'TNG\Controllers\Controller@facturacion'

        );



    }

);