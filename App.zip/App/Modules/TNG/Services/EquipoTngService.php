<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\EquipoTngRepository;
use RuntimeException;


final class EquipoTngService
{


    public function __construct(
        private readonly EquipoTngRepository $repository
    ){
    }





    /**
     * Buscar equipo
     */
    public function buscar(
        int $id
    ): ?array
    {

        return $this->repository
            ->buscar($id);

    }





    /**
     * Equipos del cliente
     */
    public function cliente(
        int $clienteId
    ): array
    {


        if($clienteId <= 0){

            throw new RuntimeException(
                'Cliente inválido.'
            );

        }



        return $this->repository
            ->cliente(
                $clienteId
            );

    }





    /**
     * Equipos disponibles TNG
     */
    public function disponibles(): array
    {

        return $this->repository
            ->disponibles();

    }





    /**
     * Equipos contratados
     */
    public function contratados(): array
    {

        return $this->repository
            ->contratados();

    }





    /**
     * Actualizar ubicación
     */
    public function actualizarUbicacion(
        int $equipoId,
        string $ubicacion
    ): bool
    {


        if(
            trim($ubicacion)===''
        ){

            throw new RuntimeException(
                'Debe indicar ubicación.'
            );

        }



        return $this->repository
            ->actualizarUbicacion(
                $equipoId,
                $ubicacion
            );

    }





}