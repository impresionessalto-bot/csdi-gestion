<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\ReglaCobroRepository;
use RuntimeException;
use Throwable;


final class ReglaCobroTngService
{


    public function __construct(

        private readonly ReglaCobroRepository $repository,

        private readonly TarifaTngService $tarifaService

    ){
    }





    /**
     * Calcular cobro de una visita TNG
     *
     * Regla:
     *
     * 1 visita = 1 cargo
     *
     * No depende de:
     *
     * - copias
     * - contador
     * - páginas
     */
    public function calcular(
        array $visita,
        array $cliente=[]
    ): array
    {


        try {


            $tipo =
                strtoupper(
                    (string)(
                        $visita['tipo_visita']
                        ?? ''
                    )
                );



            return match($tipo){


                'TOMA_CONTADOR' =>

                    $this->cobroContador(
                        $cliente
                    ),



                'SERVICIO_TECNICO' =>

                    $this->cobroServicio(),



                'INSTALACION' =>

                    $this->obtenerRegla(
                        'INSTALACION'
                    ),



                'RETIRO' =>

                    $this->obtenerRegla(
                        'RETIRO'
                    ),



                default =>

                    throw new RuntimeException(
                        'Tipo de visita TNG inválido.'
                    )

            };



        }catch(Throwable $e){


            throw new RuntimeException(

                'Error calculando cobro TNG: '
                .$e->getMessage()

            );


        }

    }





    /**
     * Toma contador mensual
     *
     * ARCA / GENERAL
     *
     * Cobra por visita.
     */
    private function cobroContador(
        array $cliente
    ): array
    {


        $tipoTarifa =
            strtoupper(

                (string)(

                    $cliente['tipo_tarifa']
                    ??
                    (
                        isset($cliente['tarifa_id'])
                        ? 'GENERAL'
                        : 'GENERAL'
                    )

                )

            );



        $tarifa =
            $this->tarifaService
                ->vigente(
                    $tipoTarifa
                );



        if(!$tarifa){


            throw new RuntimeException(

                'No existe tarifa TNG: '
                .$tipoTarifa

            );

        }



        return [


            'tipo'=>

                'TOMA_CONTADOR',



            'concepto'=>

                'Toma contador mensual TNG',



            'tarifa_id'=>

                (int)$tarifa['id'],



            'importe'=>

                (float)$tarifa['importe']


        ];

    }





    /**
     * Servicio técnico
     */
    private function cobroServicio(): array
    {


        $tarifa =
            $this->tarifaService
                ->tarifaServicio();



        return [


            'tipo'=>

                'SERVICIO_TECNICO',



            'concepto'=>

                'Servicio técnico TNG',



            'tarifa_id'=>

                (int)$tarifa['id'],



            'importe'=>

                (float)$tarifa['importe']


        ];

    }





    /**
     * Buscar regla especial
     */
    private function obtenerRegla(
        string $tipo
    ): array
    {


        $regla =
            $this->repository
                ->buscarPorTipo(
                    $tipo
                );



        if(!$regla){


            throw new RuntimeException(

                'No existe regla de cobro: '
                .$tipo

            );

        }



        return [


            'tipo'=>

                $tipo,



            'concepto'=>

                $regla['concepto'],



            'importe'=>

                (float)$regla['importe'],



            'tarifa_id'=>

                null


        ];

    }





}