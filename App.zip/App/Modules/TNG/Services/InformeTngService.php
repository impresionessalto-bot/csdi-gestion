<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\InformeTngRepository;
use App\Modules\TNG\Repositories\VisitaRepository;
use RuntimeException;


final class InformeTngService
{


    public function __construct(

        private readonly InformeTngRepository $repository,

        private readonly VisitaRepository $visitaRepository

    ){
    }





    /**
     * Buscar informe
     */
    public function buscar(
        int $id
    ): ?array
    {

        return $this->repository
            ->buscar(
                $id
            );

    }





    /**
     * Informes de cliente
     */
    public function cliente(
        int $clienteId
    ): array
    {

        return $this->repository
            ->clientePortal(
                $clienteId
            );

    }





    /**
     * Finalizar informe
     */
    public function finalizar(
        int $id
    ): bool
    {


        $informe =
            $this->buscar(
                $id
            );


        if(!$informe){

            throw new RuntimeException(
                'Informe inexistente.'
            );

        }



        if(
            $informe['estado']
            ===
            'ANULADO'
        ){

            throw new RuntimeException(
                'El informe está anulado.'
            );

        }



        return $this->repository
            ->cambiarEstado(
                $id,
                'FINALIZADO'
            );

    }





    /**
     * Anular informe
     *
     * Ejemplo:
     *
     * Técnico escribió mal
     * Cliente incorrecto
     * Contador equivocado
     */
    public function anular(
        int $id,
        int $usuarioId,
        string $motivo
    ): bool
    {


        if(
            trim($motivo)===''
        ){

            throw new RuntimeException(
                'Debe indicar motivo de anulación.'
            );

        }



        return $this->repository
            ->anular(
                $id,
                $usuarioId,
                $motivo
            );

    }





    /**
     * Asociar informe a visita
     */
    public function asociarVisita(
        int $informeId,
        int $visitaId
    ): bool
    {


        if(
            $informeId<=0 ||
            $visitaId<=0
        ){

            throw new RuntimeException(
                'Datos inválidos.'
            );

        }



        return $this->visitaRepository
            ->asociarInforme(
                $visitaId,
                $informeId
            );

    }





}