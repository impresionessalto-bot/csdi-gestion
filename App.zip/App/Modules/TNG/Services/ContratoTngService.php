<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\DTOs\ContratoDTO;
use App\Modules\TNG\Repositories\ContratoRepository;
use RuntimeException;


final class ContratoTngService
{


    public function __construct(
        private readonly ContratoRepository $repository
    ){
    }





    /**
     * Contratos activos
     */
    public function activos(): array
    {

        return $this->repository
            ->activos();

    }





    /**
     * Contrato activo de cliente
     */
    public function activoCliente(
        int $clienteId
    ): ?array
    {


        if($clienteId <= 0){

            throw new RuntimeException(
                'Cliente inválido.'
            );

        }



        return $this->repository
            ->activoCliente(
                $clienteId
            );

    }





    /**
     * Contratos del cliente
     */
    public function cliente(
        int $clienteId
    ): array
    {


        if($clienteId <= 0){

            throw new RuntimeException(
                'Cliente inválido.'
            );

        }



        return $this->repository
            ->cliente(
                $clienteId
            );

    }





    /**
     * Crear contrato
     */
    public function crear(
        ContratoDTO $dto
    ): int
    {


        $this->validarCliente(
            $dto->cliente_id
        );


        $this->validarModalidad(
            $dto->modalidad
        );


        $this->validarFechas(
            $dto->fecha_inicio,
            $dto->fecha_fin
        );



        return $this->repository
            ->crear(
                $dto->toArray()
            );

    }





    /**
     * Finalizar contrato
     */
    public function finalizar(
        int $id
    ): bool
    {


        $contrato =
            $this->buscar(
                $id
            );



        if(!$contrato){

            throw new RuntimeException(
                'Contrato inexistente.'
            );

        }



        return $this->repository
            ->finalizar(
                $id
            );

    }





    /**
     * Buscar contrato
     */
    public function buscar(
        int $id
    ): ?array
    {

        return $this->repository
            ->buscar(
                $id
            );

    }





    /**
     * Validar cliente
     */
    private function validarCliente(
        int $clienteId
    ): void
    {


        if($clienteId <= 0){

            throw new RuntimeException(
                'Cliente inválido.'
            );

        }

    }





    /**
     * Validar modalidad
     */
    private function validarModalidad(
        string $modalidad
    ): void
    {


        $permitidas = [

            'ALQUILER',

            'COPIAS',

            'SERVICIO',

            'MIXTO'

        ];



        if(
            !in_array(
                strtoupper($modalidad),
                $permitidas,
                true
            )
        ){

            throw new RuntimeException(
                'Modalidad de contrato inválida.'
            );

        }

    }





    /**
     * Validar fechas
     */
    private function validarFechas(
        string $inicio,
        ?string $fin
    ): void
    {


        if(
            $fin !== null
            &&
            strtotime($fin)
            <
            strtotime($inicio)
        ){

            throw new RuntimeException(
                'La fecha final no puede ser menor a la inicial.'
            );

        }

    }





}