<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\DTOs\CobroDTO;
use App\Modules\TNG\Repositories\InformeTngRepository;
use App\Modules\TNG\Repositories\VisitaRepository;
use App\Modules\TNG\Repositories\ClienteRepository;
use RuntimeException;


final class FacturacionTngService
{


    public function __construct(

        private readonly InformeTngRepository $informeRepository,

        private readonly VisitaRepository $visitaRepository,

        private readonly ClienteRepository $clienteRepository,

        private readonly ReglaCobroTngService $cobroService

    ){
    }





    /**
     * Preparar cobro TNG
     *
     * No genera factura.
     *
     * Solo arma el cargo.
     */
    public function preparar(
        int $informeId
    ): CobroDTO
    {


        $informe =
            $this->informeRepository
                ->buscar(
                    $informeId
                );



        if(!$informe){

            throw new RuntimeException(
                'Informe TNG inexistente.'
            );

        }





        if(
            $informe['estado']
            !==
            'FINALIZADO'
        ){

            throw new RuntimeException(
                'El informe debe estar finalizado.'
            );

        }





        $visita =
            $this->visitaRepository
                ->buscar(
                    (int)
                    $informe['visita_tng_id']
                );



        if(!$visita){

            throw new RuntimeException(
                'Visita TNG inexistente.'
            );

        }





        if(
            $visita['estado']
            !==
            'CERRADA'
        ){

            throw new RuntimeException(
                'La visita no está cerrada.'
            );

        }





        $cliente =
            $this->clienteRepository
                ->buscar(
                    (int)
                    $visita['cliente_id']
                );



        if(!$cliente){

            throw new RuntimeException(
                'Cliente inexistente.'
            );

        }





        $cobro =
            $this->cobroService
                ->calcular(
                    $visita,
                    $cliente
                );





        return new CobroDTO(


            tipo:

                $cobro['tipo'],



            concepto:

                $cobro['concepto'],



            importe:

                (float)
                $cobro['importe'],



            tarifa_id:

                $cobro['tarifa_id']
                ??
                null,



            visita_id:

                (int)
                $visita['id'],



            cliente_id:

                (int)
                $visita['cliente_id']


        );

    }





}