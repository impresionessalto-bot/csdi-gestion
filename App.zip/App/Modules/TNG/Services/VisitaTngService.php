<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\VisitaRepositories;
use App\Modules\TNG\DTOs\VisitaDTO;
use RuntimeException;
use Throwable;


final class VisitaTngService
{


    public function __construct(

        private readonly VisitaRepository $repository,

        private readonly ReglaCobroTngService $cobroService

    ){
    }





    /**
     * Crear visita
     */
    public function crear(
        VisitaDTO $dto
    ): int
    {


        return $this->repository
            ->crear(
                $dto->toArray()
            );

    }





    /**
     * Buscar visita
     */
    public function buscar(
        int $id
    ): ?array
    {


        return $this->repository
            ->buscar(
                $id
            );

    }





    /**
     * Visitas pendientes
     */
    public function pendientes(): array
    {


        return $this->repository
            ->pendientes();

    }





    /**
     * Asignar técnico
     */
    public function asignarTecnico(
        int $visitaId,
        int $tecnicoId
    ): bool
    {


        return $this->repository
            ->asignarTecnico(
                $visitaId,
                $tecnicoId
            );

    }





    /**
     * Iniciar visita
     */
    public function iniciar(
        int $id
    ): bool
    {


        return $this->repository
            ->cambiarEstado(
                $id,
                'EN_PROCESO'
            );

    }





    /**
     * Cerrar visita
     */
    public function cerrar(
        int $id
    ): bool
    {


        $visita =
            $this->buscar(
                $id
            );


        if(!$visita){


            throw new RuntimeException(
                'Visita inexistente.'
            );

        }



        if(
            $visita['estado']
            ===
            'ANULADA'
        ){

            throw new RuntimeException(
                'No se puede cerrar visita anulada.'
            );

        }



        return $this->repository
            ->cambiarEstado(
                $id,
                'CERRADA'
            );

    }





    /**
     * Calcular cobro de visita
     */
    public function calcularCobro(
        int $visitaId,
        array $cliente=[]
    ): array
    {


        $visita =
            $this->buscar(
                $visitaId
            );


        if(!$visita){


            throw new RuntimeException(
                'Visita inexistente.'
            );

        }



        return $this->cobroService
            ->calcular(
                $visita,
                $cliente
            );

    }





    /**
     * Vincular informe técnico
     */
    public function vincularInforme(
        int $visitaId,
        int $informeId
    ): bool
    {


        return $this->repository
            ->asociarInforme(
                $visitaId,
                $informeId
            );

    }





}