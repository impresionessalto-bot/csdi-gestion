<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\TarifaRepository;
use RuntimeException;


final class TarifaTngService
{


    public function __construct(
        private readonly TarifaRepository $repository
    ){
    }





    /**
     * Obtener tarifa vigente
     *
     * GENERAL
     * ARCA
     * SERVICIO
     * ESPECIAL
     */
    public function vigente(
        string $tipo
    ): ?array
    {


        $tipo =
            strtoupper(
                trim($tipo)
            );


        return $this->repository
            ->vigente(
                $tipo
            );

    }





    /**
     * Obtener tarifa obligatoria
     */
    public function obtener(
        string $tipo
    ): array
    {


        $tarifa =
            $this->vigente(
                $tipo
            );


        if(!$tarifa){


            throw new RuntimeException(

                'No existe tarifa TNG vigente: '
                .$tipo

            );

        }


        return $tarifa;

    }





    /**
     * Tarifa toma contador
     *
     * ARCA o GENERAL
     */
    public function tarifaContador(
        bool $arca=false
    ): array
    {


        return $this->obtener(

            $arca
                ? 'ARCA'
                : 'GENERAL'

        );

    }





    /**
     * Tarifa servicio técnico
     */
    public function tarifaServicio(): array
    {


        return $this->obtener(

            'SERVICIO'

        );

    }





    /**
     * Buscar tarifa
     */
    public function buscar(
        int $id
    ): ?array
    {


        return $this->repository
            ->buscar(
                $id
            );

    }





    /**
     * Listado tarifas activas
     */
    public function listar(): array
    {


        return $this->repository
            ->activas();

    }





    /**
     * Todas las tarifas
     */
    public function todas(): array
    {


        return $this->repository
            ->todas();

    }





    /**
     * Crear tarifa
     */
    public function crear(
        array $data
    ): int
    {


        if(
            empty($data['nombre'])
            ||
            empty($data['tipo'])
        ){

            throw new RuntimeException(
                'Datos de tarifa incompletos.'
            );

        }



        return $this->repository
            ->crear(
                $data
            );

    }





    /**
     * Actualizar tarifa
     */
    public function actualizar(
        int $id,
        array $data
    ): bool
    {


        return $this->repository
            ->actualizar(
                $id,
                $data
            );

    }





    /**
     * Activar tarifa
     */
    public function activar(
        int $id
    ): bool
    {


        return $this->repository
            ->activar(
                $id
            );

    }





    /**
     * Desactivar tarifa
     */
    public function desactivar(
        int $id
    ): bool
    {


        return $this->repository
            ->desactivar(
                $id
            );

    }





}