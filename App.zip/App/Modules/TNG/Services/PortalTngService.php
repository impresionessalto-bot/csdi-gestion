<?php

declare(strict_types=1);

namespace App\Modules\TNG\Services;

use App\Modules\TNG\Repositories\ContratoRepository;
use App\Modules\TNG\Repositories\VisitaRepository;
use App\Modules\TNG\Repositories\InformeTngRepository;


final class PortalTngService
{


    public function __construct(

        private readonly ContratoRepository $contratoRepository,

        private readonly VisitaRepository $visitaRepository,

        private readonly InformeTngRepository $informeRepository

    ){
    }





    /**
     * Resumen cliente portal
     */
    public function resumen(
        int $clienteId
    ): array
    {


        return [

            'contrato' =>

                $this->contratoRepository
                    ->activoCliente(
                        $clienteId
                    ),


            'visitas' =>

                $this->visitaRepository
                    ->cliente(
                        $clienteId
                    ),

        ];

    }





    /**
     * Contrato actual
     */
    public function contrato(
        int $clienteId
    ): ?array
    {

        return $this->contratoRepository
            ->activoCliente(
                $clienteId
            );

    }





    /**
     * Historial de visitas
     */
    public function visitas(
        int $clienteId
    ): array
    {

        return $this->visitaRepository
            ->cliente(
                $clienteId
            );

    }





    /**
     * Informe asociado a visita
     */
    public function informe(
        int $visitaId
    ): ?array
    {

        return $this->informeRepository
            ->buscarPorVisita(
                $visitaId
            );

    }





    /**
     * Estado general del cliente
     */
    public function estado(
        int $clienteId
    ): array
    {


        $visitas =

            $this->visitaRepository
                ->cliente(
                    $clienteId
                );



        $pendientes = 0;

        $finalizadas = 0;



        foreach($visitas as $visita){


            switch(
                $visita['estado']
            ){


                case 'PENDIENTE':

                case 'ASIGNADA':

                case 'EN_PROCESO':

                    $pendientes++;

                break;



                case 'CERRADA':

                    $finalizadas++;

                break;


            }


        }



        return [

            'visitas_pendientes'=>
                $pendientes,


            'visitas_finalizadas'=>
                $finalizadas

        ];

    }





}