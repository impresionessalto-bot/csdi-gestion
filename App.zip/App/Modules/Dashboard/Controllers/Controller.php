<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Controllers;

use App\Core\BaseController;
use App\Modules\Dashboard\DashboardManager;
use Throwable;

final class Controller extends BaseController
{
    public function __construct(
        private readonly DashboardManager $dashboardManager
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD PRINCIPAL
    |--------------------------------------------------------------------------
    */

    public function index(): mixed
    {
        try {

            $dashboard =
                $this->dashboardManager->obtener(
                    'general'
                );

            return $this->moduleView(
                'Dashboard',
                'index',
                [
                    'dashboard' =>
                        $dashboard,

                    'resumen' =>
                        $dashboard['resumen']
                        ?? [],

                    'ventas' =>
                        $dashboard['ventas']
                        ?? [],

                    'clientes' =>
                        $dashboard['clientes']
                        ?? [],

                    'equipos' =>
                        $dashboard['equipos']
                        ?? [],

                    'servicios' =>
                        $dashboard['servicios']
                        ?? [],

                    'stock' =>
                        $dashboard['stock']
                        ?? [],

                    'alertas' =>
                        $dashboard['alertas']
                        ?? [],

                    'usuario' =>
                        $this->user(),
                ]
            );

        } catch (Throwable $e) {

            if (
                defined('APP_DEBUG')
                && APP_DEBUG
            ) {
                throw $e;
            }

            return $this->moduleView(
                'Dashboard',
                'index',
                [
                    'dashboard' => [],
                    'resumen' => [],
                    'ventas' => [],
                    'clientes' => [],
                    'equipos' => [],
                    'servicios' => [],
                    'stock' => [],

                    'alertas' => [
                        [
                            'tipo' => 'danger',
                            'mensaje' =>
                                'No fue posible cargar el dashboard.',
                        ],
                    ],

                    'usuario' =>
                        $this->user(),
                ]
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD CLIENTE
    |--------------------------------------------------------------------------
    */

    public function cliente(
        int|string $id
    ): mixed {

        $clienteId = (int) $id;

        if ($clienteId <= 0) {

            return $this->notFound(
                'Cliente no encontrado.'
            );
        }

        try {

            $dashboard =
                $this->dashboardManager->obtener(
                    'cliente',
                    $clienteId
                );

            return $this->moduleView(
                'Dashboard',
                'cliente',
                [
                    'dashboard' =>
                        $dashboard,

                    'cliente' =>
                        $dashboard['cliente']
                        ?? [],

                    'resumen' =>
                        $dashboard['resumen']
                        ?? [],

                    'equipos' =>
                        $dashboard['equipos']
                        ?? [],

                    'servicios' =>
                        $dashboard['servicios']
                        ?? [],

                    'contratos' =>
                        $dashboard['contratos']
                        ?? [],

                    'ventas' =>
                        $dashboard['ventas']
                        ?? [],

                    'usuario' =>
                        $this->user(),
                ]
            );

        } catch (Throwable $e) {

            if (
                defined('APP_DEBUG')
                && APP_DEBUG
            ) {
                throw $e;
            }

            return $this->notFound(
                'No fue posible cargar el dashboard del cliente.'
            );
        }
    }
}