<?php

use App\Core\Router;
use App\Modules\Dashboard\Controllers\Controller;

Router::group(
    '/dashboard',
    [
        'auth'
    ],
    function (): void {

        Router::get(
            '',
            [
                Controller::class,
                'index'
            ]
        );

        Router::get(
            '/',
            [
                Controller::class,
                'index'
            ]
        );
    }
);