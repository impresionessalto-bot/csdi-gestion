```php
<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Services;

use App\Modules\Dashboard\Repositories\Repository;
use Throwable;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * DASHBOARD - SERVICE
 *
 * Capa de negocio/orquestación del Dashboard.
 *
 * Flujo:
 *
 * Controller
 *      ↓
 * DashboardManager
 *      ↓
 * Service
 *      ↓
 * Repository
 *      ↓
 * MySQL
 *
 * IMPORTANTE:
 * - No contiene SQL.
 * - No accede directamente a PDO.
 * - No depende de GeneralDashboard.
 * - No depende de BaseDashboard.
 * - No depende de DashboardInterface.
 * - Tolera tablas/módulos inexistentes.
 * =========================================================
 */
final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD GENERAL
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene todos los datos necesarios para el dashboard
     * principal del ERP.
     *
     * @return array<string,mixed>
     */
    public function dashboard(): array
    {
        return [
            /*
            |--------------------------------------------------------------------------
            | RESUMEN / KPIs
            |--------------------------------------------------------------------------
            */
            'resumen' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->resumen()
                ),

            /*
            |--------------------------------------------------------------------------
            | CLIENTES
            |--------------------------------------------------------------------------
            */
            'clientes' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->clientes()
                ),

            /*
            |--------------------------------------------------------------------------
            | EQUIPOS
            |--------------------------------------------------------------------------
            */
            'equipos' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->equipos()
                ),

            /*
            |--------------------------------------------------------------------------
            | SERVICIOS
            |--------------------------------------------------------------------------
            */
            'servicios' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->servicios()
                ),

            /*
            |--------------------------------------------------------------------------
            | VENTAS
            |--------------------------------------------------------------------------
            */
            'ventas' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->ventas()
                ),

            /*
            |--------------------------------------------------------------------------
            | COMPRAS
            |--------------------------------------------------------------------------
            */
            'compras' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->compras()
                ),

            /*
            |--------------------------------------------------------------------------
            | INVENTARIO
            |--------------------------------------------------------------------------
            */
            'inventario' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->inventario()
                ),

            /*
            |--------------------------------------------------------------------------
            | STOCK BAJO
            |--------------------------------------------------------------------------
            */
            'stock_bajo' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->stockBajo()
                ),

            /*
            |--------------------------------------------------------------------------
            | SIN STOCK
            |--------------------------------------------------------------------------
            */
            'sin_stock' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->sinStock()
                ),

            /*
            |--------------------------------------------------------------------------
            | ALERTAS
            |--------------------------------------------------------------------------
            */
            'alertas' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->alertas()
                ),

            /*
            |--------------------------------------------------------------------------
            | ACTIVIDAD
            |--------------------------------------------------------------------------
            */
            'actividad' =>
                $this->safe(
                    fn (): array =>
                        $this->repository->actividad()
                ),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN
    |--------------------------------------------------------------------------
    */

    /**
     * @return array<string,mixed>
     */
    public function resumen(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->resumen()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientes(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->clientes()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS
    |--------------------------------------------------------------------------
    */

    public function equipos(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->equipos()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICIOS
    |--------------------------------------------------------------------------
    */

    public function servicios(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->servicios()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VENTAS
    |--------------------------------------------------------------------------
    */

    public function ventas(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->ventas()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | COMPRAS
    |--------------------------------------------------------------------------
    */

    public function compras(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->compras()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INVENTARIO
    |--------------------------------------------------------------------------
    */

    /**
     * @return array<string,mixed>
     */
    public function inventario(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->inventario()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | STOCK BAJO
    |--------------------------------------------------------------------------
    */

    public function stockBajo(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->stockBajo()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | SIN STOCK
    |--------------------------------------------------------------------------
    */

    public function sinStock(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->sinStock()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ALERTAS
    |--------------------------------------------------------------------------
    */

    public function alertas(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->alertas()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ACTIVIDAD
    |--------------------------------------------------------------------------
    */

    public function actividad(): array
    {
        return $this->safe(
            fn (): array =>
                $this->repository->actividad()
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD CLIENTE
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene toda la información relacionada con un cliente.
     *
     * @return array<string,mixed>
     */
    public function cliente(int $clienteId): array
    {
        if ($clienteId <= 0) {
            return [
                'cliente' => null,
                'equipos' => [],
                'servicios' => [],
                'ventas' => [],
            ];
        }

        return $this->safe(
            fn (): array =>
                $this->repository->cliente($clienteId),
            [
                'cliente' => null,
                'equipos' => [],
                'servicios' => [],
                'ventas' => [],
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DEBUG
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve un resumen técnico de los datos disponibles.
     *
     * Útil para verificar rápidamente si el Service está
     * recibiendo información desde Repository.
     */
    public function debug(): array
    {
        $dashboard = $this->dashboard();

        return [
            'ok' => true,

            'claves' =>
                array_keys($dashboard),

            'resumen' =>
                $dashboard['resumen'] ?? [],

            'cantidad_clientes' =>
                count(
                    is_array($dashboard['clientes'] ?? null)
                        ? $dashboard['clientes']
                        : []
                ),

            'cantidad_equipos' =>
                count(
                    is_array($dashboard['equipos'] ?? null)
                        ? $dashboard['equipos']
                        : []
                ),

            'cantidad_servicios' =>
                count(
                    is_array($dashboard['servicios'] ?? null)
                        ? $dashboard['servicios']
                        : []
                ),

            'cantidad_ventas' =>
                count(
                    is_array($dashboard['ventas'] ?? null)
                        ? $dashboard['ventas']
                        : []
                ),

            'cantidad_compras' =>
                count(
                    is_array($dashboard['compras'] ?? null)
                        ? $dashboard['compras']
                        : []
                ),

            'inventario' =>
                $dashboard['inventario'] ?? [],

            'cantidad_alertas' =>
                count(
                    is_array($dashboard['alertas'] ?? null)
                        ? $dashboard['alertas']
                        : []
                ),

            'cantidad_actividad' =>
                count(
                    is_array($dashboard['actividad'] ?? null)
                        ? $dashboard['actividad']
                        : []
                ),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | SAFE EXECUTION
    |--------------------------------------------------------------------------
    */

    /**
     * Ejecuta una consulta del Repository sin permitir que
     * una tabla opcional rompa todo el Dashboard.
     *
     * @param callable():array $callback
     * @param array<string,mixed> $fallback
     *
     * @return array
     */
    private function safe(
        callable $callback,
        array $fallback = []
    ): array {
        try {

            $resultado = $callback();

            return is_array($resultado)
                ? $resultado
                : $fallback;

        } catch (Throwable) {

            return $fallback;
        }
    }
}
```
