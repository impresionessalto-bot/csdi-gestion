<?php

declare(strict_types=1);

namespace App\Modules\Dashboard;

use App\Core\Container;
use App\Dashboard\BaseDashboard;
use App\Dashboard\DashboardInterface;
use App\Dashboard\GeneralDashboard;
use RuntimeException;
use Throwable;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * DASHBOARD MANAGER
 *
 * Administrador central de dashboards.
 *
 * IMPORTANTE:
 * Actualmente se registra solamente el Dashboard General.
 *
 * Los dashboards específicos podrán agregarse posteriormente
 * sin romper el Dashboard principal.
 * =========================================================
 */
final class DashboardManager
{
    /**
     * Dashboards registrados.
     *
     * @var array<string, class-string>
     */
    private array $dashboards = [];

    /**
     * Instancias cacheadas.
     *
     * @var array<string, DashboardInterface>
     */
    private array $instances = [];

    /**
     * Constructor.
     */
    public function __construct(
        private readonly Container $container
    ) {
        $this->registerDefaults();
    }

    /**
     * =========================================================
     * REGISTRO DE DASHBOARDS
     * =========================================================
     */
    private function registerDefaults(): void
    {
        /*
        |--------------------------------------------------------------------------
        | DASHBOARD GENERAL
        |--------------------------------------------------------------------------
        |
        | Es el dashboard principal del ERP.
        |
        | Ruta:
        |
        | /dashboard
        |
        */

        if (class_exists(GeneralDashboard::class)) {
            $this->register(
                'general',
                GeneralDashboard::class
            );
        }
    }

    /**
     * =========================================================
     * REGISTRAR DASHBOARD
     * =========================================================
     */
    public function register(
        string $nombre,
        string $class
    ): void {

        $nombre = trim($nombre);

        if ($nombre === '') {
            throw new RuntimeException(
                'El nombre del dashboard no puede estar vacío.'
            );
        }

        if (!class_exists($class)) {
            throw new RuntimeException(
                "Dashboard inexistente: {$class}"
            );
        }

        if (!is_subclass_of($class, BaseDashboard::class)) {
            throw new RuntimeException(
                "Dashboard inválido: {$class}. " .
                "Debe extender BaseDashboard."
            );
        }

        $this->dashboards[$nombre] = $class;
    }

    /**
     * =========================================================
     * OBTENER DATOS
     * =========================================================
     *
     * @param string $nombre
     * @param int $id
     *
     * @return array<string,mixed>
     */
    public function obtener(
        string $nombre,
        int $id = 0
    ): array {

        return $this
            ->instancia($nombre)
            ->obtener($id);
    }

    /**
     * =========================================================
     * OBTENER INSTANCIA
     * =========================================================
     */
    public function instancia(
        string $nombre
    ): DashboardInterface {

        $nombre = trim($nombre);

        if (!$this->existe($nombre)) {
            throw new RuntimeException(
                "Dashboard no registrado: {$nombre}"
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CACHE
        |--------------------------------------------------------------------------
        */

        if (isset($this->instances[$nombre])) {
            return $this->instances[$nombre];
        }

        try {

            $class =
                $this->dashboards[$nombre];

            /*
            |--------------------------------------------------------------------------
            | CONTAINER
            |--------------------------------------------------------------------------
            */

            $dashboard =
                $this->container->make(
                    $class
                );

            /*
            |--------------------------------------------------------------------------
            | VALIDACIÓN
            |--------------------------------------------------------------------------
            */

            if (
                !$dashboard
                instanceof DashboardInterface
            ) {

                throw new RuntimeException(
                    "El dashboard {$class} " .
                    "no implementa DashboardInterface."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CACHEAR
            |--------------------------------------------------------------------------
            */

            $this->instances[$nombre] =
                $dashboard;

            return $dashboard;

        } catch (Throwable $e) {

            throw new RuntimeException(
                "Error cargando Dashboard {$nombre}: " .
                $e->getMessage(),
                0,
                $e
            );
        }
    }

    /**
     * =========================================================
     * EXISTE
     * =========================================================
     */
    public function existe(
        string $nombre
    ): bool {

        return isset(
            $this->dashboards[$nombre]
        );
    }

    /**
     * =========================================================
     * DISPONIBLES
     * =========================================================
     *
     * @return array<int,string>
     */
    public function disponibles(): array
    {
        return array_keys(
            $this->dashboards
        );
    }

    /**
     * =========================================================
     * ELIMINAR
     * =========================================================
     */
    public function remove(
        string $nombre
    ): void {

        unset(
            $this->dashboards[$nombre],
            $this->instances[$nombre]
        );
    }

    /**
     * =========================================================
     * RESET
     * =========================================================
     */
    public function reset(): void
    {
        $this->dashboards = [];
        $this->instances = [];

        $this->registerDefaults();
    }

    /**
     * =========================================================
     * DEBUG
     * =========================================================
     *
     * Útil para comprobar qué dashboards fueron cargados.
     *
     * @return array<string,mixed>
     */
    public function debug(): array
    {
        return [
            'dashboards' =>
                $this->dashboards,

            'instancias' =>
                array_keys(
                    $this->instances
                ),

            'total' =>
                count(
                    $this->dashboards
                ),
        ];
    }
}