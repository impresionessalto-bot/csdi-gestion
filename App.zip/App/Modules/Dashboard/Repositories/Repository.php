<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Services;

use App\Modules\Dashboard\Repositories\Repository;
use InvalidArgumentException;
use Throwable;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * DASHBOARD - SERVICE
 *
 * Capa de negocio del Dashboard.
 *
 * Flujo:
 *
 * Controller
 *     ↓
 * DashboardManager
 *     ↓
 * Service
 *     ↓
 * Repository
 *     ↓
 * MySQL
 *
 * IMPORTANTE:
 * - No contiene SQL.
 * - No depende de App\Dashboard\*
 * - No depende de GeneralDashboard.
 * - No depende de BaseDashboard.
 * - No depende de DashboardInterface.
 * =========================================================
 */
final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD GENERAL
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene toda la información necesaria
     * para el dashboard principal del ERP.
     */
    public function dashboard(): array
    {
        try {

            $resumen = $this->repository->resumen();

            return [
                /*
                 * KPIs principales
                 */
                'resumen' => $resumen,

                /*
                 * Alias directos para facilitar
                 * el consumo desde la View.
                 */
                'clientes' =>
                    (int) (
                        $resumen['clientes'] ?? 0
                    ),

                'clientes_activos' =>
                    (int) (
                        $resumen['clientes_activos'] ?? 0
                    ),

                'equipos' =>
                    (int) (
                        $resumen['equipos'] ?? 0
                    ),

                'equipos_activos' =>
                    (int) (
                        $resumen['equipos_activos'] ?? 0
                    ),

                'servicios' =>
                    (int) (
                        $resumen['servicios'] ?? 0
                    ),

                'servicios_pendientes' =>
                    (int) (
                        $resumen['servicios_pendientes'] ?? 0
                    ),

                'ventas' =>
                    (int) (
                        $resumen['ventas'] ?? 0
                    ),

                'ventas_hoy' =>
                    (int) (
                        $resumen['ventas_hoy'] ?? 0
                    ),

                'ventas_mes' =>
                    (int) (
                        $resumen['ventas_mes'] ?? 0
                    ),

                'ventas_importe' =>
                    (float) (
                        $resumen['ventas_importe'] ?? 0
                    ),

                'compras' =>
                    (int) (
                        $resumen['compras'] ?? 0
                    ),

                'compras_mes' =>
                    (int) (
                        $resumen['compras_mes'] ?? 0
                    ),

                'compras_importe' =>
                    (float) (
                        $resumen['compras_importe'] ?? 0
                    ),

                'insumos' =>
                    (int) (
                        $resumen['insumos'] ?? 0
                    ),

                'stock_bajo' =>
                    (int) (
                        $resumen['stock_bajo'] ?? 0
                    ),

                'sin_stock' =>
                    (int) (
                        $resumen['sin_stock'] ?? 0
                    ),

                /*
                 * Listados para widgets
                 */
                'clientes_recientes' =>
                    $this->clientes(),

                'equipos_recientes' =>
                    $this->equipos(),

                'servicios_recientes' =>
                    $this->servicios(),

                'ventas_recientes' =>
                    $this->ventas(),

                'compras_recientes' =>
                    $this->compras(),

                /*
                 * Inventario
                 */
                'inventario' =>
                    $this->inventario(),

                /*
                 * Alertas
                 */
                'alertas' =>
                    $this->alertas(),

                /*
                 * Actividad reciente
                 */
                'actividad' =>
                    $this->actividad(),

                /*
                 * Stock
                 */
                'stock_bajo_lista' =>
                    $this->stockBajo(),

                'sin_stock_lista' =>
                    $this->sinStock(),
            ];

        } catch (Throwable $e) {

            throw new InvalidArgumentException(
                'No se pudo cargar el dashboard: '
                . $e->getMessage(),
                0,
                $e
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RESUMEN
    |--------------------------------------------------------------------------
    */

    public function resumen(): array
    {
        return $this->repository->resumen();
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientes(): array
    {
        return $this->repository->clientes();
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS
    |--------------------------------------------------------------------------
    */

    public function equipos(): array
    {
        return $this->repository->equipos();
    }

    /*
    |--------------------------------------------------------------------------
    | SERVICIOS
    |--------------------------------------------------------------------------
    */

    public function servicios(): array
    {
        return $this->repository->servicios();
    }

    /*
    |--------------------------------------------------------------------------
    | VENTAS
    |--------------------------------------------------------------------------
    */

    public function ventas(): array
    {
        return $this->repository->ventas();
    }

    /*
    |--------------------------------------------------------------------------
    | COMPRAS
    |--------------------------------------------------------------------------
    */

    public function compras(): array
    {
        return $this->repository->compras();
    }

    /*
    |--------------------------------------------------------------------------
    | INVENTARIO
    |--------------------------------------------------------------------------
    */

    public function inventario(): array
    {
        return $this->repository->inventario();
    }

    /*
    |--------------------------------------------------------------------------
    | STOCK BAJO
    |--------------------------------------------------------------------------
    */

    public function stockBajo(): array
    {
        return $this->repository->stockBajo();
    }

    /*
    |--------------------------------------------------------------------------
    | SIN STOCK
    |--------------------------------------------------------------------------
    */

    public function sinStock(): array
    {
        return $this->repository->sinStock();
    }

    /*
    |--------------------------------------------------------------------------
    | ALERTAS
    |--------------------------------------------------------------------------
    */

    public function alertas(): array
    {
        return $this->repository->alertas();
    }

    /*
    |--------------------------------------------------------------------------
    | ACTIVIDAD
    |--------------------------------------------------------------------------
    */

    public function actividad(): array
    {
        return $this->repository->actividad();
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD DE CLIENTE
    |--------------------------------------------------------------------------
    */

    public function cliente(
        int $clienteId
    ): array {

        if ($clienteId <= 0) {
            throw new InvalidArgumentException(
                'ID de cliente inválido.'
            );
        }

        return $this->repository->cliente(
            $clienteId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS PARA WIDGETS
    |--------------------------------------------------------------------------
    */

    /**
     * Clientes recientes.
     */
    public function clientesRecientes(): array
    {
        return $this->clientes();
    }

    /**
     * Equipos recientes.
     */
    public function equiposRecientes(): array
    {
        return $this->equipos();
    }

    /**
     * Servicios recientes.
     */
    public function serviciosRecientes(): array
    {
        return $this->servicios();
    }

    /**
     * Ventas recientes.
     */
    public function ventasRecientes(): array
    {
        return $this->ventas();
    }

    /**
     * Compras recientes.
     */
    public function comprasRecientes(): array
    {
        return $this->compras();
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve las estadísticas principales
     * en una estructura simple para gráficos.
     */
    public function estadisticas(): array
    {
        $resumen = $this->repository->resumen();

        return [
            'clientes' => [
                'total' =>
                    (int) (
                        $resumen['clientes'] ?? 0
                    ),

                'activos' =>
                    (int) (
                        $resumen['clientes_activos'] ?? 0
                    ),
            ],

            'equipos' => [
                'total' =>
                    (int) (
                        $resumen['equipos'] ?? 0
                    ),

                'activos' =>
                    (int) (
                        $resumen['equipos_activos'] ?? 0
                    ),
            ],

            'servicios' => [
                'total' =>
                    (int) (
                        $resumen['servicios'] ?? 0
                    ),

                'pendientes' =>
                    (int) (
                        $resumen['servicios_pendientes'] ?? 0
                    ),
            ],

            'ventas' => [
                'total' =>
                    (int) (
                        $resumen['ventas'] ?? 0
                    ),

                'hoy' =>
                    (int) (
                        $resumen['ventas_hoy'] ?? 0
                    ),

                'mes' =>
                    (int) (
                        $resumen['ventas_mes'] ?? 0
                    ),

                'importe' =>
                    (float) (
                        $resumen['ventas_importe'] ?? 0
                    ),
            ],

            'compras' => [
                'total' =>
                    (int) (
                        $resumen['compras'] ?? 0
                    ),

                'mes' =>
                    (int) (
                        $resumen['compras_mes'] ?? 0
                    ),

                'importe' =>
                    (float) (
                        $resumen['compras_importe'] ?? 0
                    ),
            ],

            'inventario' => [
                'insumos' =>
                    (int) (
                        $resumen['insumos'] ?? 0
                    ),

                'stock_bajo' =>
                    (int) (
                        $resumen['stock_bajo'] ?? 0
                    ),

                'sin_stock' =>
                    (int) (
                        $resumen['sin_stock'] ?? 0
                    ),
            ],
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | WIDGET INDIVIDUAL
    |--------------------------------------------------------------------------
    */

    /**
     * Permite solicitar un bloque concreto
     * del dashboard sin cargar todo.
     */
    public function widget(
        string $nombre
    ): array {

        $nombre = trim($nombre);

        return match ($nombre) {

            'resumen' =>
                $this->resumen(),

            'clientes' =>
                $this->clientes(),

            'equipos' =>
                $this->equipos(),

            'servicios' =>
                $this->servicios(),

            'ventas' =>
                $this->ventas(),

            'compras' =>
                $this->compras(),

            'inventario' =>
                $this->inventario(),

            'stock_bajo' =>
                $this->stockBajo(),

            'sin_stock' =>
                $this->sinStock(),

            'alertas' =>
                $this->alertas(),

            'actividad' =>
                $this->actividad(),

            'estadisticas' =>
                $this->estadisticas(),

            default =>
                throw new InvalidArgumentException(
                    "Widget de dashboard desconocido: {$nombre}"
                ),
        };
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD COMPLETO
    |--------------------------------------------------------------------------
    */

    /**
     * Alias explícito para consumo desde
     * otros módulos del ERP.
     */
    public function obtener(): array
    {
        return $this->dashboard();
    }
}