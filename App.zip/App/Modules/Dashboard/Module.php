<?php

declare(strict_types=1);

namespace App\Modules\Dashboard;

use App\Core\Module as CoreModule;

final class Module extends CoreModule
{
    public function name(): string
    {
        return 'Dashboard';
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function menu(): array
    {
        return [
            [
                'title' => 'Dashboard',
                'url' => '/dashboard',
                'icon' => 'fa-solid fa-gauge',
                'order' => 1
            ]
        ];
    }

    public function permissions(): array
    {
        return [];
    }

    public function boot(): void
    {
    }
}