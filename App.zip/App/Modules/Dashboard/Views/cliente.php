<?php

$cliente = is_array($cliente ?? null)
    ? $cliente
    : [];

$nombre =
    $cliente['nombre']
    ?? $cliente['razon_social']
    ?? $cliente['empresa']
    ?? 'Cliente';

?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">
                <?= htmlspecialchars(
                    (string) $nombre,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h1>

            <div class="text-muted">
                Información del cliente
            </div>

        </div>

        <a
            href="/dashboard"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Dashboard
        </a>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="row g-4">

                <div class="col-md-6">

                    <div class="small text-muted">
                        Cliente
                    </div>

                    <div class="fw-semibold">
                        <?= htmlspecialchars(
                            (string) $nombre,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="small text-muted">
                        ID
                    </div>

                    <div class="fw-semibold">
                        <?= (int) (
                            $cliente['id']
                            ?? 0
                        ) ?>
                    </div>

                </div>


                <?php foreach (
                    [
                        'cuit'     => 'CUIT',
                        'telefono' => 'Teléfono',
                        'email'    => 'Email',
                        'direccion'=> 'Dirección',
                    ] as $campo => $titulo
                ): ?>

                    <?php if (
                        isset($cliente[$campo])
                        &&
                        $cliente[$campo] !== ''
                    ): ?>

                        <div class="col-md-6">

                            <div class="small text-muted">
                                <?= $titulo ?>
                            </div>

                            <div class="fw-semibold">

                                <?= htmlspecialchars(
                                    (string) $cliente[$campo],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </div>

                        </div>

                    <?php endif; ?>

                <?php endforeach; ?>

            </div>

        </div>

    </div>

</div>