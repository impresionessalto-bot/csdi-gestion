<?php

$resumen = is_array($resumen ?? null)
    ? $resumen
    : [];

$ventas = is_array($ventas ?? null)
    ? $ventas
    : [];

$clientes = is_array($clientes ?? null)
    ? $clientes
    : [];

$stock = is_array($stock ?? null)
    ? $stock
    : [];

$pendientes = is_array($pendientes ?? null)
    ? $pendientes
    : [];

$usuario = is_array($usuario ?? null)
    ? $usuario
    : [];

if (!function_exists('dashboardMoney')) {

    function dashboardMoney(
        float|int|string|null $value
    ): string {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            2,
            ',',
            '.'
        );
    }
}

if (!function_exists('dashboardNumber')) {

    function dashboardNumber(
        float|int|string|null $value
    ): string {
        return number_format(
            (float) ($value ?? 0),
            0,
            ',',
            '.'
        );
    }
}

if (!function_exists('dashboardEscape')) {

    function dashboardEscape(
        mixed $value
    ): string {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

$ventasHoy =
    (int) (
        $resumen['ventas_hoy']
        ?? 0
    );

$totalHoy =
    (float) (
        $resumen['total_hoy']
        ?? 0
    );

$totalClientes =
    (int) (
        $resumen['clientes']
        ?? 0
    );

$totalEquipos =
    (int) (
        $resumen['equipos']
        ?? 0
    );

$serviciosPendientes =
    (int) (
        $resumen['servicios_pendientes']
        ?? $pendientes['servicios']
        ?? 0
    );

$stockBajo =
    (int) (
        $resumen['stock_bajo']
        ?? $pendientes['stock']
        ?? 0
    );

$facturacionPendiente =
    (int) (
        $resumen['facturacion_pendiente']
        ?? $pendientes['facturacion']
        ?? 0
    );

?>

<div class="container-fluid py-4">

    <!-- HEADER -->

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">
                Dashboard
            </h1>

            <p class="text-muted mb-0">
                Resumen general de CSDI ERP.
            </p>

        </div>

        <div class="d-flex gap-2">

            <a
                href="/ventas/nueva"
                class="btn btn-primary"
            >
                <i class="bi bi-plus-lg me-1"></i>
                Nueva venta
            </a>

        </div>

    </div>


    <!-- INDICADORES -->

    <div class="row g-3 mb-4">

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="small text-muted">
                                Ventas hoy
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= dashboardNumber($ventasHoy) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                <?= dashboardMoney($totalHoy) ?>
                            </div>

                        </div>

                        <div class="text-primary fs-2">
                            <i class="bi bi-cart-check"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="small text-muted">
                                Clientes
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= dashboardNumber($totalClientes) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                Clientes registrados
                            </div>

                        </div>

                        <div class="text-success fs-2">
                            <i class="bi bi-people"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="small text-muted">
                                Equipos
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= dashboardNumber($totalEquipos) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                Equipos registrados
                            </div>

                        </div>

                        <div class="text-info fs-2">
                            <i class="bi bi-printer"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="small text-muted">
                                Pendientes
                            </div>

                            <div class="fs-3 fw-bold mt-1">
                                <?= dashboardNumber(
                                    $serviciosPendientes
                                    + $stockBajo
                                    + $facturacionPendiente
                                ) ?>
                            </div>

                            <div class="small text-muted mt-2">
                                Requieren atención
                            </div>

                        </div>

                        <div class="text-warning fs-2">
                            <i class="bi bi-exclamation-circle"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ACCESOS -->

    <div class="mb-3">

        <h5 class="fw-bold mb-1">
            Accesos rápidos
        </h5>

        <p class="text-muted small">
            Principales operaciones del sistema.
        </p>

    </div>


    <div class="row g-3 mb-4">

        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/ventas"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-primary fs-2 mb-3">
                            <i class="bi bi-cart3"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Ventas
                        </h6>

                        <p class="text-muted small mb-0">
                            Ventas, presupuestos, pedidos y remitos.
                        </p>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/clientes"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-success fs-2 mb-3">
                            <i class="bi bi-people"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Clientes
                        </h6>

                        <p class="text-muted small mb-0">
                            Gestionar clientes y datos comerciales.
                        </p>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/inventario"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-info fs-2 mb-3">
                            <i class="bi bi-box-seam"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Inventario
                        </h6>

                        <p class="text-muted small mb-0">
                            Stock, insumos y movimientos.
                        </p>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-6 col-xl-3">

            <a
                href="/servicios"
                class="text-decoration-none"
            >

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-warning fs-2 mb-3">
                            <i class="bi bi-tools"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Servicios
                        </h6>

                        <p class="text-muted small mb-0">
                            Trabajos técnicos y mantenimiento.
                        </p>

                    </div>

                </div>

            </a>

        </div>

    </div>


    <!-- PENDIENTES -->

    <div class="row g-3 mb-4">

        <div class="col-12 col-lg-4">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="fw-bold">
                                Servicios pendientes
                            </div>

                            <div class="text-muted small">
                                Trabajos que requieren atención.
                            </div>

                        </div>

                        <span class="badge bg-warning-subtle text-warning-emphasis fs-6">
                            <?= dashboardNumber($serviciosPendientes) ?>
                        </span>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-lg-4">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="fw-bold">
                                Stock bajo
                            </div>

                            <div class="text-muted small">
                                Insumos para revisar.
                            </div>

                        </div>

                        <span class="badge bg-danger-subtle text-danger fs-6">
                            <?= dashboardNumber($stockBajo) ?>
                        </span>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-lg-4">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <div class="fw-bold">
                                Facturación pendiente
                            </div>

                            <div class="text-muted small">
                                Operaciones pendientes de facturar.
                            </div>

                        </div>

                        <span class="badge bg-primary-subtle text-primary fs-6">
                            <?= dashboardNumber($facturacionPendiente) ?>
                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ACTIVIDAD -->

    <div class="row g-3">

        <!-- VENTAS -->

        <div class="col-12 col-xl-8">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white border-0 py-3">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <h5 class="fw-bold mb-1">
                                Últimas ventas
                            </h5>

                            <div class="small text-muted">
                                Actividad comercial reciente.
                            </div>

                        </div>

                        <a
                            href="/ventas/listado"
                            class="btn btn-sm btn-outline-primary"
                        >
                            Ver todas
                        </a>

                    </div>

                </div>

                <div class="card-body p-0">

                    <?php if (!$ventas): ?>

                        <div class="text-center text-muted py-5">
                            <i class="bi bi-cart-x fs-1 d-block mb-2"></i>
                            No hay ventas registradas.
                        </div>

                    <?php else: ?>

                        <div class="table-responsive">

                            <table class="table table-hover align-middle mb-0">

                                <thead class="table-light">

                                    <tr>

                                        <th class="ps-4">
                                            Comprobante
                                        </th>

                                        <th>
                                            Cliente
                                        </th>

                                        <th>
                                            Estado
                                        </th>

                                        <th class="text-end pe-4">
                                            Total
                                        </th>

                                    </tr>

                                </thead>

                                <tbody>

                                <?php foreach (
                                    array_slice($ventas, 0, 8)
                                    as $venta
                                ): ?>

                                    <?php

                                    $id =
                                        (int) (
                                            $venta['id']
                                            ?? 0
                                        );

                                    $cliente =
                                        $venta['cliente_nombre']
                                        ?? $venta['cliente']
                                        ?? 'Consumidor Final';

                                    $total =
                                        $venta['total_venta']
                                        ?? $venta['total']
                                        ?? 0;

                                    $estado =
                                        $venta['estado']
                                        ?? 'CONFIRMADA';

                                    ?>

                                    <tr>

                                        <td class="ps-4 fw-semibold">
                                            #<?= $id ?>
                                        </td>

                                        <td>
                                            <?= dashboardEscape($cliente) ?>
                                        </td>

                                        <td>
                                            <span class="badge bg-primary-subtle text-primary">
                                                <?= dashboardEscape(
                                                    ucfirst(
                                                        strtolower(
                                                            (string) $estado
                                                        )
                                                    )
                                                ) ?>
                                            </span>
                                        </td>

                                        <td class="text-end pe-4 fw-semibold">
                                            <?= dashboardMoney($total) ?>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>


        <!-- CLIENTES -->

        <div class="col-12 col-xl-4">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-header bg-white border-0 py-3">

                    <h5 class="fw-bold mb-1">
                        Clientes recientes
                    </h5>

                    <div class="small text-muted">
                        Últimos clientes registrados.
                    </div>

                </div>

                <div class="card-body p-0">

                    <?php if (!$clientes): ?>

                        <div class="text-center text-muted py-5">
                            No hay clientes para mostrar.
                        </div>

                    <?php else: ?>

                        <div class="list-group list-group-flush">

                            <?php foreach (
                                array_slice($clientes, 0, 8)
                                as $cliente
                            ): ?>

                                <?php

                                $clienteId =
                                    (int) (
                                        $cliente['id']
                                        ?? 0
                                    );

                                $nombre =
                                    $cliente['nombre']
                                    ?? $cliente['razon_social']
                                    ?? $cliente['empresa']
                                    ?? 'Cliente';

                                ?>

                                <div class="list-group-item px-3 py-3">

                                    <div class="d-flex align-items-center gap-3">

                                        <div class="rounded-circle bg-primary-subtle text-primary p-2">
                                            <i class="bi bi-person"></i>
                                        </div>

                                        <div class="flex-grow-1">

                                            <div class="fw-semibold">
                                                <?= dashboardEscape($nombre) ?>
                                            </div>

                                            <?php if ($clienteId > 0): ?>

                                                <div class="small text-muted">
                                                    Cliente #<?= $clienteId ?>
                                                </div>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</div>