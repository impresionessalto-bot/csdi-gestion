<?php

declare(strict_types=1);

namespace App\Modules\Dashboard;

use App\Modules\Dashboard\Services\Service;
use RuntimeException;
use Throwable;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * DASHBOARD MANAGER
 *
 * Orquestador central del módulo Dashboard.
 *
 * Arquitectura:
 *
 * Controller
 *      ↓
 * DashboardManager
 *      ↓
 * Dashboard Service
 *      ↓
 * Repository
 *      ↓
 * Base de datos
 *
 * IMPORTANTE:
 *
 * - No contiene SQL.
 * - No contiene lógica de negocio.
 * - No depende de App\Dashboard.
 * - No depende de GeneralDashboard.
 * - No depende de BaseDashboard.
 * - No depende de DashboardInterface.
 * =========================================================
 */
final class DashboardManager
{
    /**
     * Dashboards registrados.
     *
     * @var array<string,string>
     */
    private array $dashboards = [];

    /**
     * Instancias cacheadas.
     *
     * @var array<string,object>
     */
    private array $instances = [];

    /**
     * Constructor.
     */
    public function __construct(
        private readonly Service $service
    ) {
        $this->registerDefaults();
    }

    /**
     * =========================================================
     * DASHBOARDS POR DEFECTO
     * =========================================================
     *
     * El Dashboard General utiliza directamente el Service.
     *
     * También registramos "cliente" sobre el mismo Service
     * porque el Service dispone del método cliente().
     */
    private function registerDefaults(): void
    {
        $this->dashboards = [
            'general' => Service::class,
            'cliente' => Service::class,
        ];
    }

    /**
     * =========================================================
     * REGISTRAR DASHBOARD
     * =========================================================
     */
    public function register(
        string $nombre,
        string $class
    ): void {

        $nombre = trim($nombre);
        $class  = trim($class);

        if ($nombre === '') {
            throw new RuntimeException(
                'El nombre del dashboard no puede estar vacío.'
            );
        }

        if ($class === '') {
            throw new RuntimeException(
                "Clase inválida para dashboard: {$nombre}"
            );
        }

        if (!class_exists($class)) {
            throw new RuntimeException(
                "Clase de dashboard inexistente: {$class}"
            );
        }

        $this->dashboards[$nombre] = $class;

        /*
        |--------------------------------------------------------------------------
        | Si se reemplaza un dashboard, eliminamos la instancia anterior.
        |--------------------------------------------------------------------------
        */

        unset(
            $this->instances[$nombre]
        );
    }

    /**
     * =========================================================
     * OBTENER DASHBOARD
     * =========================================================
     *
     * Dashboard general:
     *
     *     obtener('general')
     *
     * Dashboard cliente:
     *
     *     obtener('cliente', $clienteId)
     */
    public function obtener(
        string $nombre,
        int $id = 0
    ): array {

        $nombre = trim($nombre);

        if ($nombre === '') {
            throw new RuntimeException(
                'Debe indicar un dashboard.'
            );
        }

        if (!$this->existe($nombre)) {
            throw new RuntimeException(
                "Dashboard no registrado: {$nombre}"
            );
        }

        try {

            $dashboard = $this->instancia(
                $nombre
            );

            /*
            |--------------------------------------------------------------------------
            | DASHBOARD GENERAL
            |--------------------------------------------------------------------------
            */

            if ($nombre === 'general') {

                if (
                    !method_exists(
                        $dashboard,
                        'dashboard'
                    )
                ) {
                    throw new RuntimeException(
                        'El Service del Dashboard no dispone del método dashboard().'
                    );
                }

                $resultado =
                    $dashboard->dashboard();

                return is_array($resultado)
                    ? $resultado
                    : [];
            }

            /*
            |--------------------------------------------------------------------------
            | DASHBOARD CLIENTE
            |--------------------------------------------------------------------------
            */

            if ($nombre === 'cliente') {

                if ($id <= 0) {
                    throw new RuntimeException(
                        'ID de cliente inválido.'
                    );
                }

                if (
                    !method_exists(
                        $dashboard,
                        'cliente'
                    )
                ) {
                    throw new RuntimeException(
                        'El Service del Dashboard no dispone del método cliente().'
                    );
                }

                $resultado =
                    $dashboard->cliente(
                        $id
                    );

                return is_array($resultado)
                    ? $resultado
                    : [];
            }

            /*
            |--------------------------------------------------------------------------
            | DASHBOARD PERSONALIZADO
            |--------------------------------------------------------------------------
            |
            | Si en el futuro registramos otro Service con un método
            | dashboard(), también será soportado.
            |
            */

            if (
                method_exists(
                    $dashboard,
                    'dashboard'
                )
            ) {

                $resultado =
                    $dashboard->dashboard();

                return is_array($resultado)
                    ? $resultado
                    : [];
            }

            throw new RuntimeException(
                "El dashboard {$nombre} no tiene un método válido."
            );

        } catch (Throwable $e) {

            /*
            |--------------------------------------------------------------------------
            | No ocultamos la excepción original.
            |--------------------------------------------------------------------------
            */

            throw new RuntimeException(
                "Error obteniendo Dashboard {$nombre}: "
                . $e->getMessage(),
                0,
                $e
            );
        }
    }

    /**
     * =========================================================
     * OBTENER INSTANCIA
     * =========================================================
     */
    public function instancia(
        string $nombre
    ): object {

        $nombre = trim($nombre);

        if ($nombre === '') {
            throw new RuntimeException(
                'Debe indicar un dashboard.'
            );
        }

        if (!$this->existe($nombre)) {
            throw new RuntimeException(
                "Dashboard no registrado: {$nombre}"
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CACHE
        |--------------------------------------------------------------------------
        */

        if (
            isset(
                $this->instances[$nombre]
            )
        ) {
            return $this->instances[$nombre];
        }

        $class =
            $this->dashboards[$nombre];

        /*
        |--------------------------------------------------------------------------
        | SERVICE PRINCIPAL
        |--------------------------------------------------------------------------
        |
        | Tanto general como cliente utilizan el mismo Service.
        |
        */

        if ($class === Service::class) {

            $this->instances[$nombre] =
                $this->service;

            return $this->service;
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDAR CLASE
        |--------------------------------------------------------------------------
        */

        if (!class_exists($class)) {
            throw new RuntimeException(
                "Clase inexistente: {$class}"
            );
        }

        /*
        |--------------------------------------------------------------------------
        | DASHBOARD PERSONALIZADO
        |--------------------------------------------------------------------------
        |
        | Actualmente no es necesario.
        |
        | Se deja preparado para una futura ampliación.
        |
        */

        try {

            $reflection =
                new \ReflectionClass(
                    $class
                );

            if (
                !$reflection->isInstantiable()
            ) {
                throw new RuntimeException(
                    "La clase {$class} no puede ser instanciada."
                );
            }

            /*
            |--------------------------------------------------------------------------
            | El Container será incorporado aquí cuando registremos
            | dashboards independientes del Service principal.
            |--------------------------------------------------------------------------
            */

            throw new RuntimeException(
                "Dashboard {$nombre} requiere una instancia específica."
            );

        } catch (Throwable $e) {

            throw new RuntimeException(
                "Error cargando Dashboard {$nombre}: "
                . $e->getMessage(),
                0,
                $e
            );
        }
    }

    /**
     * =========================================================
     * EXISTE
     * =========================================================
     */
    public function existe(
        string $nombre
    ): bool {

        return isset(
            $this->dashboards[
                trim($nombre)
            ]
        );
    }

    /**
     * =========================================================
     * DISPONIBLES
     * =========================================================
     *
     * @return array<int,string>
     */
    public function disponibles(): array
    {
        return array_keys(
            $this->dashboards
        );
    }

    /**
     * =========================================================
     * ELIMINAR DASHBOARD
     * =========================================================
     */
    public function remove(
        string $nombre
    ): void {

        $nombre = trim($nombre);

        unset(
            $this->dashboards[$nombre],
            $this->instances[$nombre]
        );
    }

    /**
     * =========================================================
     * RESET
     * =========================================================
     */
    public function reset(): void
    {
        $this->dashboards = [];
        $this->instances  = [];

        $this->registerDefaults();
    }

    /**
     * =========================================================
     * DEBUG
     * =========================================================
     *
     * Permite comprobar rápidamente qué dashboards
     * están registrados y cuáles fueron instanciados.
     *
     * @return array<string,mixed>
     */
    public function debug(): array
    {
        return [
            'dashboards' =>
                $this->dashboards,

            'instancias' =>
                array_keys(
                    $this->instances
                ),

            'total_dashboards' =>
                count(
                    $this->dashboards
                ),

            'total_instancias' =>
                count(
                    $this->instances
                ),
        ];
    }
}