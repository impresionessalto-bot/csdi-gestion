<?php

declare(strict_types=1);

use App\Core\Router;
use App\Modules\Inventario\Controllers\Controller;

/*
|--------------------------------------------------------------------------
| ERP CSDI PRO
| MÓDULO INVENTARIO
| RUTAS V2 - BLINDADAS
|--------------------------------------------------------------------------
|
| Estructura del módulo:
|
| /inventario
|    ├── /nuevo
|    ├── /insumos
|    ├── /categorias
|    ├── /marcas
|    ├── /stock
|    ├── /movimientos
|    ├── /ajustes
|    └── /inventario
|
| APIs:
|
| /inventario/api/...
|
|--------------------------------------------------------------------------
*/

Router::group(
    '/inventario',
    [
        'auth',
    ],
    function (): void {

        /*
        |--------------------------------------------------------------------------
        | DASHBOARD
        |--------------------------------------------------------------------------
        */

        Router::get(
            '',
            [
                Controller::class,
                'index',
            ]
        );

        Router::get(
            '/',
            [
                Controller::class,
                'index',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | NUEVO PRODUCTO
        |--------------------------------------------------------------------------
        |
        | Ruta principal utilizada por el nuevo sidebar.
        |
        | /inventario/nuevo
        |
        */

        Router::get(
            '/nuevo',
            [
                Controller::class,
                'nuevo',
            ]
        );

        /*
        | Compatibilidad
        */

        Router::get(
            '/insumos/nuevo',
            [
                Controller::class,
                'nuevo',
            ]
        );

        Router::get(
            '/insumos/crear',
            [
                Controller::class,
                'nuevo',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | PRODUCTOS / INSUMOS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/insumos',
            [
                Controller::class,
                'insumos',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | EDITAR PRODUCTO
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/insumos/{id}/editar',
            [
                Controller::class,
                'editarInsumo',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | CATEGORÍAS
        |--------------------------------------------------------------------------
        |
        | Vista:
        |
        | Views/categorias.php
        |
        | URL:
        |
        | /inventario/categorias
        |
        */

        Router::get(
            '/categorias',
            [
                Controller::class,
                'categoriasView',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | MARCAS
        |--------------------------------------------------------------------------
        |
        | Vista:
        |
        | Views/marcas.php
        |
        | URL:
        |
        | /inventario/marcas
        |
        */

        Router::get(
            '/marcas',
            [
                Controller::class,
                'marcasView',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | STOCK POR DEPÓSITO
        |--------------------------------------------------------------------------
        |
        | Vista:
        |
        | Views/stock.php
        |
        | URL:
        |
        | /inventario/stock
        |
        */

        Router::get(
            '/stock',
            [
                Controller::class,
                'stockView',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | MOVIMIENTOS DE STOCK
        |--------------------------------------------------------------------------
        |
        | Vista:
        |
        | Views/movimientos.php
        |
        | URL:
        |
        | /inventario/movimientos
        |
        */

        Router::get(
            '/movimientos',
            [
                Controller::class,
                'movimientosView',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | AJUSTES DE STOCK
        |--------------------------------------------------------------------------
        |
        | Vista:
        |
        | Views/ajustes.php
        |
        | URL:
        |
        | /inventario/ajustes
        |
        */

        Router::get(
            '/ajustes',
            [
                Controller::class,
                'ajustesView',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | INVENTARIO FÍSICO
        |--------------------------------------------------------------------------
        |
        | Vista:
        |
        | Views/inventario.php
        |
        | URL:
        |
        | /inventario/inventario
        |
        */

        Router::get(
            '/inventario',
            [
                Controller::class,
                'inventarioView',
            ]
        );


        Router::get(
            '/unidades',
            [Controller::class, 'unidadesMedidaView']
        );

        Router::get(
            '/api/unidades',
            [Controller::class, 'listarUnidadesMedida']
        );

        Router::post(
            '/api/unidades',
            [Controller::class, 'crearUnidadMedida']
        );

        Router::post(
            '/api/unidades/{id}',
            [Controller::class, 'actualizarUnidadMedida']
        );

        Router::post(
            '/api/unidades/{id}/eliminar',
            [Controller::class, 'eliminarUnidadMedida']
        );

        /*
        |--------------------------------------------------------------------------
        | DEPÓSITOS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/depositos',
            [Controller::class, 'depositosView']
        );

        Router::get(
            '/api/depositos',
            [Controller::class, 'listarDepositos']
        );

        Router::post(
            '/api/depositos',
            [Controller::class, 'crearDeposito']
        );

        Router::post(
            '/api/depositos/{id}',
            [Controller::class, 'actualizarDeposito']
        );

        Router::post(
            '/api/depositos/{id}/eliminar',
            [Controller::class, 'eliminarDeposito']
        );


        /*
        |--------------------------------------------------------------------------
        | API - INSUMOS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/insumos',
            [
                Controller::class,
                'listar',
            ]
        );

        Router::get(
            '/api/insumos/buscar',
            [
                Controller::class,
                'buscar',
            ]
        );

        Router::get(
            '/api/insumos/{id}',
            [
                Controller::class,
                'obtener',
            ]
        );

        Router::post(
            '/api/insumos',
            [
                Controller::class,
                'crear',
            ]
        );

        Router::post(
            '/api/insumos/{id}',
            [
                Controller::class,
                'actualizar',
            ]
        );

        Router::post(
            '/api/insumos/{id}/eliminar',
            [
                Controller::class,
                'eliminar',
            ]
        );

        Router::post(
            '/api/insumos/{id}/activar',
            [
                Controller::class,
                'activar',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - CATEGORÍAS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/categorias',
            [
                Controller::class,
                'categorias',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - MARCAS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/marcas',
            [
                Controller::class,
                'marcas',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - MOVIMIENTOS
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/movimientos',
            [
                Controller::class,
                'listarMovimientos',
            ]
        );

        Router::get(
            '/api/movimientos/{id}',
            [
                Controller::class,
                'obtenerMovimiento',
            ]
        );

        Router::get(
            '/api/insumos/{id}/movimientos',
            [
                Controller::class,
                'movimientos',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - STOCK
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/stock/bajo',
            [
                Controller::class,
                'stockBajo',
            ]
        );

        Router::get(
            '/api/stock/sin',
            [
                Controller::class,
                'sinStock',
            ]
        );

        Router::get(
            '/api/stock/sobre',
            [
                Controller::class,
                'sobreStock',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - ENTRADAS
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/api/entrada',
            [
                Controller::class,
                'entrada',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - SALIDAS
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/api/salida',
            [
                Controller::class,
                'salida',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - AJUSTES
        |--------------------------------------------------------------------------
        */

        Router::post(
            '/api/ajustar',
            [
                Controller::class,
                'ajustar',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - INVENTARIO FÍSICO
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/inventario',
            [
                Controller::class,
                'inventario',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - CONSUMO POR SERVICIO
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/servicios/{servicioId}/consumo',
            [
                Controller::class,
                'consumoPorServicio',
            ]
        );


        /*
        |--------------------------------------------------------------------------
        | API - CONSUMO POR INSUMO
        |--------------------------------------------------------------------------
        */

        Router::get(
            '/api/insumos/{insumoId}/consumo',
            [
                Controller::class,
                'consumoPorInsumo',
            ]
        );
    }
);