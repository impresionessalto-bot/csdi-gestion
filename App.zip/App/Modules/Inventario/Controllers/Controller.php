<?php

declare(strict_types=1);

namespace App\Modules\Inventario\Controllers;

use App\Core\BaseController;
use App\Modules\Inventario\Services\Service;
use InvalidArgumentException;
use Throwable;

/**
 * ============================================================================
 * ERP CSDI PRO
 *
 * MÓDULO INVENTARIO
 * CONTROLLER PRINCIPAL
 * ============================================================================
 *
 * Responsabilidades:
 *
 * - Autenticación
 * - Recepción de requests
 * - Preparación de datos
 * - Renderizado de Views
 * - Respuestas JSON
 *
 * NO contiene:
 *
 * - SQL
 * - Reglas de negocio
 * - Consultas directas a BD
 *
 * Todo eso pertenece al Service / Repository.
 *
 * ============================================================================
 *
 * ESTRUCTURA DE VISTAS
 *
 * Views/
 * ├── index.php
 * ├── insumos.php
 * ├── categorias.php
 * ├── marcas.php
 * ├── stock.php
 * ├── movimientos.php
 * ├── ajustes.php
 * └── inventario.php
 *
 * ============================================================================
 *
 * SIDEBAR
 *
 * Inventario
 * ├── Listado de productos
 * ├── Nuevo producto
 * ├── Categorías
 * ├── Marcas
 * ├── Stock
 * ├── Movimientos
 * ├── Ajustes
 * └── Inventario
 *
 * ============================================================================
 */
final class Controller extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {

            $dashboard = $this->service->dashboard();

            $insumos = $this->service->listar([
                'activo' => 1,
            ]);

            /*
             * Compatibilidad defensiva.
             *
             * Si el Repository ya devuelve sin_stock,
             * lo utilizamos.
             *
             * Si no, lo calculamos desde los insumos.
             */

            $sinStock = $dashboard['sin_stock'] ?? [];

            if (!is_array($sinStock)) {
                $sinStock = [];
            }

            if (empty($sinStock)) {

                $sinStock = array_values(
                    array_filter(
                        $insumos,
                        static function (array $item): bool {
                            return (float) (
                                $item['stock_actual'] ?? 0
                            ) <= 0;
                        }
                    )
                );
            }

            $this->assets()->addModule('Inventario');

            $this->moduleView(
                'Inventario',
                'index',
                [
                    'titulo' => 'Inventario',

                    'csrf' => $this->csrf(),

                    'resumen' =>
                        is_array($dashboard['resumen'] ?? null)
                            ? $dashboard['resumen']
                            : [],

                    'insumos' =>
                        $insumos,

                    'stockBajo' =>
                        is_array($dashboard['stock_bajo'] ?? null)
                            ? $dashboard['stock_bajo']
                            : [],

                    'sinStock' =>
                        $sinStock,

                    'sobreStock' =>
                        is_array($dashboard['sobre_stock'] ?? null)
                            ? $dashboard['sobre_stock']
                            : [],

                    'movimientos' =>
                        is_array(
                            $dashboard['ultimos_movimientos'] ?? null
                        )
                            ? $dashboard['ultimos_movimientos']
                            : [],

                    'categorias' =>
                        is_array($dashboard['categorias'] ?? null)
                            ? $dashboard['categorias']
                            : [],

                    'estadisticasCategorias' =>
                        is_array(
                            $dashboard['estadisticas_categorias'] ?? null
                        )
                            ? $dashboard['estadisticas_categorias']
                            : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO DE INSUMOS / PRODUCTOS
    |--------------------------------------------------------------------------
    */

    public function insumos(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $insumos = $this->service->listar([
                'activo' => 1,
            ]);

            $categorias = $this->service->categorias();
            $unidades = $this->service->unidadesMedida();

            $this->moduleView(
                'Inventario',
                'insumos',
                [
                    'titulo' => 'Listado de productos',

                    'csrf' => $this->csrf(),

                    'insumos' => $insumos,

                    'categorias' =>
                        is_array($categorias) ? $categorias : [],

                    'unidades' =>
                        is_array($unidades) ? $unidades : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | NUEVO PRODUCTO
    |--------------------------------------------------------------------------
    */

    public function nuevo(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $categorias = $this->service->categorias();

            $this->moduleView(
                'Inventario',
                'form',
                [
                    'titulo' => 'Nuevo producto',

                    'csrf' => $this->csrf(),

                    'insumo' => null,

                    'categorias' =>
                        is_array($categorias)
                            ? $categorias
                            : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR INSUMO - COMPATIBILIDAD
    |--------------------------------------------------------------------------
    |
    | Conservamos crearInsumo() para que las rutas anteriores
    | sigan funcionando.
    |
    */

    public function crearInsumo(): void
    {
        $this->nuevo();
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR PRODUCTO
    |--------------------------------------------------------------------------
    */

    public function editarInsumo(int $id): void
    {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Producto inválido.'
                );
            }

            $insumo = $this->service->obtener($id);

            if (!$insumo) {

                $this->notFound(
                    'Producto no encontrado.'
                );
            }

            $this->assets()->addModule('Inventario');

            $categorias = $this->service->categorias();
            $unidades = $this->service->unidadesMedida();

            $this->moduleView(
                'Inventario',
                'form',
                [
                    'titulo' => 'Editar producto',

                    'csrf' => $this->csrf(),

                    'insumo' => $insumo,

                    'categorias' =>
                        is_array($categorias) ? $categorias : [],

                    'unidades' =>
                        is_array($unidades) ? $unidades : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CATEGORÍAS
    |--------------------------------------------------------------------------
    */

    public function categoriasView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $categorias = $this->service->categorias();

            $this->moduleView(
                'Inventario',
                'categorias',
                [
                    'titulo' => 'Categorías',

                    'csrf' => $this->csrf(),

                    'categorias' =>
                        is_array($categorias)
                            ? $categorias
                            : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MARCAS
    |--------------------------------------------------------------------------
    |
    | La estructura queda preparada para que Service/Repository
    | incorporen la gestión de marcas.
    |
    | Si el Service todavía no tiene marcas(), mostramos la vista
    | con un array vacío en lugar de provocar un fatal.
    |
    */

    public function marcasView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $marcas = [];

            if (method_exists($this->service, 'marcas')) {

                $resultado = $this->service->marcas();

                if (is_array($resultado)) {
                    $marcas = $resultado;
                }
            }

            $this->moduleView(
                'Inventario',
                'marcas',
                [
                    'titulo' => 'Marcas',

                    'csrf' => $this->csrf(),

                    'marcas' => $marcas,

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | STOCK
    |--------------------------------------------------------------------------
    */

    public function stockView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $insumos = $this->service->listar([
                'activo' => 1,
            ]);

            $stockBajo = $this->service->stockBajo();

            $sinStock = $this->service->sinStock();

            $sobreStock = $this->service->sobreStock();

            $this->moduleView(
                'Inventario',
                'stock',
                [
                    'titulo' => 'Stock',

                    'csrf' => $this->csrf(),

                    'insumos' => $insumos,

                    'stockBajo' =>
                        is_array($stockBajo)
                            ? $stockBajo
                            : [],

                    'sinStock' =>
                        is_array($sinStock)
                            ? $sinStock
                            : [],

                    'sobreStock' =>
                        is_array($sobreStock)
                            ? $sobreStock
                            : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | STOCK POR DEPÓSITO
    |--------------------------------------------------------------------------
    |
    | Se deja preparado para la futura implementación de depósitos.
    |
    */

    public function stockDepositosView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $insumos = $this->service->listar([
                'activo' => 1,
            ]);

            $this->moduleView(
                'Inventario',
                'stock',
                [
                    'titulo' => 'Stock por depósito',

                    'csrf' => $this->csrf(),

                    'insumos' => $insumos,

                    'stockBajo' =>
                        $this->service->stockBajo(),

                    'sinStock' =>
                        $this->service->sinStock(),

                    'sobreStock' =>
                        $this->service->sobreStock(),

                    /*
                     * Actualmente trabajamos con un depósito
                     * lógico/general.
                     *
                     * Cuando exista la tabla depósitos,
                     * esta variable será reemplazada por los
                     * datos reales.
                     */
                    'depositos' => [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MOVIMIENTOS
    |--------------------------------------------------------------------------
    */

    public function movimientosView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $movimientos =
                $this->service->listarMovimientos(
                    $_GET
                );

            $this->moduleView(
                'Inventario',
                'movimientos',
                [
                    'titulo' => 'Movimientos de stock',

                    'csrf' => $this->csrf(),

                    'movimientos' =>
                        is_array($movimientos)
                            ? $movimientos
                            : [],

                    'filtros' => $_GET,

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | AJUSTES
    |--------------------------------------------------------------------------
    */

    public function ajustesView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $insumos = $this->service->listar([
                'activo' => 1,
            ]);

            $this->moduleView(
                'Inventario',
                'ajustes',
                [
                    'titulo' => 'Ajustes de stock',

                    'csrf' => $this->csrf(),

                    'insumos' =>
                        is_array($insumos)
                            ? $insumos
                            : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | INVENTARIO FÍSICO
    |--------------------------------------------------------------------------
    */

    public function inventarioView(): void
    {
        $this->requireAuth();

        try {

            $this->assets()->addModule('Inventario');

            $insumos = $this->service->listar([
                'activo' => 1,
            ]);

            $this->moduleView(
                'Inventario',
                'inventario',
                [
                    'titulo' => 'Inventario físico',

                    'csrf' => $this->csrf(),

                    'insumos' =>
                        is_array($insumos)
                            ? $insumos
                            : [],

                    'error' => null,
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - LISTAR INSUMOS
    |--------------------------------------------------------------------------
    */

    public function listar(): void
    {
        $this->requireAuth();

        try {

            $data = $this->service->listar(
                $_GET
            );

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - BUSCAR
    |--------------------------------------------------------------------------
    */

    public function buscar(): void
    {
        $this->requireAuth();

        try {

            $termino = trim(
                (string) (
                    $_GET['q'] ?? ''
                )
            );

            $limit = max(
                1,
                min(
                    100,
                    (int) (
                        $_GET['limit'] ?? 20
                    )
                )
            );

            $data = $this->service->buscar(
                $termino,
                $limit
            );

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - OBTENER
    |--------------------------------------------------------------------------
    */

    public function obtener(int $id): void
    {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Producto inválido.'
                );
            }

            $insumo = $this->service->obtener($id);

            if (!$insumo) {

                $this->notFound(
                    'Producto no encontrado.'
                );
            }

            $this->json([
                'success' => true,

                'data' => $insumo,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - CREAR
    |--------------------------------------------------------------------------
    */

    public function crear(): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data = $this->requestData();

            $id = $this->service->crear(
                $data
            );

            $this->created(
                [
                    'id' => $id,
                ],
                'Producto creado correctamente.'
            );

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(int $id): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            if ($id <= 0) {

                throw new InvalidArgumentException(
                    'ID de producto inválido.'
                );
            }

            $data = $this->requestData();

            $ok = $this->service->actualizar(
                $id,
                $data
            );

            $this->json([
                'success' => $ok,

                'message' => $ok
                    ? 'Producto actualizado correctamente.'
                    : 'No se realizaron cambios.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(int $id): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            if ($id <= 0) {

                throw new InvalidArgumentException(
                    'ID de producto inválido.'
                );
            }

            $ok = $this->service->eliminar(
                $id
            );

            $this->json([
                'success' => $ok,

                'message' => $ok
                    ? 'Producto desactivado correctamente.'
                    : 'No se pudo desactivar el producto.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ACTIVAR
    |--------------------------------------------------------------------------
    */

    public function activar(int $id): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            if ($id <= 0) {

                throw new InvalidArgumentException(
                    'ID de producto inválido.'
                );
            }

            $ok = $this->service->activar(
                $id
            );

            $this->json([
                'success' => $ok,

                'message' => $ok
                    ? 'Producto activado correctamente.'
                    : 'No se pudo activar el producto.',
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - MOVIMIENTOS
    |--------------------------------------------------------------------------
    */

    public function listarMovimientos(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->listarMovimientos(
                    $_GET
                );

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - MOVIMIENTO INDIVIDUAL
    |--------------------------------------------------------------------------
    */

    public function obtenerMovimiento(int $id): void
    {
        $this->requireAuth();

        try {

            if ($id <= 0) {

                $this->notFound(
                    'Movimiento inválido.'
                );
            }

            $data =
                $this->service->obtenerMovimiento(
                    $id
                );

            if (!$data) {

                $this->notFound(
                    'Movimiento no encontrado.'
                );
            }

            $this->json([
                'success' => true,

                'data' => $data,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - MOVIMIENTOS DE INSUMO
    |--------------------------------------------------------------------------
    */

    public function movimientos(int $id): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->movimientos(
                    $id,
                    $_GET
                );

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - STOCK BAJO
    |--------------------------------------------------------------------------
    */

    public function stockBajo(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->stockBajo();

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - SIN STOCK
    |--------------------------------------------------------------------------
    */

    public function sinStock(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->sinStock();

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - SOBRE STOCK
    |--------------------------------------------------------------------------
    */

    public function sobreStock(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->sobreStock();

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - CATEGORÍAS
    |--------------------------------------------------------------------------
    */

    public function categorias(): void
    {
        $this->requireAuth();

        try {

            $data =
                $this->service->categorias();

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - ENTRADA
    |--------------------------------------------------------------------------
    */

    public function entrada(): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data = $this->requestData();

            $insumoId = (int) (
                $data['insumo_id'] ?? 0
            );

            $cantidad = (int) (
                $data['cantidad'] ?? 0
            );

            $costoUnitario = null;

            if (
                isset($data['costo_unitario'])
                && $data['costo_unitario'] !== ''
            ) {
                $costoUnitario =
                    (float) $data['costo_unitario'];
            }

            $resultado =
                $this->service->entrada(
                    $insumoId,
                    $cantidad,
                    $costoUnitario,
                    $this->userId(),
                    $data['observacion'] ?? null,
                    $data['comprobante'] ?? null
                );

            $this->json([
                'success' => true,

                'message' =>
                    'Entrada registrada correctamente.',

                'data' =>
                    is_array($resultado)
                        ? $resultado
                        : $resultado,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - SALIDA
    |--------------------------------------------------------------------------
    */

    public function salida(): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data = $this->requestData();

            $resultado =
                $this->service->salida(
                    (int) (
                        $data['insumo_id'] ?? 0
                    ),

                    (int) (
                        $data['cantidad'] ?? 0
                    ),

                    $this->userId(),

                    !empty($data['cliente_id'])
                        ? (int) $data['cliente_id']
                        : null,

                    !empty($data['equipo_id'])
                        ? (int) $data['equipo_id']
                        : null,

                    !empty($data['servicio_id'])
                        ? (int) $data['servicio_id']
                        : null,

                    $data['observacion'] ?? null,

                    $data['comprobante'] ?? null
                );

            $this->json([
                'success' => true,

                'message' =>
                    'Salida registrada correctamente.',

                'data' =>
                    is_array($resultado)
                        ? $resultado
                        : $resultado,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - AJUSTAR STOCK
    |--------------------------------------------------------------------------
    */

    public function ajustar(): void
    {
        $this->requireAuth();

        try {

            $this->requireCsrfForMutation();

            $data = $this->requestData();

            $insumoId = (int) (
                $data['insumo_id'] ?? 0
            );

            $cantidad = (int) (
                $data['cantidad'] ?? 0
            );

            $resultado =
                $this->service->ajustar(
                    $insumoId,
                    $cantidad,
                    $this->userId(),
                    $data['observacion'] ?? null
                );

            $this->json([
                'success' => true,

                'message' =>
                    'Ajuste registrado correctamente.',

                'data' =>
                    is_array($resultado)
                        ? $resultado
                        : $resultado,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - CONSUMO POR SERVICIO
    |--------------------------------------------------------------------------
    */

    public function consumoPorServicio(
        int $servicioId
    ): void {
        $this->requireAuth();

        try {

            $data =
                $this->service->consumoPorServicio(
                    $servicioId
                );

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | API - CONSUMO POR INSUMO
    |--------------------------------------------------------------------------
    */

    public function consumoPorInsumo(
        int $insumoId
    ): void {
        $this->requireAuth();

        try {

            $data =
                $this->service->consumoPorInsumo(
                    $insumoId
                );

            $this->json([
                'success' => true,

                'data' =>
                    is_array($data)
                        ? $data
                        : [],

                'total' =>
                    is_array($data)
                        ? count($data)
                        : 0,
            ]);

        } catch (Throwable $e) {

            $this->jsonError($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | REQUEST DATA
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | DEPÓSITOS
    |--------------------------------------------------------------------------
    */

    public function depositosView(): void
    {
        $this->requireAuth();
        try {
            $this->assets()->addModule('Inventario');
            $this->moduleView('Inventario', 'depositos', [
                'titulo' => 'Depósitos',
                'csrf' => $this->csrf(),
                'depositos' => $this->service->depositos(false),
                'error' => null,
            ]);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function listarDepositos(): void
    {
        $this->requireAuth();
        try {
            $data = $this->service->depositos(false);
            $this->json(['success' => true, 'data' => $data, 'total' => count($data)]);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    public function crearDeposito(): void
    {
        $this->requireAuth();
        try {
            $this->requireCsrfForMutation();
            $id = $this->service->crearDeposito($this->requestData());
            $this->json(['success' => true, 'id' => $id, 'message' => 'Depósito creado correctamente.'], 201);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    public function actualizarDeposito(int $id): void
    {
        $this->requireAuth();
        try {
            $this->requireCsrfForMutation();
            $this->service->actualizarDeposito($id, $this->requestData());
            $this->json(['success' => true, 'message' => 'Depósito actualizado correctamente.']);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    public function eliminarDeposito(int $id): void
    {
        $this->requireAuth();
        try {
            $this->requireCsrfForMutation();
            $this->service->eliminarDeposito($id);
            $this->json(['success' => true, 'message' => 'Depósito desactivado correctamente.']);
        } catch (Throwable $e) {
            $this->jsonError($e);
        }
    }

    private function requestData(): array
    {
        $contentType =
            (string) (
                $_SERVER['CONTENT_TYPE']
                ?? $_SERVER['HTTP_CONTENT_TYPE']
                ?? ''
            );

        if (
            str_contains(
                strtolower($contentType),
                'application/json'
            )
        ) {

            $raw =
                file_get_contents(
                    'php://input'
                );

            if (
                $raw === false
                || trim($raw) === ''
            ) {
                return [];
            }

            $data =
                json_decode(
                    $raw,
                    true
                );

            return is_array($data)
                ? $data
                : [];
        }

        return is_array($_POST)
            ? $_POST
            : [];
    }

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    private function requireCsrfForMutation(): void
    {
        if (!$this->validateCsrf()) {

            throw new InvalidArgumentException(
                'Token CSRF inválido o ausente.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | JSON ERROR
    |--------------------------------------------------------------------------
    */

    private function jsonError(
        Throwable $e
    ): never {

        $status = 400;

        if (
            $e instanceof InvalidArgumentException
        ) {
            $status = 422;
        }

        $errors = [];

        if (
            defined('APP_DEBUG')
            && APP_DEBUG
        ) {

            $errors = [
                'exception' =>
                    get_class($e),

                'file' =>
                    $e->getFile(),

                'line' =>
                    $e->getLine(),
            ];
        }

        $this->json(
            [
                'success' => false,

                'message' =>
                    $e->getMessage(),

                'errors' =>
                    $errors,
            ],
            $status
        );
    }
}