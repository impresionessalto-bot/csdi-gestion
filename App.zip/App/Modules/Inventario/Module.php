<?php

declare(strict_types=1);

namespace App\Modules\Inventario;

use App\Core\Module as BaseModule;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * MÓDULO INVENTARIO
 *
 * Productos / Stock
 *
 * Estructura funcional:
 *
 *   Productos / Stock
 *       │
 *       ├── Listado de productos
 *       ├── Nuevo producto
 *       ├── Categorías
 *       ├── Marcas
 *       ├── Stock por depósito
 *       ├── Movimientos de stock
 *       ├── Ajustes de stock
 *       └── Inventario
 *
 * =========================================================
 */
final class Module extends BaseModule
{
    /**
     * Nombre del módulo.
     */
    public function name(): string
    {
        return 'Inventario';
    }

    /**
     * Prioridad de carga.
     */
    public function priority(): int
    {
        return 60;
    }

    /**
     * Archivo de rutas.
     */
    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    /**
     * =========================================================
     * MENÚ
     * =========================================================
     *
     * El sidebar nuevo utiliza este módulo como origen
     * de las opciones de Productos / Stock.
     */
    public function menu(): array
    {
        return [

            /*
            |--------------------------------------------------------------------------
            | PRODUCTOS / STOCK
            |--------------------------------------------------------------------------
            */

            [
                'title'      => 'Productos / Stock',
                'url'        => '/inventario',
                'icon'       => 'fa-solid fa-boxes-stacked',
                'permission' => 'inventario.view',
                'order'      => 60,

                /*
                |--------------------------------------------------------------------------
                | SUBMENÚ
                |--------------------------------------------------------------------------
                */

                'children' => [

                    /*
                    |--------------------------------------------------------------------------
                    | PRODUCTOS
                    |--------------------------------------------------------------------------
                    */

                    [
                        'title'      => 'Listado de productos',
                        'url'        => '/inventario/insumos',
                        'icon'       => 'fa-solid fa-box',
                        'permission' => 'inventario.view',
                        'order'      => 1,
                    ],

                    [
                        'title'      => 'Nuevo producto',
                        'url'        => '/inventario/insumos/crear',
                        'icon'       => 'fa-solid fa-plus',
                        'permission' => 'inventario.create',
                        'order'      => 2,
                    ],

                    /*
                    |--------------------------------------------------------------------------
                    | CLASIFICACIÓN
                    |--------------------------------------------------------------------------
                    */

                    [
                        'title'      => 'Categorías',
                        'url'        => '/inventario/categorias',
                        'icon'       => 'fa-solid fa-layer-group',
                        'permission' => 'inventario.view',
                        'order'      => 10,
                    ],

                    [
                        'title'      => 'Marcas',
                        'url'        => '/inventario/marcas',
                        'icon'       => 'fa-solid fa-tags',
                        'permission' => 'inventario.view',
                        'order'      => 11,
                    ],

                    [
                        'title'      => 'Unidades de medida',
                        'url'        => '/inventario/unidades',
                        'icon'       => 'fa-solid fa-ruler-combined',
                        'permission' => 'inventario.units',
                        'order'      => 12,
                    ],

                    [
                        'title'      => 'Depósitos',
                        'url'        => '/inventario/depositos',
                        'icon'       => 'fa-solid fa-warehouse',
                        'permission' => 'inventario.deposits',
                        'order'      => 13,
                    ],

                    /*
                    |--------------------------------------------------------------------------
                    | STOCK
                    |--------------------------------------------------------------------------
                    */

                    [
                        'title'      => 'Stock por depósito',
                        'url'        => '/inventario/stock',
                        'icon'       => 'fa-solid fa-warehouse',
                        'permission' => 'inventario.view',
                        'order'      => 20,
                    ],

                    [
                        'title'      => 'Movimientos de stock',
                        'url'        => '/inventario/movimientos',
                        'icon'       => 'fa-solid fa-arrow-right-arrow-left',
                        'permission' => 'inventario.movements',
                        'order'      => 21,
                    ],

                    [
                        'title'      => 'Ajustes de stock',
                        'url'        => '/inventario/ajustes',
                        'icon'       => 'fa-solid fa-sliders',
                        'permission' => 'inventario.edit',
                        'order'      => 22,
                    ],

                    /*
                    |--------------------------------------------------------------------------
                    | INVENTARIO FÍSICO
                    |--------------------------------------------------------------------------
                    */

                    [
                        'title'      => 'Inventario',
                        'url'        => '/inventario/inventario',
                        'icon'       => 'fa-solid fa-clipboard-check',
                        'permission' => 'inventario.view',
                        'order'      => 30,
                    ],
                ],
            ],
        ];
    }

    /**
     * =========================================================
     * PERMISOS
     * =========================================================
     */
    public function permissions(): array
    {
        return [

            /*
            |--------------------------------------------------------------------------
            | PRODUCTOS
            |--------------------------------------------------------------------------
            */

            'inventario.view',
            'inventario.create',
            'inventario.edit',
            'inventario.delete',

            /*
            |--------------------------------------------------------------------------
            | STOCK
            |--------------------------------------------------------------------------
            */

            'inventario.movements',

            /*
            |--------------------------------------------------------------------------
            | CLASIFICACIÓN
            |--------------------------------------------------------------------------
            */

            'inventario.categories',
            'inventario.brands',
            'inventario.units',

            /*
            |--------------------------------------------------------------------------
            | DEPÓSITOS
            |--------------------------------------------------------------------------
            */

            'inventario.deposits',

            /*
            |--------------------------------------------------------------------------
            | AJUSTES
            |--------------------------------------------------------------------------
            */

            'inventario.adjust',

            /*
            |--------------------------------------------------------------------------
            | INVENTARIO FÍSICO
            |--------------------------------------------------------------------------
            */

            'inventario.count',
        ];
    }

    /**
     * =========================================================
     * BOOT
     * =========================================================
     */
    public function boot(): void
    {
        /*
         * No requiere bootstrap adicional.
         *
         * La lógica pertenece al Controller / Service /
         * Repository.
         */
    }
}