<?php
$insumos = $insumos ?? [];
$categorias = $categorias ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                Productos
            </h1>

            <div class="text-muted">
                Listado y administración de productos.
            </div>
        </div>

        <div class="d-flex gap-2">

            <a href="/inventario"
               class="btn btn-outline-secondary">
                <i class="fa-solid fa-arrow-left me-1"></i>
                Inventario
            </a>

            <a href="/inventario/insumos/crear"
               class="btn btn-primary">
                <i class="fa-solid fa-plus me-1"></i>
                Nuevo producto
            </a>

        </div>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white py-3">

            <div class="row g-2">

                <div class="col-md-6">

                    <div class="input-group">

                        <span class="input-group-text bg-white">
                            <i class="fa-solid fa-search"></i>
                        </span>

                        <input
                            type="search"
                            id="buscarProducto"
                            class="form-control"
                            placeholder="Buscar producto, código o SKU..."
                        >

                    </div>

                </div>

                <div class="col-md-3">

                    <select id="filtroCategoria"
                            class="form-select">

                        <option value="">
                            Todas las categorías
                        </option>

                        <?php foreach ($categorias as $categoria): ?>

                            <option value="<?= (int)(
                                $categoria['id'] ?? 0
                            ) ?>">
                                <?= htmlspecialchars(
                                    (string)(
                                        $categoria['nombre']
                                        ?? $categoria['descripcion']
                                        ?? 'Categoría'
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="col-md-3">

                    <select id="filtroEstado"
                            class="form-select">

                        <option value="">
                            Todos
                        </option>

                        <option value="1">
                            Activos
                        </option>

                        <option value="0">
                            Inactivos
                        </option>

                    </select>

                </div>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (empty($insumos)): ?>

                <div class="text-center py-5 text-muted">

                    <i class="fa-solid fa-box-open fs-1 d-block mb-3"></i>

                    <div class="fw-semibold">
                        No hay productos registrados.
                    </div>

                    <a href="/inventario/insumos/crear"
                       class="btn btn-primary btn-sm mt-3">
                        Crear producto
                    </a>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0"
                           id="tablaProductos">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-4">
                                    Código
                                </th>

                                <th>
                                    Producto
                                </th>

                                <th>
                                    Categoría
                                </th>

                                <th class="text-end">
                                    Costo
                                </th>

                                <th class="text-end">
                                    Venta
                                </th>

                                <th class="text-end">
                                    Stock
                                </th>

                                <th>
                                    Estado
                                </th>

                                <th class="text-end pe-4">
                                    Acción
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($insumos as $item): ?>

                            <?php
                            $id = (int)($item['id'] ?? 0);

                            $codigo = $item['codigo']
                                ?? $item['sku']
                                ?? '-';

                            $nombre = $item['nombre']
                                ?? $item['descripcion']
                                ?? 'Producto';

                            $categoria = $item['categoria_nombre']
                                ?? $item['categoria']
                                ?? '-';

                            $costo = (float)(
                                $item['costo']
                                ?? $item['precio_costo']
                                ?? 0
                            );

                            $venta = (float)(
                                $item['precio_venta']
                                ?? $item['precio']
                                ?? 0
                            );

                            $stock = (float)(
                                $item['stock_actual']
                                ?? $item['stock']
                                ?? 0
                            );

                            $activo = (int)(
                                $item['activo']
                                ?? 1
                            );
                            ?>

                            <tr>

                                <td class="ps-4 fw-semibold">
                                    <?= htmlspecialchars(
                                        (string)$codigo,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        (string)$nombre,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        (string)$categoria,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td class="text-end">
                                    $ <?= number_format(
                                        $costo,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                                <td class="text-end fw-semibold">
                                    $ <?= number_format(
                                        $venta,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                                <td class="text-end">

                                    <?php if ($stock <= 0): ?>

                                        <span class="text-danger fw-semibold">
                                            <?= number_format(
                                                $stock,
                                                2,
                                                ',',
                                                '.'
                                            ) ?>
                                        </span>

                                    <?php else: ?>

                                        <?= number_format(
                                            $stock,
                                            2,
                                            ',',
                                            '.'
                                        ) ?>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if ($activo): ?>

                                        <span class="badge bg-success-subtle text-success">
                                            Activo
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-secondary-subtle text-secondary">
                                            Inactivo
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td class="text-end pe-4">

                                    <?php if ($id > 0): ?>

                                        <a
                                            href="/inventario/insumos/<?= $id ?>/editar"
                                            class="btn btn-sm btn-outline-primary"
                                            title="Editar"
                                        >
                                            <i class="fa-solid fa-pen"></i>
                                        </a>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const input = document.getElementById('buscarProducto');

    if (!input) {
        return;
    }

    input.addEventListener('input', function () {

        const value = this.value.toLowerCase().trim();

        document
            .querySelectorAll('#tablaProductos tbody tr')
            .forEach(function (row) {

                row.style.display =
                    row.innerText
                        .toLowerCase()
                        .includes(value)
                        ? ''
                        : 'none';

            });

    });

});

</script>