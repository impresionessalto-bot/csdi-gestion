<?php

declare(strict_types=1);

$insumos = $insumos ?? [];
$resumen = $resumen ?? [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('money')) {
    function money(float|int|string|null $value): string
    {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            2,
            ',',
            '.'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-boxes me-2"></i>

                Control de stock

            </h1>

            <p class="text-muted mb-0">

                Existencias, niveles mínimos y valorización.

            </p>

        </div>


        <a
            href="/inventario"
            class="btn btn-outline-secondary"
        >

            <i class="bi bi-arrow-left me-1"></i>

            Inventario

        </a>

    </div>


    <!-- RESUMEN -->

    <div class="row g-3 mb-4">

        <div class="col-md-3">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="text-muted small">
                        Unidades
                    </div>

                    <div class="fs-3 fw-bold">

                        <?= number_format(
                            (int) (
                                $resumen['unidades'] ?? 0
                            ),
                            0,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="text-muted small">
                        Stock bajo
                    </div>

                    <div class="fs-3 fw-bold text-warning">

                        <?= number_format(
                            (int) (
                                $resumen['stock_bajo'] ?? 0
                            ),
                            0,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="text-muted small">
                        Sin stock
                    </div>

                    <div class="fs-3 fw-bold text-danger">

                        <?= number_format(
                            (int) (
                                $resumen['sin_stock'] ?? 0
                            ),
                            0,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="text-muted small">
                        Valor stock
                    </div>

                    <div class="fs-4 fw-bold">

                        <?= money(
                            $resumen['valor_stock'] ?? 0
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- TABLA -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-white py-3">

            <strong>

                <i class="bi bi-stack me-2"></i>

                Existencias actuales

            </strong>

        </div>


        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover align-middle mb-0">

                    <thead class="table-light">

                        <tr>

                            <th class="ps-3">
                                Insumo
                            </th>

                            <th>
                                Código
                            </th>

                            <th class="text-center">
                                Stock
                            </th>

                            <th class="text-center">
                                Mínimo
                            </th>

                            <th class="text-center">
                                Máximo
                            </th>

                            <th class="text-end">
                                Costo
                            </th>

                            <th class="text-end">
                                Valorización
                            </th>

                            <th class="text-end pe-3">
                                Acción
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php if (!$insumos): ?>

                        <tr>

                            <td
                                colspan="8"
                                class="text-center text-muted py-5"
                            >

                                No hay información de stock.

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($insumos as $item): ?>

                            <?php

                            $id = (int) (
                                $item['id'] ?? 0
                            );

                            $stock = (int) (
                                $item['stock_actual'] ?? 0
                            );

                            $minimo = (int) (
                                $item['stock_minimo'] ?? 0
                            );

                            $maximo =
                                $item['stock_maximo']
                                ?? null;

                            $costo = (float) (
                                $item['precio_costo']
                                ?? $item['costo_compra']
                                ?? 0
                            );

                            $valor =
                                $stock * $costo;

                            ?>

                            <tr>

                                <td class="ps-3">

                                    <strong>

                                        <?= e(
                                            $item['nombre_insumo']
                                                ?? ''
                                        ) ?>

                                    </strong>

                                </td>


                                <td>

                                    <?= e(
                                        $item['codigo_parte']
                                            ?? ''
                                    ) ?>

                                </td>


                                <td class="text-center">

                                    <?php if ($stock <= 0): ?>

                                        <span class="badge text-bg-danger">

                                            <?= $stock ?>

                                        </span>

                                    <?php elseif (
                                        $minimo > 0
                                        && $stock <= $minimo
                                    ): ?>

                                        <span class="badge text-bg-warning">

                                            <?= $stock ?>

                                        </span>

                                    <?php else: ?>

                                        <span class="badge text-bg-success">

                                            <?= $stock ?>

                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td class="text-center">

                                    <?= number_format(
                                        $minimo,
                                        0,
                                        ',',
                                        '.'
                                    ) ?>

                                </td>


                                <td class="text-center">

                                    <?= $maximo !== null
                                        ? number_format(
                                            (int) $maximo,
                                            0,
                                            ',',
                                            '.'
                                        )
                                        : '-'
                                    ?>

                                </td>


                                <td class="text-end">

                                    <?= money($costo) ?>

                                </td>


                                <td class="text-end fw-semibold">

                                    <?= money($valor) ?>

                                </td>


                                <td class="text-end pe-3">

                                    <a
                                        href="/inventario/movimientos/<?= $id ?>"
                                        class="btn btn-sm btn-outline-secondary"
                                    >

                                        <i class="bi bi-clock-history"></i>

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>