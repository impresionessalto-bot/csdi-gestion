<?php
$insumos = $insumos ?? [];
$stockBajo = $stockBajo ?? [];
$sinStock = $sinStock ?? [];
$sobreStock = $sobreStock ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">
                Stock por depósito
            </h1>

            <div class="text-muted">
                Consulta de existencias y alertas de inventario.
            </div>

        </div>

        <a href="/inventario"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Inventario
        </a>

    </div>


    <!-- ALERTAS -->

    <div class="row g-3 mb-4">

        <div class="col-md-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="text-warning small">
                        Stock bajo
                    </div>

                    <div class="fs-3 fw-bold">
                        <?= number_format(
                            count($stockBajo),
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="text-danger small">
                        Sin stock
                    </div>

                    <div class="fs-3 fw-bold">
                        <?= number_format(
                            count($sinStock),
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="text-success small">
                        Sobre stock
                    </div>

                    <div class="fs-3 fw-bold">
                        <?= number_format(
                            count($sobreStock),
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white py-3">

            <div class="input-group">

                <span class="input-group-text bg-white">
                    <i class="fa-solid fa-search"></i>
                </span>

                <input
                    type="search"
                    id="buscarStock"
                    class="form-control"
                    placeholder="Buscar producto..."
                >

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (empty($insumos)): ?>

                <div class="text-center py-5 text-muted">
                    No hay información de stock.
                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0"
                           id="tablaStock">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-4">
                                    Código
                                </th>

                                <th>
                                    Producto
                                </th>

                                <th>
                                    Depósito
                                </th>

                                <th class="text-end">
                                    Stock
                                </th>

                                <th class="text-end">
                                    Mínimo
                                </th>

                                <th>
                                    Estado
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($insumos as $item): ?>

                            <?php
                            $stock = (float)(
                                $item['stock_actual']
                                ?? $item['stock']
                                ?? 0
                            );

                            $minimo = (float)(
                                $item['stock_minimo']
                                ?? 0
                            );

                            // Campos reales de la tabla insumos.
                            $codigo = trim((string) (
                                $item['codigo_parte']
                                ?? ''
                            ));

                            if ($codigo === '') {
                                $codigo = trim((string) (
                                    $item['codigo_barras']
                                    ?? ''
                                ));
                            }

                            // Registros antiguos sin código: mostramos el
                            // mismo código determinístico que genera el backend.
                            if ($codigo === '') {
                                $idProducto = (int)($item['id'] ?? 0);
                                $codigo = $idProducto > 0
                                    ? 'INS-' . str_pad((string)$idProducto, 6, '0', STR_PAD_LEFT)
                                    : 'SIN-CODIGO';
                            }

                            $nombre = trim((string) (
                                $item['nombre_insumo']
                                ?? ''
                            ));

                            if ($nombre === '') {
                                $nombre = 'Sin nombre';
                            }

                            // Actualmente insumos.stock_actual es stock global.
                            // No existe todavía una relación real con depósitos.
                            $deposito = trim((string) (
                                $item['deposito_nombre']
                                ?? $item['deposito']
                                ?? ''
                            ));

                            if ($deposito === '') {
                                $deposito = 'Depósito general';
                            }
                            ?>

                            <tr>

                                <td class="ps-4">
                                    <?= htmlspecialchars(
                                        (string)$codigo,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td class="fw-semibold">
                                    <?= htmlspecialchars(
                                        (string)$nombre,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        (string)$deposito,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td class="text-end fw-bold">
                                    <?= number_format(
                                        $stock,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                                <td class="text-end">
                                    <?= number_format(
                                        $minimo,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                                <td>

                                    <?php if ($stock <= 0): ?>

                                        <span class="badge bg-danger-subtle text-danger">
                                            Sin stock
                                        </span>

                                    <?php elseif ($minimo > 0 && $stock <= $minimo): ?>

                                        <span class="badge bg-warning-subtle text-warning-emphasis">
                                            Stock bajo
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-success-subtle text-success">
                                            Normal
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const input = document.getElementById('buscarStock');

    if (!input) {
        return;
    }

    input.addEventListener('input', function () {

        const value = this.value.toLowerCase().trim();

        document
            .querySelectorAll('#tablaStock tbody tr')
            .forEach(function (row) {

                row.style.display =
                    row.innerText
                        .toLowerCase()
                        .includes(value)
                        ? ''
                        : 'none';

            });

    });

});

</script>