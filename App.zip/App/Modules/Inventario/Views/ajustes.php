<?php
$insumos = $insumos ?? [];
$csrf = $csrf ?? '';
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">
                Ajustes de stock
            </h1>

            <div class="text-muted">
                Corrección manual de existencias.
            </div>

        </div>

        <a href="/inventario"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Inventario
        </a>

    </div>


    <div class="row g-4">

        <div class="col-lg-7">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="fw-bold mb-0">
                        Registrar ajuste
                    </h5>

                </div>

                <div class="card-body">

                    <form
                        method="post"
                        action="/inventario/api/ajustar"
                    >

                        <input
                            type="hidden"
                            name="_csrf"
                            value="<?= htmlspecialchars(
                                (string)$csrf,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >


                        <div class="mb-3">

                            <label class="form-label">
                                Producto
                                <span class="text-danger">*</span>
                            </label>

                            <select
                                name="insumo_id"
                                class="form-select"
                                required
                            >

                                <option value="">
                                    Seleccionar producto...
                                </option>

                                <?php foreach ($insumos as $insumo): ?>

                                    <option
                                        value="<?= (int)(
                                            $insumo['id'] ?? 0
                                        ) ?>"
                                    >

                                        <?= htmlspecialchars(
                                            (string)(
                                                $insumo['nombre']
                                                ?? $insumo['descripcion']
                                                ?? 'Producto'
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                        — Stock:
                                        <?= number_format(
                                            (float)(
                                                $insumo['stock_actual']
                                                ?? $insumo['stock']
                                                ?? 0
                                            ),
                                            2,
                                            ',',
                                            '.'
                                        ) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                Cantidad
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="number"
                                name="cantidad"
                                class="form-control"
                                step="0.01"
                                required
                                placeholder="Ej: 5 o -5"
                            >

                            <div class="form-text">
                                Utilizá un valor positivo para aumentar el stock
                                o negativo para disminuirlo.
                            </div>

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                Motivo
                            </label>

                            <select
                                name="motivo"
                                class="form-select"
                            >

                                <option value="CONTEO">
                                    Diferencia de conteo
                                </option>

                                <option value="ROTURA">
                                    Rotura
                                </option>

                                <option value="PERDIDA">
                                    Pérdida
                                </option>

                                <option value="SOBRANTE">
                                    Sobrante
                                </option>

                                <option value="CORRECCION">
                                    Corrección
                                </option>

                                <option value="OTRO">
                                    Otro
                                </option>

                            </select>

                        </div>


                        <div class="mb-4">

                            <label class="form-label">
                                Observación
                            </label>

                            <textarea
                                name="observacion"
                                class="form-control"
                                rows="4"
                                placeholder="Detalle del ajuste..."
                            ></textarea>

                        </div>


                        <button
                            type="submit"
                            class="btn btn-primary"
                        >
                            <i class="fa-solid fa-check me-1"></i>
                            Registrar ajuste
                        </button>

                    </form>

                </div>

            </div>

        </div>


        <div class="col-lg-5">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="text-warning fs-2 mb-3">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>

                    <h5 class="fw-bold">
                        Importante
                    </h5>

                    <p class="text-muted small">
                        Los ajustes modifican directamente la existencia
                        registrada y quedan asentados en el historial de
                        movimientos.
                    </p>

                    <hr>

                    <div class="small text-muted">

                        <div class="mb-2">
                            <strong>Positivo:</strong>
                            aumenta el stock.
                        </div>

                        <div class="mb-2">
                            <strong>Negativo:</strong>
                            reduce el stock.
                        </div>

                        <div>
                            <strong>Auditoría:</strong>
                            queda registrado usuario, fecha y motivo.
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>