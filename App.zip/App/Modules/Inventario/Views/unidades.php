<?php
declare(strict_types=1);
$csrf = $csrf ?? '';
$unidades = $unidades ?? [];
if (!function_exists('e')) { function e(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }
?>
<div class="container-fluid py-4">
 <div class="d-flex justify-content-between align-items-center mb-4">
  <div><h1 class="h3 fw-bold mb-1"><i class="bi bi-rulers me-2"></i>Unidades de medida</h1><p class="text-muted mb-0">Configurá las unidades utilizadas por los insumos y si admiten cantidades decimales.</p></div>
  <a href="/inventario/insumos" class="btn btn-outline-secondary">Volver a productos</a>
 </div>
 <div class="row g-4">
  <div class="col-12 col-lg-5">
   <div class="card shadow-sm border-0"><div class="card-header bg-white py-3"><strong>Nueva unidad</strong></div><div class="card-body">
    <form id="formUnidad">
     <input type="hidden" name="_csrf" value="<?= e($csrf) ?>">
     <div class="mb-3"><label class="form-label">Nombre</label><input class="form-control" name="nombre" maxlength="50" required placeholder="Kilogramo"></div>
     <div class="mb-3"><label class="form-label">Abreviatura</label><input class="form-control" name="abreviatura" maxlength="10" required placeholder="kg"></div>
     <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="permite_decimales" value="1" id="permiteDecimales"><label class="form-check-label" for="permiteDecimales">Permite cantidades decimales</label></div>
     <button class="btn btn-primary" type="submit">Guardar unidad</button>
    </form>
   </div></div>
  </div>
  <div class="col-12 col-lg-7">
   <div class="card shadow-sm border-0"><div class="card-header bg-white py-3"><strong>Unidades configuradas</strong></div><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Nombre</th><th>Abrev.</th><th>Decimales</th><th>Estado</th><th></th></tr></thead><tbody>
   <?php foreach ($unidades as $u): ?>
    <tr><td><?= e($u['nombre']) ?></td><td><code><?= e($u['abreviatura']) ?></code></td><td><?= !empty($u['permite_decimales']) ? '<span class="badge text-bg-success">Sí</span>' : '<span class="badge text-bg-secondary">No</span>' ?></td><td><?= !empty($u['activo']) ? '<span class="badge text-bg-success">Activa</span>' : '<span class="badge text-bg-secondary">Inactiva</span>' ?></td><td class="text-end"><?php if (!empty($u['activo'])): ?><button class="btn btn-sm btn-outline-danger" onclick="desactivarUnidad(<?= (int)$u['id'] ?>)">Desactivar</button><?php endif; ?></td></tr>
   <?php endforeach; ?>
   </tbody></table></div></div>
  </div>
 </div>
</div>
<script>
const csrf = <?= json_encode($csrf) ?>;
document.getElementById('formUnidad')?.addEventListener('submit', async e => { e.preventDefault(); const fd=new FormData(e.currentTarget); try { const r=await fetch('/inventario/api/unidades',{method:'POST',headers:{'X-CSRF-TOKEN':csrf},body:fd}); const j=await r.json(); if(!j.success) throw new Error(j.message||'No se pudo guardar'); location.reload(); } catch(err){ alert(err.message); } });
async function desactivarUnidad(id){ if(!confirm('¿Desactivar esta unidad?')) return; const fd=new FormData(); fd.append('_csrf',csrf); const r=await fetch('/inventario/api/unidades/'+id+'/eliminar',{method:'POST',headers:{'X-CSRF-TOKEN':csrf},body:fd}); const j=await r.json(); if(!j.success){alert(j.message||'No se pudo desactivar');return;} location.reload(); }
</script>
