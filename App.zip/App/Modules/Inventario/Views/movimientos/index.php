<?php

declare(strict_types=1);

$movimientos = $movimientos ?? [];
$insumo      = $insumo ?? null;
$csrf        = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-clock-history me-2"></i>

                Movimientos de inventario

            </h1>

            <p class="text-muted mb-0">

                Trazabilidad completa de entradas, salidas y ajustes.

            </p>

        </div>


        <div class="d-flex gap-2">

            <a
                href="/inventario"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Inventario
            </a>

            <a
                href="/inventario/entrada"
                class="btn btn-success"
            >
                <i class="bi bi-box-arrow-in-down me-1"></i>
                Entrada
            </a>

            <a
                href="/inventario/salida"
                class="btn btn-danger"
            >
                <i class="bi bi-box-arrow-up me-1"></i>
                Salida
            </a>

        </div>

    </div>


    <?php if ($insumo): ?>

        <div class="alert alert-light border mb-4">

            <strong>
                <?= e(
                    $insumo['nombre_insumo'] ?? ''
                ) ?>
            </strong>

            <?php if (!empty($insumo['codigo_parte'])): ?>

                <span class="text-muted ms-2">

                    <?= e(
                        $insumo['codigo_parte']
                    ) ?>

                </span>

            <?php endif; ?>

        </div>

    <?php endif; ?>


    <!-- FILTROS -->

    <div class="card shadow-sm border-0 mb-4">

        <div class="card-body">

            <form
                method="get"
                class="row g-3"
            >

                <div class="col-md-3">

                    <label class="form-label">
                        Tipo
                    </label>

                    <select
                        name="tipo"
                        class="form-select"
                    >

                        <option value="">
                            Todos
                        </option>

                        <option value="ENTRADA">
                            Entradas
                        </option>

                        <option value="SALIDA">
                            Salidas
                        </option>

                        <option value="AJUSTE">
                            Ajustes
                        </option>

                    </select>

                </div>


                <div class="col-md-3">

                    <label class="form-label">
                        Desde
                    </label>

                    <input
                        type="date"
                        name="desde"
                        class="form-control"
                        value="<?= e(
                            $_GET['desde'] ?? ''
                        ) ?>"
                    >

                </div>


                <div class="col-md-3">

                    <label class="form-label">
                        Hasta
                    </label>

                    <input
                        type="date"
                        name="hasta"
                        class="form-control"
                        value="<?= e(
                            $_GET['hasta'] ?? ''
                        ) ?>"
                    >

                </div>


                <div class="col-md-3 d-flex align-items-end">

                    <button
                        type="submit"
                        class="btn btn-primary w-100"
                    >

                        <i class="bi bi-search me-1"></i>

                        Filtrar

                    </button>

                </div>

            </form>

        </div>

    </div>


    <!-- TABLA -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-white py-3">

            <div class="d-flex justify-content-between">

                <strong>

                    <i class="bi bi-list-ul me-2"></i>

                    Historial

                </strong>

                <span class="badge text-bg-light border">

                    <?= count($movimientos) ?>

                    registros

                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (!$movimientos): ?>

                <div class="p-5 text-center text-muted">

                    <i class="bi bi-clock-history fs-1 d-block mb-3"></i>

                    No hay movimientos registrados.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-3">
                                    Fecha
                                </th>

                                <th>
                                    Insumo
                                </th>

                                <th>
                                    Tipo
                                </th>

                                <th class="text-end">
                                    Cantidad
                                </th>

                                <th class="text-end">
                                    Costo
                                </th>

                                <th>
                                    Comprobante
                                </th>

                                <th>
                                    Origen
                                </th>

                                <th>
                                    Observación
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php foreach ($movimientos as $movimiento): ?>

                                <?php

                                $tipo = strtoupper(
                                    (string) (
                                        $movimiento['tipo'] ?? ''
                                    )
                                );

                                $cantidad = (int) (
                                    $movimiento['cantidad'] ?? 0
                                );

                                ?>

                                <tr>

                                    <td class="ps-3">

                                        <?= e(
                                            $movimiento['fecha']
                                                ?? $movimiento['created_at']
                                                ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <strong>

                                            <?= e(
                                                $movimiento['nombre_insumo']
                                                    ?? ''
                                            ) ?>

                                        </strong>

                                    </td>


                                    <td>

                                        <?php if ($tipo === 'ENTRADA'): ?>

                                            <span class="badge text-bg-success">
                                                ENTRADA
                                            </span>

                                        <?php elseif ($tipo === 'SALIDA'): ?>

                                            <span class="badge text-bg-danger">
                                                SALIDA
                                            </span>

                                        <?php else: ?>

                                            <span class="badge text-bg-warning">
                                                AJUSTE
                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td class="text-end fw-bold">

                                        <?php if ($tipo === 'SALIDA'): ?>

                                            <span class="text-danger">

                                                -<?= number_format(
                                                    abs($cantidad),
                                                    0,
                                                    ',',
                                                    '.'
                                                ) ?>

                                            </span>

                                        <?php else: ?>

                                            <span class="text-success">

                                                +<?= number_format(
                                                    abs($cantidad),
                                                    0,
                                                    ',',
                                                    '.'
                                                ) ?>

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td class="text-end">

                                        <?= e(
                                            $movimiento['costo_unitario']
                                                ?? '0.00'
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= e(
                                            $movimiento['nro_comprobante']
                                                ?? $movimiento['comprobante']
                                                ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= e(
                                            $movimiento['origen']
                                                ?? $movimiento['origen_tipo']
                                                ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <span
                                            class="text-muted"
                                            title="<?= e(
                                                $movimiento['observacion']
                                                    ?? ''
                                            ) ?>"
                                        >

                                            <?= e(
                                                $movimiento['observacion']
                                                    ?? ''
                                            ) ?>

                                        </span>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>