<?php
$insumo = $insumo ?? [];
$categorias = $categorias ?? [];
$csrf = $csrf ?? '';

$id = (int)($insumo['id'] ?? 0);
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                Editar producto
            </h1>

            <div class="text-muted">
                Modificar los datos del producto.
            </div>
        </div>

        <a href="/inventario/insumos"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Volver
        </a>

    </div>


    <form
        method="post"
        action="/inventario/api/insumos/<?= $id ?>"
        id="formProducto"
    >

        <input
            type="hidden"
            name="_csrf"
            value="<?= htmlspecialchars(
                (string)$csrf,
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >


        <div class="row g-4">

            <div class="col-lg-8">

                <div class="card border-0 shadow-sm">

                    <div class="card-header bg-white">

                        <h5 class="fw-bold mb-0">
                            Datos del producto
                        </h5>

                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-md-4">

                                <label class="form-label">
                                    Código / SKU
                                </label>

                                <input
                                    type="text"
                                    name="codigo"
                                    class="form-control"
                                    value="<?= htmlspecialchars(
                                        (string)(
                                            $insumo['codigo']
                                            ?? $insumo['sku']
                                            ?? ''
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                            </div>


                            <div class="col-md-8">

                                <label class="form-label">
                                    Nombre
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="text"
                                    name="nombre"
                                    class="form-control"
                                    required
                                    value="<?= htmlspecialchars(
                                        (string)(
                                            $insumo['nombre']
                                            ?? $insumo['descripcion']
                                            ?? ''
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">
                                    Categoría
                                </label>

                                <select
                                    name="categoria_id"
                                    class="form-select"
                                >

                                    <option value="">
                                        Seleccionar...
                                    </option>

                                    <?php foreach ($categorias as $categoria): ?>

                                        <?php
                                        $categoriaId = (int)(
                                            $categoria['id'] ?? 0
                                        );

                                        $selected =
                                            $categoriaId === (int)(
                                                $insumo['categoria_id']
                                                ?? 0
                                            );
                                        ?>

                                        <option
                                            value="<?= $categoriaId ?>"
                                            <?= $selected ? 'selected' : '' ?>
                                        >
                                            <?= htmlspecialchars(
                                                (string)(
                                                    $categoria['nombre']
                                                    ?? 'Categoría'
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">
                                    Unidad
                                </label>

                                <input
                                    type="text"
                                    name="unidad"
                                    class="form-control"
                                    value="<?= htmlspecialchars(
                                        (string)(
                                            $insumo['unidad']
                                            ?? 'UN'
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                            </div>


                            <div class="col-12">

                                <label class="form-label">
                                    Descripción
                                </label>

                                <textarea
                                    name="descripcion"
                                    class="form-control"
                                    rows="4"
                                ><?= htmlspecialchars(
                                    (string)(
                                        $insumo['descripcion']
                                        ?? ''
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?></textarea>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-lg-4">

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-white">

                        <h5 class="fw-bold mb-0">
                            Precios
                        </h5>

                    </div>

                    <div class="card-body">

                        <div class="mb-3">

                            <label class="form-label">
                                Precio de costo
                            </label>

                            <input
                                type="number"
                                name="precio_costo"
                                class="form-control"
                                step="0.01"
                                min="0"
                                value="<?= htmlspecialchars(
                                    (string)(
                                        $insumo['precio_costo']
                                        ?? $insumo['costo']
                                        ?? 0
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                Precio de venta
                            </label>

                            <input
                                type="number"
                                name="precio_venta"
                                class="form-control"
                                step="0.01"
                                min="0"
                                value="<?= htmlspecialchars(
                                    (string)(
                                        $insumo['precio_venta']
                                        ?? $insumo['precio']
                                        ?? 0
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </div>


                        <div>

                            <label class="form-label">
                                IVA
                            </label>

                            <input
                                type="number"
                                name="iva"
                                class="form-control"
                                step="0.01"
                                value="<?= htmlspecialchars(
                                    (string)(
                                        $insumo['iva']
                                        ?? 21
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </div>

                    </div>

                </div>


                <div class="card border-0 shadow-sm">

                    <div class="card-header bg-white">

                        <h5 class="fw-bold mb-0">
                            Inventario
                        </h5>

                    </div>

                    <div class="card-body">

                        <div class="mb-3">

                            <label class="form-label">
                                Stock actual
                            </label>

                            <input
                                type="number"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    (string)(
                                        $insumo['stock_actual']
                                        ?? $insumo['stock']
                                        ?? 0
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                                readonly
                            >

                            <div class="form-text">
                                El stock se modifica mediante movimientos.
                            </div>

                        </div>


                        <div>

                            <label class="form-label">
                                Stock mínimo
                            </label>

                            <input
                                type="number"
                                name="stock_minimo"
                                class="form-control"
                                step="0.01"
                                min="0"
                                value="<?= htmlspecialchars(
                                    (string)(
                                        $insumo['stock_minimo']
                                        ?? 0
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="d-flex justify-content-end gap-2 mt-4">

            <a href="/inventario/insumos"
               class="btn btn-outline-secondary">
                Cancelar
            </a>

            <button
                type="submit"
                class="btn btn-primary"
            >
                <i class="fa-solid fa-floppy-disk me-1"></i>
                Guardar cambios
            </button>

        </div>

    </form>

</div>