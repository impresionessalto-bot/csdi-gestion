<?php

declare(strict_types=1);

$depositos = is_array($depositos ?? null) ? $depositos : [];
$csrf = (string)($csrf ?? '');
?>
<div class="container-fluid py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Depósitos</h1>
            <p class="text-muted mb-0">Administrá los lugares donde se almacena el stock.</p>
        </div>
        <button class="btn btn-primary" type="button" id="btnNuevoDeposito">
            <i class="fa-solid fa-plus me-1"></i> Nuevo depósito
        </button>
    </div>

    <div id="depositoAlert"></div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <strong>Depósitos registrados</strong>
            <span class="badge bg-light text-dark" id="totalDepositos"><?= count($depositos) ?></span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Dirección</th>
                        <th>Estado</th>
                        <th class="text-end">Acciones</th>
                    </tr>
                </thead>
                <tbody id="depositosBody">
                <?php foreach ($depositos as $d): ?>
                    <tr data-id="<?= (int)$d['id'] ?>">
                        <td><code><?= htmlspecialchars((string)$d['codigo'], ENT_QUOTES, 'UTF-8') ?></code></td>
                        <td class="fw-semibold"><?= htmlspecialchars((string)$d['nombre'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string)($d['direccion'] ?? ''), ENT_QUOTES, 'UTF-8') ?: '<span class="text-muted">Sin dirección</span>' ?></td>
                        <td><?= !empty($d['activo']) ? '<span class="badge text-bg-success">Activo</span>' : '<span class="badge text-bg-secondary">Inactivo</span>' ?></td>
                        <td class="text-end">
                            <button class="btn btn-sm btn-outline-primary btn-editar" type="button" data-id="<?= (int)$d['id'] ?>">Editar</button>
                            <?php if (!empty($d['activo'])): ?>
                                <button class="btn btn-sm btn-outline-danger btn-eliminar" type="button" data-id="<?= (int)$d['id'] ?>">Desactivar</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$depositos): ?>
                    <tr><td colspan="5" class="text-center text-muted py-5">No hay depósitos registrados.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="depositoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" id="depositoForm">
            <div class="modal-header">
                <h5 class="modal-title" id="depositoModalTitle">Nuevo depósito</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="depositoId" value="0">
                <input type="hidden" id="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <div class="mb-3">
                    <label class="form-label">Nombre *</label>
                    <input class="form-control" id="depositoNombre" maxlength="150" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Código</label>
                    <input class="form-control" id="depositoCodigo" maxlength="20" placeholder="Se genera automáticamente si lo dejás vacío">
                    <div class="form-text">Ejemplo: CENTRAL, SERVICIO o DEP-01.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Dirección</label>
                    <input class="form-control" id="depositoDireccion" maxlength="255">
                </div>
                <div class="form-check" id="activoWrap" style="display:none">
                    <input class="form-check-input" type="checkbox" id="depositoActivo" checked>
                    <label class="form-check-label" for="depositoActivo">Activo</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary" id="btnGuardarDeposito">Guardar</button>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    const modalEl = document.getElementById('depositoModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    const form = document.getElementById('depositoForm');
    const idEl = document.getElementById('depositoId');
    const nombreEl = document.getElementById('depositoNombre');
    const codigoEl = document.getElementById('depositoCodigo');
    const direccionEl = document.getElementById('depositoDireccion');
    const activoEl = document.getElementById('depositoActivo');
    const activoWrap = document.getElementById('activoWrap');
    const alertEl = document.getElementById('depositoAlert');
    const csrf = document.getElementById('csrf').value;
    let cache = <?= json_encode($depositos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

    const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
    const msg = (text, type='success') => { alertEl.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show">${esc(text)}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`; };

    function render() {
        const body = document.getElementById('depositosBody');
        document.getElementById('totalDepositos').textContent = cache.length;
        if (!cache.length) { body.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-5">No hay depósitos registrados.</td></tr>'; return; }
        body.innerHTML = cache.map(d => `<tr data-id="${d.id}">
            <td><code>${esc(d.codigo)}</code></td>
            <td class="fw-semibold">${esc(d.nombre)}</td>
            <td>${d.direccion ? esc(d.direccion) : '<span class="text-muted">Sin dirección</span>'}</td>
            <td>${Number(d.activo) ? '<span class="badge text-bg-success">Activo</span>' : '<span class="badge text-bg-secondary">Inactivo</span>'}</td>
            <td class="text-end">
                <button class="btn btn-sm btn-outline-primary btn-editar" data-id="${d.id}" type="button">Editar</button>
                ${Number(d.activo) ? `<button class="btn btn-sm btn-outline-danger btn-eliminar" data-id="${d.id}" type="button">Desactivar</button>` : ''}
            </td>
        </tr>`).join('');
    }

    function nuevo() {
        idEl.value = '0'; nombreEl.value = ''; codigoEl.value = ''; direccionEl.value = ''; activoEl.checked = true; activoWrap.style.display = 'none';
        document.getElementById('depositoModalTitle').textContent = 'Nuevo depósito'; modal.show();
    }

    function editar(id) {
        const d = cache.find(x => Number(x.id) === Number(id)); if (!d) return;
        idEl.value = d.id; nombreEl.value = d.nombre || ''; codigoEl.value = d.codigo || ''; direccionEl.value = d.direccion || ''; activoEl.checked = Number(d.activo) === 1; activoWrap.style.display = 'block';
        document.getElementById('depositoModalTitle').textContent = 'Editar depósito'; modal.show();
    }

    async function request(url, options={}) {
        const response = await fetch(url, {headers:{'Content-Type':'application/json','Accept':'application/json', ...(options.headers||{})}, ...options});
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data.success === false) throw new Error(data.message || 'No se pudo completar la operación.');
        return data;
    }

    async function recargar() {
        const data = await request('/inventario/api/depositos');
        cache = Array.isArray(data.data) ? data.data : []; render();
    }

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const id = Number(idEl.value);
        const payload = {csrf_token: csrf, nombre:nombreEl.value.trim(), codigo:codigoEl.value.trim(), direccion:direccionEl.value.trim(), activo:activoEl.checked ? 1 : 0};
        try {
            await request(id > 0 ? `/inventario/api/depositos/${id}` : '/inventario/api/depositos', {method:'POST', body:JSON.stringify(payload)});
            modal.hide(); await recargar(); msg(id > 0 ? 'Depósito actualizado correctamente.' : 'Depósito creado correctamente.');
        } catch (err) { msg(err.message, 'danger'); }
    });

    document.getElementById('btnNuevoDeposito').addEventListener('click', nuevo);
    document.getElementById('depositosBody').addEventListener('click', async e => {
        const edit = e.target.closest('.btn-editar'); if (edit) { editar(edit.dataset.id); return; }
        const del = e.target.closest('.btn-eliminar'); if (!del) return;
        const d = cache.find(x => Number(x.id) === Number(del.dataset.id)); if (!d) return;
        if (!confirm(`¿Desactivar el depósito "${d.nombre}"?`)) return;
        try { await request(`/inventario/api/depositos/${d.id}/eliminar`, {method:'POST', body:JSON.stringify({csrf_token:csrf})}); await recargar(); msg('Depósito desactivado correctamente.'); }
        catch (err) { msg(err.message, 'danger'); }
    });
})();
</script>
