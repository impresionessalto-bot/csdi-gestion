<?php

declare(strict_types=1);

$insumo = $insumo ?? [];
$csrf   = $csrf ?? '';

$editar = !empty($insumo['id']);

$id = (int) (
    $insumo['id'] ?? 0
);

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-box-seam me-2"></i>

                <?= $editar
                    ? 'Editar insumo'
                    : 'Nuevo insumo'
                ?>

            </h1>

            <p class="text-muted mb-0">

                Maestro de artículos del inventario.

            </p>

        </div>

        <a
            href="/inventario/insumos"
            class="btn btn-outline-secondary"
        >

            <i class="bi bi-arrow-left me-1"></i>

            Volver

        </a>

    </div>


    <!-- AVISO ARQUITECTÓNICO -->

    <div class="alert alert-info">

        <i class="bi bi-info-circle me-2"></i>

        <strong>Importante:</strong>

        el stock no se modifica desde esta pantalla.

        Las existencias ingresan mediante
        <strong>Compras / Recepciones</strong>
        y salen mediante
        <strong>Ventas / Servicios</strong>.

    </div>


    <form
        id="formInsumo"
        method="post"
        novalidate
    >

        <input
            type="hidden"
            name="_csrf"
            value="<?= e($csrf) ?>"
        >


        <div class="row g-4">


            <!-- DATOS PRINCIPALES -->

            <div class="col-12 col-xl-8">

                <div class="card shadow-sm border-0">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-card-text me-2"></i>
                            Datos del artículo
                        </strong>

                    </div>


                    <div class="card-body">

                        <div class="row g-3">


                            <div class="col-12">

                                <label class="form-label fw-semibold">

                                    Nombre del insumo
                                    <span class="text-danger">*</span>

                                </label>

                                <input
                                    type="text"
                                    name="nombre_insumo"
                                    class="form-control"
                                    required
                                    maxlength="255"
                                    value="<?= e(
                                        $insumo['nombre_insumo'] ?? ''
                                    ) ?>"
                                    placeholder="Ej. Toner Ricoh IM 430"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">

                                    Marca

                                </label>

                                <input
                                    type="text"
                                    name="marca"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['marca'] ?? ''
                                    ) ?>"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">

                                    Modelo

                                </label>

                                <input
                                    type="text"
                                    name="modelo"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['modelo'] ?? ''
                                    ) ?>"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">

                                    Código de parte

                                </label>

                                <input
                                    type="text"
                                    name="codigo_parte"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['codigo_parte'] ?? ''
                                    ) ?>"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">

                                    Código de barras

                                </label>

                                <input
                                    type="text"
                                    name="codigo_barras"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['codigo_barras'] ?? ''
                                    ) ?>"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">Unidad de medida <span class="text-danger">*</span></label>

                                <?php $unidadId = (int)($insumo['unidad_medida_id'] ?? 0); ?>

                                <select name="unidad_medida_id" class="form-select" required>
                                    <option value="">Seleccionar...</option>
                                    <?php foreach (($unidades ?? []) as $unidad): ?>
                                        <option value="<?= e($unidad['id']) ?>" <?= $unidadId === (int)$unidad['id'] ? 'selected' : '' ?>>
                                            <?= e($unidad['nombre']) ?> (<?= e($unidad['abreviatura']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <div class="form-text">La unidad determina si el stock admite decimales.</div>

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">

                                    Subrubro

                                </label>

                                <input
                                    type="text"
                                    name="subrubro"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['subrubro'] ?? ''
                                    ) ?>"
                                >

                            </div>

                        </div>

                    </div>

                </div>


                <!-- RENDIMIENTO -->

                <div class="card shadow-sm border-0 mt-4">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-speedometer2 me-2"></i>
                            Rendimiento
                        </strong>

                    </div>


                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-md-6">

                                <label class="form-label">

                                    Rendimiento estándar

                                </label>

                                <input
                                    type="number"
                                    min="0"
                                    step="1"
                                    name="rendimiento_estandar"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['rendimiento_estandar'] ?? 0
                                    ) ?>"
                                >

                                <div class="form-text">

                                    Copias estimadas por unidad.

                                </div>

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">

                                    Rendimiento real

                                </label>

                                <input
                                    type="number"
                                    min="0"
                                    step="1"
                                    name="rendimiento_copias"
                                    class="form-control"
                                    value="<?= e(
                                        $insumo['rendimiento_copias'] ?? 0
                                    ) ?>"
                                >

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- CONFIGURACIÓN -->

            <div class="col-12 col-xl-4">

                <div class="card shadow-sm border-0">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-currency-dollar me-2"></i>
                            Costos y venta
                        </strong>

                    </div>


                    <div class="card-body">

                        <div class="mb-3">

                            <label class="form-label">

                                Costo de compra

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                name="costo_compra"
                                class="form-control"
                                value="<?= e(
                                    $insumo['costo_compra'] ?? 0
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">

                                Costo compra USD

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                name="costo_compra_usd"
                                class="form-control"
                                value="<?= e(
                                    $insumo['costo_compra_usd'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">

                                Cotización USD

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                name="cotizacion_usd_compra"
                                class="form-control"
                                value="<?= e(
                                    $insumo['cotizacion_usd_compra'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">

                                Precio de costo

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                name="precio_costo"
                                class="form-control"
                                value="<?= e(
                                    $insumo['precio_costo'] ?? 0
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">

                                Precio de venta

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                name="precio_venta"
                                class="form-control"
                                value="<?= e(
                                    $insumo['precio_venta'] ?? 0
                                ) ?>"
                            >

                        </div>

                    </div>

                </div>


                <!-- STOCK -->

                <div class="card shadow-sm border-0 mt-4">

                    <div class="card-header bg-white py-3">

                        <strong>
                            <i class="bi bi-boxes me-2"></i>
                            Control de stock
                        </strong>

                    </div>


                    <div class="card-body">

                        <div class="mb-3">

                            <label class="form-label">

                                Stock mínimo

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="1"
                                name="stock_minimo"
                                class="form-control"
                                value="<?= e(
                                    $insumo['stock_minimo'] ?? 0
                                ) ?>"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">

                                Stock máximo

                            </label>

                            <input
                                type="number"
                                min="0"
                                step="1"
                                name="stock_maximo"
                                class="form-control"
                                value="<?= e(
                                    $insumo['stock_maximo'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <?php if ($editar): ?>

                            <div class="alert alert-light border mb-0">

                                <div class="small text-muted">
                                    Stock actual
                                </div>

                                <div class="fs-3 fw-bold">

                                    <?= number_format(
                                        (float) (
                                            $insumo['stock_actual'] ?? 0
                                        ),
                                        3,
                                        ',',
                                        '.'
                                    ) ?>

                                </div>

                                <div class="small text-muted mt-1">

                                    El stock se modifica mediante
                                    movimientos.

                                </div>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>


        <!-- BOTONES -->

        <div class="d-flex justify-content-end gap-2 mt-4">

            <a
                href="/inventario/insumos"
                class="btn btn-outline-secondary"
            >
                Cancelar
            </a>

            <button
                type="submit"
                class="btn btn-primary"
            >

                <i class="bi bi-check-lg me-1"></i>

                <?= $editar
                    ? 'Guardar cambios'
                    : 'Crear insumo'
                ?>

            </button>

        </div>

    </form>

</div>


<script>

(() => {

    const form =
        document.getElementById('formInsumo');

    if (!form) {
        return;
    }

    form.addEventListener('submit', async (event) => {

        event.preventDefault();

        if (!form.checkValidity()) {

            form.classList.add('was-validated');

            return;
        }

        const data =
            Object.fromEntries(
                new FormData(form)
            );

        try {

            const url =
                <?= $editar
                    ? json_encode(
                        '/inventario/api/insumos/' . $id
                    )
                    : json_encode(
                        '/inventario/api/insumos'
                    ) ?>;

            const method =
                <?= $editar
                    ? "'POST'"
                    : "'POST'" ?>;

            const response =
                await fetch(
                    url,
                    {
                        method,
                        headers: {
                            'Content-Type':
                                'application/json',
                            'Accept':
                                'application/json'
                        },
                        body:
                            JSON.stringify(data)
                    }
                );

            const result =
                await response.json();

            if (!result.success) {

                throw new Error(
                    result.message
                    || 'No se pudo guardar el insumo.'
                );

            }

            window.location.href =
                '/inventario/insumos';

        } catch (error) {

            console.error(error);

            alert(
                error.message
                || 'Error guardando el insumo.'
            );

        }

    });

})();

</script>