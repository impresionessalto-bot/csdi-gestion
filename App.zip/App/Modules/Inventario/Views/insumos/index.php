<?php

declare(strict_types=1);

$insumos = $insumos ?? [];
$csrf    = $csrf ?? '';

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('money')) {
    function money(float|int|string|null $value): string
    {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            2,
            ',',
            '.'
        );
    }
}
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                <i class="bi bi-boxes me-2"></i>
                Insumos
            </h1>

            <p class="text-muted mb-0">
                Maestro de artículos, costos, precios y stock.
            </p>
        </div>

        <div class="d-flex gap-2 mt-3 mt-md-0">

            <a
                href="/inventario"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Inventario
            </a>

            <a
                href="/inventario/insumos/crear"
                class="btn btn-primary"
            >
                <i class="bi bi-plus-lg me-1"></i>
                Nuevo insumo
            </a>

        </div>

    </div>


    <!-- FILTROS -->

    <div class="card shadow-sm border-0 mb-4">

        <div class="card-body">

            <form
                id="formFiltros"
                class="row g-3"
            >

                <div class="col-12 col-lg-5">

                    <label class="form-label">
                        Buscar
                    </label>

                    <input
                        type="text"
                        name="q"
                        id="filtroBusqueda"
                        class="form-control"
                        placeholder="Nombre, código, marca, modelo..."
                    >

                </div>


                <div class="col-12 col-sm-4 col-lg-2">

                    <label class="form-label">
                        Estado
                    </label>

                    <select
                        name="activo"
                        id="filtroActivo"
                        class="form-select"
                    >
                        <option value="1">
                            Activos
                        </option>

                        <option value="0">
                            Inactivos
                        </option>

                        <option value="">
                            Todos
                        </option>
                    </select>

                </div>


                <div class="col-12 col-sm-4 col-lg-2">

                    <label class="form-label">
                        Stock
                    </label>

                    <select
                        name="stock"
                        id="filtroStock"
                        class="form-select"
                    >
                        <option value="">
                            Todos
                        </option>

                        <option value="sin_stock">
                            Sin stock
                        </option>

                        <option value="bajo">
                            Stock bajo
                        </option>

                        <option value="disponible">
                            Disponible
                        </option>
                    </select>

                </div>


                <div class="col-12 col-sm-4 col-lg-3 d-flex align-items-end gap-2">

                    <button
                        type="submit"
                        class="btn btn-primary flex-grow-1"
                    >
                        <i class="bi bi-search me-1"></i>
                        Buscar
                    </button>

                    <button
                        type="button"
                        id="btnLimpiar"
                        class="btn btn-outline-secondary"
                    >
                        <i class="bi bi-x-lg"></i>
                    </button>

                </div>

            </form>

        </div>

    </div>


    <!-- TABLA -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-white py-3">

            <div class="d-flex justify-content-between align-items-center">

                <strong>
                    <i class="bi bi-list-ul me-2"></i>
                    Artículos
                </strong>

                <span
                    id="totalRegistros"
                    class="badge text-bg-light border"
                >
                    <?= count($insumos) ?> registros
                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover align-middle mb-0">

                    <thead class="table-light">

                        <tr>

                            <th class="ps-3">
                                ID
                            </th>

                            <th>
                                Insumo
                            </th>

                            <th>
                                Código
                            </th>

                            <th>
                                Categoría
                            </th>

                            <th class="text-center">
                                Stock
                            </th>

                            <th class="text-end">
                                Costo
                            </th>

                            <th class="text-end">
                                Precio
                            </th>

                            <th class="text-center">
                                Estado
                            </th>

                            <th class="text-end pe-3">
                                Acciones
                            </th>

                        </tr>

                    </thead>


                    <tbody id="tablaInsumos">

                    <?php if (!$insumos): ?>

                        <tr>
                            <td
                                colspan="9"
                                class="text-center text-muted py-5"
                            >
                                <i class="bi bi-box-seam fs-1 d-block mb-3"></i>

                                No hay insumos registrados.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($insumos as $item): ?>

                            <?php

                            $id = (int) ($item['id'] ?? 0);

                            $stock = (int) (
                                $item['stock_actual'] ?? 0
                            );

                            $minimo = (int) (
                                $item['stock_minimo'] ?? 0
                            );

                            $activo = (int) (
                                $item['activo'] ?? 0
                            );

                            ?>

                            <tr>

                                <td class="ps-3 text-muted">
                                    #<?= $id ?>
                                </td>


                                <td>

                                    <strong>
                                        <?= e(
                                            $item['nombre_insumo'] ?? ''
                                        ) ?>
                                    </strong>

                                    <?php if (
                                        !empty($item['marca'])
                                        || !empty($item['modelo'])
                                    ): ?>

                                        <div class="small text-muted">

                                            <?= e(
                                                $item['marca'] ?? ''
                                            ) ?>

                                            <?php if (
                                                !empty($item['marca'])
                                                && !empty($item['modelo'])
                                            ): ?>
                                                -
                                            <?php endif; ?>

                                            <?= e(
                                                $item['modelo'] ?? ''
                                            ) ?>

                                        </div>

                                    <?php endif; ?>

                                </td>


                                <td>
                                    <?= e(
                                        $item['codigo_parte'] ?? ''
                                    ) ?>
                                </td>


                                <td>
                                    <?= e(
                                        $item['categoria_nombre'] ?? ''
                                    ) ?>
                                </td>


                                <td class="text-center">

                                    <?php if ($stock <= 0): ?>

                                        <span class="badge text-bg-danger">
                                            0
                                        </span>

                                    <?php elseif (
                                        $minimo > 0
                                        && $stock <= $minimo
                                    ): ?>

                                        <span class="badge text-bg-warning">
                                            <?= $stock ?>
                                        </span>

                                    <?php else: ?>

                                        <span class="badge text-bg-success">
                                            <?= $stock ?>
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td class="text-end">
                                    <?= money(
                                        $item['precio_costo']
                                            ?? $item['costo_compra']
                                            ?? 0
                                    ) ?>
                                </td>


                                <td class="text-end">
                                    <?= money(
                                        $item['precio_venta'] ?? 0
                                    ) ?>
                                </td>


                                <td class="text-center">

                                    <?php if ($activo): ?>

                                        <span class="badge text-bg-success">
                                            Activo
                                        </span>

                                    <?php else: ?>

                                        <span class="badge text-bg-secondary">
                                            Inactivo
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td class="text-end pe-3">

                                    <div class="btn-group btn-group-sm">

                                        <a
                                            href="/inventario/insumos/<?= $id ?>"
                                            class="btn btn-outline-primary"
                                            title="Ver"
                                        >
                                            <i class="bi bi-eye"></i>
                                        </a>

                                        <a
                                            href="/inventario/insumos/<?= $id ?>/editar"
                                            class="btn btn-outline-secondary"
                                            title="Editar"
                                        >
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <a
                                            href="/inventario/movimientos/<?= $id ?>"
                                            class="btn btn-outline-dark"
                                            title="Movimientos"
                                        >
                                            <i class="bi bi-clock-history"></i>
                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>


<script>

(() => {

    const form = document.getElementById('formFiltros');
    const tabla = document.getElementById('tablaInsumos');
    const total = document.getElementById('totalRegistros');
    const limpiar = document.getElementById('btnLimpiar');

    if (!form || !tabla) {
        return;
    }

    form.addEventListener('submit', async (event) => {

        event.preventDefault();

        const params = new URLSearchParams(
            new FormData(form)
        );

        try {

            const response = await fetch(
                '/inventario/api/insumos?' + params.toString(),
                {
                    headers: {
                        'Accept': 'application/json'
                    }
                }
            );

            const result = await response.json();

            if (!result.success) {
                throw new Error(
                    result.message || 'No se pudo cargar el inventario.'
                );
            }

            render(result.data || []);

        } catch (error) {

            console.error(error);

            alert(
                error.message
                || 'Error cargando los insumos.'
            );
        }

    });


    limpiar.addEventListener('click', () => {

        form.reset();

        document.getElementById('filtroActivo').value = '1';

        form.dispatchEvent(
            new Event('submit')
        );

    });


    function render(items) {

        total.textContent =
            items.length + ' registros';

        if (!items.length) {

            tabla.innerHTML = `
                <tr>
                    <td colspan="9"
                        class="text-center text-muted py-5">
                        <i class="bi bi-search fs-1 d-block mb-3"></i>
                        No se encontraron insumos.
                    </td>
                </tr>
            `;

            return;
        }

        tabla.innerHTML = items.map(item => {

            const stock =
                Number(item.stock_actual || 0);

            const minimo =
                Number(item.stock_minimo || 0);

            let badge = 'text-bg-success';

            if (stock <= 0) {
                badge = 'text-bg-danger';
            } else if (
                minimo > 0
                && stock <= minimo
            ) {
                badge = 'text-bg-warning';
            }

            const activo =
                Number(item.activo || 0);

            return `
                <tr>

                    <td class="ps-3 text-muted">
                        #${Number(item.id || 0)}
                    </td>

                    <td>
                        <strong>
                            ${escapeHtml(item.nombre_insumo || '')}
                        </strong>
                    </td>

                    <td>
                        ${escapeHtml(item.codigo_parte || '')}
                    </td>

                    <td>
                        ${escapeHtml(item.categoria_nombre || '')}
                    </td>

                    <td class="text-center">
                        <span class="badge ${badge}">
                            ${stock}
                        </span>
                    </td>

                    <td class="text-end">
                        ${money(item.precio_costo || item.costo_compra || 0)}
                    </td>

                    <td class="text-end">
                        ${money(item.precio_venta || 0)}
                    </td>

                    <td class="text-center">
                        ${
                            activo
                            ? '<span class="badge text-bg-success">Activo</span>'
                            : '<span class="badge text-bg-secondary">Inactivo</span>'
                        }
                    </td>

                    <td class="text-end pe-3">

                        <div class="btn-group btn-group-sm">

                            <a
                                href="/inventario/insumos/${Number(item.id || 0)}"
                                class="btn btn-outline-primary"
                            >
                                <i class="bi bi-eye"></i>
                            </a>

                            <a
                                href="/inventario/insumos/${Number(item.id || 0)}/editar"
                                class="btn btn-outline-secondary"
                            >
                                <i class="bi bi-pencil"></i>
                            </a>

                        </div>

                    </td>

                </tr>
            `;

        }).join('');

    }


    function money(value) {

        return '$ ' + Number(value || 0)
            .toLocaleString(
                'es-AR',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );

    }


    function escapeHtml(value) {

        const div =
            document.createElement('div');

        div.textContent =
            String(value ?? '');

        return div.innerHTML;

    }

})();

</script>