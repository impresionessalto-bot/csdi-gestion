<?php
$movimientos = $movimientos ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">
                Movimientos de stock
            </h1>

            <div class="text-muted">
                Historial de entradas, salidas y ajustes.
            </div>

        </div>

        <a href="/inventario"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Inventario
        </a>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white">

            <form method="get">

                <div class="row g-2">

                    <div class="col-md-4">

                        <input
                            type="search"
                            name="q"
                            class="form-control"
                            placeholder="Producto o comprobante..."
                            value="<?= htmlspecialchars(
                                (string)($_GET['q'] ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >

                    </div>

                    <div class="col-md-3">

                        <select
                            name="tipo"
                            class="form-select"
                        >

                            <option value="">
                                Todos los movimientos
                            </option>

                            <option value="ENTRADA">
                                Entradas
                            </option>

                            <option value="SALIDA">
                                Salidas
                            </option>

                            <option value="AJUSTE">
                                Ajustes
                            </option>

                        </select>

                    </div>

                    <div class="col-md-3">

                        <input
                            type="date"
                            name="fecha"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                (string)($_GET['fecha'] ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >

                    </div>

                    <div class="col-md-2">

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            <i class="fa-solid fa-search me-1"></i>
                            Buscar
                        </button>

                    </div>

                </div>

            </form>

        </div>


        <div class="card-body p-0">

            <?php if (empty($movimientos)): ?>

                <div class="text-center py-5 text-muted">

                    <i class="fa-solid fa-arrow-right-arrow-left fs-1 d-block mb-3"></i>

                    No hay movimientos registrados.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-4">
                                    Fecha
                                </th>

                                <th>
                                    Producto
                                </th>

                                <th>
                                    Tipo
                                </th>

                                <th class="text-end">
                                    Cantidad
                                </th>

                                <th>
                                    Comprobante
                                </th>

                                <th>
                                    Usuario
                                </th>

                                <th class="pe-4">
                                    Observación
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($movimientos as $movimiento): ?>

                            <?php
                            $tipo = strtoupper(
                                (string)(
                                    $movimiento['tipo']
                                    ?? 'MOVIMIENTO'
                                )
                            );

                            $cantidad = (float)(
                                $movimiento['cantidad']
                                ?? 0
                            );
                            ?>

                            <tr>

                                <td class="ps-4">

                                    <?= htmlspecialchars(
                                        (string)(
                                            $movimiento['fecha']
                                            ?? $movimiento['created_at']
                                            ?? '-'
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                                <td class="fw-semibold">

                                    <?= htmlspecialchars(
                                        (string)(
                                            $movimiento['insumo_nombre']
                                            ?? $movimiento['producto']
                                            ?? '-'
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                                <td>

                                    <?php

                                    $badge = match ($tipo) {
                                        'ENTRADA' => 'bg-success-subtle text-success',
                                        'SALIDA'  => 'bg-danger-subtle text-danger',
                                        'AJUSTE'  => 'bg-warning-subtle text-warning-emphasis',
                                        default   => 'bg-secondary-subtle text-secondary',
                                    };

                                    ?>

                                    <span class="badge <?= $badge ?>">
                                        <?= htmlspecialchars(
                                            $tipo,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                </td>

                                <td class="text-end fw-bold">

                                    <?= number_format(
                                        $cantidad,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        (string)(
                                            $movimiento['comprobante']
                                            ?? '-'
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        (string)(
                                            $movimiento['usuario_nombre']
                                            ?? $movimiento['usuario']
                                            ?? '-'
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                                <td class="pe-4 text-muted">

                                    <?= htmlspecialchars(
                                        (string)(
                                            $movimiento['observacion']
                                            ?? ''
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>