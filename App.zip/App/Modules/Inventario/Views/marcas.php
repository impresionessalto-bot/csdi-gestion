<?php
$marcas = $marcas ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                Marcas
            </h1>

            <div class="text-muted">
                Fabricantes y marcas comerciales.
            </div>
        </div>

        <a href="/inventario"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Inventario
        </a>

    </div>


    <div class="row g-4">

        <div class="col-lg-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="fw-bold mb-0">
                        Nueva marca
                    </h5>

                </div>

                <div class="card-body">

                    <form method="post"
                          action="/inventario/api/marcas">

                        <input
                            type="hidden"
                            name="_csrf"
                            value="<?= htmlspecialchars(
                                (string)($csrf ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >

                        <div class="mb-3">

                            <label class="form-label">
                                Marca
                            </label>

                            <input
                                type="text"
                                name="nombre"
                                class="form-control"
                                required
                                maxlength="150"
                                placeholder="Ej: Ricoh"
                            >

                        </div>


                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            <i class="fa-solid fa-plus me-1"></i>
                            Crear marca
                        </button>

                    </form>

                </div>

            </div>

        </div>


        <div class="col-lg-8">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="fw-bold mb-0">
                        Marcas registradas
                    </h5>

                </div>

                <div class="card-body p-0">

                    <?php if (empty($marcas)): ?>

                        <div class="text-center py-5 text-muted">

                            <i class="fa-solid fa-tags fs-1 d-block mb-3"></i>

                            No hay marcas registradas.

                        </div>

                    <?php else: ?>

                        <div class="table-responsive">

                            <table class="table table-hover align-middle mb-0">

                                <thead class="table-light">

                                    <tr>

                                        <th class="ps-4">
                                            Marca
                                        </th>

                                        <th>
                                            Productos
                                        </th>

                                        <th class="text-end pe-4">
                                            Acciones
                                        </th>

                                    </tr>

                                </thead>

                                <tbody>

                                <?php foreach ($marcas as $marca): ?>

                                    <tr>

                                        <td class="ps-4 fw-semibold">
                                            <?= htmlspecialchars(
                                                (string)(
                                                    $marca['nombre']
                                                    ?? '-'
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>

                                        <td>
                                            <?= number_format(
                                                (int)(
                                                    $marca['productos']
                                                    ?? $marca['cantidad']
                                                    ?? 0
                                                ),
                                                0,
                                                ',',
                                                '.'
                                            ) ?>
                                        </td>

                                        <td class="text-end pe-4">

                                            <button
                                                type="button"
                                                class="btn btn-sm btn-outline-primary"
                                            >
                                                <i class="fa-solid fa-pen"></i>
                                            </button>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</div>