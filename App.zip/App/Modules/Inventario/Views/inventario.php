<?php
$insumos = $insumos ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">
                Inventario físico
            </h1>

            <div class="text-muted">
                Toma de inventario y conciliación de existencias.
            </div>

        </div>

        <a href="/inventario"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Inventario
        </a>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white py-3">

            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">

                <div>

                    <h5 class="fw-bold mb-1">
                        Conteo físico
                    </h5>

                    <div class="text-muted small">
                        Ingresá la cantidad física encontrada para cada producto.
                    </div>

                </div>

                <button
                    type="button"
                    class="btn btn-primary"
                    id="guardarInventario"
                >
                    <i class="fa-solid fa-check me-1"></i>
                    Guardar inventario
                </button>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (empty($insumos)): ?>

                <div class="text-center py-5 text-muted">

                    <i class="fa-solid fa-clipboard fs-1 d-block mb-3"></i>

                    No hay productos para inventariar.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>

                                <th class="ps-4">
                                    Código
                                </th>

                                <th>
                                    Producto
                                </th>

                                <th class="text-end">
                                    Stock sistema
                                </th>

                                <th style="width:180px">
                                    Conteo físico
                                </th>

                                <th class="text-end pe-4">
                                    Diferencia
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($insumos as $item): ?>

                            <?php
                            $id = (int)(
                                $item['id'] ?? 0
                            );

                            $stock = (float)(
                                $item['stock_actual']
                                ?? $item['stock']
                                ?? 0
                            );

                            $codigo = $item['codigo']
                                ?? $item['sku']
                                ?? '-';

                            $nombre = $item['nombre']
                                ?? $item['descripcion']
                                ?? 'Producto';
                            ?>

                            <tr data-id="<?= $id ?>">

                                <td class="ps-4">

                                    <?= htmlspecialchars(
                                        (string)$codigo,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                                <td class="fw-semibold">

                                    <?= htmlspecialchars(
                                        (string)$nombre,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </td>

                                <td class="text-end">

                                    <span class="stock-sistema">

                                        <?= number_format(
                                            $stock,
                                            2,
                                            ',',
                                            '.'
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    <input
                                        type="number"
                                        class="form-control form-control-sm conteo-fisico"
                                        step="0.01"
                                        min="0"
                                        value="<?= htmlspecialchars(
                                            (string)$stock,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        data-stock="<?= $stock ?>"
                                    >

                                </td>

                                <td class="text-end pe-4">

                                    <span class="diferencia text-muted">
                                        0
                                    </span>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<script>

document.addEventListener('DOMContentLoaded', function () {

    document
        .querySelectorAll('.conteo-fisico')
        .forEach(function (input) {

            input.addEventListener('input', function () {

                const row = this.closest('tr');

                const stock =
                    parseFloat(
                        this.dataset.stock || 0
                    );

                const fisico =
                    parseFloat(
                        this.value || 0
                    );

                const diferencia =
                    fisico - stock;

                const output =
                    row.querySelector('.diferencia');

                output.textContent =
                    diferencia.toLocaleString(
                        'es-AR',
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }
                    );

                output.classList.remove(
                    'text-danger',
                    'text-success',
                    'text-muted'
                );

                if (diferencia < 0) {

                    output.classList.add(
                        'text-danger'
                    );

                } else if (diferencia > 0) {

                    output.classList.add(
                        'text-success'
                    );

                } else {

                    output.classList.add(
                        'text-muted'
                    );

                }

            });

        });


    const guardar =
        document.getElementById(
            'guardarInventario'
        );

    if (!guardar) {
        return;
    }

    guardar.addEventListener(
        'click',
        async function () {

            const ajustes = [];

            document
                .querySelectorAll('tbody tr[data-id]')
                .forEach(function (row) {

                    const id =
                        parseInt(
                            row.dataset.id || 0
                        );

                    const input =
                        row.querySelector(
                            '.conteo-fisico'
                        );

                    if (!id || !input) {
                        return;
                    }

                    const stock =
                        parseFloat(
                            input.dataset.stock || 0
                        );

                    const fisico =
                        parseFloat(
                            input.value || 0
                        );

                    const diferencia =
                        fisico - stock;

                    if (diferencia !== 0) {

                        ajustes.push({

                            insumo_id: id,

                            cantidad: diferencia,

                            observacion:
                                'Ajuste por inventario físico'

                        });

                    }

                });


            if (ajustes.length === 0) {

                alert(
                    'No hay diferencias para ajustar.'
                );

                return;
            }


            if (
                !confirm(
                    'Se registrarán ' +
                    ajustes.length +
                    ' ajustes. ¿Continuar?'
                )
            ) {
                return;
            }


            guardar.disabled = true;


            try {

                const csrf =
                    document.querySelector(
                        'input[name="_csrf"]'
                    )?.value || '';


                for (const ajuste of ajustes) {

                    const response =
                        await fetch(
                            '/inventario/api/ajustar',
                            {

                                method: 'POST',

                                headers: {
                                    'Content-Type':
                                        'application/json',

                                    'X-CSRF-TOKEN':
                                        csrf
                                },

                                body:
                                    JSON.stringify({

                                        ...ajuste,

                                        _csrf: csrf

                                    })

                            }
                        );


                    const result =
                        await response.json();


                    if (!result.success) {

                        throw new Error(
                            result.message
                            || 'Error registrando ajuste.'
                        );

                    }

                }


                alert(
                    'Inventario actualizado correctamente.'
                );


                window.location.reload();


            } catch (error) {

                console.error(error);

                alert(
                    error.message
                    || 'No se pudo guardar el inventario.'
                );

                guardar.disabled = false;

            }

        }
    );

});

</script>