<?php

declare(strict_types=1);

$venta = $venta ?? [];

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

if (!function_exists('money')) {
    function money(float|int|string|null $value): string
    {
        return '$ ' . number_format(
            (float) ($value ?? 0),
            2,
            ',',
            '.'
        );
    }
}

$fecha =
    $venta['fecha']
    ?? null;

$timestamp =
    $fecha
        ? strtotime((string) $fecha)
        : false;

$detalles =
    $venta['detalle']
    ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>

            <h1 class="h3 fw-bold mb-1">

                <i class="bi bi-receipt me-2"></i>

                Venta #<?= (int) (
                    $venta['id'] ?? 0
                ) ?>

            </h1>

            <p class="text-muted mb-0">
                Comprobante interno de venta.
            </p>

        </div>


        <div class="d-flex gap-2">

            <a
                href="/ventas"
                class="btn btn-outline-secondary"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Volver
            </a>

            <button
                type="button"
                class="btn btn-outline-primary"
                onclick="window.print()"
            >
                <i class="bi bi-printer me-1"></i>
                Imprimir
            </button>

        </div>

    </div>


    <!-- CABECERA -->

    <div class="card border-0 shadow-sm mb-4">

        <div class="card-body">

            <div class="row g-4">

                <div class="col-12 col-md-4">

                    <div class="text-muted small">
                        Comprobante
                    </div>

                    <div class="fs-5 fw-bold">
                        #<?= (int) (
                            $venta['id'] ?? 0
                        ) ?>
                    </div>

                </div>


                <div class="col-12 col-md-4">

                    <div class="text-muted small">
                        Fecha
                    </div>

                    <div class="fw-semibold">

                        <?= $timestamp
                            ? date(
                                'd/m/Y H:i',
                                $timestamp
                            )
                            : '-'
                        ?>

                    </div>

                </div>


                <div class="col-12 col-md-4">

                    <div class="text-muted small">
                        Cliente
                    </div>

                    <div class="fw-semibold">

                        <?= e(
                            $venta['cliente_nombre']
                            ?: 'Consumidor final'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- DETALLE -->

    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white py-3">

            <strong>
                <i class="bi bi-list-ul me-2"></i>
                Detalle de venta
            </strong>

        </div>


        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table align-middle mb-0">

                    <thead class="table-light">

                        <tr>

                            <th class="ps-3">
                                Tipo
                            </th>

                            <th>
                                Descripción
                            </th>

                            <th class="text-end">
                                Cantidad
                            </th>

                            <th class="text-end">
                                Precio
                            </th>

                            <th class="text-end">
                                Descuento
                            </th>

                            <th class="text-end pe-3">
                                Subtotal
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php foreach ($detalles as $item): ?>

                            <?php

                            $tipo =
                                strtoupper(
                                    (string) (
                                        $item['tipo']
                                        ?? ''
                                    )
                                );

                            $badge =
                                match ($tipo) {

                                    'INSUMO' =>
                                        'text-bg-primary',

                                    'SERVICIO' =>
                                        'text-bg-info',

                                    default =>
                                        'text-bg-secondary',
                                };

                            ?>

                            <tr>

                                <td class="ps-3">

                                    <span
                                        class="badge <?= $badge ?>"
                                    >
                                        <?= e($tipo) ?>
                                    </span>

                                </td>


                                <td>

                                    <strong>
                                        <?= e(
                                            $item['descripcion']
                                            ?? ''
                                        ) ?>
                                    </strong>

                                    <?php if (
                                        !empty(
                                            $item['insumo_id']
                                        )
                                    ): ?>

                                        <div class="small text-muted">

                                            Insumo #<?= (int) (
                                                $item['insumo_id']
                                            ) ?>

                                        </div>

                                    <?php endif; ?>

                                </td>


                                <td class="text-end">

                                    <?= number_format(
                                        (float) (
                                            $item['cantidad']
                                            ?? 0
                                        ),
                                        3,
                                        ',',
                                        '.'
                                    ) ?>

                                </td>


                                <td class="text-end">

                                    <?= money(
                                        $item['precio_unitario']
                                        ?? 0
                                    ) ?>

                                </td>


                                <td class="text-end">

                                    <?= money(
                                        $item['descuento']
                                        ?? 0
                                    ) ?>

                                </td>


                                <td class="text-end pe-3 fw-semibold">

                                    <?= money(
                                        $item['subtotal']
                                        ?? 0
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        </div>


        <div class="card-footer bg-white">

            <div class="d-flex justify-content-end align-items-center gap-4">

                <span class="fs-5">
                    Total
                </span>

                <span class="fs-3 fw-bold">
                    <?= money(
                        $venta['total_venta']
                        ?? 0
                    ) ?>
                </span>

            </div>

        </div>

    </div>

</div>