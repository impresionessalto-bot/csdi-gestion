<?php
$categorias = $categorias ?? [];
$csrf = $csrf ?? '';
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                Nuevo producto
            </h1>

            <div class="text-muted">
                Registrar un nuevo producto en el inventario.
            </div>
        </div>

        <a href="/inventario/insumos"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Volver
        </a>

    </div>


    <form
        method="post"
        action="/inventario/api/insumos"
        id="formProducto"
    >

        <input
            type="hidden"
            name="_csrf"
            value="<?= htmlspecialchars(
                (string)$csrf,
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >


        <div class="row g-4">

            <div class="col-lg-8">

                <div class="card border-0 shadow-sm">

                    <div class="card-header bg-white">

                        <h5 class="fw-bold mb-0">
                            Datos del producto
                        </h5>

                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-md-4">

                                <label class="form-label">
                                    Código / SKU
                                </label>

                                <input
                                    type="text"
                                    name="codigo"
                                    class="form-control"
                                    maxlength="100"
                                >

                            </div>


                            <div class="col-md-8">

                                <label class="form-label">
                                    Nombre
                                    <span class="text-danger">*</span>
                                </label>

                                <input
                                    type="text"
                                    name="nombre"
                                    class="form-control"
                                    required
                                    maxlength="255"
                                >

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">
                                    Categoría
                                </label>

                                <select
                                    name="categoria_id"
                                    class="form-select"
                                >

                                    <option value="">
                                        Seleccionar...
                                    </option>

                                    <?php foreach ($categorias as $categoria): ?>

                                        <option
                                            value="<?= (int)(
                                                $categoria['id'] ?? 0
                                            ) ?>"
                                        >
                                            <?= htmlspecialchars(
                                                (string)(
                                                    $categoria['nombre']
                                                    ?? 'Categoría'
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>


                            <div class="col-md-6">

                                <label class="form-label">
                                    Unidad de medida
                                </label>

                                <select
                                    name="unidad"
                                    class="form-select"
                                >

                                    <option value="UN">
                                        Unidad
                                    </option>

                                    <option value="KG">
                                        Kilogramo
                                    </option>

                                    <option value="MT">
                                        Metro
                                    </option>

                                    <option value="LT">
                                        Litro
                                    </option>

                                </select>

                            </div>


                            <div class="col-12">

                                <label class="form-label">
                                    Descripción
                                </label>

                                <textarea
                                    name="descripcion"
                                    class="form-control"
                                    rows="4"
                                ></textarea>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="col-lg-4">

                <div class="card border-0 shadow-sm mb-4">

                    <div class="card-header bg-white">

                        <h5 class="fw-bold mb-0">
                            Precios
                        </h5>

                    </div>

                    <div class="card-body">

                        <div class="mb-3">

                            <label class="form-label">
                                Precio de costo
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    $
                                </span>

                                <input
                                    type="number"
                                    name="precio_costo"
                                    class="form-control"
                                    step="0.01"
                                    min="0"
                                    value="0"
                                >

                            </div>

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                Precio de venta
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    $
                                </span>

                                <input
                                    type="number"
                                    name="precio_venta"
                                    class="form-control"
                                    step="0.01"
                                    min="0"
                                    value="0"
                                >

                            </div>

                        </div>


                        <div>

                            <label class="form-label">
                                IVA
                            </label>

                            <select
                                name="iva"
                                class="form-select"
                            >

                                <option value="21">
                                    21%
                                </option>

                                <option value="10.5">
                                    10,5%
                                </option>

                                <option value="27">
                                    27%
                                </option>

                                <option value="0">
                                    Exento / 0%
                                </option>

                            </select>

                        </div>

                    </div>

                </div>


                <div class="card border-0 shadow-sm">

                    <div class="card-header bg-white">

                        <h5 class="fw-bold mb-0">
                            Inventario
                        </h5>

                    </div>

                    <div class="card-body">

                        <div class="mb-3">

                            <label class="form-label">
                                Stock inicial
                            </label>

                            <input
                                type="number"
                                name="stock_inicial"
                                class="form-control"
                                step="0.01"
                                min="0"
                                value="0"
                            >

                        </div>


                        <div>

                            <label class="form-label">
                                Stock mínimo
                            </label>

                            <input
                                type="number"
                                name="stock_minimo"
                                class="form-control"
                                step="0.01"
                                min="0"
                                value="0"
                            >

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="d-flex justify-content-end gap-2 mt-4">

            <a href="/inventario/insumos"
               class="btn btn-outline-secondary">
                Cancelar
            </a>

            <button
                type="submit"
                class="btn btn-primary"
            >
                <i class="fa-solid fa-check me-1"></i>
                Guardar producto
            </button>

        </div>

    </form>

</div>