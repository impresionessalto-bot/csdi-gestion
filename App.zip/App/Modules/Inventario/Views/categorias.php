<?php
$categorias = $categorias ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h1 class="h3 fw-bold mb-1">
                Categorías
            </h1>

            <div class="text-muted">
                Familias y rubros de productos.
            </div>
        </div>

        <a href="/inventario"
           class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i>
            Inventario
        </a>

    </div>


    <div class="row g-4">

        <div class="col-lg-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="fw-bold mb-0">
                        Nueva categoría
                    </h5>

                </div>

                <div class="card-body">

                    <form method="post"
                          action="/inventario/api/categorias">

                        <input
                            type="hidden"
                            name="_csrf"
                            value="<?= htmlspecialchars(
                                (string)($csrf ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >

                        <div class="mb-3">

                            <label class="form-label">
                                Nombre
                            </label>

                            <input
                                type="text"
                                name="nombre"
                                class="form-control"
                                required
                                maxlength="150"
                                placeholder="Ej: Insumos"
                            >

                        </div>


                        <div class="mb-3">

                            <label class="form-label">
                                Descripción
                            </label>

                            <textarea
                                name="descripcion"
                                class="form-control"
                                rows="3"
                            ></textarea>

                        </div>


                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            <i class="fa-solid fa-plus me-1"></i>
                            Crear categoría
                        </button>

                    </form>

                </div>

            </div>

        </div>


        <div class="col-lg-8">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="fw-bold mb-0">
                        Categorías registradas
                    </h5>

                </div>

                <div class="card-body p-0">

                    <?php if (empty($categorias)): ?>

                        <div class="text-center py-5 text-muted">
                            <i class="fa-solid fa-layer-group fs-1 d-block mb-3"></i>
                            No hay categorías registradas.
                        </div>

                    <?php else: ?>

                        <div class="table-responsive">

                            <table class="table table-hover align-middle mb-0">

                                <thead class="table-light">

                                    <tr>
                                        <th class="ps-4">Nombre</th>
                                        <th>Descripción</th>
                                        <th class="text-end pe-4">Acciones</th>
                                    </tr>

                                </thead>

                                <tbody>

                                <?php foreach ($categorias as $categoria): ?>

                                    <tr>

                                        <td class="ps-4 fw-semibold">
                                            <?= htmlspecialchars(
                                                (string)(
                                                    $categoria['nombre']
                                                    ?? '-'
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>

                                        <td class="text-muted">
                                            <?= htmlspecialchars(
                                                (string)(
                                                    $categoria['descripcion']
                                                    ?? ''
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>

                                        <td class="text-end pe-4">

                                            <button
                                                type="button"
                                                class="btn btn-sm btn-outline-primary"
                                            >
                                                <i class="fa-solid fa-pen"></i>
                                            </button>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</div>