<?php
$summary = $resumen ?? [];
$insumos = $insumos ?? [];
$stockBajo = $stockBajo ?? [];
$sinStock = $sinStock ?? [];
$movimientos = $movimientos ?? [];
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

        <div>
            <div class="d-flex align-items-center gap-2">
                <div class="text-primary fs-3">
                    <i class="fa-solid fa-boxes-stacked"></i>
                </div>

                <div>
                    <h1 class="h3 fw-bold mb-0">
                        Productos / Stock
                    </h1>

                    <div class="text-muted small">
                        Gestión de productos, existencias y movimientos de inventario.
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2 flex-wrap">

            <a href="/inventario/insumos/crear"
               class="btn btn-primary">

                <i class="fa-solid fa-plus me-1"></i>
                Nuevo producto

            </a>

            <a href="/inventario/stock"
               class="btn btn-outline-secondary">

                <i class="fa-solid fa-warehouse me-1"></i>
                Ver stock

            </a>

        </div>

    </div>


    <!-- INDICADORES -->

    <div class="row g-3 mb-4">

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>
                            <div class="text-muted small">
                                Productos
                            </div>

                            <div class="fs-3 fw-bold">
                                <?= number_format(
                                    (int)($summary['total_insumos'] ?? count($insumos)),
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </div>

                            <div class="text-muted small">
                                Productos activos
                            </div>
                        </div>

                        <div class="text-primary fs-2">
                            <i class="fa-solid fa-box"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>
                            <div class="text-muted small">
                                Stock bajo
                            </div>

                            <div class="fs-3 fw-bold">
                                <?= number_format(
                                    count($stockBajo),
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </div>

                            <div class="text-muted small">
                                Requieren reposición
                            </div>
                        </div>

                        <div class="text-warning fs-2">
                            <i class="fa-solid fa-triangle-exclamation"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>
                            <div class="text-muted small">
                                Sin stock
                            </div>

                            <div class="fs-3 fw-bold">
                                <?= number_format(
                                    count($sinStock),
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </div>

                            <div class="text-muted small">
                                Productos agotados
                            </div>
                        </div>

                        <div class="text-danger fs-2">
                            <i class="fa-solid fa-box-open"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm h-100">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>
                            <div class="text-muted small">
                                Movimientos
                            </div>

                            <div class="fs-3 fw-bold">
                                <?= number_format(
                                    count($movimientos),
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </div>

                            <div class="text-muted small">
                                Últimos movimientos
                            </div>
                        </div>

                        <div class="text-info fs-2">
                            <i class="fa-solid fa-arrow-right-arrow-left"></i>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ACCIONES -->

    <div class="mb-3">

        <h5 class="fw-bold mb-1">
            Gestión de inventario
        </h5>

        <div class="text-muted small">
            Accesos rápidos a las principales operaciones.
        </div>

    </div>


    <div class="row g-3 mb-4">

        <div class="col-12 col-md-6 col-xl-3">

            <a href="/inventario/insumos"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-primary fs-2 mb-3">
                            <i class="fa-solid fa-boxes-stacked"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Productos
                        </h6>

                        <div class="text-muted small">
                            Consultar y administrar productos.
                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-6 col-xl-3">

            <a href="/inventario/categorias"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-info fs-2 mb-3">
                            <i class="fa-solid fa-layer-group"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Categorías
                        </h6>

                        <div class="text-muted small">
                            Organizar productos por familias.
                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-6 col-xl-3">

            <a href="/inventario/marcas"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-success fs-2 mb-3">
                            <i class="fa-solid fa-tags"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Marcas
                        </h6>

                        <div class="text-muted small">
                            Administrar fabricantes y marcas.
                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-6 col-xl-3">

            <a href="/inventario/stock"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-4">

                        <div class="text-warning fs-2 mb-3">
                            <i class="fa-solid fa-warehouse"></i>
                        </div>

                        <h6 class="fw-bold text-dark">
                            Stock
                        </h6>

                        <div class="text-muted small">
                            Consultar existencias.
                        </div>

                    </div>

                </div>

            </a>

        </div>

    </div>


    <div class="row g-3 mb-4">

        <div class="col-12 col-md-4">

            <a href="/inventario/movimientos"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex gap-3 align-items-center">

                            <div class="text-primary fs-3">
                                <i class="fa-solid fa-arrow-right-arrow-left"></i>
                            </div>

                            <div>
                                <div class="fw-bold text-dark">
                                    Movimientos de stock
                                </div>

                                <div class="text-muted small">
                                    Entradas, salidas y transferencias.
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-4">

            <a href="/inventario/ajustes"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex gap-3 align-items-center">

                            <div class="text-warning fs-3">
                                <i class="fa-solid fa-sliders"></i>
                            </div>

                            <div>
                                <div class="fw-bold text-dark">
                                    Ajustes de stock
                                </div>

                                <div class="text-muted small">
                                    Correcciones de inventario.
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>


        <div class="col-12 col-md-4">

            <a href="/inventario/inventario"
               class="text-decoration-none">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body">

                        <div class="d-flex gap-3 align-items-center">

                            <div class="text-success fs-3">
                                <i class="fa-solid fa-clipboard-check"></i>
                            </div>

                            <div>
                                <div class="fw-bold text-dark">
                                    Inventario físico
                                </div>

                                <div class="text-muted small">
                                    Conteo y conciliación.
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </a>

        </div>

    </div>


    <!-- STOCK BAJO -->

    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white border-0 py-3">

            <div class="d-flex justify-content-between align-items-center">

                <div>
                    <h5 class="fw-bold mb-1">
                        Alertas de stock
                    </h5>

                    <div class="text-muted small">
                        Productos que requieren atención.
                    </div>
                </div>

                <a href="/inventario/stock"
                   class="btn btn-sm btn-outline-primary">
                    Ver stock
                </a>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (empty($stockBajo) && empty($sinStock)): ?>

                <div class="text-center py-5 text-muted">

                    <i class="fa-solid fa-circle-check fs-1 d-block mb-3"></i>

                    <div class="fw-semibold">
                        No hay alertas de stock.
                    </div>

                    <div class="small">
                        El inventario se encuentra dentro de los niveles configurados.
                    </div>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr>
                                <th class="ps-4">Producto</th>
                                <th>Código</th>
                                <th class="text-end">Stock</th>
                                <th class="text-end pe-4">Estado</th>
                            </tr>

                        </thead>

                        <tbody>

                        <?php
                        $alertas = array_merge(
                            $sinStock,
                            $stockBajo
                        );

                        $alertas = array_slice(
                            $alertas,
                            0,
                            10
                        );
                        ?>

                        <?php foreach ($alertas as $item): ?>

                            <?php
                            $stock = (float)(
                                $item['stock_actual']
                                ?? $item['stock']
                                ?? 0
                            );

                            $nombre = $item['nombre']
                                ?? $item['descripcion']
                                ?? 'Producto';

                            $codigo = $item['codigo']
                                ?? $item['sku']
                                ?? '-';
                            ?>

                            <tr>

                                <td class="ps-4 fw-semibold">
                                    <?= htmlspecialchars(
                                        (string)$nombre,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        (string)$codigo,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </td>

                                <td class="text-end">
                                    <?= number_format(
                                        $stock,
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                                <td class="text-end pe-4">

                                    <?php if ($stock <= 0): ?>

                                        <span class="badge bg-danger-subtle text-danger">
                                            Sin stock
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-warning-subtle text-warning-emphasis">
                                            Stock bajo
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>