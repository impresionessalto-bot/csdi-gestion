<?php

declare(strict_types=1);

namespace App\Modules\Inventario\Repositories;

use PDO;
use RuntimeException;
use Throwable;

final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function resumen(): array
    {
        $stmt = $this->db->query("
            SELECT

                COUNT(*) AS total_insumos,

                COALESCE(
                    SUM(stock_actual),
                    0
                ) AS unidades_totales,

                COALESCE(
                    SUM(
                        stock_actual * precio_costo
                    ),
                    0
                ) AS valorizacion_costo,

                COALESCE(
                    SUM(
                        stock_actual * precio_venta
                    ),
                    0
                ) AS valorizacion_venta,

                COALESCE(
                    SUM(
                        CASE
                            WHEN stock_actual <= stock_minimo
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS stock_bajo,

                COALESCE(
                    SUM(
                        CASE
                            WHEN stock_actual <= 0
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS sin_stock

            FROM insumos

            WHERE activo = 1
        ");

        return $stmt->fetch(
            PDO::FETCH_ASSOC
        ) ?: [];
    }

    public function estadisticas(): array
    {
        $stmt = $this->db->query("
            SELECT

                COUNT(*) AS total_insumos,

                COALESCE(
                    SUM(stock_actual),
                    0
                ) AS unidades_totales,

                COALESCE(
                    SUM(
                        stock_actual * precio_costo
                    ),
                    0
                ) AS valorizacion_costo,

                COALESCE(
                    SUM(
                        stock_actual * precio_venta
                    ),
                    0
                ) AS valorizacion_venta,

                COALESCE(
                    SUM(
                        CASE
                            WHEN stock_actual <= stock_minimo
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS stock_bajo,

                COALESCE(
                    SUM(
                        CASE
                            WHEN stock_actual <= 0
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS sin_stock,

                COALESCE(
                    SUM(
                        CASE
                            WHEN stock_maximo IS NOT NULL
                             AND stock_actual > stock_maximo
                            THEN 1
                            ELSE 0
                        END
                    ),
                    0
                ) AS sobre_stock

            FROM insumos

            WHERE activo = 1
        ");

        return $stmt->fetch(
            PDO::FETCH_ASSOC
        ) ?: [];
    }

    /*
    |--------------------------------------------------------------------------
    | INSUMOS
    |--------------------------------------------------------------------------
    */

    public function listar(
        array $filtros = []
    ): array {

        $sql = "
            SELECT
                i.*,

                c.nombre AS categoria_nombre,
                u.nombre AS unidad_medida_nombre,
                u.abreviatura AS unidad_medida_abreviatura,
                u.permite_decimales AS unidad_permite_decimales

            FROM insumos i

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            LEFT JOIN unidades_medida u
                ON u.id = i.unidad_medida_id

            WHERE 1 = 1
        ";

        $params = [];

        if (
            array_key_exists('activo', $filtros)
            && $filtros['activo'] !== null
            && $filtros['activo'] !== ''
        ) {
            $sql .= "
                AND i.activo = :activo
            ";

            $params[':activo'] =
                (int) $filtros['activo'];
        }

        if (
            isset($filtros['categoria_id'])
            && (int) $filtros['categoria_id'] > 0
        ) {
            $sql .= "
                AND i.categoria_id = :categoria_id
            ";

            $params[':categoria_id'] =
                (int) $filtros['categoria_id'];
        }

        if (!empty($filtros['marca'])) {

            $sql .= "
                AND i.marca LIKE :marca
            ";

            $params[':marca'] =
                '%' . trim(
                    (string) $filtros['marca']
                ) . '%';
        }

        if (
            isset($filtros['stock'])
            && $filtros['stock'] !== ''
        ) {

            switch (
                (string) $filtros['stock']
            ) {

                case 'sin_stock':

                    $sql .= "
                        AND i.stock_actual <= 0
                    ";

                    break;

                case 'bajo':

                    $sql .= "
                        AND i.stock_actual <= i.stock_minimo
                        AND i.stock_actual > 0
                    ";

                    break;

                case 'normal':

                    $sql .= "
                        AND i.stock_actual > i.stock_minimo
                    ";

                    break;

                case 'sobre':

                    $sql .= "
                        AND i.stock_maximo IS NOT NULL
                        AND i.stock_actual > i.stock_maximo
                    ";

                    break;
            }
        }

        if (!empty($filtros['buscar'])) {

            $sql .= "
                AND (
                    i.nombre_insumo LIKE :buscar
                    OR i.codigo_parte LIKE :buscar
                    OR i.codigo_barras LIKE :buscar
                    OR i.marca LIKE :buscar
                    OR i.modelo LIKE :buscar
                    OR i.subrubro LIKE :buscar
                )
            ";

            $params[':buscar'] =
                '%' . trim(
                    (string) $filtros['buscar']
                ) . '%';
        }

        $orden =
            (string) (
                $filtros['orden'] ?? 'nombre'
            );

        switch ($orden) {

            case 'stock_asc':
                $orderBy =
                    'i.stock_actual ASC, i.nombre_insumo ASC';
                break;

            case 'stock_desc':
                $orderBy =
                    'i.stock_actual DESC, i.nombre_insumo ASC';
                break;

            case 'costo_desc':
                $orderBy =
                    'i.precio_costo DESC, i.nombre_insumo ASC';
                break;

            case 'precio_desc':
                $orderBy =
                    'i.precio_venta DESC, i.nombre_insumo ASC';
                break;

            case 'id':
                $orderBy =
                    'i.id DESC';
                break;

            default:
                $orderBy =
                    'i.nombre_insumo ASC, i.id ASC';
                break;
        }

        $sql .= "
            ORDER BY {$orderBy}
        ";

        if (
            isset($filtros['limit'])
            && (int) $filtros['limit'] > 0
        ) {

            $limit = max(
                1,
                min(
                    1000,
                    (int) $filtros['limit']
                )
            );

            $sql .= "
                LIMIT {$limit}
            ";
        }

        $stmt = $this->db->prepare(
            $sql
        );

        $stmt->execute(
            $params
        );

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function buscar(
        string $termino,
        int $limit = 20
    ): array {

        $termino = trim($termino);

        if ($termino === '') {
            return [];
        }

        $limit = max(
            1,
            min(100, $limit)
        );

        $stmt = $this->db->prepare("
            SELECT

                i.id,
                i.nombre_insumo,
                i.codigo_parte,
                i.codigo_barras,
                i.marca,
                i.modelo,
                i.stock_actual,
                i.stock_minimo,
                i.stock_maximo,
                i.precio_costo,
                i.precio_venta,
                i.costo_compra,
                i.unidad_medida_id,
                u.nombre AS unidad_medida_nombre,
                u.abreviatura AS unidad_medida_abreviatura,
                u.permite_decimales AS unidad_permite_decimales

            FROM insumos i

            LEFT JOIN unidades_medida u ON u.id = i.unidad_medida_id

            WHERE i.activo = 1

              AND (
                    i.nombre_insumo LIKE :buscar
                    OR i.codigo_parte LIKE :buscar
                    OR i.codigo_barras LIKE :buscar
                    OR i.marca LIKE :buscar
                    OR i.modelo LIKE :buscar
                  )

            ORDER BY
                i.nombre_insumo ASC

            LIMIT {$limit}
        ");

        $stmt->execute([
            ':buscar' =>
                '%' . $termino . '%',
        ]);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function obtener(
        int $id
    ): ?array {

        $stmt = $this->db->prepare("
            SELECT

                i.*,

                c.nombre AS categoria_nombre,
                u.nombre AS unidad_medida_nombre,
                u.abreviatura AS unidad_medida_abreviatura,
                u.permite_decimales AS unidad_permite_decimales

            FROM insumos i

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            LEFT JOIN unidades_medida u
                ON u.id = i.unidad_medida_id

            WHERE i.id = :id

            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $id,
        ]);

        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        return $row ?: null;
    }

    public function crear(
        array $data
    ): int {

        $nombre = trim(
            (string) (
                $data['nombre_insumo'] ?? ''
            )
        );

        if ($nombre === '') {
            throw new RuntimeException(
                'El nombre del insumo es obligatorio.'
            );
        }

        $stmt = $this->db->prepare("
            INSERT INTO insumos (

                empresa_id,
                categoria_id,

                marca,
                modelo,

                activo,
                nombre_insumo,

                costo_compra,
                costo_compra_usd,
                cotizacion_usd_compra,

                rendimiento_estandar,

                stock_actual,

                codigo_parte,

                stock_minimo,
                stock_maximo,

                unidad_medida_id,

                precio_venta,
                precio_costo,

                rendimiento_copias,

                subrubro,
                codigo_barras

            ) VALUES (

                :empresa_id,
                :categoria_id,

                :marca,
                :modelo,

                :activo,
                :nombre_insumo,

                :costo_compra,
                :costo_compra_usd,
                :cotizacion_usd_compra,

                :rendimiento_estandar,

                0,

                :codigo_parte,

                :stock_minimo,
                :stock_maximo,

                :unidad_medida_id,

                :precio_venta,
                :precio_costo,

                :rendimiento_copias,

                :subrubro,
                :codigo_barras
            )
        ");

        $stmt->execute([

            ':empresa_id' =>
                (int) (
                    $data['empresa_id'] ?? 1
                ),

            ':categoria_id' =>
                !empty($data['categoria_id'])
                    ? (int) $data['categoria_id']
                    : null,

            ':marca' =>
                $this->nullableString(
                    $data['marca'] ?? null
                ),

            ':modelo' =>
                $this->nullableString(
                    $data['modelo'] ?? null
                ),

            ':activo' =>
                isset($data['activo'])
                    ? (int) $data['activo']
                    : 1,

            ':nombre_insumo' =>
                $nombre,

            ':costo_compra' =>
                (float) (
                    $data['costo_compra'] ?? 0
                ),

            ':costo_compra_usd' =>
                $this->nullableFloat(
                    $data['costo_compra_usd'] ?? null
                ),

            ':cotizacion_usd_compra' =>
                $this->nullableFloat(
                    $data['cotizacion_usd_compra'] ?? null
                ),

            ':rendimiento_estandar' =>
                (int) (
                    $data['rendimiento_estandar'] ?? 0
                ),

            ':codigo_parte' =>
                $this->nullableString(
                    $data['codigo_parte'] ?? null
                ),

            ':stock_minimo' =>
                (int) (
                    $data['stock_minimo'] ?? 0
                ),

            ':stock_maximo' =>
                $this->nullableInt(
                    $data['stock_maximo'] ?? null
                ),

            ':unidad_medida_id' =>
                (int)($data['unidad_medida_id'] ?? 1),

            ':precio_venta' =>
                (float) (
                    $data['precio_venta'] ?? 0
                ),

            ':precio_costo' =>
                (float) (
                    $data['precio_costo']
                    ?? $data['costo_compra']
                    ?? 0
                ),

            ':rendimiento_copias' =>
                (int) (
                    $data['rendimiento_copias'] ?? 0
                ),

            ':subrubro' =>
                $this->nullableString(
                    $data['subrubro'] ?? null
                ),

            ':codigo_barras' =>
                $this->nullableString(
                    $data['codigo_barras'] ?? null
                ),
        ]);

        return (int) $this->db->lastInsertId();
    }

    /**
     * Genera y persiste un código interno únicamente si el producto
     * todavía no tiene uno. Se ejecuta después del INSERT, cuando el ID
     * definitivo ya está disponible.
     */
    public function asignarCodigoAutomatico(int $id): bool
    {
        if ($id <= 0) {
            return false;
        }

        $codigo = 'INS-' . str_pad(
            (string)$id,
            6,
            '0',
            STR_PAD_LEFT
        );

        $stmt = $this->db->prepare("
            UPDATE insumos
            SET codigo_parte = :codigo
            WHERE id = :id
              AND (
                    codigo_parte IS NULL
                    OR TRIM(codigo_parte) = ''
                  )
        ");

        $stmt->execute([
            ':codigo' => $codigo,
            ':id' => $id,
        ]);

        return $stmt->rowCount() > 0;
    }

    public function actualizar(
        int $id,
        array $data
    ): bool {

        $nombre = trim(
            (string) (
                $data['nombre_insumo'] ?? ''
            )
        );

        if ($nombre === '') {
            throw new RuntimeException(
                'El nombre del insumo es obligatorio.'
            );
        }

        $stmt = $this->db->prepare("
            UPDATE insumos

            SET

                categoria_id = :categoria_id,

                marca = :marca,
                modelo = :modelo,

                nombre_insumo = :nombre_insumo,

                costo_compra = :costo_compra,
                costo_compra_usd = :costo_compra_usd,
                cotizacion_usd_compra = :cotizacion_usd_compra,

                rendimiento_estandar = :rendimiento_estandar,

                codigo_parte = :codigo_parte,

                stock_minimo = :stock_minimo,
                stock_maximo = :stock_maximo,

                unidad_medida_id = :unidad_medida_id,

                precio_venta = :precio_venta,
                precio_costo = :precio_costo,

                rendimiento_copias = :rendimiento_copias,

                subrubro = :subrubro,
                codigo_barras = :codigo_barras,

                activo = :activo

            WHERE id = :id
        ");

        return $stmt->execute([

            ':id' => $id,

            ':categoria_id' =>
                !empty($data['categoria_id'])
                    ? (int) $data['categoria_id']
                    : null,

            ':marca' =>
                $this->nullableString(
                    $data['marca'] ?? null
                ),

            ':modelo' =>
                $this->nullableString(
                    $data['modelo'] ?? null
                ),

            ':nombre_insumo' =>
                $nombre,

            ':costo_compra' =>
                (float) (
                    $data['costo_compra'] ?? 0
                ),

            ':costo_compra_usd' =>
                $this->nullableFloat(
                    $data['costo_compra_usd'] ?? null
                ),

            ':cotizacion_usd_compra' =>
                $this->nullableFloat(
                    $data['cotizacion_usd_compra'] ?? null
                ),

            ':rendimiento_estandar' =>
                (int) (
                    $data['rendimiento_estandar'] ?? 0
                ),

            ':codigo_parte' =>
                $this->nullableString(
                    $data['codigo_parte'] ?? null
                ),

            ':stock_minimo' =>
                (int) (
                    $data['stock_minimo'] ?? 0
                ),

            ':stock_maximo' =>
                $this->nullableInt(
                    $data['stock_maximo'] ?? null
                ),

            ':unidad_medida_id' =>
                (int)($data['unidad_medida_id'] ?? 1),

            ':precio_venta' =>
                (float) (
                    $data['precio_venta'] ?? 0
                ),

            ':precio_costo' =>
                (float) (
                    $data['precio_costo']
                    ?? $data['costo_compra']
                    ?? 0
                ),

            ':rendimiento_copias' =>
                (int) (
                    $data['rendimiento_copias'] ?? 0
                ),

            ':subrubro' =>
                $this->nullableString(
                    $data['subrubro'] ?? null
                ),

            ':codigo_barras' =>
                $this->nullableString(
                    $data['codigo_barras'] ?? null
                ),

            ':activo' =>
                isset($data['activo'])
                    ? (int) $data['activo']
                    : 1,
        ]);
    }

    public function eliminar(
        int $id
    ): bool {

        $stmt = $this->db->prepare("
            UPDATE insumos

            SET activo = 0

            WHERE id = :id
        ");

        $stmt->execute([
            ':id' => $id,
        ]);

        return $stmt->rowCount() > 0;
    }

    public function activar(
        int $id
    ): bool {

        $stmt = $this->db->prepare("
            UPDATE insumos

            SET activo = 1

            WHERE id = :id
        ");

        $stmt->execute([
            ':id' => $id,
        ]);

        return $stmt->rowCount() > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | STOCK
    |--------------------------------------------------------------------------
    */

    public function cambiarStock(
        int $insumoId,
        float $cantidad,
        string $tipo,
        ?int $usuarioId = null,
        ?int $clienteId = null,
        ?int $equipoId = null,
        ?int $servicioId = null,
        ?string $observacion = null,
        ?float $costoUnitario = null,
        ?string $comprobante = null
    ): array {

        $tipo = strtoupper(
            trim($tipo)
        );

        if (!in_array(
            $tipo,
            [
                'ENTRADA',
                'SALIDA',
                'AJUSTE'
            ],
            true
        )) {
            throw new RuntimeException(
                'Tipo de movimiento inválido.'
            );
        }

        if (
            $tipo !== 'AJUSTE'
            && $cantidad <= 0
        ) {
            throw new RuntimeException(
                'La cantidad debe ser mayor a cero.'
            );
        }

        if (
            $tipo === 'AJUSTE'
            && $cantidad === 0
        ) {
            throw new RuntimeException(
                'El ajuste no puede ser cero.'
            );
        }

        try {

            $this->db->beginTransaction();

            /*
            |--------------------------------------------------------------------------
            | BLOQUEAR ARTÍCULO
            |--------------------------------------------------------------------------
            */

            $stmt = $this->db->prepare("
                SELECT

                    id,
                    stock_actual,
                    precio_costo,
                    costo_compra,
                    precio_venta,
                    activo

                FROM insumos

                WHERE id = :id

                LIMIT 1

                FOR UPDATE
            ");

            $stmt->execute([
                ':id' => $insumoId,
            ]);

            $insumo =
                $stmt->fetch(
                    PDO::FETCH_ASSOC
                );

            if (!$insumo) {
                throw new RuntimeException(
                    'El insumo no existe.'
                );
            }

            if (!(bool) $insumo['activo']) {
                throw new RuntimeException(
                    'El insumo se encuentra inactivo.'
                );
            }

            $stockAnterior =
                (float) $insumo['stock_actual'];

            /*
            |--------------------------------------------------------------------------
            | CALCULAR STOCK
            |--------------------------------------------------------------------------
            */

            switch ($tipo) {

                case 'ENTRADA':

                    $cantidadMovimiento =
                        abs($cantidad);

                    $stockNuevo =
                        $stockAnterior
                        + $cantidadMovimiento;

                    break;

                case 'SALIDA':

                    $cantidadMovimiento =
                        abs($cantidad);

                    $stockNuevo =
                        $stockAnterior
                        - $cantidadMovimiento;

                    if ($stockNuevo < 0) {
                        throw new RuntimeException(
                            'Stock insuficiente. '
                            . 'Stock disponible: '
                            . $stockAnterior
                        );
                    }

                    break;

                case 'AJUSTE':

                    $cantidadMovimiento =
                        abs($cantidad);

                    $stockNuevo =
                        $stockAnterior
                        + $cantidad;

                    if ($stockNuevo < 0) {
                        throw new RuntimeException(
                            'El ajuste dejaría el stock '
                            . 'por debajo de cero.'
                        );
                    }

                    break;

                default:

                    throw new RuntimeException(
                        'Tipo de movimiento inválido.'
                    );
            }

            /*
            |--------------------------------------------------------------------------
            | COSTO
            |--------------------------------------------------------------------------
            */

            $costo =
                $costoUnitario !== null
                    ? $costoUnitario
                    : (float) (
                        $insumo['precio_costo']
                        ?? $insumo['costo_compra']
                        ?? 0
                    );

            /*
            |--------------------------------------------------------------------------
            | ACTUALIZAR STOCK
            |--------------------------------------------------------------------------
            */

            $stmt = $this->db->prepare("
                UPDATE insumos

                SET stock_actual = :stock

                WHERE id = :id
            ");

            $stmt->execute([
                ':stock' => $stockNuevo,
                ':id' => $insumoId,
            ]);

            /*
            |--------------------------------------------------------------------------
            | ENTRADA DE COMPRA
            |--------------------------------------------------------------------------
            |
            | Si conocemos el costo real de compra,
            | actualizamos el costo vigente del artículo.
            |
            */

            if (
                $tipo === 'ENTRADA'
                && $costoUnitario !== null
                && $costoUnitario >= 0
            ) {

                $stmt = $this->db->prepare("
                    UPDATE insumos

                    SET

                        costo_compra = :costo,
                        precio_costo = :costo

                    WHERE id = :id
                ");

                $stmt->execute([
                    ':costo' =>
                        $costoUnitario,

                    ':id' =>
                        $insumoId,
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | REGISTRAR MOVIMIENTO
            |--------------------------------------------------------------------------
            */

            $stmt = $this->db->prepare("
                INSERT INTO stock_movimientos (

                    insumo_id,
                    tipo,
                    cantidad,
                    fecha,

                    usuario_id,
                    cliente_id,
                    equipo_id,
                    servicio_id,

                    observacion,
                    costo_unitario,
                    nro_comprobante

                ) VALUES (

                    :insumo_id,
                    :tipo,
                    :cantidad,
                    NOW(),

                    :usuario_id,
                    :cliente_id,
                    :equipo_id,
                    :servicio_id,

                    :observacion,
                    :costo_unitario,
                    :nro_comprobante
                )
            ");

            $stmt->execute([

                ':insumo_id' =>
                    $insumoId,

                ':tipo' =>
                    $tipo,

                ':cantidad' =>
                    $cantidadMovimiento,

                ':usuario_id' =>
                    $usuarioId,

                ':cliente_id' =>
                    $clienteId,

                ':equipo_id' =>
                    $equipoId,

                ':servicio_id' =>
                    $servicioId,

                ':observacion' =>
                    $observacion,

                ':costo_unitario' =>
                    $costo,

                ':nro_comprobante' =>
                    $comprobante,
            ]);

            $movimientoId =
                (int) $this->db->lastInsertId();

            $this->db->commit();

            return [

                'movimiento_id' =>
                    $movimientoId,

                'insumo_id' =>
                    $insumoId,

                'stock_anterior' =>
                    $stockAnterior,

                'stock_nuevo' =>
                    $stockNuevo,

                'cantidad' =>
                    $cantidadMovimiento,

                'tipo' =>
                    $tipo,

                'costo_unitario' =>
                    $costo,
            ];

        } catch (Throwable $e) {

            if (
                $this->db->inTransaction()
            ) {
                $this->db->rollBack();
            }

            throw $e;
        }
    }

    public function entrada(
        int $insumoId,
        float $cantidad,
        ?float $costoUnitario = null,
        ?int $usuarioId = null,
        ?string $observacion = null,
        ?string $comprobante = null
    ): array {

        return $this->cambiarStock(
            $insumoId,
            $cantidad,
            'ENTRADA',
            $usuarioId,
            null,
            null,
            null,
            $observacion,
            $costoUnitario,
            $comprobante
        );
    }

    public function salida(
        int $insumoId,
        float $cantidad,
        ?int $usuarioId = null,
        ?int $clienteId = null,
        ?int $equipoId = null,
        ?int $servicioId = null,
        ?string $observacion = null,
        ?string $comprobante = null
    ): array {

        return $this->cambiarStock(
            $insumoId,
            $cantidad,
            'SALIDA',
            $usuarioId,
            $clienteId,
            $equipoId,
            $servicioId,
            $observacion,
            null,
            $comprobante
        );
    }

    public function ajustar(
        int $insumoId,
        float $cantidad,
        ?int $usuarioId = null,
        ?string $observacion = null
    ): array {

        return $this->cambiarStock(
            $insumoId,
            $cantidad,
            'AJUSTE',
            $usuarioId,
            null,
            null,
            null,
            $observacion,
            null,
            null
        );
    }

    /*
    |--------------------------------------------------------------------------
    | MOVIMIENTOS
    |--------------------------------------------------------------------------
    */

    public function movimientos(
        int $insumoId,
        array $filtros = []
    ): array {

        $sql = "
            SELECT

                sm.*,

                i.nombre_insumo,
                i.codigo_parte,

                c.nombre AS categoria_nombre

            FROM stock_movimientos sm

            INNER JOIN insumos i
                ON i.id = sm.insumo_id

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            WHERE sm.insumo_id = :insumo_id
        ";

        $params = [
            ':insumo_id' => $insumoId,
        ];

        if (!empty($filtros['tipo'])) {

            $tipo = strtoupper(
                trim(
                    (string) $filtros['tipo']
                )
            );

            if (in_array(
                $tipo,
                [
                    'ENTRADA',
                    'SALIDA',
                    'AJUSTE'
                ],
                true
            )) {

                $sql .= "
                    AND sm.tipo = :tipo
                ";

                $params[':tipo'] =
                    $tipo;
            }
        }

        if (!empty($filtros['desde'])) {

            $sql .= "
                AND DATE(sm.fecha) >= :desde
            ";

            $params[':desde'] =
                (string) $filtros['desde'];
        }

        if (!empty($filtros['hasta'])) {

            $sql .= "
                AND DATE(sm.fecha) <= :hasta
            ";

            $params[':hasta'] =
                (string) $filtros['hasta'];
        }

        $sql .= "
            ORDER BY
                sm.fecha DESC,
                sm.id DESC
        ";

        if (!empty($filtros['limit'])) {

            $limit = max(
                1,
                min(
                    500,
                    (int) $filtros['limit']
                )
            );

            $sql .= "
                LIMIT {$limit}
            ";
        }

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute(
            $params
        );

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function listarMovimientos(
        array $filtros = []
    ): array {

        $sql = "
            SELECT

                sm.*,

                i.nombre_insumo,
                i.codigo_parte,
                i.marca,
                i.modelo,

                c.nombre AS categoria_nombre

            FROM stock_movimientos sm

            INNER JOIN insumos i
                ON i.id = sm.insumo_id

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            WHERE 1 = 1
        ";

        $params = [];

        if (!empty($filtros['insumo_id'])) {

            $sql .= "
                AND sm.insumo_id = :insumo_id
            ";

            $params[':insumo_id'] =
                (int) $filtros['insumo_id'];
        }

        if (!empty($filtros['tipo'])) {

            $tipo = strtoupper(
                trim(
                    (string) $filtros['tipo']
                )
            );

            if (in_array(
                $tipo,
                [
                    'ENTRADA',
                    'SALIDA',
                    'AJUSTE'
                ],
                true
            )) {

                $sql .= "
                    AND sm.tipo = :tipo
                ";

                $params[':tipo'] =
                    $tipo;
            }
        }

        if (!empty($filtros['servicio_id'])) {

            $sql .= "
                AND sm.servicio_id = :servicio_id
            ";

            $params[':servicio_id'] =
                (int) $filtros['servicio_id'];
        }

        if (!empty($filtros['cliente_id'])) {

            $sql .= "
                AND sm.cliente_id = :cliente_id
            ";

            $params[':cliente_id'] =
                (int) $filtros['cliente_id'];
        }

        if (!empty($filtros['equipo_id'])) {

            $sql .= "
                AND sm.equipo_id = :equipo_id
            ";

            $params[':equipo_id'] =
                (int) $filtros['equipo_id'];
        }

        if (!empty($filtros['desde'])) {

            $sql .= "
                AND DATE(sm.fecha) >= :desde
            ";

            $params[':desde'] =
                (string) $filtros['desde'];
        }

        if (!empty($filtros['hasta'])) {

            $sql .= "
                AND DATE(sm.fecha) <= :hasta
            ";

            $params[':hasta'] =
                (string) $filtros['hasta'];
        }

        $sql .= "
            ORDER BY
                sm.fecha DESC,
                sm.id DESC
        ";

        if (!empty($filtros['limit'])) {

            $limit = max(
                1,
                min(
                    1000,
                    (int) $filtros['limit']
                )
            );

            $sql .= "
                LIMIT {$limit}
            ";
        }

        $stmt =
            $this->db->prepare($sql);

        $stmt->execute(
            $params
        );

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function ultimosMovimientos(
        int $limit = 10
    ): array {

        $limit = max(
            1,
            min(100, $limit)
        );

        $stmt = $this->db->query("
            SELECT

                sm.*,

                i.nombre_insumo,
                i.codigo_parte,

                c.nombre AS categoria_nombre

            FROM stock_movimientos sm

            INNER JOIN insumos i
                ON i.id = sm.insumo_id

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            ORDER BY
                sm.fecha DESC,
                sm.id DESC

            LIMIT {$limit}
        ");

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function obtenerMovimiento(
        int $id
    ): ?array {

        $stmt = $this->db->prepare("
            SELECT

                sm.*,

                i.nombre_insumo,
                i.codigo_parte,
                i.marca,
                i.modelo,

                c.nombre AS categoria_nombre

            FROM stock_movimientos sm

            INNER JOIN insumos i
                ON i.id = sm.insumo_id

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            WHERE sm.id = :id

            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $id,
        ]);

        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        return $row ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | ALERTAS
    |--------------------------------------------------------------------------
    */

    public function stockBajo(): array
    {
        $stmt = $this->db->query("
            SELECT

                i.*,

                c.nombre AS categoria_nombre

            FROM insumos i

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            WHERE i.activo = 1

              AND i.stock_actual <= i.stock_minimo

              AND i.stock_actual > 0

            ORDER BY
                i.stock_actual ASC,
                i.nombre_insumo ASC
        ");

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function sinStock(): array
    {
        $stmt = $this->db->query("
            SELECT

                i.*,

                c.nombre AS categoria_nombre

            FROM insumos i

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            WHERE i.activo = 1

              AND i.stock_actual <= 0

            ORDER BY
                i.nombre_insumo ASC
        ");

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function sobreStock(): array
    {
        $stmt = $this->db->query("
            SELECT

                i.*,

                c.nombre AS categoria_nombre

            FROM insumos i

            LEFT JOIN categorias_productos c
                ON c.id = i.categoria_id

            WHERE i.activo = 1

              AND i.stock_maximo IS NOT NULL

              AND i.stock_actual > i.stock_maximo

            ORDER BY
                i.stock_actual DESC,
                i.nombre_insumo ASC
        ");

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CATEGORÍAS
    |--------------------------------------------------------------------------
    */

    public function categorias(): array
    {
        $stmt = $this->db->query("
            SELECT

                id,
                nombre,
                descripcion,
                activo

            FROM categorias_productos

            WHERE activo = 1

            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function obtenerCategoria(
        int $id
    ): ?array {

        $stmt = $this->db->prepare("
            SELECT

                id,
                nombre,
                descripcion,
                activo

            FROM categorias_productos

            WHERE id = :id

            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $id,
        ]);

        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        return $row ?: null;
    }

    public function estadisticasCategorias(): array
    {
        $stmt = $this->db->query("
            SELECT

                c.id,
                c.nombre,

                COUNT(i.id)
                    AS cantidad_insumos,

                COALESCE(
                    SUM(i.stock_actual),
                    0
                ) AS unidades,

                COALESCE(
                    SUM(
                        i.stock_actual
                        * i.precio_costo
                    ),
                    0
                ) AS valorizacion_costo

            FROM categorias_productos c

            LEFT JOIN insumos i
                ON i.categoria_id = c.id
                AND i.activo = 1

            WHERE c.activo = 1

            GROUP BY
                c.id,
                c.nombre

            ORDER BY
                c.nombre ASC
        ");

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CONSUMO
    |--------------------------------------------------------------------------
    */

    public function consumoPorServicio(
        int $servicioId
    ): array {

        $stmt = $this->db->prepare("
            SELECT

                sm.*,

                i.nombre_insumo,
                i.codigo_parte,
                i.marca,
                i.modelo,

                (
                    sm.cantidad
                    * sm.costo_unitario
                ) AS costo_total

            FROM stock_movimientos sm

            INNER JOIN insumos i
                ON i.id = sm.insumo_id

            WHERE sm.servicio_id = :servicio_id

              AND sm.tipo = 'SALIDA'

            ORDER BY
                sm.fecha ASC,
                sm.id ASC
        ");

        $stmt->execute([
            ':servicio_id' =>
                $servicioId,
        ]);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    public function consumoPorInsumo(
        int $insumoId
    ): array {

        $stmt = $this->db->prepare("
            SELECT

                COALESCE(
                    SUM(
                        CASE
                            WHEN tipo = 'SALIDA'
                            THEN cantidad
                            ELSE 0
                        END
                    ),
                    0
                ) AS unidades_consumidas,

                COALESCE(
                    SUM(
                        CASE
                            WHEN tipo = 'SALIDA'
                            THEN cantidad
                            * costo_unitario
                            ELSE 0
                        END
                    ),
                    0
                ) AS costo_consumo

            FROM stock_movimientos

            WHERE insumo_id = :insumo_id
        ");

        $stmt->execute([
            ':insumo_id' =>
                $insumoId,
        ]);

        return $stmt->fetch(
            PDO::FETCH_ASSOC
        ) ?: [];
    }

    /*
    |--------------------------------------------------------------------------
    | DEPÓSITOS
    |--------------------------------------------------------------------------
    */

    public function depositos(bool $soloActivos = true): array
    {
        $sql = "SELECT id, codigo, nombre, direccion, activo, created_at, updated_at
                FROM depositos";
        if ($soloActivos) {
            $sql .= " WHERE activo = 1";
        }
        $sql .= " ORDER BY activo DESC, nombre ASC";

        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerDeposito(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT id, codigo, nombre, direccion, activo, created_at, updated_at FROM depositos WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function existeDepositoNombre(string $nombre, ?int $exceptoId = null): bool
    {
        $sql = "SELECT COUNT(*) FROM depositos WHERE LOWER(nombre) = LOWER(:nombre)";
        $params = [':nombre' => $nombre];
        if ($exceptoId !== null) {
            $sql .= " AND id <> :id";
            $params[':id'] = $exceptoId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function existeDepositoCodigo(string $codigo, ?int $exceptoId = null): bool
    {
        $sql = "SELECT COUNT(*) FROM depositos WHERE LOWER(codigo) = LOWER(:codigo)";
        $params = [':codigo' => $codigo];
        if ($exceptoId !== null) {
            $sql .= " AND id <> :id";
            $params[':id'] = $exceptoId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function crearDeposito(array $data): int
    {
        $stmt = $this->db->prepare("INSERT INTO depositos (codigo, nombre, direccion, activo) VALUES (:codigo, :nombre, :direccion, 1)");
        $stmt->execute([
            ':codigo' => $data['codigo'],
            ':nombre' => $data['nombre'],
            ':direccion' => $data['direccion'] ?? null,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function actualizarDeposito(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("UPDATE depositos SET codigo=:codigo, nombre=:nombre, direccion=:direccion, activo=:activo WHERE id=:id");
        $stmt->execute([
            ':id' => $id,
            ':codigo' => $data['codigo'],
            ':nombre' => $data['nombre'],
            ':direccion' => $data['direccion'] ?? null,
            ':activo' => (int)$data['activo'],
        ]);
        return $stmt->rowCount() > 0;
    }

    public function desactivarDeposito(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE depositos SET activo = 0 WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount() > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | UNIDADES DE MEDIDA
    |--------------------------------------------------------------------------
    */

    public function unidadesMedida(bool $soloActivas = true): array
    {
        $sql = "SELECT id, nombre, abreviatura, permite_decimales, activo FROM unidades_medida";
        if ($soloActivas) $sql .= " WHERE activo = 1";
        $sql .= " ORDER BY nombre ASC";
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerUnidadMedida(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM unidades_medida WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function crearUnidadMedida(array $data): int
    {
        try {
            $stmt = $this->db->prepare("INSERT INTO unidades_medida (nombre, abreviatura, permite_decimales, activo) VALUES (:nombre, :abreviatura, :decimales, 1)");
            $stmt->execute([':nombre'=>$data['nombre'], ':abreviatura'=>$data['abreviatura'], ':decimales'=>$data['permite_decimales']]);
            return (int)$this->db->lastInsertId();
        } catch (Throwable $e) {
            throw new RuntimeException('No se pudo crear la unidad de medida.', 0, $e);
        }
    }

    public function actualizarUnidadMedida(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("UPDATE unidades_medida SET nombre=:nombre, abreviatura=:abreviatura, permite_decimales=:decimales, activo=:activo WHERE id=:id");
        return $stmt->execute([':id'=>$id, ':nombre'=>$data['nombre'], ':abreviatura'=>$data['abreviatura'], ':decimales'=>$data['permite_decimales'], ':activo'=>$data['activo']]);
    }

    public function unidadMedidaEnUso(int $id): bool
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM insumos WHERE unidad_medida_id = :id");
        $stmt->execute([':id'=>$id]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function desactivarUnidadMedida(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE unidades_medida SET activo = 0 WHERE id = :id");
        $stmt->execute([':id'=>$id]);
        return $stmt->rowCount() > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS
    |--------------------------------------------------------------------------
    */

    private function nullableString(
        mixed $value
    ): ?string {

        if (
            $value === null
            || trim((string) $value) === ''
        ) {
            return null;
        }

        return trim(
            (string) $value
        );
    }

    private function nullableFloat(
        mixed $value
    ): ?float {

        if (
            $value === null
            || $value === ''
        ) {
            return null;
        }

        return (float) $value;
    }

    private function nullableInt(
        mixed $value
    ): ?int {

        if (
            $value === null
            || $value === ''
        ) {
            return null;
        }

        return (int) $value;
    }
}