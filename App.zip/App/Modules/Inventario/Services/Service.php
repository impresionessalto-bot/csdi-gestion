<?php

declare(strict_types=1);

namespace App\Modules\Inventario\Services;

use App\Modules\Inventario\Repositories\Repository;
use InvalidArgumentException;

final class Service
{
    public function __construct(
        private readonly Repository $repository
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD
    |--------------------------------------------------------------------------
    */

    public function dashboard(): array
    {
        return [
            'resumen' =>
                $this->repository->resumen(),

            'stock_bajo' =>
                $this->repository->stockBajo(),

            'ultimos_movimientos' =>
                $this->repository->ultimosMovimientos(10),

            'categorias' =>
                $this->repository->categorias(),

            'estadisticas_categorias' =>
                $this->repository->estadisticasCategorias(),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | INSUMOS
    |--------------------------------------------------------------------------
    */

    public function listar(
        array $filtros = []
    ): array {
        return $this->repository->listar($filtros);
    }

    public function buscar(
        string $termino,
        int $limit = 20
    ): array {

        return $this->repository->buscar(
            $termino,
            $limit
        );
    }

    public function obtener(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }

        return $this->repository->obtener($id);
    }

    public function crear(
        array $data
    ): int {

        $nombre = trim(
            (string) (
                $data['nombre_insumo'] ?? ''
            )
        );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El nombre del insumo es obligatorio.'
            );
        }

        /*
         * Un artículo nuevo siempre comienza
         * con stock 0.
         *
         * El stock entra mediante una operación
         * de compra/entrada.
         */

        $data['stock_actual'] = 0;

        // El código interno es opcional al cargar el producto.
        // Si no se informa, se genera automáticamente a partir del ID.
        $id = $this->repository->crear(
            $data
        );

        $codigo = trim((string)($data['codigo_parte'] ?? ''));

        if ($codigo === '') {
            $this->repository->asignarCodigoAutomatico($id);
        }

        return $id;
    }

    public function actualizar(
        int $id,
        array $data
    ): bool {

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de insumo inválido.'
            );
        }

        $existente = $this->repository->obtener($id);

        if (!$existente) {
            throw new InvalidArgumentException(
                'El insumo no existe.'
            );
        }

        // Los registros históricos que no tenían código reciben uno
        // automáticamente. Si el formulario llega vacío, tampoco
        // permitimos que se pierda un código ya existente.
        $codigoExistente = trim((string)($existente['codigo_parte'] ?? ''));
        $codigoRecibido = trim((string)($data['codigo_parte'] ?? ''));

        if ($codigoRecibido === '') {
            $data['codigo_parte'] = $codigoExistente !== ''
                ? $codigoExistente
                : $this->codigoAutomatico($id);
        }

        $nombre = trim(
            (string) (
                $data['nombre_insumo'] ?? ''
            )
        );

        if ($nombre === '') {
            throw new InvalidArgumentException(
                'El nombre del insumo es obligatorio.'
            );
        }

        /*
         * El stock jamás se modifica desde editar artículo.
         */

        unset($data['stock_actual']);

        return $this->repository->actualizar(
            $id,
            $data
        );
    }

    public function eliminar(
        int $id
    ): bool {

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de insumo inválido.'
            );
        }

        return $this->repository->eliminar(
            $id
        );
    }

    public function activar(
        int $id
    ): bool {

        if ($id <= 0) {
            throw new InvalidArgumentException(
                'ID de insumo inválido.'
            );
        }

        return $this->repository->activar(
            $id
        );
    }

    /*
    |--------------------------------------------------------------------------
    | COMPRAS / ENTRADAS
    |--------------------------------------------------------------------------
    |
    | Esta es la primera puerta del embudo.
    |
    | Futuramente:
    |
    | Compra
    |   ↓
    | Recepción
    |   ↓
    | Entrada inventario
    |   ↓
    | Actualización costo
    |
    */

    public function entrada(
        int $insumoId,
        float $cantidad,
        ?float $costoUnitario = null,
        ?int $usuarioId = null,
        ?string $observacion = null,
        ?string $comprobante = null
    ): array {

        $this->validarMovimiento(
            $insumoId,
            $cantidad
        );

        if (
            $costoUnitario !== null
            && $costoUnitario < 0
        ) {
            throw new InvalidArgumentException(
                'El costo unitario no puede ser negativo.'
            );
        }

        return $this->repository->entrada(
            $insumoId,
            $cantidad,
            $costoUnitario,
            $usuarioId,
            $observacion,
            $comprobante
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VENTAS / SALIDAS
    |--------------------------------------------------------------------------
    |
    | Segunda puerta del embudo.
    |
    | Venta
    |   ↓
    | Salida inventario
    |   ↓
    | Cliente
    |   ↓
    | Facturación
    |
    */

    public function salida(
        int $insumoId,
        float $cantidad,
        ?int $usuarioId = null,
        ?int $clienteId = null,
        ?int $equipoId = null,
        ?int $servicioId = null,
        ?string $observacion = null,
        ?string $comprobante = null
    ): array {

        $this->validarMovimiento(
            $insumoId,
            $cantidad
        );

        return $this->repository->salida(
            $insumoId,
            $cantidad,
            $usuarioId,
            $clienteId,
            $equipoId,
            $servicioId,
            $observacion,
            $comprobante
        );
    }

    /*
    |--------------------------------------------------------------------------
    | AJUSTE
    |--------------------------------------------------------------------------
    */

    public function ajustar(
        int $insumoId,
        float $cantidad,
        ?int $usuarioId = null,
        ?string $observacion = null
    ): array {

        if ($insumoId <= 0) {
            throw new InvalidArgumentException(
                'Insumo inválido.'
            );
        }

        if ($cantidad === 0) {
            throw new InvalidArgumentException(
                'El ajuste no puede ser cero.'
            );
        }

        return $this->repository->ajustar(
            $insumoId,
            $cantidad,
            $usuarioId,
            $observacion
        );
    }

    /*
    |--------------------------------------------------------------------------
    | MOVIMIENTOS
    |--------------------------------------------------------------------------
    */

    public function movimientos(
        int $id,
        array $filtros = []
    ): array {

        if ($id <= 0) {
            return [];
        }

        return $this->repository->movimientos(
            $id,
            $filtros
        );
    }

    public function listarMovimientos(
        array $filtros = []
    ): array {

        return $this->repository->listarMovimientos(
            $filtros
        );
    }

    public function obtenerMovimiento(
        int $id
    ): ?array {

        if ($id <= 0) {
            return null;
        }

        return $this->repository->obtenerMovimiento(
            $id
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ALERTAS
    |--------------------------------------------------------------------------
    */

    public function stockBajo(): array
    {
        return $this->repository->stockBajo();
    }

    public function sinStock(): array
    {
        return $this->repository->sinStock();
    }

    public function sobreStock(): array
    {
        return $this->repository->sobreStock();
    }

    /*
    |--------------------------------------------------------------------------
    | CATEGORÍAS
    |--------------------------------------------------------------------------
    */

    public function categorias(): array
    {
        return $this->repository->categorias();
    }

    /*
    |--------------------------------------------------------------------------
    | CONSUMO
    |--------------------------------------------------------------------------
    */

    public function consumoPorServicio(
        int $servicioId
    ): array {

        if ($servicioId <= 0) {
            return [];
        }

        return $this->repository->consumoPorServicio(
            $servicioId
        );
    }

    public function consumoPorInsumo(
        int $insumoId
    ): array {

        if ($insumoId <= 0) {
            return [];
        }

        return $this->repository->consumoPorInsumo(
            $insumoId
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DEPÓSITOS
    |--------------------------------------------------------------------------
    */

    public function depositos(bool $soloActivos = true): array
    {
        return $this->repository->depositos($soloActivos);
    }

    public function obtenerDeposito(int $id): ?array
    {
        return $id > 0 ? $this->repository->obtenerDeposito($id) : null;
    }

    public function crearDeposito(array $data): int
    {
        $nombre = trim((string)($data['nombre'] ?? ''));
        $codigo = strtoupper(trim((string)($data['codigo'] ?? '')));
        $direccion = trim((string)($data['direccion'] ?? ''));

        if ($nombre === '') {
            throw new InvalidArgumentException('El nombre del depósito es obligatorio.');
        }
        if (mb_strlen($nombre) > 150) {
            throw new InvalidArgumentException('El nombre del depósito no puede superar los 150 caracteres.');
        }
        if ($codigo === '') {
            $codigo = $this->generarCodigoDeposito();
        }
        if (!preg_match('/^[A-Z0-9][A-Z0-9._-]{1,19}$/', $codigo)) {
            throw new InvalidArgumentException('El código del depósito solo puede contener letras, números, punto, guion y guion bajo (2 a 20 caracteres).');
        }
        if ($this->repository->existeDepositoNombre($nombre)) {
            throw new InvalidArgumentException('Ya existe un depósito con ese nombre.');
        }
        if ($this->repository->existeDepositoCodigo($codigo)) {
            throw new InvalidArgumentException('Ya existe un depósito con ese código.');
        }

        return $this->repository->crearDeposito([
            'codigo' => $codigo,
            'nombre' => $nombre,
            'direccion' => $direccion !== '' ? $direccion : null,
        ]);
    }

    public function actualizarDeposito(int $id, array $data): bool
    {
        if ($id <= 0 || !$this->repository->obtenerDeposito($id)) {
            throw new InvalidArgumentException('Depósito inválido o inexistente.');
        }

        $nombre = trim((string)($data['nombre'] ?? ''));
        $codigo = strtoupper(trim((string)($data['codigo'] ?? '')));
        $direccion = trim((string)($data['direccion'] ?? ''));
        $activo = !empty($data['activo']) ? 1 : 0;

        if ($nombre === '') {
            throw new InvalidArgumentException('El nombre del depósito es obligatorio.');
        }
        if ($codigo === '') {
            throw new InvalidArgumentException('El código del depósito es obligatorio al editar.');
        }
        if (!preg_match('/^[A-Z0-9][A-Z0-9._-]{1,19}$/', $codigo)) {
            throw new InvalidArgumentException('El código del depósito no es válido.');
        }
        if ($this->repository->existeDepositoNombre($nombre, $id)) {
            throw new InvalidArgumentException('Ya existe otro depósito con ese nombre.');
        }
        if ($this->repository->existeDepositoCodigo($codigo, $id)) {
            throw new InvalidArgumentException('Ya existe otro depósito con ese código.');
        }

        return $this->repository->actualizarDeposito($id, [
            'codigo' => $codigo,
            'nombre' => $nombre,
            'direccion' => $direccion !== '' ? $direccion : null,
            'activo' => $activo,
        ]);
    }

    public function eliminarDeposito(int $id): bool
    {
        if ($id <= 0 || !$this->repository->obtenerDeposito($id)) {
            throw new InvalidArgumentException('Depósito inválido o inexistente.');
        }
        return $this->repository->desactivarDeposito($id);
    }

    private function generarCodigoDeposito(): string
    {
        do {
            $codigo = 'DEP-' . strtoupper(bin2hex(random_bytes(3)));
        } while ($this->repository->existeDepositoCodigo($codigo));
        return $codigo;
    }

    /*
    |--------------------------------------------------------------------------
    | UNIDADES DE MEDIDA
    |--------------------------------------------------------------------------
    */

    public function unidadesMedida(bool $soloActivas = true): array
    {
        return $this->repository->unidadesMedida($soloActivas);
    }

    public function obtenerUnidadMedida(int $id): ?array
    {
        return $id > 0 ? $this->repository->obtenerUnidadMedida($id) : null;
    }

    public function crearUnidadMedida(array $data): int
    {
        $nombre = trim((string)($data['nombre'] ?? ''));
        $abreviatura = trim((string)($data['abreviatura'] ?? ''));
        if ($nombre === '' || $abreviatura === '') {
            throw new InvalidArgumentException('Nombre y abreviatura son obligatorios.');
        }
        return $this->repository->crearUnidadMedida([
            'nombre' => $nombre,
            'abreviatura' => $abreviatura,
            'permite_decimales' => !empty($data['permite_decimales']) ? 1 : 0,
        ]);
    }

    public function actualizarUnidadMedida(int $id, array $data): bool
    {
        if ($id <= 0 || !$this->repository->obtenerUnidadMedida($id)) {
            throw new InvalidArgumentException('Unidad de medida inválida.');
        }
        $nombre = trim((string)($data['nombre'] ?? ''));
        $abreviatura = trim((string)($data['abreviatura'] ?? ''));
        if ($nombre === '' || $abreviatura === '') {
            throw new InvalidArgumentException('Nombre y abreviatura son obligatorios.');
        }
        return $this->repository->actualizarUnidadMedida($id, [
            'nombre' => $nombre,
            'abreviatura' => $abreviatura,
            'permite_decimales' => !empty($data['permite_decimales']) ? 1 : 0,
            'activo' => isset($data['activo']) ? (int)(bool)$data['activo'] : 1,
        ]);
    }

    public function eliminarUnidadMedida(int $id): bool
    {
        if ($id <= 0) throw new InvalidArgumentException('Unidad de medida inválida.');
        if ($this->repository->unidadMedidaEnUso($id)) {
            throw new InvalidArgumentException('No se puede desactivar una unidad de medida utilizada por insumos.');
        }
        return $this->repository->desactivarUnidadMedida($id);
    }

    /**
     * Código interno estándar para insumos sin código informado.
     */
    private function codigoAutomatico(int $id): string
    {
        return 'INS-' . str_pad(
            (string)$id,
            6,
            '0',
            STR_PAD_LEFT
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDACIONES
    |--------------------------------------------------------------------------
    */

    private function validarMovimiento(
        int $insumoId,
        float $cantidad
    ): void {

        if ($insumoId <= 0) {
            throw new InvalidArgumentException(
                'Debe indicar un insumo válido.'
            );
        }

        if ($cantidad <= 0) {
            throw new InvalidArgumentException(
                'La cantidad debe ser mayor que cero.'
            );
        }

        $insumo = $this->repository->obtener($insumoId);
        if (!$insumo) {
            throw new InvalidArgumentException('El insumo no existe.');
        }

        $permiteDecimales = (bool)($insumo['unidad_permite_decimales'] ?? false);
        if (!$permiteDecimales && floor($cantidad) !== $cantidad) {
            throw new InvalidArgumentException(
                'La unidad de medida de este insumo no permite cantidades decimales.'
            );
        }
    }
}