<?php

declare(strict_types=1);

namespace App\Modules\Informes_tng\Repositories;

use PDO;
use PDOException;
use Throwable;

/**
 * ============================================================================
 * CSDI PRO
 * INFORMES TNG - REPOSITORY
 * ============================================================================
 *
 * Responsabilidad exclusiva:
 *
 * - SQL del módulo Informes TNG.
 * - Persistencia de informes.
 * - Persistencia de talonarios.
 * - Estadísticas.
 * - Consultas de historial.
 * - Consultas de números utilizados.
 *
 * NO contiene:
 *
 * - lógica de negocio;
 * - HTML;
 * - sesiones;
 * - CSRF;
 * - archivos;
 * - auditoría;
 * - servicios externos;
 * - LocalidadService;
 * - ClienteService;
 * - EquipoService.
 *
 * Arquitectura:
 *
 * Controller
 *      ↓
 * Service
 *      ↓
 * Repository
 *      ↓
 * PDO / Database
 *
 * ============================================================================
 */
final class Repository
{
    public function __construct(
        private readonly PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS PDO
    |--------------------------------------------------------------------------
    */

    /**
     * Ejecuta un SELECT y devuelve todas las filas.
     *
     * @return array<int,array<string,mixed>>
     */
    private function fetchAll(
        string $sql,
        array $params = []
    ): array {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return is_array($rows)
                ? $rows
                : [];
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Repository fetchAll] '
                . $e->getMessage()
            );

            throw $e;
        }
    }

    /**
     * Ejecuta un SELECT y devuelve una sola fila.
     *
     * @return array<string,mixed>|null
     */
    private function fetchOne(
        string $sql,
        array $params = []
    ): ?array {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            return $row !== false
                ? $row
                : null;
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Repository fetchOne] '
                . $e->getMessage()
            );

            throw $e;
        }
    }

    /**
     * Ejecuta una consulta y devuelve un único valor.
     */
    private function fetchColumn(
        string $sql,
        array $params = []
    ): mixed {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchColumn();
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Repository fetchColumn] '
                . $e->getMessage()
            );

            throw $e;
        }
    }

    /**
     * Ejecuta INSERT / UPDATE / DELETE.
     */
    private function execute(
        string $sql,
        array $params = []
    ): bool {
        try {
            $stmt = $this->db->prepare($sql);

            return $stmt->execute($params);
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Repository execute] '
                . $e->getMessage()
            );

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS
    |--------------------------------------------------------------------------
    */

    /**
     * Total de clientes con informes TNG.
     */
    public function totalClientes(): int
    {
        return (int)$this->fetchColumn(
            "
            SELECT COUNT(DISTINCT cliente_id)
            FROM historial_informes
            WHERE cliente_id IS NOT NULL
              AND cliente_id > 0
            "
        );
    }

    /**
     * Total de equipos con informes TNG.
     */
    public function totalEquipos(): int
    {
        return (int)$this->fetchColumn(
            "
            SELECT COUNT(DISTINCT equipo_id)
            FROM historial_informes
            WHERE equipo_id IS NOT NULL
              AND equipo_id > 0
            "
        );
    }

    /**
     * Total general de informes.
     */
    public function totalInformes(): int
    {
        return (int)$this->fetchColumn(
            "
            SELECT COUNT(*)
            FROM historial_informes
            "
        );
    }

    /**
     * Total de informes pendientes.
     */
    public function pendientes(): int
    {
        return (int)$this->fetchColumn(
            "
            SELECT COUNT(*)
            FROM historial_informes
            WHERE estado = 'PENDIENTE'
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES DISPONIBLES
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve números de informe libres dentro de los talonarios TNG.
     *
     * @return array<int,array<string,mixed>>
     */
    public function informesDisponibles(
        int $limite = 500
    ): array {
        $limite = max(
            1,
            min($limite, 5000)
        );

        /*
         * Talonarios pertenecientes a TNG.
         */
        $talonarios = $this->fetchAll(
            "
            SELECT
                id,
                nombre,
                num_desde,
                num_hasta
            FROM talonarios
            WHERE propiedad = 'TNG'
              AND num_desde IS NOT NULL
              AND num_hasta IS NOT NULL
              AND num_desde > 0
              AND num_hasta >= num_desde
            ORDER BY
                num_desde ASC,
                id ASC
            "
        );

        if ($talonarios === []) {
            return [];
        }

        /*
         * Números ya utilizados.
         */
        $usados = $this->fetchAll(
            "
            SELECT
                nro_informe
            FROM historial_informes
            WHERE nro_informe IS NOT NULL
              AND TRIM(nro_informe) <> ''
            "
        );

        $ocupados = [];

        foreach ($usados as $row) {
            $numero = trim(
                (string)($row['nro_informe'] ?? '')
            );

            if ($numero !== '') {
                $ocupados[$numero] = true;
            }
        }

        $resultado = [];

        foreach ($talonarios as $talonario) {

            if (count($resultado) >= $limite) {
                break;
            }

            $desde = (int)(
                $talonario['num_desde'] ?? 0
            );

            $hasta = (int)(
                $talonario['num_hasta'] ?? 0
            );

            if (
                $desde <= 0
                || $hasta < $desde
            ) {
                continue;
            }

            /*
             * Protección contra rangos absurdamente grandes.
             */
            if (($hasta - $desde) > 100000) {
                continue;
            }

            for (
                $numero = $desde;
                $numero <= $hasta;
                $numero++
            ) {
                if (count($resultado) >= $limite) {
                    break 2;
                }

                $key = (string)$numero;

                if (isset($ocupados[$key])) {
                    continue;
                }

                $resultado[] = [
                    'numero' => $numero,

                    'nro_informe' => $numero,

                    'talonario_id' => (int)(
                        $talonario['id'] ?? 0
                    ),

                    'talonario' => trim(
                        (string)(
                            $talonario['nombre'] ?? ''
                        )
                    ),
                ];
            }
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL
    |--------------------------------------------------------------------------
    */

    /**
     * Últimos informes.
     *
     * @return array<int,array<string,mixed>>
     */
    public function ultimos(
        int $limite = 100
    ): array {
        $limite = max(
            1,
            min($limite, 1000)
        );

        return $this->fetchAll(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            ORDER BY
                hi.fecha DESC,
                hi.id DESC

            LIMIT {$limite}
            "
        );
    }

    /**
     * Buscar informe por ID.
     */
    public function buscar(
        int $id
    ): ?array {
        if ($id <= 0) {
            return null;
        }

        return $this->fetchOne(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE hi.id = :id

            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORME POR NÚMERO
    |--------------------------------------------------------------------------
    */

    /**
     * Busca un informe por número.
     */
    public function buscarPorNumero(
        string $numero
    ): ?array {
        $numero = trim($numero);

        if ($numero === '') {
            return null;
        }

        return $this->fetchOne(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE hi.nro_informe = :numero

            LIMIT 1
            ",
            [
                'numero' => $numero
            ]
        );
    }

    /**
     * Determina si existe un número de informe.
     */
    public function existeNumero(
        string $numero,
        ?int $excluirId = null
    ): bool {
        $numero = trim($numero);

        if ($numero === '') {
            return false;
        }

        $sql = "
            SELECT COUNT(*)
            FROM historial_informes
            WHERE nro_informe = :numero
        ";

        $params = [
            'numero' => $numero
        ];

        if (
            $excluirId !== null
            && $excluirId > 0
        ) {
            $sql .= "
                AND id <> :excluir_id
            ";

            $params['excluir_id'] = $excluirId;
        }

        return (int)$this->fetchColumn(
            $sql,
            $params
        ) > 0;
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS RELACIONALES - COMPATIBILIDAD
    |--------------------------------------------------------------------------
    */

    /**
     * Nombre del cliente.
     */
    public function nombreCliente(
        int $id
    ): string {
        if ($id <= 0) {
            return '';
        }

        $value = $this->fetchColumn(
            "
            SELECT nombre
            FROM clientes
            WHERE id = :id
            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );

        return trim(
            (string)($value ?? '')
        );
    }

    /**
     * Nombre de localidad.
     */
    public function nombreLocalidad(
        int $id
    ): string {
        if ($id <= 0) {
            return '';
        }

        $value = $this->fetchColumn(
            "
            SELECT nombre
            FROM localidades
            WHERE id = :id
            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );

        return trim(
            (string)($value ?? '')
        );
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR INFORME
    |--------------------------------------------------------------------------
    */

    /**
     * Guarda un informe TNG.
     *
     * El Service debe encargarse de:
     *
     * - validar;
     * - normalizar;
     * - verificar relaciones;
     * - procesar facturación;
     * - almacenar el PDF.
     */
    public function guardarInforme(
        array $data
    ): int {
        $sql = "
            INSERT INTO historial_informes
            (
                nro_informe,
                cliente_id,
                equipo_id,
                cliente,
                localidad,
                fecha,
                archivo_path,
                fact_contador_arca,
                fact_contador_general,
                fact_servicio_tecnico,
                estado_facturacion,
                estado,
                observaciones
            )
            VALUES
            (
                :nro_informe,
                :cliente_id,
                :equipo_id,
                :cliente,
                :localidad,
                :fecha,
                :archivo_path,
                :fact_contador_arca,
                :fact_contador_general,
                :fact_servicio_tecnico,
                :estado_facturacion,
                :estado,
                :observaciones
            )
        ";

        $params = [
            'nro_informe' => trim(
                (string)(
                    $data['nro_informe'] ?? ''
                )
            ),

            'cliente_id' => (int)(
                $data['cliente_id'] ?? 0
            ),

            'equipo_id' => (int)(
                $data['equipo_id'] ?? 0
            ),

            'cliente' => trim(
                (string)(
                    $data['cliente'] ?? ''
                )
            ),

            'localidad' => trim(
                (string)(
                    $data['localidad'] ?? ''
                )
            ),

            'fecha' => (string)(
                $data['fecha']
                ?? date('Y-m-d H:i:s')
            ),

            'archivo_path' => trim(
                (string)(
                    $data['archivo_path'] ?? ''
                )
            ),

            'fact_contador_arca' =>
                !empty(
                    $data['fact_contador_arca']
                )
                    ? 1
                    : 0,

            'fact_contador_general' =>
                !empty(
                    $data['fact_contador_general']
                )
                    ? 1
                    : 0,

            'fact_servicio_tecnico' =>
                !empty(
                    $data['fact_servicio_tecnico']
                )
                    ? 1
                    : 0,

            'estado_facturacion' => strtoupper(
                trim(
                    (string)(
                        $data['estado_facturacion']
                        ?? 'PENDIENTE'
                    )
                )
            ),

            'estado' => strtoupper(
                trim(
                    (string)(
                        $data['estado']
                        ?? 'PENDIENTE'
                    )
                )
            ),

            'observaciones' => trim(
                (string)(
                    $data['observaciones'] ?? ''
                )
            ),
        ];

        try {
            $stmt = $this->db->prepare($sql);

            $stmt->execute($params);

            return (int)$this->db->lastInsertId();

        } catch (PDOException $e) {

            error_log(
                '[Informes_tng Repository guardarInforme] '
                . $e->getMessage()
            );

            throw $e;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR INFORME
    |--------------------------------------------------------------------------
    */

    /**
     * Actualiza únicamente los campos recibidos.
     */
    public function actualizar(
        int $id,
        array $data
    ): bool {
        if ($id <= 0) {
            return false;
        }

        /*
         * Lista blanca.
         *
         * IMPORTANTE:
         * historial_informes NO posee localidad_id.
         */
        $permitidos = [
            'nro_informe',
            'cliente_id',
            'equipo_id',
            'cliente',
            'localidad',
            'fecha',
            'archivo_path',
            'fact_contador_arca',
            'fact_contador_general',
            'fact_servicio_tecnico',
            'estado_facturacion',
            'estado',
            'observaciones',
            'motivo_anulacion',
            'anulado_por',
            'fecha_anulacion',
        ];

        $set = [];

        $params = [
            'id' => $id
        ];

        foreach ($permitidos as $campo) {

            if (!array_key_exists($campo, $data)) {
                continue;
            }

            $set[] = "{$campo} = :{$campo}";

            /*
             * Normalización defensiva de flags.
             */
            if (
                in_array(
                    $campo,
                    [
                        'fact_contador_arca',
                        'fact_contador_general',
                        'fact_servicio_tecnico'
                    ],
                    true
                )
            ) {
                $params[$campo] =
                    !empty($data[$campo])
                        ? 1
                        : 0;

                continue;
            }

            if (
                in_array(
                    $campo,
                    [
                        'nro_informe',
                        'cliente',
                        'localidad',
                        'archivo_path',
                        'estado_facturacion',
                        'estado',
                        'observaciones',
                        'motivo_anulacion'
                    ],
                    true
                )
            ) {
                $params[$campo] =
                    trim(
                        (string)($data[$campo] ?? '')
                    );

                continue;
            }

            $params[$campo] = $data[$campo];
        }

        if ($set === []) {
            return false;
        }

        $sql = "
            UPDATE historial_informes
            SET
                " . implode(
                    ",\n                ",
                    $set
                ) . "
            WHERE id = :id
            LIMIT 1
        ";

        return $this->execute(
            $sql,
            $params
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR INFORME
    |--------------------------------------------------------------------------
    */

    public function eliminar(
        int $id
    ): bool {
        if ($id <= 0) {
            return false;
        }

        return $this->execute(
            "
            DELETE FROM historial_informes
            WHERE id = :id
            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES USADOS EN RANGO
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve únicamente los números utilizados.
     *
     * @return array<int,int|string>
     */
    public function informesUsadosEnRango(
        int $desde,
        int $hasta
    ): array {
        if (
            $desde <= 0
            || $hasta <= 0
            || $desde > $hasta
        ) {
            return [];
        }

        /*
         * Protección.
         */
        if (($hasta - $desde) > 100000) {
            return [];
        }

        $rows = $this->fetchAll(
            "
            SELECT
                nro_informe
            FROM historial_informes
            WHERE CAST(nro_informe AS UNSIGNED)
                  BETWEEN :desde AND :hasta
            ORDER BY
                CAST(nro_informe AS UNSIGNED) ASC
            ",
            [
                'desde' => $desde,
                'hasta' => $hasta
            ]
        );

        $resultado = [];

        foreach ($rows as $row) {

            $numero = trim(
                (string)(
                    $row['nro_informe'] ?? ''
                )
            );

            if ($numero === '') {
                continue;
            }

            if (ctype_digit($numero)) {
                $resultado[] = (int)$numero;
            } else {
                $resultado[] = $numero;
            }
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | TALONARIOS
    |--------------------------------------------------------------------------
    */

    /**
     * Lista los talonarios TNG.
     *
     * @return array<int,array<string,mixed>>
     */
    public function talonarios(): array
    {
        return $this->fetchAll(
            "
            SELECT
                t.*
            FROM talonarios t
            WHERE t.propiedad = 'TNG'
            ORDER BY
                t.num_desde ASC,
                t.id ASC
            "
        );
    }

    /**
     * Obtiene un talonario TNG.
     */
    public function talonario(
        int $id
    ): ?array {
        if ($id <= 0) {
            return null;
        }

        return $this->fetchOne(
            "
            SELECT
                t.*
            FROM talonarios t
            WHERE t.id = :id
              AND t.propiedad = 'TNG'
            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );
    }

    /**
     * Verifica si existe un nombre de talonario.
     */
    public function existeTalonarioNombre(
        string $nombre,
        ?int $excluirId = null
    ): bool {
        $nombre = trim($nombre);

        if ($nombre === '') {
            return false;
        }

        $sql = "
            SELECT COUNT(*)
            FROM talonarios
            WHERE nombre = :nombre
              AND propiedad = 'TNG'
        ";

        $params = [
            'nombre' => $nombre
        ];

        if (
            $excluirId !== null
            && $excluirId > 0
        ) {
            $sql .= "
                AND id <> :excluir_id
            ";

            $params['excluir_id'] = $excluirId;
        }

        return (int)$this->fetchColumn(
            $sql,
            $params
        ) > 0;
    }

    /**
     * Crear talonario TNG.
     */
    public function crearTalonario(
        array $data
    ): int {
        $sql = "
            INSERT INTO talonarios
            (
                nombre,
                num_desde,
                num_hasta,
                propiedad
            )
            VALUES
            (
                :nombre,
                :desde,
                :hasta,
                'TNG'
            )
        ";

        try {
            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                'nombre' => trim(
                    (string)(
                        $data['nombre'] ?? ''
                    )
                ),

                'desde' => (int)(
                    $data['desde'] ?? 0
                ),

                'hasta' => (int)(
                    $data['hasta'] ?? 0
                ),
            ]);

            return (int)$this->db->lastInsertId();

        } catch (PDOException $e) {

            error_log(
                '[Informes_tng Repository crearTalonario] '
                . $e->getMessage()
            );

            throw $e;
        }
    }

    /**
     * Actualizar talonario TNG.
     */
    public function actualizarTalonario(
        int $id,
        array $data
    ): bool {
        if ($id <= 0) {
            return false;
        }

        return $this->execute(
            "
            UPDATE talonarios
            SET
                nombre = :nombre,
                num_desde = :desde,
                num_hasta = :hasta
            WHERE id = :id
              AND propiedad = 'TNG'
            LIMIT 1
            ",
            [
                'id' => $id,

                'nombre' => trim(
                    (string)(
                        $data['nombre'] ?? ''
                    )
                ),

                'desde' => (int)(
                    $data['desde'] ?? 0
                ),

                'hasta' => (int)(
                    $data['hasta'] ?? 0
                ),
            ]
        );
    }

    /**
     * Eliminar talonario TNG.
     *
     * La validación de uso corresponde al Service.
     */
    public function eliminarTalonario(
        int $id
    ): bool {
        if ($id <= 0) {
            return false;
        }

        return $this->execute(
            "
            DELETE FROM talonarios
            WHERE id = :id
              AND propiedad = 'TNG'
            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS AVANZADAS
    |--------------------------------------------------------------------------
    */

    /**
     * Cantidad de informes por estado.
     *
     * @return array<int,array<string,mixed>>
     */
    public function estadisticasEstados(): array
    {
        return $this->fetchAll(
            "
            SELECT
                estado,
                COUNT(*) AS cantidad
            FROM historial_informes
            GROUP BY estado
            ORDER BY estado ASC
            "
        );
    }

    /**
     * Cantidad de informes por mes.
     *
     * @return array<int,array<string,mixed>>
     */
    public function estadisticasMensuales(
        int $anio
    ): array {
        if (
            $anio < 2000
            || $anio > 2100
        ) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                MONTH(fecha) AS mes,
                COUNT(*) AS cantidad
            FROM historial_informes
            WHERE YEAR(fecha) = :anio
            GROUP BY MONTH(fecha)
            ORDER BY MONTH(fecha) ASC
            ",
            [
                'anio' => $anio
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ÚLTIMO INFORME
    |--------------------------------------------------------------------------
    */

    /**
     * Último informe registrado.
     */
    public function ultimo(): ?array
    {
        return $this->fetchOne(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            ORDER BY
                hi.fecha DESC,
                hi.id DESC

            LIMIT 1
            "
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES POR CLIENTE
    |--------------------------------------------------------------------------
    */

    /**
     * @return array<int,array<string,mixed>>
     */
    public function porCliente(
        int $clienteId
    ): array {
        if ($clienteId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE hi.cliente_id = :cliente_id

            ORDER BY
                hi.fecha DESC,
                hi.id DESC
            ",
            [
                'cliente_id' => $clienteId
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES POR EQUIPO
    |--------------------------------------------------------------------------
    */

    /**
     * @return array<int,array<string,mixed>>
     */
    public function porEquipo(
        int $equipoId
    ): array {
        if ($equipoId <= 0) {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE hi.equipo_id = :equipo_id

            ORDER BY
                hi.fecha DESC,
                hi.id DESC
            ",
            [
                'equipo_id' => $equipoId
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES POR LOCALIDAD
    |--------------------------------------------------------------------------
    */

    /**
     * @return array<int,array<string,mixed>>
     */
    public function porLocalidad(
        int $localidadId
    ): array {
        if ($localidadId <= 0) {
            return [];
        }

        /*
         * historial_informes no posee localidad_id.
         *
         * La localidad se conserva por nombre.
         *
         * Por eso relacionamos:
         *
         * localidades.nombre
         *        =
         * historial_informes.localidad
         */
        return $this->fetchAll(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            INNER JOIN localidades l
                ON UPPER(TRIM(l.nombre))
                 = UPPER(TRIM(hi.localidad))

            WHERE l.id = :localidad_id

            ORDER BY
                hi.fecha DESC,
                hi.id DESC
            ",
            [
                'localidad_id' => $localidadId
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES POR ESTADO
    |--------------------------------------------------------------------------
    */

    /**
     * @return array<int,array<string,mixed>>
     */
    public function porEstado(
        string $estado
    ): array {
        $estado = strtoupper(
            trim($estado)
        );

        if ($estado === '') {
            return [];
        }

        return $this->fetchAll(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE hi.estado = :estado

            ORDER BY
                hi.fecha DESC,
                hi.id DESC
            ",
            [
                'estado' => $estado
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ANULAR INFORME
    |--------------------------------------------------------------------------
    */

    /**
     * Anula un informe.
     */
    public function anular(
        int $id,
        ?int $usuarioId,
        string $motivo
    ): bool {
        if ($id <= 0) {
            return false;
        }

        $motivo = trim($motivo);

        if ($motivo === '') {
            return false;
        }

        return $this->execute(
            "
            UPDATE historial_informes
            SET
                estado = 'ANULADO',
                anulado_por = :anulado_por,
                fecha_anulacion = NOW(),
                motivo_anulacion = :motivo
            WHERE id = :id
            LIMIT 1
            ",
            [
                'id' => $id,

                'anulado_por' => $usuarioId,

                'motivo' => $motivo,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | REACTIVAR / DESANULAR
    |--------------------------------------------------------------------------
    */

    /**
     * Reactiva un informe anulado.
     */
    public function reactivar(
        int $id
    ): bool {
        if ($id <= 0) {
            return false;
        }

        return $this->execute(
            "
            UPDATE historial_informes
            SET
                estado = 'PENDIENTE',
                anulado_por = NULL,
                fecha_anulacion = NULL,
                motivo_anulacion = NULL
            WHERE id = :id
            LIMIT 1
            ",
            [
                'id' => $id
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | BÚSQUEDA GENERAL
    |--------------------------------------------------------------------------
    */

    /**
     * Busca por:
     *
     * - número;
     * - cliente;
     * - localidad;
     * - código TNG;
     * - serie;
     * - modelo;
     * - estado;
     * - estado de facturación;
     * - observaciones.
     *
     * @return array<int,array<string,mixed>>
     */
    public function buscarTexto(
        string $texto,
        int $limite = 100
    ): array {
        $texto = trim($texto);

        if ($texto === '') {
            return [];
        }

        $limite = max(
            1,
            min($limite, 1000)
        );

        $like = '%' . $texto . '%';

        return $this->fetchAll(
            "
            SELECT
                hi.*,

                e.codigo_interno AS codigo_tng,

                e.serie AS serie,
                e.serie AS numero_serie,

                m.nombre_modelo AS nombre_modelo,
                m.nombre_modelo AS modelo,

                m.marca AS marca

            FROM historial_informes hi

            LEFT JOIN equipos e
                ON e.id = hi.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE
                hi.nro_informe LIKE :texto1
                OR hi.cliente LIKE :texto2
                OR hi.localidad LIKE :texto3
                OR e.codigo_interno LIKE :texto6
                OR e.serie LIKE :texto7
                OR m.nombre_modelo LIKE :texto8
                OR hi.estado LIKE :texto4
                OR hi.estado_facturacion LIKE :texto9
                OR hi.observaciones LIKE :texto5

            ORDER BY
                hi.fecha DESC,
                hi.id DESC

            LIMIT {$limite}
            ",
            [
                'texto1' => $like,
                'texto2' => $like,
                'texto3' => $like,
                'texto4' => $like,
                'texto5' => $like,
                'texto6' => $like,
                'texto7' => $like,
                'texto8' => $like,
                'texto9' => $like,
            ]
        );
    }

    /*
    |--------------------------------------------------------------------------
    | TRANSACCIONES
    |--------------------------------------------------------------------------
    */

    /**
     * Inicia una transacción.
     */
    public function beginTransaction(): bool
    {
        if ($this->db->inTransaction()) {
            return false;
        }

        return $this->db->beginTransaction();
    }

    /**
     * Confirma una transacción.
     */
    public function commit(): bool
    {
        if (!$this->db->inTransaction()) {
            return false;
        }

        return $this->db->commit();
    }

    /**
     * Revierte una transacción.
     */
    public function rollback(): bool
    {
        if (!$this->db->inTransaction()) {
            return false;
        }

        return $this->db->rollBack();
    }
}