<?php
declare(strict_types=1);

$esViewer = $esViewer ?? false;
?>

<div class="container-fluid">

    <?php require __DIR__ . '/partials/dashboard.php'; ?>

    <ul class="nav nav-tabs mb-4" id="informesTabs">

        <?php if (!$esViewer): ?>
            <li class="nav-item">
                <button
                    class="nav-link active"
                    data-bs-toggle="tab"
                    data-bs-target="#tabCarga"
                    type="button"
                >
                    <i class="fa-solid fa-file-circle-plus me-1"></i>
                    Nueva carga
                </button>
            </li>
        <?php endif; ?>

        <li class="nav-item">
            <button
                class="nav-link <?= $esViewer ? 'active' : '' ?>"
                data-bs-toggle="tab"
                data-bs-target="#tabHistorial"
                type="button"
            >
                <i class="fa-solid fa-list me-1"></i>
                Historial
            </button>
        </li>

        <?php if (!$esViewer): ?>
            <li class="nav-item">
                <button
                    class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#tabTalonarios"
                    type="button"
                >
                    <i class="fa-solid fa-book me-1"></i>
                    Talonarios
                </button>
            </li>
        <?php endif; ?>

    </ul>


    <div class="tab-content">

        <?php if (!$esViewer): ?>

            <div
                class="tab-pane fade show active"
                id="tabCarga"
            >
                <?php require __DIR__ . '/partials/nueva_carga.php'; ?>
            </div>

        <?php endif; ?>


        <div
            class="tab-pane fade <?= $esViewer ? 'show active' : '' ?>"
            id="tabHistorial"
        >
            <?php require __DIR__ . '/partials/historial.php'; ?>
        </div>


        <?php if (!$esViewer): ?>

            <div
                class="tab-pane fade"
                id="tabTalonarios"
            >
                <?php require __DIR__ . '/partials/talonarios.php'; ?>
            </div>

        <?php endif; ?>

    </div>

</div>

<?php
require __DIR__ . '/partials/modal_talonario.php';
?>