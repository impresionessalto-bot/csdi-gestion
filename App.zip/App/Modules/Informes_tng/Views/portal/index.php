<?php

declare(strict_types=1);

/**
 * =========================================================
 * ERP CSDI PRO
 * Informes TNG
 * Vista centralizada
 * Solo lectura
 * =========================================================
 */


$informes = $informes ?? [];

?>


<div class="card shadow-sm border-0">


<div class="card-header bg-white py-3">


<h5 class="mb-0 fw-bold">

<i class="fa-solid fa-file-pdf text-danger"></i>

Informes Técnicos Registrados

<span class="text-muted small">
(Solo lectura)
</span>

</h5>


</div>





<div class="table-responsive">


<table class="table table-hover align-middle mb-0">


<thead class="table-dark">

<tr>

<th>
Nº Informe
</th>

<th>
Fecha
</th>

<th>
Cliente
</th>

<th>
Equipo TNG
</th>

<th>
Observaciones
</th>

<th class="text-center">
Documento
</th>

</tr>

</thead>




<tbody>


<?php if(empty($informes)): ?>


<tr>

<td 
colspan="6"
class="text-center text-muted py-5"
>


<i class="fa-solid fa-folder-open fa-2x mb-3"></i>


<br>

No existen informes disponibles.


</td>

</tr>



<?php else: ?>



<?php foreach($informes as $i): ?>


<tr>


<td>

<strong>

<?= e($i['nro_informe'] ?? '-') ?>

</strong>

</td>




<td>

<?= e($i['fecha'] ?? '-') ?>

</td>




<td>

<?= e($i['cliente'] ?? '-') ?>

</td>




<td>


<span class="badge bg-secondary">


<i class="fa-solid fa-print"></i>


<?= e($i['equipo_tng'] ?? '-') ?>


</span>


</td>




<td style="max-width:350px">


<?= e($i['observaciones'] ?? '-') ?>


</td>





<td class="text-center">



<?php if(!empty($i['archivo_path'])): ?>


<?php

$urlPdf =
    '/informes-tng/pdf/' .
    (int)$i['id'];

?>


<div class="btn-group">


<a

href="<?= e($urlPdf) ?>"

target="_blank"

class="btn btn-danger btn-sm"

>

<i class="fa-solid fa-file-pdf"></i>

Ver

</a>



<a

href="<?= e($urlPdf) ?>"

download

class="btn btn-outline-secondary btn-sm"

>

<i class="fa-solid fa-download"></i>

</a>


</div>



<?php else: ?>


<span class="text-muted small">

<i class="fa-solid fa-ban"></i>

Sin archivo

</span>


<?php endif; ?>


</td>



</tr>



<?php endforeach; ?>



<?php endif; ?>



</tbody>


</table>


</div>


</div>