<?php
declare(strict_types=1);
?>
<div class="modal fade" id="modalExportarInformes" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 12px; overflow: hidden;">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-file-export me-2"></i> Exportar Reporte de Informes</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 bg-white">
                <form id="formExportarTng" method="GET" action="/informes-tng/reportes/excel">
                    
                    <!-- Rango de Fechas -->
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label text-dark fw-semibold small">Desde:</label>
                            <input type="date" class="form-control" name="fecha_desde" id="exp_tng_desde">
                        </div>
                        <div class="col-6">
                            <label class="form-label text-dark fw-semibold small">Hasta:</label>
                            <input type="date" class="form-control" name="fecha_hasta" id="exp_tng_hasta">
                        </div>
                    </div>

                    <!-- Filtro por Número de Informe -->
                    <div class="mb-3">
                        <label class="form-label text-dark fw-semibold small">Filtrar por Número de Informe:</label>
                        <input type="text" class="form-control" name="nro_informe" id="exp_tng_nro" placeholder="Escribe el número de informe exacto...">
                    </div>

                </form>
            </div>
            <div class="modal-footer bg-light d-flex justify-content-between">
                <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-success btn-sm fw-semibold" id="btnTngExcel">
                        <i class="fa-solid fa-file-excel me-1"></i> Excel
                    </button>
                    <button type="button" class="btn btn-danger btn-sm fw-semibold" id="btnTngPdf">
                        <i class="fa-solid fa-file-pdf me-1"></i> PDF
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>