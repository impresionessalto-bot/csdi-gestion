<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| INFORMES TNG - DASHBOARD (Compatibilidad Universal de Variables)
|--------------------------------------------------------------------------
*/

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        if (is_array($value)) {
            return htmlspecialchars(implode(', ', array_filter($value, 'is_scalar')), ENT_QUOTES, 'UTF-8');
        }
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$dashboard = is_array($dashboard ?? null) ? $dashboard : [];

// Extracción defensiva de talonarios pendientes
$talonariosPendientes =
    $dashboard['talonariosPendientes']
    ?? $dashboard['talonarios_pendientes']
    ?? $talonariosPendientes
    ?? $pendientes
    ?? [];

if (!is_array($talonariosPendientes)) {
    $talonariosPendientes = [];
}

// Extracción defensiva de KPIs
$kpisRaw = $dashboard['kpis'] ?? $kpis ?? [];
if (!is_array($kpisRaw)) {
    $kpisRaw = [];
}

// Cálculo de faltantes totales
$totalFaltantesCalculado = 0;
foreach ($talonariosPendientes as $p) {
    if (is_array($p)) {
        $totalFaltantesCalculado += (int)($p['faltantes'] ?? $p['cantidad_faltantes'] ?? 0);
    }
}

$kpis = [
    'talonarios' => (int)($kpisRaw['talonarios'] ?? count($talonarios ?? [])),
    'informes'   => (int)($kpisRaw['informes'] ?? $kpisRaw['informes_cargados'] ?? count($ultimos ?? [])),
    'faltantes'  => (int)($kpisRaw['faltantes'] ?? $kpisRaw['informes_faltantes'] ?? $totalFaltantesCalculado),
    'pendientes' => (int)($kpisRaw['pendientes'] ?? count($talonariosPendientes))
];

?>

<div class="row g-3 mb-4">

    <!-- TALONARIOS ACTIVOS -->
    <div class="col-md-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">
                            Talonarios activos
                        </div>
                        <div class="fs-3 fw-bold text-primary">
                            <?= h($kpis['talonarios']) ?>
                        </div>
                    </div>
                    <div class="fs-2 text-primary opacity-75">
                        <i class="fa-solid fa-book"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- INFORMES CARGADOS -->
    <div class="col-md-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">
                            Informes cargados
                        </div>
                        <div class="fs-3 fw-bold text-success">
                            <?= h($kpis['informes']) ?>
                        </div>
                    </div>
                    <div class="fs-2 text-success opacity-75">
                        <i class="fa-solid fa-file-circle-check"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- INFORMES FALTANTES -->
    <div class="col-md-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">
                            Informes faltantes
                        </div>
                        <div class="fs-3 fw-bold text-danger">
                            <?= h($kpis['faltantes']) ?>
                        </div>
                    </div>
                    <div class="fs-2 text-danger opacity-75">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TALONARIOS PENDIENTES -->
    <div class="col-md-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">
                            Talonarios pendientes
                        </div>
                        <div class="fs-3 fw-bold text-warning">
                            <?= h($kpis['pendientes']) ?>
                        </div>
                    </div>
                    <div class="fs-2 text-warning opacity-75">
                        <i class="fa-solid fa-clock"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- =========================================================
     TALONARIOS CON INFORMES FALTANTES
     ========================================================= -->

<div class="card border-0 shadow-sm rounded-3 overflow-hidden mb-4">

    <div class="card-header bg-dark text-white py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <div class="fw-bold">
                    <i class="fa-solid fa-triangle-exclamation text-warning me-2"></i>
                    Informes pendientes de carga
                </div>
                <div class="small text-white-50">
                    Talonarios comenzados que todavía tienen informes sin utilizar
                </div>
            </div>
        </div>
    </div>

    <div class="table-responsive">

        <table class="table table-hover align-middle mb-0">

            <thead class="table-light">
                <tr>
                    <th class="ps-4">Talonario</th>
                    <th>Inicio</th>
                    <th>Fin</th>
                    <th>Cargados</th>
                    <th>Faltantes</th>
                    <th class="text-end pe-4">Estado</th>
                </tr>
            </thead>

            <tbody>

            <?php if (empty($talonariosPendientes)): ?>

                <tr>
                    <td colspan="6" class="text-center py-5 text-muted">
                        <i class="fa-solid fa-circle-check fs-2 text-success mb-2"></i>
                        <div class="fw-semibold">
                            No hay informes pendientes.
                        </div>
                        <div class="small">
                            Todos los talonarios comenzados están completos.
                        </div>
                    </td>
                </tr>

            <?php else: ?>

                <?php foreach ($talonariosPendientes as $talonario): ?>

                    <?php
                    if (!is_array($talonario)) {
                        continue;
                    }

                    $numero = (string)(
                        $talonario['numero']
                        ?? $talonario['nro_talonario']
                        ?? $talonario['talonario']
                        ?? '-'
                    );

                    $desde = (int)(
                        $talonario['desde']
                        ?? $talonario['numero_desde']
                        ?? $talonario['nro_desde']
                        ?? 0
                    );

                    $hasta = (int)(
                        $talonario['hasta']
                        ?? $talonario['numero_hasta']
                        ?? $talonario['nro_hasta']
                        ?? 0
                    );

                    $cargados = (int)(
                        $talonario['cargados']
                        ?? $talonario['informes_cargados']
                        ?? $talonario['utilizados']
                        ?? 0
                    );

                    $cantidadFaltantes = (int)(
                        $talonario['faltantes']
                        ?? $talonario['cantidad_faltantes']
                        ?? max(0, $hasta - $desde + 1 - $cargados)
                    );

                    $faltantesList = $talonario['informes_faltantes'] ?? $talonario['numeros_faltantes'] ?? [];
                    if (!is_array($faltantesList)) {
                        $faltantesList = [];
                    }
                    ?>

                    <tr>
                        <td class="ps-4">
                            <strong><?= h($numero) ?></strong>
                        </td>

                        <td class="font-monospace">
                            <?= h($desde) ?>
                        </td>

                        <td class="font-monospace">
                            <?= h($hasta) ?>
                        </td>

                        <td>
                            <span class="badge bg-success">
                                <?= h($cargados) ?>
                            </span>
                        </td>

                        <td>
                            <?php if ($cantidadFaltantes > 0): ?>

                                <span class="badge bg-danger me-2">
                                    <?= h($cantidadFaltantes) ?>
                                </span>

                                <?php if (!empty($faltantesList)): ?>
                                    <div class="small text-muted mt-1">
                                        <?php $mostrar = array_slice($faltantesList, 0, 12); ?>
                                        <?php foreach ($mostrar as $faltante): ?>
                                            <a
                                                href="<?= base_url('informes-tng?numero=' . rawurlencode((string)$faltante)) ?>"
                                                class="badge bg-light text-danger border text-decoration-none me-1 mb-1"
                                                title="Cargar informe <?= h($faltante) ?>"
                                            >
                                                <i class="fa-solid fa-plus-circle me-1"></i>
                                                <?= h($faltante) ?>
                                            </a>
                                        <?php endforeach; ?>

                                        <?php if (count($faltantesList) > 12): ?>
                                            <span class="small text-muted">
                                                +<?= h(count($faltantesList) - 12) ?> más
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                            <?php else: ?>

                                <span class="text-success small">
                                    Completo
                                </span>

                            <?php endif; ?>
                        </td>

                        <td class="text-end pe-4">
                            <?php if ($cantidadFaltantes > 0): ?>
                                <span class="badge bg-warning text-dark">
                                    Pendiente
                                </span>
                            <?php else: ?>
                                <span class="badge bg-success">
                                    Completo
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>