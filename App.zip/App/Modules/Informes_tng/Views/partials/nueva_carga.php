<?php

declare(strict_types=1);

$informesDisponibles = is_array($informesDisponibles ?? null) ? $informesDisponibles : [];
$localidades = is_array($localidades ?? null) ? $localidades : [];
$csrf = (string)($csrf ?? '');
$numeroSeleccionado = trim((string)($numeroSeleccionado ?? ''));

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        if (is_array($value)) {
            return htmlspecialchars(implode(', ', array_filter($value, 'is_scalar')), ENT_QUOTES, 'UTF-8');
        }
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

?>

<div class="card border-0 shadow-sm rounded-3">

    <div class="card-header bg-dark text-white py-3">
        <div class="fw-bold">
            <i class="fa-solid fa-file-circle-plus text-success me-2"></i>
            Nueva carga de informe técnico
        </div>
        <div class="small text-white-50">
            Ingrese el informe correspondiente al talonario iniciado.
        </div>
    </div>

    <div class="card-body p-4">

        <form
            method="POST"
            action="<?= base_url('informes-tng/guardar') ?>"
            enctype="multipart/form-data"
            autocomplete="off"
        >

            <input
                type="hidden"
                name="_csrf"
                value="<?= h($csrf) ?>"
            >

            <div class="row g-3">

                <!-- Número de Informe -->
                <div class="col-lg-3">
                    <label class="form-label fw-semibold small">
                        Nº Informe
                    </label>

                    <input
                        type="text"
                        class="form-control fw-bold text-primary"
                        name="nro_informe"
                        id="nroInformeTng"
                        list="listaInformesDisponibles"
                        placeholder="Ej: 1001"
                        value="<?= h($numeroSeleccionado) ?>"
                        required
                    >

                    <?php if ($numeroSeleccionado !== ''): ?>
                        <div class="form-text text-success fw-semibold">
                            <i class="fa-solid fa-circle-check me-1"></i>
                            Informe pendiente seleccionado desde el dashboard.
                        </div>
                    <?php endif; ?>

                    <datalist id="listaInformesDisponibles">
                        <?php foreach ($informesDisponibles as $numero): ?>
                            <?php
                            $val = '';
                            if (is_array($numero)) {
                                $val = $numero['nro_informe'] ?? $numero['numero'] ?? $numero['id'] ?? '';
                            } else {
                                $val = $numero;
                            }
                            ?>
                            <option value="<?= h($val) ?>">
                                Informe <?= h($val) ?>
                            </option>
                        <?php endforeach; ?>
                    </datalist>
                </div>

                <!-- Fecha -->
                <div class="col-lg-3">
                    <label class="form-label fw-semibold small">
                        Fecha informe
                    </label>

                    <input
                        type="date"
                        class="form-control"
                        name="fecha"
                        value="<?= date('Y-m-d') ?>"
                        required
                    >
                </div>

                <!-- Localidad (Dispara la cascada) -->
                <div class="col-lg-6">
                    <label class="form-label fw-semibold small">
                        Localidad
                    </label>

                    <select
                        class="form-select"
                        id="tng_localidad_id"
                        name="localidad_id"
                        required
                    >
                        <option value="">
                            Seleccione localidad
                        </option>

                        <?php foreach ($localidades as $localidad): ?>
                            <?php
                            $locId = is_array($localidad) ? ($localidad['id'] ?? '') : $localidad;
                            $locNombre = is_array($localidad) ? ($localidad['nombre'] ?? '') : $localidad;
                            ?>
                            <option value="<?= h($locId) ?>">
                                <?= h($locNombre) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Cliente TNG (Carga mediante AJAX) -->
                <div class="col-lg-6">
                    <label class="form-label fw-semibold small">
                        Cliente TNG
                    </label>

                    <select
                        class="form-select fw-bold"
                        id="tng_cliente_id"
                        name="cliente_id"
                        disabled
                        required
                    >
                        <option value="">
                            Seleccione localidad primero
                        </option>
                    </select>
                </div>

                <!-- Equipo TNG (Carga mediante AJAX) -->
                <div class="col-lg-6">
                    <label class="form-label fw-semibold small">
                        Equipo TNG
                    </label>

                    <select
                        class="form-select fw-bold"
                        id="tng_equipo_id"
                        name="equipo_id"
                        disabled
                        required
                    >
                        <option value="">
                            Seleccione cliente primero
                        </option>
                    </select>
                </div>

                <!-- Observaciones -->
                <div class="col-12">
                    <label class="form-label fw-semibold small">
                        Observaciones
                    </label>

                    <textarea
                        class="form-control"
                        name="observaciones"
                        rows="3"
                        placeholder="Detalles del servicio técnico realizado..."
                    ></textarea>
                </div>

                <!-- Facturación -->
                <div class="col-12">
                    <div class="card border-primary-subtle">
                        <div class="card-header bg-light fw-bold small">
                            <i class="fa-solid fa-file-invoice-dollar text-primary me-2"></i>
                            Conceptos a facturar
                        </div>

                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="form-check form-switch">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            id="fact_contador_arca"
                                            name="fact_contador_arca"
                                            value="1"
                                        >
                                        <label
                                            class="form-check-label fw-semibold small"
                                            for="fact_contador_arca"
                                        >
                                            Contador ARCA
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-check form-switch">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            id="fact_contador_general"
                                            name="fact_contador_general"
                                            value="1"
                                        >
                                        <label
                                            class="form-check-label fw-semibold small"
                                            for="fact_contador_general"
                                        >
                                            Contador General
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-check form-switch">
                                        <input
                                            class="form-check-input"
                                            type="checkbox"
                                            id="fact_servicio_tecnico"
                                            name="fact_servicio_tecnico"
                                            value="1"
                                        >
                                        <label
                                            class="form-check-label fw-semibold small"
                                            for="fact_servicio_tecnico"
                                        >
                                            Servicio Técnico Eventual
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- PDF -->
                <div class="col-12">
                    <label class="form-label fw-semibold small">
                        Archivo PDF del informe firmado
                    </label>

                    <input
                        type="file"
                        class="form-control"
                        name="informe"
                        accept="application/pdf"
                        required
                    >
                </div>

            </div>

            <div class="text-end mt-4">
                <button
                    type="submit"
                    class="btn btn-success px-4"
                >
                    <i class="fa-solid fa-save me-1"></i>
                    Guardar informe
                </button>
            </div>

        </form>

    </div>

</div>

<!-- =====================================================
     SCRIPT DE CASCADA AJAX (LOCALIDAD -> CLIENTE -> EQUIPO)
     ===================================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const selLoc = document.getElementById('tng_localidad_id');
    const selCli = document.getElementById('tng_cliente_id');
    const selEq = document.getElementById('tng_equipo_id');

    if (!selLoc) return;

    // 1. CAMBIO DE LOCALIDAD -> CARGAR CLIENTES TNG
    selLoc.addEventListener('change', async () => {
        selCli.innerHTML = '<option value="">Cargando clientes...</option>';
        selEq.innerHTML = '<option value="">Seleccione cliente primero</option>';
        selCli.disabled = true;
        selEq.disabled = true;

        const locId = selLoc.value;
        if (!locId) {
            selCli.innerHTML = '<option value="">Seleccione localidad primero</option>';
            return;
        }

        try {
            const r = await fetch(`/informes-tng/api/clientes?localidad_id=${locId}`);
            const json = await r.json();
            const list = Array.isArray(json.data) ? json.data : (json.clientes || []);

            selCli.innerHTML = '<option value="">Seleccione cliente</option>';
            if (list.length === 0) {
                selCli.innerHTML = '<option value="">Sin clientes en esta localidad</option>';
            } else {
                list.forEach(c => {
                    const nombre = c.nombre || c.razon_social || 'Cliente';
                    selCli.innerHTML += `<option value="${c.id}">${nombre}</option>`;
                });
                selCli.disabled = false;
            }
        } catch (e) {
            console.error('Error cargando clientes TNG:', e);
            selCli.innerHTML = '<option value="">Error al cargar clientes</option>';
        }
    });

    // 2. CAMBIO DE CLIENTE -> CARGAR EQUIPOS TNG
    selCli.addEventListener('change', async () => {
        selEq.innerHTML = '<option value="">Cargando equipos...</option>';
        selEq.disabled = true;

        const cliId = selCli.value;
        if (!cliId) {
            selEq.innerHTML = '<option value="">Seleccione cliente primero</option>';
            return;
        }

        try {
            const r = await fetch(`/informes-tng/api/equipos?cliente_id=${cliId}`);
            const json = await r.json();
            const list = Array.isArray(json.data) ? json.data : (json.equipos || []);

            selEq.innerHTML = '<option value="">Seleccione equipo</option>';
            if (list.length === 0) {
                selEq.innerHTML = '<option value="">Sin equipos para este cliente</option>';
            } else {
                list.forEach(eq => {
                    const mod = eq.modelo_nombre || eq.modelo || 'Equipo Multifuncional';
                    const serie = eq.serie ? ` (Serie: ${eq.serie})` : '';
                    const cod = eq.codigo_interno ? `[${eq.codigo_interno}] ` : '';
                    selEq.innerHTML += `<option value="${eq.id}">${cod}${mod}${serie}</option>`;
                });
                selEq.disabled = false;
            }
        } catch (e) {
            console.error('Error cargando equipos TNG:', e);
            selEq.innerHTML = '<option value="">Error al cargar equipos</option>';
        }
    });
});
</script>