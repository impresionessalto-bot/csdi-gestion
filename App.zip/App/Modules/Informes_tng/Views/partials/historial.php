<?php

declare(strict_types=1);

$ultimos = is_array($ultimos ?? null) ? $ultimos : [];
$esViewer = (bool)($esViewer ?? false);

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        if (is_array($value)) {
            return htmlspecialchars(implode(', ', array_filter($value, 'is_scalar')), ENT_QUOTES, 'UTF-8');
        }
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

?>

<div class="card border-0 shadow-sm rounded-3 overflow-hidden">

    <!-- BUSCADOR SMART SEARCH -->
    <div class="card-header bg-dark text-white py-3">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <div class="fw-bold">
                    <i class="fa-solid fa-list text-info me-2"></i>
                    Historial de informes técnicos
                </div>
                <div class="small text-white-50">
                    Busque y ordene los informes en tiempo real.
                </div>
            </div>

            <div style="min-width:280px;">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="fa-solid fa-magnifying-glass text-secondary"></i>
                    </span>
                    <input
                        type="search"
                        id="smartSearchTng"
                        class="form-control border-start-0 csdi-smart-search"
                        data-target-table="tablaInformesTng"
                        placeholder="Buscar informe, cliente, serie..."
                        autocomplete="off"
                    >
                </div>
            </div>
        </div>
    </div>

    <!-- TABLA DE INFORMES -->
    <div class="table-responsive">
        <table
            class="table table-hover align-middle mb-0"
            id="tablaInformesTng"
        >
            <thead class="table-light">
                <tr>
                    <th class="ps-4">
                        <span class="sort-trigger" data-col="0">
                            Nº Informe <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="1">
                            Fecha <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="2">
                            Cliente <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="3">
                            Localidad <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="4">
                            Código TNG <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="5">
                            Serie <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="6">
                            Modelo <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="7">
                            Facturación <i class="fa-solid fa-sort ms-1 small"></i>
                        </span>
                    </th>
                    <th>PDF</th>
                    <?php if (!$esViewer): ?>
                        <th class="text-end pe-4">Acciones</th>
                    <?php endif; ?>
                </tr>
            </thead>

            <tbody>
            <?php if (empty($ultimos)): ?>
                <tr>
                    <td colspan="<?= $esViewer ? 9 : 10 ?>" class="text-center text-muted py-5">
                        <i class="fa-solid fa-folder-open fs-2 mb-2"></i>
                        <div>No hay informes cargados.</div>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($ultimos as $i): ?>
                    <?php
                    if (!is_array($i)) {
                        continue;
                    }

                    $iId       = (int)($i['id'] ?? 0);
                    $iNro      = (string)($i['nro_informe'] ?? '');
                    $iFecha    = (string)($i['fecha'] ?? '');
                    $iCliente  = (string)($i['cliente'] ?? $i['cliente_nombre'] ?? 'Sin cliente');
                    $iLocalidad= (string)($i['localidad_nombre'] ?? $i['localidad'] ?? 'Taller');
                    
                    $iCodigo   = trim((string)($i['codigo_tng'] ?? $i['codigo_interno'] ?? ''));
                    $iSerie    = trim((string)($i['serie'] ?? $i['nro_serie'] ?? $i['numero_serie'] ?? ''));
                    
                    $marca     = trim((string)($i['marca'] ?? ''));
                    $modeloNom = trim((string)($i['nombre_modelo'] ?? $i['modelo_nombre'] ?? $i['modelo'] ?? ''));
                    
                    if ($modeloNom !== '') {
                        $iModelo = ($marca !== '' && !str_contains(strtoupper($modeloNom), strtoupper($marca))) 
                            ? $marca . ' ' . $modeloNom 
                            : $modeloNom;
                    } else {
                        $iModelo = 'Multifuncional';
                    }

                    $factArca     = !empty($i['fact_contador_arca']);
                    $factGeneral  = !empty($i['fact_contador_general']);
                    $factServicio = !empty($i['fact_servicio_tecnico']);
                    $pdfPath      = (string)($i['pdf_path'] ?? $i['archivo_pdf'] ?? '');
                    ?>

                    <tr class="fila-informe">
                        <td class="ps-4 fw-bold text-primary">
                            <?= h($iNro) ?>
                        </td>

                        <td data-sort-value="<?= h($iFecha) ?>" class="font-monospace small">
                            <?= h($iFecha !== '' ? date('d/m/Y', strtotime($iFecha)) : '-') ?>
                        </td>

                        <td class="fw-semibold text-dark">
                            <?= h($iCliente) ?>
                        </td>

                        <td>
                            <?= h($iLocalidad) ?>
                        </td>

                        <td>
                            <span class="badge bg-secondary">
                                <?= h($iCodigo !== '' ? $iCodigo : '-') ?>
                            </span>
                        </td>

                        <td class="font-monospace text-secondary small">
                            <?= h($iSerie !== '' ? $iSerie : '-') ?>
                        </td>

                        <td class="small fw-semibold">
                            <?= h($iModelo) ?>
                        </td>

                        <td>
                            <?php if ($factArca): ?>
                                <span class="badge bg-danger me-1">ARCA</span>
                            <?php endif; ?>

                            <?php if ($factGeneral): ?>
                                <span class="badge bg-primary me-1">GENERAL</span>
                            <?php endif; ?>

                            <?php if ($factServicio): ?>
                                <span class="badge bg-warning text-dark me-1">SERVICIO</span>
                            <?php endif; ?>

                            <?php if (!$factArca && !$factGeneral && !$factServicio): ?>
                                <span class="text-muted small">Sin facturar</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($iId > 0): ?>
                                <a href="/informes-tng/pdf/<?= $iId ?>" target="_blank" rel="noopener" class="btn btn-danger btn-sm px-2" title="Ver PDF">
                                    <i class="fa-solid fa-file-pdf"></i>
                                </a>
                            <?php else: ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>

                        <?php if (!$esViewer): ?>
                            <td class="text-end pe-4">
                                <div class="btn-group btn-group-sm">
                                    <a href="/informes-tng/editar/<?= $iId ?>" class="btn btn-warning px-2" title="Editar">
                                        <i class="fa-solid fa-pen text-dark"></i>
                                    </a>
                                    <button type="button" class="btn btn-danger btnEliminarInforme px-2" data-id="<?= $iId ?>" title="Eliminar">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // =================================================================
    // 1. MOTOR DE BÚSQUEDA EN CALIENTE (SMART SEARCH)
    // =================================================================
    const inputSearch = document.getElementById('smartSearchTng');

    if (inputSearch) {
        inputSearch.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            const filas = document.querySelectorAll('.fila-informe');

            filas.forEach(fila => {
                const text = fila.textContent.toLowerCase();
                fila.style.setProperty('display', text.includes(query) ? '' : 'none', 'important');
            });
        });
    }

    // =================================================================
    // 2. MOTOR DE ORDENAMIENTO EN CALIENTE (SORTING)
    // =================================================================
    const sortTriggers = document.querySelectorAll('#tablaInformesTng .sort-trigger');
    let directions = {};

    sortTriggers.forEach(trigger => {
        trigger.style.cursor = 'pointer';
        trigger.addEventListener('click', function() {
            const colIndex = parseInt(this.getAttribute('data-col'));
            const table = this.closest('table');
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('.fila-informe'));

            if (rows.length === 0) return;

            const currentDir = directions[colIndex] || 'asc';
            const nextDir = currentDir === 'asc' ? 'desc' : 'asc';
            directions[colIndex] = nextDir;

            // Limpiar los iconos de todas las columnas de la tabla
            table.querySelectorAll('.sort-trigger i').forEach(icon => {
                icon.className = 'fa-solid fa-sort text-muted ms-1 small';
            });

            // Asignar el icono correspondiente de ordenamiento
            const activeIcon = this.querySelector('i');
            if (activeIcon) {
                activeIcon.className = nextDir === 'asc' 
                    ? 'fa-solid fa-sort-up text-primary ms-1 small' 
                    : 'fa-solid fa-sort-down text-primary ms-1 small';
            }

            // Lógica de ordenamiento
            const sortedRows = rows.sort((a, b) => {
                const cellA = a.querySelectorAll('td')[colIndex];
                const cellB = b.querySelectorAll('td')[colIndex];

                if (!cellA || !cellB) return 0;

                // Ordenamiento por fecha si existe el atributo data-sort-value
                const dateA = cellA.getAttribute('data-sort-value');
                const dateB = cellB.getAttribute('data-sort-value');
                if (dateA && dateB) {
                    const timeA = new Date(dateA).getTime() || 0;
                    const timeB = new Date(dateB).getTime() || 0;
                    return nextDir === 'asc' ? timeA - timeB : timeB - timeA;
                }

                const textA = cellA.textContent.trim();
                const textB = cellB.textContent.trim();

                // Ordenamiento por número correlativo
                const numA = parseFloat(textA.replace(/[^0-9\.\-]/g, ''));
                const numB = parseFloat(textB.replace(/[^0-9\.\-]/g, ''));
                if (!isNaN(numA) && !isNaN(numB)) {
                    return nextDir === 'asc' ? numA - numB : numB - numA;
                }

                // Ordenamiento alfabético general
                return nextDir === 'asc' 
                    ? textA.localeCompare(textB, 'es', { sensitivity: 'base' }) 
                    : textB.localeCompare(textA, 'es', { sensitivity: 'base' });
            });

            // Aplicar el orden reinyectando las filas al tbody
            sortedRows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>