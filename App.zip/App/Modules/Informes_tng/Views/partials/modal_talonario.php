<?php
declare(strict_types=1);

$csrfToken = function_exists('csrf_token') ? csrf_token() : ($csrf ?? '');
?>

<div class="modal fade" id="modalTalonario" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 12px; overflow: hidden;">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-book-medical me-2"></i> Nuevo talonario TNG</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 bg-white">
                <form id="formTalonario" method="POST" action="/informes-tng/guardar-talonario">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars((string)$csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)$csrfToken, ENT_QUOTES, 'UTF-8') ?>">

                    <div class="mb-3">
                        <label class="form-label text-dark fw-semibold small">Nombre / Código del Talonario</label>
                        <input type="text" class="form-control fw-bold" name="nombre" placeholder="Ej: TAL8201" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-dark fw-semibold small">Número Desde</label>
                            <input type="number" class="form-control fw-bold" name="desde" id="tal_desde" min="1" placeholder="Ej: 1001" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-dark fw-semibold small">Número Hasta</label>
                            <input type="number" class="form-control fw-bold" name="hasta" id="tal_hasta" min="1" placeholder="Ej: 1050" required>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-success btn-sm fw-bold" id="btnGuardarTalonario">
                    <i class="fa-solid fa-save me-1"></i> Guardar Talonario
                </button>
            </div>
        </div>
    </div>
</div>

<!-- =====================================================
     SCRIPT AJAX DE ENVÍO DE TALONARIO CON CSRF
     ===================================================== -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const btnGuardar = document.getElementById('btnGuardarTalonario');
    const formTalonario = document.getElementById('formTalonario');

    if (btnGuardar && formTalonario) {
        btnGuardar.addEventListener('click', async () => {
            const desde = parseInt(document.getElementById('tal_desde')?.value) || 0;
            const hasta = parseInt(document.getElementById('tal_hasta')?.value) || 0;

            if (desde <= 0 || hasta <= desde) {
                alert('El rango de numeración es inválido. El número "Hasta" debe ser mayor al número "Desde".');
                return;
            }

            try {
                btnGuardar.disabled = true;
                btnGuardar.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Guardando...';

                const formData = new FormData(formTalonario);

                // Intenta enviar a la ruta /guardar-talonario o /talonario
                let r = await fetch('/informes-tng/guardar-talonario', {
                    method: 'POST',
                    body: formData
                });

                if (!r.ok) {
                    r = await fetch('/informes-tng/talonario', {
                        method: 'POST',
                        body: formData
                    });
                }

                if (r.ok) {
                    window.location.reload();
                } else {
                    alert('Error al intentar guardar el talonario. Verifique los campos.');
                    btnGuardar.disabled = false;
                    btnGuardar.innerHTML = '<i class="fa-solid fa-save me-1"></i> Guardar Talonario';
                }
            } catch (e) {
                console.error('Error al guardar talonario:', e);
                alert('Ocurrió un error técnico de conexión.');
                btnGuardar.disabled = false;
                btnGuardar.innerHTML = '<i class="fa-solid fa-save me-1"></i> Guardar Talonario';
            }
        });
    }
});
</script>

<!-- ========================================================================
     MODAL EDITAR TALONARIO
     ======================================================================== -->
<div class="modal fade" id="modalEditarTalonario" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg" style="border-radius:12px; overflow:hidden;">
            <div class="modal-header bg-warning">
                <h5 class="modal-title fw-bold">
                    <i class="fa-solid fa-pen-to-square me-2"></i>
                    Editar talonario TNG
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="formEditarTalonario" method="POST">
                <div class="modal-body p-4">
                    <input
                        type="hidden"
                        name="csrf"
                        value="<?= htmlspecialchars((string)$csrfToken, ENT_QUOTES, 'UTF-8') ?>"
                    >
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= htmlspecialchars((string)$csrfToken, ENT_QUOTES, 'UTF-8') ?>"
                    >

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">
                            Nombre / Código
                        </label>
                        <input
                            type="text"
                            class="form-control fw-bold"
                            name="nombre"
                            id="editarTalonarioNombre"
                            required
                        >
                    </div>

                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold small">
                                Desde
                            </label>
                            <input
                                type="number"
                                class="form-control"
                                name="desde"
                                id="editarTalonarioDesde"
                                min="1"
                                required
                            >
                        </div>

                        <div class="col-6">
                            <label class="form-label fw-semibold small">
                                Hasta
                            </label>
                            <input
                                type="number"
                                class="form-control"
                                name="hasta"
                                id="editarTalonarioHasta"
                                min="1"
                                required
                            >
                        </div>
                    </div>

                    <div
                        id="editarTalonarioAviso"
                        class="alert alert-warning small mt-3 mb-0 d-none"
                    ></div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        data-bs-dismiss="modal"
                    >
                        Cancelar
                    </button>

                    <button
                        type="submit"
                        class="btn btn-warning fw-semibold"
                        id="btnActualizarTalonario"
                    >
                        <i class="fa-solid fa-save me-1"></i>
                        Guardar cambios
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    document.querySelectorAll('.btnEditarTalonario').forEach(function (button) {
        button.addEventListener('click', function () {
            const id = this.dataset.id || '';
            const nombre = this.dataset.nombre || '';
            const desde = this.dataset.desde || '';
            const hasta = this.dataset.hasta || '';

            if (!id) {
                return;
            }

            const form = document.getElementById('formEditarTalonario');
            const nombreInput = document.getElementById('editarTalonarioNombre');
            const desdeInput = document.getElementById('editarTalonarioDesde');
            const hastaInput = document.getElementById('editarTalonarioHasta');
            const aviso = document.getElementById('editarTalonarioAviso');

            if (!form || !nombreInput || !desdeInput || !hastaInput) {
                return;
            }

            form.action = '/informes-tng/talonario/' + encodeURIComponent(id) + '/actualizar';
            nombreInput.value = nombre;
            desdeInput.value = desde;
            hastaInput.value = hasta;
            aviso.classList.add('d-none');
            aviso.textContent = '';

            const modalElement = document.getElementById('modalEditarTalonario');

            if (window.bootstrap && bootstrap.Modal) {
                bootstrap.Modal.getOrCreateInstance(modalElement).show();
            }
        });
    });

    const editForm = document.getElementById('formEditarTalonario');

    if (editForm) {
        editForm.addEventListener('submit', function (event) {
            const desde = Number(document.getElementById('editarTalonarioDesde')?.value || 0);
            const hasta = Number(document.getElementById('editarTalonarioHasta')?.value || 0);
            const aviso = document.getElementById('editarTalonarioAviso');

            if (desde <= 0 || hasta <= 0 || desde > hasta) {
                event.preventDefault();

                if (aviso) {
                    aviso.textContent = 'El rango de numeración es inválido.';
                    aviso.classList.remove('d-none');
                }
            }
        });
    }
});
</script>

