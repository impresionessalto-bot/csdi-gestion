<?php

declare(strict_types=1);

$talonarios = is_array($talonarios ?? null) ? $talonarios : [];
$esViewer   = (bool)($esViewer ?? false);
$csrfToken  = function_exists('csrf_token')
    ? csrf_token()
    : (string)($csrf ?? '');

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        if (is_array($value)) {
            return htmlspecialchars(implode(', ', array_filter($value, 'is_scalar')), ENT_QUOTES, 'UTF-8');
        }
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

?>

<div class="card border-0 shadow-sm rounded-3 overflow-hidden">

    <div class="card-header bg-dark text-white py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <div class="fw-bold">
                    <i class="fa-solid fa-book text-warning me-2"></i>
                    Talonarios de informes técnicos
                </div>
                <div class="small text-white-50">
                    Administración y control de numeración.
                </div>
            </div>

            <?php if (!$esViewer): ?>
                <button
                    type="button"
                    class="btn btn-warning btn-sm fw-semibold"
                    data-bs-toggle="modal"
                    data-bs-target="#modalTalonario"
                >
                    <i class="fa-solid fa-plus me-1"></i>
                    Nuevo talonario
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-responsive">
        <table
            class="table table-hover align-middle mb-0"
            id="tablaTalonariosTng"
        >
            <thead class="table-light">
                <tr>
                    <th class="ps-4">
                        <span class="sort-trigger" data-col="0">
                            Talonario <i class="fa-solid fa-sort ms-1"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="1">
                            Desde <i class="fa-solid fa-sort ms-1"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="2">
                            Hasta <i class="fa-solid fa-sort ms-1"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="3">
                            Utilizados <i class="fa-solid fa-sort ms-1"></i>
                        </span>
                    </th>
                    <th>
                        <span class="sort-trigger" data-col="4">
                            Faltantes <i class="fa-solid fa-sort ms-1"></i>
                        </span>
                    </th>
                    <th>Estado</th>
                    <?php if (!$esViewer): ?>
                        <th class="text-end pe-4">Acciones</th>
                    <?php endif; ?>
                </tr>
            </thead>

            <tbody>
            <?php if (empty($talonarios)): ?>
                <tr>
                    <td
                        colspan="<?= $esViewer ? 6 : 7 ?>"
                        class="text-center text-muted py-5"
                    >
                        No hay talonarios registrados.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($talonarios as $talonario): ?>
                    <?php
                    if (!is_array($talonario)) {
                        continue;
                    }

                    $id = (int)($talonario['id'] ?? 0);

                    $numero = (string)(
                        $talonario['numero']
                        ?? $talonario['nro_talonario']
                        ?? $talonario['nombre']
                        ?? ''
                    );

                    $desde = (int)(
                        $talonario['desde']
                        ?? $talonario['nro_desde']
                        ?? $talonario['numero_desde']
                        ?? 0
                    );

                    $hasta = (int)(
                        $talonario['hasta']
                        ?? $talonario['nro_hasta']
                        ?? $talonario['numero_hasta']
                        ?? 0
                    );

                    $utilizados = (int)(
                        $talonario['utilizados']
                        ?? $talonario['informes_cargados']
                        ?? $talonario['usados']
                        ?? 0
                    );

                    $faltantes = (int)(
                        $talonario['faltantes']
                        ?? $talonario['cantidad_faltantes']
                        ?? max(0, $hasta - $desde + 1 - $utilizados)
                    );

                    $estado = strtoupper(
                        (string)(
                            $talonario['estado']
                            ?? 'ACTIVO'
                        )
                    );
                    ?>

                    <!-- Agregada clase fila-talonario para identificar las filas de datos -->
                    <tr class="fila-talonario">
                        <td class="ps-4 fw-bold">
                            <?= h($numero !== '' ? $numero : '#' . $id) ?>
                        </td>

                        <td class="font-monospace">
                            <?= h($desde) ?>
                        </td>

                        <td class="font-monospace">
                            <?= h($hasta) ?>
                        </td>

                        <td>
                            <span class="badge bg-success">
                                <?= h($utilizados) ?>
                            </span>
                        </td>

                        <td>
                            <?php if ($faltantes > 0): ?>
                                <span class="badge bg-danger">
                                    <?= h($faltantes) ?>
                                </span>
                            <?php else: ?>
                                <span class="badge bg-success">
                                    0
                                </span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($estado === 'FINALIZADO' || $estado === 'CERRADO'): ?>
                                <span class="badge bg-secondary">
                                    Finalizado
                                </span>
                            <?php elseif ($faltantes > 0): ?>
                                <span class="badge bg-warning text-dark">
                                    Pendiente
                                </span>
                            <?php else: ?>
                                <span class="badge bg-success">
                                    Completo
                                </span>
                            <?php endif; ?>
                        </td>

                        <?php if (!$esViewer): ?>
                            <td class="text-end pe-4">
                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-primary btnEditarTalonario"
                                    data-id="<?= h($id) ?>"
                                    data-nombre="<?= h($talonario['nombre'] ?? '') ?>"
                                    data-desde="<?= h($desde) ?>"
                                    data-hasta="<?= h($hasta) ?>"
                                    title="Editar"
                                >
                                    <i class="fa-solid fa-pen"></i>
                                </button>

                                <form
                                    method="POST"
                                    action="/informes-tng/talonario/<?= h($id) ?>/eliminar"
                                    class="d-inline"
                                    onsubmit="return confirm('¿Eliminar este talonario? Solo podrá eliminarse si no contiene informes utilizados.');"
                                >
                                    <input
                                        type="hidden"
                                        name="csrf"
                                        value="<?= h($csrfToken) ?>"
                                    >
                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h($csrfToken) ?>"
                                    >
                                    <button
                                        type="submit"
                                        class="btn btn-sm btn-outline-danger"
                                        title="Eliminar"
                                    >
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // =================================================================
    // MOTOR DE ORDENAMIENTO EN CALIENTE PARA TALONARIOS (SORTING)
    // =================================================================
    const sortTriggers = document.querySelectorAll('#tablaTalonariosTng .sort-trigger');
    let directions = {};

    sortTriggers.forEach(trigger => {
        trigger.style.cursor = 'pointer';
        trigger.addEventListener('click', function() {
            const colIndex = parseInt(this.getAttribute('data-col'));
            const table = this.closest('table');
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('.fila-talonario'));

            if (rows.length === 0) return;

            const currentDir = directions[colIndex] || 'asc';
            const nextDir = currentDir === 'asc' ? 'desc' : 'asc';
            directions[colIndex] = nextDir;

            // Limpiar los iconos de todas las columnas de la tabla
            table.querySelectorAll('.sort-trigger i').forEach(icon => {
                icon.className = 'fa-solid fa-sort text-muted ms-1 small';
            });

            // Asignar el icono correspondiente de ordenamiento
            const activeIcon = this.querySelector('i');
            if (activeIcon) {
                activeIcon.className = nextDir === 'asc' 
                    ? 'fa-solid fa-sort-up text-primary ms-1 small' 
                    : 'fa-solid fa-sort-down text-primary ms-1 small';
            }

            // Lógica de ordenamiento
            const sortedRows = rows.sort((a, b) => {
                const cellA = a.querySelectorAll('td')[colIndex];
                const cellB = b.querySelectorAll('td')[colIndex];

                if (!cellA || !cellB) return 0;

                const textA = cellA.textContent.trim();
                const textB = cellB.textContent.trim();

                // Intentar ordenamiento por número (para Desde, Hasta, Utilizados y Faltantes)
                const numA = parseFloat(textA.replace(/[^0-9\.\-]/g, ''));
                const numB = parseFloat(textB.replace(/[^0-9\.\-]/g, ''));
                if (!isNaN(numA) && !isNaN(numB)) {
                    return nextDir === 'asc' ? numA - numB : numB - numA;
                }

                // Ordenamiento alfabético general (para la columna Talonario)
                return nextDir === 'asc' 
                    ? textA.localeCompare(textB, 'es', { sensitivity: 'base' }) 
                    : textB.localeCompare(textA, 'es', { sensitivity: 'base' });
            });

            // Aplicar el orden reinyectando las filas al tbody
            sortedRows.forEach(row => tbody.appendChild(row));
        });
    });
});
</script>