<?php

declare(strict_types=1);

$informe = $informe ?? [];
$localidades = $localidades ?? [];
$clientes = $clientes ?? [];
$equipos = $equipos ?? [];


if(!function_exists('h')){

    function h(mixed $v):string
    {
        return htmlspecialchars(
            (string)($v ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }

}


$facturacion = '';


if(
    !empty($informe['fact_contador_arca'])
){
    $facturacion='ARCA';
}
elseif(
    !empty($informe['fact_contador_general'])
){
    $facturacion='GENERAL';
}
elseif(
    !empty($informe['fact_servicio_tecnico'])
){
    $facturacion='SERVICIO';
}

?>


<div class="container-fluid px-4">


<h2 class="mt-4 mb-4">

<i class="fa-solid fa-file-pen text-warning"></i>

Editar Informe Técnico TNG

</h2>



<div class="card shadow-sm">


<div class="card-header bg-warning">

<i class="fa-solid fa-edit"></i>

Modificar Informe Nº

<?=h($informe['nro_informe'] ?? '')?>

</div>



<div class="card-body">



<form

id="formInforme"

method="POST"

action="<?=base_url(
    'informes-tng/actualizar/' .
    (int)($informe['id'] ?? 0)
)?>"

enctype="multipart/form-data">


<input

type="hidden"

name="csrf"

value="<?=h($csrf ?? '')?>"

>




<div class="row g-3">



<!-- LOCALIDAD -->

<div class="col-md-4">

<label class="form-label">
Localidad
</label>


<select

id="localidad_id"

name="localidad_id"

class="form-select"

required>


<option value="">
Seleccione localidad
</option>


<?php foreach($localidades as $l): ?>

<option

value="<?=$l['id']?>"

<?=

((int)$l['id'] ===
(int)($informe['localidad_id'] ?? 0))

?'selected'
:''

?>

>

<?=h($l['nombre'])?>

</option>


<?php endforeach; ?>


</select>


</div>






<!-- CLIENTE -->

<div class="col-md-4">


<label class="form-label">

Cliente

</label>


<select

id="cliente_id"

name="cliente_id"

class="form-select"

required>


<option value="">

Seleccione cliente

</option>


<?php foreach($clientes as $c): ?>


<option

value="<?=$c['id']?>"

<?=

((int)$c['id'] ===
(int)($informe['cliente_id'] ?? 0))

?'selected'
:''

?>

>

<?=h($c['nombre'])?>

</option>


<?php endforeach; ?>


</select>


</div>







<!-- EQUIPO -->


<div class="col-md-4">


<label class="form-label">

Equipo TNG

</label>


<select

id="equipo_id"

name="equipo_id"

class="form-select"

required>


<option value="">

Seleccione equipo

</option>


<?php foreach($equipos as $e): ?>


<option

value="<?=$e['id']?>"

<?=

((int)$e['id'] ===
(int)($informe['equipo_id'] ?? 0))

?'selected'
:''

?>

>


<?=h(
    ($e['codigo_interno'] ?? '') .
    ' - ' .
    ($e['marca'] ?? '') .
    ' ' .
    ($e['nombre_modelo'] ?? '')
)?>


</option>


<?php endforeach; ?>


</select>


</div>





<!-- FECHA -->


<div class="col-md-4">


<label class="form-label">

Fecha

</label>


<input

type="date"

name="fecha"

class="form-control"

value="<?=

!empty($informe['fecha'])

?

date(
'Y-m-d',
strtotime($informe['fecha'])
)

:

date('Y-m-d')

?>"

>


</div>




<!-- FACTURACION -->

<div class="col-md-4">


<label class="form-label">

Tipo de cobro

</label>



<select

name="facturacion_tng"

id="facturacion_tng"

class="form-select"

required>


<option value="">

Seleccione

</option>



<option

value="ARCA"

<?=$facturacion==='ARCA'
?'selected'
:''?>

>

Contador ARCA

</option>



<option

value="GENERAL"

<?=$facturacion==='GENERAL'
?'selected'
:''?>

>

Contador General

</option>



<option

value="SERVICIO"

<?=$facturacion==='SERVICIO'
?'selected'
:''?>

>

Servicio Técnico

</option>



</select>


</div>





<!-- OBSERVACIONES -->


<div class="col-12">


<label class="form-label">

Observaciones

</label>


<textarea

name="observaciones"

class="form-control"

rows="4"

><?=h(
$informe['observaciones'] ?? ''
)?></textarea>


</div>
<!-- PDF -->

<div class="col-12">


<h5>

<i class="fa-solid fa-file-pdf text-danger"></i>

Archivo PDF

</h5>



<?php if(!empty($informe['archivo_path'])): ?>


<div class="alert alert-success">


PDF actual:

<br>


<strong>

<?=h(
basename(
$informe['archivo_path']
)
)?>

</strong>


<br><br>


<a

target="_blank"

class="btn btn-danger btn-sm"

href="<?=base_url(
'informes-tng/pdf/' .
(int)$informe['id']
)?>"

>

<i class="fa-solid fa-eye"></i>

Ver PDF

</a>


</div>


<?php endif; ?>



<input

type="file"

name="informe"

accept="application/pdf"

class="form-control"

>


<div class="form-text">

Al editar no es obligatorio subir un nuevo PDF.

</div>


</div>







<!-- BOTONES -->


<div class="col-12 mt-4">


<div class="d-flex justify-content-end gap-2">


<a

href="<?=base_url(
'informes-tng'
)?>"

class="btn btn-secondary"

>

Cancelar

</a>



<button

type="submit"

class="btn btn-primary"

>

<i class="fa-solid fa-save"></i>

Guardar cambios

</button>


</div>


</div>






</div>


</form>


</div>

</div>


</div>







<script>


window.CSDI = {

baseUrl:
<?=json_encode(
base_url()
)?>


};





/*
|--------------------------------------------------------------------------
| FACTURACION TNG
|--------------------------------------------------------------------------
|
| Convierte el selector único en los 3 campos
| que usa historial_informes
|
*/


document
.getElementById('formInforme')
.addEventListener(
'submit',
function(){


const tipo =
document.getElementById(
'facturacion_tng'
).value;



let arca = document.createElement('input');

arca.type='hidden';
arca.name='fact_contador_arca';


let general = document.createElement('input');

general.type='hidden';
general.name='fact_contador_general';


let servicio = document.createElement('input');

servicio.type='hidden';
servicio.name='fact_servicio_tecnico';



arca.value =
tipo==='ARCA'
?1
:0;


general.value =
tipo==='GENERAL'
?1
:0;


servicio.value =
tipo==='SERVICIO'
?1
:0;



this.appendChild(arca);
this.appendChild(general);
this.appendChild(servicio);



});







/*
|--------------------------------------------------------------------------
| LOCALIDAD -> CLIENTES
|--------------------------------------------------------------------------
*/


const localidad =
document.getElementById(
'localidad_id'
);


const cliente =
document.getElementById(
'cliente_id'
);


const equipo =
document.getElementById(
'equipo_id'
);




if(localidad && cliente){


localidad.addEventListener(
'change',
async function(){


cliente.innerHTML =
'<option>Cargando...</option>';


if(equipo){

equipo.innerHTML =
'<option>Seleccione equipo</option>';

}



try{


const r =
await fetch(

window.CSDI.baseUrl +

'informes-tng/clientes?localidad_id=' +

this.value

);



const json =
await r.json();



cliente.innerHTML =
'<option value="">Seleccione cliente</option>';



(json.data ?? []).forEach(c=>{


cliente.innerHTML +=

`
<option value="${c.id}">
${c.nombre}
</option>
`;


});



}
catch(e){


console.error(e);


cliente.innerHTML =
'<option>Error cargando clientes</option>';


}



});



}







/*
|--------------------------------------------------------------------------
| CLIENTE -> EQUIPOS
|--------------------------------------------------------------------------
*/


if(cliente && equipo){


cliente.addEventListener(
'change',
async function(){


equipo.innerHTML =
'<option>Cargando...</option>';



try{


const r =
await fetch(

window.CSDI.baseUrl +

'informes-tng/equipos?cliente_id=' +

this.value

);



const json =
await r.json();



equipo.innerHTML =
'<option value="">Seleccione equipo</option>';



(json.data ?? []).forEach(e=>{


equipo.innerHTML +=


`
<option value="${e.id}">
${e.codigo_interno ?? ''}
-
${e.marca ?? ''}
${e.nombre_modelo ?? ''}
</option>
`;



});


}
catch(error){


console.error(error);


equipo.innerHTML =
'<option>Error cargando equipos</option>';


}



});


}



</script>