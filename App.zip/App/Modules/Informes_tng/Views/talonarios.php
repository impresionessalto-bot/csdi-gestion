<?php

declare(strict_types=1);

$talonarios = is_array(
    $talonarios ?? null
)
    ? $talonarios
    : [];

$esViewer = (bool)(
    $esViewer ?? false
);

$csrfToken = function_exists('csrf_token')
    ? csrf_token()
    : (string)($csrf ?? '');

if (!function_exists('h')) {

    function h(mixed $value): string
    {
        if (is_array($value)) {

            return htmlspecialchars(
                implode(
                    ', ',
                    array_filter(
                        $value,
                        'is_scalar'
                    )
                ),
                ENT_QUOTES,
                'UTF-8'
            );
        }

        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

?>

<div class="card border-0 shadow-sm rounded-3 overflow-hidden">

    <!-- ================================================================
         CABECERA
         ================================================================ -->

    <div class="card-header bg-dark text-white py-3">

        <div class="d-flex justify-content-between align-items-center">

            <div>

                <div class="fw-bold">

                    <i
                        class="fa-solid fa-book text-warning me-2"
                    ></i>

                    Talonarios de informes técnicos

                </div>

                <div class="small text-white-50">

                    Administración y control de numeración.

                </div>

            </div>

            <div class="d-flex flex-wrap gap-2">

                <!-- ====================================================
                     EXPORTAR PDF
                     ==================================================== -->

                <a
                    href="/informes-tng/talonarios/exportar-pdf"
                    class="btn btn-danger btn-sm fw-semibold"
                    title="Exportar talonarios a PDF"
                >

                    <i
                        class="fa-solid fa-file-pdf me-1"
                    ></i>

                    PDF

                </a>

                <!-- ====================================================
                     EXPORTAR XLS
                     ==================================================== -->

                <a
                    href="/informes-tng/talonarios/exportar-excel"
                    class="btn btn-success btn-sm fw-semibold"
                    title="Exportar talonarios a Excel"
                >

                    <i
                        class="fa-solid fa-file-excel me-1"
                    ></i>

                    XLS

                </a>

                <!-- ====================================================
                     NUEVO TALONARIO
                     ==================================================== -->

                <?php if (!$esViewer): ?>

                    <button
                        type="button"
                        class="btn btn-warning btn-sm fw-semibold"
                        data-bs-toggle="modal"
                        data-bs-target="#modalTalonario"
                    >

                        <i
                            class="fa-solid fa-plus me-1"
                        ></i>

                        Nuevo talonario

                    </button>

                <?php endif; ?>

            </div>

        </div>

    </div>


    <!-- ================================================================
         TABLA
         ================================================================ -->

    <div class="table-responsive">

        <table
            class="table table-hover align-middle mb-0"
            id="tablaTalonariosTng"
        >

            <thead class="table-light">

                <tr>

                    <th class="ps-4">

                        <span
                            class="sort-trigger"
                            data-col="0"
                        >

                            Talonario

                            <i
                                class="fa-solid fa-sort ms-1"
                            ></i>

                        </span>

                    </th>

                    <th>

                        <span
                            class="sort-trigger"
                            data-col="1"
                        >

                            Desde

                            <i
                                class="fa-solid fa-sort ms-1"
                            ></i>

                        </span>

                    </th>

                    <th>

                        <span
                            class="sort-trigger"
                            data-col="2"
                        >

                            Hasta

                            <i
                                class="fa-solid fa-sort ms-1"
                            ></i>

                        </span>

                    </th>

                    <th>

                        <span
                            class="sort-trigger"
                            data-col="3"
                        >

                            Utilizados

                            <i
                                class="fa-solid fa-sort ms-1"
                            ></i>

                        </span>

                    </th>

                    <th>

                        <span
                            class="sort-trigger"
                            data-col="4"
                        >

                            Faltantes

                            <i
                                class="fa-solid fa-sort ms-1"
                            ></i>

                        </span>

                    </th>

                    <th>
                        Estado
                    </th>

                    <?php if (!$esViewer): ?>

                        <th class="text-end pe-4">
                            Acciones
                        </th>

                    <?php endif; ?>

                </tr>

            </thead>


            <tbody>

            <?php if (empty($talonarios)): ?>

                <tr>

                    <td
                        colspan="<?= $esViewer ? 6 : 7 ?>"
                        class="text-center text-muted py-5"
                    >

                        <i
                            class="fa-solid fa-folder-open fa-2x mb-3 d-block"
                        ></i>

                        No hay talonarios registrados.

                    </td>

                </tr>

            <?php else: ?>

                <?php foreach ($talonarios as $talonario): ?>

                    <?php

                    if (!is_array($talonario)) {
                        continue;
                    }

                    $id = (int)(
                        $talonario['id'] ?? 0
                    );

                    /*
                     * ----------------------------------------------------
                     * NOMBRE / TALONARIO
                     * ----------------------------------------------------
                     */

                    $numero = (string)(
                        $talonario['numero']
                        ?? $talonario['nro_talonario']
                        ?? $talonario['nombre']
                        ?? ''
                    );

                    /*
                     * ----------------------------------------------------
                     * DESDE
                     * ----------------------------------------------------
                     */

                    $desde = (int)(
                        $talonario['desde']
                        ?? $talonario['num_desde']
                        ?? $talonario['numero_desde']
                        ?? $talonario['nro_desde']
                        ?? 0
                    );

                    /*
                     * ----------------------------------------------------
                     * HASTA
                     * ----------------------------------------------------
                     */

                    $hasta = (int)(
                        $talonario['hasta']
                        ?? $talonario['num_hasta']
                        ?? $talonario['numero_hasta']
                        ?? $talonario['nro_hasta']
                        ?? 0
                    );

                    /*
                     * ----------------------------------------------------
                     * UTILIZADOS
                     * ----------------------------------------------------
                     */

                    $utilizados = (int)(
                        $talonario['utilizados']
                        ?? $talonario['informes_cargados']
                        ?? $talonario['usados']
                        ?? 0
                    );

                    /*
                     * ----------------------------------------------------
                     * FALTANTES
                     * ----------------------------------------------------
                     */

                    $faltantes = (int)(
                        $talonario['faltantes']
                        ?? $talonario['cantidad_faltantes']
                        ?? max(
                            0,
                            $hasta
                            - $desde
                            + 1
                            - $utilizados
                        )
                    );

                    /*
                     * ----------------------------------------------------
                     * ESTADO
                     * ----------------------------------------------------
                     */

                    $estado = strtoupper(
                        (string)(
                            $talonario['estado']
                            ?? 'ACTIVO'
                        )
                    );

                    ?>

                    <tr>

                        <!-- =================================================
                             TALONARIO
                             ================================================= -->

                        <td class="ps-4 fw-bold">

                            <?= h(
                                $numero !== ''
                                    ? $numero
                                    : '#' . $id
                            ) ?>

                        </td>


                        <!-- =================================================
                             DESDE
                             ================================================= -->

                        <td class="font-monospace">

                            <?= h($desde) ?>

                        </td>


                        <!-- =================================================
                             HASTA
                             ================================================= -->

                        <td class="font-monospace">

                            <?= h($hasta) ?>

                        </td>


                        <!-- =================================================
                             UTILIZADOS
                             ================================================= -->

                        <td>

                            <span class="badge bg-success">

                                <?= h($utilizados) ?>

                            </span>

                        </td>


                        <!-- =================================================
                             FALTANTES
                             ================================================= -->

                        <td>

                            <?php if ($faltantes > 0): ?>

                                <span class="badge bg-danger">

                                    <?= h($faltantes) ?>

                                </span>

                            <?php else: ?>

                                <span class="badge bg-success">

                                    0

                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- =================================================
                             ESTADO
                             ================================================= -->

                        <td>

                            <?php if (
                                $estado === 'FINALIZADO'
                                || $estado === 'CERRADO'
                            ): ?>

                                <span class="badge bg-secondary">

                                    Finalizado

                                </span>

                            <?php elseif ($faltantes > 0): ?>

                                <span
                                    class="badge bg-warning text-dark"
                                >

                                    Pendiente

                                </span>

                            <?php else: ?>

                                <span class="badge bg-success">

                                    Completo

                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- =================================================
                             ACCIONES
                             ================================================= -->

                        <?php if (!$esViewer): ?>

                            <td class="text-end pe-4">

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-primary btnEditarTalonario"
                                    data-id="<?= h($id) ?>"
                                    data-nombre="<?= h($talonario['nombre'] ?? '') ?>"
                                    data-desde="<?= h($desde) ?>"
                                    data-hasta="<?= h($hasta) ?>"
                                    title="Editar"
                                >

                                    <i
                                        class="fa-solid fa-pen"
                                    ></i>

                                </button>

                                <form
                                    method="POST"
                                    action="/informes-tng/talonario/<?= h($id) ?>/eliminar"
                                    class="d-inline"
                                    onsubmit="return confirm('¿Eliminar este talonario? Solo podrá eliminarse si no contiene informes utilizados.');"
                                >
                                    <input
                                        type="hidden"
                                        name="csrf"
                                        value="<?= h($csrfToken) ?>"
                                    >
                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h($csrfToken) ?>"
                                    >
                                    <button
                                        type="submit"
                                        class="btn btn-sm btn-outline-danger"
                                        title="Eliminar"
                                    >
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>

                            </td>

                        <?php endif; ?>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php require __DIR__ . '/partials/modal_talonario.php'; ?>
