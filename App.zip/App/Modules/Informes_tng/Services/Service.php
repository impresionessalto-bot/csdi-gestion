<?php

declare(strict_types=1);

namespace App\Modules\Informes_tng\Services;

use App\Modules\Informes_tng\Repositories\Repository;
use App\Services\Audit\AuditService;
use App\Services\ClienteService;
use App\Services\EquipoService;
use App\Services\Export\ExcelService;
use App\Services\Export\PdfService;
use App\Services\IaService;
use App\Services\LocalidadService;
use PDOException;
use RuntimeException;
use Throwable;

/**
 * ============================================================================
 * CSDI PRO
 * INFORMES TNG - SERVICE
 * ============================================================================
 *
 * Responsabilidad:
 *
 * - Reglas de negocio.
 * - Validaciones.
 * - Normalización.
 * - Coordinación de servicios.
 * - Coordinación con Repository.
 * - Gestión de archivos PDF recibidos.
 * - Auditoría.
 * - IA.
 * - Preparación de información para dashboard.
 * - Coordinación de exportaciones.
 *
 * NO contiene:
 *
 * - SQL.
 * - PDO.
 * - HTML.
 * - sesiones.
 * - CSRF.
 *
 * Arquitectura:
 *
 * Controller
 *      ↓
 * Informes_tng\Service
 *      ├── Repository
 *      ├── LocalidadService
 *      ├── ClienteService
 *      ├── EquipoService
 *      ├── IaService
 *      ├── AuditService
 *      ├── PdfService
 *      └── ExcelService
 *
 * ============================================================================
 */
final class Service
{
    public function __construct(
        private readonly Repository $repository,
        private readonly LocalidadService $localidadService,
        private readonly ClienteService $clienteService,
        private readonly EquipoService $equipoService,
        private readonly IaService $iaService,
        private readonly AuditService $audit,
        private readonly PdfService $pdfService,
        private readonly ExcelService $excelService,
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    /**
     * Datos principales del módulo.
     *
     * @return array<string,mixed>
     */
    public function index(): array
    {
        $talonarios = $this->talonarios();

        return [
            'localidades'         => $this->localidades(),
            'informesDisponibles' => $this->informesDisponibles(),
            'ultimos'             => $this->ultimos(),
            'talonarios'          => $talonarios,
            'talonariosPendientes'=> $this->talonariosPendientes($talonarios),
            'stats'               => $this->estadisticas(),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS
    |--------------------------------------------------------------------------
    */

    /**
     * Estadísticas generales del módulo.
     *
     * Clientes y equipos se resuelven mediante servicios globales.
     * Los informes y pendientes salen del Repository.
     */
    public function estadisticas(): array
    {
        try {
            $clientes = $this->clienteService->todos();

            if (!is_array($clientes)) {
                $clientes = [];
            }
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service estadisticas clientes] '
                . $e->getMessage()
            );

            $clientes = [];
        }

        try {
            $equipos = $this->equipoService->todos('TNG');

            if (!is_array($equipos)) {
                $equipos = [];
            }
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service estadisticas equipos] '
                . $e->getMessage()
            );

            $equipos = [];
        }

        return [
            'clientes'  => count($clientes),
            'equipos'   => count($equipos),
            'informes'  => $this->repository->totalInformes(),
            'pendientes'=> $this->repository->pendientes(),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | LOCALIDADES
    |--------------------------------------------------------------------------
    */

    /**
     * Combo general de localidades.
     *
     * @return array<int,array<string,mixed>>
     */
    public function localidades(): array
    {
        try {
            $resultado = $this->localidadService->combo();

            return is_array($resultado)
                ? $resultado
                : [];
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service localidades] '
                . $e->getMessage()
            );

            return [];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES
    |--------------------------------------------------------------------------
    */

    /**
     * Clientes pertenecientes a una localidad.
     *
     * @return array<int,array<string,mixed>>
     */
    public function clientes(int $localidadId): array
    {
        if ($localidadId <= 0) {
            return [];
        }

        try {
            $resultado =
                $this->clienteService->porLocalidad(
                    $localidadId
                );

            return is_array($resultado)
                ? $resultado
                : [];
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service clientes] '
                . $e->getMessage()
            );

            return [];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS
    |--------------------------------------------------------------------------
    */

    /**
     * Equipos TNG de un cliente.
     *
     * @return array<int,array<string,mixed>>
     */
    public function equipos(int $clienteId): array
    {
        if ($clienteId <= 0) {
            return [];
        }

        try {
            $resultado =
                $this->equipoService->tng(
                    $clienteId
                );

            return is_array($resultado)
                ? $resultado
                : [];
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service equipos] '
                . $e->getMessage()
            );

            return [];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | INFORMES DISPONIBLES
    |--------------------------------------------------------------------------
    */

    /**
     * Devuelve números libres de los talonarios TNG.
     */
    public function informesDisponibles(
        int $limite = 500
    ): array {
        $limite = max(
            1,
            min($limite, 5000)
        );

        return $this->repository->informesDisponibles(
            $limite
        );
    }

    /*
    |--------------------------------------------------------------------------
    | HISTORIAL
    |--------------------------------------------------------------------------
    */

    /**
     * Últimos informes registrados.
     */
    public function ultimos(
        int $limite = 100
    ): array {
        $limite = max(
            1,
            min($limite, 1000)
        );

        return $this->repository->ultimos(
            $limite
        );
    }

    /**
     * Alias semántico para historial.
     */
    public function historial(
        int $limite = 100
    ): array {
        return $this->ultimos($limite);
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene un informe por ID.
     */
    public function buscar(int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->buscar($id);
    }

    /**
     * Busca por número de informe.
     */
    public function buscarPorNumero(
        string $numero
    ): ?array {
        $numero = trim($numero);

        if ($numero === '') {
            return null;
        }

        return $this->repository->buscarPorNumero(
            $numero
        );
    }

    /**
     * Verifica si un número ya existe.
     */
    public function existeNumero(
        string $numero,
        ?int $excluirId = null
    ): bool {
        return $this->repository->existeNumero(
            $numero,
            $excluirId
        );
    }

    /**
     * Búsqueda general.
     */
    public function buscarTexto(
        string $texto,
        int $limite = 100
    ): array {
        $texto = trim($texto);

        if ($texto === '') {
            return [];
        }

        return $this->repository->buscarTexto(
            $texto,
            $limite
        );
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS RELACIONALES
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene el nombre del cliente mediante ClienteService.
     */
    public function nombreCliente(int $id): string
    {
        if ($id <= 0) {
            return '';
        }

        try {
            $cliente =
                $this->clienteService->obtener($id);

            if (!is_array($cliente)) {
                return '';
            }

            return trim(
                (string)(
                    $cliente['nombre']
                    ?? $cliente['razon_social']
                    ?? $cliente['razonSocial']
                    ?? ''
                )
            );
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service nombreCliente] '
                . $e->getMessage()
            );

            return '';
        }
    }

    /**
     * Obtiene el nombre de localidad.
     */
    public function nombreLocalidad(int $id): string
    {
        if ($id <= 0) {
            return '';
        }

        try {
            $localidades =
                $this->localidadService->combo();

            if (!is_array($localidades)) {
                return '';
            }

            foreach ($localidades as $localidad) {
                if (!is_array($localidad)) {
                    continue;
                }

                if (
                    (int)($localidad['id'] ?? 0)
                    !== $id
                ) {
                    continue;
                }

                return trim(
                    (string)(
                        $localidad['nombre']
                        ?? $localidad['localidad']
                        ?? ''
                    )
                );
            }
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service nombreLocalidad] '
                . $e->getMessage()
            );
        }

        return '';
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR INFORME
    |--------------------------------------------------------------------------
    */

    /**
     * Guarda un informe TNG.
     *
     * @param array<string,mixed> $data
     * @param array<string,mixed> $files
     */
    public function guardar(
        array $data,
        array $files
    ): int {
        /*
        |--------------------------------------------------------------------------
        | 1. DATOS BÁSICOS
        |--------------------------------------------------------------------------
        */

        $clienteId = (int)(
            $data['cliente_id'] ?? 0
        );

        $equipoId = (int)(
            $data['equipo_id'] ?? 0
        );

        $localidadId = (int)(
            $data['localidad_id'] ?? 0
        );

        $nroInforme = trim(
            (string)(
                $data['nro_informe']
                ?? ''
            )
        );

        if ($nroInforme === '') {
            throw new RuntimeException(
                'Debe indicar el número de informe.'
            );
        }

        if ($clienteId <= 0) {
            throw new RuntimeException(
                'Debe seleccionar un cliente.'
            );
        }

        if ($equipoId <= 0) {
            throw new RuntimeException(
                'Debe seleccionar un equipo.'
            );
        }

        if ($localidadId <= 0) {
            throw new RuntimeException(
                'Debe seleccionar una localidad.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 2. NÚMERO DUPLICADO
        |--------------------------------------------------------------------------
        */

        if (
            $this->repository->existeNumero(
                $nroInforme
            )
        ) {
            throw new RuntimeException(
                "El informe Nº {$nroInforme} ya fue registrado."
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 3. CLIENTE
        |--------------------------------------------------------------------------
        */

        $cliente = $this->obtenerCliente(
            $clienteId
        );

        if ($cliente === null) {
            throw new RuntimeException(
                'El cliente seleccionado no existe.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 4. LOCALIDAD
        |--------------------------------------------------------------------------
        */

        $localidad = $this->nombreLocalidad(
            $localidadId
        );

        if ($localidad === '') {
            throw new RuntimeException(
                'La localidad seleccionada no existe.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 5. EQUIPO
        |--------------------------------------------------------------------------
        */

        $equipo =
            $this->obtenerEquipo(
                $equipoId
            );

        if ($equipo === null) {
            throw new RuntimeException(
                'El equipo seleccionado no existe.'
            );
        }

        $propiedad = strtoupper(
            trim(
                (string)(
                    $equipo['propiedad']
                    ?? ''
                )
            )
        );

        if ($propiedad !== 'TNG') {
            throw new RuntimeException(
                'El equipo seleccionado no pertenece a TNG.'
            );
        }

        $equipoClienteId = (int)(
            $equipo['cliente_id']
            ?? 0
        );

        if (
            $equipoClienteId > 0
            && $equipoClienteId !== $clienteId
        ) {
            throw new RuntimeException(
                'El equipo seleccionado no pertenece al cliente indicado.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 6. PDF
        |--------------------------------------------------------------------------
        */

        $archivo = $files['informe'] ?? null;

        if (
            !is_array($archivo)
        ) {
            throw new RuntimeException(
                'Debe seleccionar el PDF del informe.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 7. NORMALIZACIÓN
        |--------------------------------------------------------------------------
        */

        $data['nro_informe'] =
            $nroInforme;

        $data['cliente_id'] =
            $clienteId;

        $data['equipo_id'] =
            $equipoId;

        $data['localidad_id'] =
            $localidadId;

        $data['cliente'] =
            $this->nombreClienteDesdeDatos(
                $cliente,
                $clienteId
            );

        $data['localidad'] =
            $localidad;

        $data['fecha'] =
            $this->normalizarFecha(
                $data['fecha'] ?? null
            );

        $this->normalizarFacturacion(
            $data
        );

        $this->normalizarEstadoFacturacion(
            $data
        );

        $data['estado'] = strtoupper(
            trim(
                (string)(
                    $data['estado']
                    ?? 'PENDIENTE'
                )
            )
        );

        $this->validarEstado(
            $data['estado']
        );

        /*
        |--------------------------------------------------------------------------
        | 8. GUARDAR PDF
        |--------------------------------------------------------------------------
        */

        $archivoPath =
            $this->guardarPdf(
                $archivo,
                $nroInforme
            );

        $data['archivo_path'] =
            $archivoPath;

        /*
        |--------------------------------------------------------------------------
        | 9. PERSISTENCIA
        |--------------------------------------------------------------------------
        */

        try {
            $id =
                $this->repository->guardarInforme(
                    $data
                );
        } catch (PDOException $e) {
            $this->borrarPdf(
                $archivoPath
            );

            if (
                $this->esDuplicado(
                    $e
                )
            ) {
                throw new RuntimeException(
                    "El informe Nº {$nroInforme} ya fue registrado."
                );
            }

            throw $e;
        } catch (Throwable $e) {
            $this->borrarPdf(
                $archivoPath
            );

            throw $e;
        }

        if ($id <= 0) {
            $this->borrarPdf(
                $archivoPath
            );

            throw new RuntimeException(
                'No se pudo registrar el informe.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 10. AUDITORÍA
        |--------------------------------------------------------------------------
        */

        $this->auditarCreacion(
            $id,
            $data
        );

        return $id;
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR INFORME
    |--------------------------------------------------------------------------
    */

    /**
     * @param array<string,mixed> $data
     * @param array<string,mixed> $files
     */
    public function actualizar(
        int $id,
        array $data,
        array $files = []
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'Informe inválido.'
            );
        }

        $actual =
            $this->buscar($id);

        if ($actual === null) {
            throw new RuntimeException(
                'Informe inexistente.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | NO permitir editar un informe anulado sin una operación específica.
        |--------------------------------------------------------------------------
        */

        $estadoActual = strtoupper(
            trim(
                (string)(
                    $actual['estado']
                    ?? ''
                )
            )
        );

        if ($estadoActual === 'ANULADO') {
            throw new RuntimeException(
                'No se puede modificar un informe anulado.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | NÚMERO
        |--------------------------------------------------------------------------
        */

        if (
            array_key_exists(
                'nro_informe',
                $data
            )
        ) {
            $numero =
                trim(
                    (string)$data['nro_informe']
                );

            if ($numero === '') {
                throw new RuntimeException(
                    'El número de informe es obligatorio.'
                );
            }

            if (
                $this->repository->existeNumero(
                    $numero,
                    $id
                )
            ) {
                throw new RuntimeException(
                    "El informe Nº {$numero} ya fue registrado."
                );
            }

            $data['nro_informe'] =
                $numero;
        }

        /*
        |--------------------------------------------------------------------------
        | CLIENTE
        |--------------------------------------------------------------------------
        */

        $clienteId = (int)(
            $data['cliente_id']
            ?? $actual['cliente_id']
            ?? 0
        );

        if ($clienteId <= 0) {
            throw new RuntimeException(
                'El cliente del informe es inválido.'
            );
        }

        $cliente =
            $this->obtenerCliente(
                $clienteId
            );

        if ($cliente === null) {
            throw new RuntimeException(
                'El cliente seleccionado no existe.'
            );
        }

        $data['cliente_id'] =
            $clienteId;

        $data['cliente'] =
            $this->nombreClienteDesdeDatos(
                $cliente,
                $clienteId
            );

        /*
        |--------------------------------------------------------------------------
        | LOCALIDAD
        |--------------------------------------------------------------------------
        */

        $localidadId = (int)(
            $data['localidad_id']
            ?? $actual['localidad_id']
            ?? 0
        );

        if ($localidadId <= 0) {
            throw new RuntimeException(
                'La localidad del informe es inválida.'
            );
        }

        $localidad =
            $this->nombreLocalidad(
                $localidadId
            );

        if ($localidad === '') {
            throw new RuntimeException(
                'La localidad seleccionada no existe.'
            );
        }

        $data['localidad_id'] =
            $localidadId;

        $data['localidad'] =
            $localidad;

        /*
        |--------------------------------------------------------------------------
        | EQUIPO
        |--------------------------------------------------------------------------
        */

        $equipoId = (int)(
            $data['equipo_id']
            ?? $actual['equipo_id']
            ?? 0
        );

        if ($equipoId <= 0) {
            throw new RuntimeException(
                'El equipo del informe es inválido.'
            );
        }

        $equipo =
            $this->obtenerEquipo(
                $equipoId
            );

        if ($equipo === null) {
            throw new RuntimeException(
                'El equipo seleccionado no existe.'
            );
        }

        if (
            strtoupper(
                trim(
                    (string)(
                        $equipo['propiedad']
                        ?? ''
                    )
                )
            ) !== 'TNG'
        ) {
            throw new RuntimeException(
                'El equipo seleccionado no pertenece a TNG.'
            );
        }

        $equipoClienteId = (int)(
            $equipo['cliente_id']
            ?? 0
        );

        if (
            $equipoClienteId > 0
            && $equipoClienteId !== $clienteId
        ) {
            throw new RuntimeException(
                'El equipo seleccionado no pertenece al cliente indicado.'
            );
        }

        $data['equipo_id'] =
            $equipoId;

        /*
        |--------------------------------------------------------------------------
        | FECHA
        |--------------------------------------------------------------------------
        */

        if (
            array_key_exists(
                'fecha',
                $data
            )
        ) {
            $data['fecha'] =
                $this->normalizarFecha(
                    $data['fecha']
                );
        } else {
            $data['fecha'] =
                $this->normalizarFecha(
                    $actual['fecha']
                    ?? null
                );
        }

        /*
        |--------------------------------------------------------------------------
        | FACTURACIÓN
        |--------------------------------------------------------------------------
        */

        $this->normalizarFacturacion(
            $data,
            $actual
        );

        $this->normalizarEstadoFacturacion(
            $data,
            $actual
        );

        /*
        |--------------------------------------------------------------------------
        | ESTADO
        |--------------------------------------------------------------------------
        */

        if (
            array_key_exists(
                'estado',
                $data
            )
        ) {
            $data['estado'] =
                strtoupper(
                    trim(
                        (string)$data['estado']
                    )
                );

            $this->validarEstado(
                $data['estado']
            );
        }

        /*
        |--------------------------------------------------------------------------
        | NUEVO PDF
        |--------------------------------------------------------------------------
        */

        $nuevoArchivo = null;

        $archivo =
            $files['informe'] ?? null;

        if (
            is_array($archivo)
            && (
                ($archivo['error'] ?? 1)
                === UPLOAD_ERR_OK
            )
        ) {
            $numeroArchivo =
                (string)(
                    $data['nro_informe']
                    ?? $actual['nro_informe']
                    ?? ''
                );

            $nuevoArchivo =
                $this->guardarPdf(
                    $archivo,
                    $numeroArchivo
                );

            $data['archivo_path'] =
                $nuevoArchivo;
        }

        /*
        |--------------------------------------------------------------------------
        | PERSISTENCIA
        |--------------------------------------------------------------------------
        */

        try {
            $ok =
                $this->repository->actualizar(
                    $id,
                    $data
                );
        } catch (PDOException $e) {
            if ($nuevoArchivo !== null) {
                $this->borrarPdf(
                    $nuevoArchivo
                );
            }

            if (
                $this->esDuplicado(
                    $e
                )
            ) {
                throw new RuntimeException(
                    'El número de informe ya se encuentra registrado.'
                );
            }

            throw $e;
        } catch (Throwable $e) {
            if ($nuevoArchivo !== null) {
                $this->borrarPdf(
                    $nuevoArchivo
                );
            }

            throw $e;
        }

        if (!$ok) {
            if ($nuevoArchivo !== null) {
                $this->borrarPdf(
                    $nuevoArchivo
                );
            }

            return false;
        }

        /*
        |--------------------------------------------------------------------------
        | ELIMINAR PDF ANTERIOR
        |--------------------------------------------------------------------------
        */

        if (
            $nuevoArchivo !== null
            && !empty(
                $actual['archivo_path']
            )
        ) {
            $this->borrarPdf(
                (string)$actual['archivo_path']
            );
        }

        /*
        |--------------------------------------------------------------------------
        | AUDITORÍA
        |--------------------------------------------------------------------------
        */

        $this->auditarActualizacion(
            $id,
            $actual,
            $data
        );

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR INFORME
    |--------------------------------------------------------------------------
    */

    public function eliminar(
        int $id
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'Informe inválido.'
            );
        }

        $informe =
            $this->buscar($id);

        if ($informe === null) {
            throw new RuntimeException(
                'Informe inexistente.'
            );
        }

        $estado = strtoupper(
            trim(
                (string)(
                    $informe['estado']
                    ?? ''
                )
            )
        );

        if ($estado === 'ANULADO') {
            throw new RuntimeException(
                'El informe está anulado. No corresponde eliminarlo.'
            );
        }

        $ok =
            $this->repository->eliminar(
                $id
            );

        if (!$ok) {
            throw new RuntimeException(
                'No se pudo eliminar el informe.'
            );
        }

        if (
            !empty(
                $informe['archivo_path']
            )
        ) {
            $this->borrarPdf(
                (string)$informe['archivo_path']
            );
        }

        $this->auditarEliminacion(
            $id,
            $informe
        );

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | ANULAR
    |--------------------------------------------------------------------------
    */

    /**
     * Anula un informe.
     */
    public function anular(
        int $id,
        ?int $usuarioId,
        string $motivo
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'Informe inválido.'
            );
        }

        $motivo = trim($motivo);

        if ($motivo === '') {
            throw new RuntimeException(
                'Debe indicar el motivo de la anulación.'
            );
        }

        $informe =
            $this->buscar($id);

        if ($informe === null) {
            throw new RuntimeException(
                'Informe inexistente.'
            );
        }

        $estado =
            strtoupper(
                trim(
                    (string)(
                        $informe['estado']
                        ?? ''
                    )
                )
            );

        if ($estado === 'ANULADO') {
            throw new RuntimeException(
                'El informe ya se encuentra anulado.'
            );
        }

        $ok =
            $this->repository->anular(
                $id,
                $usuarioId,
                $motivo
            );

        if (!$ok) {
            throw new RuntimeException(
                'No se pudo anular el informe.'
            );
        }

        $despues = $informe;

        $despues['estado'] =
            'ANULADO';

        $despues['anulado_por'] =
            $usuarioId;

        $despues['motivo_anulacion'] =
            $motivo;

        $despues['fecha_anulacion'] =
            date('Y-m-d H:i:s');

        $this->auditarActualizacion(
            $id,
            $informe,
            $despues
        );

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | REACTIVAR
    |--------------------------------------------------------------------------
    */

    /**
     * Reactiva un informe anulado.
     */
    public function reactivar(
        int $id
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'Informe inválido.'
            );
        }

        $informe =
            $this->buscar($id);

        if ($informe === null) {
            throw new RuntimeException(
                'Informe inexistente.'
            );
        }

        $estado =
            strtoupper(
                trim(
                    (string)(
                        $informe['estado']
                        ?? ''
                    )
                )
            );

        if ($estado !== 'ANULADO') {
            throw new RuntimeException(
                'El informe no está anulado.'
            );
        }

        $ok =
            $this->repository->reactivar(
                $id
            );

        if (!$ok) {
            throw new RuntimeException(
                'No se pudo reactivar el informe.'
            );
        }

        $despues = $informe;

        $despues['estado'] =
            'PENDIENTE';

        $despues['anulado_por'] =
            null;

        $despues['fecha_anulacion'] =
            null;

        $despues['motivo_anulacion'] =
            null;

        $this->auditarActualizacion(
            $id,
            $informe,
            $despues
        );

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | IA
    |--------------------------------------------------------------------------
    */

    /**
     * Análisis IA de informes TNG.
     */
    public function analisisIA(
        array $informes
    ): mixed {
        return $this->iaService->analizarInformesTng(
            $informes
        );
    }

    /*
    |--------------------------------------------------------------------------
    | TALONARIOS
    |--------------------------------------------------------------------------
    */

    /**
     * Lista talonarios TNG con información de utilización y faltantes.
     *
     * Regla de negocio:
     *
     * - NO INICIADO: no existe ningún informe dentro del rango.
     * - COMPLETO: existe utilización y no hay huecos entre el primer y
     *   último número utilizado.
     * - PENDIENTE: existe utilización y hay uno o más huecos entre el primer
     *   y último número utilizado.
     *
     * Los números posteriores al último utilizado NO se consideran faltantes.
     * Esto permite que un talonario físico quede abierto con números libres
     * al final sin generar falsas alertas.
     */
    public function talonarios(): array
    {
        try {
            $talonarios = $this->repository->talonarios();

            if ($talonarios === []) {
                return [];
            }

            foreach ($talonarios as &$talonario) {
                $desde = (int)($talonario['num_desde'] ?? 0);
                $hasta = (int)($talonario['num_hasta'] ?? 0);

                $total = (
                    $desde > 0
                    && $hasta >= $desde
                )
                    ? ($hasta - $desde) + 1
                    : 0;

                $faltantes = [];
                $usados = [];

                if ($total > 0) {
                    $usados = $this->numerosUsadosEnRango(
                        $desde,
                        $hasta
                    );

                    if ($usados !== []) {
                        $min = min($usados);
                        $max = max($usados);

                        $ocupados = array_fill_keys(
                            array_map('strval', $usados),
                            true
                        );

                        for ($i = $min; $i <= $max; $i++) {
                            if (!isset($ocupados[(string)$i])) {
                                $faltantes[] = $i;
                            }
                        }
                    }
                }

                $cargados = count($usados);

                // Normalizamos los nombres que esperan las vistas.
                // La tabla real usa num_desde / num_hasta, mientras que
                // las vistas históricas del módulo esperan desde / hasta.
                $talonario['desde'] = $desde;
                $talonario['hasta'] = $hasta;
                $talonario['numero_desde'] = $desde;
                $talonario['numero_hasta'] = $hasta;
                $talonario['nro_desde'] = $desde;
                $talonario['nro_hasta'] = $hasta;
                $talonario['inicio'] = $desde;
                $talonario['fin'] = $hasta;

                $talonario['total'] = $total;
                $talonario['cargados'] = $cargados;
                $talonario['informes_cargados'] = $cargados;
                $talonario['utilizados'] = $cargados;
                $talonario['faltantes'] = count($faltantes);
                $talonario['cantidad_faltantes'] = count($faltantes);
                $talonario['informes_faltantes'] = $faltantes;
                $talonario['numeros_faltantes'] = $faltantes;
                $talonario['primer_utilizado'] = $usados !== [] ? min($usados) : null;
                $talonario['ultimo_utilizado'] = $usados !== [] ? max($usados) : null;

                if ($usados === []) {
                    $talonario['estado'] = 'NO INICIADO';
                } elseif ($faltantes !== []) {
                    $talonario['estado'] = 'PENDIENTE';
                } else {
                    $talonario['estado'] = 'COMPLETO';
                }
            }

            unset($talonario);

            return $talonarios;
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service talonarios] '
                . $e->getMessage()
            );

            return [];
        }
    }

    /**
     * Devuelve solamente los talonarios que requieren atención.
     *
     * @param array<int,array<string,mixed>> $talonarios
     * @return array<int,array<string,mixed>>
     */
    public function talonariosPendientes(
        array $talonarios = []
    ): array {
        if ($talonarios === []) {
            $talonarios = $this->talonarios();
        }

        $pendientes = [];

        foreach ($talonarios as $talonario) {
            if (!is_array($talonario)) {
                continue;
            }

            $estado = strtoupper(
                trim((string)($talonario['estado'] ?? ''))
            );

            if ($estado !== 'PENDIENTE') {
                continue;
            }

            $pendientes[] = $talonario;
        }

        return $pendientes;
    }

    /**
     * Devuelve los números utilizados dentro de un rango como enteros.
     *
     * El Repository actual devuelve números simples. Por compatibilidad,
     * también aceptamos el formato antiguo donde cada elemento podía ser
     * un array con nro_informe.
     *
     * @return array<int,int>
     */
    private function numerosUsadosEnRango(
        int $desde,
        int $hasta
    ): array {
        if (
            $desde <= 0
            || $hasta <= 0
            || $desde > $hasta
        ) {
            return [];
        }

        $usados = $this->repository->informesUsadosEnRango(
            $desde,
            $hasta
        );

        $numeros = [];

        foreach ($usados as $row) {
            if (is_array($row)) {
                $valor = $row['nro_informe']
                    ?? $row['numero']
                    ?? null;
            } else {
                $valor = $row;
            }

            if ($valor === null) {
                continue;
            }

            $numero = (int)trim((string)$valor);

            if (
                $numero >= $desde
                && $numero <= $hasta
            ) {
                $numeros[$numero] = $numero;
            }
        }

        $numeros = array_values($numeros);
        sort($numeros, SORT_NUMERIC);

        return $numeros;
    }

    /**
     * Calcula números faltantes de un talonario.
     *
     * Solamente se consideran faltantes los huecos entre el primer y último
     * número efectivamente utilizado.
     */
    public function faltantesTalonario(
        int $desde,
        int $hasta
    ): array {
        if (
            $desde <= 0
            || $hasta <= 0
            || $desde > $hasta
        ) {
            return [];
        }

        if (($hasta - $desde) > 100000) {
            throw new RuntimeException(
                'El rango del talonario es demasiado grande.'
            );
        }

        $usados = $this->numerosUsadosEnRango(
            $desde,
            $hasta
        );

        if ($usados === []) {
            return [];
        }

        $ocupados = array_fill_keys(
            array_map('strval', $usados),
            true
        );

        $primero = min($usados);
        $ultimo = max($usados);
        $faltantes = [];

        for ($i = $primero; $i <= $ultimo; $i++) {
            if (!isset($ocupados[(string)$i])) {
                $faltantes[] = $i;
            }
        }

        return $faltantes;
    }

    /**
     * Obtiene un talonario.
     */
    public function talonario(
        int $id
    ): ?array {
        if ($id <= 0) {
            return null;
        }

        return $this->repository->talonario(
            $id
        );
    }

    /*
    |--------------------------------------------------------------------------
    | FALTANTES
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | CREAR TALONARIO
    |--------------------------------------------------------------------------
    */

    public function crearTalonario(
        array $data
    ): int {
        $nombre = trim(
            (string)(
                $data['nombre']
                ?? ''
            )
        );

        $desde = (int)(
            $data['desde']
            ?? $data['num_desde']
            ?? 0
        );

        $hasta = (int)(
            $data['hasta']
            ?? $data['num_hasta']
            ?? 0
        );

        if ($nombre === '') {
            throw new RuntimeException(
                'El nombre del talonario es obligatorio.'
            );
        }

        if (
            $desde <= 0
            || $hasta <= 0
            || $desde > $hasta
        ) {
            throw new RuntimeException(
                'El rango del talonario es inválido.'
            );
        }

        if (
            ($hasta - $desde)
            > 100000
        ) {
            throw new RuntimeException(
                'El rango del talonario es demasiado grande.'
            );
        }

        if (
            $this->repository->existeTalonarioNombre(
                $nombre
            )
        ) {
            throw new RuntimeException(
                "Ya existe el talonario '{$nombre}'."
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Evitar solapamiento de rangos
        |--------------------------------------------------------------------------
        */

        $this->validarSolapamientoTalonario(
            $desde,
            $hasta
        );

        $datos = [
            'nombre' => $nombre,
            'desde'  => $desde,
            'hasta'  => $hasta,
        ];

        $id =
            $this->repository->crearTalonario(
                $datos
            );

        if ($id <= 0) {
            throw new RuntimeException(
                'No se pudo crear el talonario.'
            );
        }

        $this->auditarCreacion(
            $id,
            $datos,
            'talonarios'
        );

        return $id;
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR TALONARIO
    |--------------------------------------------------------------------------
    */

    public function actualizarTalonario(
        int $id,
        array $data
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'Talonario inválido.'
            );
        }

        $actual =
            $this->repository->talonario(
                $id
            );

        if ($actual === null) {
            throw new RuntimeException(
                'Talonario inexistente.'
            );
        }

        $nombre = trim(
            (string)(
                $data['nombre']
                ?? ''
            )
        );

        $desde = (int)(
            $data['desde']
            ?? $data['num_desde']
            ?? 0
        );

        $hasta = (int)(
            $data['hasta']
            ?? $data['num_hasta']
            ?? 0
        );

        if ($nombre === '') {
            throw new RuntimeException(
                'El nombre del talonario es obligatorio.'
            );
        }

        if (
            $desde <= 0
            || $hasta <= 0
            || $desde > $hasta
        ) {
            throw new RuntimeException(
                'El rango del talonario es inválido.'
            );
        }

        if (
            ($hasta - $desde)
            > 100000
        ) {
            throw new RuntimeException(
                'El rango del talonario es demasiado grande.'
            );
        }

        if (
            $this->repository->existeTalonarioNombre(
                $nombre,
                $id
            )
        ) {
            throw new RuntimeException(
                "Ya existe el talonario '{$nombre}'."
            );
        }

        /*
        |--------------------------------------------------------------------------
        | No permitir cambiar un rango de forma que genere conflictos
        |--------------------------------------------------------------------------
        */

        $this->validarSolapamientoTalonario(
            $desde,
            $hasta,
            $id
        );

        /*
        |--------------------------------------------------------------------------
        | Si ya hay informes dentro del rango anterior,
        | el nuevo rango debe seguir cubriéndolos.
        |--------------------------------------------------------------------------
        */

        $usados =
            $this->numerosUsadosEnRango(
                (int)(
                    $actual['num_desde']
                    ?? 0
                ),
                (int)(
                    $actual['num_hasta']
                    ?? 0
                )
            );

        /*
         * El helper anterior consulta únicamente el rango viejo, por lo que
         * aquí verificamos que cada número realmente utilizado siga dentro
         * del nuevo rango.
         */
        foreach ($usados as $numero) {
            if (
                $numero > 0
                && (
                    $numero < $desde
                    || $numero > $hasta
                )
            ) {
                throw new RuntimeException(
                    'No se puede modificar el rango porque dejaría informes utilizados fuera del talonario.'
                );
            }
        }

        $datos = [
            'nombre' => $nombre,
            'desde'  => $desde,
            'hasta'  => $hasta,
        ];

        $ok =
            $this->repository->actualizarTalonario(
                $id,
                $datos
            );

        if (!$ok) {
            return false;
        }

        $this->auditarActualizacion(
            $id,
            $actual,
            $datos,
            'talonarios'
        );

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR TALONARIO
    |--------------------------------------------------------------------------
    */

    public function eliminarTalonario(
        int $id
    ): bool {
        if ($id <= 0) {
            throw new RuntimeException(
                'Talonario inválido.'
            );
        }

        $talonario =
            $this->repository->talonario(
                $id
            );

        if ($talonario === null) {
            throw new RuntimeException(
                'Talonario inexistente.'
            );
        }

        $usados =
            $this->repository->informesUsadosEnRango(
                (int)(
                    $talonario['num_desde']
                    ?? 0
                ),
                (int)(
                    $talonario['num_hasta']
                    ?? 0
                )
            );

        if (!empty($usados)) {
            throw new RuntimeException(
                'No se puede eliminar un talonario que ya contiene informes utilizados.'
            );
        }

        $ok =
            $this->repository->eliminarTalonario(
                $id
            );

        if (!$ok) {
            throw new RuntimeException(
                'No se pudo eliminar el talonario.'
            );
        }

        $this->auditarEliminacion(
            $id,
            $talonario,
            'talonarios'
        );

        return true;
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADÍSTICAS AVANZADAS
    |--------------------------------------------------------------------------
    */

    public function estadisticasEstados(): array
    {
        return $this->repository
            ->estadisticasEstados();
    }

    public function estadisticasMensuales(
        int $anio
    ): array {
        return $this->repository
            ->estadisticasMensuales(
                $anio
            );
    }

    /**
     * Último informe.
     */
    public function ultimo(): ?array
    {
        return $this->repository->ultimo();
    }

    /**
     * Informes de un cliente.
     */
    public function porCliente(
        int $clienteId
    ): array {
        return $this->repository
            ->porCliente(
                $clienteId
            );
    }

    /**
     * Informes de un equipo.
     */
    public function porEquipo(
        int $equipoId
    ): array {
        return $this->repository
            ->porEquipo(
                $equipoId
            );
    }

    /**
     * Informes de una localidad.
     */
    public function porLocalidad(
        int $localidadId
    ): array {
        return $this->repository
            ->porLocalidad(
                $localidadId
            );
    }

    /**
     * Informes por estado.
     */
    public function porEstado(
        string $estado
    ): array {
        $estado =
            strtoupper(
                trim($estado)
            );

        if ($estado === '') {
            return [];
        }

        $this->validarEstado(
            $estado
        );

        return $this->repository
            ->porEstado(
                $estado
            );
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTACIONES
    |--------------------------------------------------------------------------
    */

    /**
     * Datos preparados para exportación.
     */
    public function datosExportacion(): array
    {
        return $this->repository->ultimos(
            1000
        );
    }

    /**
     * Servicio transversal PDF.
     */
    public function pdfService(): PdfService
    {
        return $this->pdfService;
    }

    /**
     * Servicio transversal Excel.
     */
    public function excelService(): ExcelService
    {
        return $this->excelService;
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS PRIVADOS - CLIENTE
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene un cliente de forma defensiva.
     */
    private function obtenerCliente(
        int $clienteId
    ): ?array {
        if ($clienteId <= 0) {
            return null;
        }

        try {
            $cliente =
                $this->clienteService->obtener(
                    $clienteId
                );

            return is_array($cliente)
                ? $cliente
                : null;
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service obtenerCliente] '
                . $e->getMessage()
            );

            return null;
        }
    }

    /**
     * Obtiene el nombre del cliente contemplando
     * distintas estructuras posibles del servicio global.
     */
    private function nombreClienteDesdeDatos(
        array $cliente,
        int $clienteId
    ): string {
        $nombre = trim(
            (string)(
                $cliente['nombre']
                ?? $cliente['razon_social']
                ?? $cliente['razonSocial']
                ?? ''
            )
        );

        if ($nombre !== '') {
            return $nombre;
        }

        $nombre = $this->nombreCliente(
            $clienteId
        );

        if ($nombre !== '') {
            return $nombre;
        }

        throw new RuntimeException(
            'El cliente seleccionado no tiene un nombre válido.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | HELPERS PRIVADOS - EQUIPO
    |--------------------------------------------------------------------------
    */

    /**
     * Obtiene un equipo.
     */
    private function obtenerEquipo(
        int $equipoId
    ): ?array {
        if ($equipoId <= 0) {
            return null;
        }

        try {
            $equipo =
                $this->equipoService->find(
                    $equipoId
                );

            return is_array($equipo)
                ? $equipo
                : null;
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Service obtenerEquipo] '
                . $e->getMessage()
            );

            return null;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | FACTURACIÓN
    |--------------------------------------------------------------------------
    */

    /**
     * Normaliza la facturación TNG.
     *
     * Regla TNG:
     *
     * - ARCA
     * - GENERAL
     * - SERVICIO
     *
     * Se mantiene compatibilidad con los tres flags.
     *
     * @param array<string,mixed> $data
     * @param array<string,mixed> $actual
     */
    private function normalizarFacturacion(
        array &$data,
        array $actual = []
    ): void {
        /*
        |--------------------------------------------------------------------------
        | Si se recibe explícitamente facturacion_tng,
        | ese valor tiene prioridad.
        |--------------------------------------------------------------------------
        */

        $tipo = strtoupper(
            trim(
                (string)(
                    $data['facturacion_tng']
                    ?? ''
                )
            )
        );

        /*
        |--------------------------------------------------------------------------
        | En actualización, si no llega facturacion_tng,
        | conservamos la facturación anterior.
        |--------------------------------------------------------------------------
        */

        if (
            $tipo === ''
            && $actual !== []
        ) {
            if (
                !empty(
                    $actual['fact_contador_arca']
                )
            ) {
                $tipo = 'ARCA';
            } elseif (
                !empty(
                    $actual['fact_contador_general']
                )
            ) {
                $tipo = 'GENERAL';
            } elseif (
                !empty(
                    $actual['fact_servicio_tecnico']
                )
            ) {
                $tipo = 'SERVICIO';
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Defaults
        |--------------------------------------------------------------------------
        */

        $arca = 0;
        $general = 0;
        $servicio = 0;

        /*
        |--------------------------------------------------------------------------
        | Tipo principal
        |--------------------------------------------------------------------------
        */

        switch ($tipo) {
            case 'ARCA':
                $arca = 1;
                break;

            case 'GENERAL':
                $general = 1;
                break;

            case 'SERVICIO':
            case 'SERVICIO_TECNICO':
            case 'TECNICO':
                $servicio = 1;
                break;
        }

        /*
        |--------------------------------------------------------------------------
        | Compatibilidad con flags independientes.
        |--------------------------------------------------------------------------
        */

        if (
            array_key_exists(
                'fact_contador_arca',
                $data
            )
            && $data['fact_contador_arca'] !== ''
        ) {
            $arca =
                !empty(
                    $data['fact_contador_arca']
                )
                    ? 1
                    : 0;
        }

        if (
            array_key_exists(
                'fact_contador_general',
                $data
            )
            && $data['fact_contador_general'] !== ''
        ) {
            $general =
                !empty(
                    $data['fact_contador_general']
                )
                    ? 1
                    : 0;
        }

        if (
            array_key_exists(
                'fact_servicio_tecnico',
                $data
            )
            && $data['fact_servicio_tecnico'] !== ''
        ) {
            $servicio =
                !empty(
                    $data['fact_servicio_tecnico']
                )
                    ? 1
                    : 0;
        }

        /*
        |--------------------------------------------------------------------------
        | TNG trabaja con una modalidad de facturación por informe.
        |
        | Si llegaron varios flags activos, prevalece el tipo explícito.
        |--------------------------------------------------------------------------
        */

        if ($tipo !== '') {
            $arca = 0;
            $general = 0;
            $servicio = 0;

            switch ($tipo) {
                case 'ARCA':
                    $arca = 1;
                    break;

                case 'GENERAL':
                    $general = 1;
                    break;

                case 'SERVICIO':
                case 'SERVICIO_TECNICO':
                case 'TECNICO':
                    $servicio = 1;
                    break;
            }
        }

        $data['fact_contador_arca'] =
            $arca;

        $data['fact_contador_general'] =
            $general;

        $data['fact_servicio_tecnico'] =
            $servicio;
    }

    /**
     * Normaliza el estado persistente de facturación.
     *
     * Estados permitidos:
     * - PENDIENTE   : cargado, aún no liberado para facturar.
     * - FACTURABLE  : listo para ingresar a facturación.
     * - FACTURADO   : ya incorporado/facturado.
     * - NO_FACTURAR : excepción explícita.
     *
     * @param array<string,mixed> $data
     * @param array<string,mixed> $actual
     */
    private function normalizarEstadoFacturacion(
        array &$data,
        array $actual = []
    ): void {
        $estado = strtoupper(
            trim(
                (string)(
                    $data['estado_facturacion']
                    ?? ''
                )
            )
        );

        if (
            $estado === ''
            && $actual !== []
        ) {
            $estado = strtoupper(
                trim(
                    (string)(
                        $actual['estado_facturacion']
                        ?? ''
                    )
                )
            );
        }

        if ($estado === '') {
            $estado = 'PENDIENTE';
        }

        $permitidos = [
            'PENDIENTE',
            'FACTURABLE',
            'FACTURADO',
            'NO_FACTURAR',
        ];

        if (!in_array($estado, $permitidos, true)) {
            throw new RuntimeException(
                'El estado de facturación no es válido.'
            );
        }

        $data['estado_facturacion'] = $estado;
    }

    /*
    |--------------------------------------------------------------------------
    | FECHA
    |--------------------------------------------------------------------------
    */

    private function normalizarFecha(
        mixed $fecha
    ): string {
        if (
            $fecha === null
            || trim((string)$fecha) === ''
        ) {
            return date(
                'Y-m-d H:i:s'
            );
        }

        $valor = trim(
            (string)$fecha
        );

        /*
        |--------------------------------------------------------------------------
        | Formato HTML date
        |--------------------------------------------------------------------------
        */

        if (
            preg_match(
                '/^\d{4}-\d{2}-\d{2}$/',
                $valor
            )
        ) {
            $timestamp =
                strtotime(
                    $valor . ' 00:00:00'
                );
        } else {
            $timestamp =
                strtotime($valor);
        }

        if ($timestamp === false) {
            throw new RuntimeException(
                'La fecha del informe es inválida.'
            );
        }

        return date(
            'Y-m-d H:i:s',
            $timestamp
        );
    }

    /*
    |--------------------------------------------------------------------------
    | ESTADOS
    |--------------------------------------------------------------------------
    */

    private function validarEstado(
        string $estado
    ): void {
        $permitidos = [
            'PENDIENTE',
            'BORRADOR',
            'FINALIZADO',
            'ANULADO',
        ];

        if (
            !in_array(
                $estado,
                $permitidos,
                true
            )
        ) {
            throw new RuntimeException(
                'El estado del informe no es válido.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | TALONARIOS - SOLAPAMIENTO
    |--------------------------------------------------------------------------
    */

    /**
     * Verifica que un rango no se superponga con otro talonario TNG.
     *
     * No utiliza SQL: aprovecha Repository::talonarios().
     */
    private function validarSolapamientoTalonario(
        int $desde,
        int $hasta,
        ?int $excluirId = null
    ): void {
        foreach (
            $this->repository->talonarios()
            as $talonario
        ) {
            if (!is_array($talonario)) {
                continue;
            }

            $id = (int)(
                $talonario['id']
                ?? 0
            );

            if (
                $excluirId !== null
                && $id === $excluirId
            ) {
                continue;
            }

            $otroDesde = (int)(
                $talonario['num_desde']
                ?? 0
            );

            $otroHasta = (int)(
                $talonario['num_hasta']
                ?? 0
            );

            if (
                $otroDesde <= 0
                || $otroHasta < $otroDesde
            ) {
                continue;
            }

            /*
             * Dos rangos se superponen si:
             *
             * desde <= otroHasta
             * y
             * hasta >= otroDesde
             */
            if (
                $desde <= $otroHasta
                && $hasta >= $otroDesde
            ) {
                $nombre = trim(
                    (string)(
                        $talonario['nombre']
                        ?? 'existente'
                    )
                );

                throw new RuntimeException(
                    "El rango {$desde}-{$hasta} se superpone con el talonario '{$nombre}'."
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PDF
    |--------------------------------------------------------------------------
    */

    /**
     * Guarda un PDF recibido por upload.
     */
    private function guardarPdf(
        array $archivo,
        string $numero = ''
    ): string {
        $error =
            (int)(
                $archivo['error']
                ?? UPLOAD_ERR_NO_FILE
            );

        if (
            $error !== UPLOAD_ERR_OK
        ) {
            throw new RuntimeException(
                $this->mensajeErrorUpload(
                    $error
                )
            );
        }

        $tmpName = (string)(
            $archivo['tmp_name']
            ?? ''
        );

        if (
            $tmpName === ''
            || !is_uploaded_file(
                $tmpName
            )
        ) {
            throw new RuntimeException(
                'El archivo recibido no es válido.'
            );
        }

        $size = (int)(
            $archivo['size']
            ?? 0
        );

        if (
            $size <= 0
        ) {
            throw new RuntimeException(
                'El PDF está vacío.'
            );
        }

        if (
            $size > 10 * 1024 * 1024
        ) {
            throw new RuntimeException(
                'El PDF supera el límite de 10 MB.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | MIME
        |--------------------------------------------------------------------------
        */

        $mime = '';

        if (
            function_exists(
                'finfo_open'
            )
        ) {
            $finfo =
                finfo_open(
                    FILEINFO_MIME_TYPE
                );

            if ($finfo !== false) {
                $mime =
                    (string)finfo_file(
                        $finfo,
                        $tmpName
                    );

                finfo_close(
                    $finfo
                );
            }
        }

        if (
            $mime === ''
            && function_exists(
                'mime_content_type'
            )
        ) {
            $mime =
                (string)mime_content_type(
                    $tmpName
                );
        }

        if (
            $mime !== 'application/pdf'
        ) {
            throw new RuntimeException(
                'El archivo no es un PDF válido.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Verificación adicional de firma PDF
        |--------------------------------------------------------------------------
        */

        $handle =
            @fopen(
                $tmpName,
                'rb'
            );

        if ($handle === false) {
            throw new RuntimeException(
                'No se pudo validar el PDF.'
            );
        }

        $firma =
            fread(
                $handle,
                5
            );

        fclose($handle);

        if (
            $firma !== '%PDF-'
        ) {
            throw new RuntimeException(
                'El archivo recibido no contiene una firma PDF válida.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Carpeta
        |--------------------------------------------------------------------------
        */

        $carpeta =
            BASE_PATH
            . '/informes_tecnicos';

        if (!is_dir($carpeta)) {
            if (
                !mkdir(
                    $carpeta,
                    0755,
                    true
                )
                && !is_dir($carpeta)
            ) {
                throw new RuntimeException(
                    'No se pudo crear la carpeta de informes técnicos.'
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Número seguro
        |--------------------------------------------------------------------------
        */

        $numero =
            preg_replace(
                '/[^0-9]/',
                '',
                $numero
            ) ?? '';

        if ($numero === '') {
            $numero = 'TNG';
        }

        /*
        |--------------------------------------------------------------------------
        | Nombre único
        |--------------------------------------------------------------------------
        */

        try {
            $aleatorio =
                bin2hex(
                    random_bytes(8)
                );
        } catch (Throwable) {
            $aleatorio =
                uniqid(
                    '',
                    true
                );
        }

        $nombre =
            $numero
            . '_'
            . date('Ymd_His')
            . '_'
            . $aleatorio
            . '.pdf';

        $destino =
            $carpeta
            . DIRECTORY_SEPARATOR
            . $nombre;

        if (
            !move_uploaded_file(
                $tmpName,
                $destino
            )
        ) {
            throw new RuntimeException(
                'No se pudo guardar el PDF.'
            );
        }

        @chmod(
            $destino,
            0644
        );

        return 'informes_tecnicos/'
            . $nombre;
    }

    /**
     * Mensaje amigable para errores de upload.
     */
    private function mensajeErrorUpload(
        int $error
    ): string {
        return match ($error) {
            UPLOAD_ERR_INI_SIZE,
            UPLOAD_ERR_FORM_SIZE =>
                'El PDF supera el tamaño máximo permitido.',

            UPLOAD_ERR_PARTIAL =>
                'El PDF se recibió de forma incompleta.',

            UPLOAD_ERR_NO_FILE =>
                'Debe seleccionar el PDF del informe.',

            UPLOAD_ERR_NO_TMP_DIR =>
                'El servidor no dispone de una carpeta temporal para la carga.',

            UPLOAD_ERR_CANT_WRITE =>
                'No se pudo escribir el archivo recibido.',

            UPLOAD_ERR_EXTENSION =>
                'Una extensión del servidor bloqueó la carga del PDF.',

            default =>
                'Error al subir el PDF.',
        };
    }

    /*
    |--------------------------------------------------------------------------
    | BORRAR PDF
    |--------------------------------------------------------------------------
    */

    private function borrarPdf(
        string $archivo
    ): void {
        $archivo =
            trim($archivo);

        if ($archivo === '') {
            return;
        }

        $archivo =
            ltrim(
                $archivo,
                '/\\'
            );

        /*
        |--------------------------------------------------------------------------
        | Protección contra traversal
        |--------------------------------------------------------------------------
        */

        if (
            str_contains(
                $archivo,
                '..'
            )
            || str_contains(
                $archivo,
                '\\'
            )
        ) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Solo permitimos archivos dentro de informes_tecnicos.
        |--------------------------------------------------------------------------
        */

        if (
            !str_starts_with(
                $archivo,
                'informes_tecnicos/'
            )
        ) {
            return;
        }

        $ruta =
            BASE_PATH
            . '/'
            . $archivo;

        if (
            is_file($ruta)
        ) {
            try {
                @unlink($ruta);
            } catch (Throwable $e) {
                error_log(
                    '[Informes_tng PDF delete] '
                    . $e->getMessage()
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DUPLICADOS
    |--------------------------------------------------------------------------
    */

    private function esDuplicado(
        PDOException $e
    ): bool {
        $code =
            (string)$e->getCode();

        if (
            $code === '23000'
        ) {
            return true;
        }

        return str_contains(
            strtolower(
                $e->getMessage()
            ),
            '1062'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | AUDITORÍA
    |--------------------------------------------------------------------------
    */

    private function auditarCreacion(
        int $id,
        array $data,
        string $tabla = 'historial_informes'
    ): void {
        try {
            $this->audit->created(
                'Informes_tng',
                $tabla,
                $id,
                $data
            );
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Audit created] '
                . $e->getMessage()
            );
        }
    }

    private function auditarActualizacion(
        int $id,
        array $antes,
        array $despues,
        string $tabla = 'historial_informes'
    ): void {
        try {
            $this->audit->updated(
                'Informes_tng',
                $tabla,
                $id,
                $antes,
                $despues
            );
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Audit updated] '
                . $e->getMessage()
            );
        }
    }

    private function auditarEliminacion(
        int $id,
        array $data,
        string $tabla = 'historial_informes'
    ): void {
        try {
            $this->audit->deleted(
                'Informes_tng',
                $tabla,
                $id,
                $data
            );
        } catch (Throwable $e) {
            error_log(
                '[Informes_tng Audit deleted] '
                . $e->getMessage()
            );
        }
    }
}