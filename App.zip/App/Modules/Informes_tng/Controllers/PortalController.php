<?php

declare(strict_types=1);


namespace App\Modules\Informes_tng\Controllers;


use App\Core\BaseController;
use App\Modules\Informes_tng\Repositories\Repository;
use PDO;
use Throwable;



final class PortalController extends BaseController
{


    private Repository $repository;




    public function __construct(
        private readonly PDO $db
    )
    {

        parent::__construct();


        $this->repository =
            new Repository(
                $this->db
            );

    }







    public function index():void
    {


        $this->requireAuth();



        try{


            $informes =
                $this->repository->ultimos();




            $this->moduleView(

                'Informes_tng',

                'portal_tng',

                [

                    'titulo'=>'Portal TNG',

                    'informes'=>$informes

                ],

                'app'

            );



        }
        catch(Throwable $e)
        {

            $this->fail($e);

        }



    }



}