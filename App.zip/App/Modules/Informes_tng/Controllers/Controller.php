<?php

declare(strict_types=1);

namespace App\Modules\Informes_tng\Controllers;

use App\Core\BaseController;
use App\Modules\Informes_tng\Services\Service;
use App\Services\Export\PdfService;
use App\Services\Export\ExcelService;
use RuntimeException;
use Throwable;
use PDO;

final class Controller extends BaseController
{
    private readonly Service $service;

    public function __construct(
        Service $service
    ) {
        parent::__construct();
        $this->service = $service;
    }

    /**
     * Helper de seguridad interno para restringir acciones de escritura a los Viewers.
     */
    private function restringirViewer(): void
    {
        if (
            $this->role() === 'tng_viewer'
            || $this->role() === 'TNG_VIEWER'
        ) {
            throw new RuntimeException(
                'Tu perfil de visualizador de informes TNG no tiene permisos para realizar esta operación.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        $this->requireAuth();

        try {
            $datos = $this->service->index() ?? [];

            /*
             * Permite llegar desde un número faltante del dashboard
             * directamente a Nueva carga con el Nº de informe precargado.
             */
            $numeroSeleccionado = trim(
                (string)($_GET['numero'] ?? '')
            );

            if (
                $numeroSeleccionado !== ''
                && !ctype_digit($numeroSeleccionado)
            ) {
                $numeroSeleccionado = '';
            }

            $esViewer = (
                $this->role() === 'tng_viewer'
                || $this->role() === 'TNG_VIEWER'
            );

            $this->moduleView(
                'Informes_tng',
                'index',
                array_merge(
                    [
                        'titulo' => 'Informes Técnicos TNG',

                        'csrf' => $this->csrf(),

                        'numeroSeleccionado' => $numeroSeleccionado,

                        'esViewer' => $esViewer,

                        'moduleCss' => [
                            '/assets/css/informes_tng/style.css'
                        ],

                        'moduleJs' => [
                            '/assets/js/modules/informes_tng/informes_tng.js'
                        ]
                    ],
                    $datos
                )
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function listado(): void
    {
        $this->index();
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR INFORMES A EXCEL
    |--------------------------------------------------------------------------
    */

    public function exportarExcel(): void
    {
        $this->requireAuth();

        try {
            $datosRaw = $this->obtenerDatosFiltradosExportar();

            $datosExcel = [];

            foreach ($datosRaw as $row) {

                $datosExcel[] = [
                    'Nº Informe' => (string)(
                        $row['nro_informe'] ?? ''
                    ),

                    'Fecha de Toma' => !empty($row['fecha'])
                        ? date(
                            'd/m/Y',
                            strtotime(
                                (string)$row['fecha']
                            )
                        )
                        : '-',

                    'Cliente' => (string)(
                        $row['cliente_nombre']
                        ?? 'Taller General'
                    ),

                    'Código TNG' => (string)(
                        $row['codigo_tng'] ?? ''
                    ),

                    'Número de Serie' => (string)(
                        $row['serie'] ?? ''
                    ),

                    'Modelo Equipo' => (string)(
                        $row['nombre_modelo'] ?? ''
                    ),

                    'Observaciones' => (string)(
                        $row['observaciones'] ?? ''
                    )
                ];
            }

            $excel = new ExcelService();

            $excel->download(
                $datosExcel,
                'reporte_informes_tng_'
                . date('Ymd_His')
                . '.csv'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR INFORMES A PDF
    |--------------------------------------------------------------------------
    */

    public function exportarPdf(): void
    {
        $this->requireAuth();

        try {
            $datosRaw = $this->obtenerDatosFiltradosExportar();

            $datosPdf = [];

            foreach ($datosRaw as $row) {

                $datosPdf[] = [
                    'Nº Informe' => (string)(
                        $row['nro_informe'] ?? ''
                    ),

                    'Fecha' => !empty($row['fecha'])
                        ? date(
                            'd/m/Y',
                            strtotime(
                                (string)$row['fecha']
                            )
                        )
                        : '-',

                    'Cliente' => (string)(
                        $row['cliente_nombre']
                        ?? 'Taller General'
                    ),

                    'Código' => (string)(
                        $row['codigo_tng'] ?? ''
                    ),

                    'Serie' => (string)(
                        $row['serie'] ?? ''
                    )
                ];
            }

            $pdf = new PdfService();

            $archivo = $pdf->generar(
                'Reporte de Informes Técnicos',
                $datosPdf
            );

            $pdf->descargar($archivo);

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS PARA EXPORTACIÓN
    |--------------------------------------------------------------------------
    */

    private function obtenerDatosFiltradosExportar(): array
    {
        $desde = trim(
            (string)(
                $_GET['fecha_desde'] ?? ''
            )
        );

        $hasta = trim(
            (string)(
                $_GET['fecha_hasta'] ?? ''
            )
        );

        $nro = trim(
            (string)(
                $_GET['nro_informe'] ?? ''
            )
        );

        $sql = "
            SELECT
                r.*,

                c.nombre AS cliente_nombre,

                e.codigo_interno AS codigo_tng,

                e.serie,

                m.nombre_modelo

            FROM registros_tng r

            LEFT JOIN clientes c
                ON c.id = r.cliente_id

            LEFT JOIN equipos e
                ON e.id = r.equipo_id

            LEFT JOIN modelos_equipos m
                ON m.id = e.modelo_id

            WHERE 1 = 1
        ";

        $params = [];

        if ($desde !== '') {

            $sql .= "
                AND r.fecha >= ?
            ";

            $params[] = $desde;
        }

        if ($hasta !== '') {

            $sql .= "
                AND r.fecha <= ?
            ";

            $params[] = $hasta;
        }

        if ($nro !== '') {

            $sql .= "
                AND r.nro_informe = ?
            ";

            $params[] = $nro;
        }

        $sql .= "
            ORDER BY
                r.id DESC

            LIMIT 500
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute($params);

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        ) ?: [];
    }

    /*
    |--------------------------------------------------------------------------
    | AJAX - CLIENTES
    |--------------------------------------------------------------------------
    */

    public function clientes(): void
    {
        $this->requireAuth();

        try {

            $localidadId = (int)(
                $_GET['localidad_id'] ?? 0
            );

            $this->json([
                'success' => true,

                'data' => $this->service->clientes(
                    $localidadId
                )
            ]);

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' => false,
                    'message' => $e->getMessage()
                ],
                500
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | AJAX - EQUIPOS
    |--------------------------------------------------------------------------
    */

    public function equipos(): void
    {
        $this->requireAuth();

        try {

            $clienteId = (int)(
                $_GET['cliente_id'] ?? 0
            );

            $this->json([
                'success' => true,

                'data' => $this->service->equipos(
                    $clienteId
                )
            ]);

        } catch (Throwable $e) {

            $this->json(
                [
                    'success' => false,
                    'message' => $e->getMessage()
                ],
                500
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | GUARDAR INFORME
    |--------------------------------------------------------------------------
    */

    public function guardar(): void
    {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            if (!$this->validateCsrf()) {
                throw new RuntimeException(
                    'Token CSRF inválido'
                );
            }

            $this->service->guardar(
                $_POST,
                $_FILES ?? []
            );

            $this->redirect(
                '/informes-tng?success=created'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR
    |--------------------------------------------------------------------------
    */

    public function editar(int $id): void
    {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de informe inválido.'
                );
            }

            $informe = $this->service->buscar(
                $id
            );

            if (!$informe) {
                throw new RuntimeException(
                    'Informe inexistente.'
                );
            }

            $localidadId = (int)(
                $informe['localidad_id'] ?? 0
            );

            $clienteId = (int)(
                $informe['cliente_id'] ?? 0
            );

            $this->moduleView(
                'Informes_tng',
                'editar',
                [
                    'titulo' => 'Editar Informe TNG',

                    'informe' => $informe,

                    'localidades' =>
                        $this->service->localidades(),

                    'clientes' =>
                        $this->service->clientes(
                            $localidadId
                        ),

                    'equipos' =>
                        $this->service->equipos(
                            $clienteId
                        ),

                    'csrf' => $this->csrf(),

                    'moduleCss' => [
                        '/assets/css/informes_tng/style.css'
                    ],

                    'moduleJs' => []
                ]
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR
    |--------------------------------------------------------------------------
    */

    public function actualizar(int $id): void
    {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            $this->validateCsrf();

            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de informe inválido.'
                );
            }

            $this->service->actualizar(
                $id,
                $_POST,
                $_FILES ?? []
            );

            $this->redirect(
                '/informes-tng?success=updated'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR
    |--------------------------------------------------------------------------
    */

    public function eliminar(int $id): void
    {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de informe inválido.'
                );
            }

            $this->service->eliminar(
                $id
            );

            $this->redirect(
                '/informes-tng?success=deleted'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | TALONARIOS
    |--------------------------------------------------------------------------
    */

    public function talonarios(): void
    {
        $this->requireAuth();

        try {

            $datos = $this->service->talonarios();

            $esViewer = (
                $this->role() === 'tng_viewer'
                || $this->role() === 'TNG_VIEWER'
            );

            $this->moduleView(
                'Informes_tng',
                'talonarios',
                [
                    'titulo' => 'Talonarios TNG',

                    'talonarios' => $datos,

                    'esViewer' => $esViewer,

                    'csrf' => $this->csrf(),

                    'moduleCss' => [
                        '/assets/css/informes_tng/style.css'
                    ],

                    'moduleJs' => []
                ]
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR TALONARIOS - EXCEL
    |--------------------------------------------------------------------------
    */

    public function exportarTalonariosExcel(): void
    {
        $this->requireAuth();

        try {

            $talonarios = $this->service->talonarios();

            $datosExcel = [];

            foreach ($talonarios as $talonario) {

                if (!is_array($talonario)) {
                    continue;
                }

                $numero = (string)(
                    $talonario['numero']
                    ?? $talonario['nro_talonario']
                    ?? $talonario['nombre']
                    ?? ''
                );

                $desde = (int)(
                    $talonario['desde']
                    ?? $talonario['num_desde']
                    ?? $talonario['numero_desde']
                    ?? 0
                );

                $hasta = (int)(
                    $talonario['hasta']
                    ?? $talonario['num_hasta']
                    ?? $talonario['numero_hasta']
                    ?? 0
                );

                $utilizados = (int)(
                    $talonario['utilizados']
                    ?? $talonario['informes_cargados']
                    ?? $talonario['usados']
                    ?? 0
                );

                $faltantes = (int)(
                    $talonario['faltantes']
                    ?? $talonario['cantidad_faltantes']
                    ?? 0
                );

                $estado = strtoupper(
                    (string)(
                        $talonario['estado']
                        ?? 'ACTIVO'
                    )
                );

                $datosExcel[] = [
                    'Talonario' => $numero,
                    'Desde' => $desde,
                    'Hasta' => $hasta,
                    'Utilizados' => $utilizados,
                    'Faltantes' => $faltantes,
                    'Estado' => $estado
                ];
            }

            $excel = new ExcelService();

            $excel->download(
                $datosExcel,
                'talonarios_tng_'
                . date('Ymd_His')
                . '.csv'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EXPORTAR TALONARIOS - PDF
    |--------------------------------------------------------------------------
    */

    public function exportarTalonariosPdf(): void
    {
        $this->requireAuth();

        try {

            $talonarios = $this->service->talonarios();

            $datosPdf = [];

            foreach ($talonarios as $talonario) {

                if (!is_array($talonario)) {
                    continue;
                }

                $numero = (string)(
                    $talonario['numero']
                    ?? $talonario['nro_talonario']
                    ?? $talonario['nombre']
                    ?? ''
                );

                $desde = (int)(
                    $talonario['desde']
                    ?? $talonario['num_desde']
                    ?? $talonario['numero_desde']
                    ?? 0
                );

                $hasta = (int)(
                    $talonario['hasta']
                    ?? $talonario['num_hasta']
                    ?? $talonario['numero_hasta']
                    ?? 0
                );

                $utilizados = (int)(
                    $talonario['utilizados']
                    ?? $talonario['informes_cargados']
                    ?? $talonario['usados']
                    ?? 0
                );

                $faltantes = (int)(
                    $talonario['faltantes']
                    ?? $talonario['cantidad_faltantes']
                    ?? 0
                );

                $estado = strtoupper(
                    (string)(
                        $talonario['estado']
                        ?? 'ACTIVO'
                    )
                );

                $datosPdf[] = [
                    'Talonario' => $numero,
                    'Desde' => $desde,
                    'Hasta' => $hasta,
                    'Utilizados' => $utilizados,
                    'Faltantes' => $faltantes,
                    'Estado' => $estado
                ];
            }

            $pdf = new PdfService();

            $archivo = $pdf->generar(
                'Talonarios de Informes Técnicos TNG',
                $datosPdf
            );

            $pdf->descargar(
                $archivo
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR TALONARIO
    |--------------------------------------------------------------------------
    */

    public function crearTalonario(): void
    {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            $this->validateCsrf();

            $this->service->crearTalonario(
                $_POST
            );

            $this->redirect(
                '/informes-tng/talonarios?success=created'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR TALONARIO
    |--------------------------------------------------------------------------
    */

    public function actualizarTalonario(
        int $id
    ): void {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            $this->validateCsrf();

            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de talonario inválido.'
                );
            }

            $this->service->actualizarTalonario(
                $id,
                $_POST
            );

            $this->redirect(
                '/informes-tng/talonarios?success=updated'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR TALONARIO
    |--------------------------------------------------------------------------
    */

    public function eliminarTalonario(
        int $id
    ): void {
        $this->requireAuth();

        $this->restringirViewer();

        try {

            $this->validateCsrf();

            if ($id <= 0) {
                throw new RuntimeException(
                    'ID de talonario inválido.'
                );
            }

            $this->service->eliminarTalonario(
                $id
            );

            $this->redirect(
                '/informes-tng/talonarios?success=deleted'
            );

        } catch (Throwable $e) {
            $this->fail($e);
        }
    }
}