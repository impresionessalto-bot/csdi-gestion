<?php

declare(strict_types=1);

use App\Modules\Informes_tng\Controllers\Controller;
use App\Core\Router;

/*
|--------------------------------------------------------------------------
| INFORMES TNG
|--------------------------------------------------------------------------
*/

$registrarRutasInformesTng = function (): void {

    /*
    |--------------------------------------------------------------------------
    | PRINCIPAL
    |--------------------------------------------------------------------------
    */

    Router::get(
        '/',
        [
            Controller::class,
            'index'
        ]
    );

    Router::get(
        '/listado',
        [
            Controller::class,
            'listado'
        ]
    );

    /*
    |--------------------------------------------------------------------------
    | INFORMES
    |--------------------------------------------------------------------------
    */

    Router::get(
        '/clientes',
        [
            Controller::class,
            'clientes'
        ]
    );

    Router::get(
        '/equipos',
        [
            Controller::class,
            'equipos'
        ]
    );

    Router::post(
        '/guardar',
        [
            Controller::class,
            'guardar'
        ]
    );

    Router::get(
        '/{id}/editar',
        [
            Controller::class,
            'editar'
        ]
    );

    Router::post(
        '/{id}/actualizar',
        [
            Controller::class,
            'actualizar'
        ]
    );

    Router::post(
        '/{id}/eliminar',
        [
            Controller::class,
            'eliminar'
        ]
    );

    /*
    |--------------------------------------------------------------------------
    | EXPORTACIONES DE INFORMES
    |--------------------------------------------------------------------------
    */

    Router::get(
        '/exportar-excel',
        [
            Controller::class,
            'exportarExcel'
        ]
    );

    Router::get(
        '/exportar-pdf',
        [
            Controller::class,
            'exportarPdf'
        ]
    );

    /*
    |--------------------------------------------------------------------------
    | TALONARIOS
    |--------------------------------------------------------------------------
    */

    Router::get(
        '/talonarios/exportar-excel',
        [
            Controller::class,
            'exportarTalonariosExcel'
        ]
    );

    Router::get(
        '/talonarios/exportar-pdf',
        [
            Controller::class,
            'exportarTalonariosPdf'
        ]
    );

    Router::get(
        '/talonarios',
        [
            Controller::class,
            'talonarios'
        ]
    );

    Router::post(
        '/talonario',
        [
            Controller::class,
            'crearTalonario'
        ]
    );

    Router::post(
        '/guardar-talonario',
        [
            Controller::class,
            'crearTalonario'
        ]
    );

    Router::post(
        '/talonario/{id}/actualizar',
        [
            Controller::class,
            'actualizarTalonario'
        ]
    );

    Router::post(
        '/talonario/{id}/eliminar',
        [
            Controller::class,
            'eliminarTalonario'
        ]
    );
};

/*
|--------------------------------------------------------------------------
| GRUPO PRINCIPAL
|--------------------------------------------------------------------------
*/

Router::group(
    '/informes-tng',
    [
        'auth'
    ],
    $registrarRutasInformesTng
);

/*
|--------------------------------------------------------------------------
| GRUPO ALTERNATIVO
|--------------------------------------------------------------------------
*/

Router::group(
    '/informes_tng',
    [
        'auth'
    ],
    $registrarRutasInformesTng
);