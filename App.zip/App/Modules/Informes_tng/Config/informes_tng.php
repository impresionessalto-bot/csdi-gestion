<?php

declare(strict_types=1);


use App\Modules\Informes_tng\Controllers\Controller;



/*
|--------------------------------------------------------------------------
| INFORMES TNG
|--------------------------------------------------------------------------
*/



$router->get(

    '/informes-tng',

    [
        Controller::class,
        'index'
    ]

);



/*
|--------------------------------------------------------------------------
| GUARDAR INFORME
|--------------------------------------------------------------------------
*/


$router->post(

    '/informes-tng/guardar',

    [
        Controller::class,
        'guardar'
    ]

);





/*
|--------------------------------------------------------------------------
| EDITAR
|--------------------------------------------------------------------------
*/


$router->get(

    '/informes-tng/editar/{id}',

    [
        Controller::class,
        'editar'
    ]

);





/*
|--------------------------------------------------------------------------
| ACTUALIZAR
|--------------------------------------------------------------------------
*/


$router->post(

    '/informes-tng/actualizar/{id}',

    [
        Controller::class,
        'actualizar'
    ]

);





/*
|--------------------------------------------------------------------------
| ELIMINAR
|--------------------------------------------------------------------------
*/


$router->post(

    '/informes-tng/eliminar/{id}',

    [
        Controller::class,
        'eliminar'
    ]

);







/*
|--------------------------------------------------------------------------
| CASCADA
|--------------------------------------------------------------------------
*/


$router->get(

    '/informes-tng/clientes',

    [
        Controller::class,
        'clientes'
    ]

);





$router->get(

    '/informes-tng/equipos',

    [
        Controller::class,
        'equipos'
    ]

);







/*
|--------------------------------------------------------------------------
| PDF
|--------------------------------------------------------------------------
*/


$router->get(

    '/informes-tng/pdf/{id}',

    [
        Controller::class,
        'pdf'
    ]

);







/*
|--------------------------------------------------------------------------
| TALONARIOS
|--------------------------------------------------------------------------
*/


$router->post(

    '/informes-tng/talonario',

    [
        Controller::class,
        'guardarTalonario'
    ]

);





$router->post(

    '/informes-tng/talonario/eliminar/{id}',

    [
        Controller::class,
        'eliminarTalonario'
    ]

);