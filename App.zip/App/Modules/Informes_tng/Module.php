<?php

declare(strict_types=1);

namespace App\Modules\Informes_tng;


use App\Core\Module as BaseModule;



final class Module extends BaseModule
{


    public function name():string
    {
        return 'Informes_tng';
    }



    public function routes():string
    {
        return __DIR__.'/Config/routes.php';
    }



    public function priority():int
    {
        return 60;
    }



    public function menu():array
    {

        return [

            [

                'title'=>'Informes TNG',

                'icon'=>'fa-solid fa-file-circle-check',

                'url'=>'/informes-tng',

                'group'=>'Operaciones',

                'order'=>60,

                'permission'=>'informes_tng.view',

                'roles'=>[

                    'admin',
                    'tng'

                ],

                'visible'=>true

            ]

        ];

    }




    public function icon():string
    {
        return 'fa-solid fa-file-circle-check';
    }



    public function url():string
    {
        return '/informes-tng';
    }



    public function group():string
    {
        return 'Operaciones';
    }



    public function order():int
    {
        return 60;
    }




    public function permissions():array
    {

        return [

            'informes_tng.view',

            'informes_tng.create',

            'informes_tng.edit',

            'informes_tng.delete'

        ];

    }




    public function dependencies():array
    {
        return [];
    }




    public function enabled():bool
    {
        return true;
    }




    public function boot():void
    {

    }


}