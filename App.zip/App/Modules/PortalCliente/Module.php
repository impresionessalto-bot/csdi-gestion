<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente;

use App\Core\Module as BaseModule;

final class Module extends BaseModule
{
    public function name(): string
    {
        return 'Portal Cliente';
    }

    public function routes(): string
    {
        return __DIR__ . '/Config/routes.php';
    }

    public function menu(): array
    {
        return [
            [
                'title'      => 'Portal Cliente',
                'icon'       => 'fa-solid fa-user',
                'url'        => '/portal-cliente',
                'group'      => 'Clientes',
                'order'      => 40,
                'permission' => 'portal_cliente.view',
                'visible'    => true,
                'children'   => [],
            ]
        ];
    }

    public function icon(): string
    {
        return 'fa-solid fa-user';
    }

    public function url(): string
    {
        return '/portal-cliente';
    }

    public function group(): string
    {
        return 'Clientes';
    }

    public function order(): int
    {
        return 40;
    }

    public function permissions(): array
    {
        return [
            'portal_cliente.view',
            'portal_cliente.create',
            'portal_cliente.edit',
            'portal_cliente.delete',
        ];
    }

    public function dependencies(): array
    {
        return [];
    }

    public function enabled(): bool
    {
        return true;
    }

    public function boot(): void
    {
    }
}