<?php
/**
 * FORMULARIO DE REGISTRO INSTITUCIONAL - CSDI ERP
 * Ubicación: App/Modules/PortalCliente/Views/registro.php
 */
$csrf = $csrf ?? ($_SESSION['csrf'] ?? '');
$error = $error ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($titulo ?? 'Registro', ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow-sm border-0 rounded-4" style="width: 480px;">
        <div class="card-body p-4">
            
            <div class="text-center mb-4">
                <h3 class="fw-bold text-dark">CSDI ERP INSTITUCIONAL</h3>
                <p class="text-muted small">Creá tu cuenta institucional para acceder al Portal de Gestión</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2 small">
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <form method="post" action="/registro-cliente/guardar">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Razón Social / Nombre y Apellido *</label>
                    <input type="text" name="nombre" class="form-control" required placeholder="Ej. Empresa o Cliente SRL">
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Teléfono / WhatsApp</label>
                    <input type="text" name="telefono" class="form-control" placeholder="Ej. 2474597883">
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Correo Electrónico</label>
                    <input type="email" name="email" class="form-control" placeholder="correo@ejemplo.com">
                </div>

                <hr class="text-muted my-3">

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Nombre de Usuario (para ingresar) *</label>
                    <input type="text" name="usuario" class="form-control" required placeholder="Definí tu usuario">
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Contraseña *</label>
                    <input type="password" name="password" class="form-control" required placeholder="••••••••">
                </div>

                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold rounded-3 mb-3">
                    Registrarse en el Sistema
                </button>

                <div class="text-center">
                    <a href="/login" class="text-decoration-none small text-secondary">
                        ← Volver al inicio de sesión
                    </a>
                </div>
            </form>

        </div>
    </div>
</div>

</body>
</html>