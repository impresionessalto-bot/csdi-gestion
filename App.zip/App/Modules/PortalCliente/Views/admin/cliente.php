<?php
declare(strict_types=1);

$titulo = $titulo ?? 'Clientes Portal';
$clientes = $clientes ?? [];
$csrf = $csrf ?? '';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark">
                <i class="fa-solid fa-users text-primary me-2"></i> <?= htmlspecialchars($titulo) ?>
            </h2>
            <p class="text-muted mb-0">Gestión y control de accesos de clientes al portal</p>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Cliente</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Estado</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($clientes)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">No hay clientes registrados en el portal.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($clientes as $c): ?>
                                <tr>
                                    <td><?= (int)$c['cliente_id'] ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($c['nombre'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($c['email'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($c['telefono'] ?? '-') ?></td>
                                    <td>
                                        <?php if (!empty($c['activo'])): ?>
                                            <span class="badge bg-success">Activo</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inactivo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <a href="/portal-cliente/admin/editar/<?= (int)$c['cliente_id'] ?>" class="btn btn-sm btn-outline-primary" title="Configurar">
                                            <i class="fa-solid fa-gear"></i> Configurar
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>