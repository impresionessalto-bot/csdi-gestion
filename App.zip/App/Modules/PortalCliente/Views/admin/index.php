<?php
declare(strict_types=1);

$titulo = $titulo ?? 'Administración Portal Clientes';
$data = $data ?? [];
$csrf = $csrf ?? '';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark">
                <i class="fa-solid fa-users-gear text-primary me-2"></i> <?= htmlspecialchars($titulo) ?>
            </h2>
            <p class="text-muted mb-0">Panel general de control y estadísticas del portal de clientes</p>
        </div>
        <div>
            <a href="/portal-cliente/admin/clientes" class="btn btn-primary">
                <i class="fa-solid fa-list me-1"></i> Ver Listado de Clientes
            </a>
        </div>
    </div>

    <!-- Tarjetas de Estadísticas -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-primary text-white">
                <div class="card-body">
                    <h6 class="text-uppercase small fw-bold">Total Clientes Portal</h6>
                    <h2 class="display-6 fw-bold mb-0"><?= (int)($data['clientes'] ?? 0) ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success text-white">
                <div class="card-body">
                    <h6 class="text-uppercase small fw-bold">Activos</h6>
                    <h2 class="display-6 fw-bold mb-0"><?= (int)($data['activos'] ?? 0) ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning text-dark">
                <div class="card-body">
                    <h6 class="text-uppercase small fw-bold">Con Contadores</h6>
                    <h2 class="display-6 fw-bold mb-0"><?= (int)($data['contadores'] ?? 0) ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-danger text-white">
                <div class="card-body">
                    <h6 class="text-uppercase small fw-bold">Tickets Pendientes</h6>
                    <h2 class="display-6 fw-bold mb-0"><?= (int)($data['tickets'] ?? 0) ?></h2>
                </div>
            </div>
        </div>
    </div>
</div>