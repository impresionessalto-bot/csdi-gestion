<?php
/**
 * DASHBOARD PORTAL CLIENTE - CSDI ERP PRO
 * Ubicación: App/Modules/PortalCliente/Views/index.php
 */
$csrf = $csrf ?? ($_SESSION['csrf'] ?? '');
$cliente = $cliente ?? ['nombre' => 'Cliente'];
$config = $config ?? [];
$saldo = $saldo ?? 0;
$equipos = $equipos ?? [];
$consumo = $consumo ?? ['bn' => 0, 'col' => 0];
$movimientos = $movimientos ?? [];
$estado_cuenta = $estado_cuenta ?? [];
?>

<div class="container py-4 text-dark">

    <script>
    const CSRF_TOKEN = "<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>";
    </script>

    <!-- CABECERA -->
    <div class="row mb-4 align-items-center">
        <div class="col-md-8">
            <h2 class="fw-bold m-0">Hola, <?= htmlspecialchars($cliente['nombre'] ?? 'Cliente', ENT_QUOTES, 'UTF-8') ?> 👋</h2>
            <p class="text-muted"><?= htmlspecialchars($config['portal_mensaje_bienvenida'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
        </div>
        <div class="col-md-4 text-md-end">
            <div class="card border-0 shadow-sm rounded-4 p-2 px-3 d-inline-block bg-white border-start border-success border-4">
                <small class="text-muted fw-bold">SALDO</small>
                <span class="fw-bold fs-5 <?= $saldo > 0 ? 'text-danger' : 'text-success' ?>">
                    $ <?= number_format($saldo, 2, ',', '.') ?>
                </span>
            </div>
        </div>
    </div>

    <!-- KPI -->
    <div class="row g-3 mb-4 text-center">
        <div class="col-md-4">
            <div class="card p-3 rounded-4 shadow-sm border-0">
                <small class="text-muted">Equipos</small>
                <h4 class="fw-bold mb-0"><?= count($equipos) ?></h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 rounded-4 shadow-sm border-0">
                <small class="text-muted">B&N</small>
                <h4 class="fw-bold mb-0"><?= number_format($consumo['bn'] ?? 0, 0, ',', '.') ?></h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 rounded-4 shadow-sm border-0">
                <small class="text-muted">Color</small>
                <h4 class="fw-bold mb-0"><?= number_format($consumo['col'] ?? 0, 0, ',', '.') ?></h4>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- EQUIPOS -->
        <div class="col-lg-8">
            <div class="card shadow-sm rounded-4 mb-4 border-0">
                <div class="card-header bg-white fw-bold py-3">Equipos Asignados y Lecturas</div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Equipo / Serie</th>
                                <th>Lectura Anterior</th>
                                <th>Última Lectura</th>
                                <th class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($equipos)): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-4">No hay equipos registrados.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($equipos as $e): ?>
                                <tr>
                                    <td>
                                        <b class="text-dark"><?= htmlspecialchars($e['nombre_modelo'] ?? '', ENT_QUOTES, 'UTF-8') ?></b><br>
                                        <small class="text-muted">Serie: <?= htmlspecialchars($e['serie'] ?? '', ENT_QUOTES, 'UTF-8') ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">B&N: <?= number_format((int)($e['anterior_bn'] ?? 0), 0, ',', '.') ?></span><br>
                                        <small class="text-muted">Color: <?= number_format((int)($e['anterior_col'] ?? 0), 0, ',', '.') ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-success">B&N: <?= number_format((int)($e['ultima_bn'] ?? 0), 0, ',', '.') ?></span><br>
                                        <small class="text-muted">Color: <?= number_format((int)($e['ultima_col'] ?? 0), 0, ',', '.') ?></small>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-primary btn-sm mb-1" onclick="abrirModalContador(<?= (int)$e['id'] ?>, '<?= htmlspecialchars($e['nombre_modelo'] ?? '', ENT_QUOTES, 'UTF-8') ?>')">
                                            LECTURA
                                        </button>
                                        <button class="btn btn-info btn-sm mb-1 text-white" onclick="pedirInsumo(<?= (int)$e['id'] ?>)">
                                            TONER
                                        </button>
                                        <button class="btn btn-danger btn-sm mb-1" onclick="reportarFalla(<?= (int)$e['id'] ?>)">
                                            SERVICE
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- DERECHA -->
        <div class="col-lg-4">
            <!-- SOPORTE WHATSAPP -->
            <?php if (!empty($config['portal_whatsapp'])): ?>
            <div class="card p-3 mb-4 text-center bg-primary text-white rounded-4 border-0 shadow-sm">
                <p class="mb-2 small fw-semibold">¿Necesitás asistencia inmediata?</p>
                <a href="https://wa.me/<?= htmlspecialchars($config['portal_whatsapp'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" class="btn btn-light btn-sm fw-bold">
                    <i class="fa-brands fa-whatsapp text-success me-1"></i> Contactar por WhatsApp
                </a>
            </div>
            <?php endif; ?>

            <!-- MOVIMIENTOS -->
            <div class="card shadow-sm mb-4 rounded-4 border-0">
                <div class="card-header bg-white fw-bold py-3">Últimos Movimientos</div>
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <tbody>
                            <?php if (empty($movimientos)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-3">Sin movimientos recientes.</td></tr>
                            <?php else: ?>
                                <?php foreach($movimientos as $m): ?>
                                <tr>
                                    <td><?= !empty($m['fecha']) ? date('d/m', strtotime($m['fecha'])) : '-' ?></td>
                                    <td><?= htmlspecialchars($m['concepto'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                                    <td class="text-end fw-semibold">$ <?= number_format((float)($m['importe'] ?? 0), 0, ',', '.') ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ESTADO CUENTA -->
            <div class="card shadow-sm rounded-4 border-0">
                <div class="card-header bg-white fw-bold py-3">Estado de Cuenta</div>
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <tbody>
                            <?php if (empty($estado_cuenta)): ?>
                                <tr><td colspan="3" class="text-center text-muted py-3">Sin registros en cuenta corriente.</td></tr>
                            <?php else: ?>
                                <?php foreach($estado_cuenta as $m): ?>
                                <tr>
                                    <td><?= !empty($m['fecha']) ? date('d/m', strtotime($m['fecha'])) : '-' ?></td>
                                    <td>
                                        <?= htmlspecialchars($m['concepto'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                                        <?php if(($m['tipo'] ?? '') === 'factura' && !empty($m['referencia_id'])): ?>
                                            <a href="/portal/ver-factura/<?= (int)$m['referencia_id'] ?>" class="ms-1 small">Ver</a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end fw-semibold">$ <?= number_format((float)($m['importe'] ?? 0), 0, ',', '.') ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL CONTADOR -->
<div class="modal fade" id="modalContador" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Registrar Lectura de Contador</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-4">
                <input type="hidden" id="cont-eq-id">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Contador Blanco y Negro</label>
                    <input type="number" id="input-bn" class="form-control" placeholder="Ej. 15420" min="0">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Contador Color (Opcional)</label>
                    <input type="number" id="input-col" class="form-control" placeholder="Ej. 1250" min="0">
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary btn-sm px-4" onclick="enviarContador()">Guardar Lectura</button>
            </div>
        </div>
    </div>
</div>

<script>
function abrirModalContador(id, modelo) {
    document.getElementById('cont-eq-id').value = id;
    document.getElementById('input-bn').value = '';
    document.getElementById('input-col').value = '';
    new bootstrap.Modal(document.getElementById('modalContador')).show();
}

function pedirInsumo(id) {
    if (!confirm("¿Desea solicitar un tóner para este equipo?")) return;

    fetch('/portal/solicitar-insumo', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': CSRF_TOKEN
        },
        body: JSON.stringify({ equipo_id: id })
    })
    .then(r => r.json())
    .then(r => {
        if (r.success) {
            alert('¡Solicitud de insumo enviada correctamente!');
        } else {
            alert('Error: ' + (r.error || 'No se pudo procesar la solicitud.'));
        }
    })
    .catch(() => alert('Error de conexión con el servidor.'));
}

function reportarFalla(id) {
    const falla = prompt("Por favor, describa brevemente la falla o motivo del servicio técnico:");
    if (!falla || falla.trim() === '') return;

    fetch('/portal/abrir-ticket', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': CSRF_TOKEN
        },
        body: JSON.stringify({ equipo_id: id, falla: falla })
    })
    .then(r => r.json())
    .then(r => {
        if (r.success) {
            alert('¡Ticket de soporte creado exitosamente!');
            location.reload();
        } else {
            alert('Error: ' + (r.error || 'No se pudo abrir el ticket.'));
        }
    })
    .catch(() => alert('Error de conexión con el servidor.'));
}

function enviarContador() {
    const bnVal = document.getElementById('input-bn').value;
    const bn = parseInt(bnVal || 0, 10);
    
    if (bn <= 0) {
        return alert("Por favor, ingrese un valor de lectura B&N válido.");
    }

    const equipoId = document.getElementById('cont-eq-id').value;
    const col = parseInt(document.getElementById('input-col').value || 0, 10);

    fetch('/portal/guardar-contador', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': CSRF_TOKEN
        },
        body: JSON.stringify({
            equipo_id: equipoId,
            lectura_bn: bn,
            lectura_col: col
        })
    })
    .then(r => r.json())
    .then(r => {
        if (r.success) {
            alert('¡Lectura guardada con éxito!');
            location.reload();
        } else {
            alert('Error: ' + (r.error || 'No se pudo guardar la lectura.'));
        }
    })
    .catch(() => alert('Error de conexión con el servidor.'));
}
</script>