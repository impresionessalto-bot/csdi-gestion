<?php
declare(strict_types=1);

namespace App\Modules\PortalCliente\Repositories;

use PDO;

final class Repository
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function obtenerCliente(int $clienteId): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM clientes WHERE id = ?");
        $stmt->execute([$clienteId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function obtenerEquiposCliente(int $clienteId): array
    {
        $sql = "SELECT e.id, 
                       COALESCE(m.nombre_modelo, 'Equipo Genérico') AS nombre_modelo, 
                       e.serie 
                FROM equipos e 
                LEFT JOIN modelos_equipos m ON e.modelo_id = m.id 
                WHERE e.cliente_id = ? AND (e.deleted_at IS NULL)";
                
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$clienteId]);
        $equipos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($equipos as &$eq) {
            $stmtReg = $this->db->prepare("
                SELECT contador_actual, contador_actual_color, fecha 
                FROM registros 
                WHERE equipo_id = ? 
                ORDER BY fecha DESC, id DESC 
                LIMIT 2
            ");
            $stmtReg->execute([$eq['id']]);
            $lecturas = $stmtReg->fetchAll(PDO::FETCH_ASSOC);

            $eq['ultima_bn'] = $lecturas[0]['contador_actual'] ?? 0;
            $eq['ultima_col'] = $lecturas[0]['contador_actual_color'] ?? 0;
            $eq['fecha_ultima'] = $lecturas[0]['fecha'] ?? '-';

            $eq['anterior_bn'] = $lecturas[1]['contador_actual'] ?? 0;
            $eq['anterior_col'] = $lecturas[1]['contador_actual_color'] ?? 0;
        }
        unset($eq);

        return $equipos;
    }

    public function obtenerClienteIdPorUsuarioId(int $usuarioId): int
    {
        $stmt = $this->db->prepare("SELECT linked_cliente_id FROM usuarios WHERE id = ?");
        $stmt->execute([$usuarioId]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        return (int)($res['linked_cliente_id'] ?? 0);
    }

    public function obtenerMovimientos(int $clienteId): array
    {
        $stmt = $this->db->prepare("SELECT fecha, concepto, importe FROM cta_cte_clientes WHERE cliente_id = ? ORDER BY fecha DESC LIMIT 10");
        $stmt->execute([$clienteId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerEstadoCuenta(int $clienteId): array
    {
        $stmt = $this->db->prepare("SELECT fecha, concepto, tipo, importe, id AS referencia_id FROM cta_cte_clientes WHERE cliente_id = ? ORDER BY fecha DESC LIMIT 15");
        $stmt->execute([$clienteId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerConfiguracion(): array
    {
        $stmt = $this->db->query("SELECT clave, valor FROM configuracion_sistema");
        $config = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $config[$row['clave']] = $row['valor'];
        }
        return $config;
    }

    public function guardarLecturaContador(int $equipoId, int $bn, int $col): bool
    {
        $stmt = $this->db->prepare("INSERT INTO registros (equipo_id, contador_actual, copias_color, fecha) VALUES (?, ?, ?, NOW())");
        return $stmt->execute([$equipoId, $bn, $col]);
    }

    public function registrarInsumoPedido(int $equipoId): bool
    {
        $stmt = $this->db->prepare("INSERT INTO pedidos_insumos (equipo_id, estado, fecha_pedido) VALUES (?, 'Pendiente', NOW())");
        return $stmt->execute([$equipoId]);
    }

    public function crearTicketFallaConIA(int $clienteId, int $equipoId, string $falla, string $analisisIa): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO servicios (cliente_id, equipo_id, fecha_solicitud, descripcion_problema, estado, prioridad, zona_falla) 
            VALUES (?, ?, NOW(), ?, 'Pendiente', 1, 'OTRO')
        ");
        $insertado = $stmt->execute([$clienteId, $equipoId, $falla]);

        if ($insertado) {
            $stmtAct = $this->db->prepare("
                INSERT INTO sistema_actividad (fecha_hora, tipo, titulo, descripcion, estado_accion) 
                VALUES (NOW(), 'servicio', 'AI Alerta: Nuevo Ticket Portal', ?, 'pendiente')
            ");
            $stmtAct->execute(["Cliente ID {$clienteId} (Equipo ID {$equipoId}) abrió reporte. Análisis IA: {$analisisIa}"]);

            $stmtIa = $this->db->prepare("
                INSERT INTO ia_buzon (fecha_proceso, tipo_detectado, datos_json, estado) 
                VALUES (NOW(), 'contador', ?, 'pendiente')
            ");
            $jsonControl = json_encode([
                'tipo' => 'control_servicio_cliente',
                'cliente_id' => $clienteId,
                'equipo_id' => $equipoId,
                'falla_reportada' => $falla,
                'evaluacion_ia' => $analisisIa
            ], JSON_UNESCAPED_UNICODE);
            
            $stmtIa->execute([$jsonControl]);
        }

        return $insertado;
    }

    public function guardarClienteYUsuarioInstitucional(array $data): bool
    {
        // 1. Insertamos el nuevo cliente en la tabla de clientes
        $stmtCli = $this->db->prepare("
            INSERT INTO clientes (nombre, telefono, email, tipo_cliente, activo) 
            VALUES (?, ?, ?, 'Alquiler', 1)
        ");
        $stmtCli->execute([$data['nombre'], $data['telefono'], $data['email']]);
        $clienteId = (int)$this->db->lastInsertId();

        // 2. Creamos el usuario vinculado utilizando correctamente 'linked_cliente_id'
        $stmtUsu = $this->db->prepare("
            INSERT INTO usuarios (usuario, nombre, password, rol, activo, linked_cliente_id) 
            VALUES (?, ?, ?, 'cliente', 1, ?)
        ");
        return $stmtUsu->execute([$data['usuario'], $data['nombre'], $data['password'], $clienteId]);
    }
}