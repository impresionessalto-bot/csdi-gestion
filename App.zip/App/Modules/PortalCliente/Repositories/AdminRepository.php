<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente\Repositories;

use App\Core\BaseRepository;
use RuntimeException;
use Throwable;


final class AdminRepository extends BaseRepository
{


    /**
     * Dashboard portal
     */
    public function totalClientesPortal(): int
    {
        return (int)$this->db
            ->query(
                "SELECT COUNT(*) FROM portal_clientes"
            )
            ->fetchColumn();
    }





    public function clientesActivos(): int
    {
        return (int)$this->db
            ->query(
                "SELECT COUNT(*) 
                 FROM portal_clientes
                 WHERE activo = 1"
            )
            ->fetchColumn();
    }





    public function clientesInactivos(): int
    {
        return (int)$this->db
            ->query(
                "SELECT COUNT(*) 
                 FROM portal_clientes
                 WHERE activo = 0"
            )
            ->fetchColumn();
    }





    /**
     * Clientes con contador visible
     */
    public function clientesConContadores(): int
    {
        return (int)$this->db
            ->query(
                "SELECT COUNT(*) 
                 FROM portal_clientes
                 WHERE mostrar_contadores = 1"
            )
            ->fetchColumn();
    }





    /**
     * Tickets pendientes
     */
    public function ticketsPendientes(): int
    {

        try {

            return (int)$this->db
                ->query(
                    "SELECT COUNT(*)
                     FROM servicios
                     WHERE estado NOT IN ('Finalizado','Cerrado')"
                )
                ->fetchColumn();

        } catch(Throwable){

            return 0;

        }

    }





    /**
     * Listado clientes portal
     */
    public function clientes(): array
    {

        $sql="
            SELECT
                pc.*,
                c.nombre,
                c.email,
                c.telefono
            FROM portal_clientes pc
            INNER JOIN clientes c
                ON c.id = pc.cliente_id
            ORDER BY c.nombre
        ";


        return $this->db
            ->query($sql)
            ->fetchAll(\PDO::FETCH_ASSOC);

    }





    /**
     * Configuración cliente
     */
    public function clientePortal(
        int $clienteId
    ):array|null
    {


        $stmt=$this->db->prepare(
            "
            SELECT
                pc.*,
                c.nombre,
                c.email,
                c.telefono
            FROM portal_clientes pc
            INNER JOIN clientes c
                ON c.id = pc.cliente_id
            WHERE pc.cliente_id = ?
            LIMIT 1
            "
        );


        $stmt->execute([
            $clienteId
        ]);


        $data=$stmt->fetch(
            \PDO::FETCH_ASSOC
        );


        return $data ?: null;

    }





    /**
     * Guardar configuración general
     */
    public function guardarConfiguracion(
        int $clienteId,
        array $data
    ):array
    {


        $stmt=$this->db->prepare(
            "
            UPDATE portal_clientes SET

                activo=?,
                mostrar_contadores=?,
                mostrar_documentos=?,
                mostrar_servicios=?,
                actualizado=NOW()

            WHERE cliente_id=?
            "
        );


        $stmt->execute([

            (int)$data['activo'],
            (int)$data['permite_contadores'],
            (int)$data['permite_documentos'],
            (int)$data['permite_servicios'],
            $clienteId

        ]);



        return [
            'cliente_id'=>$clienteId
        ];

    }





    /**
     * Cambiar estado acceso
     */
    public function cambiarEstado(
        int $clienteId,
        bool $estado
    ):array
    {


        $stmt=$this->db->prepare(
            "
            UPDATE portal_clientes
            SET activo=?,
                actualizado=NOW()
            WHERE cliente_id=?
            "
        );


        $stmt->execute([

            $estado ? 1 : 0,
            $clienteId

        ]);



        return [
            'activo'=>$estado
        ];

    }





    /**
     * Guardar módulos visibles
     */
    public function guardarModulos(
        int $clienteId,
        array $modulos
    ):array
    {


        $sql="
        UPDATE portal_clientes SET

            mostrar_contadores=?,
            mostrar_documentos=?,
            mostrar_servicios=?,
            mostrar_publicidad=?,

            mostrar_informes=?,
            mostrar_facturas=?,
            mostrar_equipos=?,
            mostrar_consumos=?,
            mostrar_marketing=?,

            actualizado=NOW()

        WHERE cliente_id=?
        ";


        $stmt=$this->db->prepare($sql);



        $stmt->execute([

            (int)$modulos['contadores'],
            (int)$modulos['documentos'],
            (int)$modulos['servicio'],
            (int)$modulos['publicidad'],

            1,
            1,
            1,
            1,
            1,

            $clienteId

        ]);



        return [
            'cliente_id'=>$clienteId
        ];

    }





    /**
     * Publicidad
     */
    public function guardarPublicidad(
        int $clienteId,
        array $data
    ):array
    {


        /*
         * Actualmente la tabla controla
         * solamente habilitación.
         *
         * El contenido publicitario
         * lo agregaremos en tabla:
         *
         * portal_publicidad
         *
         */


        $stmt=$this->db->prepare(
            "
            UPDATE portal_clientes
            SET mostrar_publicidad=?,
                actualizado=NOW()
            WHERE cliente_id=?
            "
        );


        $stmt->execute([

            (int)$data['habilitada'],
            $clienteId

        ]);



        return [
            'habilitada'=>
                (bool)$data['habilitada']
        ];

    }





    /**
     * Reset password portal
     */
    public function resetPassword(
        int $clienteId
    ):array
    {


        $password =
            strtoupper(
                substr(
                    md5((string)microtime()),
                    0,
                    8
                )
            );


        $hash=password_hash(
            $password,
            PASSWORD_DEFAULT
        );



        $stmt=$this->db->prepare(
            "
            UPDATE portal_clientes SET

                password=?,
                cambiar_password=1,
                actualizado=NOW()

            WHERE cliente_id=?

            "
        );


        $stmt->execute([

            $hash,
            $clienteId

        ]);



        return [

            'password_temporal'=>$password

        ];

    }





    /**
     * Buscar clientes
     */
    public function buscar(
        string $texto
    ):array
    {


        $stmt=$this->db->prepare(
            "
            SELECT
                pc.*,
                c.nombre
            FROM portal_clientes pc

            INNER JOIN clientes c
                ON c.id=pc.cliente_id

            WHERE c.nombre LIKE ?

            ORDER BY c.nombre

            LIMIT 50
            "
        );


        $stmt->execute([
            '%'.$texto.'%'
        ]);



        return $stmt->fetchAll(
            \PDO::FETCH_ASSOC
        );

    }





    public function totalEquiposPortal(): int
    {

        try{

            return (int)$this->db
                ->query(
                    "SELECT COUNT(*)
                     FROM equipos"
                )
                ->fetchColumn();

        }catch(Throwable){

            return 0;

        }

    }





    public function totalLecturasPortal(): int
    {

        try{

            return (int)$this->db
                ->query(
                    "SELECT COUNT(*)
                     FROM registros"
                )
                ->fetchColumn();

        }catch(Throwable){

            return 0;

        }

    }


}