<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente\Services;

use App\Modules\PortalCliente\Repositories\AdminRepository;
use RuntimeException;
use Throwable;


final class AdminService
{


    public function __construct(
        private readonly AdminRepository $repo
    ) {
    }





    /**
     * Dashboard administración portal
     */
    public function dashboard(): array
    {

        return [

            'clientes' =>
                $this->repo->totalClientesPortal(),

            'activos' =>
                $this->repo->clientesActivos(),

            'inactivos' =>
                $this->repo->clientesInactivos(),

            'contadores' =>
                $this->repo->clientesConContadores(),

            'tickets' =>
                $this->repo->ticketsPendientes(),

        ];

    }





    /**
     * Listado clientes
     */
    public function clientes(): array
    {

        return $this->repo->clientes();

    }





    /**
     * Datos configuración cliente
     */
    public function editar(
        int $clienteId
    ): array
    {

        if($clienteId<=0){

            throw new RuntimeException(
                'Cliente inválido'
            );

        }


        $cliente =
            $this->repo->clientePortal($clienteId);



        if(!$cliente){

            throw new RuntimeException(
                'Cliente no encontrado'
            );

        }



        return $cliente;

    }





    /**
     * Guardar configuración general
     */
    public function guardar(
        array $data
    ): array
    {

        $clienteId =
            (int)($data['cliente_id'] ?? 0);



        if($clienteId<=0){

            throw new RuntimeException(
                'Cliente inválido'
            );

        }



        return $this->repo->guardarConfiguracion(
            $clienteId,
            [

                'activo'=>
                    !empty($data['activo']),

                'permite_contadores'=>
                    !empty($data['permite_contadores']),

                'permite_documentos'=>
                    !empty($data['permite_documentos']),

                'permite_servicios'=>
                    !empty($data['permite_servicios']),

            ]
        );

    }





    /**
     * Cambiar estado portal
     */
    public function cambiarEstado(
        int $clienteId,
        bool $estado
    ): array
    {

        return $this->repo->cambiarEstado(
            $clienteId,
            $estado
        );

    }





    /**
     * Módulos visibles cliente
     */
    public function guardarModulos(
        array $data
    ): array
    {


        $clienteId =
            (int)($data['cliente_id'] ?? 0);



        if($clienteId<=0){

            throw new RuntimeException(
                'Cliente inválido'
            );

        }



        $modulos =
            [

                'contadores'=>
                    !empty($data['modulo_contadores']),

                'documentos'=>
                    !empty($data['modulo_documentos']),

                'servicio'=>
                    !empty($data['modulo_servicio']),

                'publicidad'=>
                    !empty($data['modulo_publicidad']),

            ];



        return $this->repo->guardarModulos(
            $clienteId,
            $modulos
        );

    }





    /**
     * Publicidad portal
     */
    public function guardarPublicidad(
        array $data
    ): array
    {


        $clienteId =
            (int)($data['cliente_id'] ?? 0);



        if($clienteId<=0){

            throw new RuntimeException(
                'Cliente inválido'
            );

        }



        return $this->repo->guardarPublicidad(
            $clienteId,
            [

                'habilitada'=>
                    !empty($data['habilitada']),


                'titulo'=>
                    trim(
                        (string)($data['titulo'] ?? '')
                    ),


                'mensaje'=>
                    trim(
                        (string)($data['mensaje'] ?? '')
                    ),

            ]
        );

    }





    /**
     * Reset contraseña cliente
     */
    public function resetPassword(
        int $clienteId
    ): array
    {


        if($clienteId<=0){

            throw new RuntimeException(
                'Cliente inválido'
            );

        }



        /*
         * El repositorio genera:
         *
         * - contraseña temporal
         * - hash bcrypt
         * - actualización usuario
         *
         */


        return $this->repo->resetPassword(
            $clienteId
        );

    }





    /**
     * Buscador
     */
    public function buscar(
        string $texto
    ): array
    {

        return $this->repo->buscar(
            $texto
        );

    }





    /**
     * Estadísticas generales
     */
    public function estadisticas(): array
    {

        return [

            'clientes'=>
                $this->repo->totalClientesPortal(),


            'equipos'=>
                $this->repo->totalEquiposPortal(),


            'lecturas'=>
                $this->repo->totalLecturasPortal(),


            'tickets'=>
                $this->repo->ticketsPendientes(),


        ];

    }


}