<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente\Services;

use App\Modules\PortalCliente\Repositories\Repository;
use RuntimeException;

final class Service
{
    private Repository $repository;

    public function __construct(Repository $repository)
    {
        $this->repository = $repository;
    }

    public function obtenerDatosDashboard(int $clienteId): array
    {
        $cliente = $this->repository->obtenerCliente($clienteId);
        $equipos = $this->repository->obtenerEquiposCliente($clienteId);
        $movimientos = $this->repository->obtenerMovimientos($clienteId);
        $estadoCuenta = $this->repository->obtenerEstadoCuenta($clienteId);
        $config = $this->repository->obtenerConfiguracion();

        $saldo = 0;
        foreach ($estadoCuenta as $item) {
            $saldo += (float)($item['importe'] ?? 0);
        }

        return [
            'cliente'       => $cliente ?? ['nombre' => 'Cliente'],
            'equipos'       => $equipos,
            'movimientos'   => $movimientos,
            'estado_cuenta' => $estadoCuenta,
            'config'        => $config,
            'saldo'         => $saldo,
            'consumo'       => ['bn' => 1250, 'col' => 340]
        ];
    }

    public function obtenerClienteIdPorUsuario(int $usuarioId): int
    {
        return $this->repository->obtenerClienteIdPorUsuarioId($usuarioId);
    }

    public function registrarContador(array $data): bool
    {
        $equipoId = (int)($data['equipo_id'] ?? 0);
        $bn = (int)($data['lectura_bn'] ?? 0);
        $col = (int)($data['lectura_col'] ?? 0);

        if ($equipoId <= 0 || $bn <= 0) {
            throw new RuntimeException('Datos de contador inválidos.');
        }

        return $this->repository->guardarLecturaContador($equipoId, $bn, $col);
    }

    public function solicitarInsumo(int $equipoId): bool
    {
        if ($equipoId <= 0) {
            throw new RuntimeException('Equipo no válido.');
        }
        return $this->repository->registrarInsumoPedido($equipoId);
    }

    public function abrirTicketConIA(int $clienteId, int $equipoId, string $falla): bool
    {
        if ($clienteId <= 0 || $equipoId <= 0 || trim($falla) === '') {
            throw new RuntimeException('Faltan datos para generar el ticket.');
        }

        $fallaLower = mb_strtolower($falla);
        $analisisIa = "Incidencia reportada por el cliente bajo seguimiento estándar.";
        
        if (str_contains($fallaLower, 'no enciende') || str_contains($fallaLower, 'fuego') || str_contains($fallaLower, 'bloqueo')) {
            $analisisIa = "ALERTA CRÍTICA: Posible fallo de hardware o energía detectado automáticamente.";
        } elseif (str_contains($fallaLower, 'atasco') || str_contains($fallaLower, 'papel')) {
            $analisisIa = "AVISO TÉCNICO: Posible obstrucción en vías de alimentación o rodillos.";
        } elseif (str_contains($fallaLower, 'toner') || str_contains($fallaLower, 'claro')) {
            $analisisIa = "AVISO CONSUMIBLES: Posible agotamiento de toner o calidad de impresión.";
        }

        return $this->repository->crearTicketFallaConIA($clienteId, $equipoId, trim($falla), $analisisIa);
    }

    public function registrarNuevoClienteInstitucional(array $data): bool
    {
        $nombre = trim($data['nombre'] ?? '');
        $usuario = trim($data['usuario'] ?? '');
        $password = $data['password'] ?? '';
        $telefono = trim($data['telefono'] ?? '');
        $email = trim($data['email'] ?? '');

        if ($nombre === '' || $usuario === '' || $password === '') {
            throw new RuntimeException('Por favor, complete los campos obligatorios.');
        }

        return $this->repository->guardarClienteYUsuarioInstitucional([
            'nombre'   => $nombre,
            'usuario'  => $usuario,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'telefono' => $telefono,
            'email'    => $email
        ]);
    }
}