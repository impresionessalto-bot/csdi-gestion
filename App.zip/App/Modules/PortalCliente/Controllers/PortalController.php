<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente\Controllers;

use App\Core\BaseController;
use App\Modules\PortalCliente\Services\Service;
use Throwable;
use RuntimeException;

final class PortalController extends BaseController
{
    public function __construct(
        private readonly Service $service
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | DASHBOARD CLIENTE
    |--------------------------------------------------------------------------
    */
    public function index(): void
    {
        $this->requireAuth();

        try {
            $clienteId = $this->clienteActual();

            $this->view(
                'portal/dashboard',
                [
                    'titulo' => 'Mi Portal CSDI',
                    'data' => $this->service->obtenerDatosDashboard($clienteId),
                    'csrf' => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PERFIL
    |--------------------------------------------------------------------------
    */
    public function perfil(): void
    {
        $this->requireAuth();

        try {
            $this->view(
                'portal/perfil',
                [
                    'cliente' => $this->service->obtenerDatosDashboard($this->clienteActual()),
                    'csrf' => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function actualizarPerfil(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf($_POST['csrf'] ?? null);

            $this->success(
                true,
                'Perfil actualizado'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | EQUIPOS
    |--------------------------------------------------------------------------
    */
    public function equipos(): void
    {
        $this->requireAuth();

        try {
            $data = $this->service->obtenerDatosDashboard($this->clienteActual());
            $this->success($data['equipos'] ?? []);
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CONTADORES
    |--------------------------------------------------------------------------
    */
    public function contadores(): void
    {
        $this->requireAuth();

        try {
            $this->view(
                'portal/contadores',
                [
                    'contador' => $this->service->obtenerDatosDashboard($this->clienteActual()),
                    'csrf' => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function guardarContador(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf($_POST['csrf'] ?? null);

            $this->success(
                $this->service->registrarContador($_POST),
                'Contador registrado'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DOCUMENTOS
    |--------------------------------------------------------------------------
    */
    public function documentos(): void
    {
        $this->requireAuth();

        try {
            $data = $this->service->obtenerDatosDashboard($this->clienteActual());
            $this->view(
                'portal/documentos',
                [
                    'documentos' => $data['estado_cuenta'] ?? []
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | TICKETS
    |--------------------------------------------------------------------------
    */
    public function tickets(): void
    {
        $this->requireAuth();

        try {
            $data = $this->service->obtenerDatosDashboard($this->clienteActual());
            $this->view(
                'portal/tickets',
                [
                    'tickets' => $data['movimientos'] ?? [],
                    'csrf' => $this->csrf()
                ]
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    public function crearTicket(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf($_POST['csrf'] ?? null);

            $clienteId = $this->clienteActual();
            $equipoId = (int)($_POST['equipo_id'] ?? 0);
            $falla = (string)($_POST['falla'] ?? '');

            $this->success(
                $this->service->abrirTicketConIA($clienteId, $equipoId, $falla),
                'Solicitud enviada'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | INSUMOS
    |--------------------------------------------------------------------------
    */
    public function solicitarInsumo(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf($_POST['csrf'] ?? null);

            $equipoId = (int)($_POST['equipo_id'] ?? 0);

            $this->success(
                $this->service->solicitarInsumo($equipoId),
                'Solicitud enviada'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | SEGURIDAD
    |--------------------------------------------------------------------------
    */
    public function cambiarPassword(): void
    {
        $this->requireAuth();

        try {
            $this->validateCsrf($_POST['csrf'] ?? null);

            $this->success(
                true,
                'Contraseña actualizada'
            );
        } catch (Throwable $e) {
            $this->fail($e);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTE ACTUAL
    |--------------------------------------------------------------------------
    */
    private function clienteActual(): int
    {
        $clienteId = (int)(
            $_SESSION['cliente_id']
            ?? $_SESSION['linked_cliente_id']
            ?? 0
        );

        if ($clienteId <= 0) {
            throw new RuntimeException(
                'Usuario sin cliente asociado'
            );
        }

        return $clienteId;
    }
}