<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente\Controllers;

use App\Core\BaseController;
use App\Modules\PortalCliente\Services\AdminService;
use RuntimeException;
use Throwable;


final class AdminController extends BaseController
{


    public function __construct(
        private readonly AdminService $service
    ) {
    }





    /**
     * Dashboard administración portal
     */
    public function index(): void
    {
        $this->requireAdmin();

        try {

            $this->view(
                'admin/index',
                [
                    'titulo'=>'Administración Portal Clientes',
                    'data'=>$this->service->dashboard(),
                    'csrf'=>$this->csrf()
                ]
            );


        } catch(Throwable $e){

            $this->fail($e);

        }
    }





    /**
     * Listado clientes habilitados
     */
    public function clientes(): void
    {
        $this->requireAdmin();

        try {

            $this->view(
                'admin/clientes',
                [
                    'titulo'=>'Clientes Portal',
                    'clientes'=>$this->service->clientes(),
                    'csrf'=>$this->csrf()
                ]
            );


        }catch(Throwable $e){

            $this->fail($e);

        }
    }





    /**
     * Editar configuración cliente
     */
    public function editar(
        int|string $id
    ): void
    {

        $this->requireAdmin();


        try {


            $clienteId=(int)$id;


            if($clienteId<=0){

                throw new RuntimeException(
                    'Cliente inválido'
                );

            }



            $this->view(
                'admin/edit',
                [
                    'titulo'=>'Configuración Portal Cliente',
                    'cliente'=>$this->service->editar($clienteId),
                    'csrf'=>$this->csrf()
                ]
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Guardar configuración general
     */
    public function guardar(
        int|string $id
    ): void
    {

        $this->requireAdmin();


        try {


            $this->validateCsrf(
                $_POST['csrf'] ?? null
            );


            $_POST['cliente_id']=(int)$id;


            $this->success(
                $this->service->guardar($_POST),
                'Configuración guardada'
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Activar / desactivar portal
     */
    public function estado(
        int|string $id
    ): void
    {

        $this->requireAdmin();


        try {


            $this->validateCsrf(
                $_POST['csrf'] ?? null
            );


            $clienteId=(int)$id;


            if($clienteId<=0){

                throw new RuntimeException(
                    'Cliente inválido'
                );

            }


            $estado =
                (bool)($_POST['activo'] ?? false);



            $this->success(
                $this->service->cambiarEstado(
                    $clienteId,
                    $estado
                ),
                'Estado actualizado'
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Módulos visibles cliente
     */
    public function guardarModulos(): void
    {

        $this->requireAdmin();


        try {


            $this->validateCsrf(
                $_POST['csrf'] ?? null
            );


            $this->success(
                $this->service->guardarModulos($_POST),
                'Módulos actualizados'
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Publicidad portal
     */
    public function guardarPublicidad(): void
    {

        $this->requireAdmin();


        try {


            $this->validateCsrf(
                $_POST['csrf'] ?? null
            );


            $this->success(
                $this->service->guardarPublicidad($_POST),
                'Publicidad actualizada'
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Reset contraseña cliente
     */
    public function resetPassword(
        int|string $id
    ): void
    {

        $this->requireAdmin();


        try {


            $this->validateCsrf(
                $_POST['csrf'] ?? null
            );


            $clienteId=(int)$id;


            if($clienteId<=0){

                throw new RuntimeException(
                    'Cliente inválido'
                );

            }



            $this->success(
                $this->service->resetPassword($clienteId),
                'Contraseña regenerada'
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Buscador AJAX
     */
    public function buscarClientes(): void
    {

        $this->requireAdmin();


        try {


            $q=trim(
                (string)($_GET['q'] ?? '')
            );


            $this->success(
                $this->service->buscar($q)
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    /**
     * Estadísticas
     */
    public function estadisticas(): void
    {

        $this->requireAdmin();


        try {


            $this->success(
                $this->service->estadisticas()
            );


        }catch(Throwable $e){

            $this->fail($e);

        }

    }





    private function requireAdmin(): void
    {

        $this->requireAuth();


        $rol =
            $_SESSION['user']['rol']
            ??
            $_SESSION['rol']
            ??
            '';



        if($rol !== 'admin'){

            throw new RuntimeException(
                'Acceso restringido'
            );

        }

    }


}