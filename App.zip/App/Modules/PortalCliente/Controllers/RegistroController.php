<?php

declare(strict_types=1);

namespace App\Modules\PortalCliente\Controllers;

use App\Core\BaseController;
use App\Modules\PortalCliente\Services\PortalService;
use RuntimeException;
use Throwable;

final class RegistroController extends BaseController
{
    public function __construct(
        private readonly PortalService $service
    ) {
        parent::__construct();
    }

    /*
    |--------------------------------------------------------------------------
    | FORMULARIO DE REGISTRO
    |--------------------------------------------------------------------------
    */

    public function index(): void
    {
        try {

            $this->moduleView(
                'PortalCliente',
                'registro/index',
                [
                    'titulo' => 'Registro Portal Cliente',
                    'csrf'   => $this->csrf()
                ]
            );

        } catch (Throwable $e) {

            $this->fail($e);

        }
    }

    /*
    |--------------------------------------------------------------------------
    | PROCESAR REGISTRO
    |--------------------------------------------------------------------------
    */

    public function guardar(): void
    {
        try {

            if (!$this->validateCsrf()) {
                throw new RuntimeException(
                    'Token CSRF inválido.'
                );
            }

            $this->service->registrarNuevoClienteInstitucional(
                $_POST
            );

            $this->redirect(
                '/portal/login?registrado=1'
            );

        } catch (Throwable $e) {

            $this->moduleView(
                'PortalCliente',
                'registro/index',
                [
                    'titulo' => 'Registro Portal Cliente',
                    'csrf'   => $this->csrf(),
                    'error'  => $e->getMessage(),
                    'old'    => $_POST
                ]
            );

        }
    }
}