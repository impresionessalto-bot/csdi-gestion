<?php

declare(strict_types=1);

use App\Core\Router;

Router::group(
    '/portal-cliente',
    ['auth'],
    function (): void {
        Router::get(
            '',
            'PortalCliente\\Controllers\\PortalController@index'
        );

        Router::get(
            '/perfil',
            'PortalCliente\\Controllers\\PortalController@perfil'
        );

        Router::post(
            '/contador',
            'PortalCliente\\Controllers\\PortalController@guardarContador'
        );

        Router::post(
            '/ticket',
            'PortalCliente\\Controllers\\PortalController@crearTicket'
        );

        Router::post(
            '/insumo',
            'PortalCliente\\Controllers\\PortalController@solicitarInsumo'
        );

        Router::get(
            '/documentos',
            'PortalCliente\\Controllers\\PortalController@documentos'
        );
    }
);

Router::group(
    '/portal-cliente/admin',
    ['auth', 'admin'],
    function (): void {
        Router::get(
            '',
            'PortalCliente\\Controllers\\AdminController@index'
        );

        Router::get(
            '/editar/{id}',
            'PortalCliente\\Controllers\\AdminController@editar'
        );

        Router::post(
            '/guardar/{id}',
            'PortalCliente\\Controllers\\AdminController@guardar'
        );

        Router::post(
            '/estado/{id}',
            'PortalCliente\\Controllers\\AdminController@estado'
        );

        Router::post(
            '/password/{id}',
            'PortalCliente\\Controllers\\AdminController@resetPassword'
        );
    }
);