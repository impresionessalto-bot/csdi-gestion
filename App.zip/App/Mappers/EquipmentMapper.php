<?php

declare(strict_types=1);

namespace App\Mappers;

final class EquipmentMapper
{
    /**
     * DB → VIEW MODEL (lo que usa la UI)
     */
    public static function toView(array $row): array
    {
        return [
            'id' => $row['id'] ?? null,

            // 🔥 UNIFICACIÓN REAL DEL ERP
            'nombre' => self::buildNombre($row),

            'serie' => $row['numero_serie'] ?? '',

            'tipo' => $row['tipo'] ?? '',

            'estado' => $row['estado'] ?? 'Activo',

            'cliente_id' => $row['cliente_id'] ?? null,
        ];
    }

    /**
     * LISTA COMPLETA
     */
    public static function toViewList(array $rows): array
    {
        $out = [];

        foreach ($rows as $row) {
            $out[] = self::toView($row);
        }

        return $out;
    }

    /**
     * Construcción inteligente de nombre ERP
     */
    private static function buildNombre(array $row): string
    {
        $marca = $row['marca'] ?? '';
        $modelo = $row['modelo'] ?? '';

        $nombre = trim($marca . ' ' . $modelo);

        return $nombre !== '' ? $nombre : 'Sin nombre';
    }

    /**
     * VIEW → DB (para alta/edición)
     */
    public static function toDatabase(array $data): array
    {
        return [
            'marca' => $data['marca'] ?? '',
            'modelo' => $data['modelo'] ?? '',
            'numero_serie' => $data['serie'] ?? '',
            'tipo' => $data['tipo'] ?? '',
            'cliente_id' => $data['cliente_id'] ?? null,
        ];
    }
}