<?php

declare(strict_types=1);

namespace App\DTO;

final class EquipmentDTO
{
    public function __construct(
        public string $marca,
        public string $modelo,
        public string $numeroSerie,
        public string $tipo,
        public ?int $clienteId = null
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            marca: $data['marca'] ?? '',
            modelo: $data['modelo'] ?? '',
            numeroSerie: $data['numero_serie'] ?? '',
            tipo: $data['tipo'] ?? '',
            clienteId: $data['cliente_id'] ?? null
        );
    }

    public function toArray(): array
    {
        return [
            'marca' => $this->marca,
            'modelo' => $this->modelo,
            'numero_serie' => $this->numeroSerie,
            'tipo' => $this->tipo,
            'cliente_id' => $this->clienteId,
        ];
    }

    public function nombreCompleto(): string
    {
        return trim($this->marca . ' ' . $this->modelo);
    }
}