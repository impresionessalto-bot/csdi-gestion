<?php
declare(strict_types=1);

$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

$isActive = static function (string $path) use ($currentPath): bool {
    if ($path === '/') {
        return $currentPath === '/';
    }

    return $currentPath === $path || str_starts_with($currentPath, $path . '/');
};

$isSectionOpen = static function (array $paths) use ($currentPath): bool {
    foreach ($paths as $path) {
        if ($path === '/') {
            if ($currentPath === '/') {
                return true;
            }

            continue;
        }

        if ($currentPath === $path || str_starts_with($currentPath, $path . '/')) {
            return true;
        }
    }

    return false;
};
?>

<aside id="csdiSidebar" class="csdi-sidebar">

    <!-- =========================================================
         BRAND
    ========================================================== -->
    <div class="csdi-brand">
        <a href="/dashboard" class="csdi-brand-link">
            <span class="csdi-brand-mark">
                <i class="bi bi-grid-1x2-fill"></i>
            </span>

            <span class="csdi-brand-text">
                <strong>CSDI</strong>
                <small>ERP PRO</small>
            </span>
        </a>
    </div>


    <!-- =========================================================
         NAVEGACIÓN
    ========================================================== -->
    <nav class="csdi-nav">

        <!-- DASHBOARD -->
        <a href="/dashboard"
           class="csdi-nav-link <?= $isActive('/dashboard') ? 'active' : '' ?>">
            <i class="bi bi-speedometer2"></i>
            <span>Dashboard</span>
        </a>


        <!-- =====================================================
             VENTAS
        ====================================================== -->
        <?php
        $ventasOpen = $isSectionOpen([
            '/ventas',
            '/facturacion'
        ]);
        ?>

        <div class="csdi-nav-section <?= $ventasOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/ventas"
                   class="csdi-nav-link <?= $isActive('/ventas') ? 'active' : '' ?>">
                    <i class="bi bi-cart3"></i>
                    <span>Ventas</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Ventas"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/ventas"
                   class="<?= $currentPath === '/ventas' ? 'active' : '' ?>">
                    Resumen
                </a>

                <a href="/ventas/nueva"
                   class="<?= $isActive('/ventas/nueva') ? 'active' : '' ?>">
                    Nueva venta
                </a>

                <a href="/ventas/listado"
                   class="<?= $isActive('/ventas/listado') ? 'active' : '' ?>">
                    Listado de ventas
                </a>

                <a href="/ventas/presupuestos"
                   class="<?= $isActive('/ventas/presupuestos') ? 'active' : '' ?>">
                    Presupuestos
                </a>

                <a href="/ventas/pedidos"
                   class="<?= $isActive('/ventas/pedidos') ? 'active' : '' ?>">
                    Pedidos
                </a>

                <a href="/ventas/remitos"
                   class="<?= $isActive('/ventas/remitos') ? 'active' : '' ?>">
                    Remitos
                </a>

                <a href="/facturacion"
                   class="<?= $isActive('/facturacion') ? 'active' : '' ?>">
                    Facturación
                </a>

            </div>
        </div>


        <!-- =====================================================
             COMPRAS
        ====================================================== -->
        <?php
        $comprasOpen = $isSectionOpen([
            '/compras',
            '/proveedores'
        ]);
        ?>

        <div class="csdi-nav-section <?= $comprasOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/compras"
                   class="csdi-nav-link <?= $isActive('/compras') ? 'active' : '' ?>">
                    <i class="bi bi-bag-check"></i>
                    <span>Compras</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Compras"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/compras"
                   class="<?= $currentPath === '/compras' ? 'active' : '' ?>">
                    Resumen
                </a>

                <a href="/compras/nueva"
                   class="<?= $isActive('/compras/nueva') ? 'active' : '' ?>">
                    Nueva compra
                </a>

                <a href="/compras/listado"
                   class="<?= $isActive('/compras/listado') ? 'active' : '' ?>">
                    Listado de compras
                </a>

                <a href="/compras/ordenes"
                   class="<?= $isActive('/compras/ordenes') ? 'active' : '' ?>">
                    Órdenes de compra
                </a>

                <a href="/compras/remitos"
                   class="<?= $isActive('/compras/remitos') ? 'active' : '' ?>">
                    Remitos
                </a>

                <a href="/proveedores"
                   class="<?= $isActive('/proveedores') ? 'active' : '' ?>">
                    Proveedores
                </a>

            </div>
        </div>


        <!-- =====================================================
             PRODUCTOS / STOCK
        ====================================================== -->
        <?php
        $inventarioOpen = $isSectionOpen([
            '/inventario'
        ]);
        ?>

        <div class="csdi-nav-section <?= $inventarioOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/inventario"
                   class="csdi-nav-link <?= $isActive('/inventario') ? 'active' : '' ?>">
                    <i class="bi bi-box-seam"></i>
                    <span>Productos / Stock</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Productos / Stock"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/inventario"
                   class="<?= $currentPath === '/inventario' ? 'active' : '' ?>">
                    Resumen
                </a>

                <a href="/inventario/nuevo"
                   class="<?= $isActive('/inventario/nuevo') ? 'active' : '' ?>">
                    Nuevo producto
                </a>

                <a href="/inventario/categorias"
                   class="<?= $isActive('/inventario/categorias') ? 'active' : '' ?>">
                    Categorías
                </a>

                <a href="/inventario/marcas"
                   class="<?= $isActive('/inventario/marcas') ? 'active' : '' ?>">
                    Marcas
                </a>

                <a href="/inventario/stock"
                   class="<?= $isActive('/inventario/stock') ? 'active' : '' ?>">
                    Stock
                </a>

                <a href="/inventario/movimientos"
                   class="<?= $isActive('/inventario/movimientos') ? 'active' : '' ?>">
                    Movimientos
                </a>

                <a href="/inventario/ajustes"
                   class="<?= $isActive('/inventario/ajustes') ? 'active' : '' ?>">
                    Ajustes
                </a>

                <a href="/inventario/inventario"
                   class="<?= $isActive('/inventario/inventario') ? 'active' : '' ?>">
                    Inventario
                </a>

            </div>
        </div>


        <!-- =====================================================
             SERVICIO TÉCNICO
        ====================================================== -->
        <?php
        $servicioOpen = $isSectionOpen([
            '/servicios'
        ]);
        ?>

        <div class="csdi-nav-section <?= $servicioOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/servicios"
                   class="csdi-nav-link <?= $isActive('/servicios') ? 'active' : '' ?>">
                    <i class="bi bi-tools"></i>
                    <span>Servicio Técnico</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Servicio Técnico"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/servicios"
                   class="<?= $currentPath === '/servicios' ? 'active' : '' ?>">
                    Resumen
                </a>

                <a href="/servicios/nuevo"
                   class="<?= $isActive('/servicios/nuevo') ? 'active' : '' ?>">
                    Nuevo servicio técnico
                </a>

                <a href="/servicios/historial"
                   class="<?= $isActive('/servicios/historial') ? 'active' : '' ?>">
                    Listado de servicios
                </a>

                <a href="/facturacion"
                   class="<?= $isActive('/facturacion') ? 'active' : '' ?>">
                    Facturación
                </a>

                <a href="/servicios/buscar-equipo"
                   class="<?= $isActive('/servicios/buscar-equipo') ? 'active' : '' ?>">
                    <i class="bi bi-qr-code me-1"></i>
                    Buscar equipo
                </a>

            </div>
        </div>


        <!-- =====================================================
             DOCUMENTOS
        ====================================================== -->
        <?php
        $documentosOpen = $isSectionOpen([
            '/documentos-ia'
        ]);
        ?>

        <div class="csdi-nav-section <?= $documentosOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/documentos-ia"
                   class="csdi-nav-link <?= $isActive('/documentos-ia') ? 'active' : '' ?>">
                    <i class="bi bi-file-earmark-text"></i>
                    <span>Documentos</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Documentos"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/documentos-ia"
                   class="<?= $currentPath === '/documentos-ia' ? 'active' : '' ?>">
                    Resumen
                </a>

                <a href="/documentos-ia/subir"
                   class="<?= $isActive('/documentos-ia/subir') ? 'active' : '' ?>">
                    Subir documento
                </a>

                <a href="/documentos-ia?estado=PENDIENTE"
                   class="<?= $currentPath === '/documentos-ia' && ($_GET['estado'] ?? '') === 'PENDIENTE' ? 'active' : '' ?>">
                    Pendientes
                </a>

                <a href="/documentos-ia?estado=PROCESADO"
                   class="<?= $currentPath === '/documentos-ia' && ($_GET['estado'] ?? '') === 'PROCESADO' ? 'active' : '' ?>">
                    Procesados
                </a>

            </div>
        </div>


        <!-- FINANZAS -->
        <a href="/finanzas"
           class="csdi-nav-link <?= $isActive('/finanzas') ? 'active' : '' ?>">
            <i class="bi bi-cash-stack"></i>
            <span>Finanzas</span>
        </a>


        <!-- =====================================================
             BASE DE DATOS
        ====================================================== -->
        <?php
        $baseDatosOpen = $isSectionOpen([
            '/clientes',
            '/equipos',
            '/modelos-equipos',
            '/proveedores',
            '/localidades',
            '/tarifas',
            '/tecnicos'
        ]);
        ?>

        <div class="csdi-nav-section <?= $baseDatosOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/clientes"
                   class="csdi-nav-link <?= $isActive('/clientes') ? 'active' : '' ?>">
                    <i class="bi bi-database"></i>
                    <span>Base de datos</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Base de datos"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/clientes"
                   class="<?= $isActive('/clientes') ? 'active' : '' ?>">
                    Clientes
                </a>

                <a href="/equipos"
                   class="<?= $isActive('/equipos') ? 'active' : '' ?>">
                    Equipos
                </a>

                <a href="/modelos-equipos"
                   class="<?= $isActive('/modelos-equipos') ? 'active' : '' ?>">
                    Modelos de equipos
                </a>

                <a href="/proveedores"
                   class="<?= $isActive('/proveedores') ? 'active' : '' ?>">
                    Proveedores
                </a>

                <a href="/localidades"
                   class="<?= $isActive('/localidades') ? 'active' : '' ?>">
                    Localidades
                </a>

                <a href="/tarifas"
                   class="<?= $isActive('/tarifas') ? 'active' : '' ?>">
                    Tarifas
                </a>

                <a href="/tecnicos"
                   class="<?= $isActive('/tecnicos') ? 'active' : '' ?>">
                    Técnicos
                </a>

            </div>
        </div>


        <!-- REPORTES -->
        <a href="/reportes"
           class="csdi-nav-link <?= $isActive('/reportes') ? 'active' : '' ?>">
            <i class="bi bi-bar-chart-line"></i>
            <span>Reportes</span>
        </a>


        <!-- =====================================================
             CONFIGURACIÓN
        ====================================================== -->
        <?php
        $configOpen = $isSectionOpen([
            '/configuracion',
            '/admin/usuarios',
            '/admin/roles'
        ]);
        ?>

        <div class="csdi-nav-section <?= $configOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/configuracion"
                   class="csdi-nav-link <?= $isActive('/configuracion') ? 'active' : '' ?>">
                    <i class="bi bi-gear"></i>
                    <span>Configuración</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Configuración"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/configuracion"
                   class="<?= $currentPath === '/configuracion' ? 'active' : '' ?>">
                    Configuración general
                </a>

                <a href="/admin/usuarios"
                   class="<?= $isActive('/admin/usuarios') ? 'active' : '' ?>">
                    Usuarios
                </a>

                <a href="/admin/roles"
                   class="<?= $isActive('/admin/roles') ? 'active' : '' ?>">
                    Roles y permisos
                </a>

            </div>
        </div>


        <!-- =====================================================
             HERRAMIENTAS
        ====================================================== -->
        <?php
        $herramientasOpen = $isSectionOpen([
            '/admin/database',
            '/admin/cache',
            '/admin/debug',
            '/admin/logs',
            '/herramientas'
        ]);
        ?>

        <div class="csdi-nav-section <?= $herramientasOpen ? 'open' : '' ?>">

            <div class="csdi-nav-header">

                <a href="/herramientas"
                   class="csdi-nav-link <?= $isActive('/herramientas') ? 'active' : '' ?>">
                    <i class="bi bi-wrench-adjustable"></i>
                    <span>Herramientas</span>
                </a>

                <button type="button"
                        class="csdi-nav-toggle"
                        data-nav-toggle
                        aria-label="Mostrar u ocultar Herramientas"
                        title="Mostrar u ocultar">
                    <i class="bi bi-chevron-down csdi-chevron"></i>
                </button>

            </div>

            <div class="csdi-subnav">

                <a href="/admin/database"
                   class="<?= $isActive('/admin/database') ? 'active' : '' ?>">
                    Base de datos
                </a>

                <a href="/admin/cache"
                   class="<?= $isActive('/admin/cache') ? 'active' : '' ?>">
                    Caché
                </a>

                <a href="/admin/debug"
                   class="<?= $isActive('/admin/debug') ? 'active' : '' ?>">
                    Debug
                </a>

                <a href="/admin/logs"
                   class="<?= $isActive('/admin/logs') ? 'active' : '' ?>">
                    Logs
                </a>

                <a href="/herramientas"
                   class="<?= $currentPath === '/herramientas' ? 'active' : '' ?>">
                    Herramientas
                </a>

            </div>
        </div>

    </nav>


    <!-- =========================================================
         FOOTER SIDEBAR
    ========================================================== -->
    <div class="csdi-sidebar-footer">

        <button type="button"
                class="csdi-collapse-btn"
                data-sidebar-collapse
                title="Contraer menú">

            <i class="bi bi-layout-sidebar-inset"></i>

            <span>Contraer menú</span>

        </button>

    </div>

</aside>