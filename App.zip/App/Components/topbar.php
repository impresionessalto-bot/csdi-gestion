<?php
declare(strict_types=1);

$user = [];

try {
    if (class_exists(\App\Core\Auth::class)) {
        $authUser = \App\Core\Auth::user();

        if (is_array($authUser)) {
            $user = $authUser;
        }
    }
} catch (\Throwable $e) {
    $user = [];
}

$currentUserId = (int) (
    $user['id']
    ?? $_SESSION['usuario_id']
    ?? 0
);

$userName = trim((string) (
    $user['nombre']
    ?? $user['name']
    ?? $user['usuario']
    ?? $_SESSION['usuario_nombre']
    ?? 'Usuario'
));

$userEmail = trim((string) (
    $user['email']
    ?? $_SESSION['usuario_email']
    ?? ''
));

$userRole = trim((string) (
    $user['rol']
    ?? $user['role']
    ?? $_SESSION['rol']
    ?? ''
));

$initial = strtoupper(
    function_exists('mb_substr')
        ? mb_substr($userName, 0, 1)
        : substr($userName, 0, 1)
);

if ($initial === '') {
    $initial = 'U';
}
?>

<header class="csdi-topbar">

    <!-- =====================================================
         BUSCADOR
    ====================================================== -->
    <div class="csdi-topbar-search">

        <div class="csdi-search-wrapper">

            <i class="bi bi-search csdi-search-icon"></i>

            <input
                type="search"
                id="globalSearch"
                class="csdi-global-search"
                placeholder="Buscar..."
                autocomplete="off"
            >

            <span class="csdi-search-shortcut">
                Ctrl K
            </span>

        </div>

    </div>


    <!-- =====================================================
         ACCIONES
    ====================================================== -->
    <div class="csdi-topbar-actions">

        <!-- NOTIFICACIONES -->
        <button
            type="button"
            class="csdi-topbar-icon"
            title="Notificaciones"
            aria-label="Notificaciones"
        >
            <i class="bi bi-bell"></i>
        </button>


        <!-- AYUDA -->
        <button
            type="button"
            class="csdi-topbar-icon"
            title="Ayuda"
            aria-label="Ayuda"
        >
            <i class="bi bi-question-circle"></i>
        </button>


        <!-- USUARIO -->
        <div class="dropdown">

            <button
                type="button"
                class="csdi-user csdi-user-button"
                data-bs-toggle="dropdown"
                data-bs-auto-close="true"
                aria-expanded="false"
            >

                <span class="csdi-user-avatar">
                    <?= htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') ?>
                </span>

                <span class="csdi-user-info">

                    <strong>
                        <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?>
                    </strong>

                    <?php if ($userRole !== ''): ?>
                        <small>
                            <?= htmlspecialchars($userRole, ENT_QUOTES, 'UTF-8') ?>
                        </small>
                    <?php elseif ($userEmail !== ''): ?>
                        <small>
                            <?= htmlspecialchars($userEmail, ENT_QUOTES, 'UTF-8') ?>
                        </small>
                    <?php endif; ?>

                </span>

                <i class="bi bi-chevron-down csdi-user-chevron"></i>

            </button>


            <!-- =================================================
                 DROPDOWN USUARIO
            ================================================== -->
            <div class="dropdown-menu dropdown-menu-end shadow border-0 csdi-user-menu">

                <div class="csdi-user-menu-header">

                    <span class="csdi-user-avatar csdi-user-avatar-large">
                        <?= htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') ?>
                    </span>

                    <div>

                        <strong>
                            <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?>
                        </strong>

                        <?php if ($userEmail !== ''): ?>
                            <small>
                                <?= htmlspecialchars($userEmail, ENT_QUOTES, 'UTF-8') ?>
                            </small>
                        <?php endif; ?>

                    </div>

                </div>


                <div class="dropdown-divider"></div>


                <?php if ($currentUserId > 0): ?>

                    <!-- MI USUARIO -->
                    <a
                        href="/admin/usuarios/editar/<?= $currentUserId ?>"
                        class="dropdown-item py-2"
                    >
                        <i class="bi bi-person me-2"></i>
                        Mi usuario
                    </a>


                    <!-- PERMISOS -->
                    <a
                        href="/admin/usuarios/permisos/<?= $currentUserId ?>"
                        class="dropdown-item py-2"
                    >
                        <i class="bi bi-shield-lock me-2"></i>
                        Permisos
                    </a>

                <?php endif; ?>


                <div class="dropdown-divider"></div>


                <!-- CERRAR SESIÓN -->
                <a
                    href="/logout"
                    class="dropdown-item py-2 text-danger"
                >
                    <i class="bi bi-box-arrow-right me-2"></i>
                    Cerrar sesión
                </a>

            </div>

        </div>

    </div>

</header>


<style>
/* ============================================================
   TOPBAR
============================================================ */

.csdi-topbar {
    min-height: 64px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 10px 18px;

    background: #fff;

    border-bottom: 1px solid #e6eaf0;

    position: relative;

    z-index: 1020;
}


/* ============================================================
   SEARCH
============================================================ */

.csdi-topbar-search {
    flex: 1 1 auto;

    max-width: 520px;
}

.csdi-search-wrapper {
    position: relative;

    display: flex;
    align-items: center;
}

.csdi-search-icon {
    position: absolute;
    left: 13px;

    color: #8996a5;

    font-size: 15px;

    pointer-events: none;
}

.csdi-global-search {
    width: 100%;

    height: 40px;

    padding: 8px 72px 8px 38px;

    border: 1px solid #e6eaf0;
    border-radius: 8px;

    background: #f8fafc;

    color: #18212b;

    font-size: 14px;

    outline: none;

    transition:
        border-color .15s ease,
        background .15s ease,
        box-shadow .15s ease;
}

.csdi-global-search:focus {
    background: #fff;

    border-color: #2f6fed;

    box-shadow:
        0 0 0 3px rgba(47,111,237,.10);
}

.csdi-search-shortcut {
    position: absolute;

    right: 10px;

    padding: 3px 7px;

    border: 1px solid #dfe4ea;
    border-radius: 5px;

    background: #fff;

    color: #8996a5;

    font-size: 10px;
}


/* ============================================================
   ACTIONS
============================================================ */

.csdi-topbar-actions {
    display: flex;
    align-items: center;

    gap: 6px;
}

.csdi-topbar-icon {
    width: 38px;
    height: 38px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 0;
    border-radius: 8px;

    background: transparent;

    color: #596675;

    cursor: pointer;

    font-size: 17px;

    transition:
        background .15s ease,
        color .15s ease;
}

.csdi-topbar-icon:hover {
    background: #f1f4f8;
    color: #18212b;
}


/* ============================================================
   USER BUTTON
============================================================ */

.csdi-user-button {
    min-height: 42px;

    display: flex;
    align-items: center;

    gap: 9px;

    padding: 4px 7px 4px 5px;

    border: 0;
    border-radius: 8px;

    background: transparent;

    cursor: pointer;
}

.csdi-user-button:hover {
    background: #f1f4f8;
}

.csdi-user-button:focus {
    outline: none;
}

.csdi-user-avatar {
    width: 34px;
    height: 34px;

    flex: 0 0 34px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: #2f6fed;

    color: #fff;

    font-size: 13px;
    font-weight: 700;
}

.csdi-user-info {
    min-width: 0;

    display: flex;
    flex-direction: column;

    align-items: flex-start;
}

.csdi-user-info strong {
    max-width: 150px;

    overflow: hidden;

    text-overflow: ellipsis;
    white-space: nowrap;

    color: #18212b;

    font-size: 13px;
    line-height: 16px;
}

.csdi-user-info small {
    color: #8996a5;

    font-size: 11px;
    line-height: 14px;
}

.csdi-user-chevron {
    margin-left: 2px;

    color: #8996a5;

    font-size: 10px;
}


/* ============================================================
   USER MENU
============================================================ */

.csdi-user-menu {
    min-width: 250px;

    margin-top: 7px;

    padding: 7px;
}

.csdi-user-menu-header {
    display: flex;
    align-items: center;

    gap: 10px;

    padding: 8px;
}

.csdi-user-avatar-large {
    width: 40px;
    height: 40px;

    flex: 0 0 40px;
}

.csdi-user-menu-header > div {
    min-width: 0;

    display: flex;
    flex-direction: column;
}

.csdi-user-menu-header strong {
    color: #18212b;

    font-size: 13px;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.csdi-user-menu-header small {
    margin-top: 2px;

    color: #8996a5;

    font-size: 11px;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.csdi-user-menu .dropdown-item {
    border-radius: 6px;

    font-size: 13px;
}

.csdi-user-menu .dropdown-item:hover {
    background: #f1f4f8;
}

.csdi-user-menu .dropdown-item i {
    width: 18px;
    text-align: center;
}


/* ============================================================
   RESPONSIVE
============================================================ */

@media (max-width: 767.98px) {

    .csdi-topbar {
        padding: 9px 12px;
    }

    .csdi-topbar-search {
        max-width: none;

        margin-right: 8px;
    }

    .csdi-user-info,
    .csdi-user-chevron {
        display: none;
    }

    .csdi-user-button {
        padding-right: 2px;
    }

    .csdi-search-shortcut {
        display: none;
    }

    .csdi-global-search {
        padding-right: 12px;
    }
}
</style>