<?php

declare(strict_types=1);

namespace App\Components\Documentos;

use InvalidArgumentException;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * COMPONENTE TRANSVERSAL DE DOCUMENTOS
 *
 * DocumentTypes
 *
 * Catálogo central de documentos del ERP.
 *
 * =========================================================
 */
final class DocumentTypes
{
    public const PRESUPUESTO = 'PRESUPUESTO';

    public const PEDIDO = 'PEDIDO';

    public const REMITO = 'REMITO';

    public const VENTA = 'VENTA';

    public const PEDIDO_COMPRA = 'PEDIDO_COMPRA';

    public const COMPRA = 'COMPRA';

    public const DEVOLUCION_VENTA = 'DEVOLUCION_VENTA';

    public const DEVOLUCION_COMPRA = 'DEVOLUCION_COMPRA';

    /**
     * Configuraciones.
     *
     * @var array<string,array<string,mixed>>
     */
    private const CONFIG = [

        /*
        |--------------------------------------------------------------------------
        | VENTAS
        |--------------------------------------------------------------------------
        */

        self::PRESUPUESTO => [
            'tipo' => self::PRESUPUESTO,
            'nombre' => 'Presupuesto',
            'descripcion' =>
                'Presupuesto comercial para un cliente.',

            'tercero' => 'cliente',
            'tercero_label' => 'Cliente',
            'tercero_required' => true,

            'permite_lista_precios' => true,

            'permite_articulos' => true,
            'permite_servicios' => true,

            'permite_descuento' => true,
            'permite_iva' => true,

            'permite_comprobante' => false,
            'permite_punto_venta' => false,
            'permite_numero' => false,

            'movimiento_stock' => 'none',

            'estado_default' => 'PENDIENTE',

            'documentos_destino' => [
                self::PEDIDO,
                self::VENTA,
            ],
        ],

        self::PEDIDO => [
            'tipo' => self::PEDIDO,
            'nombre' => 'Pedido',
            'descripcion' =>
                'Pedido de cliente.',

            'tercero' => 'cliente',
            'tercero_label' => 'Cliente',
            'tercero_required' => true,

            'permite_lista_precios' => true,

            'permite_articulos' => true,
            'permite_servicios' => true,

            'permite_descuento' => true,
            'permite_iva' => true,

            'movimiento_stock' => 'none',

            'estado_default' => 'PENDIENTE',

            'documento_origen_permitido' =>
                self::PRESUPUESTO,

            'documentos_destino' => [
                self::REMITO,
                self::VENTA,
            ],
        ],

        self::REMITO => [
            'tipo' => self::REMITO,
            'nombre' => 'Remito',
            'descripcion' =>
                'Documento de entrega de mercadería.',

            'tercero' => 'cliente',
            'tercero_label' => 'Cliente',
            'tercero_required' => true,

            'permite_moneda' => false,
            'permite_lista_precios' => false,

            'permite_articulos' => true,
            'permite_servicios' => false,

            'permite_precio' => false,

            'permite_descuento' => false,
            'permite_iva' => false,

            'mostrar_precio' => false,
            'mostrar_descuento' => false,
            'mostrar_iva' => false,

            'movimiento_stock' => 'salida',

            'estado_default' => 'PENDIENTE',

            'documento_origen_permitido' =>
                self::PEDIDO,

            'documentos_destino' => [
                self::VENTA,
            ],
        ],

        self::VENTA => [
            'tipo' => self::VENTA,
            'nombre' => 'Venta',
            'descripcion' =>
                'Venta de artículos y servicios.',

            'tercero' => 'cliente',
            'tercero_label' => 'Cliente',
            'tercero_required' => false,

            'permite_lista_precios' => true,

            'permite_articulos' => true,
            'permite_servicios' => true,

            'permite_descuento' => true,
            'permite_iva' => true,

            'permite_comprobante' => true,
            'permite_punto_venta' => true,
            'permite_numero' => true,

            'movimiento_stock' => 'salida',

            'estado_default' => 'CONFIRMADA',

            'documento_origen_permitido' =>
                null,

            'documentos_destino' => [
                self::DEVOLUCION_VENTA,
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | COMPRAS
        |--------------------------------------------------------------------------
        */

        self::PEDIDO_COMPRA => [
            'tipo' => self::PEDIDO_COMPRA,
            'nombre' => 'Pedido de compra',
            'descripcion' =>
                'Pedido realizado a un proveedor.',

            'tercero' => 'proveedor',
            'tercero_label' => 'Proveedor',
            'tercero_required' => true,

            'permite_lista_precios' => false,

            'permite_articulos' => true,
            'permite_servicios' => false,

            'permite_descuento' => true,
            'permite_iva' => true,

            'movimiento_stock' => 'none',

            'estado_default' => 'PENDIENTE',

            'documentos_destino' => [
                self::COMPRA,
            ],
        ],

        self::COMPRA => [
            'tipo' => self::COMPRA,
            'nombre' => 'Compra',
            'descripcion' =>
                'Compra de artículos a un proveedor.',

            'tercero' => 'proveedor',
            'tercero_label' => 'Proveedor',
            'tercero_required' => true,

            'permite_lista_precios' => false,

            'permite_articulos' => true,
            'permite_servicios' => true,

            'permite_descuento' => true,
            'permite_iva' => true,

            'permite_comprobante' => true,
            'permite_punto_venta' => true,
            'permite_numero' => true,

            'movimiento_stock' => 'entrada',

            'estado_default' => 'CONFIRMADA',

            'documento_origen_permitido' =>
                self::PEDIDO_COMPRA,

            'documentos_destino' => [
                self::DEVOLUCION_COMPRA,
            ],
        ],

        /*
        |--------------------------------------------------------------------------
        | DEVOLUCIONES
        |--------------------------------------------------------------------------
        */

        self::DEVOLUCION_VENTA => [
            'tipo' => self::DEVOLUCION_VENTA,
            'nombre' => 'Devolución de venta',
            'descripcion' =>
                'Devolución de mercadería vendida.',

            'tercero' => 'cliente',
            'tercero_label' => 'Cliente',
            'tercero_required' => true,

            'permite_articulos' => true,
            'permite_servicios' => false,

            'permite_descuento' => false,
            'permite_iva' => true,

            'movimiento_stock' => 'entrada',

            'estado_default' => 'CONFIRMADA',
        ],

        self::DEVOLUCION_COMPRA => [
            'tipo' => self::DEVOLUCION_COMPRA,
            'nombre' => 'Devolución de compra',
            'descripcion' =>
                'Devolución de mercadería al proveedor.',

            'tercero' => 'proveedor',
            'tercero_label' => 'Proveedor',
            'tercero_required' => true,

            'permite_articulos' => true,
            'permite_servicios' => false,

            'permite_descuento' => false,
            'permite_iva' => true,

            'movimiento_stock' => 'salida',

            'estado_default' => 'CONFIRMADA',
        ],
    ];

    /**
     * Devuelve la configuración de un documento.
     */
    public static function config(string $tipo): DocumentConfig
    {
        $tipo =
            strtoupper(
                trim($tipo)
            );

        if (!isset(self::CONFIG[$tipo])) {
            throw new InvalidArgumentException(
                'Tipo de documento no soportado: ' .
                $tipo
            );
        }

        return new DocumentConfig(
            self::CONFIG[$tipo]
        );
    }

    /**
     * Verifica si existe.
     */
    public static function exists(string $tipo): bool
    {
        return isset(
            self::CONFIG[
                strtoupper(
                    trim($tipo)
                )
            ]
        );
    }

    /**
     * Devuelve todos los tipos.
     *
     * @return array<int,string>
     */
    public static function all(): array
    {
        return array_keys(
            self::CONFIG
        );
    }

    /**
     * Documentos comerciales de venta.
     *
     * @return array<int,string>
     */
    public static function ventas(): array
    {
        return [
            self::PRESUPUESTO,
            self::PEDIDO,
            self::REMITO,
            self::VENTA,
        ];
    }

    /**
     * Documentos comerciales de compra.
     *
     * @return array<int,string>
     */
    public static function compras(): array
    {
        return [
            self::PEDIDO_COMPRA,
            self::COMPRA,
        ];
    }

    /**
     * Devuelve el nombre visible.
     */
    public static function label(string $tipo): string
    {
        return self::config($tipo)->nombre();
    }

    /**
     * Devuelve descripción.
     */
    public static function description(string $tipo): string
    {
        return self::config($tipo)->descripcion();
    }

    /**
     * Devuelve documentos destino.
     *
     * @return array<int,string>
     */
    public static function destinos(string $tipo): array
    {
        return self::config($tipo)->documentosDestino();
    }

    /**
     * Devuelve todos los documentos con información básica.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function options(): array
    {
        $result = [];

        foreach (self::CONFIG as $tipo => $config) {
            $result[] = [
                'tipo' =>
                    $tipo,

                'nombre' =>
                    $config['nombre'],

                'descripcion' =>
                    $config['descripcion'],

                'tercero' =>
                    $config['tercero'],

                'movimiento_stock' =>
                    $config['movimiento_stock'],
            ];
        }

        return $result;
    }
}