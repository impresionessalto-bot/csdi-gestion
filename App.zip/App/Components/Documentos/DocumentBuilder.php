<?php

declare(strict_types=1);

namespace App\Components\Documentos;

use InvalidArgumentException;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * COMPONENTE TRANSVERSAL DE DOCUMENTOS
 *
 * DocumentBuilder
 *
 * Construye documentos normalizados.
 *
 * NO guarda en BD.
 * NO modifica stock.
 *
 * =========================================================
 */
final class DocumentBuilder
{
    /**
     * Datos internos.
     *
     * @var array<string,mixed>
     */
    private array $data = [];

    /**
     * Configuración.
     */
    private DocumentConfig $config;

    /**
     * Constructor.
     */
    public function __construct(DocumentConfig $config)
    {
        $this->config = $config;

        $this->data = [
            'tipo' =>
                $config->tipo(),

            'tercero_id' =>
                null,

            'fecha' =>
                date('Y-m-d'),

            'moneda' =>
                $config->monedaDefault(),

            'cotizacion_usd' =>
                null,

            'lista_precio_id' =>
                $config->listaPrecioDefault(),

            'tipo_comprobante' =>
                null,

            'punto_venta' =>
                null,

            'numero' =>
                null,

            'vendedor_id' =>
                null,

            'observacion' =>
                null,

            'estado' =>
                $config->estadoDefault(),

            'documento_origen_id' =>
                null,

            'documento_origen_tipo' =>
                null,

            'items' =>
                [],
        ];
    }

    /**
     * Crea un builder.
     */
    public static function create(
        DocumentConfig|string $config
    ): self {

        if (is_string($config)) {
            $config =
                DocumentTypes::config(
                    $config
                );
        }

        return new self($config);
    }

    /**
     * Configuración.
     */
    public function config(): DocumentConfig
    {
        return $this->config;
    }

    /**
     * Tipo.
     */
    public function tipo(string $tipo): self
    {
        $tipo =
            strtoupper(
                trim($tipo)
            );

        if (
            $tipo !==
            $this->config->tipo()
        ) {
            throw new InvalidArgumentException(
                'El tipo no coincide con la configuración.'
            );
        }

        $this->data['tipo'] =
            $tipo;

        return $this;
    }

    /**
     * Tercero.
     */
    public function tercero(?int $id): self
    {
        $this->data['tercero_id'] =
            $id !== null && $id > 0
                ? $id
                : null;

        return $this;
    }

    /**
     * Cliente.
     */
    public function cliente(?int $id): self
    {
        if (
            $this->config->tercero()
            !== 'cliente'
        ) {
            throw new InvalidArgumentException(
                'Este documento utiliza proveedor.'
            );
        }

        return $this->tercero($id);
    }

    /**
     * Proveedor.
     */
    public function proveedor(?int $id): self
    {
        if (
            $this->config->tercero()
            !== 'proveedor'
        ) {
            throw new InvalidArgumentException(
                'Este documento utiliza cliente.'
            );
        }

        return $this->tercero($id);
    }

    /**
     * Fecha.
     */
    public function fecha(?string $fecha): self
    {
        if ($fecha === null || trim($fecha) === '') {
            $this->data['fecha'] =
                date('Y-m-d');

            return $this;
        }

        $timestamp =
            strtotime($fecha);

        if ($timestamp === false) {
            throw new InvalidArgumentException(
                'La fecha indicada no es válida.'
            );
        }

        $this->data['fecha'] =
            date(
                'Y-m-d',
                $timestamp
            );

        return $this;
    }

    /**
     * Moneda.
     */
    public function moneda(string $moneda): self
    {
        $moneda =
            strtoupper(
                trim($moneda)
            );

        if (
            !in_array(
                $moneda,
                ['ARS', 'USD'],
                true
            )
        ) {
            throw new InvalidArgumentException(
                'La moneda debe ser ARS o USD.'
            );
        }

        $this->data['moneda'] =
            $moneda;

        return $this;
    }

    /**
     * Cotización USD.
     */
    public function cotizacion(?float $valor): self
    {
        $this->data['cotizacion_usd'] =
            $valor !== null && $valor > 0
                ? round($valor, 6)
                : null;

        return $this;
    }

    /**
     * Lista de precios.
     */
    public function listaPrecio(?int $id): self
    {
        $this->data['lista_precio_id'] =
            $id !== null && $id > 0
                ? $id
                : null;

        return $this;
    }

    /**
     * Comprobante.
     */
    public function comprobante(
        ?string $tipo,
        ?int $puntoVenta = null,
        ?string $numero = null
    ): self {

        $this->data['tipo_comprobante'] =
            $tipo !== null
                ? strtoupper(
                    trim($tipo)
                )
                : null;

        $this->data['punto_venta'] =
            $puntoVenta !== null &&
            $puntoVenta > 0
                ? $puntoVenta
                : null;

        $this->data['numero'] =
            $numero !== null &&
            trim($numero) !== ''
                ? trim($numero)
                : null;

        return $this;
    }

    /**
     * Vendedor.
     */
    public function vendedor(?int $id): self
    {
        $this->data['vendedor_id'] =
            $id !== null && $id > 0
                ? $id
                : null;

        return $this;
    }

    /**
     * Observación.
     */
    public function observacion(?string $texto): self
    {
        $this->data['observacion'] =
            $texto !== null
                ? trim($texto)
                : null;

        return $this;
    }

    /**
     * Estado.
     */
    public function estado(string $estado): self
    {
        $estado =
            strtoupper(
                trim($estado)
            );

        if ($estado === '') {
            throw new InvalidArgumentException(
                'El estado no puede estar vacío.'
            );
        }

        $this->data['estado'] =
            $estado;

        return $this;
    }

    /**
     * Documento origen.
     */
    public function origen(
        ?int $id,
        ?string $tipo = null
    ): self {

        $this->data['documento_origen_id'] =
            $id !== null && $id > 0
                ? $id
                : null;

        $this->data['documento_origen_tipo'] =
            $tipo !== null
                ? strtoupper(
                    trim($tipo)
                )
                : null;

        return $this;
    }

    /**
     * Agrega un artículo.
     *
     * @param array<string,mixed> $item
     */
    public function addItem(array $item): self
    {
        $this->data['items'][] =
            $item;

        return $this;
    }

    /**
     * Agrega un insumo.
     */
    public function addInsumo(
        int $insumoId,
        float $cantidad,
        float $precio,
        float $descuento = 0,
        float $iva = 0,
        ?string $descripcion = null
    ): self {

        return $this->addItem([
            'tipo' =>
                'INSUMO',

            'insumo_id' =>
                $insumoId,

            'servicio_id' =>
                null,

            'descripcion' =>
                $descripcion,

            'cantidad' =>
                $cantidad,

            'precio_unitario' =>
                $precio,

            'descuento' =>
                $descuento,

            'iva_porcentaje' =>
                $iva,
        ]);
    }

    /**
     * Agrega un servicio.
     */
    public function addServicio(
        int $servicioId,
        float $cantidad,
        float $precio,
        float $descuento = 0,
        float $iva = 0,
        ?string $descripcion = null
    ): self {

        return $this->addItem([
            'tipo' =>
                'SERVICIO',

            'insumo_id' =>
                null,

            'servicio_id' =>
                $servicioId,

            'descripcion' =>
                $descripcion,

            'cantidad' =>
                $cantidad,

            'precio_unitario' =>
                $precio,

            'descuento' =>
                $descuento,

            'iva_porcentaje' =>
                $iva,
        ]);
    }

    /**
     * Agrega un artículo genérico.
     */
    public function addOtro(
        string $descripcion,
        float $cantidad,
        float $precio,
        float $descuento = 0,
        float $iva = 0
    ): self {

        return $this->addItem([
            'tipo' =>
                'OTRO',

            'insumo_id' =>
                null,

            'servicio_id' =>
                null,

            'descripcion' =>
                trim($descripcion),

            'cantidad' =>
                $cantidad,

            'precio_unitario' =>
                $precio,

            'descuento' =>
                $descuento,

            'iva_porcentaje' =>
                $iva,
        ]);
    }

    /**
     * Reemplaza los items.
     *
     * @param array<int,array<string,mixed>> $items
     */
    public function items(array $items): self
    {
        $this->data['items'] =
            $items;

        return $this;
    }

    /**
     * Descuento global.
     */
    public function descuentoGlobal(float $importe): self
    {
        $this->data['descuento_global'] =
            max(
                0,
                round($importe, 2)
            );

        return $this;
    }

    /**
     * Devuelve los datos sin validar.
     *
     * @return array<string,mixed>
     */
    public function data(): array
    {
        return $this->data;
    }

    /**
     * Construye y valida el documento.
     *
     * @return array<string,mixed>
     */
    public function build(): array
    {
        /*
         * Validamos primero la relación
         * documento origen.
         */

        $origenTipo =
            $this->data[
                'documento_origen_tipo'
            ] ?? null;

        if (
            $origenTipo !== null
            && $origenTipo !== ''
        ) {

            $permitido =
                $this->config
                    ->documentoOrigenPermitido();

            if (
                $permitido !== null
                && strtoupper($origenTipo)
                    !== $permitido
            ) {
                throw new InvalidArgumentException(
                    'El documento origen no es válido para ' .
                    $this->config->nombre() .
                    '.'
                );
            }
        }

        /*
         * Validación central.
         */

        return DocumentValidator::validate(
            $this->data,
            $this->config
        );
    }

    /**
     * Alias de build().
     *
     * @return array<string,mixed>
     */
    public function validate(): array
    {
        return $this->build();
    }
}