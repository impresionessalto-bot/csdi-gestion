```php
<?php

declare(strict_types=1);

namespace App\Components\Documentos;

/**
 * Componente reutilizable para carga de documentos mediante Drag & Drop.
 *
 * Uso:
 *
 * echo DocumentDropzone::render([
 *     'id'       => 'documento',
 *     'name'     => 'documento',
 *     'multiple' => false,
 *     'accept'   => ['pdf', 'jpg', 'jpeg', 'png'],
 * ]);
 *
 * El componente NO procesa OCR ni IA.
 * Su responsabilidad es únicamente:
 *
 * - Drag & Drop
 * - selección mediante explorador
 * - validación básica del navegador
 * - mostrar archivos seleccionados
 * - mostrar tamaño
 * - eliminar archivos
 * - preview de imágenes
 * - preview de PDF
 * - preparar el input para el formulario
 */
final class DocumentDropzone
{
    /**
     * Configuración por defecto.
     */
    private const DEFAULTS = [
        'id'             => 'documentDropzone',
        'name'           => 'documento',
        'multiple'       => false,
        'accept'         => ['pdf', 'jpg', 'jpeg', 'png'],
        'maxSize'        => 15 * 1024 * 1024,
        'preview'        => true,
        'showFileList'   => true,
        'showFormats'    => true,
        'showMaxSize'    => true,
        'disabled'       => false,
        'required'       => false,

        'title'          => 'Arrastrá tu documento aquí',
        'subtitle'       => 'o hacé clic para seleccionar un archivo',
        'formatsText'    => '',
        'buttonText'     => 'Seleccionar archivo',

        'emptyIcon'      => 'bi bi-cloud-arrow-up',
        'fileIcon'       => 'bi bi-file-earmark',

        'inputClass'     => '',
        'containerClass' => '',
        'labelClass'     => '',
        'data'           => [],
    ];

    /**
     * Renderiza el componente.
     *
     * @param array<string,mixed> $options
     */
    public static function render(array $options = []): string
    {
        $config = self::normalizeOptions($options);

        $id = $config['id'];
        $name = $config['name'];

        $multiple = $config['multiple'];
        $accept = $config['accept'];
        $maxSize = $config['maxSize'];

        $inputId = $id . 'Input';
        $filesId = $id . 'Files';
        $previewId = $id . 'Preview';
        $removeId = $id . 'Remove';
        $browseId = $id . 'Browse';
        $messageId = $id . 'Message';

        $acceptAttribute = self::buildAcceptAttribute($accept);

        $multipleAttribute = $multiple ? ' multiple' : '';
        $requiredAttribute = $config['required'] ? ' required' : '';
        $disabledAttribute = $config['disabled'] ? ' disabled' : '';

        $formats = self::buildFormats($accept);

        $maxSizeText = self::formatBytes($maxSize);

        $containerClass = trim(
            'document-dropzone-component ' .
            $config['containerClass']
        );

        $dropzoneClass = 'document-dropzone';

        if ($config['disabled']) {
            $dropzoneClass .= ' document-dropzone-disabled';
        }

        $dataAttributes = self::buildDataAttributes($config['data']);

        $title = self::escape($config['title']);
        $subtitle = self::escape($config['subtitle']);
        $buttonText = self::escape($config['buttonText']);

        ob_start();
        ?>

        <div
            id="<?= self::escape($id) ?>Container"
            class="<?= self::escape($containerClass) ?>"
            data-document-dropzone
            data-dropzone-id="<?= self::escape($id) ?>"
            data-max-size="<?= (int) $maxSize ?>"
            data-multiple="<?= $multiple ? 'true' : 'false' ?>"
            data-preview="<?= $config['preview'] ? 'true' : 'false' ?>"
            <?= $dataAttributes ?>
        >

            <!-- =========================================================
                 DROPZONE
                 ========================================================= -->

            <div
                id="<?= self::escape($id) ?>"
                class="<?= self::escape($dropzoneClass) ?>"
                data-dropzone
                tabindex="0"
                role="button"
                aria-label="<?= $title ?>"
            >

                <div class="document-dropzone-content">

                    <!-- Icono -->

                    <div class="document-dropzone-icon">

                        <i class="<?= self::escape($config['emptyIcon']) ?>"></i>

                    </div>


                    <!-- Título -->

                    <h3 class="document-dropzone-title">

                        <?= $title ?>

                    </h3>


                    <!-- Subtítulo -->

                    <p class="document-dropzone-subtitle">

                        <?= $subtitle ?>

                    </p>


                    <!-- Formatos -->

                    <?php if ($config['showFormats'] && $formats !== ''): ?>

                        <div class="document-dropzone-formats">

                            <?= $formats ?>

                        </div>

                    <?php endif; ?>


                    <!-- Tamaño máximo -->

                    <?php if ($config['showMaxSize'] && $maxSize > 0): ?>

                        <div class="document-dropzone-max-size">

                            Tamaño máximo:
                            <?= self::escape($maxSizeText) ?>

                        </div>

                    <?php endif; ?>


                    <!-- Botón -->

                    <button
                        type="button"
                        id="<?= self::escape($browseId) ?>"
                        class="btn btn-outline-primary document-dropzone-browse"
                        data-dropzone-browse
                        <?= $disabledAttribute ?>
                    >

                        <i class="bi bi-folder2-open me-1"></i>

                        <?= $buttonText ?>

                    </button>


                    <!-- Input real -->

                    <input
                        type="file"
                        id="<?= self::escape($inputId) ?>"
                        name="<?= self::escape($name) ?>"
                        class="<?= self::escape($config['inputClass']) ?>"
                        accept="<?= self::escape($acceptAttribute) ?>"
                        data-dropzone-input
                        hidden
                        <?= $multipleAttribute ?>
                        <?= $requiredAttribute ?>
                        <?= $disabledAttribute ?>
                    >

                </div>

            </div>


            <!-- =========================================================
                 MENSAJE DE ERROR / VALIDACIÓN
                 ========================================================= -->

            <div
                id="<?= self::escape($messageId) ?>"
                class="document-dropzone-message d-none"
                data-dropzone-message
                role="alert"
            ></div>


            <!-- =========================================================
                 ARCHIVOS SELECCIONADOS
                 ========================================================= -->

            <?php if ($config['showFileList']): ?>

                <div
                    id="<?= self::escape($filesId) ?>"
                    class="document-dropzone-files d-none"
                    data-dropzone-files
                >

                    <div class="document-dropzone-files-header">

                        <div>

                            <h5 class="document-dropzone-files-title mb-0">

                                <i class="bi bi-paperclip me-1"></i>

                                Archivos seleccionados

                            </h5>

                        </div>

                        <span
                            class="document-dropzone-files-count"
                            data-dropzone-count
                        >
                            0
                        </span>

                    </div>


                    <div
                        class="document-dropzone-file-list"
                        data-dropzone-file-list
                    ></div>

                </div>

            <?php endif; ?>


            <!-- =========================================================
                 PREVIEW
                 ========================================================= -->

            <?php if ($config['preview']): ?>

                <div
                    id="<?= self::escape($previewId) ?>"
                    class="document-dropzone-preview-container d-none"
                    data-dropzone-preview-container
                >

                    <div class="document-dropzone-preview-header">

                        <h5 class="mb-0">

                            <i class="bi bi-eye me-1"></i>

                            Vista previa

                        </h5>

                        <button
                            type="button"
                            class="btn btn-sm btn-outline-secondary"
                            data-dropzone-preview-close
                        >

                            <i class="bi bi-x-lg"></i>

                        </button>

                    </div>


                    <div
                        class="document-dropzone-preview"
                        data-dropzone-preview
                    ></div>

                </div>

            <?php endif; ?>


            <!-- =========================================================
                 ESTADO
                 ========================================================= -->

            <div
                class="document-dropzone-status d-none"
                data-dropzone-status
            >

                <div class="document-dropzone-status-content">

                    <span
                        class="document-dropzone-status-icon"
                        data-dropzone-status-icon
                    >

                        <i class="bi bi-check-circle"></i>

                    </span>

                    <span
                        class="document-dropzone-status-text"
                        data-dropzone-status-text
                    ></span>

                </div>

            </div>

        </div>

        <?php

        return (string) ob_get_clean();
    }


    /**
     * Normaliza y valida la configuración.
     *
     * @param array<string,mixed> $options
     * @return array<string,mixed>
     */
    private static function normalizeOptions(array $options): array
    {
        $config = array_replace(self::DEFAULTS, $options);

        /*
         * ID
         */

        $config['id'] = self::sanitizeId(
            (string) $config['id']
        );

        /*
         * Name
         */

        $config['name'] = trim(
            (string) $config['name']
        );

        if ($config['name'] === '') {
            $config['name'] = 'documento';
        }

        /*
         * Booleanos
         */

        $config['multiple'] = (bool) $config['multiple'];
        $config['preview'] = (bool) $config['preview'];
        $config['showFileList'] = (bool) $config['showFileList'];
        $config['showFormats'] = (bool) $config['showFormats'];
        $config['showMaxSize'] = (bool) $config['showMaxSize'];
        $config['disabled'] = (bool) $config['disabled'];
        $config['required'] = (bool) $config['required'];

        /*
         * Tamaño máximo.
         */

        $config['maxSize'] = max(
            0,
            (int) $config['maxSize']
        );

        /*
         * Extensiones.
         */

        $config['accept'] = self::normalizeAccept(
            $config['accept']
        );

        /*
         * Textos.
         */

        $config['title'] = (string) $config['title'];
        $config['subtitle'] = (string) $config['subtitle'];
        $config['formatsText'] = (string) $config['formatsText'];
        $config['buttonText'] = (string) $config['buttonText'];

        /*
         * Clases.

         */

        $config['containerClass'] = trim(
            (string) $config['containerClass']
        );

        $config['inputClass'] = trim(
            (string) $config['inputClass']
        );

        /*
         * Datos personalizados.
         */

        if (!is_array($config['data'])) {
            $config['data'] = [];
        }

        return $config;
    }


    /**
     * Normaliza las extensiones aceptadas.
     *
     * @param mixed $accept
     * @return array<int,string>
     */
    private static function normalizeAccept(mixed $accept): array
    {
        if (is_string($accept)) {
            $accept = preg_split(
                '/\s*,\s*/',
                $accept
            );
        }

        if (!is_array($accept)) {
            return [];
        }

        $result = [];

        foreach ($accept as $value) {

            if (!is_scalar($value)) {
                continue;
            }

            $value = strtolower(
                trim((string) $value)
            );

            if ($value === '') {
                continue;
            }

            /*
             * Permite:
             *
             * pdf
             * .pdf
             * image/png
             * application/pdf
             */

            if ($value[0] === '.') {
                $value = substr($value, 1);
            }

            $result[] = $value;
        }

        return array_values(
            array_unique($result)
        );
    }


    /**
     * Construye el atributo accept del input.
     *
     * @param array<int,string> $accept
     */
    private static function buildAcceptAttribute(array $accept): string
    {
        $mimeMap = [
            'pdf'  => 'application/pdf',

            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png'  => 'image/png',
            'gif'  => 'image/gif',
            'webp' => 'image/webp',

            'doc'  => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

            'xls'  => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',

            'csv'  => 'text/csv',
        ];

        $result = [];

        foreach ($accept as $value) {

            if (isset($mimeMap[$value])) {
                $result[] = $mimeMap[$value];
                continue;
            }

            /*
             * Si ya es MIME.
             */

            if (str_contains($value, '/')) {
                $result[] = $value;
                continue;
            }

            /*
             * Como fallback, utilizar extensión.
             */

            $result[] = '.' . ltrim(
                $value,
                '.'
            );
        }

        return implode(',', array_unique($result));
    }


    /**
     * Construye las insignias de formatos.
     *
     * @param array<int,string> $accept
     */
    private static function buildFormats(array $accept): string
    {
        if ($accept === []) {
            return '';
        }

        $known = [
            'pdf'  => 'PDF',
            'jpg'  => 'JPG',
            'jpeg' => 'JPEG',
            'png'  => 'PNG',
            'gif'  => 'GIF',
            'webp' => 'WEBP',
            'doc'  => 'DOC',
            'docx' => 'DOCX',
            'xls'  => 'XLS',
            'xlsx' => 'XLSX',
            'csv'  => 'CSV',
        ];

        $result = [];

        foreach ($accept as $value) {

            $label = $known[$value]
                ?? strtoupper(
                    str_replace(
                        ['image/', 'application/'],
                        '',
                        $value
                    )
                );

            $result[] =
                '<span class="badge rounded-pill document-dropzone-format">'
                . self::escape($label)
                . '</span>';
        }

        return implode('', $result);
    }


    /**
     * Construye atributos data-* personalizados.
     *
     * @param array<string,mixed> $data
     */
    private static function buildDataAttributes(array $data): string
    {
        $attributes = [];

        foreach ($data as $key => $value) {

            if (!is_string($key)) {
                continue;
            }

            $key = trim($key);

            if ($key === '') {
                continue;
            }

            /*
             * Permitimos pasar:
             *
             * [
             *     'module' => 'compras',
             *     'tipo'   => 'factura'
             * ]
             *
             * y lo convertimos en:
             *
             * data-module="compras"
             * data-tipo="factura"
             */

            $key = preg_replace(
                '/[^a-zA-Z0-9\-_]/',
                '-',
                $key
            );

            if ($key === null || $key === '') {
                continue;
            }

            if (is_bool($value)) {
                $value = $value ? 'true' : 'false';
            } elseif (is_scalar($value)) {
                $value = (string) $value;
            } else {
                continue;
            }

            $attributes[] =
                'data-' .
                self::escape($key) .
                '="' .
                self::escape($value) .
                '"';
        }

        return $attributes !== []
            ? ' ' . implode(' ', $attributes)
            : '';
    }


    /**
     * Sanitiza un ID HTML.
     */
    private static function sanitizeId(string $id): string
    {
        $id = trim($id);

        if ($id === '') {
            return 'documentDropzone';
        }

        $id = preg_replace(
            '/[^a-zA-Z0-9\-_]/',
            '-',
            $id
        );

        if ($id === null || $id === '') {
            return 'documentDropzone';
        }

        /*
         * Evitamos IDs que comiencen con número.
         */

        if (preg_match('/^[0-9]/', $id) === 1) {
            $id = 'document-' . $id;
        }

        return $id;
    }


    /**
     * Formatea bytes para mostrar al usuario.
     */
    private static function formatBytes(int $bytes): string
    {
        if ($bytes <= 0) {
            return 'sin límite';
        }

        $units = [
            'B',
            'KB',
            'MB',
            'GB',
        ];

        $size = (float) $bytes;
        $index = 0;

        while ($size >= 1024 && $index < count($units) - 1) {

            $size /= 1024;
            $index++;
        }

        if ($index === 0) {
            return (string) $size . ' ' . $units[$index];
        }

        return number_format(
            $size,
            $size >= 10 ? 0 : 1,
            ',',
            '.'
        ) . ' ' . $units[$index];
    }


    /**
     * Escapado HTML seguro.
     */
    private static function escape(string $value): string
    {
        return htmlspecialchars(
            $value,
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}
```
