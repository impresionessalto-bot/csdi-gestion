```php
<?php

declare(strict_types=1);

namespace App\Components\Documentos;

use InvalidArgumentException;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * COMPONENTE TRANSVERSAL DE DOCUMENTOS
 *
 * DocumentValidator
 *
 * Valida la estructura de un documento antes de que
 * llegue al Service específico de Compras / Ventas.
 *
 * NO guarda información.
 * NO consulta BD.
 * NO modifica stock.
 *
 * =========================================================
 */
final class DocumentValidator
{
    /*
    |--------------------------------------------------------------------------
    | VALIDAR DOCUMENTO COMPLETO
    |--------------------------------------------------------------------------
    */

    public static function validate(
        array $documento,
        DocumentConfig $config
    ): array {

        $data = $documento;

        /*
         * Normalizamos.
         */

        $data['tipo'] =
            strtoupper(
                trim(
                    (string) (
                        $data['tipo']
                        ?? $config->tipo()
                    )
                )
            );

        if (
            $data['tipo'] !==
            $config->tipo()
        ) {
            throw new InvalidArgumentException(
                'El tipo de documento no coincide con la configuración.'
            );
        }

        /*
         * Tercero.
         */

        $terceroId =
            (int) (
                $data['tercero_id']
                ?? $data[
                    $config->tercero() . '_id'
                ]
                ?? 0
            );

        if (
            $config->terceroRequired()
            && $terceroId <= 0
        ) {
            throw new InvalidArgumentException(
                'Debe seleccionar un ' .
                strtolower(
                    $config->terceroLabel()
                ) .
                '.'
            );
        }

        $data['tercero_id'] =
            $terceroId > 0
                ? $terceroId
                : null;

        /*
         * Fecha.
         */

        if ($config->permiteFecha()) {

            $fecha =
                trim(
                    (string) (
                        $data['fecha']
                        ?? ''
                    )
                );

            if ($fecha !== '') {

                $timestamp =
                    strtotime($fecha);

                if ($timestamp === false) {
                    throw new InvalidArgumentException(
                        'La fecha del documento no es válida.'
                    );
                }

                $data['fecha'] =
                    date(
                        'Y-m-d',
                        $timestamp
                    );
            } else {
                $data['fecha'] =
                    date('Y-m-d');
            }
        }

        /*
         * Moneda.
         */

        if ($config->permiteMoneda()) {

            $moneda =
                strtoupper(
                    trim(
                        (string) (
                            $data['moneda']
                            ?? $config->monedaDefault()
                        )
                    )
                );

            if (
                !in_array(
                    $moneda,
                    ['ARS', 'USD'],
                    true
                )
            ) {
                throw new InvalidArgumentException(
                    'La moneda debe ser ARS o USD.'
                );
            }

            $data['moneda'] = $moneda;

            /*
             * Cotización.
             */

            if (
                $moneda === 'USD'
                && $config->permiteCotizacion()
            ) {

                $cotizacion =
                    (float) (
                        $data['cotizacion_usd']
                        ?? 0
                    );

                if ($cotizacion <= 0) {
                    throw new InvalidArgumentException(
                        'Debe indicar la cotización del dólar.'
                    );
                }

                $data['cotizacion_usd'] =
                    round(
                        $cotizacion,
                        6
                    );
            }
        }

        /*
         * Lista de precios.
         */

        if ($config->permiteListaPrecios()) {

            $listaId =
                (int) (
                    $data['lista_precio_id']
                    ?? $config->listaPrecioDefault()
                    ?? 0
                );

            $data['lista_precio_id'] =
                $listaId > 0
                    ? $listaId
                    : null;
        } else {
            unset(
                $data['lista_precio_id']
            );
        }

        /*
         * Comprobante.
         */

        if ($config->permiteComprobante()) {

            $tipoComprobante =
                strtoupper(
                    trim(
                        (string) (
                            $data['tipo_comprobante']
                            ?? ''
                        )
                    )
                );

            if (
                $tipoComprobante !== ''
                && strlen($tipoComprobante) > 30
            ) {
                throw new InvalidArgumentException(
                    'El tipo de comprobante no es válido.'
                );
            }

            $data['tipo_comprobante'] =
                $tipoComprobante !== ''
                    ? $tipoComprobante
                    : null;
        }

        /*
         * Punto de venta.
         */

        if ($config->permitePuntoVenta()) {

            $puntoVenta =
                (int) (
                    $data['punto_venta']
                    ?? 0
                );

            if ($puntoVenta < 0) {
                throw new InvalidArgumentException(
                    'El punto de venta no puede ser negativo.'
                );
            }

            $data['punto_venta'] =
                $puntoVenta > 0
                    ? $puntoVenta
                    : null;
        }

        /*
         * Número.
         */

        if ($config->permiteNumero()) {

            $numero =
                trim(
                    (string) (
                        $data['numero']
                        ?? ''
                    )
                );

            if (strlen($numero) > 100) {
                throw new InvalidArgumentException(
                    'El número de comprobante es demasiado largo.'
                );
            }

            $data['numero'] =
                $numero !== ''
                    ? $numero
                    : null;
        }

        /*
         * Vendedor / usuario.
         */

        if ($config->permiteVendedor()) {

            $vendedorId =
                (int) (
                    $data['vendedor_id']
                    ?? $data['usuario_id']
                    ?? 0
                );

            $data['vendedor_id'] =
                $vendedorId > 0
                    ? $vendedorId
                    : null;
        }

        /*
         * Observación.
         */

        if ($config->permiteObservacion()) {

            $observacion =
                $data['observacion']
                ?? null;

            if (
                $observacion !== null
                && !is_scalar($observacion)
            ) {
                throw new InvalidArgumentException(
                    'La observación no es válida.'
                );
            }

            $data['observacion'] =
                $observacion !== null
                    ? trim(
                        (string) $observacion
                    )
                    : null;
        }

        /*
         * ITEMS
         */

        $items =
            $data['items']
            ?? [];

        $data['items'] =
            self::validateItems(
                is_array($items)
                    ? $items
                    : [],
                $config
            );

        if (
            $config->permiteArticulos()
            && !$data['items']
        ) {
            throw new InvalidArgumentException(
                'El documento debe contener al menos un artículo.'
            );
        }

        /*
         * Totales:
         *
         * Nunca confiamos en los totales enviados
         * desde JavaScript.
         */

        $totales =
            self::calcularTotales(
                $data['items'],
                $data,
                $config
            );

        $data['subtotal'] =
            $totales['subtotal'];

        $data['descuento_total'] =
            $totales['descuento'];

        $data['iva_total'] =
            $totales['iva'];

        $data['total'] =
            $totales['total'];

        return $data;
    }

    /*
    |--------------------------------------------------------------------------
    | ITEMS
    |--------------------------------------------------------------------------
    */

    public static function validateItems(
        array $items,
        DocumentConfig $config
    ): array {

        if (
            count($items) >
            $config->maxItems()
        ) {
            throw new InvalidArgumentException(
                'El documento supera el máximo de ' .
                $config->maxItems() .
                ' artículos.'
            );
        }

        $resultado = [];

        foreach ($items as $index => $item) {

            if (!is_array($item)) {
                throw new InvalidArgumentException(
                    'El artículo #' .
                    ((int) $index + 1) .
                    ' no es válido.'
                );
            }

            $insumoId =
                (int) (
                    $item['insumo_id']
                    ?? $item['producto_id']
                    ?? $item['id']
                    ?? 0
                );

            $servicioId =
                (int) (
                    $item['servicio_id']
                    ?? 0
                );

            $tipo =
                strtoupper(
                    trim(
                        (string) (
                            $item['tipo']
                            ?? 'INSUMO'
                        )
                    )
                );

            /*
             * Validar tipo.
             */

            if (
                $tipo === 'INSUMO'
                && !$config->permiteArticulos()
            ) {
                throw new InvalidArgumentException(
                    'Este documento no permite artículos.'
                );
            }

            if (
                $tipo === 'SERVICIO'
                && !$config->permiteServicios()
            ) {
                throw new InvalidArgumentException(
                    'Este documento no permite servicios.'
                );
            }

            if (
                !in_array(
                    $tipo,
                    [
                        'INSUMO',
                        'SERVICIO',
                        'OTRO',
                    ],
                    true
                )
            ) {
                throw new InvalidArgumentException(
                    'Tipo de artículo inválido en la posición ' .
                    ((int) $index + 1) .
                    '.'
                );
            }

            if (
                $tipo === 'INSUMO'
                && $insumoId <= 0
            ) {
                throw new InvalidArgumentException(
                    'El artículo #' .
                    ((int) $index + 1) .
                    ' no tiene un insumo válido.'
                );
            }

            if (
                $tipo === 'SERVICIO'
                && $servicioId <= 0
            ) {
                throw new InvalidArgumentException(
                    'El servicio #' .
                    ((int) $index + 1) .
                    ' no es válido.'
                );
            }

            /*
             * Cantidad.
             */

            $cantidad =
                (float) (
                    $item['cantidad']
                    ?? 0
                );

            if (
                $cantidad <
                $config->cantidadMinima()
            ) {
                throw new InvalidArgumentException(
                    'La cantidad del artículo #' .
                    ((int) $index + 1) .
                    ' debe ser mayor que cero.'
                );
            }

            if (
                !$config->permiteCantidadDecimal()
                && floor($cantidad) !== $cantidad
            ) {
                throw new InvalidArgumentException(
                    'La cantidad del artículo #' .
                    ((int) $index + 1) .
                    ' debe ser entera.'
                );
            }

            /*
             * Precio.
             */

            $precio =
                (float) (
                    $item['precio_unitario']
                    ?? $item['precio']
                    ?? 0
                );

            if (
                $precio <
                $config->precioMinimo()
            ) {
                throw new InvalidArgumentException(
                    'El precio del artículo #' .
                    ((int) $index + 1) .
                    ' no es válido.'
                );
            }

            /*
             * Descuento.
             */

            $descuento =
                (float) (
                    $item['descuento']
                    ?? 0
                );

            if ($descuento < 0) {
                throw new InvalidArgumentException(
                    'El descuento no puede ser negativo.'
                );
            }

            if (
                $descuento >
                $config->descuentoMaximo()
            ) {
                throw new InvalidArgumentException(
                    'El descuento supera el máximo permitido.'
                );
            }

            /*
             * IVA.
             */

            $ivaPorcentaje =
                (float) (
                    $item['iva_porcentaje']
                    ?? $item['iva']
                    ?? 0
                );

            if ($ivaPorcentaje < 0) {
                throw new InvalidArgumentException(
                    'El IVA no puede ser negativo.'
                );
            }

            if ($ivaPorcentaje > 100) {
                throw new InvalidArgumentException(
                    'El IVA no puede superar el 100%.'
                );
            }

            /*
             * Subtotal bruto.
             */

            $bruto =
                round(
                    $cantidad * $precio,
                    2
                );

            /*
             * Descuento monetario.
             */

            $descuentoImporte =
                round(
                    $bruto * $descuento / 100,
                    2
                );

            /*
             * Neto.
             */

            $neto =
                max(
                    0,
                    round(
                        $bruto -
                        $descuentoImporte,
                        2
                    )
                );

            /*
             * IVA.
             */

            $iva =
                $config->permiteIva()
                    ? round(
                        $neto *
                        $ivaPorcentaje /
                        100,
                        2
                    )
                    : 0;

            /*
             * Total línea.
             */

            $subtotal =
                round(
                    $neto + $iva,
                    2
                );

            /*
             * Normalización.
             */

            $normalizado = $item;

            $normalizado['tipo'] =
                $tipo;

            $normalizado['insumo_id'] =
                $insumoId > 0
                    ? $insumoId
                    : null;

            $normalizado['servicio_id'] =
                $servicioId > 0
                    ? $servicioId
                    : null;

            $normalizado['cantidad'] =
                round(
                    $cantidad,
                    3
                );

            $normalizado['precio_unitario'] =
                round(
                    $precio,
                    2
                );

            $normalizado['descuento'] =
                round(
                    $descuento,
                    4
                );

            $normalizado['descuento_importe'] =
                $descuentoImporte;

            $normalizado['iva_porcentaje'] =
                round(
                    $ivaPorcentaje,
                    4
                );

            $normalizado['iva_importe'] =
                $iva;

            $normalizado['subtotal'] =
                $neto;

            $normalizado['total'] =
                $subtotal;

            $resultado[] =
                $normalizado;
        }

        return $resultado;
    }

    /*
    |--------------------------------------------------------------------------
    | CALCULAR TOTALES
    |--------------------------------------------------------------------------
    */

    public static function calcularTotales(
        array $items,
        array $documento,
        DocumentConfig $config
    ): array {

        $subtotal = 0.0;

        $descuento = 0.0;

        $iva = 0.0;

        foreach ($items as $item) {

            $cantidad =
                (float) (
                    $item['cantidad']
                    ?? 0
                );

            $precio =
                (float) (
                    $item['precio_unitario']
                    ?? 0
                );

            $descuentoPorcentaje =
                (float) (
                    $item['descuento']
                    ?? 0
                );

            $ivaPorcentaje =
                (float) (
                    $item['iva_porcentaje']
                    ?? 0
                );

            $bruto =
                round(
                    $cantidad *
                    $precio,
                    2
                );

            $descuentoLinea =
                $config->permiteDescuento()
                    ? round(
                        $bruto *
                        $descuentoPorcentaje /
                        100,
                        2
                    )
                    : 0;

            $neto =
                max(
                    0,
                    round(
                        $bruto -
                        $descuentoLinea,
                        2
                    )
                );

            $ivaLinea =
                $config->permiteIva()
                    ? round(
                        $neto *
                        $ivaPorcentaje /
                        100,
                        2
                    )
                    : 0;

            $subtotal += $neto;

            $descuento +=
                $descuentoLinea;

            $iva +=
                $ivaLinea;
        }

        /*
         * Descuento global opcional.
         */

        $descuentoGlobal =
            (float) (
                $documento['descuento_global']
                ?? 0
            );

        if ($descuentoGlobal < 0) {
            $descuentoGlobal = 0;
        }

        $descuentoGlobal =
            min(
                $descuentoGlobal,
                $subtotal
            );

        $subtotalFinal =
            round(
                $subtotal -
                $descuentoGlobal,
                2
            );

        /*
         * IVA global.
         *
         * Normalmente el IVA viene por línea.
         * Por eso NO lo recalculamos acá.
         */

        $total =
            round(
                $subtotalFinal +
                $iva,
                2
            );

        return [
            'subtotal' =>
                round(
                    $subtotal,
                    2
                ),

            'descuento' =>
                round(
                    $descuento +
                    $descuentoGlobal,
                    2
                ),

            'iva' =>
                round(
                    $iva,
                    2
                ),

            'total' =>
                max(
                    0,
                    $total
                ),
        ];
    }
}
```
