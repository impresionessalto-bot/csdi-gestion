<?php

declare(strict_types=1);

namespace App\Components\Documentos;

use InvalidArgumentException;

/**
 * =========================================================
 * ERP CSDI PRO
 *
 * COMPONENTE TRANSVERSAL DE DOCUMENTOS
 *
 * DocumentConfig
 *
 * Define las reglas de comportamiento de cada tipo de
 * documento del ERP.
 *
 * NO guarda información.
 * NO consulta BD.
 * NO modifica stock.
 *
 * =========================================================
 */
final class DocumentConfig
{
    /**
     * Configuración interna.
     *
     * @var array<string,mixed>
     */
    private array $config;

    /**
     * Constructor.
     *
     * @param array<string,mixed> $config
     */
    public function __construct(array $config)
    {
        if (!isset($config['tipo'])) {
            throw new InvalidArgumentException(
                'La configuración del documento debe indicar un tipo.'
            );
        }

        $tipo = strtoupper(
            trim(
                (string) $config['tipo']
            )
        );

        if ($tipo === '') {
            throw new InvalidArgumentException(
                'El tipo de documento no puede estar vacío.'
            );
        }

        $defaults = [
            'tipo' => $tipo,

            'nombre' => $tipo,

            'descripcion' => '',

            /*
             * Tercero.
             *
             * cliente / proveedor
             */
            'tercero' => 'cliente',

            'tercero_label' => 'Cliente',

            'tercero_required' => true,

            /*
             * Fecha.
             */
            'permite_fecha' => true,

            /*
             * Moneda.
             */
            'permite_moneda' => true,

            'moneda_default' => 'ARS',

            'permite_cotizacion' => true,

            /*
             * Lista de precios.
             */
            'permite_lista_precios' => false,

            'lista_precio_default' => null,

            /*
             * Artículos.
             */
            'permite_articulos' => true,

            'permite_servicios' => true,

            'permite_cantidad_decimal' => true,

            'cantidad_minima' => 0.001,

            'precio_minimo' => 0,

            'max_items' => 500,

            /*
             * Descuentos.
             */
            'permite_descuento' => true,

            'descuento_maximo' => 100,

            /*
             * IVA.
             */
            'permite_iva' => true,

            /*
             * Comprobante.
             */
            'permite_comprobante' => false,

            'permite_punto_venta' => false,

            'permite_numero' => false,

            /*
             * Vendedor / usuario.
             */
            'permite_vendedor' => true,

            /*
             * Observaciones.
             */
            'permite_observacion' => true,

            /*
             * Stock.
             *
             * none
             * entrada
             * salida
             */
            'movimiento_stock' => 'none',

            /*
             * Estado inicial.
             */
            'estado_default' => 'BORRADOR',

            /*
             * Flujo documental.
             */
            'documento_origen_permitido' => null,

            'documentos_destino' => [],

            /*
             * Adjuntos.
             */
            'permite_adjuntos' => true,

            /*
             * Pantalla.
             */
            'mostrar_precio' => true,

            'mostrar_descuento' => true,

            'mostrar_iva' => true,

            'mostrar_totales' => true,

            /*
             * Metadatos adicionales.
             */
            'extra' => [],
        ];

        $this->config = array_replace(
            $defaults,
            $config
        );

        $this->config['tipo'] = $tipo;

        $this->normalizar();
    }

    /**
     * Crea una configuración directamente.
     *
     * @param array<string,mixed> $config
     */
    public static function make(array $config): self
    {
        return new self($config);
    }

    /**
     * Tipo.
     */
    public function tipo(): string
    {
        return (string) $this->config['tipo'];
    }

    /**
     * Nombre visible.
     */
    public function nombre(): string
    {
        return (string) $this->config['nombre'];
    }

    /**
     * Descripción.
     */
    public function descripcion(): string
    {
        return (string) $this->config['descripcion'];
    }

    /**
     * Campo de tercero.
     */
    public function tercero(): string
    {
        return (string) $this->config['tercero'];
    }

    /**
     * Etiqueta del tercero.
     */
    public function terceroLabel(): string
    {
        return (string) $this->config['tercero_label'];
    }

    /**
     * Tercero obligatorio.
     */
    public function terceroRequired(): bool
    {
        return (bool) $this->config['tercero_required'];
    }

    /**
     * Fecha.
     */
    public function permiteFecha(): bool
    {
        return (bool) $this->config['permite_fecha'];
    }

    /**
     * Moneda.
     */
    public function permiteMoneda(): bool
    {
        return (bool) $this->config['permite_moneda'];
    }

    /**
     * Moneda por defecto.
     */
    public function monedaDefault(): string
    {
        return (string) $this->config['moneda_default'];
    }

    /**
     * Cotización.
     */
    public function permiteCotizacion(): bool
    {
        return (bool) $this->config['permite_cotizacion'];
    }

    /**
     * Lista de precios.
     */
    public function permiteListaPrecios(): bool
    {
        return (bool) $this->config['permite_lista_precios'];
    }

    /**
     * Lista de precios por defecto.
     */
    public function listaPrecioDefault(): ?int
    {
        $value = $this->config['lista_precio_default'];

        if ($value === null) {
            return null;
        }

        $id = (int) $value;

        return $id > 0
            ? $id
            : null;
    }

    /**
     * Artículos.
     */
    public function permiteArticulos(): bool
    {
        return (bool) $this->config['permite_articulos'];
    }

    /**
     * Servicios.
     */
    public function permiteServicios(): bool
    {
        return (bool) $this->config['permite_servicios'];
    }

    /**
     * Cantidad decimal.
     */
    public function permiteCantidadDecimal(): bool
    {
        return (bool) $this->config['permite_cantidad_decimal'];
    }

    /**
     * Cantidad mínima.
     */
    public function cantidadMinima(): float
    {
        return (float) $this->config['cantidad_minima'];
    }

    /**
     * Precio mínimo.
     */
    public function precioMinimo(): float
    {
        return (float) $this->config['precio_minimo'];
    }

    /**
     * Máximo de artículos.
     */
    public function maxItems(): int
    {
        return (int) $this->config['max_items'];
    }

    /**
     * Descuento.
     */
    public function permiteDescuento(): bool
    {
        return (bool) $this->config['permite_descuento'];
    }

    /**
     * Descuento máximo.
     */
    public function descuentoMaximo(): float
    {
        return (float) $this->config['descuento_maximo'];
    }

    /**
     * IVA.
     */
    public function permiteIva(): bool
    {
        return (bool) $this->config['permite_iva'];
    }

    /**
     * Comprobante.
     */
    public function permiteComprobante(): bool
    {
        return (bool) $this->config['permite_comprobante'];
    }

    /**
     * Punto de venta.
     */
    public function permitePuntoVenta(): bool
    {
        return (bool) $this->config['permite_punto_venta'];
    }

    /**
     * Número.
     */
    public function permiteNumero(): bool
    {
        return (bool) $this->config['permite_numero'];
    }

    /**
     * Vendedor.
     */
    public function permiteVendedor(): bool
    {
        return (bool) $this->config['permite_vendedor'];
    }

    /**
     * Observación.
     */
    public function permiteObservacion(): bool
    {
        return (bool) $this->config['permite_observacion'];
    }

    /**
     * Movimiento de stock.
     *
     * none / entrada / salida
     */
    public function movimientoStock(): string
    {
        return (string) $this->config['movimiento_stock'];
    }

    /**
     * ¿Ingresa stock?
     */
    public function afectaStockEntrada(): bool
    {
        return $this->movimientoStock() === 'entrada';
    }

    /**
     * ¿Sale stock?
     */
    public function afectaStockSalida(): bool
    {
        return $this->movimientoStock() === 'salida';
    }

    /**
     * Estado inicial.
     */
    public function estadoDefault(): string
    {
        return (string) $this->config['estado_default'];
    }

    /**
     * Documento origen permitido.
     *
     * @return string|null
     */
    public function documentoOrigenPermitido(): ?string
    {
        $value =
            $this->config[
                'documento_origen_permitido'
            ];

        if ($value === null) {
            return null;
        }

        return strtoupper(
            trim((string) $value)
        );
    }

    /**
     * Documentos destino.
     *
     * @return array<int,string>
     */
    public function documentosDestino(): array
    {
        return $this->config['documentos_destino'];
    }

    /**
     * Adjuntos.
     */
    public function permiteAdjuntos(): bool
    {
        return (bool) $this->config['permite_adjuntos'];
    }

    /**
     * Mostrar precio.
     */
    public function mostrarPrecio(): bool
    {
        return (bool) $this->config['mostrar_precio'];
    }

    /**
     * Mostrar descuento.
     */
    public function mostrarDescuento(): bool
    {
        return (bool) $this->config['mostrar_descuento'];
    }

    /**
     * Mostrar IVA.
     */
    public function mostrarIva(): bool
    {
        return (bool) $this->config['mostrar_iva'];
    }

    /**
     * Mostrar totales.
     */
    public function mostrarTotales(): bool
    {
        return (bool) $this->config['mostrar_totales'];
    }

    /**
     * Devuelve un valor adicional.
     */
    public function extra(string $key, mixed $default = null): mixed
    {
        $extra = $this->config['extra'];

        return $extra[$key] ?? $default;
    }

    /**
     * Devuelve toda la configuración.
     *
     * @return array<string,mixed>
     */
    public function toArray(): array
    {
        return $this->config;
    }

    /**
     * Normalización interna.
     */
    private function normalizar(): void
    {
        $this->config['tercero'] =
            strtolower(
                trim(
                    (string) $this->config['tercero']
                )
            );

        if (
            !in_array(
                $this->config['tercero'],
                [
                    'cliente',
                    'proveedor',
                ],
                true
            )
        ) {
            throw new InvalidArgumentException(
                'El tercero debe ser cliente o proveedor.'
            );
        }

        $this->config['moneda_default'] =
            strtoupper(
                trim(
                    (string) $this->config['moneda_default']
                )
            );

        if (
            !in_array(
                $this->config['moneda_default'],
                ['ARS', 'USD'],
                true
            )
        ) {
            $this->config['moneda_default'] = 'ARS';
        }

        $this->config['cantidad_minima'] =
            max(
                0.000001,
                (float) $this->config['cantidad_minima']
            );

        $this->config['precio_minimo'] =
            max(
                0,
                (float) $this->config['precio_minimo']
            );

        $this->config['max_items'] =
            max(
                1,
                (int) $this->config['max_items']
            );

        $this->config['descuento_maximo'] =
            min(
                100,
                max(
                    0,
                    (float) $this->config['descuento_maximo']
                )
            );

        $movimiento =
            strtolower(
                trim(
                    (string) $this->config['movimiento_stock']
                )
            );

        if (
            !in_array(
                $movimiento,
                [
                    'none',
                    'entrada',
                    'salida',
                ],
                true
            )
        ) {
            $movimiento = 'none';
        }

        $this->config['movimiento_stock'] =
            $movimiento;

        $this->config['estado_default'] =
            strtoupper(
                trim(
                    (string) $this->config['estado_default']
                )
            );

        if ($this->config['estado_default'] === '') {
            $this->config['estado_default'] =
                'BORRADOR';
        }

        if (
            !is_array(
                $this->config['documentos_destino']
            )
        ) {
            $this->config['documentos_destino'] = [];
        }

        $destinos = [];

        foreach (
            $this->config['documentos_destino']
            as $destino
        ) {
            if (!is_scalar($destino)) {
                continue;
            }

            $destino =
                strtoupper(
                    trim(
                        (string) $destino
                    )
                );

            if ($destino !== '') {
                $destinos[] = $destino;
            }
        }

        $this->config['documentos_destino'] =
            array_values(
                array_unique($destinos)
            );

        if (
            !is_array(
                $this->config['extra']
            )
        ) {
            $this->config['extra'] = [];
        }
    }
}