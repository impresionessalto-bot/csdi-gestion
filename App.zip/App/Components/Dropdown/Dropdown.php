<?php

declare(strict_types=1);

namespace App\Components\Dropdown;

use function htmlspecialchars;

final class Dropdown
{
    private string $label = 'Acciones';

    private string $buttonClass = 'btn btn-sm btn-light border dropdown-toggle';

    private string $icon = 'three-dots';

    private array $items = [];

    /**
     * ---------------------------------------------------------
     * FACTORY
     * ---------------------------------------------------------
     */
    public static function make(): self
    {
        return new self();
    }

    /**
     * ---------------------------------------------------------
     * LABEL
     * ---------------------------------------------------------
     */
    public function label(string $label): self
    {
        $this->label = $label;
        return $this;
    }

    /**
     * ---------------------------------------------------------
     * BUTTON CLASS
     * ---------------------------------------------------------
     */
    public function buttonClass(string $class): self
    {
        $this->buttonClass = $class;
        return $this;
    }

    /**
     * ---------------------------------------------------------
     * ICON (reservado futuro)
     * ---------------------------------------------------------
     */
    public function icon(string $icon): self
    {
        $this->icon = $icon;
        return $this;
    }

    /**
     * ---------------------------------------------------------
     * ITEM
     * ---------------------------------------------------------
     */
    public function item(
        string $text,
        string $url = '#',
        ?string $icon = null,
        bool $danger = false,
        bool $confirm = false
    ): self {

        $this->items[] = [
            'type'    => 'item',
            'text'    => $text,
            'url'     => $url,
            'icon'    => $icon,
            'danger'  => $danger,
            'confirm' => $confirm
        ];

        return $this;
    }

    /**
     * ---------------------------------------------------------
     * DIVIDER
     * ---------------------------------------------------------
     */
    public function divider(): self
    {
        $this->items[] = [
            'type' => 'divider'
        ];

        return $this;
    }

    /**
     * ---------------------------------------------------------
     * RENDER (SIN view(), FULL HTML)
     * ---------------------------------------------------------
     */
    public function render(): string
    {
        $html = '<div class="dropdown">';

        $html .= '<button type="button" class="' . htmlspecialchars($this->buttonClass) . '" data-bs-toggle="dropdown" aria-expanded="false">';
        $html .= htmlspecialchars($this->label);
        $html .= '</button>';

        $html .= '<ul class="dropdown-menu dropdown-menu-end">';

        foreach ($this->items as $item) {

            // DIVIDER
            if ($item['type'] === 'divider') {
                $html .= '<li><hr class="dropdown-divider"></li>';
                continue;
            }

            $text = htmlspecialchars($item['text']);
            $url  = htmlspecialchars($item['url']);

            $dangerClass = $item['danger'] ? 'text-danger' : '';

            $confirmAttr = '';

            if (!empty($item['confirm'])) {
                $confirmAttr = 'onclick="return confirm(\'¿Estás seguro?\')"';
            }

            $html .= '<li>';
            $html .= "<a class='dropdown-item {$dangerClass}' href='{$url}' {$confirmAttr}>";
            $html .= $text;
            $html .= '</a>';
            $html .= '</li>';
        }

        $html .= '</ul>';
        $html .= '</div>';

        return $html;
    }

    /**
     * ---------------------------------------------------------
     * GETTERS (compatibilidad futura)
     * ---------------------------------------------------------
     */
    public function getLabel(): string
    {
        return $this->label;
    }

    public function getButtonClass(): string
    {
        return $this->buttonClass;
    }

    public function getIcon(): string
    {
        return $this->icon;
    }

    public function getItems(): array
    {
        return $this->items;
    }
}