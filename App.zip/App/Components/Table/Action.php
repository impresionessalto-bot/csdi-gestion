<?php

declare(strict_types=1);

namespace App\Components\Table;


final class Action
{

    public function __construct(
        private string $name
    )
    {}



    public function name(): string
    {
        return $this->name;
    }

}