<?php

declare(strict_types=1);

namespace App\Components\Table;


final class Column
{

    public function __construct(
        private string $label,
        private string $field
    )
    {}



    public function label(): string
    {
        return $this->label;
    }



    public function field(): string
    {
        return $this->field;
    }

}