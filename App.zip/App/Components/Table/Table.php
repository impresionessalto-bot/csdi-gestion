<?php

declare(strict_types=1);

namespace App\Components\Table;

use App\Components\Toolbar\Toolbar;
use App\Components\Pagination\Pagination;


final class Table
{

    private string $title = '';

    private ?string $repository = null;


    /**
     * Columnas
     */
    private array $columns = [];


    /**
     * Acciones
     */
    private array $actions = [];


    /**
     * Toolbar
     */
    private ?Toolbar $toolbar = null;


    /**
     * Pagination
     */
    private ?Pagination $pagination = null;



    /**
     * Datos de tabla
     */
    private array $data = [];



    /**
     * Crear Table
     */
    public static function make(): self
    {
        return new self();
    }





    /**
     * Título
     */
    public function title(
        string $title
    ): self {

        $this->title = $title;

        return $this;

    }





    /**
     * Repository asociado
     */
    public function repository(
        string $repository
    ): self {

        $this->repository = $repository;

        return $this;

    }





    /**
     * Agregar columna
     */
    public function column(
        string $label,
        ?string $field = null
    ): self {


        $this->columns[] = new Column(

            $label,

            $field 
                ??
            strtolower(
                str_replace(
                    ' ',
                    '_',
                    $label
                )
            )

        );


        return $this;

    }





    /**
     * Agregar acciones
     */
    public function actions(
        array $actions
    ): self {


        foreach($actions as $action){

            $this->actions[] =
                new Action($action);

        }


        return $this;

    }





    /**
     * Asociar Toolbar
     */
    public function toolbar(
        Toolbar $toolbar
    ): self {


        $this->toolbar = $toolbar;


        return $this;

    }





    /**
     * Asociar Pagination
     */
    public function pagination(
        Pagination $pagination
    ): self {


        $this->pagination = $pagination;


        return $this;

    }





    /**
     * Cargar datos manualmente
     * (futuro Service/Repository)
     */
    public function data(
        array $data
    ): self {


        $this->data = $data;


        return $this;

    }





    /**
     * Render
     */
    public function render(): string
    {


        return view(

            'components/table',

            [
                'table'=>$this
            ]

        );


    }






    public function getTitle(): string
    {
        return $this->title;
    }





    public function getRepository(): ?string
    {
        return $this->repository;
    }





    public function getColumns(): array
    {
        return $this->columns;
    }





    public function getActions(): array
    {
        return $this->actions;
    }





    public function getToolbar(): ?Toolbar
    {
        return $this->toolbar;
    }





    public function getPagination(): ?Pagination
    {
        return $this->pagination;
    }





    public function getData(): array
    {
        return $this->data;
    }


}