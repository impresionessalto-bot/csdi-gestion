<?php

declare(strict_types=1);

namespace App\Components\Toolbar;

use App\Components\Buttons\Button;


final class Toolbar
{

    private array $buttons = [];

    private array $filters = [];

    private bool $search = false;



    /**
     * Crear Toolbar
     */
    public static function make(): self
    {
        return new self();
    }




    /**
     * Activar buscador
     */
    public function search(
        bool $enabled = true
    ): self {

        $this->search = $enabled;

        return $this;

    }





    /**
     * Agregar filtro
     */
    public function filter(
        string $name
    ): self {

        $this->filters[] = $name;

        return $this;

    }





    /**
     * Agregar botón
     */
    public function button(
        Button $button
    ): self {


        $this->buttons[] = $button;


        return $this;

    }





    /**
     * Atajo para crear botones rápidos
     */
    public function addButton(
        string $label,
        string $type = 'primary',
        ?string $url = null
    ): self {


        $button = Button::make()

            ->label($label)

            ->type($type);



        if($url){

            $button->url($url);

        }



        $this->buttons[] = $button;


        return $this;

    }





    /**
     * Render
     */
    public function render(): string
    {

        return view(
            'components/toolbar',
            [
                'toolbar'=>$this
            ]
        );

    }





    public function hasSearch(): bool
    {
        return $this->search;
    }





    public function getFilters(): array
    {
        return $this->filters;
    }





    public function getButtons(): array
    {
        return $this->buttons;
    }


}