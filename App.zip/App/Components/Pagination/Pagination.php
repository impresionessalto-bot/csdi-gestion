<?php

declare(strict_types=1);

namespace App\Components\Pagination;


final class Pagination
{

    private int $currentPage = 1;

    private int $totalPages = 1;

    private string $baseUrl = '';

    private array $parameters = [];



    /**
     * Crear Pagination
     */
    public static function make(): self
    {
        return new self();
    }




    /**
     * Página actual
     */
    public function current(
        int $page
    ): self {

        $this->currentPage = $page;

        return $this;

    }





    /**
     * Total de páginas
     */
    public function total(
        int $pages
    ): self {

        $this->totalPages = max(
            1,
            $pages
        );

        return $this;

    }





    /**
     * URL base
     */
    public function url(
        string $url
    ): self {

        $this->baseUrl = $url;

        return $this;

    }





    /**
     * Parámetros adicionales
     */
    public function parameter(
        string $key,
        string $value
    ): self {

        $this->parameters[$key] = $value;

        return $this;

    }





    /**
     * Render
     */
    public function render(): string
    {

        return view(
            'components/pagination',
            [
                'pagination'=>$this
            ]
        );

    }





    public function getCurrent(): int
    {
        return $this->currentPage;
    }




    public function getTotal(): int
    {
        return $this->totalPages;
    }




    public function getUrl(): string
    {
        return $this->baseUrl;
    }




    public function getParameters(): array
    {
        return $this->parameters;
    }


}