<?php

declare(strict_types=1);

namespace App\Components\Buttons;

use App\Core\Component;


final class Button extends Component
{

    private string $label = '';

    private string $type = 'primary';

    private ?string $url = null;

    private ?string $icon = null;

    private array $attributes = [];





    public function __construct()
    {

        $this->setView(
            'components/button'
        );

    }






    /**
     * Crear botón
     */
    public static function make(): self
    {
        return new self();
    }






    /**
     * Texto
     */
    public function label(
        string $label
    ): self {


        $this->label = $label;


        return $this;

    }






    /**
     * Tipo visual
     */
    public function type(
        string $type
    ): self {


        $this->type = $type;


        return $this;

    }






    /**
     * URL
     */
    public function url(
        string $url
    ): self {


        $this->url = $url;


        return $this;

    }






    /**
     * Icono
     */
    public function icon(
        string $icon
    ): self {


        $this->icon = $icon;


        return $this;

    }






    /**
     * Atributos HTML
     */
    public function attribute(
        string $name,
        string $value
    ): self {


        $this->attributes[$name] = $value;


        return $this;

    }







    /**
     * Render heredado
     */
    public function render(): string
    {

        return parent::render();


    }






    public function getLabel(): string
    {
        return $this->label;
    }






    public function getType(): string
    {
        return $this->type;
    }






    public function getUrl(): ?string
    {
        return $this->url;
    }






    public function getIcon(): ?string
    {
        return $this->icon;
    }






    public function getAttributes(): array
    {
        return $this->attributes;
    }


}