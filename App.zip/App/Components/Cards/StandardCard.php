<?php

declare(strict_types=1);

namespace App\Components\Cards;

use App\Core\Component;

/**
 * Componente de tarjeta estándar para el ERP CSDI PRO.
 */
final class StandardCard extends Component
{
    public function __construct()
    {
        // Definimos la ruta de la vista que procesará este componente
        // El helper view() resolverá esta ruta según la configuración global del sistema
        $this->setView('components/cards/standard-card');
    }
}