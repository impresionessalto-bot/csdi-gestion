<?php

declare(strict_types=1);

namespace App\Components\Cards;


final class Card
{

    private string $title = '';

    private string $value = '';

    private ?string $description = null;

    private ?string $icon = null;

    private string $type = 'default';



    /**
     * Crear Card
     */
    public static function make(): self
    {
        return new self();
    }




    /**
     * Título
     */
    public function title(
        string $title
    ): self {

        $this->title = $title;

        return $this;

    }




    /**
     * Valor principal
     */
    public function value(
        string|int|float $value
    ): self {

        $this->value = (string)$value;

        return $this;

    }




    /**
     * Descripción
     */
    public function description(
        string $description
    ): self {

        $this->description = $description;

        return $this;

    }




    /**
     * Icono
     */
    public function icon(
        string $icon
    ): self {

        $this->icon = $icon;

        return $this;

    }




    /**
     * Tipo visual
     */
    public function type(
        string $type
    ): self {

        $this->type = $type;

        return $this;

    }




    /**
     * Render
     */
    public function render(): string
    {

        return view(
            'components/card',
            [
                'card'=>$this
            ]
        );

    }





    public function getTitle(): string
    {
        return $this->title;
    }



    public function getValue(): string
    {
        return $this->value;
    }



    public function getDescription(): ?string
    {
        return $this->description;
    }



    public function getIcon(): ?string
    {
        return $this->icon;
    }



    public function getType(): string
    {
        return $this->type;
    }


}