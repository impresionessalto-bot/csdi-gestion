<?php

declare(strict_types=1);

namespace App\Components\Badge;


final class Badge
{

    private string $text = '';

    private string $type = 'secondary';

    private ?string $icon = null;



    /**
     * Crear Badge
     */
    public static function make(): self
    {
        return new self();
    }





    /**
     * Texto del badge
     */
    public function text(
        string $text
    ): self {

        $this->text = $text;

        return $this;

    }





    /**
     * Tipo visual
     *
     * success
     * danger
     * warning
     * primary
     * secondary
     */
    public function type(
        string $type
    ): self {

        $this->type = $type;

        return $this;

    }





    /**
     * Icono opcional
     */
    public function icon(
        string $icon
    ): self {

        $this->icon = $icon;

        return $this;

    }





    /**
     * Render
     */
    public function render(): string
    {

        return view(
            'components/badge',
            [
                'badge'=>$this
            ]
        );

    }





    public function getText(): string
    {
        return $this->text;
    }




    public function getType(): string
    {
        return $this->type;
    }




    public function getIcon(): ?string
    {
        return $this->icon;
    }


}