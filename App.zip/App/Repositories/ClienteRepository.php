<?php
declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class ClienteRepository
{
    public function __construct(
        private PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO GENERAL
    |--------------------------------------------------------------------------
    */
    public function all(): array
    {
        $stmt = $this->db->query("
            SELECT *
            FROM clientes
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | COMBO
    |--------------------------------------------------------------------------
    */
    public function combo(): array
    {
        $stmt = $this->db->query("
            SELECT
                id,
                nombre
            FROM clientes
            WHERE activo = 1
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | CLIENTES POR LOCALIDAD
    |--------------------------------------------------------------------------
    */
    public function porLocalidad(int $localidadId): array 
    {
        $stmt = $this->db->prepare("
            SELECT
                id,
                nombre
            FROM clientes
            WHERE
                activo = 1
                AND localidad_id = ?
            ORDER BY nombre ASC
        ");

        $stmt->execute([$localidadId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR POR ID
    |--------------------------------------------------------------------------
    */
    public function find(int $id): ?array 
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM clientes
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCADOR GENERAL
    |--------------------------------------------------------------------------
    */
    public function search(string $texto): array 
    {
        $buscar = "%{$texto}%";

        $stmt = $this->db->prepare("
            SELECT
                id,
                nombre,
                telefono,
                email
            FROM clientes
            WHERE
                activo = 1
                AND (
                    nombre LIKE ?
                    OR telefono LIKE ?
                    OR email LIKE ?
                )
            ORDER BY nombre ASC
        ");

        $stmt->execute([$buscar, $buscar, $buscar]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | AUTOCOMPLETE (TomSelect / Select2)
    |--------------------------------------------------------------------------
    */
    public function autocomplete(string $texto, int $limite = 20): array 
    {
        $stmt = $this->db->prepare("
            SELECT
                id,
                nombre
            FROM clientes
            WHERE
                activo = 1
                AND nombre LIKE ?
            ORDER BY nombre ASC
            LIMIT ?
        ");

        $stmt->bindValue(1, "%{$texto}%");
        $stmt->bindValue(2, $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR (Sincronizado con todas las columnas de la BD)
    |--------------------------------------------------------------------------
    */
    public function create(array $data): int 
    {
        $stmt = $this->db->prepare("
            INSERT INTO clientes
            (
                nombre,
                razon_social,
                cuit,
                direccion,
                localidad_id,
                email,
                telefono,
                activo
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, 1)
        ");

        $stmt->execute([
            $data['nombre'] ?? '',
            $data['razon_social'] ?? '',
            $data['cuit'] ?? '',
            $data['direccion'] ?? '',
            $data['localidad_id'] ?? null,
            $data['email'] ?? '',
            $data['telefono'] ?? ''
        ]);

        return (int)$this->db->lastInsertId();
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR (Sincronizado con todas las columnas de la BD)
    |--------------------------------------------------------------------------
    */
    public function update(int $id, array $data): bool 
    {
        $stmt = $this->db->prepare("
            UPDATE clientes
            SET
                nombre = ?,
                razon_social = ?,
                cuit = ?,
                direccion = ?,
                localidad_id = ?,
                email = ?,
                telefono = ?
            WHERE id = ?
        ");

        return $stmt->execute([
            $data['nombre'] ?? '',
            $data['razon_social'] ?? '',
            $data['cuit'] ?? '',
            $data['direccion'] ?? '',
            $data['localidad_id'] ?? null,
            $data['email'] ?? '',
            $data['telefono'] ?? '',
            $id
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | BAJA LÓGICA
    |--------------------------------------------------------------------------
    */
    public function delete(int $id): bool 
    {
        $stmt = $this->db->prepare("
            UPDATE clientes
            SET activo = 0
            WHERE id = ?
        ");

        return $stmt->execute([$id]);
    }
}