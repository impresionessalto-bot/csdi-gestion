<?php
declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class EquipoRepository
{
    public function __construct(
        private PDO $db
    ) {
    }

    /*
    |--------------------------------------------------------------------------
    | LISTADO GENERAL
    |--------------------------------------------------------------------------
    */
    public function all(): array
    {
        $stmt = $this->db->query("
            SELECT e.*, c.nombre as cliente_nombre, m.nombre_modelo, m.marca
            FROM equipos e
            LEFT JOIN clientes c ON e.cliente_id = c.id
            LEFT JOIN modelos_equipos m ON e.modelo_id = m.id
            WHERE e.deleted_at IS NULL
            ORDER BY e.id DESC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR POR ID
    |--------------------------------------------------------------------------
    */
    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT e.*, c.nombre as cliente_nombre, m.nombre_modelo, m.marca
            FROM equipos e
            LEFT JOIN clientes c ON e.cliente_id = c.id
            LEFT JOIN modelos_equipos m ON e.modelo_id = m.id
            WHERE e.id = ? AND e.deleted_at IS NULL
            LIMIT 1
        ");

        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | BUSCAR POR NÚMERO DE SERIE
    |--------------------------------------------------------------------------
    */
    public function findBySerie(string $serie): ?array
    {
        $stmt = $this->db->prepare("
            SELECT * 
            FROM equipos 
            WHERE serie = ? AND deleted_at IS NULL 
            LIMIT 1
        ");

        $stmt->execute([trim($serie)]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /*
    |--------------------------------------------------------------------------
    | FILTRAR POR PROPIEDAD o ESTADO (TNG, CSDI, Taller, etc.)
    |--------------------------------------------------------------------------
    */
    public function porPropiedadYEstado(string $propiedad, ?string $estado = null): array
    {
        $sql = "SELECT * FROM equipos WHERE propiedad = ? AND deleted_at IS NULL";
        $params = [$propiedad];

        if ($estado !== null) {
            $sql .= " AND estado = ?";
            $params[] = $estado;
        }

        $sql .= " ORDER BY id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    |--------------------------------------------------------------------------
    | CREAR EQUIPO
    |--------------------------------------------------------------------------
    */
    public function create(array $data): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO equipos (
                codigo_interno, cliente_id, cod_item_dux, modelo_id, serie,
                identificador_externo, propiedad, estado, ubicacion_actual,
                origen_compra, fecha_registro, abono_minimo_mono, abono_minimo_color,
                voltaje, valor_activo, init_k, init_c, init_m, init_y, 
                localidad_id, direccion_equipo, observaciones, activo
            ) VALUES (
                ?, ?, ?, ?, ?, 
                ?, ?, ?, ?, 
                ?, ?, ?, ?, 
                ?, ?, ?, ?, ?, ?, 
                ?, ?, ?, 1
            )
        ");

        $stmt->execute([
            $data['codigo_interno'] ?? null,
            $data['cliente_id'] ?? null,
            $data['cod_item_dux'] ?? null,
            $data['modelo_id'] ?? null,
            $data['serie'] ?? '',
            $data['identificador_externo'] ?? null,
            $data['propiedad'] ?? 'CSDI',
            $data['estado'] ?? 'Disponible',
            $data['ubicacion_actual'] ?? null,
            $data['origen_compra'] ?? null,
            $data['fecha_registro'] ?? date('Y-m-d'),
            $data['abono_minimo_mono'] ?? 0,
            $data['abono_minimo_color'] ?? 0,
            $data['voltaje'] ?? '220V',
            $data['valor_activo'] ?? 0.00,
            $data['init_k'] ?? 100,
            $data['init_c'] ?? 100,
            $data['init_m'] ?? 100,
            $data['init_y'] ?? 100,
            $data['localidad_id'] ?? null,
            $data['direccion_equipo'] ?? null,
            $data['observaciones'] ?? null
        ]);

        return (int)$this->db->lastInsertId();
    }

    /*
    |--------------------------------------------------------------------------
    | ACTUALIZAR EQUIPO
    |--------------------------------------------------------------------------
    */
    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare("
            UPDATE equipos SET
                codigo_interno = ?,
                cliente_id = ?,
                cod_item_dux = ?,
                modelo_id = ?,
                serie = ?,
                identificador_externo = ?,
                propiedad = ?,
                estado = ?,
                ubicacion_actual = ?,
                origen_compra = ?,
                abono_minimo_mono = ?,
                abono_minimo_color = ?,
                voltaje = ?,
                valor_activo = ?,
                localidad_id = ?,
                direccion_equipo = ?,
                observaciones = ?,
                activo = ?
            WHERE id = ? AND deleted_at IS NULL
        ");

        return $stmt->execute([
            $data['codigo_interno'] ?? null,
            $data['cliente_id'] ?? null,
            $data['cod_item_dux'] ?? null,
            $data['modelo_id'] ?? null,
            $data['serie'] ?? '',
            $data['identificador_externo'] ?? null,
            $data['propiedad'] ?? 'CSDI',
            $data['estado'] ?? 'Activo',
            $data['ubicacion_actual'] ?? null,
            $data['origen_compra'] ?? null,
            $data['abono_minimo_mono'] ?? 0,
            $data['abono_minimo_color'] ?? 0,
            $data['voltaje'] ?? '220V',
            $data['valor_activo'] ?? 0.00,
            $data['localidad_id'] ?? null,
            $data['direccion_equipo'] ?? null,
            $data['observaciones'] ?? null,
            $data['activo'] ?? 1,
            $id
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | ELIMINAR (Soft Delete / Baja lógica)
    |--------------------------------------------------------------------------
    */
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE equipos 
            SET deleted_at = NOW(), activo = 0 
            WHERE id = ?
        ");

        return $stmt->execute([$id]);
    }
}