<?php
declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class LocalidadRepository // <-- Asegurate de que acá diga Repository y NO Service
{
    public function __construct(
        private PDO $db
    ) {
    }

    /**
     * Todas las localidades
     */
    public function all(): array
    {
        $stmt = $this->db->query("
            SELECT *
            FROM localidades
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Buscar por ID
     */
    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM localidades
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$id]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Buscar por nombre
     */
    public function search(string $texto): array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM localidades
            WHERE nombre LIKE ?
            ORDER BY nombre ASC
        ");

        $stmt->execute([
            "%{$texto}%"
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Combo básico para selectores
     */
    public function combo(): array
    {
        $stmt = $this->db->query("
            SELECT
                id,
                nombre
            FROM localidades
            ORDER BY nombre ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Crear incluyendo viático por defecto
     */
    public function create(array $data): int
    {
        $stmt = $this->db->prepare("
            INSERT INTO localidades
            (
                nombre,
                importe_viatico
            )
            VALUES
            (?, ?)
        ");

        $stmt->execute([
            $data['nombre'] ?? '',
            $data['importe_viatico'] ?? 0.00
        ]);

        return (int)$this->db->lastInsertId();
    }

    /**
     * Modificar incluyendo viático
     */
    public function update(int $id, array $data): bool 
    {
        $stmt = $this->db->prepare("
            UPDATE localidades
            SET 
                nombre = ?,
                importe_viatico = ?
            WHERE id = ?
        ");

        return $stmt->execute([
            $data['nombre'] ?? '',
            $data['importe_viatico'] ?? 0.00,
            $id
        ]);
    }

    /**
     * Eliminar
     */
    public function delete(int $id): bool 
    {
        $stmt = $this->db->prepare("
            DELETE FROM localidades
            WHERE id = ?
        ");

        return $stmt->execute([$id]);
    }
}