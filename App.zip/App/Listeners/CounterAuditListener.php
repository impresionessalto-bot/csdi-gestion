<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\CounterUpdatedEvent;

final class CounterAuditListener
{
    public function __construct(
        private $repo
    ) {}

    public function __invoke(CounterUpdatedEvent $event): void
    {
        $old = $event->oldData;
        $new = $event->newData;

        foreach ($new as $field => $value) {

            $oldValue = $old[$field] ?? null;

            if ($oldValue === $value) {
                continue;
            }

            $this->repo->logChange(
                $event->userId,
                $event->clienteId,
                $event->equipoId,
                $field,
                $oldValue,
                $value
            );
        }
    }
}