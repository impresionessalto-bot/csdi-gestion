<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\CounterUpdatedEvent;

final class CounterVersionListener
{
    public function __construct(
        private $repo
    ) {}

    public function __invoke(CounterUpdatedEvent $event): void
    {
        // snapshot completo del equipo antes del cambio
        $this->repo->saveVersion(
            $event->equipoId,
            $event->oldData,
            $event->userId
        );
    }
}